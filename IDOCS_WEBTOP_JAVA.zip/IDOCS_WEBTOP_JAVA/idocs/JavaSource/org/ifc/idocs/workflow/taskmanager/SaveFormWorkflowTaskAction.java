/**
* 
* This class displays the Task action atttributes during the activity.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.workflow.taskmanager;

import java.util.Map;

import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.webcomponent.library.workflow.taskmanager.WorkflowTaskComponent;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.action.IActionExecution;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.control.xforms.XForms;

// Referenced classes of package com.documentum.webcomponent.library.workflow.taskmanager:
//            taskmanager
public class SaveFormWorkflowTaskAction extends WorkflowTaskComponent implements IActionExecution
{
	public boolean execute(String strAction, IConfigElement config, ArgumentList args, Context context, Component component, Map completionArgs)
    {
    	boolean rv=false;
		try {
			DfLogger.info(this, " :: execute : "+getDfSession().getLoginUserName(), null, null);
			saveForm();
			rv=true;
		} catch (DfException e) {
			DfLogger.error(this, " :: execute Exception >> "+e.getMessage(), null, e);
		}
		return rv;
    }

    public void saveForm() throws DfException
    {
    	try
    	{
	        XForms xFormControl = (XForms)getControl("__XFORM_CONTROL_NAME", XForms.class);
	        boolean saved = xFormControl.saveForm();
	        DfLogger.info(this, " :: saveForm : Form : "+xFormControl.getElementName()+" : saved : "+saved, null, null);
    	}
    	catch(Exception e)
    	{
			DfLogger.error(this, " :: saveForm Exception >> "+e.getMessage(), null, e);
    	}
    }

    public String[] getRequiredParams()
    {
        return (new String[] {
            "objectId"
        });
    }
}