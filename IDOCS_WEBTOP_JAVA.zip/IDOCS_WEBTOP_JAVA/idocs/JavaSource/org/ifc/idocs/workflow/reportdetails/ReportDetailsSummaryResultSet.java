/**
* 
* This class is an activity for Report Detail Summary page.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* BGupta			    09/20/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.workflow.reportdetails;

import com.documentum.fc.client.IDfActivity;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfGroup;
import com.documentum.fc.client.IDfProcess;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfTime;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfTime;
import com.documentum.nls.NlsResourceClass;
import com.documentum.services.workflow.report.ITaskReport;
import com.documentum.services.workflow.report.IWorkflowReportBuilder;
import com.documentum.web.form.control.format.DateValueFormatter;
import com.documentum.web.formext.component.Component;
import com.documentum.web.util.DfcUtils;
import com.documentum.webcomponent.common.WebComponentErrorService;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

/**
 * @author bgupta
 *
 */
public class ReportDetailsSummaryResultSet extends com.documentum.webcomponent.library.workflow.reportdetails.ReportDetailsSummaryResultSet {
	private static final String DM_BPS_INBOUND_USER = "dm_bps_inbound_user";

	public ReportDetailsSummaryResultSet(Component parentComp, IWorkflowReportBuilder reportBuilder, NlsResourceClass nlsclass, String wfId, int taskFilter, boolean showAttachment)
	throws DfException
	{
		this(parentComp, reportBuilder, nlsclass, wfId, taskFilter, showAttachment, false);
	}

	@SuppressWarnings("unchecked")
	public ReportDetailsSummaryResultSet(Component parentComp, IWorkflowReportBuilder reportBuilder, NlsResourceClass nlsclass, String wfId, int taskFilter, boolean showAttachment, boolean getRuntimeReports)
	throws DfException
	{
		super(parentComp, reportBuilder, nlsclass, wfId, getRuntimeReports);
		this.m_rowMap = null;
		this.m_taskReportColl = null;
		this.m_futureActivities = null;
		this.m_futureActIndex = -1;
		this.m_rowMap = new HashMap((int)((s_columnNames.length + 1) / 0.75F));
		this.m_taskFilter = taskFilter;
		this.m_showAttachments = showAttachment;
		this.m_taskReportColl = this.m_wfReport.getTaskReports();
		try{
			int wfState = this.m_wfReport.getRuntimeState();
			String strActivityID ="";
			if ((wfState == 0) || (wfState == 3) || (wfState == 1)){
				IDfProcess processObj = (IDfProcess)this.m_session.getObject(this.m_wfReport.getProcessId());
				int actCount = processObj.getActivityCount();
				HashSet allActSet = new HashSet();
				for (int actIndex = 0; actIndex < actCount; ++actIndex){
					int actType = processObj.getActivityType(actIndex);
					strActivityID =processObj.getActivityDefId(actIndex).getId();
					// Condition added to exclude auto activity and Delay Activity for Idocs 
					if (actType != 4 && getActivityExecType(strActivityID) == 0){
						allActSet.add(strActivityID);
					}
				}
				HashSet startedActSet = new HashSet();
				IDfQuery query = DfcUtils.getClientX().getQuery();
				query.setDQL("select distinct r_act_def_id from dmi_workitem where r_workflow_id ='" + wfId + "'");
				IDfCollection coll = query.execute(this.m_session, 0);
				while (coll.next()){
					strActivityID = coll.getString("r_act_def_id");
					// Condition added to exclude auto activity and Delay Activity for Idocs 
					if(getActivityExecType(strActivityID) == 0){
						startedActSet.add(strActivityID);					
					}
				}
				if(coll != null)coll.close();
				allActSet.removeAll(startedActSet);
				if (allActSet.size() > 0){
					this.m_futureActivities = new Vector(allActSet.size());
					this.m_futureActivities.addAll(allActSet);
				}
			}
		}catch (DfException e){
			DfLogger.error(this, " :: ReportDetailsSummaryResultSet Exception >> "+e.getMessage(),null,e);
		}
	}
	
	public boolean next(){
		boolean rv = nextItem();
		if (rv){
			readRow();
		}
		else if ((rv = nextFutureActivity()))
			readFutureActivityRow();

//		DfLogger.info(this, " :: next : rv : "+rv,null,null);
		return rv;
	}
	
	
	protected boolean nextItem(){
		if (this.m_taskReportColl == null)
			return false;

		boolean rv = false;
		try {
			do {
				if (!((rv = this.m_taskReportColl.next())))
					break;
				// Condition added to exclude auto activity for Report Detail Summary page 
				if (this.m_taskFilter == 0 
						&& !(this.m_taskReportColl.isAutomatic()) 
						&& !(this.m_taskReportColl.getPerformerName().equalsIgnoreCase(DM_BPS_INBOUND_USER)))
					break;

				if ((this.m_taskFilter == 1) && 
						(this.m_taskReportColl.getRuntimeState() != 2))
					break;

				if ((this.m_taskFilter == 2) && 
						(this.m_taskReportColl.getRuntimeState() != 2) && (this.m_taskReportColl.getTimeLeft() > 0)){
					break; 
				}
			}while ((this.m_taskFilter != 3) || (this.m_taskReportColl.getRuntimeState() == -1));

			if (!(rv)){
				this.m_taskReportColl.close();
				this.m_taskReportColl = null;
			}
		}catch (DfException e){
			WebComponentErrorService.getService().setNonFatalError(getNlsResourceClass(), "MSG_NEXT_ITEM_ERROR", this.m_parentComp, null, null);
			DfLogger.error(this, " :: nextItem Exception >> "+e.getMessage(),null,e);
			return false;
		}
//		DfLogger.info(this, " :: nextItem : rv : "+rv,null,null);
		return rv;
	}
	
	protected int getActivityExecType(String actId)
	{
		IDfActivity actObj;
		int perfType=1;
		if ((actId == null) || (actId.length() == 0))
			return 0;
		try{
			actObj = (IDfActivity)this.m_session.getObject(new DfId(actId));
			perfType = actObj.getExecType();
			String activityPerformerName = actObj.getPerformerName();
			if(activityPerformerName !=null && activityPerformerName.trim().length() > 0
					&& activityPerformerName.equalsIgnoreCase(DM_BPS_INBOUND_USER) == true){
				DfLogger.info(this, " :: getActivityExecType : activityPerformerName : "+activityPerformerName,null,null);
				perfType = 0;
			}
		}catch (DfException e){
			DfLogger.error(this, " :: getActivityExecType Exception >> "+e.getMessage(),null,e);
		}
//		DfLogger.info(this, " :: getActivityExecType : ActivityExecType : "+perfType,null,null);
		return perfType;
	}
	
	protected void populateRow(ITaskReport taskReport)
	throws DfException
	{
		String strTaskPerformer = getTaskPerformer(taskReport);
		DfLogger.info(this, " :: populateRow : TaskName : "+getTaskName(taskReport) +" : strTaskPerformer="+strTaskPerformer,null,null);
		if(strTaskPerformer !=null && strTaskPerformer.trim().length() > 0
				&& strTaskPerformer.equalsIgnoreCase(DM_BPS_INBOUND_USER) == false){
			this.m_rowMap.put("task_name", getTaskName(taskReport));
			this.m_rowMap.put("status", getTaskStatus(taskReport));
			this.m_rowMap.put("action", getTaskAction(taskReport));
			IDfGroup objGroup =null;
			try{
				objGroup= (IDfGroup)this.m_session.getObjectByQualification("dm_group where group_name='"+strTaskPerformer+"'");
				if(objGroup !=  null){
					String strUsers =objGroup.getAllRepeatingStrings("i_all_users_names", "\n");
					this.m_rowMap.put("performer", "Group : "+strUsers);
					DfLogger.info(this, " :: populateRow : Users "+strUsers+" in group "+strTaskPerformer,null,null);
				}else{
					this.m_rowMap.put("performer", strTaskPerformer);
				}
			}catch(Exception e){
				DfLogger.error(this, " :: populateRow Exception >> "+e.getMessage(),null,e);
				this.m_rowMap.put("performer", strTaskPerformer);
			}
			this.m_rowMap.put("comment", getTaskComment(taskReport));
			DateValueFormatter formatter = new DateValueFormatter();
			formatter.setType("short");
			IDfTime receiveDfTime = getTaskReceiveDate(taskReport);
			Date receiveDate = DfTime.DF_NULLDATE.getDate();
			if (receiveDfTime != null)
			{
				receiveDate = receiveDfTime.getDate();
			}
			this.m_rowMap.put("receive_date", receiveDate);
	
			IDfTime dueDateDfTime = getDueDate(taskReport);
			Date dueDate = DfTime.DF_NULLDATE.getDate();
			if (dueDateDfTime != null)
			{
				dueDate = dueDateDfTime.getDate();
			}
			this.m_rowMap.put("due_date", dueDate);
	
			IDfTime completeDfTime = getTaskEndData(taskReport);
			Date completeDate = DfTime.DF_NULLDATE.getDate();
			if (completeDfTime != null)
			{
				completeDate = completeDfTime.getDate();
			}
			this.m_rowMap.put("complete_date", completeDate);
	
			if (this.m_showAttachments)
				this.m_rowMap.put("attachments", getTaskAttachments(taskReport));
			else
				this.m_rowMap.put("attachments", "");
			this.m_rowMap.put("overdue", getTaskOverdueTime(taskReport));
			this.m_rowMap.put("status_flag", String.valueOf(taskReport.getRuntimeState()));
			this.m_rowMap.put("status_tooltip", getTaskStatusTooltip(taskReport));
			this.m_rowMap.put("workitem_id", taskReport.getWorkitemObjectId());
			this.m_rowMap.put("activity_id", taskReport.getActivityObjectId().getId());
	
			IDfId queueItemObjectId = taskReport.getQueueItemObjectId();
	
			if (queueItemObjectId != null) {
				this.m_rowMap.put("queueitem_id", taskReport.getQueueItemObjectId());
			}
			else
				this.m_rowMap.put("queueitem_id", "0000000000000000");
		}else{
			DfLogger.info(this, " :: populateRow : TaskName : "+getTaskName(taskReport) +" : strTaskPerformer="+strTaskPerformer +" Delay Activity - Donot Add",null,null);
		}
	}

}
