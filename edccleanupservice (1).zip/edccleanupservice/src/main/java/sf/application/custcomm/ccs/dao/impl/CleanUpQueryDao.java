/***************************************************************************
 * State Farm
 * Version Template: 2012
 *
 * File Name: ExportProcessQueryDaoImpl.java
 *
 * Version     ChgDate          Author           Comments
 * ________   __________       ________         ___________
 * 1.0        05/31/2013                  		Initial Creation 
 *
 ***************************************************************************/
package sf.application.custcomm.ccs.dao.impl;

import java.util.ArrayList;
import java.util.List;

import sf.application.custcomm.ccs.constants.ExceptionConstants;
import sf.application.custcomm.ccs.constants.QueryConstants;
import sf.application.custcomm.ccs.dao.ICleanUpQueryDao;
import sf.application.custcomm.ccs.exceptions.QueryException;
import sf.application.custcomm.ccs.util.CommonUtils;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfAttr;
import com.emciig.utils.QueryUtils;

/**
 * <i>ExportProcessQueryDaoImpl</i> contains the methods that interacts with
 * database.
 * 
 */
public class CleanUpQueryDao implements ICleanUpQueryDao {

	

	

	/**
	 * It retrieves the count of the objects by executing a query.
	 * 
	 * @param queryString
	 *            Query to be executed
	 * @param values
	 *            values that needs to be replaced in query
	 * @param session
	 *            Documentum session
	 * @return Integer output attribute value
	 * 
	 * @throws QueryException
	 *             Custom Exception used within the export services module
	 */
	public int getQueryCount(String queryString, Object[] values, IDfSession session) throws QueryException {

		if(DfLogger.isTraceEnabled(this)) {
			DfLogger.trace(this, "Method getQueryCount() entry", null, null);
		}
		try {
			if(DfLogger.isTraceEnabled(this)) {
				DfLogger.trace(this, "Method getQueryCount() exit", null, null);
			}
			return QueryUtils.getQueryCount(QueryUtils.getDqlStatement(queryString, values), session);
		} catch(DfException dfException) {
			throw new QueryException(CommonUtils.frameMessage(ExceptionConstants.ERROR_IN_RETRIEVING_QUERY_COUNT,
					queryString), dfException);
		}

	}

	

		
	
	
	


	/**
	 * It returns the query results in a form of list of workitem object id's.
	 * 
	 * @param session
	 *            Documentum session
	 * @param queryString
	 *            Query to be executed
	 * 
	 * @return List of object id's
	 * @throws QueryException
	 *             Custom Exception used within the workflow timer services
	 *             module
	 */

	public List<String> getMarkedAsPurgeFolderIds(IDfSession session,
			String queryString,Object[] values) throws QueryException {
		
		
		IDfCollection collections = null;
		List<String> resultsList = null;
		try {

			collections = QueryUtils.query(queryString,
					values,
					session);

			resultsList = new ArrayList<String>();

			while (collections.next()) {
				
				try{
				
				IDfFolder objFolder=(IDfFolder)session.getObject(collections.getId("folderid"));
				objFolder.setSubject("Marked as Purge");
				objFolder.save();
				resultsList.add(collections
						.getString("folderid"));
				
				
				
				}catch(Exception e){
					
					  DfLogger.error(this,
			   					ExceptionConstants.ERROR_IN_RETRIEVING_OBJECTS, null,
			   					e);
				}
			}

		} catch (DfException dfException) {
			
			
			throw new QueryException(
					ExceptionConstants.ERROR_IN_RETRIEVING_OBJECTS,
					dfException);

		} finally {
			QueryUtils.closeCollection(collections);
		}

		return resultsList;
	}








	public List<String> getFolderContents(IDfSession session,
			String queryString, Object[] values) throws QueryException {
		
		IDfCollection collections = null;
		List<String> resultsList = null;
		try {

			collections = QueryUtils.query(queryString,
					values,
					session);

			resultsList = new ArrayList<String>();

			while (collections.next()) {
				
				try{
				
				
				resultsList.add(collections
						.getString("r_object_id"));
				
				
				
				}catch(Exception e){
					
					  DfLogger.error(this,
			   					ExceptionConstants.ERROR_IN_RETRIEVING_OBJECTS, null,
			   					e);
				}
			}

		} catch (DfException dfException) {
			
			
			throw new QueryException(
					ExceptionConstants.ERROR_IN_RETRIEVING_OBJECTS,
					dfException);

		} finally {
			QueryUtils.closeCollection(collections);
		}

		return resultsList;
		
		
		
	}








	public String executeContentDestroy(IDfSession session,
			String queryString, Object[] values) throws QueryException {
	
		
		IDfCollection collections = null;
		String result=null;
		
		try {

			

			collections=QueryUtils.query(QueryUtils.getDqlStatement(queryString, values),IDfQuery.DF_EXEC_QUERY, session);

			while (collections.next()) {
				
				try{
				
				
			result=collections.getString("result");
				
				
				}catch(Exception e){
					
					  DfLogger.error(this,
			   					ExceptionConstants.ERROR_IN_RETRIEVING_OBJECTS, null,
			   					e);
				}
			}

		} catch (DfException dfException) {
			
			System.out.println(dfException.getMessage());
			/*throw new QueryException(
					ExceptionConstants.ERROR_IN_RETRIEVING_OBJECTS,
					dfException);*/

		} finally {
			QueryUtils.closeCollection(collections);
		}

		
		
		return result;
	}








	public List<String> getDmrContentIds(IDfSession session, String queryString,
			Object[] values) throws QueryException {
		IDfCollection collections = null;
		List<String> resultsList = null;
		try {

			collections = QueryUtils.query(queryString,
					values,
					session);

			resultsList = new ArrayList<String>();

			while (collections.next()) {
				
				try{
					
					
				String objectId=collections.getString("r_object_id");
				
			
				
				resultsList.add(objectId);
				
				
				
				}catch(Exception e){
					
					  DfLogger.error(this,
			   					ExceptionConstants.ERROR_IN_RETRIEVING_OBJECTS, null,
			   					e);
				}
			}

		} catch (DfException dfException) {
			
			
			throw new QueryException(
					ExceptionConstants.ERROR_IN_RETRIEVING_OBJECTS,
					dfException);

		} finally {
			QueryUtils.closeCollection(collections);
		}

		return resultsList;
	}
	
	
	public  int getParentCount(IDfSession session,
			String queryString, Object[] values) throws QueryException {
	
		
		IDfCollection collections = null;
		int result = 1;
		
		try {

			collections=QueryUtils.query(QueryUtils.getDqlStatement(queryString, values),IDfQuery.DF_READ_QUERY, session);

			if (collections.next()) {
				
				try{
				
				
					   IDfAttr attr = collections.getAttr(0);
				       result = collections.getInt(attr.getName());
				
				
				}catch(Exception e){
					
					  DfLogger.error(this,
			   					ExceptionConstants.ERROR_IN_RETRIEVING_OBJECTS, null,
			   					e);
				}
			}

		} catch (DfException dfException) {
			
			System.out.println(dfException.getMessage());
			throw new QueryException(
					ExceptionConstants.ERROR_IN_RETRIEVING_OBJECTS,
					dfException);

		} finally {
			QueryUtils.closeCollection(collections);
		}

		
		
		return result;
	}









	public List<String> getFilesFromRepo(IDfSession session,
			String queryString, Object[] values) throws QueryException {
		
		
		
		IDfCollection collections = null;
		List<String> resultsList = null;
		try {
			System.out.println(QueryUtils.getDqlStatement(queryString,values));
			collections = QueryUtils.query(queryString,
					values,
					session);

			resultsList = new ArrayList<String>();

			while (collections.next()) {
				
				try{
				
				
				resultsList.add(collections
						.getString("r_object_id"));
				
				
				
				}catch(Exception e){
					
					  DfLogger.error(this,
			   					ExceptionConstants.ERROR_IN_RETRIEVING_OBJECTS, null,
			   					e);
				}
			}

		} catch (DfException dfException) {
			
			
			throw new QueryException(
					ExceptionConstants.ERROR_IN_RETRIEVING_OBJECTS,
					dfException);

		} finally {
			QueryUtils.closeCollection(collections);
		}

		return resultsList;
		
	}
	
	/**
	 * It retrieve a specific attribute value from the query string.
	 * 
	 * @param queryString
	 *            Query to be executed
	 * @param attributeName
	 *            Name of the attribute whose value should be fetched
	 * @param queryType
	 *            Determines the query execution type(read/cache/apply etc.)
	 * @param session
	 *            Documentum session
	 * @return String output attribute value
	 * 
	 * @throws QueryException
	 *             Custom Exception used within the export services module
	 */
	public String getQueryStringValue(String queryString, String attributeName, int queryType, IDfSession session)
			throws QueryException {

		if(DfLogger.isTraceEnabled(this)) {
			DfLogger.trace(this, "Method getQueryStringValue() entry", null, null);
		}

		IDfCollection collections = null;
		try {
			collections = QueryUtils.query(queryString, queryType, session);

			if(!CommonUtils.isNull(collections) && collections.next()) {
				if(DfLogger.isTraceEnabled(this)) {
					DfLogger.trace(this, "Method getQueryStringValue() exit", null, null);
				}
				return collections.getString(attributeName);
			} else {
				throw new QueryException(CommonUtils.frameMessage(ExceptionConstants.ERROR_IN_RETRIEVING_OBJECTS,
						CommonUtils.frameMessage(queryString, attributeName)));
			}

		} catch(DfException dfException) {
			throw new QueryException(CommonUtils.frameMessage(ExceptionConstants.ERROR_IN_RETRIEVING_OBJECTS,
					CommonUtils.frameMessage(queryString, attributeName)), dfException);
		} finally {
			QueryUtils.closeCollection(collections);
		}

	}
	
	
	
	public String  queryExecute(String dql, Object[] values,  IDfSession session)
			throws QueryException{
			IDfCollection collections = null;
			String result=null;
		 try{
		    collections=QueryUtils.query(QueryUtils.getDqlStatement(dql, values),IDfQuery.DF_EXEC_QUERY, session);

			if (collections.next()) {
				
				try{
				
				
					   IDfAttr attr = collections.getAttr(0);
				       result = collections.getString(attr.getName());
				
				
				}catch(Exception e){
					
					  DfLogger.error(this,
			   					ExceptionConstants.ERROR_IN_RETRIEVING_OBJECTS, null,
			   					e);
				}
			}
		 }catch(Exception e){
				
			  DfLogger.error(this,
	   					ExceptionConstants.ERROR_IN_RETRIEVING_OBJECTS, null,
	   					e);
		}
			
			return result;
		
	}

	

	
}
