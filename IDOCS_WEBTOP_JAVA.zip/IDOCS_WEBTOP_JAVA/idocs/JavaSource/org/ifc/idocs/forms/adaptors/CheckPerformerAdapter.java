package org.ifc.idocs.forms.adaptors;

import com.documentum.fc.common.DfLogger;
import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.xforms.engine.adaptor.validator.IStringValidator;
import com.documentum.xforms.engine.adaptor.validator.ItemValidator;


public class CheckPerformerAdapter extends ItemValidator implements IStringValidator{

	public void destroy() throws AdaptorException {
		DfLogger.info(this, " : Inside the destroy method...", null, null);
	}

	public void init(IAdaptorConfiguration arg0) throws AdaptorException {		
		DfLogger.info(this, " : Inside the init method...", null, null);
	}

	public boolean validateString(String arg0) throws AdaptorException {
		
		
		boolean flag = false;
		
		if(null != arg0 && !"".equals(arg0)){
			flag = true;
		}
		
		return flag;
	}


}
