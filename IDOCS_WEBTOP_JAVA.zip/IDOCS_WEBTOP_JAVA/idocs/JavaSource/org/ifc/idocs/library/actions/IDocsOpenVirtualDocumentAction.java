package org.ifc.idocs.library.actions;

import com.documentum.web.formext.action.ActionService;
import com.documentum.web.formext.action.IActionCompleteListener;
import com.documentum.webcomponent.library.actions.OpenVirtualDocumentAction;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.*;
import com.documentum.web.formext.docbase.ObjectCacheUtil;
import java.util.Map;

public class IDocsOpenVirtualDocumentAction extends OpenVirtualDocumentAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 599346439184079574L;
	
    public boolean execute(String strAction, IConfigElement config, ArgumentList args, Context context, Component component, Map completionArgs)
    {
    	DfLogger.info(this, " :: execute :: start", null, null);
        String actionToInvoke = null;
        String preference = null;
        String strObjectId = args.get(STR_OBJECT_ID);
        if(strObjectId !=null)
          DfLogger.debug(this, " :: execute :: objectId"+strObjectId, null, null);
        else
          DfLogger.debug(this, " :: execute :: null objectId", null, null);
        
        long contentSize = 0L;
        try
        {
            IDfSysObject obj = (IDfSysObject)ObjectCacheUtil.getObject(component.getDfSession(), strObjectId);
            contentSize = obj.getContentSize();
            DfLogger.debug(this,"execute:: contentSize"+contentSize, null,null);
        }catch(DfException e) { 
        	DfLogger.error(this, e.getMessage(), null,null);
        }
        
        if(contentSize == 0L)
        {
            preference = STR_CONTENT;
            DfLogger.debug(this,"execute:: contentSize is Zero  setting default VD double click as content instead of VDM", null,null);
        } else
        {
            IPreferenceStore preferenceStore = PreferenceService.getPreferenceStore();
            preference = preferenceStore.readString(STR_VDM_CLICK_ACTION);
            if(preference == null)
                preference = STR_CONTENT;
            
        }
        if(preference != null && preference.length() >0 ){
        	actionToInvoke = STR_VIEW_CONTENT;
        	DfLogger.info(this, " :: execute :: preference", null, null);
        }else{
        	if(preference.equals(STR_CONTENT))
        		actionToInvoke = STR_VIEW_CONTENT;
        	else
        		actionToInvoke = STR_VIEW_CONTENT;
        	DfLogger.debug(this, " :: execute :: preference"+preference, null, null);
        	DfLogger.debug(this, " :: execute :: actionToInvoke"+actionToInvoke, null, null);
        }
        IActionCompleteListener actionCompleteListener = (IActionCompleteListener)completionArgs.get(STR_DMF_COMPLETE_LISTENER);
        return ActionService.execute(actionToInvoke, args, context, component, actionCompleteListener);
    }

    public String[] getRequiredParams()
    {
        return (new String[] {
        		STR_OBJECT_ID
        });
    }

    protected String getDefaultStructureComponent()
    {
        return STR_DEFAULT_VDM_STRUCTURE_COMPONENT;
    }
    
    public static String STR_CONTENT="Content";
    public static String STR_STRTUCTURE="Structure";
    public static String STR_VDM_CLICK_ACTION="vdm.click.action";
    public static String STR_VIEW_CONTENT="view";
    public static String STR_VDM_CLICK_ACTION_PROMPT="vdmclickactionprompt"; 
    private static String STR_DEFAULT_VDM_STRUCTURE_COMPONENT = "vdmliststreamline";
    //private static String STR_STRUCTURE_COMPONENT_ARGUMENT = "structureComponent";
    public static String STR_DMF_COMPLETE_LISTENER="___dmfCompleteListener";
    public static String STR_OBJECT_ID="objectId"; 

}
