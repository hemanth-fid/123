/**
 * IDocsReleasedStateAttributeValueTag - Tag class to change the behavior
 *  of attributes in idocs application UI in the Released State.
 *  
 * @author SKurian1
 * 
 * #####################################################################
 * Author		DateofChange	Version		ModificationHistory
 * #####################################################################
 * 
 * #####################################################################
 */
package org.ifc.idocs.control.docbase;

import java.io.IOException;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.formext.control.docbase.DocbaseAttributeValue;
import com.documentum.web.formext.control.docbase.DocbaseObject;

/**
 * This class is to control the behavior of the security_classification
 * attribute in the idocs application.
 * This marks the attribute as read only for the users who does not have the 
 * CHANGE_PERMIT extended permit on the document.
 * @author SKurian1
 *
 */
public class IDocsReleasedStateAttributeValueTag extends
		com.documentum.web.formext.control.docbase.DocbaseAttributeValueTag {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3368052167667006276L;
	private static final String MSG_RELEASED="Released";
	private static final String MSG_SEC_CLASSIFICATION_CODE="sec_classification_code";
	private static final String MSG_IDOCS_COUNTRY_DOC="idocs_country_doc";
	private static final String MSG_IDOCS_INSTITUTION_DOC = "idocs_institution_doc";
	private static final String MSG_IDOCS_PROJECT_DOC = "idocs_project_doc";
	private static final String QRY_GRUOP_FROM = "select i_all_users_names from dm_group where group_name='" ;
	private static final String QRY_SUFF_ALLUSER_NAMES = "' and ANY i_all_users_names='";
	private static final String MSG_OFFICIAL_CODE="O";
	private static final String MSG_CONFIDENTIAL_CODE="C";
	private static final String MSG_STRICTLY_CONFIDENTIAL_CODE="S";

	public IDocsReleasedStateAttributeValueTag() {
		DfLogger.debug(this, " : IDocsReleasedStateAttributeValueTag >> ", null, null);
	}
	
	/**
	 * This method will render the security classification attribute as ReadOnly
	 * if the logged in user don't have ChangePermit permission on the object.
	 */
	protected void renderSingleAttribute(String strFormattedValue,
			String strValue, boolean bReadonly, boolean bHasCompleteList,
			JspWriter out) throws IOException, JspTagException {
		DfLogger.debug(this, " : renderSingleAttribute() : Enter ", null, null);
		if (bReadonly == false ) {
			DfLogger.info(this, " : renderSingleAttribute() : bReadonly @START = " + bReadonly, null, null);
			try {
				IDfSysObject sysObject = null;
				DocbaseAttributeValue value = (DocbaseAttributeValue) getControl();
				DocbaseObject docbaseObject = (DocbaseObject) getForm().getControl(value.getObject());
				IDfPersistentObject persistentObject = docbaseObject.getDfObject();
				if(persistentObject != null && persistentObject instanceof IDfSysObject){
					sysObject = (IDfSysObject) persistentObject;
				}else{
					DfLogger.debug(this, " : renderSingleAttribute() : DocbaseObject Is NULL ", null, null);
				}
				/** Add the Released State Changes if the Attribute 
				 * is still editable and the Document is in Released state **/
				if( bReadonly == false && sysObject!=null 
						&& sysObject.getObjectSession().getLoginUserName().equals(sysObject.getOwnerName()) == false 
						&& MSG_RELEASED.equals(sysObject.getString(IDocsConstants.MSG_DOC_STATE))){
					DfLogger.debug(this,"Document is " + MSG_RELEASED, null, null);
					DfLogger.debug(this,"Check whether to Disable the Attribute ", null, null);
					bReadonly = canEditableInReleasedState(sysObject,bReadonly);
				}else{
					DfLogger.debug(this,"Attribute is Read Only or not " + MSG_RELEASED 
							+ " or Current user is the Owner", null, null);
				}
			} catch (DfException e) {
				DfLogger.error(this, "Exception :" + e.getLocalizedMessage(),null, null);
				e.printStackTrace();
			}
		}
		DfLogger.info(this, " : renderSingleAttribute() : bReadonly @END = " + bReadonly, null, null);
		super.renderSingleAttribute(strFormattedValue, strValue,bReadonly, bHasCompleteList, out);
		DfLogger.debug(this, " : renderSingleAttribute() : Leave ", null, null);
	}

	/**
	 * This method is used to decide whether the attribute can be editable in the UI
	 * for the documents which are in released state
	 * @param currentSysObject    -  currentSysObject
	 * @param currentReadonlyFlag - currentValue of ReadOnly Flag
	 * @return
	 */
	private boolean canEditableInReleasedState(IDfSysObject currentSysObject,boolean currentReadonlyFlag) {
		DfLogger.debug(this, "canEditableInReleasedState Enter ", null, null);
		boolean canEditableFlag = false;
		try {
			String currentSecurityClassificationCode = currentSysObject.getString(MSG_SEC_CLASSIFICATION_CODE);
			if(MSG_OFFICIAL_CODE.equals(currentSecurityClassificationCode)){
				/** Official Use Only */
				if(MSG_IDOCS_PROJECT_DOC.equals(currentSysObject.getTypeName())){
					/** Project Document READ ONLY to idocs_pr_<%projid%>_ed_off_grp */					
					canEditableFlag = isUserMemberOfGroup(currentSysObject,"idocs_pr_#_ed_off_grp",MSG_IDOCS_PROJECT_DOC);
				}else if(MSG_IDOCS_INSTITUTION_DOC.equals(currentSysObject.getTypeName())){							
				/**  Institution Document	READ ONLY to idocs_inst_<%inst nbr%>_ed_off_grp */
					canEditableFlag = isUserMemberOfGroup(currentSysObject,"idocs_inst_#_ed_off_grp",MSG_IDOCS_INSTITUTION_DOC);
				} else if(MSG_IDOCS_COUNTRY_DOC.equals(currentSysObject.getTypeName())){	
				/** Country Document NO UPDATE */
					DfLogger.debug(this, "canEditableInReleasedState() : Skip Country Document ", null, null);
//					canEditableFlag = isUserMemberOfGroup(currentSysObject,"idocs_inst_#_ed_off_grp",MSG_IDOCS_COUNTRY_DOC);
				}else{
				/** Unknown Type */
					DfLogger.debug(this, "canEditableInReleasedState Leave : " +
							"Unknown Object Type = " + currentSysObject.getTypeName() , null, null);
					return currentReadonlyFlag ;
				}
			}else if(MSG_CONFIDENTIAL_CODE.equals(currentSecurityClassificationCode)){
				/** Confidential  */
				if(MSG_IDOCS_PROJECT_DOC.equals(currentSysObject.getTypeName())){
				/** Project Document READ ONLY to idocs_pr_<%projid%>_ed_con_grp */
					canEditableFlag = isUserMemberOfGroup(currentSysObject,"idocs_pr_#_ed_con_grp",MSG_IDOCS_PROJECT_DOC);
				}else if(MSG_IDOCS_INSTITUTION_DOC.equals(currentSysObject.getTypeName())){
				/**	Institution Document READ ONLY to idocs_inst_<%inst nbr%>_ed_con_grp */
					canEditableFlag = isUserMemberOfGroup(currentSysObject,"idocs_inst_#_ed_con_grp",MSG_IDOCS_INSTITUTION_DOC);
				}else if(MSG_IDOCS_COUNTRY_DOC.equals(currentSysObject.getTypeName())){
				/** Country Document NO UPDATE */
					DfLogger.debug(this, "canEditableInReleasedState() : Skip Country Document ", null, null);
				}else{
				/** Unknown Type */
					DfLogger.debug(this, "canEditableInReleasedState Leave : " +
							"Unknown Object Type = " + currentSysObject.getTypeName() , null, null);
					return currentReadonlyFlag ;
				}
			}else if(MSG_STRICTLY_CONFIDENTIAL_CODE.equals(currentSecurityClassificationCode)){
				/** Strictly Confidential  */
				if(MSG_IDOCS_PROJECT_DOC.equals(currentSysObject.getTypeName())){
				/** READ ONLY to "idocs_pr_<%projid%>_tl_grp : idocs_pr_<%projid%>_po_grp" */
					if(isUserMemberOfGroup(currentSysObject,"idocs_pr_#_tl_grp",MSG_IDOCS_PROJECT_DOC) &&
							isUserMemberOfGroup(currentSysObject,"idocs_pr_#_po_grp",MSG_IDOCS_PROJECT_DOC)){
						return true;
					}
				}else if(MSG_IDOCS_INSTITUTION_DOC.equals(currentSysObject.getTypeName())){	
				/** Institution Document READ ONLY to "idocs_inst_<%inst nbr%>_tl_grp : idocs_inst_<%inst nbr%>_po_grp" */
					if(isUserMemberOfGroup(currentSysObject,"idocs_inst_#_tl_grp",MSG_IDOCS_INSTITUTION_DOC) &&
							isUserMemberOfGroup(currentSysObject,"idocs_inst_#_po_grp",MSG_IDOCS_INSTITUTION_DOC)){
						return true;
					}
				} else if(MSG_IDOCS_COUNTRY_DOC.equals(currentSysObject.getTypeName())){
				/** Country Document NO UPDATE */
					DfLogger.debug(this, "canEditableInReleasedState() : Skip Country Document ", null, null);
				}else{
				/** Unknown Type */
					DfLogger.debug(this, "canEditableInReleasedState Leave : " +
							"Unknown Object Type = " + currentSysObject.getTypeName() , null, null);
					return currentReadonlyFlag ;
				}
			}else{
				DfLogger.debug(this, "canEditableInReleasedState Leave : " +
						"Unknown Security Classification Code = " + currentSecurityClassificationCode , null, null);
				return currentReadonlyFlag ;
			}
		} catch (DfException e) {
			DfLogger.debug(this, "canEditableInReleasedState Leave : Exception = " + e.getMessage() , null, null);
			e.printStackTrace();
		}
		DfLogger.debug(this, "canEditableInReleasedState Leave : canEditableFlag = " + canEditableFlag , null, null);
		return canEditableFlag;
	}

	/**
	 * This method checks whether the logged in user is part of the given project group
	 * or not.
	 * @param currentSysObject - current Object
	 * @param strGroupTemplateName - templateName of the group
	 * @param objectType - Type Name of the Current Object
	 * @return
	 */
	private boolean isUserMemberOfGroup(IDfSysObject currentSysObject,
			String strGroupTemplateName,String objectType) {
		IDfCollection userNamesCollection = null;
		try {
			String loginUserName = currentSysObject.getObjectSession().getLoginUserName();
			String finalGroupName = null;
			if(MSG_IDOCS_PROJECT_DOC.equals(objectType)){
				finalGroupName = getProjectGroupName(currentSysObject,strGroupTemplateName);
			}else if(MSG_IDOCS_INSTITUTION_DOC.equals(objectType)){
				finalGroupName = getInstitutionGroupName(currentSysObject,strGroupTemplateName);
			}else if(MSG_IDOCS_COUNTRY_DOC.equals(objectType)){
				finalGroupName = getCountryGroupName(currentSysObject,strGroupTemplateName);
			}
			if(finalGroupName!=null && finalGroupName.trim().length() > 0){
				IDfQuery dfQuery = new DfQuery();
				String strQuery = new StringBuilder().append(QRY_GRUOP_FROM)
				.append(finalGroupName).append(QRY_SUFF_ALLUSER_NAMES)
				.append(IdocsUtil.handleSingleQuote(loginUserName)).append("'")// Handled single quote in username
				.toString();
				dfQuery.setDQL(strQuery);
				DfLogger.info(this, " : isUserMemberOfGroup() : strQuery = "+strQuery , null, null);
				userNamesCollection = dfQuery.execute(currentSysObject.getObjectSession(), IDfQuery.DF_READ_QUERY);
				while(userNamesCollection.next()){
					String userName = userNamesCollection.getString("i_all_users_names");
					if(userName!=null && userName.trim().length()>0){
						DfLogger.info(this, " : isUserMemberOfGroup() :" 
								+loginUserName +" IS A MEMBER of "+finalGroupName, null, null);
						return true;
					}
				}
				DfLogger.info(this, " : isUserMemberOfGroup() :" 
						+ loginUserName + " IS NOT A MEMBER of "+finalGroupName, null, null);
			}else{
				DfLogger.info(this, " : isUserMemberOfGroup() : Invalid Group Name", null, null);
			}
		} catch (DfException e) {
			e.printStackTrace();
			DfLogger.info(this, " : isUserMemberOfGroup() : Exception " + e.getMessage(), null, null);
		}finally{
			if(userNamesCollection!=null){
				try {userNamesCollection.close();}
				catch (DfException e) {e.printStackTrace();
				DfLogger.info(this, " : isUserMemberOfGroup() : Finally : Exception : " + e.getMessage(), null, null);}
			}
		}
		return false;
	}

	/**
	 * This method is to frame the groupName for Project Documents from the 
	 * given Group template name
	 * @param currentSysObject
	 * @param string
	 */
	private String getProjectGroupName(IDfSysObject currentSysObject,
			String strGroupTemplateName) {
		String groupName = null;
		try{
			String projectId = currentSysObject.getString("project_id");
			groupName = strGroupTemplateName.replace("#", projectId);
		}catch (Exception e) {
			e.printStackTrace();
			DfLogger.info(this, " : getProjectGroupName() : Exception in generating the groupName", null, null);
		}
		DfLogger.info(this, " : getProjectGroupName() : groupName ="+groupName, null, null);
		return groupName;
	}
	
	/**
	 * This method is to frame the groupName for Institution Documents from the 
	 * given Group template name
	 * @param currentSysObject
	 * @param string
	 */
	private String getInstitutionGroupName(IDfSysObject currentSysObject,
			String strGroupTemplateName) {
		String groupName = null;
		try{
			String institutionNumber = currentSysObject.getString("institution_nbr");
			groupName = strGroupTemplateName.replace("#", institutionNumber);
		}catch (Exception e) {
			e.printStackTrace();
			DfLogger.info(this, " : getInstitutionGroupName() : Exception in generating the groupName", null, null);
		}
		DfLogger.info(this, " : getInstitutionGroupName() : groupName ="+groupName, null, null);
		return groupName;
	}
	
	/**
	 * This method is to frame the groupName for Country Documents from the 
	 * given Group template name
	 * @param currentSysObject
	 * @param string
	 */
	private String getCountryGroupName(IDfSysObject currentSysObject,
			String strGroupTemplateName) {
		String groupName = null;
		try{
			String countryCode = currentSysObject.getString("country_code");
			groupName = strGroupTemplateName.replace("#", countryCode);
		}catch (Exception e) {
			e.printStackTrace();
			DfLogger.info(this, " : getCountryGroupName() : Exception in generating the groupName", null, null);
		}
		DfLogger.info(this, " : getCountryGroupName() : groupName ="+groupName, null, null);
		return groupName;
	}
}
