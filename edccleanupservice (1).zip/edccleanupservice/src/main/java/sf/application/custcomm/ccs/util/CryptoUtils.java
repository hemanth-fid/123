/***************************************************************************
 * State Farm
 * Version Template: 2012
 *
 * File Name: CryptoUtils.java
 *
 * Version     ChgDate          Author           Comments
 * ________   __________       ________         ___________
 * 1.0        03/19/2013         t1or         Initial Creation 
 *
 ***************************************************************************/
package sf.application.custcomm.ccs.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;

import org.apache.commons.codec.binary.Base64;

import sf.application.custcomm.ccs.constants.CleanUpConstants;
import sf.application.custcomm.ccs.exceptions.CleanUpServiceException;

import com.documentum.fc.common.DfLogger;

/**
 * <i> CryptoUtils </i> is a utility class contains the static methods which are
 * used to decrypt the password.
 * 
 */
public final class CryptoUtils {

	private Cipher dcipher;

	private static CryptoUtils cryptoUtils;

	/**
	 * It returns a CryptoUtils instance.
	 * 
	 * @param serviceKey
	 *            Service key as a parameter
	 * @return CryptoUtils instance
	 * @throws ExportProcessException
	 *             Custom Exception used within the export services module
	 */
	public static CryptoUtils getInstance(String serviceKey) throws CleanUpServiceException {// Singleton
		if(cryptoUtils == null) {
			cryptoUtils = new CryptoUtils(serviceKey);
		}
		return cryptoUtils;
	}

	/**
	 * Constructor
	 * 
	 * @param serviceKey
	 *            Service key as a parameter
	 * @throws ExportProcessException
	 *             Custom Exception used within the export services module
	 */
	private CryptoUtils(String serviceKey) throws CleanUpServiceException {

		if(DfLogger.isTraceEnabled(this)) {
			DfLogger.trace(this, "Method CryptoUtils() entry", null, null);
		}
		try {

			DESedeKeySpec keySpec = new DESedeKeySpec(new Base64().decode(serviceKey
					.getBytes(CleanUpConstants.FORMAT_UTF8)));
			SecretKey secretKey = SecretKeyFactory.getInstance(CleanUpConstants.CRYPTO_ALGORITHM_NAME)
					.generateSecret(keySpec);
			IvParameterSpec ivSpec = new IvParameterSpec(new byte[CleanUpConstants.NUMBER_OF_BITS]);
			dcipher = Cipher.getInstance(CleanUpConstants.CRYPTO_ALGORITM_TRANSFORMAION);
			dcipher.init(Cipher.DECRYPT_MODE, secretKey, ivSpec);

		} catch(GeneralSecurityException generalSecurityException) {
			throw new CleanUpServiceException(generalSecurityException.getMessage(), generalSecurityException);
		} catch(UnsupportedEncodingException unsupportedEncodingException) {
			throw new CleanUpServiceException(unsupportedEncodingException.getMessage(), unsupportedEncodingException);
		}
		if(DfLogger.isTraceEnabled(this)) {
			DfLogger.trace(this, "Method CryptoUtils() exit", null, null);
		}
	}

	/**
	 * It decrypts the password.
	 * 
	 * @param encryptedPassword
	 * @return decrypted password
	 * @throws ExportProcessException
	 *             Custom Exception used within the export services module
	 */
	public String decrypt(String encryptedPassword) throws CleanUpServiceException {
		if(DfLogger.isTraceEnabled(this)) {
			DfLogger.trace(this, "Method decrypt() entry", null, null);
		}
		try {
			byte[] dec = new sun.misc.BASE64Decoder().decodeBuffer(encryptedPassword);

			byte[] utf8 = dcipher.doFinal(dec);

			if(DfLogger.isTraceEnabled(this)) {
				DfLogger.trace(this, "Method decrypt() exit", null, null);
			}
			return new String(utf8, CleanUpConstants.FORMAT_UTF8);
		} catch(GeneralSecurityException generalSecurityException) {
			throw new CleanUpServiceException(generalSecurityException.getMessage(), generalSecurityException);
		} catch(IOException ioException) {
			throw new CleanUpServiceException(ioException.getMessage(), ioException);
		}
	}

}