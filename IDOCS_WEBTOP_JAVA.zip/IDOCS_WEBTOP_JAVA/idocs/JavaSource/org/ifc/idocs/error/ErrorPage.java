/**
* * This class is for calling the exception when trying to previous state of the activity.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Parag Doshi		    01/02/2011	     1.0          Created
* #######################################################################################################
*/
package org.ifc.idocs.error;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.component.Component;
import com.documentum.web.form.*;
import com.documentum.web.form.control.Label;

public class ErrorPage extends Component{
	
	public static final String ERROR_CONTROL_CODE = "code";
	public static final String ERROR_CONTROL_DESCRIPTION = "description";
	/**
	 * Component Initialization : sets the errorcode,errodescription labels with values.
	 * @argumentList ArgumenList containing key-value pairs
	 */
	public void onInit(ArgumentList argumentList) {
		try
		{
			DfLogger.info(this," :: onInit "+getDfSession().getLoginUserName(),null,null);
			((Label) getControl(ERROR_CONTROL_CODE, Label.class)).setLabel(
				"Error Code : " + argumentList.get("code"));
			((Label) getControl(ERROR_CONTROL_DESCRIPTION, Label.class)).setLabel(
				"Error Message :" + argumentList.get("description"));
			DfLogger.info(this," :: onInit Ends",null,null);
		}
		catch(DfException e)
		{
			DfLogger.error(this, " :: onInit Exception >> "+e.getMessage(), null, null);
		}
	}
	
	/**
	 * When user clicks on Back button of error page this method will be called
	 * @param control  Control on which the event has been generated.
     * @param argumentList Arguments if any passed with this event 
	 */
	public final void onBack(Control control, ArgumentList argumentlist) {
		try{
			DfLogger.info(this," :: onBack "+getDfSession().getLoginUserName(),null,null);
			setComponentReturn();
		}catch(DfException e){
			DfLogger.error(this, " :: onInit Exception >> "+e.getMessage(), null, null);
		}
	}
}
