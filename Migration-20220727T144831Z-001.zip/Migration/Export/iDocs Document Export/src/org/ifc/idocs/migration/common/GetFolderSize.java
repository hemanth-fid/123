package org.ifc.idocs.migration.common;

import java.io.File;
import java.text.DecimalFormat;

public class GetFolderSize {
	
	public static void main(String args[]){
		String folder = "C:\\Users\\VVellakkattumana\\workspace";
		getFolderSize(folder);
	}

	public static String getFolderSize(String folder){  
		String totalSize = "0#0";
		try{
			DecimalFormat fmt = new DecimalFormat("#.######");
			GetFolderSize size = new GetFolderSize();
			double fileSizeByte = size.getFileSize(new File(folder));
//			System.out.println("Folder Size : "+fmt.format(fileSizeByte)+" Bytes" );
//			System.out.println("Folder Size : "+fmt.format(fileSizeByte/1024)+" KB" );
//			System.out.println("Folder Size : " +fmt.format(fileSizeByte/1048576)+ " MB" );
//			System.out.println("Folder Size : " +fmt.format(fileSizeByte/1073741824)+ " GB" );
			totalSize = fmt.format(fileSizeByte/1048576) + "#" + fmt.format(fileSizeByte/1073741824);
			System.out.println(totalSize);
			
		}catch (Exception e){}
		
		return totalSize;
	}
	public double getFileSize(File folder) {
		double foldersize = 0.0;

		File[] filelist = folder.listFiles();
		for (int i = 0; i < filelist.length; i++) {
			if (filelist[i].isDirectory()) {
				foldersize += getFileSize(filelist[i]);
			} else {
				foldersize += filelist[i].length();
			}
		}
		return foldersize;
	}
}
