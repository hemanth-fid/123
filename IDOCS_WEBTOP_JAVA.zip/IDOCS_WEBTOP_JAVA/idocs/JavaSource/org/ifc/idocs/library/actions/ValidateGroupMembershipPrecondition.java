/**
* This precondition class is validate the group membership.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/28/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.library.actions;

import java.util.HashMap;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.LocaleService;
import com.documentum.web.formext.action.IActionPrecondition;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

public class ValidateGroupMembershipPrecondition implements IActionPrecondition
{
 	private static String m_NewDocContainerNlsProp;
    private static NlsResourceBundle m_nlsResourceBundle;

    public ValidateGroupMembershipPrecondition()
    {
    }

    public String[] getRequiredParams()
    {
        return (new String[] {
            "objectId"
        });
    }

    /**
     * 
     */
    public boolean queryExecute(String strAction, IConfigElement config,
			ArgumentList arg, Context context, Component component) {
        boolean bExecute=false;
        try {
            IDfSession dfSession = component.getDfSession();
            String strObjectId = arg.get("objectId");
            HashMap<String, String> valuesMap=IdocsUtil.getRequiredAttributesValues(strObjectId,dfSession);
            
            String strOwnerName =valuesMap.get(IDocsConstants.MSG_OWNER_NAME);
            String strType = valuesMap.get(IDocsConstants.MSG_DOC_STATE);
    		String strDocState = valuesMap.get(IDocsConstants.MSG_OWNER_NAME);
    		
            if(strObjectId !=  null && strObjectId.trim().length() > 0 && strObjectId.startsWith(IDocsConstants.MSG_DM_DOC_TYPE_PREF_CODE) 
            		&& strDocState.equals(m_nlsResourceBundle.getString("MSG_RELEASED", LocaleService.getLocale()))
            		&& strOwnerName!=null ){
            	bExecute=IDocDocbaseAttributeTagUtility.canEditableInReleasedState(component.getDfSession(), strObjectId, true);
            }else{
    			bExecute=true;
    			DfLogger.debug(this, " :: queryExecute  >> Document NOT in Released OR Current User is the Owner : PreCondition Success ",null,null);
            }
		}catch (Exception e) {
			DfLogger.error(this, " :: queryExecute Exception >> "+e.getMessage(), null, e);
			bExecute=false;
		}
		DfLogger.debug(this, " :: queryExecute  >> Precondition Status : " + bExecute,null,null);
		return bExecute;
	}

	static
    {
        m_NewDocContainerNlsProp = "org.ifc.idocs.action.ValidateGroupMembershipNlsProp";
        m_nlsResourceBundle = new NlsResourceBundle(m_NewDocContainerNlsProp);
    }
}