package org.ifc.idocs.report.transform;

import java.util.Random;

import lotus.domino.Database;
import lotus.domino.DbDirectory;
import lotus.domino.NotesException;

import org.ifc.idocs.report.common.NotesSession;

/**
 * @author SPankajamsadanan
 *
 */
public class TempDb {

	private TempDb(){}
	private static Database tempDb = null;
	

	/**
	 * getInstance method gets the database instance
	 * @return Database object
	 * @throws NotesException
	 */
	public static Database getInstance() throws NotesException {
		if (tempDb == null) {
			DbDirectory dir = NotesSession.getInstance().getDbDirectory(null);
			String dbName = "extraction_temp_db" + (new Random().nextInt()) + ".nsf";
			tempDb = dir.createDatabase(dbName, true);
		}
		return tempDb;
	}

	/**
	 * recycle method recycles the database object
	 * @return void
	 */
	public static void recycle() {
		if (tempDb != null) {
			try {
				System.out.println("Inside TEMPDB.java");
				tempDb.recycle();
			} catch (NotesException e) {
				e.printStackTrace();
			}
			tempDb = null;
		}
	}
}
