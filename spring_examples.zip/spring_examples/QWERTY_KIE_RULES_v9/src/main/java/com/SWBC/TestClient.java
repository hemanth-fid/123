package com.SWBC;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class TestClient {

	public static void main(String[] args) throws ParseException {
		
		
		Date transaction_effective_date = new SimpleDateFormat("ddMMyyyy").parse("12042018");	
		
		Date todayDate = new Date();
		
		System.out.println(addMonthDate(transaction_effective_date, 11));
		
		if(getMonthsBWDate(transaction_effective_date, new Date()) <= 11 || getMonthsBWDate(new Date(),transaction_effective_date) >= 11)
		{
			System.out.println("in between 11 Months");
		}
		

	System.out.println(getMonthsBWDate(transaction_effective_date, new Date()));
	System.out.println(getMonthsBWDate(new Date(),transaction_effective_date));
		
	}
	
	
	

	public static Date addMonthDate(Date myDate, int incrementMonth) {
		Date chDate = myDate;

		SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
		Calendar c = Calendar.getInstance();
		c.setTime(chDate);
		c.add(Calendar.MONTH, incrementMonth);
		return c.getTime();
	}
	
	
	
	public static int getMonthsBWDate(Date biggerDate, Date lesserDate) {

		Calendar cal = Calendar.getInstance();
		Calendar cal2 = Calendar.getInstance();

		cal.setTime(biggerDate);
		cal2.setTime(lesserDate);

		return (cal.get(Calendar.YEAR) - cal2.get(Calendar.YEAR)) * 12 + cal.get(Calendar.MONTH)
				- cal2.get(Calendar.MONTH);

	}
}
//		Date transaction_effective_date = new SimpleDateFormat("ddMMyyyy").parse("28022021");		
//		
//	
//		String tst = "AB+$!@";
//		
//		
//		System.out.println(tst.replaceAll("[-+.^:,%$!@]"," ").trim());
		
//		String str1 = "BIC_2.1";
//		
//		System.out.println(str1.contains("CIB"));
//		
//		
//		Date chDate = new SimpleDateFormat("ddMMyyyy").parse("28022021");
//
//		SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
//		Calendar c = Calendar.getInstance();
//		c.setTime(chDate);
//		c.add(Calendar.DATE, -10);
//		System.out.println(c.getTime());
//		
		
		
		
		
		
//		
//		(TimeUnit.DAYS.convert
//		(transaction_effective_date.getTime() - new Date().getTime(), 
//		TimeUnit.MILLISECONDS) >= 30 
//		|| TimeUnit.DAYS.convert
//		( new Date().getTime() - transaction_effective_date.getTime(), 
//		TimeUnit.MILLISECONDS) >= 30 ),
		
//		
//		List<String> mytyp = new ArrayList<>();
//		mytyp.add("a");
//		mytyp.add("b");
//		mytyp.add("c");
//		mytyp.add("d");
//		mytyp.add("e");
//		
//		int counter = 0;
//		
//		for (int i = 0; i < mytyp.size(); i++) {
//			
//			System.out.println("Value of i : "+i);
//			
//			if(i==4)break;
//			
//			counter++;
//		
//		}
//		
//		System.out.println("Size : "+mytyp.size()+ " And Counter : "+counter);
//		
//	

