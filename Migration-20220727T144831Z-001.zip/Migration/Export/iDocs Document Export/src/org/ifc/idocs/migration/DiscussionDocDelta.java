package org.ifc.idocs.migration;

import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;

import org.ifc.idocs.migration.common.AppConfig;
import org.ifc.idocs.migration.common.DomdocRepository;
import org.ifc.idocs.migration.common.DomdocRepositoryDescriptor;
import org.ifc.idocs.migration.extract.AsposeUtilities;
import org.ifc.idocs.migration.extract.DBConnection;
import org.ifc.idocs.migration.extract.Discussion;
import org.ifc.idocs.migration.extract.DomdocDocument;
import org.ifc.idocs.migration.extract.DomdocFolder;
import org.ifc.idocs.migration.extract.LogHelper;
import org.ifc.idocs.migration.extract.NotesSession;

/**
 * @author SPankajamsadanan
 * @see DiscussionDocDelta - extracts all sort of documents from lotus notes database
 *
 */
public class DiscussionDocDelta extends ExtractCommon{

	protected static String utilityId = "";
	private static DomdocRepository domdoc = null;
	private static DomdocRepositoryDescriptor repo = null;
	private static AppConfig config = AppConfig.getInstance();
	private static Logger exportDocLogger = LogHelper.getLogger(DiscussionDocDelta.class);
	private static Integer notesExcep = 0,wflow_cnt = 0,cout_cnt = 0;
	@SuppressWarnings("unused")
	private static String folderQuery = null,folderQuery1=null,region = null,folder_num=null,cntry = null,Folder_name=null;
	private static Database parentDatabse = null;
	private static String documentQuery = null,documentQuery1=null,disId=null, display_path = null;
	private static String docid=null;
	static String version=null;
	private static int exportCount = 0,failureCount = 0;
	static boolean excludeInWorkflow = true;
	String foldermanPath = null;
	String[] foldermans = null;
	/**
	 * Constructor for ExtractDocuments
	 * @throws Exception 
	 */
	public DiscussionDocDelta(final Set<String> docIdSet) throws Exception {
		migrationSkippedDocumentList.clear();
		File theDir = new File(config.getString("export.path"));
		if (!theDir.exists()){
			NotesSession.terminate();//terminate the extraction
		}
		else{	//if extraction folder is present , then only proceed with extraction
			try{
				String extractionQuery = config.getString("filters.extractioncriteriacode");	//retrieving query string from extraction_criteria table			
				String [] extCriteria = extractionQuery .split(";");
				String server = config.getString("repository.server");

				for(int k = 0; k < extCriteria.length; k++){
					criteriaCount = 0;
					foldermanPath=config.getString("repository.foldermanPath");
					foldermans = foldermanPath .split(";");

					for(int fman = 0; fman < foldermans.length; fman++){
						repo = new DomdocRepositoryDescriptor("","",server,foldermans[fman]);
						domdoc = new DomdocRepository(repo);
						String extractionId = extCriteria[k];
						ResultSet rs1=DBConnection.getDeltaExtractionUtilityID(extractionId);
						exportDocLogger.warning(foldermans[fman]+ " ~ "+extractionId );
						try {
							while (rs1.next()){
								disId=rs1.getString("EXTRACTION_UTILITY_ID");
							}

						} catch (SQLException e) {
							exportDocLogger.warning("Error : " + e);
						}
						rs1.close();
						utilityId=disId;
						if (disId == null){
							exportDocLogger.warning("PLEASE ENSURE THAT REPORT UTILITY & MAIN DELTA EXTRACTION FOR THIS EXTRACTION CRITERIA IS EXECUTED FIRST");
							System.exit(1);
						}
						exportDocLogger.warning("*********Extraction Utility ID is : " + disId);

						String[] extInfo = DBConnection.getExtractionInfo(extractionId);	//getting extraction query-string from database
						if(extInfo != null){
							folderQuery=extInfo[0];
							documentQuery1 = extInfo[1];
							region = extInfo[2];
							cntry = extInfo[3];
						}
						if (cntry.length() > 3){ // extracts the country name (IND / BRA) from folder query value if query contains more inputs (COUNTRY_NAME_CODE='BRA' & project_id = '9999')
							cntry = cntry.substring(0, 3);
						}
						String path = config.getString("export.path") + cntry + "\\";
						if(extractionId.contains("PRJ")){
							path += "Project\\";
						}else if(extractionId.contains("PTR")){
							path += "Partner\\";
						}
						
						path = path + "\\" + utilityId + "\\"; 	//include extraction utility run time ID to the path
						display_path = path;

						for(String docId : docIdSet){
							documentQuery1=docId;
							exportDocLogger.log(Level.WARNING,"discussion modified docId="+docId);
							String[]  splits = folderQuery.split(" & ");
							String countryName = splits[0], projectId = null;
							ArrayList<String>  projectsIds = new ArrayList<String>();
							if(splits.length > 1){
								String[]  splits1 = splits[1].split("'");
								projectId = splits1[0];
								int j = 0;
								for(int i=1; i<splits1.length; i++){
									if(!splits1[i].contains(",")){
										projectsIds.add(splits1[i]);
										j++;
									}
								}
								for(String pid : projectsIds){
									folderQuery1 = countryName + " & " + projectId + "'" + pid + "'";
									//exportDocLogger.info("project specific extraction");
									extractionDocsAndProjects(folderQuery1, path);
								}//end of query split loop
							}else{
								folderQuery1 = countryName;
								extractionDocsAndProjects(folderQuery1, path);
							}
						}
						domdoc.recycle();
					}}
			}catch (RuntimeException ioe){	//loop to finish multiple project id extraction
				exportDocLogger.warning("Please ensure valid inputs are provided in config.xml");
				ioe.printStackTrace();
				exportDocLogger.log(Level.WARNING, "DiscussionDocDelta ~ RuntimeException ~", ioe);
			}
			catch(NotesException e){
				exportDocLogger.warning("NotesError ~ " + e.id + " ~ " + e.text);
				e.printStackTrace();
				exportDocLogger.log(Level.WARNING, "DiscussionDocDelta ~ NotesException ~", e);
			}
			catch (Exception e){
				exportDocLogger.warning("Initialization error");
				e.printStackTrace();
				exportDocLogger.log(Level.WARNING, "DiscussionDocDelta ~ Exception ~", e);
			}
			finally {
				DBConnection.updateExtractionUtilityStart(utilityId);	//updating discussion extraction start status
				Discussion.extractDocuments(region,cntry,display_path,utilityId);	// Extract documents
				DBConnection.updateExtractionUtilityEnd(utilityId);	//	updating discussion extraction end status
//				TODO Aspose fix in delta discussion
				AsposeUtilities au = new AsposeUtilities();
				au.updateCustomProperties(display_path, cntry, utilityId);
				System.out.println("Completed");
				try {
					DBConnection.updateRegionTableExtractionSuccessfulField(utilityId,region, "N");
					DBConnection.updateEndSummary(utilityId,exportCount);
				} catch (IOException e) {
					exportDocLogger.warning("Error while updating extraction end in export_utility_info table");
					e.printStackTrace();
					exportDocLogger.log(Level.WARNING, "In Finally Section ~ IOException ~", e);
				}
			}
		}
	}


	/**
	 * extractionDocsAndProjects method extracts all projects & documents from lotus notes database
	 * @param folderQuery
	 * @param path
	 * @throws Exception
	 * @return void
	 */
	private void extractionDocsAndProjects(String folderQuery, String path) throws Exception {
		exportDocLogger.info("extractionDocsAndProjects folder query = " + folderQuery);
		DocumentCollection folders = domdoc.getFoldermanDb().findFolders(folderQuery);
		exportDocLogger.warning("Count of entries in Folderman Database = " + folders.getCount());
		Document nfolder = folders.getFirstDocument();
		DomdocFolder folder = null;
		Document tempDoc = null;
		//		splitting of multiple documents
		ArrayList<String> docIds = new ArrayList<String>();
		if(documentQuery1 != null){
			String []ids = documentQuery1.split("'");
			if (ids.length > 1){
				for( int p=1; p < ids.length; p++){
					if(!ids[p].contains(",")){
						docIds.add(ids[p]);
					}
				}
			}
		}

		documentQuery = "!(IsWIPVer='1')";	//ensuring that document is not checked out
		while (nfolder != null) {				
			try {
				folder = new DomdocFolder(domdoc, nfolder);
				String docExportPath = path + folder.getMetadata().getFileroomId();
				new File(docExportPath).mkdirs();
//				documentQuery1 = documentQuery1.contains("DocID") ? documentQuery1 : "DocID = '" + documentQuery1+"'";
//				documentQuery=documentQuery+" & "+documentQuery1;
				documentQuery="DocID = '" + documentQuery1+"'";
//				System.out.println(documentQuery);
				documentExtraction(folder, nfolder, docExportPath);
			}catch (NullPointerException ne) {	
				exportDocLogger.warning("NullPointerException");
				exportDocLogger.log(Level.WARNING,"NullPointerException-", ne);

			}catch (NotesException ne) {	
				exportDocLogger.warning("NotesException in ExtractDocuments-#~"+ne.id+"~"+ne.text);
				ne.printStackTrace();
				exportDocLogger.log(Level.WARNING,"NotesException-", ne);
			}
			catch (Exception e) {	
				exportDocLogger.warning("Exception in ExtractDocuments #");
				e.printStackTrace();
				exportDocLogger.log(Level.WARNING,"Exception-", e);
			}
			tempDoc = folders.getNextDocument();
			nfolder.recycle();
			nfolder = tempDoc;
		} //end of while loop

		failureCount = failureCount + notesExcep ;//adding failures
		saveListToDatabse();
//		utilityIdFlag = true;

		if (folder != null ){
			folder.recycle();
		}
		if (folders != null){
			folders.recycle();
		}
	}
	private void saveListToDatabse() {
		if(regionList.size() > 0){
			DBConnection.updateRegion(regionList,region,DBConnection.getBatchConnection());
			regionList.clear();						
		}
		if(migrationSkippedDocumentList.size() > 0){
			DBConnection.saveSkippedDocuments(migrationSkippedDocumentList,DBConnection.getBatchConnection());
			migrationSkippedDocumentList.clear();
		}	
		System.gc();
	}

	/**
	 * documentExtraction method deals with document extraction
	 * @param folder
	 * @param nfolder
	 * @param docExportPath
	 * @throws NotesException
	 * @return void
	 * @throws IOException 
	 * @throws SQLException 
	 */
	private void documentExtraction(DomdocFolder folder, Document nfolder, String docExportPath) throws NotesException, SQLException, IOException {

		Document newNdoc = null,ndoc=null;
		DocumentCollection documents=null;
		try{
			documents = folder.findDocuments(documentQuery, null);
			int doc_cnt = documents.getCount();
			exportDocLogger.warning("Documents inside folder ~ " + nfolder.getItemValueString("title") + " = " + doc_cnt);
			ndoc = documents.getFirstDocument();
			parentDatabse = null;
		}
		catch(NotesException ne){
			exportDocLogger.warning(" Invalid Replica ID Found - "+nfolder.getItemValueString("documentdbid"));
			exportDocLogger.log(Level.WARNING,"documentExtraction Exception-", ne);
			listSkipDatabase(nfolder.getItemValueString("documentdbid"),nfolder.getItemValueString("filecabinet"),
			nfolder.getItemValueString("fileroom"),"Invalid Replica ID Found" ,"ER_019") ;
		}

		while (ndoc != null) {
			try{
				if(parentDatabse == null){
					parentDatabse = ndoc.getParentDatabase();
				}
			}catch(NotesException ne){
				exportDocLogger.log(Level.WARNING, "NotesException : Unable to open Parent Database database", ne);
			}

			try { 
				newNdoc = documents.getNextDocument(ndoc);	// for recycling ndoc, assigning the next ndoc to a variable
				boolean skipDocument = false;
				Document latest;					
				docid = ndoc.getItemValueString("docid");

				Folder_name=(ndoc.getItemValueString("FileRoom")).toUpperCase();//case is not uniform in documents.So converting all to upper case
				if (Folder_name.equals("MISCELLANEOUS")){Folder_name="COUNTRY";}
				if ((ndoc.getItemValueString("FileRoom")).toLowerCase().equals("projects")) folder_num=ndoc.getItemValueString("Project_id");
				if ((ndoc.getItemValueString("FileRoom")).toLowerCase().equals("institutions")) folder_num=ndoc.getItemValueString("Institution_Nbr");
				if ((ndoc.getItemValueString("FileRoom")).toLowerCase().equals("miscellaneous")) folder_num=ndoc.getItemValueString("Country_Name_Code");

				if (ndoc.getItemValueString("isCurrentVer").equals("1")) {
					latest = ndoc;
				} else {
					latest = parentDatabse.getView("IFCLatestDraftByDocID").getDocumentByKey(docid);
					if (latest == null) {
						latest = parentDatabse.getView("IFCLatestByDocID").getDocumentByKey(docid);
					}
				}
				if (latest == null) {
					listSkipDocuments(ndoc, docid, "Could not find latest document by docid.", "ER_018");
					skipDocument = true;
				}
				if (latest.getItemValueString("WIPUNID").length()>0) {	
					skipDocument = true;
					cout_cnt++;
					exportDocLogger.warning("Document " + docid + " is checked out, skipping...");
					listSkipDocuments(ndoc, docid, "Checked Out", "ER_002");
				} else if (latest.getItemValueString("WorkflowStatus").matches("[124]")) {
					skipDocument = true;
					wflow_cnt++;
					exportDocLogger.warning("Document " + docid + " is in workflow, skipping...");	
					listSkipDocuments(ndoc, docid, "In Workflow", "ER_003");
				}

				if (!skipDocument) {
					DomdocDocument doc = new DomdocDocument(ndoc);	//process current document
					doc.export(docExportPath);
					//updating the extraction of each entry into region table.
					boolean uniqueDoc = DBConnection.checkDuplicates(docid,region,utilityId);
					if (uniqueDoc){
						addToRegionList(utilityId, ndoc,region, "Y");
					}
					exportDocLogger.warning("DocID = " + ndoc.getItemValueString("DocID") + " ~ Title = " + nfolder.getItemValueString("TITLE")
							+ " ~ Type = " + ndoc.getItemValueString("FolderType") + " ~ FileCabinet = " + ndoc.getItemValueString("FileCabinet")
							+ " ~ exported successfully" + " ~ exportCount = " + exportCount);
					doc.recycle();
				}
				if(regionList.size()>=2000 || migrationSkippedDocumentList.size()>=2000){
					saveListToDatabse();
				}
			} 

			catch (NotesException e){
				notesExcep++;
				exportDocLogger.info(ndoc.getItemValueString("DocID") + " ~ has error ~ " + e.id + " ~ " + e.text);
				addToRegionList(utilityId, ndoc,region, "N");
				listSkipDocuments(ndoc, ndoc.getItemValueString("DocID"), "Doc Error - NotesException", "ER_001");
			} 
			catch (Exception e) {
				failureCount++;
				exportDocLogger.log(Level.WARNING,"documentExtraction Exception", e);
				e.printStackTrace();
				exportDocLogger.info(("Error exporting document " + ndoc.getUniversalID() + " from database " + parentDatabse.getTitle()+nfolder.getItemValueString("TITLE")));
				addToRegionList(utilityId, ndoc,region, "N");
				listSkipDocuments(ndoc, ndoc.getItemValueString("DocID"), "Doc Error - Exception", "ER_001");
			}
			ndoc.recycle();
			ndoc = newNdoc;
		}
		if(documents!=null){
		documents.recycle();
		}
	}
}
