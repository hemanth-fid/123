/**
 * This is the custom browser tree control class which extends Webtop's browser tree control
 * This customization is to hide the 'Add Repository' link which appears in the OOTB browser tree
 */
package org.ifc.idocs.controls.browsertree;

import java.util.Iterator;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.TreeNode;

/**
 * @author CVattathara
 *
 */
@SuppressWarnings("serial")
public class iDocsBrowserTreeControl extends com.documentum.webtop.control.WebTopBrowserTree
{

	@SuppressWarnings("unchecked")
	public void onInit(ArgumentList args)
	{
		DfLogger.info(this, " :: onInit", null, null);
		super.onInit(args);
		Iterator it = getAllNodes();
		if (null != it)
		{
			Object m_Node = null;
			while (it.hasNext())
			{
				m_Node = it.next();
			}
			if (null != m_Node)
			{
				((TreeNode) m_Node).setVisible(false);
			}
		}
	}
	
}
