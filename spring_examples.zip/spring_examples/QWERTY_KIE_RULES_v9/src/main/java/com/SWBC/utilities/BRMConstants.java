package com.SWBC.utilities;

public final class BRMConstants {
	
	public static final String DATE_FORMAT = "yyyy-MM-dd";
	public static final String NULL_DATE_VALUE = "1900-01-01";
	public static final String API_SOURCE = "api";
	public static final String APP_SOURCE = "app";
	public static final String NO_LOAN = "NO_LOAN";
	


}
