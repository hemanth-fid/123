package com.SWBC.model;

import java.util.Date;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;



@Service("PreProc_Doca_Ucap")
public class PreProc_Doca_Ucap {

	// New Attr
	private String pp_flag;
//	private String agent_email;
	private String insurance_type;
	
	private String object_name;
	private String operator_id;
	private String property_zip_4;
	
	private String impairmentC;
	private String impairmentE;
	private String impairmentM;
	private String impairmentN;
	private String impairmentR;
	private String impairmentY;
	private String impairmentZ;
	
	private String process_status;
	private Date process_date;
	private String process_flag;
	private String process_time;
	
	private String carrier_address_2;
	
	private String authors;
	
	private String agent_fax;
	
	private String a_status;
	
	
	private	double coverage_amount_2;
	private double net_premium_amount_2;
	private	double policy_premium_2;
	
	
	
	
	
	//LOG TABLE JOIN ID
	private long logJoinID;
	
//	private String agent_fax;
//	private String operator_id;
//	private	double	coverage_amount_2;
//	private double net_premium_amount_2;
//	private	double	policy_premium;
//	2nd Policy Premium Amount
//	2nd Net Premium Amount

	// SubString ACCT Attrs
	private String FC_FORMAT;
	private String FC_ACCOUNT;
	private String FIRE;
	private String HOME;
	private String FLOOD;
	private String WIND;
	private String CONT;
	private String LIAB;
	private String EQUIP;
	private String QUAKE;
	private String GAP;
	private String OTHR;

	// Carrier Attrs
	private String CO_ALIAS;
	private String CO_NAME;
	private String CO_TRAN_DATE;
	private String CO_OPERATOR_ID;
	private String CO_SPARE_01;
	private String CO_SPARE_02;
	private String CO_DATE_01;
	private String CO_DATE_02;
	private String CO_FILLER;

	// Rule 3.1 Pre Proc FMS057 table columns

	private List<String> SHORTNAME;
	private List<String> PAYEE;
	private List<String> SHORTNAME_CARRIER;
	private List<String> PAYEE_CARRIER;

	// Rule 3.4 Pre proc IS_AGENT_CODE
	private String IS_AGENT_CODE;

	// Policy Score
	private int policy_score;

	// Master Payee - Pre Proc Rule 3.3
	private String masterPayee;

	private String flood_zone;
	private String ho_6_flag;
	private String grandfater_zone;
	private String earthquake_excluded;
	private String grandfather_zone;
	private Date doc_scan_date;
	private String replace_cost_ind;
	private String bill_indicator;
	private String percent_add_other_structure;
	private String wind_excluded;
	private String document_sub_type;
	private Date follow_up_date;
	private String follow_up_reason;
	private String agent_email;
	private String cov_type;
	private String is_qc_candidate;
	private String document_type;
	private String loan_type;
	private Date policy_expiration_date;
	private Date policy_cancel_date;
	private String carrier_zip;
	private Date premium_due_date;
	private String transaction_status;
	private String orig_file_name;
	private String property_zip;
	private String loan_number;
	private double percent_primary_coverage;
	private double policy_premium;
	private String agency_number;
	private String escrow_indicator;
	private String mailing_address;
	private double percent_deductible;
	private String account_number;
	private int batch_number;
	private double coverage_amount;
	private String account_tax_id;
	private String property_address_1;
	private String property_address_2;
	private Date doc_issue_date;
	private String mailing_state;
	private String payee_code;
	private String client_number;
	private int number_of_condos;
	private String qc_response_code;
	private String scan_id;
	private Date doc_notice_effective_date;
	private Date doc_delivery_date;
	private String property_city;
	private String policy_number;
	private String mortgagee_zip;
	private String mortgagee_name;
	private Date doc_notice_date;
	private String agent_city;
	private String impairment_code;
	private String agent_name;
	private String mailing_city;
	private String policy_cancel_reason;
	private String mortgagee_city;
	private String agent_zip;
	private String account_name;
	private String transaction_id;
	private int batch_seq_no;
	private Date reinstatement_date;
	private String transaction_source;
	private String co_policy_holder_name;
	private Date policy_effective_date;
	private String property_state;
	private String carrier_city;
	private String agent_phone;
	private String carrier_name;
	private String loan_suffix;
	private Date doc_received_date;
	private String mortgagee_address;
	private String carrier_state;
	private Date as400_post_date;
	private String agent_address;
	private double additional_coverage_amount;
	private double additional_premium_amt;
	private String institution_code;
	private String carrier_address_1;
	private String agent_state;
	private String policy_holder_name;
	private double deductible;
	private String transaction_type;
	private String mailing_zip;
	private String mortgagee_state;
	private String carrier_phone;
	private double base_coverage_other_structs;
	
	
	
	



	public String getObject_name() {
		return object_name;
	}

	public void setObject_name(String object_name) {
		this.object_name = object_name;
	}

	public String getOperator_id() {
		return operator_id;
	}

	public void setOperator_id(String operator_id) {
		this.operator_id = operator_id;
	}

	public String getProperty_zip_4() {
		return property_zip_4;
	}

	public void setProperty_zip_4(String property_zip_4) {
		this.property_zip_4 = property_zip_4;
	}

	public String getImpairmentC() {
		return impairmentC;
	}

	public void setImpairmentC(String impairmentC) {
		this.impairmentC = impairmentC;
	}

	public String getImpairmentE() {
		return impairmentE;
	}

	public void setImpairmentE(String impairmentE) {
		this.impairmentE = impairmentE;
	}

	public String getImpairmentM() {
		return impairmentM;
	}

	public void setImpairmentM(String impairmentM) {
		this.impairmentM = impairmentM;
	}

	public String getImpairmentN() {
		return impairmentN;
	}

	public void setImpairmentN(String impairmentN) {
		this.impairmentN = impairmentN;
	}

	public String getImpairmentR() {
		return impairmentR;
	}

	public void setImpairmentR(String impairmentR) {
		this.impairmentR = impairmentR;
	}

	public String getImpairmentY() {
		return impairmentY;
	}

	public void setImpairmentY(String impairmentY) {
		this.impairmentY = impairmentY;
	}

	public String getImpairmentZ() {
		return impairmentZ;
	}

	public void setImpairmentZ(String impairmentZ) {
		this.impairmentZ = impairmentZ;
	}

	public String getProcess_status() {
		return process_status;
	}

	public void setProcess_status(String process_status) {
		this.process_status = process_status;
	}

	public Date getProcess_date() {
		return process_date;
	}

	public void setProcess_date(Date process_date) {
		this.process_date = process_date;
	}

	public String getProcess_flag() {
		return process_flag;
	}

	public void setProcess_flag(String process_flag) {
		this.process_flag = process_flag;
	}

	public String getProcess_time() {
		return process_time;
	}

	public void setProcess_time(String process_time) {
		this.process_time = process_time;
	}

	public String getCarrier_address_2() {
		return carrier_address_2;
	}

	public void setCarrier_address_2(String carrier_address_2) {
		this.carrier_address_2 = carrier_address_2;
	}

	public String getAuthors() {
		return authors;
	}

	public void setAuthors(String authors) {
		this.authors = authors;
	}

	public String getAgent_fax() {
		return agent_fax;
	}

	public void setAgent_fax(String agent_fax) {
		this.agent_fax = agent_fax;
	}

	public String getA_status() {
		return a_status;
	}

	public void setA_status(String a_status) {
		this.a_status = a_status;
	}

	public double getCoverage_amount_2() {
		return coverage_amount_2;
	}

	public void setCoverage_amount_2(double coverage_amount_2) {
		this.coverage_amount_2 = coverage_amount_2;
	}

	public double getNet_premium_amount_2() {
		return net_premium_amount_2;
	}

	public void setNet_premium_amount_2(double net_premium_amount_2) {
		this.net_premium_amount_2 = net_premium_amount_2;
	}

	public double getPolicy_premium_2() {
		return policy_premium_2;
	}

	public void setPolicy_premium_2(double policy_premium_2) {
		this.policy_premium_2 = policy_premium_2;
	}

	public long getLogJoinID() {
		return logJoinID;
	}

	public void setLogJoinID(long logJoinID) {
		this.logJoinID = logJoinID;
	}

	public String getPp_flag() {
		return pp_flag;
	}

	public void setPp_flag(String pp_flag) {
		this.pp_flag = pp_flag;
	}

	public List<String> getSHORTNAME() {
		return SHORTNAME;
	}

	public void setSHORTNAME(List<String> sHORTNAME) {
		SHORTNAME = sHORTNAME;
	}

	public List<String> getPAYEE() {
		return PAYEE;
	}

	public void setPAYEE(List<String> pAYEE) {
		PAYEE = pAYEE;
	}

	public String getMasterPayee() {
		return masterPayee;
	}

	public void setMasterPayee(String masterPayee) {
		this.masterPayee = masterPayee;
	}

	public List<String> getSHORTNAME_CARRIER() {
		return SHORTNAME_CARRIER;
	}

	public void setSHORTNAME_CARRIER(List<String> sHORTNAME_CARRIER) {
		SHORTNAME_CARRIER = sHORTNAME_CARRIER;
	}

	public List<String> getPAYEE_CARRIER() {
		return PAYEE_CARRIER;
	}

	public void setPAYEE_CARRIER(List<String> pAYEE_CARRIER) {
		PAYEE_CARRIER = pAYEE_CARRIER;
	}

	public String getIS_AGENT_CODE() {
		return IS_AGENT_CODE;
	}

	public void setIS_AGENT_CODE(String iS_AGENT_CODE) {
		IS_AGENT_CODE = iS_AGENT_CODE;
	}

	public int getPolicy_score() {
		return policy_score;
	}

	public void setPolicy_score(int policy_score) {
		this.policy_score = policy_score;
	}

	public String getInsurance_type() {
		return insurance_type;
	}

	public void setInsurance_type(String insurance_type) {
		this.insurance_type = insurance_type;
	}

	public String getFC_FORMAT() {
		return FC_FORMAT;
	}

	public void setFC_FORMAT(String fC_FORMAT) {
		FC_FORMAT = fC_FORMAT;
	}

	public String getFC_ACCOUNT() {
		return FC_ACCOUNT;
	}

	public void setFC_ACCOUNT(String fC_ACCOUNT) {
		FC_ACCOUNT = fC_ACCOUNT;
	}

	public String getFIRE() {
		return FIRE;
	}

	public void setFIRE(String fIRE) {
		FIRE = fIRE;
	}

	public String getHOME() {
		return HOME;
	}

	public void setHOME(String hOME) {
		HOME = hOME;
	}

	public String getFLOOD() {
		return FLOOD;
	}

	public void setFLOOD(String fLOOD) {
		FLOOD = fLOOD;
	}

	public String getWIND() {
		return WIND;
	}

	public void setWIND(String wIND) {
		WIND = wIND;
	}

	public String getCONT() {
		return CONT;
	}

	public void setCONT(String cONT) {
		CONT = cONT;
	}

	public String getLIAB() {
		return LIAB;
	}

	public void setLIAB(String lIAB) {
		LIAB = lIAB;
	}

	public String getEQUIP() {
		return EQUIP;
	}

	public void setEQUIP(String eQUIP) {
		EQUIP = eQUIP;
	}

	public String getQUAKE() {
		return QUAKE;
	}

	public void setQUAKE(String qUAKE) {
		QUAKE = qUAKE;
	}

	public String getGAP() {
		return GAP;
	}

	public void setGAP(String gAP) {
		GAP = gAP;
	}

	public String getOTHR() {
		return OTHR;
	}

	public void setOTHR(String oTHR) {
		OTHR = oTHR;
	}

	public String getCO_ALIAS() {
		return CO_ALIAS;
	}

	public void setCO_ALIAS(String cO_ALIAS) {
		CO_ALIAS = cO_ALIAS;
	}

	public String getCO_NAME() {
		return CO_NAME;
	}

	public void setCO_NAME(String cO_NAME) {
		CO_NAME = cO_NAME;
	}

	public String getCO_TRAN_DATE() {
		return CO_TRAN_DATE;
	}

	public void setCO_TRAN_DATE(String cO_TRAN_DATE) {
		CO_TRAN_DATE = cO_TRAN_DATE;
	}

	public String getCO_OPERATOR_ID() {
		return CO_OPERATOR_ID;
	}

	public void setCO_OPERATOR_ID(String cO_OPERATOR_ID) {
		CO_OPERATOR_ID = cO_OPERATOR_ID;
	}

	public String getCO_SPARE_01() {
		return CO_SPARE_01;
	}

	public void setCO_SPARE_01(String cO_SPARE_01) {
		CO_SPARE_01 = cO_SPARE_01;
	}

	public String getCO_SPARE_02() {
		return CO_SPARE_02;
	}

	public void setCO_SPARE_02(String cO_SPARE_02) {
		CO_SPARE_02 = cO_SPARE_02;
	}

	public String getCO_DATE_01() {
		return CO_DATE_01;
	}

	public void setCO_DATE_01(String cO_DATE_01) {
		CO_DATE_01 = cO_DATE_01;
	}

	public String getCO_DATE_02() {
		return CO_DATE_02;
	}

	public void setCO_DATE_02(String cO_DATE_02) {
		CO_DATE_02 = cO_DATE_02;
	}

	public String getCO_FILLER() {
		return CO_FILLER;
	}

	public void setCO_FILLER(String cO_FILLER) {
		CO_FILLER = cO_FILLER;
	}

	public String getFlood_zone() {
		return flood_zone;
	}

	public void setFlood_zone(String flood_zone) {
		this.flood_zone = flood_zone;
	}

	public String getHo_6_flag() {
		return ho_6_flag;
	}

	public void setHo_6_flag(String ho_6_flag) {
		this.ho_6_flag = ho_6_flag;
	}

	public String getGrandfater_zone() {
		return grandfater_zone;
	}

	public void setGrandfater_zone(String grandfater_zone) {
		this.grandfater_zone = grandfater_zone;
	}

	public String getEarthquake_excluded() {
		return earthquake_excluded;
	}

	public void setEarthquake_excluded(String earthquake_excluded) {
		this.earthquake_excluded = earthquake_excluded;
	}

	public String getGrandfather_zone() {
		return grandfather_zone;
	}

	public void setGrandfather_zone(String grandfather_zone) {
		this.grandfather_zone = grandfather_zone;
	}

	public Date getDoc_scan_date() {
		return doc_scan_date;
	}

	public void setDoc_scan_date(Date doc_scan_date) {
		this.doc_scan_date = doc_scan_date;
	}

	public String getReplace_cost_ind() {
		return replace_cost_ind;
	}

	public void setReplace_cost_ind(String replace_cost_ind) {
		this.replace_cost_ind = replace_cost_ind;
	}

	public String getBill_indicator() {
		return bill_indicator;
	}

	public void setBill_indicator(String bill_indicator) {
		this.bill_indicator = bill_indicator;
	}

	public String getPercent_add_other_structure() {
		return percent_add_other_structure;
	}

	public void setPercent_add_other_structure(String percent_add_other_structure) {
		this.percent_add_other_structure = percent_add_other_structure;
	}

	public String getWind_excluded() {
		return wind_excluded;
	}

	public void setWind_excluded(String wind_excluded) {
		this.wind_excluded = wind_excluded;
	}

	public String getDocument_sub_type() {
		return document_sub_type;
	}

	public void setDocument_sub_type(String document_sub_type) {
		this.document_sub_type = document_sub_type;
	}

	public Date getFollow_up_date() {
		return follow_up_date;
	}

	public void setFollow_up_date(Date follow_up_date) {
		this.follow_up_date = follow_up_date;
	}

	public String getFollow_up_reason() {
		return follow_up_reason;
	}

	public void setFollow_up_reason(String follow_up_reason) {
		this.follow_up_reason = follow_up_reason;
	}

	public String getAgent_email() {
		return agent_email;
	}

	public void setAgent_email(String agent_email) {
		this.agent_email = agent_email;
	}

	public String getCov_type() {
		return cov_type;
	}

	public void setCov_type(String cov_type) {
		this.cov_type = cov_type;
	}

	public String getIs_qc_candidate() {
		return is_qc_candidate;
	}

	public void setIs_qc_candidate(String is_qc_candidate) {
		this.is_qc_candidate = is_qc_candidate;
	}

	public String getDocument_type() {
		return document_type;
	}

	public void setDocument_type(String document_type) {
		this.document_type = document_type;
	}

	public String getLoan_type() {
		return loan_type;
	}

	public void setLoan_type(String loan_type) {
		this.loan_type = loan_type;
	}

	public Date getPolicy_expiration_date() {
		return policy_expiration_date;
	}

	public void setPolicy_expiration_date(Date policy_expiration_date) {
		this.policy_expiration_date = policy_expiration_date;
	}

	public Date getPolicy_cancel_date() {
		return policy_cancel_date;
	}

	public void setPolicy_cancel_date(Date policy_cancel_date) {
		this.policy_cancel_date = policy_cancel_date;
	}

	public String getCarrier_zip() {
		return carrier_zip;
	}

	public void setCarrier_zip(String carrier_zip) {
		this.carrier_zip = carrier_zip;
	}

	public Date getPremium_due_date() {
		return premium_due_date;
	}

	public void setPremium_due_date(Date premium_due_date) {
		this.premium_due_date = premium_due_date;
	}

	public String getTransaction_status() {
		return transaction_status;
	}

	public void setTransaction_status(String transaction_status) {
		this.transaction_status = transaction_status;
	}

	public String getOrig_file_name() {
		return orig_file_name;
	}

	public void setOrig_file_name(String orig_file_name) {
		this.orig_file_name = orig_file_name;
	}

	public String getProperty_zip() {
		return property_zip;
	}

	public void setProperty_zip(String property_zip) {
		this.property_zip = property_zip;
	}

	public String getLoan_number() {
		return loan_number;
	}

	public void setLoan_number(String loan_number) {
		this.loan_number = loan_number;
	}

	public double getPercent_primary_coverage() {
		return percent_primary_coverage;
	}

	public void setPercent_primary_coverage(double percent_primary_coverage) {
		this.percent_primary_coverage = percent_primary_coverage;
	}

	public double getPolicy_premium() {
		return policy_premium;
	}

	public void setPolicy_premium(double policy_premium) {
		this.policy_premium = policy_premium;
	}

	public String getAgency_number() {
		return agency_number;
	}

	public void setAgency_number(String agency_number) {
		this.agency_number = agency_number;
	}

	public String getEscrow_indicator() {
		return escrow_indicator;
	}

	public void setEscrow_indicator(String escrow_indicator) {
		this.escrow_indicator = escrow_indicator;
	}

	public String getMailing_address() {
		return mailing_address;
	}

	public void setMailing_address(String mailing_address) {
		this.mailing_address = mailing_address;
	}

	public double getPercent_deductible() {
		return percent_deductible;
	}

	public void setPercent_deductible(double percent_deductible) {
		this.percent_deductible = percent_deductible;
	}

	public String getAccount_number() {
		return account_number;
	}

	public void setAccount_number(String account_number) {
		this.account_number = account_number;
	}

	public int getBatch_number() {
		return batch_number;
	}

	public void setBatch_number(int batch_number) {
		this.batch_number = batch_number;
	}

	public double getCoverage_amount() {
		return coverage_amount;
	}

	public void setCoverage_amount(double coverage_amount) {
		this.coverage_amount = coverage_amount;
	}

	public String getAccount_tax_id() {
		return account_tax_id;
	}

	public void setAccount_tax_id(String account_tax_id) {
		this.account_tax_id = account_tax_id;
	}

	public String getProperty_address_1() {
		return property_address_1;
	}

	public void setProperty_address_1(String property_address_1) {
		this.property_address_1 = property_address_1;
	}

	public String getProperty_address_2() {
		return property_address_2;
	}

	public void setProperty_address_2(String property_address_2) {
		this.property_address_2 = property_address_2;
	}

	public Date getDoc_issue_date() {
		return doc_issue_date;
	}

	public void setDoc_issue_date(Date doc_issue_date) {
		this.doc_issue_date = doc_issue_date;
	}

	public String getMailing_state() {
		return mailing_state;
	}

	public void setMailing_state(String mailing_state) {
		this.mailing_state = mailing_state;
	}

	public String getPayee_code() {
		return payee_code;
	}

	public void setPayee_code(String payee_code) {
		this.payee_code = payee_code;
	}

	public String getClient_number() {
		return client_number;
	}

	public void setClient_number(String client_number) {
		this.client_number = client_number;
	}

	public int getNumber_of_condos() {
		return number_of_condos;
	}

	public void setNumber_of_condos(int number_of_condos) {
		this.number_of_condos = number_of_condos;
	}

	public String getQc_response_code() {
		return qc_response_code;
	}

	public void setQc_response_code(String qc_response_code) {
		this.qc_response_code = qc_response_code;
	}

	public String getScan_id() {
		return scan_id;
	}

	public void setScan_id(String scan_id) {
		this.scan_id = scan_id;
	}

	public Date getDoc_notice_effective_date() {
		return doc_notice_effective_date;
	}

	public void setDoc_notice_effective_date(Date doc_notice_effective_date) {
		this.doc_notice_effective_date = doc_notice_effective_date;
	}

	public Date getDoc_delivery_date() {
		return doc_delivery_date;
	}

	public void setDoc_delivery_date(Date doc_delivery_date) {
		this.doc_delivery_date = doc_delivery_date;
	}

	public String getProperty_city() {
		return property_city;
	}

	public void setProperty_city(String property_city) {
		this.property_city = property_city;
	}

	public String getPolicy_number() {
		return policy_number;
	}

	public void setPolicy_number(String policy_number) {
		this.policy_number = policy_number;
	}

	public String getMortgagee_zip() {
		return mortgagee_zip;
	}

	public void setMortgagee_zip(String mortgagee_zip) {
		this.mortgagee_zip = mortgagee_zip;
	}

	public String getMortgagee_name() {
		return mortgagee_name;
	}

	public void setMortgagee_name(String mortgagee_name) {
		this.mortgagee_name = mortgagee_name;
	}

	public Date getDoc_notice_date() {
		return doc_notice_date;
	}

	public void setDoc_notice_date(Date doc_notice_date) {
		this.doc_notice_date = doc_notice_date;
	}

	public String getAgent_city() {
		return agent_city;
	}

	public void setAgent_city(String agent_city) {
		this.agent_city = agent_city;
	}

	public String getImpairment_code() {
		return impairment_code;
	}

	public void setImpairment_code(String impairment_code) {
		this.impairment_code = impairment_code;
	}

	public String getAgent_name() {
		return agent_name;
	}

	public void setAgent_name(String agent_name) {
		this.agent_name = agent_name;
	}

	public String getMailing_city() {
		return mailing_city;
	}

	public void setMailing_city(String mailing_city) {
		this.mailing_city = mailing_city;
	}

	public String getPolicy_cancel_reason() {
		return policy_cancel_reason;
	}

	public void setPolicy_cancel_reason(String policy_cancel_reason) {
		this.policy_cancel_reason = policy_cancel_reason;
	}

	public String getMortgagee_city() {
		return mortgagee_city;
	}

	public void setMortgagee_city(String mortgagee_city) {
		this.mortgagee_city = mortgagee_city;
	}

	public String getAgent_zip() {
		return agent_zip;
	}

	public void setAgent_zip(String agent_zip) {
		this.agent_zip = agent_zip;
	}

	public String getAccount_name() {
		return account_name;
	}

	public void setAccount_name(String account_name) {
		this.account_name = account_name;
	}

	public String getTransaction_id() {
		return transaction_id;
	}

	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}

	public int getBatch_seq_no() {
		return batch_seq_no;
	}

	public void setBatch_seq_no(int batch_seq_no) {
		this.batch_seq_no = batch_seq_no;
	}

	public Date getReinstatement_date() {
		return reinstatement_date;
	}

	public void setReinstatement_date(Date reinstatement_date) {
		this.reinstatement_date = reinstatement_date;
	}

	public String getTransaction_source() {
		return transaction_source;
	}

	public void setTransaction_source(String transaction_source) {
		this.transaction_source = transaction_source;
	}

	public String getCo_policy_holder_name() {
		return co_policy_holder_name;
	}

	public void setCo_policy_holder_name(String co_policy_holder_name) {
		this.co_policy_holder_name = co_policy_holder_name;
	}

	public Date getPolicy_effective_date() {
		return policy_effective_date;
	}

	public void setPolicy_effective_date(Date policy_effective_date) {
		this.policy_effective_date = policy_effective_date;
	}

	public String getProperty_state() {
		return property_state;
	}

	public void setProperty_state(String property_state) {
		this.property_state = property_state;
	}

	public String getCarrier_city() {
		return carrier_city;
	}

	public void setCarrier_city(String carrier_city) {
		this.carrier_city = carrier_city;
	}

	public String getAgent_phone() {
		return agent_phone;
	}

	public void setAgent_phone(String agent_phone) {
		this.agent_phone = agent_phone;
	}

	public String getCarrier_name() {
		return carrier_name;
	}

	public void setCarrier_name(String carrier_name) {
		this.carrier_name = carrier_name;
	}

	public String getLoan_suffix() {
		return loan_suffix;
	}

	public void setLoan_suffix(String loan_suffix) {
		this.loan_suffix = loan_suffix;
	}

	public Date getDoc_received_date() {
		return doc_received_date;
	}

	public void setDoc_received_date(Date doc_received_date) {
		this.doc_received_date = doc_received_date;
	}

	public String getMortgagee_address() {
		return mortgagee_address;
	}

	public void setMortgagee_address(String mortgagee_address) {
		this.mortgagee_address = mortgagee_address;
	}

	public String getCarrier_state() {
		return carrier_state;
	}

	public void setCarrier_state(String carrier_state) {
		this.carrier_state = carrier_state;
	}

	public Date getAs400_post_date() {
		return as400_post_date;
	}

	public void setAs400_post_date(Date as400_post_date) {
		this.as400_post_date = as400_post_date;
	}

	public String getAgent_address() {
		return agent_address;
	}

	public void setAgent_address(String agent_address) {
		this.agent_address = agent_address;
	}

	public double getAdditional_coverage_amount() {
		return additional_coverage_amount;
	}

	public void setAdditional_coverage_amount(double additional_coverage_amount) {
		this.additional_coverage_amount = additional_coverage_amount;
	}

	public double getAdditional_premium_amt() {
		return additional_premium_amt;
	}

	public void setAdditional_premium_amt(double additional_premium_amt) {
		this.additional_premium_amt = additional_premium_amt;
	}

	public String getInstitution_code() {
		return institution_code;
	}

	public void setInstitution_code(String institution_code) {
		this.institution_code = institution_code;
	}

	public String getCarrier_address_1() {
		return carrier_address_1;
	}

	public void setCarrier_address_1(String carrier_address_1) {
		this.carrier_address_1 = carrier_address_1;
	}

	public String getAgent_state() {
		return agent_state;
	}

	public void setAgent_state(String agent_state) {
		this.agent_state = agent_state;
	}

	public String getPolicy_holder_name() {
		return policy_holder_name;
	}

	public void setPolicy_holder_name(String policy_holder_name) {
		this.policy_holder_name = policy_holder_name;
	}

	public double getDeductible() {
		return deductible;
	}

	public void setDeductible(double deductible) {
		this.deductible = deductible;
	}

	public String getTransaction_type() {
		return transaction_type;
	}

	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}

	public String getMailing_zip() {
		return mailing_zip;
	}

	public void setMailing_zip(String mailing_zip) {
		this.mailing_zip = mailing_zip;
	}

	public String getMortgagee_state() {
		return mortgagee_state;
	}

	public void setMortgagee_state(String mortgagee_state) {
		this.mortgagee_state = mortgagee_state;
	}

	public String getCarrier_phone() {
		return carrier_phone;
	}

	public void setCarrier_phone(String carrier_phone) {
		this.carrier_phone = carrier_phone;
	}

	public double getBase_coverage_other_structs() {
		return base_coverage_other_structs;
	}

	public void setBase_coverage_other_structs(double base_coverage_other_structs) {
		this.base_coverage_other_structs = base_coverage_other_structs;
	}
}
