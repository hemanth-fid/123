package com.swbc.letters.commercial.migrate.utils;

import java.io.FileNotFoundException;
import java.io.InputStream;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.Logger;


public class PropertyReader {

	private static final Logger LOGGER = Logger.getLogger(PropertyReader.class);

	private  PropertiesConfiguration propertiesConfiguration = null;

	public PropertyReader(String propFileName) throws Exception {

		try {
			
			LOGGER.info("Loading properties...."+ propFileName);
			
			propertiesConfiguration=new PropertiesConfiguration();
			InputStream appContextStream = this.getClass().getClassLoader().getResourceAsStream(propFileName);
			
			if (appContextStream != null) {
				
				propertiesConfiguration.load(appContextStream);
				
			} else {
				throw new FileNotFoundException("Configuration property file '"
						+ propFileName
						+ "' to run the utility not found in the classpath.");
			}
				
				
			
		} catch (FileNotFoundException ex) {
			throw new Exception(
					"Error while loading the utility property file : "
							+ ex.getMessage());
		}
	}

	public String getProperty(String propKey) {
		return propertiesConfiguration.getString(propKey);
	}

}
