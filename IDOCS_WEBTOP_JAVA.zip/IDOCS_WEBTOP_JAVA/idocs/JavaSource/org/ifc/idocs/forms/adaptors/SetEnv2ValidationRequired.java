package org.ifc.idocs.forms.adaptors;

import com.documentum.fc.common.DfLogger;
import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.IAdaptorParameter;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.xforms.engine.adaptor.datasource.ISetValueAdaptor;

public class SetEnv2ValidationRequired
    implements ISetValueAdaptor
{

    public SetEnv2ValidationRequired()
    {
    }

    public Object execute(IAdaptorParameter parameters[])
        throws AdaptorException
    {
        DfLogger.info(this,"SetEnv2ValidationRequired:: SetEnv2ValidationRequired",null,null); 
        String validationRequired = "env2";
        return validationRequired;
    }

    public void destroy()
        throws AdaptorException
    {
    }

    public void init(IAdaptorConfiguration iadaptorconfiguration)
        throws AdaptorException
    {
    }
}
