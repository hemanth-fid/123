package com.SWBC.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service("BRMUtilities")

public class BRMUtilities {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	public static int getPolicyNumberScore(String a, String b) {
		a = a.toLowerCase().trim();
		b = b.toLowerCase().trim();
		// i == 0
		int[] costs = new int[b.length() + 1];
		for (int j = 0; j < costs.length; j++)
			costs[j] = j;
		for (int i = 1; i <= a.length(); i++) {
			// j == 0; nw = lev(i - 1, j)
			costs[0] = i;
			int nw = i - 1;
			for (int j = 1; j <= b.length(); j++) {
				int cj = Math.min(1 + Math.min(costs[j], costs[j - 1]),
						a.charAt(i - 1) == b.charAt(j - 1) ? nw : nw + 1);
				nw = costs[j];
				costs[j] = cj;
			}
		}
		return costs[b.length()];
	}

	public static Date convertAS400DateToDateStr(String as400Date) {
		System.out.println("convertAS400DateToDateStr() Input:" + as400Date);
		// String as400DateStr = Integer.toString(as400Date);
		String as400DateStr = as400Date;

		String strDate = "";

		if (as400DateStr.matches("\\d{2}\\/\\d{2}\\/\\d{4}") || (as400DateStr.isEmpty())) {
			strDate = as400DateStr;
		} else if (as400DateStr.equalsIgnoreCase("0") || as400DateStr.equalsIgnoreCase("0.0")) {
			strDate = "1900-01-01";
		} else {
			int idate = Integer.parseInt(as400DateStr.replace(".0", ""));
			int iday = idate % 100;
			idate /= 100;
			int imonth = idate % 100;
			idate /= 100;
			int iyear = idate + 1900;
			strDate = padLeft(String.valueOf(iyear), 4, "0").concat("-").concat(padLeft(String.valueOf(imonth), 2, "0"))
					.concat("-").concat(padLeft(String.valueOf(iday), 2, "0"));
		}

		System.out.println("convertAS400DateToDateStr() Output:" + as400Date);

		DateFormat parser = new SimpleDateFormat("yyyy-MM-dd");
		Date date = null;
		try {
			date = (Date) parser.parse(strDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return date;
	}

	public static String padLeft(String instring, int length, String padstring) {
		while (instring.length() < length) {
			instring = padstring.concat(instring);
		}

		return instring;
	}

	public static String getKIESessionName(String ruleVersion, String transType) {
		String kSessionName = "";

		if (transType.equals("XLC") || transType.equals("RWX")) {
			if (ruleVersion.equals("100")) {
				return "xlc_rulesSession";
			} else {
				return "xlc_rulesSession_v2";
			}
		} else if (transType.equals("REI")) {
			if (ruleVersion.equals("100")) {
				return "rei_rulesSession";
			} else {
				return "rei_rulesSession_v2";
			}
		} else if (transType.equals("ITC")) {
			if (ruleVersion.equals("100")) {
				return "itc_rulesSession";
			} else {
				return "itc_rulesSession_v2";
			}
		}

		// else if (transType.equals("CVC"))
		// {
		// if (ruleVersion.equals("100")) {
		// return "pch_rulesSession";
		// } else {
		// return "pch_rulesSession_v2";
		// }
		// }
		else if (transType.equals("INV")) {
			if (ruleVersion.equals("100")) {
				return "inv_rulesSession";
			} else {
				return "inv_rulesSession_v2";
			}
		} else if (getNBSTypes().contains(transType)) {
			if (ruleVersion.equals("100")) {
				return "nbs_rulesSession";
			} else {
				return "nbs_rulesSession_v2";
			}
		} else {
			return "default_rulesSession";
		}

	}

	public static Date evaluateNullDate(Date toBeChecked) {

		try {

			// if(toBeChecked.toString().equalsIgnoreCase("1900-01-01
			// 00:00:00.0"))
			if (toBeChecked.toString().equalsIgnoreCase("1900-01-01")) {
				return new SimpleDateFormat("yyyy-mm-dd").parse("1900-01-01");
			} else {
				return toBeChecked;
			}

		} catch (Exception e) {
			System.out.println("############### evaluateNullDate Exception " + e.getMessage().toString() + ", Date:"
					+ toBeChecked.toString() + " #######################");
		}

		return null;

	}

	public static Boolean checkNullDate(Date toBeChecked) {

		boolean dateBlankFlag = false;

		try {

			if (toBeChecked.toString().contains("1900")) {
				dateBlankFlag = true;
			} else {
				dateBlankFlag = false;
			}

		} catch (Exception e) {
			System.out.println("############### evaluateNullDate Exception " + e.getMessage().toString() + ", Date:"
					+ toBeChecked.toString() + " #######################");
		}
		return dateBlankFlag;

	}

	public static Boolean checkNullDate(Date toBeChecked, boolean notNullCheck) {

		boolean dateBlankFlag = false;

		if (notNullCheck) {

			try {

				if (toBeChecked.toString().contains("1900")) {
					dateBlankFlag = true;
				} else {
					dateBlankFlag = false;
				}

			} catch (Exception e) {
				System.out.println("############### evaluateNullDate Exception " + e.getMessage().toString() + ", Date:"
						+ toBeChecked.toString() + " #######################");
			}
		}

		return dateBlankFlag;

	}

	
	
	
	public static Boolean isNullDate(Date toBeChecked) {

		boolean dateBlankFlag = false;

		try {

			if (toBeChecked.toString().contains("1900")) {
				dateBlankFlag = true;
			} else {
				dateBlankFlag = false;
			}

		} catch (Exception e) {
			System.out.println("############### evaluateNullDate Exception " + e.getMessage().toString() + ", Date:"
					+ toBeChecked.toString() + " #######################");
		}
		return dateBlankFlag;

	}

	public static Boolean isNullDate(Date toBeChecked, boolean notNullCheck) {

		boolean dateBlankFlag = false;

		if (notNullCheck) {

			try {

				if (toBeChecked.toString().contains("1900")) {
					dateBlankFlag = false;
				} else {
					dateBlankFlag = true;
				}

			} catch (Exception e) {
				System.out.println("############### evaluateNullDate Exception " + e.getMessage().toString() + ", Date:"
						+ toBeChecked.toString() + " #######################");
			}
		}

		return dateBlankFlag;

	}
	
	
	
	
	public static boolean evaluateDateRange(Date startDate, Date betweenDate, Date endDate) {

		if (startDate.compareTo(betweenDate) < 0 && endDate.compareTo(betweenDate) > 0) {
			return true;
		}

		return false;

	}

	public static List<String> getNBSTypes() {
		List<String> reqList = new ArrayList<String>();

		String[] tempArr = "PCH,CVC,NBS,RWL,RWF,REW,RIX,EPI,TMP,BND,BLANK".split(",");

		for (int i = 0; i < tempArr.length; i++) {

			reqList.add(tempArr[i].trim());
		}

		return reqList;
	}

	public static Connection createDBConnection(String DB_URL, String USER, String PASS, String DB_Driver) {
		System.out.println("Inside createDBConnection()");

		Connection conn = null;

		try {
			Class.forName(DB_Driver);

			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			System.out.println("Database Connection Created for [" + DB_Driver + "]: " + conn.toString());

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			System.out.println("Error createDBConnection(): " + e.toString());
		}

		return conn;

	}

	public static void closeDBConnection(Connection conn) {
		// System.out.println("Inside closeConnection()");
		try {
			conn.close();
			System.out.println("Database Connection Closed" + "\n");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			System.out.println("Error: " + e.toString());

		}
	}
	
	public static boolean isDateBWProcDate(Date dateToCheck, int range)
	{
		boolean testDates = false;
		
		testDates = TimeUnit.DAYS.convert(dateToCheck.getTime() - new Date().getTime(), 
				TimeUnit.MILLISECONDS) >= range
				|| 
				TimeUnit.DAYS.convert( new Date().getTime() - dateToCheck.getTime(), 
				TimeUnit.MILLISECONDS) <= range;
		
		
		return testDates;
		
	}
	
	
	public static boolean isDateBWDate(Date dateToCheck, Date dateOlder, Date dateFuture)
	{
		boolean testDates = false;
		
		
		
		
		return testDates;
		
	}
	
	
	
	public static int getMonthsBWDate(Date biggerDate, Date lesserDate)
	{
		
		
		Calendar cal = Calendar.getInstance();
		Calendar cal2 = Calendar.getInstance();
		
		
		cal.setTime(biggerDate);
		cal2.setTime(lesserDate);
		
		return (cal.get(Calendar.YEAR) - cal2.get(Calendar.YEAR))*12 + cal.get(Calendar.MONTH) - cal2.get(Calendar.MONTH);
		

	}
	
	
	public static Date addYearDate(Date myDate, int incrementYear)
	{
		Date chDate = myDate;
		
		SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
		Calendar c = Calendar.getInstance();
		c.setTime(chDate);
		c.add(Calendar.YEAR, incrementYear); 
		return c.getTime();  
	}

}
