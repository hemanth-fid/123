package org.ifc.idocs.migration;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;

import lotus.domino.Database;
import lotus.domino.DateTime;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;

import org.ifc.idocs.migration.common.AppConfig;
import org.ifc.idocs.migration.common.DomdocRepository;
import org.ifc.idocs.migration.common.DomdocRepositoryDescriptor;
import org.ifc.idocs.migration.common.GetFolderSize;
import org.ifc.idocs.migration.extract.AsposeUtilities;
import org.ifc.idocs.migration.extract.DBConnection;
import org.ifc.idocs.migration.extract.Discussion;
import org.ifc.idocs.migration.extract.DomdocDocument;
import org.ifc.idocs.migration.extract.DomdocFolder;
import org.ifc.idocs.migration.extract.LogHelper;
import org.ifc.idocs.migration.extract.NotesSession;
import org.ifc.idocs.migration.extract.TempDb;
import org.ifc.idocs.migration.transform.IFCNAB;
import org.ifc.idocs.migration.transform.WBNAB;

/**
 * @author SPankajamsadanan
 * @see ExtractDocuments - extracts all sort of documents from lotus notes database
 *
 */
public class ExtractDocuments extends ExtractionReport {

	private static String skipMsg;
//	private static boolean deltaRun = false;
	private static Calendar calender = null;
	private static DateTime cutOffDate = null;
	private static Database parentDatabse = null;
	
	private DomdocRepository domdoc = null;
	private DomdocRepositoryDescriptor repo = null;
	private AppConfig config = AppConfig.getInstance();
	private Logger exportDocLogger = LogHelper.getLogger(ExtractDocuments.class);
	private String folderQuery = null, documentQuery1 = null, foldermanPath = null;
	private String displayPath = null, documentQuery = null, cntry = null, docid = null, skipReason = "", exportPath = "";
	private long extractionTime = 0, discussionTime = 0;
	private boolean utilityIdFlag = false, checkedOut = false, inWorkflow = false;
	private ArrayList<String> skipList = new ArrayList<String>();
	
	/**
	 * Constructor for ExtractDocuments
	 */
	public ExtractDocuments() {
		migSkipDocUniqSet.clear();
		skipDocUniqueIdSet.clear();
		migrationSkippedDocumentList.clear();
		calender = Calendar.getInstance();
		long startTime = calender.getTimeInMillis(); 
		
		String extractionQuery = null;

		try{
			extractionQuery = config.getString("filters.extractioncriteriacode");	//retrieving query string from extraction_criteria table			
			exportDocLogger.warning("EXTRACTION CRITERIA ID = " + extractionQuery );
			String [] extCriteria = extractionQuery .split(";");
			String server = config.getString("repository.server");

			for(int k = 0; k < extCriteria.length; k++){
				extractionId = extCriteria[k];
				exportDocLogger.warning("Extraction id = " + extractionId);

				criteriaCount = 0;
				foldermanPath = config.getString("repository.foldermanPath");
				
				repo = new DomdocRepositoryDescriptor("", "", server, foldermanPath);
				domdoc = new DomdocRepository(repo);
				
				String[] extInfo = DBConnection.getExtractionInfo(extractionId);	//getting extraction query-string from database
				boolean invalidResultSet = true;
				try{
					if(extInfo != null){
						folderQuery = extInfo[0];
						documentQuery1 = extInfo[1];
						region = extInfo[2];
						cntry = extInfo[3];
						invalidResultSet = extInfo[4].equals("false") ? false : true;
					}
				}catch(NullPointerException ne){
					exportDocLogger.warning("Please provide a valid Extraction Criteria in config.xml.");
					System.exit(0);
				}
				if(invalidResultSet){
					exportDocLogger.warning("Invalid Extraction Criteria. Please check config.xml file");
					System.exit(0);
				}
				if (cntry.length() > 3){ // extracts the country name (IND / BRA) from folder query value if query contains more inputs (COUNTRY_NAME_CODE='BRA' & project_id = '9999')
					cntry = cntry.substring(0, 3);
				}

				String commonPath = config.getString("export.path") + cntry + "\\";
				if(extractionId.contains("PRJ")){
					commonPath += "Project\\";
				}else if(extractionId.contains("PTR")){
					commonPath += "Partner\\";
				}
				
				File theDir = new File(commonPath);
				if (!theDir.exists()){
					theDir.mkdirs();
				}

				if(skipExtractedDocs){
					utilityId = DBConnection.getExtractiontUtilityId(extractionId);
					WorkflowAuditTrial.workflowMap.put("utilityId",utilityId);
					extractedDocuments = DBConnection.getToBeSkippedDocuments(region,utilityId);
					alreadySkippedDocsSet = DBConnection.alreadySkippedDocuments(utilityId);
				}else{
					if(utilityIdFlag){ // Multiple log files will be created when a new extraction criteria code exists
						ExportUtilityMain.getNewUtilityId();
						LogHelper.loggerMap.put("loggerMap",null);
					}
					utilityId = WorkflowAuditTrial.workflowMap.get("utilityId");
				}
				exportDocLogger.warning("  utilityId= " + utilityId);
				
//				TODO- Uncomment hardcoded folderquery values if any
//				documentQuery1="DocID='1868A20F1D02F980852573000064ADD8'";// 27367 ERROR
//				folderQuery = "COUNTRY_NAME_CODE='IND' & Project_id='11442'";
									
				exportPath = commonPath + utilityId + "\\"; 	//include extraction utility run time ID to the path
				displayPath = commonPath + utilityId;
				exportDocLogger.warning("Display path = " + displayPath);

				if(!skipExtractedDocs){
					DBConnection.updateStartSummary(utilityId, extractionId, displayPath);	//updating extraction utility info
				}else{
					DBConnection.updateEndSummary(utilityId,criteriaCount);
				}
				
				exportDocLogger.info("start summary updated");
				errorDocuments = DBConnection.getErrorDocuments(extractionId);
				reportUtilId = DBConnection.updateReportUtilityMap(utilityId,extractionId);
				folderQuery = folderQuery.trim();
				String[]  splits = folderQuery.split(" & ");
				String countryName = splits[0], projectId = null;
				ArrayList<String>  projectsIds = new ArrayList<String>();
				if(splits.length > 1){
					String[]  splits1 = splits[1].split("'");
					projectId = splits1[0];
					int j = 0;
					for(int i=1; i<splits1.length; i++){
						//checking doc query
						if(splits1.length>2){
							if (documentQuery1!=null){ 
								exportDocLogger.warning("MULTIPLE PROJECTS EXTRACTION SHOULD NOT HAVE DOCUMENT_QUERY ENTRIES ");
								exportDocLogger.warning("PLEASE REMOVE DOCUMENT_QUERY_TEXT FROM TABLE & TRY AGAIN");
								System.exit(1);
							}}
						//end of doc query check
						if(!splits1[i].contains(",")){
							projectsIds.add(splits1[i]);
							j++;
						}
					}
					for(String pid : projectsIds){
						folderQuery = countryName + " & " + projectId + "'" + pid + "'";
						exportDocLogger.info(folderQuery);
						extractionDocsAndProjects(folderQuery, exportPath);
					}//end of query split loop
				}else{
					folderQuery = countryName;
					extractionDocsAndProjects(folderQuery, exportPath);
				}
				exportDocLogger.warning("one extraction criteria completed.next is discussion");

				calender = Calendar.getInstance();
				long st = calender.getTimeInMillis(); 
				
//				TODO - uncomment below discussion extraction
				DBConnection.updateExtractionUtilityStart(utilityId);	//updating discussion extraction start status
				Discussion.extractDocuments(region,cntry,displayPath,utilityId);	// Extract documents
				DBConnection.updateExtractionUtilityEnd(utilityId);	//	updating discussion extraction end status
				domdoc.recycle();
				
				calender = Calendar.getInstance();
				long et = calender.getTimeInMillis();
				discussionTime = discussionTime + (et - st);
				
				exportDocLogger.warning("Extraction Utility ID is : " + utilityId + " ~ Total number of documents for criteria " + extractionId + " ~ Count : " + criteriaCount);
				DBConnection.updateEndSummary(utilityId,(criteriaCount+extractedDocuments.size()));
				DBConnection.updateRegionTableExtractionSuccessfulField(utilityId,region, "N");
				saveListToDatabse();
				skipList.addAll(DBConnection.getSkippedDocsCount(utilityId));
			}
			
			//multiple criteria loop ends here
		}catch (RuntimeException ioe){	//loop to finish multiple project id extraction
			exportDocLogger.log(Level.WARNING,"Please ensure valid inputs are provided in config.xml. RuntimeException", ioe);
			System.exit(0);
		}
		catch(NotesException e){
			exportDocLogger.log(Level.WARNING,"NotesError ~ " + e.id + " ~ " + e.text, e);
			System.exit(0);
		}
		catch (Exception e){
			exportDocLogger.log(Level.WARNING,"Initialization error", e);
			System.exit(0);
		}
		finally {

			String folderSize = GetFolderSize.getFolderSize(displayPath);
			String[] totalFolderSize = folderSize.split("#");
			
			long totalSkipped = 0, longVal = 0, lastRunCount = 0;
			String[] skipCount = null;
			
			for(String skip : skipList){
				skipCount = skip.split("Documents : ");
				totalSkipped += Long.parseLong(skipCount[1]); 
			}			

//			int failedCount = DBConnection.getMigrationFailedCount(utilityId,region);
//			versionCount = versionCount - failedCount;
			long totalDocsWithVer = exportCount + versionCount;
			printProcessRunTime(startTime, "Total time taken for extraction : "); 
			exportDocLogger.info("Extraction Time only : " + extractionTime);
			exportDocLogger.info("Discussion Time only : " + discussionTime);

			exportDocLogger.warning("================== Extraction Summary =========================");
			exportDocLogger.warning("Complete Extraction Criteria : " + extractionQuery);
			exportDocLogger.warning(foldermanPath + " ~ " + extractionId );
			exportDocLogger.warning("Last Extraction Utility ID is : " + utilityId);
			exportDocLogger.warning("Last Export completed for " + extractionId + " = " + folderQuery);
			exportDocLogger.warning("Total number of processed documents (A = B + C) = " + totalProcessedDocCount);
			if(skipExtractedDocs){
				lastRunCount = extractedDocuments.size();
				exportDocLogger.warning("Total number of documents found in Current run (D) = " + (totalDocsWithVer - extractedDocuments.size()));
				exportDocLogger.warning("Total number of documents found in Last run( (E) = " + extractedDocuments.size());					
				DBConnection.updateExtractionSummary(extractionQuery, utilityId, folderQuery, totalProcessedDocCount, longVal, longVal,
						(totalDocsWithVer - extractedDocuments.size()), lastRunCount, totalDocsWithVer, totalSkipped, totalFolderSize[0], totalFolderSize[1]);

			}else{
				exportDocLogger.warning("Total number of unique documents found (D) = " + exportCount);
				exportDocLogger.warning("Total number of version documents found (E) = " + versionCount);
				DBConnection.updateExtractionSummary(extractionQuery, utilityId, folderQuery, totalProcessedDocCount, exportCount, versionCount,
						longVal, longVal, totalDocsWithVer, totalSkipped, totalFolderSize[0], totalFolderSize[1]);

			}
			exportDocLogger.warning("Total number of Extracted documents (including versions) (B = D + E) = " + totalDocsWithVer);

			for(String skip : skipList){
				exportDocLogger.warning(skip);
			}			
			exportDocLogger.warning("Total number of skipped documents (C) = " + totalSkipped );
			exportDocLogger.warning("Total number of Duplicate documents Skipped = " + duplicateDocCounter );
			
			exportDocLogger.warning("=================================================================");			
			
			TempDb.recycle();
			IFCNAB.recycle();
			WBNAB.recycle();
			NotesSession.terminate();
			System.gc();
			exportDocLogger.warning("Extraction Completed Successfully...!");

//			TODO remove aspose comment secion
			AsposeUtilities au = new AsposeUtilities();
			au.updateCustomProperties(exportPath, cntry, utilityId);
		}

	}// ExtractDocument


	private void printProcessRunTime(long startTime, String msg) {
		calender = Calendar.getInstance();
		long endTime = calender.getTimeInMillis();
		long totalSeconds = endTime - startTime;
		exportDocLogger.warning(msg + " (in milli seconds) : " + totalSeconds);
		totalSeconds = totalSeconds / 1000;
		exportDocLogger.warning(msg + " (in seconds) : " + totalSeconds);
		exportDocLogger.warning(msg + " (in minutes) : " + totalSeconds / 60 + ":" + totalSeconds % 60);
	}

	/**
	 * extractionDocsAndProjects method extracts all projects & documents from lotus notes database
	 * @param folderQuery
	 * @param path
	 * @throws Exception
	 * @return void
	 */
	private void extractionDocsAndProjects(String folderQuery, String path) throws Exception {
		exportDocLogger.info("extractionDocsAndProjects folder query = " + folderQuery);
		DocumentCollection folders = domdoc.getFoldermanDb().findFolders(folderQuery);
		exportDocLogger.warning("Count of entries in Folderman Database = " + folders.getCount());
		Document nfolder = folders.getFirstDocument();
		Document tempDoc = null;
		DomdocFolder folder = null;

		//		splitting of multiple documents
		ArrayList<String> docIds = new ArrayList<String>();
		if(documentQuery1 != null){
			String []ids = documentQuery1.split("'");
			if (ids.length > 1){
				for( int p=1; p < ids.length; p++){
					if(!ids[p].contains(",")){
						docIds.add(ids[p]);
					}
				}
			}
		}

		documentQuery = "!(IsWIPVer='1')";	//ensuring that document is not checked out
		while (nfolder != null) {				
			try {
				folder = new DomdocFolder(domdoc, nfolder);
				String docExportPath = path + folder.getMetadata().getFileroomId();

				folderTypeCode = (nfolder.getItemValueString("FileRoom")).toUpperCase();//case is not uniform in documents.So converting all to upper case
				if (folderTypeCode.equals("MISCELLANEOUS")){folderTypeCode = "COUNTRY";}
				if ((nfolder.getItemValueString("FileRoom")).toLowerCase().equals("projects")) folderValueCode = nfolder.getItemValueString("Project_id");
				if ((nfolder.getItemValueString("FileRoom")).toLowerCase().equals("institutions")) folderValueCode = nfolder.getItemValueString("Institution_Nbr");
				if ((nfolder.getItemValueString("FileRoom")).toLowerCase().equals("miscellaneous")) folderValueCode = nfolder.getItemValueString("Country_Name_Code");
				
				if(docIds.size() > 0){
					for(String dids : docIds ){
						documentQuery = "!(IsWIPVer='1')";	//ensuring that document is not checked out
						documentQuery1 = "DocID = '" + dids + "'";
						if (documentQuery1 != null){
							documentQuery = documentQuery + " & " + documentQuery1;
							documentExtraction(folder, nfolder, docExportPath);
						}
					}
				}else{
					documentExtraction(folder, nfolder, docExportPath);
				}
			}catch (NullPointerException ne) {	
				exportDocLogger.warning("NullPointerException");
				exportDocLogger.log(Level.WARNING,"NullPointerException-", ne);

			}catch (NotesException ne) {	
				exportDocLogger.warning("NotesException in ExtractDocuments-#~"+ne.id+"~"+ne.text);
				ne.printStackTrace();
				exportDocLogger.log(Level.WARNING,"NotesException-", ne);
			}
			catch (Exception e) {	
				exportDocLogger.warning("Exception in ExtractDocuments #");
				e.printStackTrace();
				exportDocLogger.log(Level.WARNING,"Exception-", e);
			}
			tempDoc = folders.getNextDocument();
			nfolder.recycle();
			nfolder = tempDoc;
			
		} //end of while loop
		
		saveListToDatabse();
		utilityIdFlag = true;

		if (folder != null ){
			folder.recycle();
		}
		if (folders != null){
			folders.recycle();
		}
	}

	private void saveListToDatabse() {
		if(regionList.size() > 0){
			DBConnection.updateRegion(regionList,region,DBConnection.getBatchConnection());
			regionList.clear();						
		}
		if(migrationSkippedDocumentList.size() > 0){
			DBConnection.saveSkippedDocuments(migrationSkippedDocumentList,DBConnection.getBatchConnection());
			migrationSkippedDocumentList.clear();
		}
		
//		Report code start
//		exportDocLogger.warning("######## going to save - saveListToDatabse");
//		saveExtractionReportRecords();
//		Report code end

		System.gc();
	}
	
	/** 
	 * documentExtraction method deals with document extraction
	 * @param folder
	 * @param nfolder
	 * @param docExportPath
	 * @throws NotesException
	 * @return void
	 * @throws IOException 
	 * @throws SQLException 
	 */
	private void documentExtraction(DomdocFolder folder, Document nfolder, String docExportPath) throws NotesException, SQLException, IOException {

		Document newNdoc = null, ndoc = null;
		DocumentCollection documents = null;
		try{
			documents = folder.findDocuments(documentQuery, cutOffDate);
			int doc_cnt = documents.getCount();
			exportDocLogger.warning("Documents inside folder ~ " + nfolder.getItemValueString("title") + " = " + doc_cnt);
			ndoc = documents.getFirstDocument();
			parentDatabse = null;
		}
		catch(NotesException ne){
			exportDocLogger.warning(" Invalid Replica ID Found - "+nfolder.getItemValueString("documentdbid"));
			exportDocLogger.log(Level.WARNING,"documentExtraction Exception-", ne);
			listSkipDatabase(nfolder.getItemValueString("documentdbid"),nfolder.getItemValueString("filecabinet"),
			nfolder.getItemValueString("fileroom"),"Invalid Replica ID Found" ,"ER_019") ;
		}

//		Report code start
//		isQualifiedDoc = true; documentsSize = 0.0; docLevelSize = 0.0; docLvlSize = 0.0; level1DocCount = 0; docCount = 0; 
//		Report code end

		calender = Calendar.getInstance();
		long st = calender.getTimeInMillis(); 

		while (ndoc != null) {
			try{
				if(parentDatabse == null){
					parentDatabse = ndoc.getParentDatabase();
				}
			}catch(NotesException ne){
				exportDocLogger.log(Level.WARNING, "NotesException : Unable to open Parent Database database", ne);
			}

			try { 
				totalProcessedDocCount++;
				if(!skipDocUniqueIdSet.contains(ndoc.getUniversalID())){
				
					newNdoc = documents.getNextDocument(ndoc);	// for recycling ndoc, assigning the next ndoc to a variable
					boolean skipDocument = false;
					Document latest;					
					docid = ndoc.getItemValueString("docid");
					String unid = ndoc.getUniversalID();
					exportDocLogger.warning("Extracting : DocID = " + docid + " ~ Doc Unique ID = " + unid);
					skipDocUniqueIdSet.add(ndoc.getUniversalID());
					int skipVal = toBeSkippedDoc(unid, docid, folderValueCode);
					if(skipVal == 0){		
						if (ndoc.getItemValueString("isCurrentVer").equals("1")) {
							latest = ndoc;
						} else {
							latest = parentDatabse.getView("IFCLatestDraftByDocID").getDocumentByKey(docid);
							if (latest == null) {
								latest = parentDatabse.getView("IFCLatestByDocID").getDocumentByKey(docid);
							}
						}
						if (latest == null) {
							skipDocument = true;
							listSkipDocuments(ndoc, docid, "Could not find latest document by docid.", "ER_018");
						}
						if (!skipDocument) {
							try{
								checkedOut = latest.hasItem("WIPUNID");
								inWorkflow = latest.hasItem("WorkflowStatus");
								
								if(checkedOut && inWorkflow && latest.getItemValueString("WIPUNID").length() > 0 && latest.getItemValueString("WorkflowStatus").matches("[124]")){
									skipDocument = true;
									exportDocLogger.warning("Document " + docid + " is checked out and in workflow, skipping...");
									listSkipDocuments(ndoc, docid, "Checked Out & In Workflow", "ER_045");	
								}
								else if(checkedOut && latest.getItemValueString("WIPUNID").length() > 0){	
									skipDocument = true;
									exportDocLogger.warning("Document " + docid + " is checked out, skipping...");
									listSkipDocuments(ndoc, docid, "Checked Out - WIPUNID doc ", "ER_002");							
								}else if(inWorkflow && latest.getItemValueString("WorkflowStatus").matches("[124]")) {
									skipDocument = true;
									exportDocLogger.warning("Document " + docid + " is In workflow, skipping...");	
									listSkipDocuments(ndoc, docid, "In Workflow", "ER_003");
								}
							}catch(NullPointerException ne){
								skipDocument = true;
								exportDocLogger.warning("DocID = " + docid +" ~ " + skipMsg);
								listSkipDocuments(ndoc, docid, "WIPUNID / WorkflowStatus attribute not found", "ER_031");
							}
						}
						if (!skipDocument) {
							new File(docExportPath).mkdirs();
							DomdocDocument doc = new DomdocDocument(ndoc);	//process current document
							if(doc != null){
								doc.export(docExportPath);
							}
							if(!migSkipDocUniqSet.contains(ndoc.getUniversalID())){
								addToRegionList(utilityId, ndoc,region, "Y");
								
							}							
							exportDocLogger.warning("DocID = " + docid + " ~ Doc Unique ID = " + unid + " ~ Title = " + nfolder.getItemValueString("TITLE") + " ~ exportCount = " 
									+ exportCount + " ~ Total Processed Doc Count = " + totalProcessedDocCount + " ~ "	+ ndoc.getParentDatabase().getTitle() + " ~ exported successfully" );
							
							doc.recycle();
						}
						if((regionList.size() >= 1000 || migrationSkippedDocumentList.size() >= 1000)){
							saveListToDatabse();
						}
					}else if(skipVal == 1){
						skipReason = "Error Document - is already added in Failure Document Report Table";
						listSkipDocuments(ndoc, docid, skipReason, "ER_044");
						exportDocLogger.warning("DocID = " + docid + " ~ Doc Unique ID = " + unid + " ~ Skip Reson : " + skipReason);
					}else{
						exportDocLogger.warning("DocID = " + docid + " ~ Already extracted once. ~ Total Processed Doc Count = " + totalProcessedDocCount);
					}
					
				}else{
					duplicateDocCounter++;
					exportDocLogger.warning("Duplicate Document ~ Document id : " + docid + " ~ Unique Document Id : " + ndoc.getUniversalID() +" skipping...");	
				}
			} 
			catch (NotesException e){
//				addToRegionList(utilityId, ndoc,region, "N");
				errorCode = errorCode.length() > 0 ? errorCode : "ER_001";
				errorMsg = errorMsg.length() > 0 ? errorMsg : "Doc Error - Exception";
				exportDocLogger.warning(ndoc.getItemValueString("DocID") + " ~ has error ~ " + e.id + " ~ " + e.text);
				listSkipDocuments(ndoc, ndoc.getItemValueString("DocID"), errorMsg, errorCode);
			} 
			catch (Exception e) {
//				addToRegionList(utilityId, ndoc,region, "N");
				errorCode = errorCode.length() > 0 ? errorCode : "ER_001";
				errorMsg = errorMsg.length() > 0 ? errorMsg : "Doc Error - Exception";
				exportDocLogger.warning(("Error exporting document ~"+docid+" ~ " + ndoc.getUniversalID() + " from database " + parentDatabse.getTitle()+nfolder.getItemValueString("TITLE")));
 				listSkipDocuments(ndoc, ndoc.getItemValueString("DocID"), errorMsg, errorCode);
			}
			ndoc.recycle();
			ndoc = newNdoc;
		}
		
//		Report code start
//		documentAndDetailedReport(nfolder, false);
//		Report code end

		if (documents != null ){
		documents.recycle();}
		calender = Calendar.getInstance();
		long et = calender.getTimeInMillis();
		extractionTime = extractionTime + (et - st);
	}

	private int toBeSkippedDoc(String unid, String docid, String folderValueCode) {
		int skipErrorNo = 0;
		skipErrorNo = (errorDocuments.contains(unid + "_" + docid)) ? 1 : 0;
		if(skipErrorNo == 0){
			if(extractedDocuments.contains(folderValueCode + "_" + docid)){
				skipErrorNo = 2;
				exportCount++;
			}else{
				skipErrorNo = 0;
			}
		}
		return skipErrorNo;
	}
}