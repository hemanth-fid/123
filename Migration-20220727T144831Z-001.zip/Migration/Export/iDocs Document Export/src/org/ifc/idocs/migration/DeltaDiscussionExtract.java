package org.ifc.idocs.migration;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import lotus.domino.Database;
import lotus.domino.DateTime;
import lotus.domino.DbDirectory;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.Session;
import lotus.domino.View;

import org.ifc.idocs.migration.common.AppConfig;
import org.ifc.idocs.migration.extract.DBConnection;
import org.ifc.idocs.migration.extract.LogHelper;
import org.ifc.idocs.migration.extract.NotesSession;
import org.ifc.idocs.migration.extract.TempDb;
import org.ifc.idocs.migration.transform.IFCNAB;
import org.ifc.idocs.migration.transform.WBNAB;

public class DeltaDiscussionExtract{

	@SuppressWarnings("unused")
	private static String folderQuery = null;
	private static String region = null, deltaDiscDocId=null;
	static String country = null;
	static String replica_code = null;
	static java.sql.Date replica_date = null;

	@SuppressWarnings("unchecked")
	public DeltaDiscussionExtract() throws Exception {

		AppConfig config  =  AppConfig.getInstance();
		Logger exportDocLogger  =  LogHelper.getLogger(ExportUtilityMain.class);
		//exportDocLogger.info("iDocs- Discussion Document Extraction Started");
		Set<String> docIdSet = new HashSet<String>();
		try {
			String extractionQuery = config.getString("filters.extractioncriteriacode");	//retrieving query string from extraction_criteria table			
			exportDocLogger.warning("EXTRACTION CRITERIA ID = " + extractionQuery );
			String [] extCriteria = extractionQuery .split(";");
			String server = config.getString("repository.server");
			for(int k = 0; k < extCriteria.length; k++){
				String extractionId = extCriteria[k];
				System.out.println("extractionId="+extractionId);
				
				String[] extInfo = DBConnection.getExtractionInfo(extractionId);	//getting extraction query-string from database
				if(extInfo != null){
					folderQuery=extInfo[0];
					region = extInfo[2];
					country = extInfo[3];
					replica_code = extInfo[5];
				}
				
				System.out.println("country="+country);
				if (country.length() > 3){ // extracts the country name (IND / BRA) from folder query value if query contains more inputs (COUNTRY_NAME_CODE='BRA' & project_id = '9999')
					country = country.substring(0, 3);
				}
				ResultSet rs1=DBConnection.getReplicaDate(replica_code);
				try {
					while(rs1.next()){
						replica_date = rs1.getDate("REPLICATION_START_DATE");
					}
					rs1.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
					exportDocLogger.log(Level.SEVERE, "DeltaDiscussionExtract ~ getReplicaDate ~ SQLException", e1);
				} 
				java.util.Date date = new java.util.Date(replica_date.getTime());
				DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
				String date1 = formatter.format(date);
				DateTime date2 = null;
				try {
					Session session =  NotesSession.getInstance();
					date2 = session.createDateTime(date1);
				} catch(Exception e) {
					e.printStackTrace();
					exportDocLogger.log(Level.SEVERE, "DeltaDiscussionExtract ~ Getting replica date ~ Exception", e);
				}
				
				exportDocLogger.warning("Cut off for discussion date = " + date2);
				String dbReplicaId;
				Database binderDb = null;
				String libraryDbPath = config.getString("repository.libPath");
				DbDirectory dbdir  =  NotesSession.getInstance().getDbDirectory(server);
				//exportDocLogger.info("Lib = " + libraryDbPath);
				Database Lib = dbdir.openDatabase(libraryDbPath);
				View mainView  =  Lib.getView("vaMainView");	//getting the main view from lib database
				String realRegion=region;
				if (realRegion.equals("EUROPE")){
					realRegion="ECA";
				}
				DocumentCollection docCollection = mainView.getAllDocumentsByKey(realRegion);
				exportDocLogger.warning("Count of binder documents matching region ~ " + region + " = " + docCollection.getCount());
				Document doc = docCollection.getFirstDocument();
				Integer docCounter = 0;
				Document nextDoc=null; 
				while (doc != null){
					
					String title = doc.getItemValueString("DbTitle");
					if (title.equals(country)){
						dbReplicaId = doc.getItemValueString("BinderDBReplicaID");	//getting replica ID of target binder DB from filecabinet
						binderDb = dbdir.openDatabaseByReplicaID(dbReplicaId);	//opening the binder db
						View binderView = binderDb.getView("vaServerProfileList");
						Document binderProfile = binderView.getFirstDocument();
						Vector documentDb = binderProfile.getItemValue("ListOfDocDBs");
						Integer docDbCount = documentDb.size();	//getting the number of document databases for this binder
						exportDocLogger.warning(docDbCount + " ~ document databases ~ " + documentDb + " ~ found for region ~ " + region + " ~ country ~ " + country);
						docCounter = 0;
						
						while(docCounter < docDbCount){
							Object document = documentDb.elementAt(docCounter);
							String sourceName = (String) document;
							Database sourceDb = dbdir.openDatabase(sourceName);
							StringBuffer searchFormulaStringBuffer = new StringBuffer("Form='faMainTopic'|Form='faResponse'|Form='faResponseToResponse'");
							String searchFormula = searchFormulaStringBuffer.toString();           
							DocumentCollection docColl = sourceDb.search(searchFormula,date2);//searching document database with above query
							Integer docCount = docColl.getCount();
							docCounter++;
							exportDocLogger.warning(docCount+" ~ matching documents found in the cutoff date provided");
							Document doc1 = docColl.getFirstDocument();

							while(doc1 != null){
								deltaDiscDocId = doc1.getItemValueString("DocID");
								docIdSet.add(deltaDiscDocId);
								doc1 = docColl.getNextDocument();
							}							
							sourceDb.recycle();
							docColl.recycle();
						}						
						documentDb.clear();
						binderDb.recycle();
						binderView.recycle();
						binderProfile.recycle();
					}
					else{
						exportDocLogger.warning("No matching country documents found ~ " + region + " ~ country ~ " + country+"~where Title="+title);
					}
					nextDoc=docCollection.getNextDocument(doc);
					doc.recycle();
					doc=nextDoc;
				}
				
				Lib.recycle();
				dbdir.recycle();
				mainView.recycle();				
				docCollection.recycle();				
				if(docIdSet.size() > 0){
					new DiscussionDocDelta(docIdSet);
				}
			}//loop ending for extraction criteria check

		}catch (NotesException e){
			e.printStackTrace();
			exportDocLogger.log(Level.SEVERE, "DeltaDiscussionExtract ~ NotesException", e);
			NotesSession.terminate();
		}catch (Exception e){
			exportDocLogger.log(Level.SEVERE, "DeltaDiscussionExtract ~ NotesException", e);
			NotesSession.terminate();
		}finally {
			TempDb.recycle();
			IFCNAB.recycle();
			WBNAB.recycle();
			NotesSession.terminate();
			exportDocLogger.warning("Completed");
		}

	}	
}

