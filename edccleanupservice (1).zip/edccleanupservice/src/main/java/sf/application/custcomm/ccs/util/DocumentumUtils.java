/***************************************************************************
 * State Farm
 * Version Template: 2012
 *
 * File Name: DocumentumUtils.java
 *
 * Version     ChgDate          Author           Comments
 * ________   __________       ________         ___________
 * 1.0        05/31/2013         t7p9        Initial Creation 
 *
 ***************************************************************************/
package sf.application.custcomm.ccs.util;

import java.io.IOException;
import java.util.Map;



import sf.application.custcomm.ccs.constants.ExceptionConstants;
import sf.application.custcomm.ccs.constants.CleanUpConstants;
import sf.application.custcomm.ccs.exceptions.CleanUpServiceException;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.server.impl.method.common.SessionManagerManager;
import com.emciig.utils.MiscUtils;
import com.emciig.utils.SessionUtils;

/**
 * <i>DocumentumUtils</i> have the documentum utility methods that are being
 * used across the export process.
 * 
 */
public final class DocumentumUtils {

	/**
	 * Construtor
	 */
	private DocumentumUtils() {

	}

	/**
	 * Retrieves a Documentum active repository session
	 * 
	 * @param params
	 *            repository name user credentials in a map.
	 * @return IDfSession active repository session
	 * @throws ExportProcessException
	 *             Custom Exception used within the export services module
	 */
	public static IDfSession getSession(Map<String, String> params) throws CleanUpServiceException {
		if(DfLogger.isTraceEnabled(DocumentumUtils.class)) {
			DfLogger.trace(DocumentumUtils.class, "Method getSession() entry", null, null);
		}
		try {
			if(DfLogger.isTraceEnabled(DocumentumUtils.class)) {
				DfLogger.trace(DocumentumUtils.class, "Method getSession() exit", null, null);
			}
			
			return SessionManagerManager.getSession(params.get(CleanUpConstants.DOCBASE),params.get(CleanUpConstants.USERNAME),null);
		
		} catch(DfException dfException) {
			throw new CleanUpServiceException(ExceptionConstants.UNABLE_TO_GET_SESSION, dfException);
		}
		catch(Exception Exception) {
			throw new CleanUpServiceException(ExceptionConstants.UNABLE_TO_GET_SESSION, Exception);
		}
	}
	
	

	/**
	 * It create and returns a new SessionUtilsObject
	 * 
	 * @return SessionUtils
	 */
	public static SessionUtils getSessionUtilsObject()
	{
		return new SessionUtils();
	}
	
	

	/**
	 * Reads the property file and returns the map
	 * 
	 * @param propertiesFile
	 *            Name of the properties file name
	 * @return Map Holds the key value pairs got from properties file
	 * @throws ExportProcessException
	 *             Custom Exception used within the export services module
	 */
	public static Map<String, String> getPropertiesMap(String propertiesFile) throws CleanUpServiceException {

		if(DfLogger.isTraceEnabled(DocumentumUtils.class)) {
			DfLogger.trace(DocumentumUtils.class, "Method getPropertiesMap() entry", null, null);
		}
		try {
			if(DfLogger.isTraceEnabled(DocumentumUtils.class)) {
				DfLogger.trace(DocumentumUtils.class, "Method getPropertiesMap() exit", null, null);
			}
			return MiscUtils.getPropertiesArrayList(propertiesFile);
		} catch(IOException ioException) {
			throw new CleanUpServiceException(ExceptionConstants.ERROR_IN_READING_PROPERTIES, ioException);
		}
	}


	
	
}
