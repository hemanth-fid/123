package org.ifc.idocs.migration.helper;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.owasp.esapi.ESAPI;
import org.owasp.esapi.errors.EncryptionException;

import com.documentum.fc.client.DfAuthenticationException;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.DfIdentityException;
import com.documentum.fc.client.DfPrincipalException;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.fc.tools.RegistryPasswordUtils;

public class GetDocBaseAttrDetails_3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String strDocbase = "ifcecmqaidocs";
		String strUserName = "ifcdocssrvqa";
		String strPassword = "Ifcd0c$Web@dm";
		
		try {
			IDfSessionManager sessionMgr = getSessionMgr(strUserName, ESAPI.encryptor().encrypt(strPassword), strDocbase);
			IDfSession dfSession = sessionMgr.getSession(strDocbase);
			System.out.println("Login User Name::"+dfSession.getLoginUserName());
			

					 
					String countryCode = "CHA";
					ArrayList<String> docRObjectIDs = fetchAdvisoryProjects(dfSession, countryCode);
					for(int k=0;k<docRObjectIDs.size();k++){
						String r_object_id = docRObjectIDs.get(k);
						System.out.println("Processing Document ID::"+r_object_id+"::Cnt::"+k);
						IDfSysObject document = (IDfSysObject)dfSession.getObject(new DfId(r_object_id));
						  if(document.isImmutable()){
							  System.out.println("Document immutable so reset");
							  document.setBoolean("r_immutable_flag", false);
						  }
						  if(document.isCheckedOut()){
							  System.out.println("Document is checked out");
						  }else{
							  document.setString("sec_classification_code", "");
							  document.setString("is_migrated", "T");
							  document.save();
						  }
					}
					  /*System.out.println("Processing Legacy Document ID::"+currentID+"::Cnt::"+i++);
					  String docBaseQry = "Select r_object_id,orig_doc_id from idocs_document(all) where country_code='EGT' and acl_name like 'idocs_09%' and orig_doc_id<>' '";
					  IDfCollection collection = null;
					  IDfQuery query = new DfQuery();
					  query.setDQL(docBaseQry);
					  collection = query.execute(dfSession, DfQuery.EXECREAD_QUERY);
					  while(collection.next()){
						  i++;
						  String r_object_id = collection.getString("r_object_id");
						  String origDocID = collection.getString("orig_doc_id");
						  System.out.println("Processing Legacy Document ID::"+origDocID+"::Cnt::"+i);*/
						  /*IDfDocument document = (IDfDocument)dfSession.getObjectByQualification("idocs_document where r_object_id='"+r_object_id+"'");
						  if(document != null && document.getBoolean("r_immutable_flag")){
							  document.setBoolean("r_immutable_flag", false);
						  }
						  if(document != null && document.getString("r_lock_owner")!=""){
							  System.out.println("Document is checked out");
						  }else{
							  document.setString("sec_classification_code", "");
							  document.setString("is_migrated", "T");
							  document.save();
						  }*/
						  /*IDfSysObject document = (IDfSysObject)dfSession.getObject(new DfId(r_object_id));
						 
						  if(document.isImmutable()){
							  System.out.println("Document immutable so reset");
							  document.setBoolean("r_immutable_flag", false);
						  }
						  if(document.isCheckedOut()){
							  System.out.println("Document is checked out");
						  }else{
							  System.out.println("Document saving..."+i);
							  document.setString("sec_classification_code", "");
							  document.setString("is_migrated", "T");
							  document.save();
							  System.out.println("Document saved..."+i);
						  }*/
						  
					  /*}*/
			 
			  /*String file_name = "C:\\Users\\SVarikuti\\Desktop\\Get_all_doc_details.txt";
			  File file = new File(file_name);
			  
			  if (!file.createNewFile()) {
				  System.out.println("File already exists.");
				  System.exit(0);
			  } else {
				  FileWriter fstream = new FileWriter(file_name);
				  BufferedWriter out = new BufferedWriter(fstream);
				  int i=0;
				  String docBaseQry = "Select r_object_id,orig_doc_id,orig_doc_unique_id,country_code,project_id,is_custom_security,acl_name,sec_classification_code from idocs_project_doc(all) where country_code not in('"+countryCode+"')";
				  IDfCollection collection = null;
				  IDfQuery query = new DfQuery();
				  query.setDQL(docBaseQry);
				  collection = query.execute(dfSession, DfQuery.EXECREAD_QUERY);
				  while(collection.next()){
					  System.out.println("Total::"+i++);
					  out.write(collection.getString("r_object_id")+"\t"
							  	+collection.getString("orig_doc_id")+"\t"
							  		+collection.getString("orig_doc_unique_id")+"\t"
							  			+collection.getString("country_code")+"\t"
							  				+collection.getString("project_id")+"\t"
							  					+collection.getString("is_custom_security")+"\t"
							  						+collection.getString("acl_name")+"\t"
							  							+collection.getString("sec_classification_code"));
					  out.newLine();
				  }
				  out.close();
			  }*/
			 
			
			
			/*String file_name = "C:\\Users\\HAnuganti\\Desktop\\testing_3.txt";
			File file = new File(file_name);
			file.mkdirs();
			if(file.exists()){
				
				
				FileWriter fstream = new FileWriter(file_name);
				BufferedWriter out = new BufferedWriter(fstream);
				out.write("Hema"+"\t"+"Chandra"+"\n");
				out.write("asdfas"+"\t"+"asdfasdf"+"\n");
				out.close();
				 System.out.println("File created successfully.");
			}else{
				System.out.println("File already exists.");
				System.exit(0);
			}*/
			
				 
			
			 
			
			
			
			/*FileInputStream fstream = new FileInputStream("C:\\Users\\HAnuganti\\Desktop\\test.txt");
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			//Read File Line By Line
			while ((strLine = br.readLine()) != null) {
			  // Print the content on the console
			  System.out.println (strLine);
			}
			//Close the input stream
			in.close();*/
		}catch (EncryptionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DfIdentityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DfAuthenticationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DfPrincipalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DfServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DfException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	private static ArrayList<String> fetchAdvisoryProjects(IDfSession mySession, String countryCode) throws DfException{
		//String projCategory = "";
		
		String strQuery = "Select r_object_id from idocs_document(all) where country_code='"+countryCode+"' and acl_name like 'idocs_09%' and orig_doc_id<>' '";
		IDfCollection dfCollection = executeQuery(mySession, strQuery, IDfQuery.DF_READ_QUERY);
		//HashMap<String, String> projCategoryMap = new HashMap<String, String>(); 
		String docRObjID = "";
		ArrayList<String> objIDSArray = new ArrayList<String>();
		while (dfCollection.next()){
			docRObjID = dfCollection.getString("r_object_id");
			objIDSArray.add(docRObjID);
			//projCategoryMap.put(strProjectId, strProjectCategory);
		}
		
		if (dfCollection!=null)
			dfCollection.close();
		
		return objIDSArray;
	}
	
	protected static IDfCollection executeQuery(IDfSession dfSession, String strQuery, int queryType) throws DfException{
		IDfCollection dfCollection = null;
		IDfQuery dfQuery = new DfQuery();
		System.out.println("Utilities :: executeQuery() : strQuery : "+strQuery);
		dfQuery.setDQL(strQuery);
		dfCollection = dfQuery.execute(dfSession,queryType);
		return dfCollection;
	} // end of executeQuery()
	
	protected static IDfSessionManager getSessionMgr(String strUserName2,
			String strPassword2, String strDocbase2) {
		// TODO Auto-generated method stub

		IDfClient client;
		IDfSessionManager sMgr = null;
		RegistryPasswordUtils rpu = new RegistryPasswordUtils();
		try {
			client = DfClient.getLocalClient();
			sMgr = client.newSessionManager();
			IDfLoginInfo login = new DfLoginInfo();
			login.setUser(strUserName2);
//			login.setPassword(rpu.decrypt(strPassword2));
			login.setPassword(ESAPI.encryptor().decrypt(strPassword2));
			login.setDomain(null);
			sMgr.setIdentity(strDocbase2, login);
		} catch (DfException e) {
			e.printStackTrace();
		} catch (EncryptionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sMgr;
	}

}
