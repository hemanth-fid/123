/***************************************************************************
 * State Farm
 * Version Template: 2012
 *
 * File Name: FileOperationUtils.java
 *
 * Version     ChgDate          Author           Comments
 * ________   __________       ________         ___________
 * 1.0        06/01/2013         t7p9         Initial Creation 
 *
 ***************************************************************************/
package sf.application.custcomm.ccs.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.documentum.fc.common.DfLogger;

/**
 * <i> FileOperationUtils </i> class provides various functionalities to perform
 * file operations during the export process.
 * 
 */

public final class FileOperationUtils {

	/**
	 * Constructor
	 */

	private static final Logger LOGGER = DfLogger
			.getLogger(FileOperationUtils.class);

	private FileOperationUtils() {

	}

	public static void fileMove(String src, String target) {
		Path movefromPath = FileSystems.getDefault().getPath(src);
		Path targetPath = FileSystems.getDefault().getPath(target);
		try {
			Files.move(movefromPath, targetPath,
					StandardCopyOption.REPLACE_EXISTING);
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
		}
	}

	public static List<String> readFile(String fileName) {
		String line = null;
		List<String> records = new ArrayList<String>();
		BufferedReader bufferedReader = null;

		try {
			bufferedReader = new BufferedReader(new FileReader(fileName));

			while ((line = bufferedReader.readLine()) != null) {
				records.add(line);
			}
		} catch (Exception e) {

			LOGGER.error(e.getMessage(), e);
		} finally {

			try {

				bufferedReader.close();

			} catch (IOException e) {

				LOGGER.error(e.getMessage(), e);
			}
		}
		return records;
	}

	public static void createFolderstructure(Map<String, String> parameters) {

		String[] serverNames = CleanUpHelper.getServerNames(parameters);
		for (int i = 0; i < serverNames.length; i++) {
			File dropoffpath = new File("\\\\" + serverNames[i] + "\\"
					+ parameters.get("drive") + "$"
					+ parameters.get("edc_cleanup_folder_path")
					+ parameters.get("drop_off"));
			if (!dropoffpath.exists())
				dropoffpath.mkdirs();
			File readytoprocesspath = new File("\\\\" + serverNames[i] + "\\"
					+ parameters.get("drive") + "$"
					+ parameters.get("edc_cleanup_folder_path")
					+ parameters.get("ready_to_process"));
			if (!readytoprocesspath.exists())
				readytoprocesspath.mkdirs();
			File inprocesspath = new File("\\\\" + serverNames[i] + "\\"
					+ parameters.get("drive") + "$"
					+ parameters.get("edc_cleanup_folder_path")
					+ parameters.get("in_process"));
			if (!inprocesspath.exists())
				inprocesspath.mkdirs();
			File completedpath = new File("\\\\" + serverNames[i] + "\\"
					+ parameters.get("drive") + "$"
					+ parameters.get("edc_cleanup_folder_path")
					+ parameters.get("completed"));
			if (!completedpath.exists())
				completedpath.mkdirs();
			File errorpath = new File("\\\\" + serverNames[i] + "\\"
					+ parameters.get("drive") + "$"
					+ parameters.get("edc_cleanup_folder_path")
					+ parameters.get("error"));
			if (!errorpath.exists())
				errorpath.mkdirs();
		}
	}

	public static String getFileName() {
		long nanotime = System.nanoTime();
		String FileName = "destroyscript-" + CommonUtils.getDate() + "-"
				+ nanotime + ".txt";
		return FileName;
	}

	public static void deleteFiles(String path, int retention) {

		File file = new File(path);
		if (file.isDirectory()) {

			for (File f : file.listFiles()) {

				long diff = new Date().getTime() - f.lastModified();

				if (diff > retention * 24 * 60 * 60 * 1000) {

					f.delete();

				}

			}
		}

	}

	public static void moveFilesInProcessToReadyToProcess(Map parameters) {

		File file = new File(parameters.get("drive") + ":\\"
				+ parameters.get("edc_cleanup_folder_path")
				+ parameters.get("in_process"));
		if (file.isDirectory()) {

			for (File f : file.listFiles()) {
				try {
					fileMove(
							parameters.get("drive") + ":\\"
									+ parameters.get("edc_cleanup_folder_path")
									+ parameters.get("in_process")
									+ f.getName(),
							parameters.get("drive") + ":\\"
									+ parameters.get("edc_cleanup_folder_path")
									+ parameters.get("ready_to_process")
									+ f.getName());
				} catch (Exception e) {

					LOGGER.error(e.getMessage(), e);
				}
			}
		}

	}
}
