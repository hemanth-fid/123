/*package org.ifc.idocs.library.actions;
import java.util.Properties;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfLogger;



public class PermissionPreConditionUtility{	
	
	*//**
	 * This utility method checks the authenticity of the current user from 
	 * changing the permission set on the current document.
	 * @param session
	 * @param strObjectId
	 * @param strObjectType
	 * @param strDocState
	 * @param strOwnerName
	 * @param currentSecurityClassificationCode
	 * @param idocsProperties
	 * @return
	 *//*
	public static boolean callPermissionPreCondition(IDfSession session,String strObjectId,String strObjectType,String strDocState,String strOwnerName,String currentSecurityClassificationCode,Properties idocsProperties){
		try{
        
			DfLogger.info(PermissionPreConditionUtility.class,":: CHANGE PERMIT Id:"+ strObjectId + " ::Type: " + strObjectType + " ::Permit:" , null, null);
			
			*//** If the document is country allow user to edit the permissions  *//*
			if(strObjectType!=null && strObjectType.trim().length() > 0 
					&& strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_COUNTRY_DOC)){
				DfLogger.debug(PermissionPreConditionUtility.class,":: Enable 'add' Link as its a :"+ IDocsConstants.MSG_IDOCS_COUNTRY_DOC , null, null);
				return true;
			}
			
			*//** If the document state is released nobody is allowed to modify the ACL *//*
			if( strDocState != null && strDocState.equalsIgnoreCase(IdocsConstants.DOC_STATE_RELEASED)== true ){
				DfLogger.debug(PermissionPreConditionUtility.class,":: Disable 'add' Link as its :"+ IdocsConstants.DOC_STATE_RELEASED, null, null);
				return false;
			}
			DfLogger.info(PermissionPreConditionUtility.class, " :: DocState loop is done: ",null,null);
			
			*//** For non 'Released' Documents owners are allowed to edit the ACl *//*
			if(strOwnerName!=null && strOwnerName.equalsIgnoreCase(session.getLoginUserName()) == true ){
				DfLogger.debug(PermissionPreConditionUtility.class,":: Enable 'add' Link as :"+ session.getLoginUserName() +" is the owner.", null, null);
				return true;
			}
			
			*//** For non 'Released' documents only specific users are allowed to edit the ACL. *//*
			
			DfLogger.info(PermissionPreConditionUtility.class, " :: currentSecurityClassificationCode: "+ currentSecurityClassificationCode,null,null);
			String projectRole = null;
			if(IDocsConstants.MSG_OFFICIAL_CODE.equals(currentSecurityClassificationCode)){
				projectRole = idocsProperties.getProperty("PROJECT_CHANGE_PERMIT_ROLE_O");
				projectRole = projectRole.replaceAll(",", "','");
				DfLogger.info(PermissionPreConditionUtility.class, " :: projectRole value: "+ projectRole,null,null);
			}else if(IDocsConstants.MSG_CONFIDENTIAL_CODE.equals(currentSecurityClassificationCode)){
				projectRole = idocsProperties.getProperty("PROJECT_CHANGE_PERMIT_ROLE_C");
				projectRole = projectRole.replaceAll(",", "','");
			}else if(IDocsConstants.MSG_STRICTLY_CONFIDENTIAL_CODE.equals(currentSecurityClassificationCode)){
				projectRole = idocsProperties.getProperty("PROJECT_CHANGE_PERMIT_ROLE_S");
				projectRole = projectRole.replaceAll(",", "','");
			}else{
				DfLogger.info(PermissionPreConditionUtility.class, " :: Exception: Unknown Security Classigication Code : "+currentSecurityClassificationCode,null,null);
			}
			DfLogger.info(PermissionPreConditionUtility.class, " :: projectRole value: "+ projectRole,null,null);
			if(projectRole != null && projectRole.trim().length() > 0 ){
				return checkTeamMemberShip(session, strObjectId, strObjectType,projectRole,idocsProperties);				
			}else{
				if(strOwnerName!=null && strOwnerName.equalsIgnoreCase(session.getLoginUserName()) == true ){
					return true;
				}else{
					return false;
				}
			}
		}catch (Exception e) {
			DfLogger.info(PermissionPreConditionUtility.class, " :: Exception:"+e.getMessage(),null,null);
		}
		return false;
	}

	*//**
	 * 
	 * @param dfSession
	 * @param strObjectId
	 * @param strObjectType
	 * @param role
	 * @param idocsProperties
	 * @return
	 *//*
	public static boolean checkTeamMemberShip(IDfSession dfSession,
			String strObjectId, String strObjectType,
			String role,Properties idocsProperties){
		boolean validated = false;
		String strInstitutionNumberOrProjectId = null;
		try{
			String strMemberRoleQry = null;
			if(strObjectType != null && strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_INSTITUTION_DOC)){
				strMemberRoleQry = idocsProperties.getProperty("QRY_INSTITUTION_MEMBER");
				strInstitutionNumberOrProjectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(dfSession,
						strObjectId,IdocsConstants.MSG_INSTITUTION_NBR,strObjectType);
			}else if(strObjectType != null && strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_PROJECT_DOC)){
				strMemberRoleQry = idocsProperties.getProperty("QRY_PROJ_MEMBER");
				strInstitutionNumberOrProjectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(dfSession,
						strObjectId,IdocsConstants.PROJ_ID,strObjectType);
			}
			strMemberRoleQry = strMemberRoleQry.replaceFirst("''", "'"+strInstitutionNumberOrProjectId+"'");
			strMemberRoleQry = strMemberRoleQry.replaceFirst("''", "'"+role+"'");
			strMemberRoleQry = strMemberRoleQry.replaceFirst("''", "'"+IdocsUtil.handleSingleQuote(dfSession.getLoginUserName())+"'");

			IDfQuery query = new DfQuery();
			query.setDQL(strMemberRoleQry);
			DfLogger.info(PermissionPreConditionUtility.class, " :: validateUserAccess : Check User Role Query :"+strMemberRoleQry,null,null);
			IDfCollection coll=query.execute(dfSession,IDfQuery.DF_READ_QUERY);
			if(coll.next()){
				validated=true;
				coll.close();
			}
			if(coll != null )coll.close();
		}catch (Exception e) {
			DfLogger.info(PermissionPreConditionUtility.class, " :: validateUserAccess : Exception :"+e.getMessage(),null,null);
		}
		return validated;
	}	
}
*/