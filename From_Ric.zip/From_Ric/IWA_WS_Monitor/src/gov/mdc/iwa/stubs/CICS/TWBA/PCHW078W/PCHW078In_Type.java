/**
 * PCHW078In_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W;

public class PCHW078In_Type  implements java.io.Serializable {
    private gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078InHdr_Type PCHW078InHdr;

    private java.lang.String PONUM2360;

    public PCHW078In_Type() {
    }

    public PCHW078In_Type(
           gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078InHdr_Type PCHW078InHdr,
           java.lang.String PONUM2360) {
           this.PCHW078InHdr = PCHW078InHdr;
           this.PONUM2360 = PONUM2360;
    }


    /**
     * Gets the PCHW078InHdr value for this PCHW078In_Type.
     * 
     * @return PCHW078InHdr
     */
    public gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078InHdr_Type getPCHW078InHdr() {
        return PCHW078InHdr;
    }


    /**
     * Sets the PCHW078InHdr value for this PCHW078In_Type.
     * 
     * @param PCHW078InHdr
     */
    public void setPCHW078InHdr(gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078InHdr_Type PCHW078InHdr) {
        this.PCHW078InHdr = PCHW078InHdr;
    }


    /**
     * Gets the PONUM2360 value for this PCHW078In_Type.
     * 
     * @return PONUM2360
     */
    public java.lang.String getPONUM2360() {
        return PONUM2360;
    }


    /**
     * Sets the PONUM2360 value for this PCHW078In_Type.
     * 
     * @param PONUM2360
     */
    public void setPONUM2360(java.lang.String PONUM2360) {
        this.PONUM2360 = PONUM2360;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PCHW078In_Type)) return false;
        PCHW078In_Type other = (PCHW078In_Type) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.PCHW078InHdr==null && other.getPCHW078InHdr()==null) || 
             (this.PCHW078InHdr!=null &&
              this.PCHW078InHdr.equals(other.getPCHW078InHdr()))) &&
            ((this.PONUM2360==null && other.getPONUM2360()==null) || 
             (this.PONUM2360!=null &&
              this.PONUM2360.equals(other.getPONUM2360())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPCHW078InHdr() != null) {
            _hashCode += getPCHW078InHdr().hashCode();
        }
        if (getPONUM2360() != null) {
            _hashCode += getPONUM2360().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PCHW078In_Type.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "PCHW078In_Type"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PCHW078InHdr");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "PCHW078InHdr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "PCHW078InHdr_Type"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PONUM2360");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "PONUM2360"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
