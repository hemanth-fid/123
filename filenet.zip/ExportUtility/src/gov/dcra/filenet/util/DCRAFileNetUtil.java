package gov.dcra.filenet.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
//import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.lang.String;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
//import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.filenet.api.collection.ContentElementList;
import com.filenet.api.collection.RepositoryRowSet;
import com.filenet.api.constants.PropertyNames;
import com.filenet.api.core.ContentElement;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.property.Property;
import com.filenet.api.query.RepositoryRow;
import com.filenet.api.query.SearchSQL;
import com.filenet.api.query.SearchScope;


import gov.dcra.filenet.constants.Constants;

public class DCRAFileNetUtil {

	private final static Logger log=Logger.getLogger(DCRAFileNetUtil.class);
	
	public ObjectStore getObjectStore (Domain domain, String objectStoreName) throws Exception {
		
		ObjectStore os = null;
		os = Factory.ObjectStore.fetchInstance(domain, objectStoreName, null);
		return os;
		
	}
	
	public Map<String,String> getDocProperties(ObjectStore os,Document doc) throws Exception {
		
		Map<String,String> propsMap=new LinkedHashMap<String,String>();
	
		if(doc!=null){

			com.filenet.api.property.Properties docProps = doc.getProperties();

			@SuppressWarnings("rawtypes")
			Iterator iter = docProps.iterator();
			while (iter.hasNext() )
			{
				Property prop = (Property)iter.next();
				
				if(prop.getPropertyName()!=null && prop.getObjectValue()!=null){
					log.debug("ID : "+doc.get_Id().toString()+ ", Property : "+prop.getPropertyName() +" , val : "+prop.getObjectValue().toString());
					propsMap.put(prop.getPropertyName(), prop.getObjectValue().toString());
				}
			}
		}
		return propsMap;
	}
	
	
	public String  getDocContent(Document doc,String docExportDir,String fileNumber, Property prop, String documentTilte, String NAME) throws Exception {
		
		log.debug("ID : "+doc.get_Id().toString()+"     No. of document content elements: " + doc.get_ContentElements().size() + "\t" +
				 "Total size of content: " + doc.get_ContentSize());
		
		String filePath=null;
		ContentElementList contents = doc.get_ContentElements();
	
		ContentElement content=null;
		@SuppressWarnings("rawtypes")
		Iterator itContent = contents.iterator();
		while(itContent.hasNext())
		{
			content = (ContentElement)itContent.next();
			filePath=getContentStream((ContentTransfer)content,docExportDir,doc,prop,fileNumber,documentTilte);
		}
		
		
		return filePath;
	}
	
	@SuppressWarnings("resource")
	public String getContentStream(ContentTransfer content,String docExportDir,Document doc,Property prop,String fileNumber, String documentTilte ) throws Exception {
		String fileParentPath=null;
		String docAbsolutePath=null;
		
		try{
			
			//fileParentPath=createObjectIdDirectory(docExportDir, fileNumber.toString());
			//prop.getObjectValue().toString()
			//fileParentPath=createObjectIdDirectory(docExportDir, doc.get_Id().toString());
			fileParentPath=createObjectIdDirectory(docExportDir, doc.get_Name().toString());
           // docAbsolutePath=new StringBuffer().append(fileParentPath).append(Constants.FILESEPARATOR).append(docPropsMap.get(PropertyNames.NAME)).append(".").append(FilenameUtils.getExtension(content.get_RetrievalName())).toString();
			//docAbsolutePath=new StringBuffer().append(fileParentPath).append(Constants.FILESEPARATOR).append(content.get_RetrievalName()).toString();
			docAbsolutePath=new StringBuffer().append(fileParentPath).append(Constants.FILESEPARATOR).append(documentTilte).append(".").append(FilenameUtils.getExtension(content.get_RetrievalName())).toString();
			//docAbsolutePath=new StringBuffer().append(fileParentPath).append(Constants.FILESEPARATOR).append(doc.get_ContentElements().toString()).append(".").append(FilenameUtils.getExtension(content.get_RetrievalName())).toString();
			InputStream inputStream = content.accessContentStream();
			OutputStream outputStream = new FileOutputStream(docAbsolutePath);

			byte[] nextBytes = new byte[64000];
			int nBytesRead;

			while((nBytesRead = inputStream.read(nextBytes)) != -1){

				outputStream.write(nextBytes, 0, nBytesRead);
				outputStream.flush();
			}
		}catch(Exception e){
			
			log.error(e.getMessage());
			return null;
		}
		
		return docAbsolutePath;
	}
	
	
	public String createObjectIdDirectory(String parentPath,String objectId) {
	//public String createObjectIdDirectory(String parentPath,String NAME){
		
		String absPath=null;
		
		File file = new File(parentPath.concat(Constants.FILESEPARATOR).concat(objectId));
		//File file = new File(parentPath.concat(Constants.FILESEPARATOR).concat(NAME));
        if (!file.exists()) {
            if (file.mkdir()) {
            	absPath=file.getAbsolutePath();
            } else {
                System.out.println("Failed to create directory!");
            }
        }else{
        	
        	absPath=file.getAbsolutePath();
        }
        
        return absPath;
	}
	
	public String parseDate(String date) throws ParseException {

		Date fnDate = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss").parse(date);
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'");
		return df.format(fnDate);

	}
	
	public List<String> getObjectIds(ObjectStore os) throws Exception {

		List<String> objectIdLst=null;
		objectIdLst= new LinkedList<String>();
		
		String fromDate = parseDate("02-21-2018 00:00:00");
		String toDate = parseDate("02-22-2018 00:00:00");
		
//		String query = "select File_Number, ID,Address,DocumentTitle,Document_Date,Document_Type, Permit_Type, DateCreated from POD_BUILDING where ";
//		String query = "select ID from POD_BUILDING where ";
//		String dateCriteria = " Document_Date>=" + fromDate + " AND Document_Date<=" + toDate + "AND DocumentTitle is NULL";
//		String searchCriteria = query + dateCriteria;
		
		String query = "select  ID from POD_BUILDING where ";
		String dateCriteria = " DateCreated>=" + fromDate + " AND DateCreated<=" + toDate;
		String searchCriteria = query + dateCriteria;

		SearchSQL sqlObject = new SearchSQL(searchCriteria);
		SearchScope searchScope = new SearchScope(os);

		RepositoryRowSet rowSet = searchScope.fetchRows(sqlObject, Integer.getInteger("50"), null,Boolean.valueOf(true));
		@SuppressWarnings("rawtypes")
		Iterator itRow = rowSet.iterator();
		RepositoryRow row;

		while (itRow.hasNext()){
			row = (RepositoryRow)itRow.next();
			com.filenet.api.property.Properties props = row.getProperties();
			@SuppressWarnings("rawtypes")
			Iterator itProp = props.iterator();
			
			while (itProp.hasNext()){
				Property prop = (com.filenet.api.property.Property)itProp.next();
				//System.out.println(prop.getPropertyName());
				System.out.println(prop.getPropertyName());
				//System.out.println(prop.getObjectValue());
				log.debug("prop.getObjectValue() : "+prop.getObjectValue());
				objectIdLst.add(prop.getObjectValue().toString());
				
			}
		}
		return objectIdLst;
	}
	
	
	@SuppressWarnings("deprecation")
	public List<String> readInputFile(String fileName,String columnName) throws IOException,Exception{
		
		
		      
		List<String> docIds=null;
		Integer columnNo = null;
	    FileInputStream fileIn = new FileInputStream(fileName);
	    
	    OPCPackage pkg = OPCPackage.open(fileIn);
	    @SuppressWarnings("resource")
		XSSFWorkbook filename = new XSSFWorkbook(pkg);
	    XSSFSheet sheet = filename.getSheetAt(0);
	  
	    docIds = new LinkedList<String>();
	   
	   Row firstRow = sheet.getRow(0);

	    for(Cell cell:firstRow){
	        
	    	if(cell.getCellType()==Cell.CELL_TYPE_STRING){
	    		if (cell.getStringCellValue().equals(columnName)){
	    			columnNo = cell.getColumnIndex();
	    			break;
	    		}
	    	}
	    }

	    if (columnNo != null){
	    	for (Row row : sheet) {
	    		Cell c = row.getCell(columnNo);
	    		if (c != null && c.getCellType() != Cell.CELL_TYPE_BLANK) {
	    			if(!c.getStringCellValue().equalsIgnoreCase(columnName)){
	    				log.debug("Value : "+c.getStringCellValue());
	    				docIds.add(c.getStringCellValue().trim());
	    			}
	    		} 
	    	}
	    }else{
	        System.out.println("could not find column " + columnName + " in first row of " + fileIn.toString());
	    }
	    return docIds;
	}
}

