
package org.ifc.idocs.forms.adaptors;

import java.util.Date;

import com.documentum.fc.common.DfLogger;
import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.xforms.engine.adaptor.validator.IDateValidator;
import com.documentum.xforms.engine.adaptor.validator.ItemValidator;

public class ClearFutureDate extends ItemValidator implements IDateValidator  {


	public boolean validateDate(Date dateField) throws AdaptorException {

		DfLogger.info(this,"validateDate()",null,null);
		boolean errorValue = false;

		Date now = new Date();
		if (dateField == null)
			errorValue = true;
		else if (dateField.after(now))
			errorValue = true;

		return errorValue;
	}






	public void destroy() throws AdaptorException {
		// TODO Auto-generated method stub

	}

	public void init(IAdaptorConfiguration adaptor) throws AdaptorException {


	}
}