package org.worldbank.icsid.rps;

public class Constants {
	public static final String NEWLINE = "\r\n";
	public static final String QRY_STRING_APPLY_POLICY_TASK_ID = "<apply_policy_task_id>";
	public static final String QRY_STRING_R_OBJECT_ID = "<r_object_id>";
	public static final String QRY_STRING_STATUS = "<status>";
	public static final String QRY_STRING_PROCESSED = "<processed>";
	public static final String QRY_STRING_IS_POLICY_APPLIED = "<is_policy_applied>";
	public static final String QRY_STRING_IS_LOCKED = "<is_locked>";
	public static final String ACTION = "action";
	public static final String ISPROCESSED = "isprocessed";
	public static final String RETENTION_POLICY_NAME = "retention_policy_name";
	public static final String FOLDER_PATH = "folder_path";
	public static final String APPLY_POLICY_TASK_ID = "apply_policy_task_id";
	public static final String START_TIME = "start_time";
	public static final String END_TIME = "end_time";
	public static final String TOTAL_EXECUTION_TIME = "total_execution_time";
	public static final String RPS_EXECUTION_TIME = "rps_execution_time";
	
	
	public static final String QRY_STRING_USERID = "<userid>";
	public static final String QRY_STRING_R_MODIFIER = "<r_modifier>";
	public static final String QRY_STRING_R_MODIFY_DATE = "<r_modify_date>";
}
