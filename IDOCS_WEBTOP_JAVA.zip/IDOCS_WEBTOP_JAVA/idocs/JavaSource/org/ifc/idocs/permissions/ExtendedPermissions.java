/**
* This component class extends default component class.
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* CVattathara			09/25/2010		1.0				created
* #######################################################################################################
*/
package org.ifc.idocs.permissions;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;

public class ExtendedPermissions extends com.documentum.webcomponent.library.permissions.ExtendedPermissions {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5331582035284973763L;
		
	public void onInit(ArgumentList args){
    	super.onInit(args);
    	String strObjectId = args.get("objectId");
    	DfLogger.info(this, "ExtendedPermissions :: ObjectId :: "+strObjectId,null,null);

    }
}
