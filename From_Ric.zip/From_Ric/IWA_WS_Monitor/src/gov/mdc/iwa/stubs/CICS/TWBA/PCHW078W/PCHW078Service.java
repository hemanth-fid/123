/**
 * PCHW078Service.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W;

public interface PCHW078Service extends javax.xml.rpc.Service {
    public java.lang.String getPCHW078ServicePortAddress();

    public gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078ServicePort_Type getPCHW078ServicePort() throws javax.xml.rpc.ServiceException;

    public gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078ServicePort_Type getPCHW078ServicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
