package org.ifc.idocs.contenttransfer.cancelcheckout;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ErrorMessageService;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.contentxfer.ContentTransferException;
import com.documentum.web.contentxfer.JobAdapter;
import com.documentum.web.contentxfer.impl.CancelCheckoutService;
import com.documentum.web.form.Form;
import com.documentum.web.formext.component.Component;
import com.documentum.webcomponent.library.contenttransfer.cancelcheckout.CancelCheckoutContainer;
import com.documentum.webcomponent.library.contenttransfer.cancelcheckout.UcfCancelCheckout;
import com.documentum.webcomponent.library.messages.MessageService;

public class IDocsCancelCheckoutContainer extends CancelCheckoutContainer {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String MSG_CANCELLED_CHECKOUT = "Cancelled Checkout";

    protected void handleOnReturnFromProgressSuccess(Form form, Map map, JobAdapter job)
    {
        Map ids = null;
        try
        {
        	super.handleOnReturnFromProgressSuccess(form, map, job);
            if(job.getService() instanceof CancelCheckoutService)
            {
                CancelCheckoutService service = (CancelCheckoutService)job.getService();
                ids = service.getObjectIds();
                if(ids != null)
                    setReturnValue("newObjectIds", ids);
            }
            boolean anyError = false;
            ArrayList <Component> components = getContainedComponents();
            for (Iterator iterator = components.iterator(); iterator.hasNext();) {
				Component component = (Component) iterator.next();
				DfLogger.debug(this, "component.getClass()"+component.getClass(),null,null);
                if(component instanceof UcfCancelCheckout){
                	IDocsUcfCancelCheckout idocsCancelCheckout = (IDocsUcfCancelCheckout)component;
                	String messageNlsId = idocsCancelCheckout.getFailureMessageId();
                	String failedObjectName = idocsCancelCheckout.getFailedObjectName();
                	DfLogger.debug(this, "This is a Cancel Checkout Container MSG:"+idocsCancelCheckout.getFailureMessageId(),null,null);
                	if(failedObjectName != null && failedObjectName.trim().length() > 0){
                		addCustomFinalSuccessMessage(messageNlsId,failedObjectName);
                		anyError = true;
                	}                	
                }            			
			}
            if(anyError){
            	DfLogger.debug(this, "There was some error in Cancel Checkout.",null,null);
            }else{
            	addFinalSuccessMessage();                
            	DfLogger.debug(this, "Cancel Checkout Successful.",null,null);
            }
            processDocumentForCancelCheckoutAudit(ids);
        }
        catch(ContentTransferException e)
        {
            throw new WrapperRuntimeException(e);
        }
    }
    
    private void addCustomFinalSuccessMessage(String messageNlsId,
    		String failedObjectName) {
    	MessageService.addMessage(this, messageNlsId, new Object[]{failedObjectName});
    	ErrorMessageService.getService().setNonFatalError(this, messageNlsId, new Object[]{failedObjectName}, null);
	}

	private void processDocumentForCancelCheckoutAudit(Map objectIdMap) {
    	Iterator it = objectIdMap.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry e = (Map.Entry) it.next();
			DfLogger.info(this, e.getKey() + " " + e.getValue(), null, null);
			if(e != null && e.getValue() != null ){
				String objectId = e.getValue().toString();
				IdocsUtil.auditIDocsActivity(MSG_CANCELLED_CHECKOUT,objectId,getDfSession());
			}
		}
	}

	protected void addFinalSuccessMessage(){
        MessageService.addMessage(this, "MSG_OPERATION_SUCCESSFUL");
    }	    
}
