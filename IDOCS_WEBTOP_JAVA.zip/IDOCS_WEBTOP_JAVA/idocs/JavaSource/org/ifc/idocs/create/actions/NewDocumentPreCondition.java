/**
* 
* This precondition class decides whether to allow the user to create 
* document in the current folder
* ########################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* ########################################################################
* Gangadhar Reddy.V    02/12/2011       1.0          Created

* ########################################################################
*//*
package org.ifc.idocs.create.actions;

import java.util.Map;

import org.ifc.idocs.main.MainEx;

import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.ErrorMessageService;
import com.documentum.web.formext.action.IActionPrecondition;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

public class NewDocumentPreCondition implements IActionPrecondition{
	private static String strFolderId = "";
	
	private static final NlsResourceBundle s_lookup = new NlsResourceBundle("org.ifc.idocs.create.NewDocumentNlsProp");
	
	public String[] getRequiredParams() {
			return (new String[] {
		            "projectStatus"
		        });
		}

	*//**
	 * Checks the business rule and enables/disables the menu item.
	 * 
	 * @param strAction
	 * @param config
	 * @param arg
	 * @param context
	 * @param component
	 * @param completionArgs
	 * @return
	 * @throws DfException
	 *//*
	public boolean queryExecute(String strAction, IConfigElement config, ArgumentList arg, Context context, Component component,Map completionArgs) throws DfException {
		boolean bExecute=false;
	    IDfSession dfSession = component.getDfSession();
		strFolderId=arg.get("objectId");
		IDfFolder docFolder = (IDfFolder)dfSession.getObject(new DfId(strFolderId));
		String projectStatusId = docFolder.getString("project_status_code");
	    
		DfLogger.info(this, " :: strFolderId : "+strFolderId, null, null);
	    String projectStatus = MainEx.getSourceName(component.getPageContext().getSession());
	      
	    DfLogger.info(this, " :: projectStatus : "+projectStatus, null, null);
	    if ( projectStatusId == "X"){
//	       	ActionExecutionUtil.setCompletionError(completionArgs, s_lookup, "MSG_PERMISSION_DENIED", component, null, null);
            ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_PERMISSION_DENIED", component, null, null);
 	       	bExecute = true;
	    }
	        return bExecute;
	}

	public boolean queryExecute(String s, IConfigElement iconfigelement,
			ArgumentList argumentlist, Context context, Component component) {
		// TODO Auto-generated method stub
		return false;
	}

}*/