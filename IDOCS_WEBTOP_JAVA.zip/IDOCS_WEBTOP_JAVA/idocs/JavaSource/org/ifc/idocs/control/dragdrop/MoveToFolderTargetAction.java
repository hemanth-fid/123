/**
* This component sets the attributes of the document when moved from one 
* project to another.
* 
* ##########################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* ##########################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* ##########################################################################
*/
package org.ifc.idocs.control.dragdrop;

import java.util.HashMap;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.environment.actions.IDocsMoveAction;
import org.ifc.idocs.library.actions.LaunchViewComponentWithPermitCheck;
import org.ifc.idocs.utils.IDocsClipboardPasteHandler;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.dragdrop.IDragDropData;
import com.documentum.web.dragdrop.IDragDropDataProvider;
import com.documentum.web.form.Form;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.control.dragdrop.DragDropClipboard;
import com.documentum.web.formext.docbase.FolderUtil;
import com.documentum.web.formext.docbase.ObjectCacheUtil;
import com.documentum.web.formext.session.DocbaseUtils;
import com.documentum.webcomponent.common.WebComponentErrorService;

public class MoveToFolderTargetAction extends com.documentum.web.formext.control.dragdrop.MoveToFolderTargetAction
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static NlsResourceBundle m_nlsResourceBundle = new NlsResourceBundle("org.ifc.idocs.clipboard.ClipboardErrorsNlsProp");

	/**
	 * This method sets the attributes and ACL Of the object based on the project folder where its being moved to.
	 */
	
    public boolean execute(Form form, String position, IDragDropDataProvider sourceDataProvider[], IDragDropDataProvider targetDataProvider, String sourceItemData[], String targetItemData)
    {
        if(!(form instanceof Component))
            throw new IllegalArgumentException("MoveToFolderTargetAction.execute() expects a Component as the first argument");
        IDragDropData targetData = getTargetDataFromProvider(targetDataProvider, targetItemData);
        String arrParentFolderPaths[] = new String[sourceItemData.length];
        Component component = (Component)form;
        String componentId;
        if(targetItemData.indexOf("homecabinet_classic") != -1)
            componentId = "homecabinet_classic";
        else
            componentId = component.getComponentId();
        for(int i = 0; i < sourceItemData.length && sourceItemData.length == sourceDataProvider.length; i++)
        {
            IDragDropData sourceData = getSourceDataFromProvider(sourceDataProvider[i], sourceItemData[i]);
            String strTargetObjId = getObjectIdFromData(targetData);
            com.documentum.web.formext.clipboard.IClipboardPasteHandler handler = component.getClipboardPasteHandler(strTargetObjId);
            if(handler != null)
            {
                DragDropClipboard dragDropClipboard = new DragDropClipboard();
                String strSrcParentObjId = getSourceContainerObjectId(sourceData);
                String strSrcObjId = getObjectIdFromData(sourceData);
                try {
					IDfSysObject sourceSysobject = (IDfSysObject)ObjectCacheUtil.getObject(component.getDfSession(), strSrcObjId);
					setRequiredAttributes(strSrcObjId,component.getDfSession());
					if(LaunchViewComponentWithPermitCheck.validateUserPermissionsForView(true,strSrcObjId, component.getDfSession(),docValuesMap) == false){
						throw new DfException("You are not Authorised to Move '"+strObjectName+"'.");
	    			}
					IDocsClipboardPasteHandler.checkIDocsDocumentCopyOperationRule(sourceSysobject, strTargetObjId, component.getDfSession(), IDocsMoveAction.MOVE_OPERATION_NAME);
				} catch (DfException e) {
					DfLogger.error(this, ": Move Via Drag Drop Failed :"+e.getMessage(),null, null);
					String validationError=e.getMessage();							 
	            	Object params[] = new Object[1];             
	            	params[0] = DocbaseUtils.getValidationExceptionMsg(new DfException(validationError));			            	   	
	            	WebComponentErrorService.getService().setNonFatalError(m_nlsResourceBundle, "MSG_VALIDATION_ERROR", form, params, null);
					return false;
				}
                com.documentum.web.formext.clipboard.IClipboardCutHandler cutHandler = component.getClipboardCutHandler(strSrcObjId, strSrcParentObjId);
                dragDropClipboard.setCutHandler(cutHandler);
                arrParentFolderPaths[i] = getFolderPath(componentId, component.getCurrentDocbase(), strSrcParentObjId);
                dragDropClipboard.pasteAsMove(strSrcObjId, handler);
                postMoveAttributeUpdation(strSrcObjId,strTargetObjId,component);
            } else
            {
                throw new IllegalArgumentException("Component must implement IClipboardPasteHandler!");
            }
        }

        component.getPageContext().setAttribute("PROPERTY_HIDDEN_COLLAPSE", arrParentFolderPaths, 3);
        component.updateStateFromRequest();
        return true;
    }
    
    private boolean postMoveAttributeUpdation(String destinationObjectId,String destinationFolderId, Component component) {
		try{
			IDfFolder targerFolder = null;
			IDfFolder parentTargetFolder = null;
			if(destinationFolderId != null && destinationFolderId.trim().length() > 0){
				targerFolder = (IDfFolder)ObjectCacheUtil.getObject(component.getDfSession(), destinationFolderId);
				parentTargetFolder = IDocsClipboardPasteHandler.getParentFolder(component.getDfSession(),targerFolder);
			}
			if(destinationObjectId!=null && destinationObjectId.trim().length()>0
					&& parentTargetFolder != null ){
				IDfSysObject movedObject = (IDfSysObject)ObjectCacheUtil.getObject(component.getDfSession(), destinationObjectId);
				IdocsUtil.updateAttribute(component.getDfSession(), movedObject, parentTargetFolder, IDocsConstants.IDOCS_MOVE_OPERATION);
				IdocsUtil.auditIDocsActivity(IDocsMoveAction.MSG_MOVED,destinationObjectId,component.getDfSession());
			}
		}catch (Exception e) {
			DfLogger.error(this, " : Attribute Updation Failed : Abort "+e.getMessage(), null, null);
			return false;
		}	
		return true;
	}
    
	/**
	 * Retrives the destination folder path
	 * @param componentId
	 * @param strDocbaseName
	 * @param clipItems
	 * @return
	 */
    private String getFolderPath(String componentId, String strDocbaseName, String clipItems)
    {
        String arrFolderPaths = clipItems;
        String strFolderId = FolderUtil.getFolderIdsFromPath(FolderUtil.getPrimaryFolderPath(clipItems));
        StringBuffer sbFolderPath = new StringBuffer("_ROOT");
        sbFolderPath.append(".").append(strDocbaseName).append(".");
        if(strFolderId != null)
        {
            String strFolderIds = strFolderId.substring(strFolderId.indexOf(".0b") + 1, strFolderId.length());
            if(componentId.equals("objectlist") || componentId.equals("browsertree"))
                sbFolderPath.append("/").append(strDocbaseName).append(".").append(strFolderId);
            if(componentId.equals("homecabinet_classic"))
            {
                sbFolderPath.append(componentId);
                if(strFolderId.indexOf(".") != -1)
                    sbFolderPath.append(".").append(strFolderIds);
            }
            if(componentId.equals("browsertree") || componentId.equals("homecabinet_classic"))
                arrFolderPaths = (new StringBuilder()).append(sbFolderPath.toString()).append(".").append(clipItems).toString();
            else
                arrFolderPaths = sbFolderPath.toString();
        } else
        {
            arrFolderPaths = sbFolderPath.append("/").append(strDocbaseName).append(".").append(clipItems).toString();
        }
        return arrFolderPaths;
    }
    
    private void setRequiredAttributes(String strObjectId,IDfSession dfSession){
		docValuesMap=IdocsUtil.getRequiredAttributesValues(strObjectId,dfSession);
		strObjectName= docValuesMap.get(IDocsConstants.MSG_OBJECT_NAME);
		}
	
	private HashMap<String, String> docValuesMap = new HashMap<String, String>();
	private String strObjectName="";
}
