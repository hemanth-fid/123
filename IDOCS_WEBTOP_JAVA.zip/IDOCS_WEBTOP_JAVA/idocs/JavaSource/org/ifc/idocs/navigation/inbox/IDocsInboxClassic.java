/**
* Class to control the behavior of the user Inbox.
* 	This class defaults the Inbox View to Show Tasks + Attachments as the
* default selection in the inbox filter.
* 
* ########################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* ########################################################################
* Sleeba Kurian			26/04/2011		1.0					created 
* ########################################################################
* L V Sudhakar			06/08/2012		1.1					modified 
* ########################################################################
*/
package org.ifc.idocs.navigation.inbox;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.SessionState;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.databound.DataProvider;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.formext.common.ClientSessionState;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigLookup;
import com.documentum.web.formext.config.IPreferenceStore;
import com.documentum.web.formext.config.PreferenceService;
import com.documentum.webcomponent.navigation.inbox.InboxList;

public class IDocsInboxClassic extends com.documentum.webcomponent.navigation.inbox.InboxList {
	
	public void onInit(ArgumentList arg) {
		setCurrentFilter(DISPLAY_ALL_TASKS);
		storeFilterValue();
		/** confirmfinishtask.showprompt = false */
		IPreferenceStore preferences = PreferenceService.getPreferenceStore();
        preferences.writeBoolean("confirmfinishtask.showprompt", false);
        
		ArgumentList argDrl = new ArgumentList();
		String objectId = arg.get(OBJECT_ID);
		if (objectId == null || objectId.length() <= 0) {
			ArgumentList argDrlView = (ArgumentList) ClientSessionState.getAttribute(DRL_VIEW_ARG);
			if (argDrlView != null) {
				ClientSessionState.removeAttribute(DRL_VIEW_ARG);
				objectId = argDrlView.get(OBJECT_ID);
			}
		}
		argDrl.add(OBJECT_ID, objectId);
		argDrl.add(TYPE, DM_TASK);
		argDrl.add(TASKMANAGER_ID, TASKMGRCLASSIC);
		String taskId = (String)SessionState.getAttribute(IDocsConstants.DIRECT_TASK_ID);
		if(taskId != null && taskId.trim().length() > 0
				&& taskId.equalsIgnoreCase(objectId)== true){
			DfLogger.debug(this, "This task has been open recently. Donot Trigger Task View =" + taskId, null, null);
			objectId = null;
		}else{
			DfLogger.debug(this, "New Task . Trigger Task View =" + objectId, null, null);			
		}
		super.onInit(arg);
		if(objectId !=null && objectId.trim().length() > 0){
			DataProvider provider = ((Datagrid) getControl(InboxList.DATAGRID_CONTROL_NAME)).getDataProvider();
			provider.initBind();
			while (provider.nextRow()) {
				String providerObjectId = provider.getDataField(R_OBJECT_ID);
				if (providerObjectId != null && providerObjectId.trim().length() > 0 && providerObjectId.equals(objectId)) {
					argDrl.add(ARG_PROJECT_ID, provider.getDataField(PROJECT_ID));
					argDrl.add(ARG_PROJECT_SHORT_NAME, provider.getDataField(PROJECT_SHORT_NME));
					argDrl.add(ARG_COUNTRY_NAME, provider.getDataField(COUNTRY_NME));
					argDrl.add(ARG_DOCUMENT_TYPE, provider.getDataField(OBJECT_TYPE));
					argDrl.add(ARG_COUNTRY_CODE, provider.getDataField(COUNTRY_CODE));
					DfLogger.debug(this,providerObjectId + ": argDrl="+argDrl,null,null);
					break;
				}
			}
		}
		if (objectId != null){
			DfLogger.debug(this, "Open Task View ObjectId = " + objectId, null, null);
			setClientEvent(ON_DRL_INBOX_VIEW, argDrl);
		}

		/**
		 * This part is to Enable ESRI/SII template delayedDisclosure status row
		 * (Start)
		 */
		String highlightSIIESRS = IdocsUtil.getMessage(STR_HIGHLITING_ENABLE);
		if (highlightSIIESRS != null && highlightSIIESRS.trim().length() > 0
				&& highlightSIIESRS.equalsIgnoreCase(YES)) {
			DfLogger.info(this, "Highliting ESRS and SII is Enabled"+ highlightSIIESRS, null, null);
			enableHighliting = true;
		} else {
			DfLogger.info(this, "Highlighting ESRS and SII is Disbled", null,null);
		}
		/** (End) */		
		DfLogger.debug(this,"IDocsInboxClassic << " +Calendar.getInstance().getTimeInMillis(),null,null);
	}

	public void onRender(){
        super.onRender();
        readPreferences();
    }

    public void onExit(){
        super.onExit();
    }

    protected void readPreferences(){
        IConfigLookup lookup = getConfigLookup();
        Integer nItems = lookup.lookupInteger("application.display.classic", new Context());
        if(nItems != null)
            ((Datagrid)getControl(DATAGRID_CONTROL_NAME, Datagrid.class)).getDataProvider().setPageSize(nItems.intValue());
    }

    protected String buildHeaderlabel(){
        StringBuffer header = new StringBuffer(64);
        header.append(getString(MSG_HEADER)).append(" (").append(getCurrentDocbase()).append(')');
        return header.toString();
    }

    protected String getColumnsPreferenceId(){
        return "application.display.classic_inbox_columns";
    }

    public void refreshInbox(Control control,ArgumentList args ){
		onRefreshData();
	}
	
	/**
	 * purpose  to enable highlighting delayedDisclouser Activity 
	 * @param values
	 * @return
	 */
	public static boolean getDelayedDisclouserStatus(HashMap<String,String> values,IDfSession dfSession){
		if(values != null){
		 Set<String> keys=values.keySet();
		 if(!keys.isEmpty()){
			Iterator<String> iter=keys.iterator();
			String keyValue=EMPTY_STRING;
		 	while(iter.hasNext()){
		 		String mapKeys=iter.next(); 
		          //@ TODO remove mapKeys.equalsIgnoreCase("idocs_pds_commitment_form"))
		 		if(mapKeys.equalsIgnoreCase(IDocsConstants.IDOCS_ESRS_FORM) || mapKeys.equalsIgnoreCase(IDocsConstants.IDOCS_SPI_FORM)){
		 			keyValue=values.get(mapKeys);
		 			DfLogger.debug(IDocsInboxClassic.class, "getDelayedDisclouserStatus :: form instance existed values are :: "+keyValue, null, null);
		 		}else{
		 			keyValue=null;
		 		}
		 	}
		  if(keyValue != null && keyValue.trim().length()> 0 && keyValue.equals(IDocsConstants.BLANK_OBJECT_ID)){
			  try {
				  IDfDocument dfDocumnet = (IDfDocument)dfSession.getObject(new DfId(keyValue));
				   if(dfDocumnet != null){
				   if(dfDocumnet.hasAttr(IDocsConstants.DISCLOSURE_TYPE)){
					   String disclosureTypeValue=dfDocumnet.getString(IDocsConstants.DISCLOSURE_TYPE);
					   if(disclosureTypeValue != null && disclosureTypeValue.trim().length() >0){
							if(disclosureTypeValue.equals(DISCLOSURE_FORMVALUE_D)){
							DfLogger.debug(IDocsInboxClassic.class, "getDelayedDisclouserStatus :: disclosureTypeValue existed(return true) "+DISCLOSURE_FORMVALUE_D, null, null);
								return true;
							}else{
							DfLogger.debug(IDocsInboxClassic.class, "getDelayedDisclouserStatus :: disclosureTypeValue existed(return false) "+disclosureTypeValue, null, null);
								return false;
							}		  
						}else{
						DfLogger.debug(IDocsInboxClassic.class, "getDelayedDisclouserStatus :: disclosureTypeValue is empty or null"+IDocsConstants.DISCLOSURE_TYPE, null, null);	
							return false; 
							 }
						}else{
						 DfLogger.debug(IDocsInboxClassic.class, "getDelayedDisclouserStatus :: no such attribute existed"+IDocsConstants.DISCLOSURE_TYPE, null, null);
						 return false; 
						}
					}else{
						DfLogger.debug(IDocsInboxClassic.class, "getDelayedDisclouserStatus :: document object is null", null, null);
						return false;
					}	
				} catch (DfException e) {
					DfLogger.error(IDocsInboxClassic.class, "Exception encountred ...getDelayedDisclouserStatus ::"+e.getMessage(), null, null);
				}
		 	}else{
		 		DfLogger.debug(IDocsInboxClassic.class, "getDelayedDisclouserStatus :: form instance object is null (or) empty (or) nullobject", null, null);
		 			return false;
		 	}	
		}else{
		  return false;
		}
		}else{
		  return false;
		}
		return false;
	}
	public static String DISCLOSURE_FORMVALUE_D = "delayedDisclosure";
	
	protected String[] getInboxAttrForDataHandler(boolean includeDocInfo){
		if(includeDocInfo)
            return s_customAttrs;
        else
            return s_customAttrsNoDocInfo;
    }
	
	public boolean enableHighliting=false;
	private static final String YES = "YES";
	private static final String TYPE = "type";
	private static final String EMPTY_STRING = "";
	private static final String DM_TASK = "dm_task";
	private static final long serialVersionUID = 1L;
	private static final String OBJECT_ID = "objectId";
	private static final String PROJECT_ID = "project_id";
	private static final String MSG_HEADER = "MSG_HEADER";
	private static final String COUNTRY_NME = "country_nme";
	private static final String OBJECT_TYPE = "object_type";
	private static final String OBJECT_NAME = "object_name";
	private static final String R_OBJECT_ID = "r_object_id";
	private static final String ARG_PROJECT_ID = "projectId";
	private static final String DRL_VIEW_ARG = "__drlViewArg";
	private static final String COUNTRY_CODE = "country_code";
	private static final String TASKMANAGER_ID = "taskmanagerId";
	private static final String ARG_COUNTRY_NAME = "countryName";
	private static final String TASKMGRCLASSIC = "taskmgrclassic";
	private static final String ARG_COUNTRY_CODE = "countryCode";
	private static final String ARG_DOCUMENT_TYPE = "documentType";
	private static final String ON_DRL_INBOX_VIEW = "onDrlInboxView";
	private static final String PROJECT_SHORT_NME = "project_short_nme";
	private static final String ARG_PROJECT_SHORT_NAME = "projectShortName";
	private static final String STR_HIGHLITING_ENABLE = "STR_HIGHLITING_ENABLE";
	
	private static String s_customAttrs[] = {
        "taskName", "docNames", "contentType", "itemType",PROJECT_ID,PROJECT_SHORT_NME,OBJECT_NAME,COUNTRY_NME,OBJECT_TYPE,COUNTRY_CODE
    };
    private static String s_customAttrsNoDocInfo[] = {
        "taskName", "contentType", "itemType",PROJECT_ID,PROJECT_SHORT_NME,OBJECT_NAME,COUNTRY_NME,OBJECT_TYPE,COUNTRY_CODE
    }; 
}
