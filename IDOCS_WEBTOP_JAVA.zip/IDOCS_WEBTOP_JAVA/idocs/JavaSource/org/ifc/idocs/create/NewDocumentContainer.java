/**
* 
* This class is NewDocumentContainer custom behaviour class validates user access and also updates the attribute
* fields while clicking next button on UI.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Parag Doshi           12/25/2010	     1.0          Created
* #######################################################################################################
*/
package org.ifc.idocs.create;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.DocumentBuilderFactory;
import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.crrpsr.LinkToGHG;
import org.ifc.idocs.services.ProductAppService;
import org.ifc.idocs.services.TripTemplateService;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.documentum.fc.client.DfAuthenticationException;
import com.documentum.fc.client.DfIdentityException;
import com.documentum.fc.client.DfPrincipalException;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfACL;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfList;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.operations.IDfDeleteOperation;
import com.documentum.operations.IDfDeleteOperationInternal;
import com.documentum.operations.IDfOperationError;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.LocaleService;
import com.documentum.web.form.Control;
import com.documentum.web.form.Form;
import com.documentum.web.form.FormActionReturnListener;
import com.documentum.web.form.control.Text;
import com.documentum.web.form.control.databound.DataDropDownList;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.formext.action.ActionService;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.component.Prompt;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.docbase.ObjectCacheUtil;
import com.documentum.web.formext.session.DocbaseUtils;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import com.documentum.web.util.DfcUtils;
import com.documentum.webcomponent.common.WebComponentErrorService;
import com.documentum.webcomponent.library.attributes.Attributes;
import com.documentum.webcomponent.library.create.NewDocument;

public class NewDocumentContainer extends com.documentum.webcomponent.library.create.NewDocContainer {

    
	private static final String IDOCS_XML_URL = "IDOCS_XML_URL";
	private static final String PRODUCT_DRL_UPDATE_SERVLET_URL = "PRODUCT_DRL_UPDATE_SERVLET_URL";
	private static final String MSG_TRIP_TEMPLATES = "TRIP_TEMPLATES";
	private static final long serialVersionUID = 1L;
	private static final String PROMPT_TITLE_MSG = "Document Creation";
	private static String m_NewDocContainerNlsProp;
 	private String validationError="";
    private String strFolderId = "";
    private String proceed = "";
	private static NlsResourceBundle m_nlsResourceBundle;
    protected String strFolderCategory = "";
    public boolean m_bNeedCreate = false;
    public String docId;
	private static final String MSG_CREATED = "Created";
	private boolean docStatus=false;
	
	private NewDocument component;
	IdocsUtil idocsUtils = new IdocsUtil();
	
	public void onInit(ArgumentList args) {
		try {
			DfLogger.debug(this, " :: onInit : "+getDfSession().getLoginUserName(), null, null);
			super.onInit(args);
			strFolderId=args.get("objectId");
		} catch (DfException e) {
			DfLogger.error(this, " :: onInit Exception >> "+e.getMessage(), null, e);
		}
		m_bNeedCreate = false;
		DfLogger.debug(this, " :: onInit : m_bNeedCreate SET TO " + m_bNeedCreate , null, null);
	}

	/**
	 * This component validates the authenticity of the user to create the document in
	 * the current project.
	 */
	public boolean onNextComponent(Control arg0, ArgumentList args) {
		docStatus=true;
		try {
			DfLogger.debug(this, " :: onNextComponent : m_bNeedCreate IS NOW " + m_bNeedCreate , null, null);
			IDfFolder parentFolder=null;
			IDfSession dfsess = getDfSession();
	        
			DfLogger.debug(this, " :: onNextComponent : "+getDfSession().getLoginUserName(), null, null);
			//Get the Text control and get the typed value
			ArrayList <Component> components = getContainedComponents();
	        component = (NewDocument)components.get(0);
	        Text txtTemplate = (Text)component.getControl("templateName");
	        String strTemplateName = txtTemplate.getInputValue();
	        int tripTemplateCode = idocsUtils.getTemplateCode(getDfSession(),strTemplateName);
	        DfLogger.debug(this," :: onNextComponent : strTemplateName : " + strTemplateName,null,null);  
	        
	        Component currentComponent = getContainedComponent();
            if (currentComponent instanceof org.ifc.idocs.attributes.Attributes){
            	org.ifc.idocs.attributes.Attributes IDocsAttributes = (org.ifc.idocs.attributes.Attributes)currentComponent;
            	int productWorkflowTypeCode = IDocsAttributes.getPdtWfTypeCode();
            	
            	// Validating $ in IOM template
            	if(IdocsUtil.getMessage("MSG_INTERNAL_OFFICE_MEMORANDUM").equals(strTemplateName)) {
            		String exisitingDocName = IDocsAttributes.getDocumentName();
            		DfLogger.debug(this, " :: onNextComponent:: exisitingDocName: " + exisitingDocName, null, null);
            		if (IdocsUtil.isValidIOMObjectName(exisitingDocName) == false) {
            			DfLogger.info(this, "exisitingDocName: contains $ symbol", null, null);
            			Object params[] = new Object[1];
           			 	params[0] = IDocsConstants.MSG_EMPTY_STRING;
           			 	WebComponentErrorService.getService().setNonFatalError(this, "MSG_DOLLAR_CHAR_VALIDATION", params, null);
           			 	return false;
            		}
            	}
            	
            	/*if( tripTemplateCode == Integer.parseInt(IdocsUtil.getMessage("MSG_DONORTEMPLATE_CODE"))
						|| tripTemplateCode == Integer.parseInt(IdocsUtil.getMessage("MSG_CONSULTANTREPORTTEMPLATE_CODE"))
					|| tripTemplateCode == Integer.parseInt(IdocsUtil.getMessage("MSG_TAPPTEMPLATE_CODE")) ){*/
            	String strTripTemplateNames = IdocsUtil.getMessage(MSG_TRIP_TEMPLATES);
   			 	DfLogger.debug(this, " :: onNextComponent : strTripTemplateNames :" + strTripTemplateNames,null,null);
   			 	if (IdocsUtil.checkIfTokenPresent(strTripTemplateNames, strTemplateName, IdocsConstants.MSG_COMMA)){
					String submission_nubr =  IDocsAttributes.getSelectedSubmissionNbr();
					DfLogger.debug(this, " :: onNextComponent : for submission Number : " +submission_nubr, null, null);
					if(submission_nubr !=null && submission_nubr.trim().length() > 0){
						DfLogger.debug(this, " :: onNextComponent: Submission Number Selected " +submission_nubr + " Proceed Creation", null, null);
						return super.onNextComponent(arg0, args);
					}else{
						validationError=IdocsUtil.getMessage("MSG_TRIP_SELECT_VALIDATION");							 
		            	Object params[] = new Object[1];             
		            	params[0] = DocbaseUtils.getValidationExceptionMsg(new DfException(validationError));			            	   	
		            	WebComponentErrorService.getService().setNonFatalError(this, "MSG_VALIDATION_ERROR", params, null);
						return false;
					}
            	}else if(IdocsUtil.ifProductIntegrationRequired(strTemplateName)){
            		//Hidden hdWfNbr = (Hidden)getControl(IDocsConstants.SELECTED_WF_NBR_HIDDEN,Hidden.class); 
					//String strSelectedWfNbr = hdWfNbr.getValue();			
            		String strSelectedWfNbr = IDocsAttributes.getSelectedWfNbr();
            		DfLogger.debug(this, " :: onNextComponent :: strSelectedWfNbr : " +strSelectedWfNbr, null, null);
					if(strSelectedWfNbr != null && strSelectedWfNbr.trim().length() > 0){
						DfLogger.debug(this, " :: onNextComponent: Workflow Number Selected " +strSelectedWfNbr + " Proceed Creation", null, null);
						return super.onNextComponent(arg0, args);
					}else{
						validationError=IdocsUtil.getMessage("MSG_WF_SELECT_VALIDATION");							 
		            	Object params[] = new Object[1];             
		            	params[0] = DocbaseUtils.getValidationExceptionMsg(new DfException(validationError));			            	   	
		            	WebComponentErrorService.getService().setNonFatalError(this, "MSG_VALIDATION_ERROR", params, null);
						return false;						
					}            		
            	}else{
            		return super.onNextComponent(arg0, args);
            	}
            	
            }			        
	        
	        parentFolder = getParentFolder(dfsess, strFolderId);
	       	        
	        strFolderCategory = parentFolder.getString("folder_category");
	        
	        DfLogger.debug(this," :: onNextComponent : strFolderCategory : " + strFolderCategory,null,null);
	        
	        boolean validateTemplate=validateTemplate(strTemplateName, parentFolder.getTypeName());
	        if (validateTemplate == false) {
	            Object params[] = new Object[1];
	            params[0] = getDetailsMessage(new DfException(validationError));
	        	WebComponentErrorService.getService().setNonFatalError(this, "MSG_VALIDATION_ERROR", params, null);
	        	return false;
	        }
	       
	        boolean validateUserAccess=true;
	        String strTemplateFullName="";
	
	        if (parentFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_PROJ_FOLDER", LocaleService.getLocale()))) {
	        	DfLogger.debug(this, " :: onNextComponent : for Project Document",null,null);
	        	String currentProjectId = parentFolder.getString("project_id");
	        	String projectStatusId = parentFolder.getString("project_status_code");
	        	
	        	// Document creation is not allowed to user present in Conflict Of Interest group
	        	if(IdocsUtil.isUserPresentInConflictOfInterest(currentProjectId,getDfSession()) || IdocsUtil.isUserMemberofLDAPGroup(
						 IdocsUtil.getMessage(IdocsConstants.CONFLICT_OF_INTEREST_ROLE), currentProjectId, getDfSession())){
	        		DfLogger.info(this," :: onNextComponent:: User is Present in Conflict Of Interest", null, null);
	        		proceed = "N";
	        		ArgumentList promptArguments = new ArgumentList();
	        		promptArguments.add(Prompt.ARG_TITLE, PROMPT_TITLE_MSG);
	        		promptArguments.add(Prompt.ARG_MESSAGE, IdocsUtil.getMessage("COI_ROLE_CREATE_ERROR_MESSAGE"));
	        		promptArguments.add(Prompt.ARG_BUTTON, new String[]{Prompt.OK});
	        		setComponentNested(IDocsConstants.MSG_IDOCS_PROMPT_COMPONENT, promptArguments, getContext(),
	        				new FormActionReturnListener(this, "onReturnFromPromptInput"));
	        	}
	        	int prductWorkflowCode = idocsUtils.getProductTypeCode(getDfSession(), strTemplateName);
	        	DfLogger.debug(this, " :: onNextComponent : projectStatusId: " + projectStatusId, null, null);
	        	if (projectStatusId != null && projectStatusId.trim().length() >0  && 
	        			 projectStatusId.equalsIgnoreCase("X")){ 
	        		 proceed = "N";
	        		 ArgumentList promptArguments = new ArgumentList();
	        		 promptArguments.add(Prompt.ARG_TITLE, PROMPT_TITLE_MSG);
	        		 promptArguments.add(Prompt.ARG_MESSAGE, m_nlsResourceBundle.getString("ENVT_CATEGORY_MSG_X",
								LocaleService.getLocale()));
	     			
	        		 promptArguments.add(Prompt.ARG_BUTTON, new String[]{Prompt.OK});
	     			setComponentNested(IDocsConstants.MSG_IDOCS_PROMPT_COMPONENT, promptArguments, getContext(
	     			), new FormActionReturnListener(
	     			this, "onReturnFromPromptInput"));
	        	 }else{
	        		 //Validate User Access based on their project role
	        		 validateUserAccess = validateProjUserAccess(getDfSession(), strTemplateName, 
	        				 				parentFolder.getString(m_nlsResourceBundle.getString("MSG_PROJECT_ID", LocaleService.getLocale())));
	
	        		 if(!validateUserAccess) {
	        			 Object params[] = new Object[1];
	        			 params[0] = getDetailsMessage(new DfException(validationError));
	        			 WebComponentErrorService.getService().setNonFatalError(this, "MSG_VALIDATION_ERROR", params, null);
	        			 return false;
	        		 }
	        		 // To restrict creation of product workflow templates from IFCDocs
	        		 if(IdocsUtil.isProductTemplate(strTemplateName)) {
	        			 String templateType = null;
	        			 if (strTemplateName.equals(IdocsUtil.getMessage("MSG_TEMPLATE_REVISED_MAM_APPROVAL"))) {
	        				 templateType = IDocsConstants.MSG_TYPE_PRODUCT;
	        			 } else if (strTemplateName.equals(IdocsUtil.getMessage("MSG_TEMPLATE_PDS_COMMITMENT"))) {
	        				 templateType = IDocsConstants.MSG_TYPE_COMMITMENT;
	        			 } else if (strTemplateName.equals(IdocsUtil.getMessage("MSG_TEMPLATE_PDS_FIRST_DISBURSEMENT")) ||
	        					 strTemplateName.equals(IdocsUtil.getMessage("MSG_TEMPLATE_PDS_SUBSEQ_DISBURSEMENT"))){
	        				 templateType = IDocsConstants.MSG_TYPE_DISBURSEMENT;
	        			 } else if (strTemplateName.equals(IdocsUtil.getMessage("MSG_TEMPLATE_CANCELLATION_MEMO")) ||
	        					 strTemplateName.equals(IdocsUtil.getMessage("MSG_TEMPLATE_COMMITMENT_TRANSFER_MEMO")) ||
	        					 strTemplateName.equals(IdocsUtil.getMessage("MSG_TEMPLATE_DROPPAGE_MEMO"))) {
	        				 templateType = IDocsConstants.MSG_TYPE_ADJUSTMENT;
	        			 } else if (strTemplateName.equals(IdocsUtil.getMessage("MSG_TEMPLATE_PDS_SIGNING"))){
	        				 templateType = IDocsConstants.MSG_EMPTY_STRING;
	        			 } else {
	        				 DfLogger.debug(this, " :: onNextComponent : Not a Product template: ", null, null);
	        				 return true;
	        			 }
	        			 validationError = m_nlsResourceBundle.getString("MSG_RESTRICT_PRODUCT_TEMPLATE_CREATION",new String[] {templateType}, LocaleService.getLocale());
	        			 DfLogger.info(this, " :: onNextComponent : validationError: " + validationError,null,null);
	        			 Object params[] = new Object[1]; 
						 params[0] = getDetailsMessage(new DfException(validationError));
	 		           	 WebComponentErrorService.getService().setNonFatalError(this, "MSG_VALIDATION_ERROR", params, null);
	 					 return false;	
	        			 
	        		 }
	        		 
	        		 strTemplateFullName = parentFolder.getString(m_nlsResourceBundle.getString("MSG_PROJECT_ID",
	        				 									LocaleService.getLocale()))+"_"+strTemplateName;
	        		 /** Execute the special validation for SPI and ESRS */
	        		 triggerSPIESRSValidation(arg0, args, parentFolder, strTemplateName);
	        		 /** Execute the GHG validation check for GHG enabled templates */
	        		 boolean ghgValidation = true;
	        		 boolean useConfirmationFlag =true;
	        		 boolean waiverCheckFlag = true;
	        		 boolean productTemplateValidation = true;
	        		 boolean tripValidation = true;
	        		 
	        		 if (ghgValidation ) {
	        			 ghgValidation = triggerGHGValidationCheck(currentProjectId, tripTemplateCode, getDfSession(), strTemplateName);
	        		 }
	        		 
	        		//*************************************************************************************** 
	        		 //Start of Modification done for Product Integration......................................
	        		 /** Check the value selected for Product Grid and Validate the Creation */
	        		 if (ghgValidation && productTemplateValidation) {
	        			 productTemplateValidation = validateProductTemplate(parentFolder, strTemplateName);
	        		 }
	        		 
	        		 /** Check the value selected for TRIP Grid and Validate the Creation */
	        		 if (ghgValidation &&  productTemplateValidation && tripValidation ) {
	        			 tripValidation = validateTripSubmission(parentFolder, strTemplateName);
	        		 }
	        		 
	        		 /** Show the extra validation /COnfirmation Message for selected templates */
	        		 if( ghgValidation && productTemplateValidation && tripValidation && useConfirmationFlag) {
	        			 String userConfirmationMessagearray[] = getUtilizationDetails(prductWorkflowCode,currentProjectId);
		        		 useConfirmationFlag = showUserConfirmationMessage(parentFolder, strTemplateName,userConfirmationMessagearray);
	        		 }
	        		 
	        		 // Displays confirmation message to user for Financial Waiver Write-Off Memorandum-Prior To Handover
	        		 // and Financial Waiver Write-Off Memorandum-Prior To Handover templates
	        		 if (ghgValidation && productTemplateValidation && tripValidation && useConfirmationFlag && waiverCheckFlag) {
	        			 waiverCheckFlag = showFinancialWaiverWriteOffTemplateConfirmation(strTemplateName);
	        		 }	        			        		 
	        	 } 
	            //End of Modification done for Product Integration......................................
	          //*************************************************************************************** 
	        }else if(parentFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_INSTIT_FOLDER", LocaleService.getLocale()))){
	        	DfLogger.debug(this, " :: onNextComponent : for Institution Document",null,null);
	        	//Can validate User Access based on their institution role
	            strTemplateFullName=parentFolder.getString(m_nlsResourceBundle.getString("MSG_INSTIT_NBR", LocaleService.getLocale()))+"_"+strTemplateName;
	        }else{
	        	DfLogger.debug(this, " :: onNextComponent : for Country Document",null,null);
	        	//Can validate User Access based on their country role
	            strTemplateFullName=parentFolder.getString(m_nlsResourceBundle.getString("MSG_COUNTRY_CODE", LocaleService.getLocale()))+"_"+strTemplateName;
	        }
	       
	        
	        /*
             * This code is checking for only Advisory Service Templates 
             */
            if(IdocsUtil.isAdvisoryTemplate(strTemplateName)){
            	
              	String projectID = parentFolder.getString(m_nlsResourceBundle.getString("MSG_PROJECT_ID", LocaleService.getLocale()));
                DfLogger.debug(this," :: Project id::  " + projectID,null,null);
                //StringBuffer asDocumentName = new StringBuffer(projectID).append("_").append(strTemplateName);
				HttpServletRequest servletRequest = (HttpServletRequest) getPageContext().getRequest();
                HashMap<String,String> advisoryValidationMap= new ASOPCreateDocService().forAdvisoryServicesTemplatesForNewDocContainer(strTemplateName, projectID, component, getDfSession(), servletRequest);
                return false;
              }
            
            /** Set the Object Name and Selected Template Name */
            DfLogger.debug(this," :: strTemplateFullName::  " + strTemplateFullName,null,null);
            setTemplateListnObjectName(strTemplateName, strTemplateFullName);
	        super.onNextComponent(arg0, args);
	        String strNewObjectId = component.getNewObjectId();
	        DfLogger.debug(this, " :: onNextComponent : fstrNewObjectId: " + strNewObjectId,null,null);
	        /** Attache LifeCycle to the Newly Created Document */
	        attachPolicy(dfsess, strNewObjectId);
            DfLogger.debug(this, " :: onNextComponent : Document Created Successfully ",null,null);
		}catch(DfException e){
    		DfLogger.error(this, " :: onNextComponent Exception >>> "+e.getMessage(),null,null);
		}
        return true;
	}
	
	
	
	/**
	 * 
	 * @param prductWorkflowCode
	 * @param currentProjectId
	 * @return
	 */
	private String[] getUtilizationDetails(int prductWorkflowCode, String currentProjectId) {
		String strIdocsUrl = null;
		try {
			strIdocsUrl = IdocsUtil.getIdocsConfigInfoValue(getDfSession(), IDOCS_XML_URL);
			if(strIdocsUrl != null && strIdocsUrl.trim().length() > 0){
				StringBuilder servletURL = new StringBuilder(strIdocsUrl);
				servletURL.append(IdocsConstants.PROJ_ID).append("=");
				servletURL.append(currentProjectId);
				servletURL.append("&").append(IdocsConstants.WORKFLOW_TYPE_CODE).append("=");
				servletURL.append(prductWorkflowCode);
				String xmlURL=servletURL.toString();
				DfLogger.debug(this,": getUtilizationDetails() :: xmlURL : "+xmlURL,null,null);	
				
				DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
				javax.xml.parsers.DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
				InputSource source = new InputSource(xmlURL);
				Document docObj = docBuilder.parse(source);
				DfLogger.debug(this, ":  xmlURL : " + xmlURL, null, null);
				NodeList indicatorNde = docObj.getElementsByTagName("data");
				int nodelength = indicatorNde.getLength();
				
				String ceilingAmount = IDocsConstants.MSG_EMPTY_STRING;
			    String utilizationAmount = IDocsConstants.MSG_EMPTY_STRING;
			    String fiscalYear = IDocsConstants.MSG_EMPTY_STRING;
			    
				for (int s = 0; s < nodelength; s++) {
					Node productNodeType = indicatorNde.item(s);
					if (productNodeType.getAttributes().getNamedItem("field").getNodeValue().equals("ceilingamount")) {
						ceilingAmount = productNodeType.getTextContent(); 
						DfLogger.debug(this,": SDT Attribute ceilingAmount Value : "+productNodeType.getTextContent(),null,null);
					} else if (productNodeType.getAttributes().getNamedItem("field").getNodeValue().equals("utilizationamount")) {
						utilizationAmount = productNodeType.getTextContent(); 
						DfLogger.debug(this,": SDT Attribute utilizationAmount Value : "+productNodeType.getTextContent(),null,null);
					} else if (productNodeType.getAttributes().getNamedItem("field").getNodeValue().equals("fiscalyear")) {
						fiscalYear = productNodeType.getTextContent(); 
						DfLogger.debug(this,": SDT Attribute fiscalYear Value : "+productNodeType.getTextContent(),null,null);
					}
				}
				return new String[]{fiscalYear,ceilingAmount,utilizationAmount};
			}				
		} catch (DfException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * This method handles confirmation logic for Financial Waiver Write-Off Memorandum-Prior To Handover
	 * and Financial Waiver Write-Off Memorandum-Prior To Handover templates
	 * @param parentFolder
	 * @param strTemplateName
	 */

	private boolean showFinancialWaiverWriteOffTemplateConfirmation(String strTemplateName) {
		
		String templateFinancialWaiverWriteOff = m_nlsResourceBundle.getString("TEMPLATE_FINANCIAL_WAIVER_WRITEOFF", LocaleService.getLocale());
		String[] financialWaiverWriteOffArray = templateFinancialWaiverWriteOff.split(IdocsConstants.MSG_COMMA);
		List templatesAL = Arrays.asList(financialWaiverWriteOffArray);
		if(templatesAL.contains(strTemplateName)) {
		 	 DfLogger.debug(this, " :: showFinancialWaiverWriteOffTemplateConfirmation : strTemplateName: "+strTemplateName, null, null);
			 proceed = "Y";
			 ArgumentList promptArguments = new ArgumentList();
			 promptArguments.add(Prompt.ARG_TITLE, PROMPT_TITLE_MSG);
			 promptArguments.add(Prompt.ARG_ICON, Prompt.ICON_QUESTION);
			 promptArguments.add(Prompt.ARG_MESSAGE,	m_nlsResourceBundle.getString("FINANCIAL_WAIVER_WRITEOFF_MSG", LocaleService.getLocale()));
			 promptArguments.add(Prompt.ARG_BUTTON, new String[] { Prompt.OK, Prompt.CANCEL });
			 setComponentNested(IDocsConstants.MSG_IDOCS_PROMPT_COMPONENT, promptArguments, getContext(),
					 new FormActionReturnListener(this, "onReturnFromPromptInput"));
			 return false;
		 }
		return true;
	}

	private boolean triggerGHGValidationCheck(String currentProjectId,
			int tripTemplateCode, IDfSession dfSession, String strTemplateName) {
		if(LinkToGHG.isGHGCheckValidForDocument(currentProjectId, String.valueOf(tripTemplateCode), dfSession, strTemplateName) == false){
			/** STOP Creation GHG Emission entry Or Emission Estimation Not available in IDES */
			DfLogger.debug(this, " :: triggerGHGValidationCheck : GHG Check Failed. Stop Creation ",null,null);
			proceed = "N";
			ArgumentList promptArguments = new ArgumentList();
			promptArguments.add(Prompt.ARG_TITLE,"Document Creation");
			promptArguments.add(Prompt.ARG_MESSAGE,m_nlsResourceBundle.getString("GHG_EMISSION_ESTIMATION_NOT_AVAILABLE",
					LocaleService.getLocale()));
			promptArguments.add(Prompt.ARG_BUTTON,new String[] { Prompt.OK });
			setComponentNested(IDocsConstants.MSG_IDOCS_PROMPT_COMPONENT,promptArguments, getContext(),
					new FormActionReturnListener(this,"onReturnFromPromptInput"));
			return false;
		}else{
			DfLogger.debug(this, " :: triggerGHGValidationCheck : GHG Check is Validated ",null,null);
		}
		return true;
	}

	/**
	 * 
	 * @param arg0
	 * @param args
	 * @param parentFolder
	 * @param strTemplateName
	 */
	private void triggerSPIESRSValidation(Control arg0, ArgumentList args,
			IDfFolder parentFolder, String strTemplateName) {
		// Validate ESRS and SPI templates
		 String templateESRS = m_nlsResourceBundle.getString("TEMPLATE_ESRS", LocaleService.getLocale());
		 String templateSPI = m_nlsResourceBundle.getString("TEMPLATE_SPI", LocaleService.getLocale());
		 String templateSII = m_nlsResourceBundle.getString("TEMPLATE_SII", LocaleService.getLocale());
		 if(strTemplateName.equals(templateESRS) ||	strTemplateName.equals(templateSPI) || strTemplateName.equals(templateSII)) {
			 validateESRSAndSPITemplates(strTemplateName, parentFolder, templateESRS, templateSPI, templateSII, arg0, args);
		 }
	}

	/**
	 * 
	 * @param strTemplateName
	 * @param strTemplateFullName
	 * @throws DfException
	 */
	private void setTemplateListnObjectName(String strTemplateName,
		String strTemplateFullName) throws DfException {
		Text txtDocObjName = (Text)component.getControl("attribute_object_name");
		txtDocObjName.setValue(strTemplateFullName);
		DfLogger.debug(this, " :: setTemplateListnObjectName : strTemplateFullName: "+strTemplateFullName,null,null);
		//Get the r_object_id of template stored and set as the selected value of template list which is hidden
		//String strTemplateObjectId = getTemplateId(strTemplateName);
		String strTemplateObjectId = getDocumentId();
		DataDropDownList templateList = (DataDropDownList)component.getControl("templateList", DataDropDownList.class);
		templateList.setValue(strTemplateObjectId);
		
		DfLogger.debug(this, " :: setTemplateListnObjectName : strTemplateObjectId: "+strTemplateObjectId,null,null);
		//DfLogger.debug(this, " :: setTemplateListnObjectName : strTemplateObjectIdTemp: "+strTemplateObjectIdTemp,null,null);
	}

	/**
	 * This method attaches the lifecycle to the newly created document
	 * @param dfsess
	 * @param strNewObjectId
	 * @throws DfException
	 */
	private void attachPolicy(IDfSession dfsess, String strNewObjectId)
			throws DfException {
		IDfDocument newDoc = (IDfDocument)getDfSession().getObject(new DfId(strNewObjectId));
		DfLogger.debug(this, " :: attachPolicy : r_policy_id : "+newDoc.getString("r_policy_id"),null,null);
		if(newDoc.getString("r_policy_id").equals("0000000000000000")){
			DfLogger.debug(this, "attachPolicy :: If label : "+newDoc.getString("r_version_label"),null,null);
		    StringBuffer strBuff = new StringBuffer(64);
		    strBuff.append("dm_policy where object_name='").append(IDocsConstants.MSG_IDOCS_LIFECYCLE).append("'");
		    com.documentum.fc.common.IDfId policyId = dfsess.getIdByQualification(strBuff.toString());
		    if(policyId!=null){
		    	DfLogger.debug(this, "attachPolicy :: LifeCycle : "+policyId.getId(),null,null);
		    }else{
		    	DfLogger.debug(this, "attachPolicy :: LifeCycle NOT FOUND :strBuff="+strBuff,null,null);	
		    }
		    newDoc.attachPolicy(policyId, "0", "");
			 DfLogger.debug(this, " :: attachPolicy : LifeCycle '"+IDocsConstants.MSG_IDOCS_LIFECYCLE+"' is attached with Stage '",null,null);
		}else{
			DfLogger.debug(this, " :: attachPolicy : Else",null,null);
		}
	}

	/**
	 * This method handles validation logic for TRIP templates
	 * @param parentFolder
	 * @param strTemplateName
	 * @throws DfException
	 */
	private boolean validateTripSubmission(IDfFolder parentFolder,
			String strTemplateName) throws DfException {
		int template_code = idocsUtils.getTemplateCode(getDfSession(),strTemplateName);	
		DfLogger.debug(this, " :: validateTripSubmission : strTemplateName :" + strTemplateName,null,null);
		 String strTripTemplateNames = IdocsUtil.getMessage(MSG_TRIP_TEMPLATES);
		 DfLogger.debug(this, " :: validateTripSubmission : strTripTemplateNames :" + strTripTemplateNames,null,null);
		 /*if( template_code == Integer.parseInt(IdocsUtil.getMessage("MSG_DONORTEMPLATE_CODE"))
				|| template_code == Integer.parseInt(IdocsUtil.getMessage("MSG_CONSULTANTREPORTTEMPLATE_CODE"))
				|| template_code == Integer.parseInt(IdocsUtil.getMessage("MSG_TAPPTEMPLATE_CODE"))){*/
		 if (IdocsUtil.checkIfTokenPresent(strTripTemplateNames, strTemplateName, IdocsConstants.MSG_COMMA)){
			 ArrayList <Component> containedComps = getAllContainedComponents();
			 if (null != containedComps && containedComps.size()>1) {
				Attributes attrComp = (Attributes)containedComps.get(1);
				Datagrid tripDatagrid = (Datagrid)attrComp.getControl(IDocsConstants.TEMPLATE_DATAGRID);
				TripTemplateService tripService = new TripTemplateService();
				String strProjectID = parentFolder.getString(m_nlsResourceBundle.getString("MSG_PROJECT_ID", LocaleService.getLocale()));
				if(tripDatagrid==null) {
					tripDatagrid = (Datagrid)attrComp.createControl(IDocsConstants.TEMPLATE_DATAGRID, Datagrid.class);
				 }
				DfLogger.debug(this, " :: validateTripSubmission : strTemplateName :" + strTemplateName,null,null);
				tripDatagrid  = tripService.getTripGridDetails(getDfSession(),strProjectID,template_code,tripDatagrid,strTemplateName);

				if (tripDatagrid == null || tripDatagrid.getDataProvider().getResultsCount()<1) {
//	        					 validationError=tripService.getValidationMsg();
					String strValidationMessage = m_nlsResourceBundle.getString("ERR_NO_SUBMISSION_NUMBER", LocaleService.getLocale());
					strValidationMessage.concat(strProjectID);
					DfLogger.debug(this, " :: validateTripSubmission : strValidationMessagel :"+ strValidationMessage,null,null);
					proceed = "N";
					 ArgumentList promptArguments = new ArgumentList();
					 promptArguments.add(Prompt.ARG_TITLE, PROMPT_TITLE_MSG);
					 promptArguments.add(Prompt.ARG_MESSAGE, strValidationMessage);
					 promptArguments.add(Prompt.ARG_BUTTON, new String[] { Prompt.OK });
					 setComponentNested(IDocsConstants.MSG_IDOCS_PROMPT_COMPONENT, promptArguments, getContext(),
							 new FormActionReturnListener(this, "onReturnFromPromptInput"));
					 return false;
				 }else {
					 DfLogger.debug(this, " :: validateTripSubmission : tripDatagrid is not null :"+ tripDatagrid.getDataProvider().getResultsCount(),null,null);
				 }	        			
			 }	        			 	 					
		}else{
			DfLogger.debug(this, " :: validateTripSubmission: Not a TRIP Template Document : ", null, null);
		}
		 return true;
	}

	/**
	 * This method handles validation logic for product based templates
	 * @param parentFolder
	 * @param strTemplateName
	 * @throws DfException
	 */
	private boolean validateProductTemplate(IDfFolder parentFolder,
			String strTemplateName) throws DfException {
		int pdtWfTypeCode = idocsUtils.getProductTypeCode(getDfSession(),strTemplateName);
		DfLogger.debug(this, " :: validateProductTemplate : pdtWfTypeCode :" + pdtWfTypeCode,null,null);
		//		 if(pdtWfTypeCode > Integer.parseInt(IdocsUtil.getMessage("MSG_FIRST_VALID_PROD_WF_CODE"))) {
		if(IdocsUtil.ifProductIntegrationRequired(strTemplateName)) {
			String templateRightsIssue = IdocsUtil.getMessage("MSG_RIGHTS_ISSUE_TEMPLATE_TITLE");
			String rightIssueRestrictedTemplates = IdocsUtil.getMessage("MSG_RIGHTS_ISSUE_RESTRICTED_TEMPLATES"); 
			String strProjSubCategory = parentFolder.getString(IDocsConstants.MSG_PROJECT_SUB_CATEGORY_NME);
			if(templateRightsIssue!=null && templateRightsIssue.trim().length() > 0
					&& strProjSubCategory !=null && strProjSubCategory.trim().length() > 0
					&& templateRightsIssue.equals(strProjSubCategory)
					&& rightIssueRestrictedTemplates!=null && rightIssueRestrictedTemplates.trim().length() > 0
					&& IdocsUtil.checkIfTokenPresent(rightIssueRestrictedTemplates, strTemplateName, IdocsConstants.MSG_COMMA)){
				proceed = "N";
				ArgumentList promptArguments = new ArgumentList();
				promptArguments.add(Prompt.ARG_TITLE, PROMPT_TITLE_MSG);
				promptArguments.add(Prompt.ARG_MESSAGE, m_nlsResourceBundle.getString("MSG_NOT_ALLOWED_CAT_RIGHT_ISSUE", LocaleService.getLocale()));
				promptArguments.add(Prompt.ARG_BUTTON, new String[] { Prompt.OK});
				setComponentNested(IDocsConstants.MSG_IDOCS_PROMPT_COMPONENT, promptArguments, getContext(),
						new FormActionReturnListener(this, "onReturnFromPromptInput"));
				return false; 
			}
			DfLogger.debug(this, " :: validateProductTemplate : In Outer IF :",null,null);
			ArrayList <Component> containedComps = getAllContainedComponents();
			if (null != containedComps && containedComps.size()>1) {
				DfLogger.debug(this, " :: validateProductTemplate : containedComps.size() :"+ containedComps.size(),null,null);
				Attributes attrComp = (Attributes)containedComps.get(1);
				Datagrid productGrid = (Datagrid)attrComp.getControl("productgrid");

				ProductAppService pdtAppService = new ProductAppService();
				String strProjectID = parentFolder.getString(m_nlsResourceBundle.getString("MSG_PROJECT_ID", LocaleService.getLocale()));

				if(productGrid==null) {
					productGrid = (Datagrid)attrComp.createControl("productgrid", Datagrid.class);
				}
				//boolean isPdtDataPresent
				//strProjectID = "21422" 27294-uganda;
				productGrid = pdtAppService.getProductWfDetails(getDfSession(), strProjectID, pdtWfTypeCode, productGrid);
				//DfLogger.debug(this, " :: onNextComponent : productGrid: RESULT COUNT :"+ productGrid.getDataProvider().getResultsCount(),null,null);
				if (productGrid == null || productGrid.getDataProvider().getResultsCount()<1) {
					validationError=pdtAppService.getValidationMsg();
					proceed = "N";
					ArgumentList promptArguments = new ArgumentList();
					promptArguments.add(Prompt.ARG_TITLE, PROMPT_TITLE_MSG);
					promptArguments.add(Prompt.ARG_MESSAGE, validationError);
					promptArguments.add(Prompt.ARG_BUTTON, new String[] { Prompt.OK});
					setComponentNested(IDocsConstants.MSG_IDOCS_PROMPT_COMPONENT, promptArguments, getContext(),
							new FormActionReturnListener(this, "onReturnFromPromptInput"));
					return false;
				}
				else {
					DfLogger.debug(this, " :: validateProductTemplate : productGrid is not null :"+ productGrid.getDataProvider().getResultsCount(),null,null);
				}	        			
			}


		}
		return true;
	}

	/**
	 * This method handles validation logic for MAM for Risk Management Products
	 * and B-Loan Increase templates
	 * @param parentFolder
	 * @param strTemplateName
	 * @throws DfException
	 */
	private boolean showUserConfirmationMessage(IDfFolder parentFolder,
			String strTemplateName,String[] utilisationDetails) throws DfException {
		// Validating MAM for Risk Management Products and B-Loan Increase templates
		 String templateMAM_RMP = IdocsUtil.getMessage("MSG_TEMPLATE_MAM_RMP");
		 String templateBLoan = IdocsUtil.getMessage("MSG_TEMPLATE_BLOAN");
		 String templateRightsIssue = IdocsUtil.getMessage("MSG_RIGHTS_ISSUE_TEMPLATE_TITLE");
		 if ((strTemplateName.equals(templateMAM_RMP)) 
				 || (IdocsUtil.checkIfTokenPresent(templateBLoan, strTemplateName, IdocsConstants.MSG_COMMA)) 
				 || (strTemplateName.equals(templateRightsIssue))) {
			 String fldrPrjSubCategory = parentFolder.getString(IDocsConstants.MSG_PROJECT_SUB_CATEGORY_NME);
			 DfLogger.debug(this, " :: showUserConfirmationMessage : Project Sub Category of selected folder: " + fldrPrjSubCategory, null, null); 
			 String validatePrjSubCategories = m_nlsResourceBundle.getString("VALIDATE_PRJ_SUB_CATEGORY_NAMES", LocaleService.getLocale());
			 String[] prjSubCategoryArray = validatePrjSubCategories.split(IdocsConstants.MSG_COMMA);
			 List prjSubCategoryAL = Arrays.asList(prjSubCategoryArray);
			 if(prjSubCategoryAL.contains(fldrPrjSubCategory)) {
				 DfLogger.debug(this, " :: showUserConfirmationMessage : validation of project sub category is  successfull ", null, null); 
				 if (strTemplateName.equals(templateMAM_RMP)) {
					 DfLogger.debug(this, " :: showUserConfirmationMessage : strTemplateName: "+strTemplateName, null, null);
					 DfLogger.debug(this, " :: showUserConfirmationMessage : templateMAM_RMP: "+templateMAM_RMP, null, null);
					 proceed = "Y";
					 ArgumentList promptArguments = new ArgumentList();
					 promptArguments.add(Prompt.ARG_TITLE, PROMPT_TITLE_MSG);
					 promptArguments.add(Prompt.ARG_ICON, Prompt.ICON_QUESTION);
					 promptArguments.add(Prompt.ARG_MESSAGE,	m_nlsResourceBundle.getString("MAM_MSG", LocaleService.getLocale()));
					 promptArguments.add(Prompt.ARG_BUTTON, new String[] { Prompt.OK, Prompt.CANCEL });
					 setComponentNested(IDocsConstants.MSG_IDOCS_PROMPT_COMPONENT, promptArguments, getContext(),
							 new FormActionReturnListener(this, "onReturnFromPromptInput"));
					 return false;
				 } else if (IdocsUtil.checkIfTokenPresent(templateBLoan, strTemplateName, IdocsConstants.MSG_COMMA)) {
					 DfLogger.debug(this, " :: showUserConfirmationMessage : proceeding for B-Loan  template creation", null, null);
					 proceed = "Y";
					 ArgumentList promptArguments = new ArgumentList();
					 promptArguments.add(Prompt.ARG_TITLE, PROMPT_TITLE_MSG);
					 promptArguments.add(Prompt.ARG_ICON, Prompt.ICON_QUESTION);
					 String bLoanMsg = m_nlsResourceBundle.getString("BLOAN_MSG1", LocaleService.getLocale()) + m_nlsResourceBundle.getString("BLOAN_MSG2",utilisationDetails, LocaleService.getLocale());
					 promptArguments.add(Prompt.ARG_MESSAGE,	bLoanMsg);
					 promptArguments.add(Prompt.ARG_BUTTON, new String[] { Prompt.OK, Prompt.CANCEL });
					 setComponentNested(IDocsConstants.MSG_IDOCS_PROMPT_COMPONENT, promptArguments, getContext(),
							 new FormActionReturnListener(this, "onReturnFromPromptInput"));
					 return false;
				 }else if (strTemplateName.equals(templateRightsIssue)) {
					 DfLogger.debug(this, " :: showUserConfirmationMessage : proceeding for Rights Issue  template creation", null, null);
					 proceed = "Y";
					 ArgumentList promptArguments = new ArgumentList();
					 promptArguments.add(Prompt.ARG_TITLE, PROMPT_TITLE_MSG);
					 promptArguments.add(Prompt.ARG_ICON, Prompt.ICON_QUESTION);
					 promptArguments.add(Prompt.ARG_MESSAGE,	m_nlsResourceBundle.getString("RIGHTS_ISSUE_MSG",utilisationDetails, LocaleService.getLocale()));
					 promptArguments.add(Prompt.ARG_BUTTON, new String[] { Prompt.OK, Prompt.CANCEL });
					 setComponentNested(IDocsConstants.MSG_IDOCS_PROMPT_COMPONENT, promptArguments, getContext(),
							 new FormActionReturnListener(this, "onReturnFromPromptInput"));
					 return false;
				 } else {
					 DfLogger.debug(this, " :: showUserConfirmationMessage : proceeding for template creation which is other than MAM/B-Loan/Rights Issue", null, null);
				 }
			 } else {
				 DfLogger.debug(this, " :: showUserConfirmationMessage : validation of project sub category is  unsuccessfull ", null, null); 
				 proceed = "N";
				 ArgumentList promptArguments = new ArgumentList();
				 promptArguments.add(Prompt.ARG_TITLE, PROMPT_TITLE_MSG);
				 promptArguments.add(Prompt.ARG_ICON, Prompt.ICON_WARNING);
				 promptArguments.add(Prompt.ARG_MESSAGE,	m_nlsResourceBundle.getString("VALIDATE_PRJ_SUB_CATEGORY", LocaleService.getLocale()));
				 promptArguments.add(Prompt.ARG_BUTTON, new String[] { Prompt.OK });
				 setComponentNested(IDocsConstants.MSG_IDOCS_PROMPT_COMPONENT, promptArguments, getContext(),
						 new FormActionReturnListener(this, "onReturnFromPromptInput"));
				 return false;
			 }
		 }
		 return true;
	}

	/**
	 * 
	 * @param dfsess
	 * @param strFolderId
	 * @return
	 * @throws DfException
	 */
	private IDfFolder getParentFolder(IDfSession dfsess, String strFolderId)
			throws DfException {
		IDfFolder docFolder =(IDfFolder) ObjectCacheUtil.getObject(getDfSession(), strFolderId);
		IDfFolder parentFolder;
		if (docFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_PROJ_FOLDER", LocaleService.getLocale())) || 
				docFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_INSTIT_FOLDER", LocaleService.getLocale())) || 
				docFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_COUNTRY_FOLDER", LocaleService.getLocale()))) {
			
		    parentFolder = docFolder;
		}else {
		    docFolder = (IDfFolder)dfsess.getObject(docFolder.getFolderId(0));
		    if(docFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_PROJ_FOLDER", LocaleService.getLocale())) || 
		    		docFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_INSTIT_FOLDER", LocaleService.getLocale())) || 
		    		docFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_COUNTRY_FOLDER", LocaleService.getLocale()))) {
		    	parentFolder = docFolder;
		    }else{
		    	parentFolder=(IDfFolder)dfsess.getObject(docFolder.getFolderId(0));
		    }
		}
		DfLogger.debug(this, " :: getParentFolder : Parent Folder Id : " + parentFolder.getObjectId(),null,null);
	    DfLogger.debug(this, " :: getParentFolder : Object Name : " + parentFolder.getObjectName(),null,null);
	
		return parentFolder;
	}

	/**
	 * This method handles validation logic for SPI and ESRS templates
	 * @param templateName
	 * @param parentFolderObj
	 * @param arg0
	 * @param args
	 */
	private void validateESRSAndSPITemplates(String templateName, IDfFolder parentFolderObj,
			String templateESRS, String templateSPI, String templateSII, Control arg0, ArgumentList args) {
		try {
			String envCategoryCode = null;
			String qryEnvtCategoryCode = IdocsUtil.getMessage("QRY_ENVT_CATEGORY_CODE");
			String attrEnvCategoryCode = m_nlsResourceBundle.getString("MSG_ENV_CATEGORY_CODE", LocaleService.getLocale());
			String projectID = parentFolderObj.getString(m_nlsResourceBundle.getString("MSG_PROJECT_ID", LocaleService.getLocale()));
			qryEnvtCategoryCode = qryEnvtCategoryCode + projectID + "'";
			DfQuery query = new DfQuery();
			query.setDQL(qryEnvtCategoryCode);
			IDfCollection dfCollection = query.execute(getDfSession(), IDfQuery.DF_READ_QUERY);
			if(dfCollection.next()) {
				envCategoryCode = dfCollection.getString(attrEnvCategoryCode);
				dfCollection.close();
			}
			if(dfCollection != null )dfCollection.close();
			envCategoryCode = envCategoryCode.trim();
			DfLogger.debug(this, " :: validateESRSAndSPITemplates : envCategoryCode: " + envCategoryCode, null, null); 

			if(envCategoryCode != null && envCategoryCode.trim().length() > 0 
					&& envCategoryCode.equals("U") == false ){				
				if(envCategoryCode.equals("A")){
					ArgumentList promptArguments = new ArgumentList();
					promptArguments.add(Prompt.ARG_TITLE, PROMPT_TITLE_MSG);
					promptArguments.add(Prompt.ARG_MESSAGE, m_nlsResourceBundle.getString("ENVT_CATEGORY_MSG_A",
							LocaleService.getLocale()));
					promptArguments.add(Prompt.ARG_BUTTON, new String[]{Prompt.YES, Prompt.NO});
					setComponentNested(IDocsConstants.MSG_IDOCS_PROMPT_COMPONENT, promptArguments, getContext(
					), new FormActionReturnListener(
							this, "onReturnFromPromptInput"));
				}else if(templateName.equals(templateESRS) == true ){
					if(envCategoryCode.equals("B") == true){
						super.onNextComponent(arg0, args);
					}else{
						proceed = "N";
						ArgumentList promptArguments = new ArgumentList();
						promptArguments.add(Prompt.ARG_TITLE,"Document Creation");
						promptArguments.add(Prompt.ARG_MESSAGE,m_nlsResourceBundle.getString("ESRS_CATEGORY_B_ERROR",
								LocaleService.getLocale()));
						promptArguments.add(Prompt.ARG_BUTTON,new String[] { Prompt.OK });
						setComponentNested(IDocsConstants.MSG_IDOCS_PROMPT_COMPONENT,promptArguments, getContext(),
								new FormActionReturnListener(this,"onReturnFromPromptInput"));
					}
				}else{
					super.onNextComponent(arg0, args);
				}
			}else{
				proceed = "N";
				ArgumentList promptArguments = new ArgumentList();
				promptArguments.add(Prompt.ARG_TITLE,"Document Creation");
				promptArguments.add(Prompt.ARG_MESSAGE,m_nlsResourceBundle.getString("ENVT_CATEGORY_MSG_UNKNOWN",
						LocaleService.getLocale()));
				promptArguments.add(Prompt.ARG_BUTTON,new String[] { Prompt.OK });
				setComponentNested(IDocsConstants.MSG_IDOCS_PROMPT_COMPONENT,promptArguments, getContext(),
						new FormActionReturnListener(this,"onReturnFromPromptInput"));
			}
		} catch (DfException e) {
			
			DfLogger.error(this, " :: validateESRSAndSPITemplates Exception >>> "+e.getMessage(),null,null);
		}
	}

	/**
	 * 
	 * @param form
	 * @param map
	 * @throws DfException
	 */
	public void onReturnFromPromptInput(Form form, Map map) throws DfException{
		String strButton = (String) map.get(Prompt.RTN_BUTTON);
		IDfSessionManager sessionManager = getDfSession().getSessionManager();
		String newObjectid = component.getNewObjectId();
		if(newObjectid !=null && newObjectid .trim().length() > 0){
			try {
				IDfSysObject newDocument = (IDfSysObject)ObjectCacheUtil.getObject(getDfSession(), newObjectid);
				if(newDocument.hasPermission(IDfACL.DF_PERMIT_DELETE_STR, getDfSession().getLoginUserName())
						|| newDocument.hasPermission(IDfACL.DF_XPERMIT_DELETE_OBJECT_STR, getDfSession().getLoginUserName()) ){
					DfLogger.debug(this, " :: user Has Delete Permission. Continue with User Session : ", null, null);	
				}else{
					sessionManager = IdocsUtil.getAdminSessionManager(getDfSession());					
					DfLogger.debug(this, " :: getAdminSessionManager :Success: ", null, null);
				}				
			} catch (DfException e) {
				try {
					sessionManager = IdocsUtil.getAdminSessionManager(getDfSession());
					DfLogger.debug(this, " :: getAdminSessionManager :Success: ", null, null);
				}catch (DfException e2) {
					DfLogger.error(this, " :: onReturnFromPromptInput Exception >>> "+e2.getMessage(),null,null);
				}
			}
		}
		if(strButton != null && strButton.equals(Prompt.YES)) {
			setCurrentComponent("attributes");
		}else if((strButton != null) && ((strButton.equals(Prompt.NO)) || (strButton.equals(Prompt.CANCEL)))) {
			if (sessionManager != null) {
				//component.onCancelChanges(sessionManager);
				if(deleteDocument(sessionManager))
					DfLogger.info(this, "Document Deleted Success Fully", null, null);
				else 
					DfLogger.info(this, "Document Deleted Failed", null, null);
			}
			setComponentReturn();
		}else if(strButton != null && strButton.equals(Prompt.OK)) {
			if(proceed.equalsIgnoreCase("Y")){
				setCurrentComponent("attributes");
			}else{
				if (sessionManager != null) {
					if(deleteDocument(sessionManager))
						DfLogger.info(this, "Document Deleted Success Fully", null, null);
					else 
						DfLogger.info(this, "Document Deleted Failed", null, null);
					//component.onCancelChanges(sessionManager);
				}
				setComponentReturn();
			}
		}
	}
  
	public boolean deleteDocument(IDfSessionManager manager){
         IDfSession dfSession= null;
         boolean status=false;
        
         if(component.getNewObjectId() == null){
         status=component.onCancelChanges();
         }else
            try {
            	
        		DfId newObjectId = new DfId(component.getNewObjectId());
				String docbase = DocbaseUtils.getDocbaseNameFromId(newObjectId);
				dfSession = manager.getSession(docbase);
				deleteObject(component.getNewObjectId(), dfSession, true);
				status=true;
			} catch (DfIdentityException e) {
				// TODO Auto-generated catch block
				status=false;
				DfLogger.error(this, " :: deleteDocument Exception >>> "+e.getMessage(),null,null);
			} catch (DfAuthenticationException e) {
				// TODO Auto-generated catch block
				DfLogger.error(this, " :: deleteDocument Exception >>> "+e.getMessage(),null,null);
				status=false;
			} catch (DfPrincipalException e) {
				// TODO Auto-generated catch block
				DfLogger.error(this, " :: deleteDocument Exception >>> "+e.getMessage(),null,null);
				status=false;
			} catch (DfServiceException e) {
				// TODO Auto-generated catch block
				DfLogger.error(this, " :: deleteDocument Exception >>> "+e.getMessage(),null,null);
				status=false;
			} catch (DfException e) {
				// TODO Auto-generated catch block
				DfLogger.error(this, " :: deleteDocument Exception >>> "+e.getMessage(),null,null);
				status=false;
			}finally{
				if(dfSession != null)
	                manager.release(dfSession);
	      }
          return status;
	}
	
	
	private void deleteObject(String strObjectId, IDfSession idfSession, boolean fIgnoreError)
    {
		DfLogger.info(this, " :: deleteObject  >>>  :: entred ",null,null);
        try
        {
            IDfDeleteOperation deleteOperation = DfcUtils.getClientX().getDeleteOperation();
            if(deleteOperation instanceof IDfDeleteOperationInternal)
            {
                IDfDeleteOperationInternal deleteOperationInt = (IDfDeleteOperationInternal)deleteOperation;
                deleteOperationInt.enableRemoteMode(true);
            }
            DfLogger.info(this, " :: deleteObject  >>>  :: sysobject fetch of "+strObjectId,null,null);
            IDfSysObject sysObj = (IDfSysObject)idfSession.getObject(new DfId(strObjectId));
            if(sysObj.isCheckedOutBy(null))
                sysObj.cancelCheckout();
            if(sysObj.isFrozen())
            {
                sysObj.unfreeze(true);
                sysObj.save();
            }
            deleteOperation.add(sysObj);
            
            boolean executeSucceeded = deleteOperation.execute();
            if(!executeSucceeded && !fIgnoreError)
            {
            	String strDeleteExecuteError = "";
                IDfList list = deleteOperation.getErrors();
                int count = list.getCount();
                if(count > 0)
                {
                    IDfOperationError opErr = (IDfOperationError)list.get(0);
                    strDeleteExecuteError = opErr.getMessage();
                }
                DfLogger.info(this, " :: deleteObject  >>>  :: Document Delete operation failed reason"+strDeleteExecuteError,null,null);
                Exception e = new Exception(strDeleteExecuteError);
                setReturnError("MSG_ERROR_DELETING_DOC", null, e);
                WebComponentErrorService.getService().setNonFatalError(this, "MSG_ERROR_DELETING_DOC", e);
            }
        }
        catch(DfException e)
        {
            if(!fIgnoreError)
            {
                setReturnError("MSG_ERROR_DELETING_DOC", null, e);
                WebComponentErrorService.getService().setNonFatalError(this, "MSG_ERROR_DELETING_DOC", e);
            }
        }
    }

 /**
  * Purpose : is to delete the document if user by mistake closed the window.
  * @param control
  * @param argList
  */
	public void onCloseForm(Control control, ArgumentList argList) {
//		System.out.println("in Side the file changes >>>");
			 onCancelChanges();
	}
	
	/**
	 * 
	 */
	public boolean onCancelChanges() {
		DfLogger.debug(this, " :: onCancelChanges :Entered: ", null, null);
		boolean bChangesCancelled = true;
		if(docStatus)
		if (component != null) {
			IDfSessionManager sessionManager = getDfSession().getSessionManager();
			String newObjectid = component.getNewObjectId();
			if(newObjectid !=null && newObjectid .trim().length() > 0){
				try {
					IDfSysObject newDocument = (IDfSysObject)ObjectCacheUtil.getObject(getDfSession(), newObjectid);
					if(newDocument.hasPermission(IDfACL.DF_PERMIT_DELETE_STR, getDfSession().getLoginUserName())
							|| newDocument.hasPermission(IDfACL.DF_XPERMIT_DELETE_OBJECT_STR, getDfSession().getLoginUserName()) ){
						DfLogger.debug(this, " :: user Has Delete Permission. Continue with User Session : ", null, null);	
					}else{
						sessionManager = IdocsUtil.getAdminSessionManager(getDfSession());					
						DfLogger.debug(this, " :: getAdminSessionManager :Success: ", null, null);
					}				
				} catch (DfException e) {
					try {
						sessionManager = IdocsUtil.getAdminSessionManager(getDfSession());
						DfLogger.debug(this, " :: getAdminSessionManager :Success: ", null, null);
					}catch (DfException e2) {
						DfLogger.error(this, " :: onCancelChanges Exception >>> "+e2.getMessage(),null,null);
					}
				}
			}
			ArrayList components = getContainedComponents();
			for (int i = components.size() - 1; i >= 0; --i) {
				Component tempComponent = (Component) components.get(i);

				if(tempComponent instanceof NewDocument){
					NewDocument newDocumentComponent = (NewDocument)tempComponent;				
					DfLogger.debug(this, " :: onCancelChanges : if cond: " + tempComponent.getName(),null,null);
					//bChangesCancelled = (bChangesCancelled) && (newDocumentComponent.onCancelChanges(sessionManager));
					bChangesCancelled = (bChangesCancelled) && (deleteDocument(sessionManager));
				}else{
					DfLogger.debug(this, " :: onCancelChanges : else cond: " + tempComponent.getName(),null,null);
					bChangesCancelled = (bChangesCancelled) && (tempComponent.onCancelChanges());
				}
			}
			if (bChangesCancelled) {
				SessionManagerHttpBinding.removeHttpSessionUnboundListener(this);
			}
		}
		setComponentReturn();
		return bChangesCancelled;
	}
	
	/**
	 * This method validates whether the logged user has sufficient privileges to create document
	 * in selected project folder
	 * @param dfSession
	 * @param strTemplateName
	 * @param projectId
	 * @return
	 */
	 public boolean validateProjUserAccess(IDfSession dfSession, String strTemplateName, String projectId) {
		boolean validated=false;
    	DfQuery query = new DfQuery();
    	try{
			String role="";
			DfLogger.debug(NewDocumentContainer.class, " :: validateProjUserAccess : UserLoginName : "+getDfSession().getLoginUserName(),null,null);
    		String templateQry = IdocsUtil.getMessage("QRY_TEMPLATE_INFO");
    		templateQry = templateQry.replaceFirst("''", "'"+strTemplateName+"'");
    		DfLogger.debug(NewDocumentContainer.class, " :: validateProjUserAccess : templateQry : " + templateQry, null, null);
    		
    		query.setDQL(templateQry);
			IDfCollection coll=query.execute(dfSession,IDfQuery.DF_READ_QUERY);
			if(coll.next()){
				validationError=coll.getString(m_nlsResourceBundle.getString("MSG_ERROR_MESSAGE", LocaleService.getLocale()));
				role=coll.getString(m_nlsResourceBundle.getString("MSG_ROLE", LocaleService.getLocale()));
				coll.close();
			}
			if(coll != null )coll.close();
			DfLogger.debug(NewDocumentContainer.class, " :: validateProjUserAccess : validationError : " + validationError + ": role: " + role,null,null);
			if(role.equalsIgnoreCase("All")){
				DfLogger.debug(NewDocumentContainer.class, " :: validateProjUserAccess : Validated : "+role,null,null);
				validated=true;
			}else if(role.equalsIgnoreCase("None")){
				DfLogger.debug(NewDocumentContainer.class, " :: validateProjUserAccess : NOT Validated : "+role,null,null);
				validated=false;
			}else if(role.startsWith(IDocsConstants.MSG_RESTART_ONLY)){
				DfLogger.debug(NewDocumentContainer.class, " :: validateProjUserAccess : NOT Validated : "+role,null,null);
				validated=false;
			}else{
				String createRole=null;String createRoleType = null; String errorMsg=null;
				boolean isWFStarted=false;
				String templateAccessQry=IdocsUtil.getMessage("QRY_APP_SEC_CONFIG_CREATE");	
				templateAccessQry=templateAccessQry.replaceAll("''", "'"+strTemplateName+"'");
				DfLogger.debug(NewDocumentContainer.class, " :: validateProjUserAccess : templateAccessQry : " + templateAccessQry, null, null);
				query.setDQL(templateAccessQry);
				coll=query.execute(dfSession,IDfQuery.DF_READ_QUERY);
				boolean enteredRoleCheck = false;
				while(coll.next() && validated==false){
					enteredRoleCheck = true;
					createRole=coll.getString(IdocsConstants.MSG_CREATE_ROLE);
					createRoleType=coll.getString(IdocsConstants.MSG_CREATE_ROLE_TYPE);
					isWFStarted=coll.getBoolean(IDocsConstants.MSG_IS_WORKFLOW_RESTARTABLE);
					errorMsg=coll.getString(IdocsConstants.MSG_ERROR_MESSAGES);					
					validated = IdocsUtil.validateRole(projectId,createRole,createRoleType,"",isWFStarted,errorMsg,getDfSession());	
				}
				if(coll!=null)coll.close();
				if(validated == false && enteredRoleCheck == false){
					DfLogger.debug(this, " :: validateProjUserAccess : NO ROWS in APP SEC : SKIP Validation ", null, null);
					validated = true;
				}
			}
    	}catch(DfException e){
    		DfLogger.error(NewDocumentContainer.class, " :: validateProjUserAccess Exception >>> "+e.getMessage(),null,null);
    	}
		return validated;
	}

	
	/**
	 * This method checks if document is getting created in its respective folder type
	 * @param strTemplateName -- Name of the template
	 * @param folderType - Type of the folder
	 * @return - True or False
	 */
	private boolean validateTemplate(String strTemplateName, String folderType){
		boolean validated=false;
		String documentType="";
		String documentId = "";
		 
        if(strTemplateName.equals(null)||strTemplateName.equals("")||strTemplateName.equals(" ")){
        	validationError=m_nlsResourceBundle.getString("ERR_TMPL_NAME", LocaleService.getLocale());
        	validated=false;
        }else{
        	try {
        		
        		String strNonWorkFlowTemplateNames = IdocsUtil.getMessage("MSG_NONWORKFLOW_TEMPLATES");
        		if(IdocsUtil.checkIfTokenPresent(strNonWorkFlowTemplateNames, strTemplateName, IdocsConstants.MSG_COMMA)){ // Validate Non-Workflow Templates
        			return validateNonWorkflowtemplates(strTemplateName, folderType);
        		}
        		else { // Validate Workflow Templates
        			DfQuery query = new DfQuery();
        			String strQry = IdocsUtil.getMessage("QRY_TEMPLATE_ID");
        			strQry = strQry.replaceFirst("''", "'"+strTemplateName+"'");
        			query.setDQL(strQry);
        			DfLogger.debug(NewDocumentContainer.class, " :: validateTemplate : strQry : "+strQry,null,null);
        			IDfCollection coll=query.execute(getDfSession(),IDfQuery.DF_READ_QUERY);
        			if(coll.next()){
        				documentType=coll.getString(IDocsConstants.MSG_R_OBJECT_TYPE);
        				documentId = coll.getString(IDocsConstants.MSG_R_OBJECT_ID);
        				coll.close();
        			}
        			if(coll != null )coll.close();
        			DfLogger.debug(NewDocumentContainer.class, " :: validateTemplate : documentType : "+documentType,null,null);
        			if(documentType.equals(null) || documentType.equals("") || documentType.equals(" ")){
        				validated=false;
        				validationError=m_nlsResourceBundle.getString("ERR_FOLDER_VALIDATION", LocaleService.getLocale());
        			}else {
        				if(documentType.equals(m_nlsResourceBundle.getString("MSG_IDOCS_PROJ_DOC", LocaleService.getLocale())) &&
        						folderType.equals(m_nlsResourceBundle.getString("MSG_IDOCS_PROJ_FOLDER", LocaleService.getLocale()))) {
        					validated = true;
        					setDocumentId(documentId);
        				}else if(documentType.equals(m_nlsResourceBundle.getString("MSG_IDOCS_INSTIT_DOC", LocaleService.getLocale())) &&
        						folderType.equals(m_nlsResourceBundle.getString("MSG_IDOCS_INSTIT_FOLDER", LocaleService.getLocale()))) {
        					validated = true;
        					setDocumentId(documentId);
        				}else if(documentType.equals(m_nlsResourceBundle.getString("MSG_IDOCS_COUNTRY_DOC", LocaleService.getLocale())) &&
        						folderType.equals(m_nlsResourceBundle.getString("MSG_IDOCS_COUNTRY_FOLDER", LocaleService.getLocale()))) {
        					validated=true;
        					setDocumentId(documentId);
        					DfLogger.debug(NewDocumentContainer.class, " :: validateTemplate : documentType is idocs_document",null,null);
        				}else {
        					validated=false;
        					validationError=m_nlsResourceBundle.getString("ERR_FOLDER_VALIDATION", LocaleService.getLocale());
        				}
        			}
        		}
			}catch (DfException e){
        		DfLogger.error(this, " :: validateTemplate Exception >>> "+e.getMessage(),null,null);
			}
        }
        DfLogger.debug(this, " :: validateTemplate : " + validated,null,null);
    	return validated;
	}

	/**
	 * This method validates the Non Workflow Templates and allows user to create them
	 * in any of institution or project folders
	 * 
	 * @param nonWfTemplateName - Non Workflow Template Name
	 * @return boolean - True or False
	 */
	private boolean validateNonWorkflowtemplates(String nonWfTemplateName, String folderObjectType) {
		boolean validated=false;
		try {
			DfLogger.debug(this, " :: validateNonWorkflowtemplates : Validating non workflow templates: ", null, null);
			DfQuery query = new DfQuery();
			String strQry = IdocsUtil.getMessage("QRY_TEMPLATE_ID");
			strQry = strQry.replaceFirst("''", "'"+nonWfTemplateName+"'");
			DfLogger.debug(this, " :: validateNonWorkflowtemplates : strQry : "+strQry,null,null);
			query.setDQL(strQry);
			IDfCollection coll=query.execute(getDfSession(),IDfQuery.DF_READ_QUERY);
			String documentType = "";
			String documentId = "";
			 
			while (coll.next()) {
				documentType = coll.getString(IDocsConstants.MSG_R_OBJECT_TYPE);
				documentId = coll.getString(IDocsConstants.MSG_R_OBJECT_ID);
				DfLogger.debug(this, " :: validateNonWorkflowtemplates : documentType: " + documentType, null, null);
				if(documentType.equals(m_nlsResourceBundle.getString("MSG_IDOCS_PROJ_DOC", LocaleService.getLocale())) &&
						folderObjectType.equals(m_nlsResourceBundle.getString("MSG_IDOCS_PROJ_FOLDER", LocaleService.getLocale()))) {
					validated = true;
					DfLogger.debug(this, " :: validateNonWorkflowtemplates : documentType: " + documentType +
							" , folderObjectType: " + folderObjectType, null, null);
					setDocumentId(documentId);
					coll.close();
					break;
				}else if(documentType.equals(m_nlsResourceBundle.getString("MSG_IDOCS_INSTIT_DOC", LocaleService.getLocale())) &&
						folderObjectType.equals(m_nlsResourceBundle.getString("MSG_IDOCS_INSTIT_FOLDER", LocaleService.getLocale()))) {
					validated = true;
					DfLogger.debug(this, " :: validateNonWorkflowtemplates : documentType: " + documentType +
							" , folderObjectType: " + folderObjectType, null, null);
					setDocumentId(documentId);
					coll.close();
					break;
				}else if(documentType.equals(m_nlsResourceBundle.getString("MSG_IDOCS_COUNTRY_DOC", LocaleService.getLocale())) &&
						folderObjectType.equals(m_nlsResourceBundle.getString("MSG_IDOCS_COUNTRY_FOLDER", LocaleService.getLocale()))) {
					validated=true;
					DfLogger.debug(this, " :: validateNonWorkflowtemplates : documentType: " + documentType +
							" , folderObjectType: " + folderObjectType, null, null);
					setDocumentId(documentId);
					coll.close();
					break;
					
				}else {
					validated=false;
					validationError=m_nlsResourceBundle.getString("ERR_FOLDER_VALIDATION", LocaleService.getLocale());
				}			
			}
			if(coll != null )coll.close();
			
		} catch (DfException e) {
			DfLogger.error(this, " :: validateNonWorkflowtemplates >>> "+e.getMessage(),null,null);
		}
		DfLogger.debug(this, " :: validateTemplate : " + validated,null,null);
    	return validated;
	}

	/**
	 * This method returns the Object ID of the selected template
	 * @param strTemplateName - selected template name
	 * @return String - r_object_id of the template
	 * @throws DfException
	 */
	private String getTemplateId(String strTemplateName) throws DfException {
		String strId=null;
		String strQry = IdocsUtil.getMessage("QRY_TEMPLATE_ID");
		strQry = strQry.replaceFirst("''", "'"+strTemplateName+"'");
		DfQuery query = new DfQuery();
		query.setDQL(strQry);
		DfLogger.debug(this, " :: getTemplateId : strQry: " + strQry,null,null);
		IDfCollection collection=query.execute(getDfSession(), IDfQuery.DF_READ_QUERY);
		if(collection.next()) {
		   strId = collection.getString("r_object_id");
		   collection.close();
	    }
		if(collection != null )collection.close();
		DfLogger.debug(this, " :: getTemplateId : strId: " + strId,null,null);
		return strId;
	}

	public void setDocumentId(String docId){
		this.docId = docId;
	}
	
	public String getDocumentId(){
		return this.docId;
	}
	
    /**
	 * This methods sets the version label on the document
	 * @param button - Button
	 * @param args - Arguments
	 */
	public void onOk(Control button, ArgumentList args) {
		
        Component containedComponent = getContainedComponent();
        containedComponent.validate();
        if(containedComponent.getIsValid() && canCommitChanges() &&
        		onCommitChanges() && validateNameChange()) {
            SessionManagerHttpBinding.removeHttpSessionUnboundListener(this);
            ArrayList components = getContainedComponents();
            NewDocument component = (NewDocument)components.get(0);
            String strNewObjectId = component.getNewObjectId();
            try {
				IDfSysObject newDoc = (IDfSysObject)ObjectCacheUtil.getObject(getDfSession(), strNewObjectId);
				/** Setting initial version as 0.1*/
				int verlabelcnt = newDoc.getVersionLabelCount();
				if(verlabelcnt==2){
					newDoc.mark ("0.1");
					newDoc.mark ("CURRENT");
				}else{
					newDoc.mark ("0.1");
					newDoc.mark ("CURRENT");
					newDoc.mark ("_NEW_");
				}
				DfLogger.debug(NewDocumentContainer.class, " :: onOk :: Document Marked _NEW_ ", null, null);
				if(newDoc.hasAttr("product_wf_nbr") == true ){
					invokeUrlUpdate(newDoc);
				}
				newDoc.save();
				IdocsUtil.auditIDocsActivity(MSG_CREATED,newDoc.getObjectId().getId(),getDfSession());
			} catch (Exception e) {
				DfLogger.debug(NewDocumentContainer.class, " :: onOk :: Document Mark _NEW_ Failed"+e.getMessage(), null, null);
				e.printStackTrace();
			}
            setReturnValue("newObjectId", strNewObjectId);
            if(strNewObjectId != null) {
                String strType = component.getNewType();
                Context context = getContext();
                ArgumentList componentArgs = new ArgumentList();
                componentArgs.add("objectId", strNewObjectId);
                context.set("type", strType);
                context.set("objectId", strNewObjectId);
                ActionService.execute("editafternew", componentArgs, context, this, null);
            } else {
                setComponentReturn();
            }
        }   
	}

	/**
	 * 
	 * @param newDoc 
	 * @throws Exception
	 */
	private void invokeUrlUpdate(IDfSysObject newDoc) throws Exception {
		String strTemplateName = null;
		String strDocName = newDoc.getObjectName();
		if(strDocName.indexOf("_") != -1){
		    strTemplateName = strDocName.substring(strDocName.indexOf("_") + 1);
		}
		IdocsUtil idocsUtil = new IdocsUtil();
		int pdtWfTypeCode = idocsUtil.getProductTypeCode(getDfSession(), strTemplateName);
		String strPdtWfNbr = newDoc.getString("product_wf_nbr");
		if(pdtWfTypeCode > 100 && strPdtWfNbr != null && !"".equals(strPdtWfNbr)){
		    String strServletURL = buildServletURL(getDfSession(), newDoc, strPdtWfNbr, String.valueOf(pdtWfTypeCode));
		    IdocsUtil.buildAndExecuteServlet(strServletURL);
		}
	}
	
	 /**
     * This method frames the IDESK integration servlet URL for product templates.
     * @param dfSession - Login Session
     * @param doc 	- Selecte document
     * @param strPdtWfNbr - Product Workflow number from the Template info
     * @param strPdtWfTypeCode - Product Workflow type code from the Template info.
     * @return - Servlet URl
     * @throws DfException
     */
    private String buildServletURL(IDfSession dfSession, IDfSysObject newDocument,
			String strPdtWfNbr, String strPdtWfTypeCode) throws DfException {
    	String servletBasicUrl = IdocsUtil.getIdocsConfigInfoValue(dfSession, PRODUCT_DRL_UPDATE_SERVLET_URL);
        
    	String strProject_id = newDocument.getString("project_id");
        String strObjectId = newDocument.getObjectId().toString();
        
        String strDRL = IdocsUtil.constructDrl(strObjectId,this,getPageContext().getRequest());
        strDRL = strDRL + "/versionLabel/CURRENT";
        DfLogger.info(this, ":: buildServletURL :: strDRL: " + strDRL, null, null);
        StringBuilder servletURL = new StringBuilder(servletBasicUrl);
        servletURL.append("userid").append("=iapplications");
        servletURL.append("&").append("mainresourceid").append("=");
        servletURL.append(strProject_id);
        servletURL.append("&").append("workflow_nbr").append("=");
        servletURL.append(strPdtWfNbr);
        servletURL.append("&").append("workflow_type_code").append("=");
        servletURL.append(strPdtWfTypeCode);
        servletURL.append("&").append("doc_url").append("=");
        servletURL.append(strDRL);
        DfLogger.info(this, (new StringBuilder(" :: buildServletURL : Pdt Servlet : ")).append(servletURL).toString(), null, null);
        DfLogger.info(this, ":: buildServletURL :: servletURL.toString(): " + servletURL.toString(), null, null);
        return servletURL.toString();
    }
    
  	static {
        m_NewDocContainerNlsProp = "org.ifc.idocs.create.NewDocContainerNlsProp";
        m_nlsResourceBundle = new NlsResourceBundle(m_NewDocContainerNlsProp);
    }
}
