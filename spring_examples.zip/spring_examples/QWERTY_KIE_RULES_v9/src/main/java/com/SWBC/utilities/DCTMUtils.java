package com.SWBC.utilities;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;

public class DCTMUtils {
	
	public static IDfCollection executeQuery(IDfSession session, String query)
			throws DfException {
	

		IDfCollection outputColl = null;
		try {
			IDfClientX cx = new DfClientX();
			IDfQuery idfQry = cx.getQuery(); 
			idfQry.setDQL(query); 

			
			outputColl = idfQry.execute(session, IDfQuery.READ_QUERY);
		} catch (DfException dfe) {
			throw new DfException(
					"Error while executing the query in executeQuery() : "
							+ dfe.getMessage());
		}
		return outputColl;
	}

}
