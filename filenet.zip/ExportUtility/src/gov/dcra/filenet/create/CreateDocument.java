package gov.dcra.filenet.create;

import gov.dcra.filenet.connection.DCRAFileNetConnection;
import gov.dcra.filenet.constants.Constants;
import gov.dcra.filenet.util.DCRAFileNetUtil;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.filenet.api.collection.ContentElementList;
import com.filenet.api.constants.AutoClassify;
import com.filenet.api.constants.AutoUniqueName;
import com.filenet.api.constants.CheckinType;
import com.filenet.api.constants.DefineSecurityParentage;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;


public class CreateDocument {

	private final static Logger log = Logger.getLogger(DocumentCreateExecute.class);
	private final String appPropsFile = Constants.APPLICATION_PROPS;
	private Properties appProps = new Properties();
	
	public static void main(String[] args) {
		
		CreateDocument createDoc=new CreateDocument();
		createDoc.processCreate();
	}
	
	private void processCreate() {

		DCRAFileNetConnection conn = null;
		DCRAFileNetUtil exportUtil = null;
		Domain domain = null;
		ObjectStore os = null;
			
		try {

			log.debug("Start Processing......");
			appProps.load(CreateDocument.class.getResourceAsStream(appPropsFile));
			
			conn = new DCRAFileNetConnection();
			exportUtil = new DCRAFileNetUtil();
			domain = conn.getDomain();
			os = exportUtil.getObjectStore(domain,appProps.getProperty(Constants.MSG_OBJECTSTORE_NAME));
			String folderPath=appProps.getProperty(Constants.TARGET_FOLDER_PATH);
			
			create(getFolder(os,folderPath));
			
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public Folder getFolder(ObjectStore os,String folderPath) throws Exception {

		Folder folder=null;
		folder=Factory.Folder.fetchInstance(os, folderPath, null); 
		return folder;

	}
	
	public void create(Object parent) throws Exception {
		Folder folder = (Folder) parent;
		Document document = createDocument(folder.getObjectStore());
		folder.file(document, AutoUniqueName.AUTO_UNIQUE, null,
				DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE).save(
				RefreshMode.NO_REFRESH);
	}

	private Document createDocument(ObjectStore objectStore) throws Exception {
		Document document = Factory.Document.createInstance(objectStore, "Document");
		document.getProperties().putValue("DocumentTitle", getDocumentTitle() );
		document.set_ContentElements( getContentElements() );
		document.checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION );
		document.save(RefreshMode.REFRESH);
		return document;
	}

	private String getDocumentTitle() {
		return "Console Project Test " + (new Date()).getTime();
	}

	@SuppressWarnings("unchecked")
	private ContentElementList getContentElements() throws Exception {
		ContentElementList contentElementList = Factory.ContentElement.createList();
		contentElementList.add( createStringContent("Hello, World!") );
		return contentElementList;
	}

	private ContentTransfer createStringContent(String data) throws Exception {
		ContentTransfer content = Factory.ContentTransfer.createInstance();
		content.set_RetrievalName( "data.txt" );
		content.setCaptureSource( new ByteArrayInputStream( data.getBytes() ) );
		content.set_ContentType( "text/plain" );
		return content;
	}
}