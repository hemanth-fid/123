package com.SWBC.model;

import java.util.Date;

public class PreProc_Doca_Ucap {
	
	private	String	flood_zone;
	private	String	ho_6_flag;
	private	String	grandfater_zone;
	private	String	earthquake_excluded;
	private	String	grandfather_zone;
	private	Date	doc_scan_date;
	private	String	replace_cost_ind;
	private	String	bill_indicator;
	private	String	percent_add_other_structure;
	private	String	wind_excluded;
	private	String	document_sub_type;
	private	Date	follow_up_date;
	private	String	follow_up_reason;
	private	String	agent_email;
	private	String	cov_type;
	private	String	is_qc_candidate;
	private	String	document_type;
	private	String	loan_type;
	private	Date	policy_expiration_date;
	private	Date	policy_cancel_date;
	private	String	carrier_zip;
	private	Date	premium_due_date;
	private	String	transaction_status;
	private	String	orig_file_name;
	private	String	property_zip;
	private	String	loan_number;
	private	double	percent_primary_coverage;
	private	double	policy_premium;
	private	String	agency_number;
	private	String	escrow_indicator;
	private	String	mailing_address;
	private	double	percent_deductible;
	private	String	account_number;
	private	int	batch_number;
	private	double	coverage_amount;
	private	String	account_tax_id;
	private	String	property_address_1;
	private	String	property_address_2;
	private	Date	doc_issue_date;
	private	String	mailing_state;
	private	String	payee_code;
	private	String	client_number;
	private	int	number_of_condos;
	private	String	qc_response_code;
	private	String	scan_id;
	private	Date	doc_notice_effective_date;
	private	Date	doc_delivery_date;
	private	String	property_city;
	private	String	policy_number;
	private	String	mortgagee_zip;
	private	String	mortgagee_name;
	private	Date	doc_notice_date;
	private	String	agent_city;
	private	String	impairment_code;
	private	String	agent_name;
	private	String	mailing_city;
	private	String	policy_cancel_reason;
	private	String	mortgagee_city;
	private	String	agent_zip;
	private	String	account_name;
	private	String	transaction_id;
	private	int	batch_seq_no;
	private	Date	reinstatement_date;
	private	String	transaction_source;
	private	String	co_policy_holder_name;
	private	Date	policy_effective_date;
	private	String	property_state;
	private	String	carrier_city;
	private	String	agent_phone;
	private	String	carrier_name;
	private	String	loan_suffix;
	private	Date	doc_received_date;
	private	String	mortgagee_address;
	private	String	carrier_state;
	private	Date	as400_post_date;
	private	String	agent_address;
	private	double	additional_coverage_amount;
	private	double	additional_premium_amt;
	private	String	institution_code;
	private	String	carrier_address_1;
	private	String	agent_state;
	private	String	policy_holder_name;
	private	double	deductible;
	private	String	transaction_type;
	private	String	mailing_zip;
	private	String	mortgagee_state;
	private	String	carrier_phone;
	private	double	base_coverage_other_structs;
	public String getFlood_zone() {
		return flood_zone;
	}
	public void setFlood_zone(String flood_zone) {
		this.flood_zone = flood_zone;
	}
	public String getHo_6_flag() {
		return ho_6_flag;
	}
	public void setHo_6_flag(String ho_6_flag) {
		this.ho_6_flag = ho_6_flag;
	}
	public String getGrandfater_zone() {
		return grandfater_zone;
	}
	public void setGrandfater_zone(String grandfater_zone) {
		this.grandfater_zone = grandfater_zone;
	}
	public String getEarthquake_excluded() {
		return earthquake_excluded;
	}
	public void setEarthquake_excluded(String earthquake_excluded) {
		this.earthquake_excluded = earthquake_excluded;
	}
	public String getGrandfather_zone() {
		return grandfather_zone;
	}
	public void setGrandfather_zone(String grandfather_zone) {
		this.grandfather_zone = grandfather_zone;
	}
	public Date getDoc_scan_date() {
		return doc_scan_date;
	}
	public void setDoc_scan_date(Date doc_scan_date) {
		this.doc_scan_date = doc_scan_date;
	}
	public String getReplace_cost_ind() {
		return replace_cost_ind;
	}
	public void setReplace_cost_ind(String replace_cost_ind) {
		this.replace_cost_ind = replace_cost_ind;
	}
	public String getBill_indicator() {
		return bill_indicator;
	}
	public void setBill_indicator(String bill_indicator) {
		this.bill_indicator = bill_indicator;
	}
	public String getPercent_add_other_structure() {
		return percent_add_other_structure;
	}
	public void setPercent_add_other_structure(String percent_add_other_structure) {
		this.percent_add_other_structure = percent_add_other_structure;
	}
	public String getWind_excluded() {
		return wind_excluded;
	}
	public void setWind_excluded(String wind_excluded) {
		this.wind_excluded = wind_excluded;
	}
	public String getDocument_sub_type() {
		return document_sub_type;
	}
	public void setDocument_sub_type(String document_sub_type) {
		this.document_sub_type = document_sub_type;
	}
	public Date getFollow_up_date() {
		return follow_up_date;
	}
	public void setFollow_up_date(Date follow_up_date) {
		this.follow_up_date = follow_up_date;
	}
	public String getFollow_up_reason() {
		return follow_up_reason;
	}
	public void setFollow_up_reason(String follow_up_reason) {
		this.follow_up_reason = follow_up_reason;
	}
	public String getAgent_email() {
		return agent_email;
	}
	public void setAgent_email(String agent_email) {
		this.agent_email = agent_email;
	}
	public String getCov_type() {
		return cov_type;
	}
	public void setCov_type(String cov_type) {
		this.cov_type = cov_type;
	}
	public String getIs_qc_candidate() {
		return is_qc_candidate;
	}
	public void setIs_qc_candidate(String is_qc_candidate) {
		this.is_qc_candidate = is_qc_candidate;
	}
	public String getDocument_type() {
		return document_type;
	}
	public void setDocument_type(String document_type) {
		this.document_type = document_type;
	}
	public String getLoan_type() {
		return loan_type;
	}
	public void setLoan_type(String loan_type) {
		this.loan_type = loan_type;
	}
	public Date getPolicy_expiration_date() {
		return policy_expiration_date;
	}
	public void setPolicy_expiration_date(Date policy_expiration_date) {
		this.policy_expiration_date = policy_expiration_date;
	}
	public Date getPolicy_cancel_date() {
		return policy_cancel_date;
	}
	public void setPolicy_cancel_date(Date policy_cancel_date) {
		this.policy_cancel_date = policy_cancel_date;
	}
	public String getCarrier_zip() {
		return carrier_zip;
	}
	public void setCarrier_zip(String carrier_zip) {
		this.carrier_zip = carrier_zip;
	}
	public Date getPremium_due_date() {
		return premium_due_date;
	}
	public void setPremium_due_date(Date premium_due_date) {
		this.premium_due_date = premium_due_date;
	}
	public String getTransaction_status() {
		return transaction_status;
	}
	public void setTransaction_status(String transaction_status) {
		this.transaction_status = transaction_status;
	}
	public String getOrig_file_name() {
		return orig_file_name;
	}
	public void setOrig_file_name(String orig_file_name) {
		this.orig_file_name = orig_file_name;
	}
	public String getProperty_zip() {
		return property_zip;
	}
	public void setProperty_zip(String property_zip) {
		this.property_zip = property_zip;
	}
	public String getLoan_number() {
		return loan_number;
	}
	public void setLoan_number(String loan_number) {
		this.loan_number = loan_number;
	}
	public double getPercent_primary_coverage() {
		return percent_primary_coverage;
	}
	public void setPercent_primary_coverage(double percent_primary_coverage) {
		this.percent_primary_coverage = percent_primary_coverage;
	}
	public double getPolicy_premium() {
		return policy_premium;
	}
	public void setPolicy_premium(double policy_premium) {
		this.policy_premium = policy_premium;
	}
	public String getAgency_number() {
		return agency_number;
	}
	public void setAgency_number(String agency_number) {
		this.agency_number = agency_number;
	}
	public String getEscrow_indicator() {
		return escrow_indicator;
	}
	public void setEscrow_indicator(String escrow_indicator) {
		this.escrow_indicator = escrow_indicator;
	}
	public String getMailing_address() {
		return mailing_address;
	}
	public void setMailing_address(String mailing_address) {
		this.mailing_address = mailing_address;
	}
	public double getPercent_deductible() {
		return percent_deductible;
	}
	public void setPercent_deductible(double percent_deductible) {
		this.percent_deductible = percent_deductible;
	}
	public String getAccount_number() {
		return account_number;
	}
	public void setAccount_number(String account_number) {
		this.account_number = account_number;
	}
	public int getBatch_number() {
		return batch_number;
	}
	public void setBatch_number(int batch_number) {
		this.batch_number = batch_number;
	}
	public double getCoverage_amount() {
		return coverage_amount;
	}
	public void setCoverage_amount(double coverage_amount) {
		this.coverage_amount = coverage_amount;
	}
	public String getAccount_tax_id() {
		return account_tax_id;
	}
	public void setAccount_tax_id(String account_tax_id) {
		this.account_tax_id = account_tax_id;
	}
	public String getProperty_address_1() {
		return property_address_1;
	}
	public void setProperty_address_1(String property_address_1) {
		this.property_address_1 = property_address_1;
	}
	public String getProperty_address_2() {
		return property_address_2;
	}
	public void setProperty_address_2(String property_address_2) {
		this.property_address_2 = property_address_2;
	}
	public Date getDoc_issue_date() {
		return doc_issue_date;
	}
	public void setDoc_issue_date(Date doc_issue_date) {
		this.doc_issue_date = doc_issue_date;
	}
	public String getMailing_state() {
		return mailing_state;
	}
	public void setMailing_state(String mailing_state) {
		this.mailing_state = mailing_state;
	}
	public String getPayee_code() {
		return payee_code;
	}
	public void setPayee_code(String payee_code) {
		this.payee_code = payee_code;
	}
	public String getClient_number() {
		return client_number;
	}
	public void setClient_number(String client_number) {
		this.client_number = client_number;
	}
	public int getNumber_of_condos() {
		return number_of_condos;
	}
	public void setNumber_of_condos(int number_of_condos) {
		this.number_of_condos = number_of_condos;
	}
	public String getQc_response_code() {
		return qc_response_code;
	}
	public void setQc_response_code(String qc_response_code) {
		this.qc_response_code = qc_response_code;
	}
	public String getScan_id() {
		return scan_id;
	}
	public void setScan_id(String scan_id) {
		this.scan_id = scan_id;
	}
	public Date getDoc_notice_effective_date() {
		return doc_notice_effective_date;
	}
	public void setDoc_notice_effective_date(Date doc_notice_effective_date) {
		this.doc_notice_effective_date = doc_notice_effective_date;
	}
	public Date getDoc_delivery_date() {
		return doc_delivery_date;
	}
	public void setDoc_delivery_date(Date doc_delivery_date) {
		this.doc_delivery_date = doc_delivery_date;
	}
	public String getProperty_city() {
		return property_city;
	}
	public void setProperty_city(String property_city) {
		this.property_city = property_city;
	}
	public String getPolicy_number() {
		return policy_number;
	}
	public void setPolicy_number(String policy_number) {
		this.policy_number = policy_number;
	}
	public String getMortgagee_zip() {
		return mortgagee_zip;
	}
	public void setMortgagee_zip(String mortgagee_zip) {
		this.mortgagee_zip = mortgagee_zip;
	}
	public String getMortgagee_name() {
		return mortgagee_name;
	}
	public void setMortgagee_name(String mortgagee_name) {
		this.mortgagee_name = mortgagee_name;
	}
	public Date getDoc_notice_date() {
		return doc_notice_date;
	}
	public void setDoc_notice_date(Date doc_notice_date) {
		this.doc_notice_date = doc_notice_date;
	}
	public String getAgent_city() {
		return agent_city;
	}
	public void setAgent_city(String agent_city) {
		this.agent_city = agent_city;
	}
	public String getImpairment_code() {
		return impairment_code;
	}
	public void setImpairment_code(String impairment_code) {
		this.impairment_code = impairment_code;
	}
	public String getAgent_name() {
		return agent_name;
	}
	public void setAgent_name(String agent_name) {
		this.agent_name = agent_name;
	}
	public String getMailing_city() {
		return mailing_city;
	}
	public void setMailing_city(String mailing_city) {
		this.mailing_city = mailing_city;
	}
	public String getPolicy_cancel_reason() {
		return policy_cancel_reason;
	}
	public void setPolicy_cancel_reason(String policy_cancel_reason) {
		this.policy_cancel_reason = policy_cancel_reason;
	}
	public String getMortgagee_city() {
		return mortgagee_city;
	}
	public void setMortgagee_city(String mortgagee_city) {
		this.mortgagee_city = mortgagee_city;
	}
	public String getAgent_zip() {
		return agent_zip;
	}
	public void setAgent_zip(String agent_zip) {
		this.agent_zip = agent_zip;
	}
	public String getAccount_name() {
		return account_name;
	}
	public void setAccount_name(String account_name) {
		this.account_name = account_name;
	}
	public String getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}
	public int getBatch_seq_no() {
		return batch_seq_no;
	}
	public void setBatch_seq_no(int batch_seq_no) {
		this.batch_seq_no = batch_seq_no;
	}
	public Date getReinstatement_date() {
		return reinstatement_date;
	}
	public void setReinstatement_date(Date reinstatement_date) {
		this.reinstatement_date = reinstatement_date;
	}
	public String getTransaction_source() {
		return transaction_source;
	}
	public void setTransaction_source(String transaction_source) {
		this.transaction_source = transaction_source;
	}
	public String getCo_policy_holder_name() {
		return co_policy_holder_name;
	}
	public void setCo_policy_holder_name(String co_policy_holder_name) {
		this.co_policy_holder_name = co_policy_holder_name;
	}
	public Date getPolicy_effective_date() {
		return policy_effective_date;
	}
	public void setPolicy_effective_date(Date policy_effective_date) {
		this.policy_effective_date = policy_effective_date;
	}
	public String getProperty_state() {
		return property_state;
	}
	public void setProperty_state(String property_state) {
		this.property_state = property_state;
	}
	public String getCarrier_city() {
		return carrier_city;
	}
	public void setCarrier_city(String carrier_city) {
		this.carrier_city = carrier_city;
	}
	public String getAgent_phone() {
		return agent_phone;
	}
	public void setAgent_phone(String agent_phone) {
		this.agent_phone = agent_phone;
	}
	public String getCarrier_name() {
		return carrier_name;
	}
	public void setCarrier_name(String carrier_name) {
		this.carrier_name = carrier_name;
	}
	public String getLoan_suffix() {
		return loan_suffix;
	}
	public void setLoan_suffix(String loan_suffix) {
		this.loan_suffix = loan_suffix;
	}
	public Date getDoc_received_date() {
		return doc_received_date;
	}
	public void setDoc_received_date(Date doc_received_date) {
		this.doc_received_date = doc_received_date;
	}
	public String getMortgagee_address() {
		return mortgagee_address;
	}
	public void setMortgagee_address(String mortgagee_address) {
		this.mortgagee_address = mortgagee_address;
	}
	public String getCarrier_state() {
		return carrier_state;
	}
	public void setCarrier_state(String carrier_state) {
		this.carrier_state = carrier_state;
	}
	public Date getAs400_post_date() {
		return as400_post_date;
	}
	public void setAs400_post_date(Date as400_post_date) {
		this.as400_post_date = as400_post_date;
	}
	public String getAgent_address() {
		return agent_address;
	}
	public void setAgent_address(String agent_address) {
		this.agent_address = agent_address;
	}
	public double getAdditional_coverage_amount() {
		return additional_coverage_amount;
	}
	public void setAdditional_coverage_amount(double additional_coverage_amount) {
		this.additional_coverage_amount = additional_coverage_amount;
	}
	public double getAdditional_premium_amt() {
		return additional_premium_amt;
	}
	public void setAdditional_premium_amt(double additional_premium_amt) {
		this.additional_premium_amt = additional_premium_amt;
	}
	public String getInstitution_code() {
		return institution_code;
	}
	public void setInstitution_code(String institution_code) {
		this.institution_code = institution_code;
	}
	public String getCarrier_address_1() {
		return carrier_address_1;
	}
	public void setCarrier_address_1(String carrier_address_1) {
		this.carrier_address_1 = carrier_address_1;
	}
	public String getAgent_state() {
		return agent_state;
	}
	public void setAgent_state(String agent_state) {
		this.agent_state = agent_state;
	}
	public String getPolicy_holder_name() {
		return policy_holder_name;
	}
	public void setPolicy_holder_name(String policy_holder_name) {
		this.policy_holder_name = policy_holder_name;
	}
	public double getDeductible() {
		return deductible;
	}
	public void setDeductible(double deductible) {
		this.deductible = deductible;
	}
	public String getTransaction_type() {
		return transaction_type;
	}
	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}
	public String getMailing_zip() {
		return mailing_zip;
	}
	public void setMailing_zip(String mailing_zip) {
		this.mailing_zip = mailing_zip;
	}
	public String getMortgagee_state() {
		return mortgagee_state;
	}
	public void setMortgagee_state(String mortgagee_state) {
		this.mortgagee_state = mortgagee_state;
	}
	public String getCarrier_phone() {
		return carrier_phone;
	}
	public void setCarrier_phone(String carrier_phone) {
		this.carrier_phone = carrier_phone;
	}
	public double getBase_coverage_other_structs() {
		return base_coverage_other_structs;
	}
	public void setBase_coverage_other_structs(double base_coverage_other_structs) {
		this.base_coverage_other_structs = base_coverage_other_structs;
	}
}
