/**
 * 
 */
package gov.iwa.fema.export.processor;

import gov.iwa.export.csv.utils.CreateExcelUtils;
import gov.iwa.fema.export.bean.FemaObjectBean;
import gov.iwa.fema.export.dctm.methodbase.MethodBase;
import gov.iwa.fema.export.dctm.utils.DctmUtils;
import gov.iwa.fema.export.dctm.utils.IUtilConstants;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfTime;
import com.documentum.fc.common.IDfTime;


public class FEMAExportProcessor extends MethodBase{

	private static Logger log = Logger.getLogger(FEMAExportProcessor.class);
	
	public String fileShareLocation;
	
	@Override
	protected void doExecute() throws IOException,Exception {
		// TODO Auto-generated method stub
		IDfCollection dfColl=null;
		List<FemaObjectBean> fobList=null;

		try{

			log.info("Start Processing");
			fileShareLocation=getStringProperty(IUtilConstants.JOB_PARAM_FILE_SHARE_LOCATION);

			//check file share exists
			if(DctmUtils.isFileShareValid(fileShareLocation)){
				
				fobList=new ArrayList<FemaObjectBean>();
			
				String exportQry="select r_object_id,invoice_no,vendor_name,department,po_no,voucher_no,gl_index_code,received_date,total_amt from mdc_iwa_invoice where any hist_date >= DATE('11/1/2020 00:00:00','MM/DD/YYYY hh:mm:ss') and any hist_date < DATE('11/24/2020 12:00:00','MM/DD/YYYY hh:mm:ss') and any gl_index_code in ('NDLACOVID','CRCOVID19','CTCOVID19','FRECOVID19','FNECOVID019','HRCOVID19','HTCOVID','FREOEMVIRUS','MTCOVID19','PECOVID19','SWEC0COVID19','SWED0COVID19','ADEMERGENCY','COCOVID19','JU03420590','PREGEN177219','SWEMOCOVID19','LBCOVID19','ELECOVID19','CUECOVID19','SWED0COVIDCY','CL0000000050','SAECOVID','ndlacovid','crcovid19','ctcovid19','frecovid19','fnecovid019','hrcovid19','htcovid','freoemvirus','mtcovid19','pecovid19','swec0covid19','swed0covid19','ademergency','cocovid19','ju03420590','pregen177219','swemocovid19','lbcovid19','elecovid19','cuecovid19','mtpwcovid-19','swed0covidcy','cl0000000050','saecovid','MTPWCOVID-19') and invoice_status = 'Complete'";
				
				 dfColl=DctmUtils.executeQuery(getSession(), exportQry, DfQuery.DF_EXEC_QUERY);
				
				 //Build Bean List
				while(dfColl.next()){
					
					String r_object_id=dfColl.getString("r_object_id");
					String invoice_no=dfColl.getString("invoice_no");
					String vendor_name=dfColl.getString("vendor_name");
					String department=dfColl.getString("department");
					String po_no=dfColl.getString("po_no");
					
					fobList.add(DctmUtils.createFemaObjectBean(r_object_id, invoice_no, vendor_name, department, po_no));
					
				}
				
				//Iterate over the list to export content and generate report
				
				if(fobList!=null && fobList.size()>0){
					
					for(FemaObjectBean fobBean : fobList){
						
						if(DctmUtils.exportObject(getSession(), fobBean.getR_object_id(), fileShareLocation)){
							
							log.debug("Export Success : "+fobBean.getR_object_id());
							
						}
						
					}
					CreateExcelUtils.generateWorkbook(fileShareLocation, fobList);
					log.debug("Report generated : "+fileShareLocation);
				}
				
			}else{

				log.error("INVALID file share location : "+fileShareLocation +" , Please input the job correct  : 'file_share_location'");
				throw new IOException("INVALID file share location : "+fileShareLocation +" ,  Please input the job correct file_share_location");
				
			}
		}catch(IOException e){
			log.error("Error : "+DctmUtils.getExceptionStack(e));
			throw e;
		}catch(Exception e){
			log.error("Error : "+DctmUtils.getExceptionStack(e));
			throw e;
		}finally{
			
			closeCollection(dfColl);
		}


	}
	}
	



