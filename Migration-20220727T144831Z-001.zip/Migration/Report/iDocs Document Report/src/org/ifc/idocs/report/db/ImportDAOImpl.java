package org.ifc.idocs.report.db;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.ifc.idocs.report.common.LogHelper;
import org.owasp.esapi.ESAPI;
import org.owasp.esapi.errors.EncryptionException;

import com.documentum.fc.client.DfAuthenticationException;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.DfIdentityException;
import com.documentum.fc.client.DfPrincipalException;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfLoginInfo;

public class ImportDAOImpl extends DBFactory{
	
	private static IDfSession dfSession = null;
	private static IDfSessionManager sessionMgr = null;	
	private Logger exportDocLogger = LogHelper.getLogger(ImportDAOImpl.class);
			
	public static IDfSessionManager getSessionMgr(String strUserName, String strPassword, String strDocbase){
		IDfSessionManager sMgr = null;
		try{
			IDfClient client = DfClient.getLocalClient();
			sMgr = client.newSessionManager();
			IDfLoginInfo login = new DfLoginInfo();
			login.setUser(strUserName);
			login.setPassword(ESAPI.encryptor().decrypt(strPassword));
			login.setDomain(null);
			sMgr.setIdentity(strDocbase, login);
		} catch (DfException e) {
			e.printStackTrace();
		} catch (EncryptionException e) {
			e.printStackTrace();
		}
		return sMgr;
	}
	
	protected  IDfSession  initializeSession() {
		if(dfSession == null){
			exportDocLogger.warning("Creating dfSession...");
	        String strUserName = "idocsmigrusrprd"; // "idocsmigrusrqa"; // "ifcecmidocsdevadmin";
	        String strPassword = "WmDLLNvNUvl4Xu4eOGSHoQ=="; // "ifc@qamIgru3r"; // "ifc3cmd0c$adm";
	        String strDocbase = "ifcecmidocs"; // "ifcecmqaidocs"; // "ifcecmdevidocs";
			
			try {
				sessionMgr = getSessionMgr(strUserName, strPassword, strDocbase);
				dfSession = sessionMgr.getSession(strDocbase);
				exportDocLogger.warning("login username::" + dfSession.getLoginUserName());
			} catch (DfIdentityException e) {
				exportDocLogger.warning("DfIdentityException::"+e.getMessage());
				e.printStackTrace();
			} catch (DfAuthenticationException e) {
				exportDocLogger.warning("DfAuthenticationException::"+e.getMessage());
				e.printStackTrace();
			} catch (DfPrincipalException e) {
				exportDocLogger.warning("DfPrincipalException::"+e.getMessage());
				e.printStackTrace();
			} catch (DfServiceException e) {
				exportDocLogger.warning("DfServiceException::"+e.getMessage());
				e.printStackTrace();
			} catch (DfException e) {
				exportDocLogger.warning("DfException::"+e.getMessage());
				e.printStackTrace();
			}
		}
		return dfSession;
	}	

	public void updateReconTables(String country, String tableName, String columnName, String prefix, String folderTypeCode, String extractionId) throws DfException{
		IDfSession dfSession =  initializeSession();
		String folderValueCode = null, docId = null, docUnid = null;		
		String strQuery = "select orig_doc_unique_id, orig_doc_id, " + columnName + " from " + tableName + " where country_code='" + country + "' and orig_doc_id <> ' '";
		StringBuffer sb = new StringBuffer();
		exportDocLogger.warning("Processing : " + country);
		IDfCollection dfCollection = executeQuery(dfSession, strQuery, IDfQuery.DF_READ_QUERY);
		while (dfCollection.next()){
			docId = dfCollection.getString("orig_doc_id");
			docUnid = dfCollection.getString("orig_doc_unique_id");
			folderValueCode = dfCollection.getString(columnName);
//			exportDocLogger.warning("Processing : " + folderValueCode + " ~ Doc Id : " + docId + " ~ Doc Unique Id : " + docUnid );
			sb.append(folderValueCode).append(",").append(docId).append(",").append(docUnid).append("\n");
		}
		if(sb.length() > 0){ 
			try {
				String fileName = config.getString("repository.exportPath") + extractionId +".csv";
			    FileWriter fstream = new FileWriter(fileName);
		        BufferedWriter out = new BufferedWriter(fstream);
			    out.write(sb.toString());
			    out.close();
			} catch (IOException e) {
				e.printStackTrace();
				exportDocLogger.log(Level.WARNING,"IOException-", e);
			}
		}
		exportDocLogger.warning("Completed : " + country);
		if (dfCollection != null){
			dfCollection.close();
		}
		sb.delete(0, sb.length());
		System.gc();
	}
	
	protected IDfCollection executeQuery(IDfSession dfSession, String strQuery, int queryType) throws DfException{
		IDfCollection dfCollection = null;
		IDfQuery dfQuery = new DfQuery();
		exportDocLogger.warning("Utilities :: executeQuery() : strQuery : " + strQuery);
		dfQuery.setDQL(strQuery);
		dfCollection = dfQuery.execute(dfSession,queryType);
		return dfCollection;
	} 

}
