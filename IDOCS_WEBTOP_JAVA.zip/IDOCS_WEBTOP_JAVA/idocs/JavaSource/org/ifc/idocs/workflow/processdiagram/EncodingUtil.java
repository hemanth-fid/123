/**
* 
* This class is encoding the Utility conditions.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.workflow.processdiagram;

import com.documentum.fc.common.DfLogger;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import javax.servlet.http.HttpServletResponse;
 
public class EncodingUtil
{
  public static String toUTF8(String paramString, HttpServletResponse paramHttpServletResponse)
  {
    String str1 = paramString;
    if ((null != paramString) && (!(paramString.equals(""))))
    {
      String str2 = paramHttpServletResponse.getCharacterEncoding();
      if (str2 != null)
        try
        {
          byte[] arrayOfByte = paramString.getBytes(str2);
          str1 = new String(arrayOfByte, "UTF-8");
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException)
        {
          DfLogger.warn(EncodingUtil.class, " :: toUTF8 Exception >> " + localUnsupportedEncodingException.getMessage(), null, localUnsupportedEncodingException);
        }
    }
    return str1;
  }

  public static String decodeString(String paramString)
  {
    return decodeString(paramString, null);
  }

  public static String decodeString(String paramString, HttpServletResponse paramHttpServletResponse)
  {
    if (paramString != null)
      try
      {
        paramString = paramString.replace("%2B", "+").replace("%23", "#").replace("%26", "&").replace("%3C", "<").replace("%3E", ">").replace("%3F", "?").replace("%3B", ";").replace("%2F", "/").replace("%25", "%");
        if (paramHttpServletResponse != null)
          paramString = toUTF8(paramString, paramHttpServletResponse);
        paramString = URLDecoder.decode(paramString, "UTF-8");
      }
      catch (Exception localException)
      {
        DfLogger.error(EncodingUtil.class," :: decodeString Exception >> " + localException.getMessage(), null, localException);
      }
    return paramString;
  }

  public static String encodeString(String paramString)
  {
    if (paramString != null)
      paramString = paramString.replace("%", "%25").replace("#", "%23").replace("&", "%26").replace("?", "%3F").replace("+", "%2B");
    return paramString;
  }

  public static String urlEencodeString(String paramString)
  {
    if (paramString != null)
    {
      try
      {
        paramString = URLEncoder.encode(paramString, "UTF-8");
      }
      catch (Exception localException)
      {
        DfLogger.error(EncodingUtil.class," :: urlEencodeString Exception >> " + localException.getMessage(), null, localException);
      }
      paramString = paramString.replace("%", "%25").replace("#", "%23").replace("&", "%26").replace("?", "%3F").replace("+", "%2B");
    }
    return paramString;
  }
}