package com.SWBC.DataService;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.sql.DataSource;

import java.util.Properties;

import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.tools.ant.taskdefs.optional.extension.resolvers.LocationResolver;
import org.drools.core.definitions.rule.impl.RuleImpl;
import org.drools.core.rule.Pattern;
import org.drools.core.spi.KnowledgeHelper;
import org.json.JSONObject;
import org.kie.api.runtime.KieSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.SWBC.model.Brm_app_info;
import com.SWBC.model.Brm_app_json_info;
//import com.SWBC.model.Brm_app_json_info;
import com.SWBC.model.Brm_loan_info;
import com.SWBC.model.Brm_policy_info;
import com.SWBC.model.Brm_processing_info;
import com.SWBC.model.Brm_request_info;
import com.SWBC.model.Brm_rule;
import com.SWBC.model.Brm_rule_lookup_log;
import com.SWBC.model.PreProc_Doca_Ucap;
import com.SWBC.model.Trec;
import com.SWBC.utilities.BRMUtilities;
import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;

import static com.SWBC.utilities.BRMConstants.*;

@Repository
@Qualifier("trecDao")
@PropertySource(value = { "classpath:application.properties" })
public class TrecDaoImpl implements TrecDao {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	JdbcTemplate jdbcTemplate;
	@Autowired
	JdbcTemplate jdbcTemplate_iir;
	@Autowired
	JdbcTemplate jdbcTemplate_FMI006;
	@Autowired
	JdbcTemplate jdbcTemplate_AS400;
	@Autowired
	private Environment env;
	@Autowired
	private Connection AS400Conn;
	@Autowired
	private ArrayList<String> mortlibraryList;
	@Autowired
	private DataSource dataSource;

	public void insertLogTbl(String transaction_id, String transaction_type, String inputParameter, String ruleName,
			String ruleOutcome, String ruleMsg, String loginUserName, String cov_type, String loan_account_no,
			String loan_no, String loan_no_suffix, int policyTLMatchScore, String source, String rule_version,
			String jsonString) {

		if (source.equalsIgnoreCase(API_SOURCE)) {

			jdbcTemplate.update(env.getRequiredProperty("insert.log.tbl"), transaction_id, transaction_type,
					inputParameter, ruleName, ruleOutcome, ruleMsg, loginUserName, cov_type, loan_account_no, loan_no,
					loan_no_suffix, policyTLMatchScore, source, rule_version, jsonString);

			logger.debug("Log Inserted Successfully For " + transaction_id + " and Coverage Type:" + cov_type
					+ ", Loan Number:" + loan_no + " as " + ruleOutcome + " [" + ruleMsg + "] for the rule "
					+ ruleName);
		} else if (source.equalsIgnoreCase("app")) {
			jdbcTemplate.update(env.getRequiredProperty("insert.log.app.tbl"), transaction_id, transaction_type,
					inputParameter, ruleName, ruleOutcome, ruleMsg, loginUserName, cov_type, loan_account_no, loan_no,
					"0", policyTLMatchScore, source, rule_version, jsonString);

			logger.debug("Log Inserted Successfully For " + transaction_id + " and Coverage Type:" + cov_type
					+ ", Loan Number:" + loan_no + " as " + ruleOutcome + " [" + ruleMsg + "] for the rule "
					+ ruleName);

		}

	}

	public List<Brm_processing_info> getProcInfo(Brm_request_info brm_request_info) {

		List<Brm_processing_info> procInfo = new ArrayList<Brm_processing_info>();
		String sql = env.getRequiredProperty("select.proc.tbl.input.qur");
		List<Map<String, Object>> rows;

		// AND T.match_status IN ('F', 'M') AND P.final_decision IN ('F', 'M')
		// AND F.EM_PROCESS_FLAG IN ('S', 'M')

		if (brm_request_info.getSingleAPITrec().equalsIgnoreCase("true")) {
			
			sql = sql + "AND [EM_DOC_NO] = ? AND P.[account_number_iir_match] = ? AND P.[loan_number_iir_match] = ? "
					+ "AND P.[coverage_type_iir_match] = ? AND [EM_LOAN_SUFFIX] = ?";
			
			
			rows = jdbcTemplate_iir.queryForList(sql,
					new Object[] { brm_request_info.getTid().trim(),brm_request_info.getAcc_no().trim(),brm_request_info.getLoan_no().trim(),					
							brm_request_info.getCov_type().trim(),brm_request_info.getLoan_suffix().trim() });
		} else {
			
			//sql = sql + " AND T.match_status IN ('F', 'M') AND P.final_decision IN ('F', 'M') ";
			
			sql = sql + " AND T.match_status IN ('F', 'M') AND P.final_decision IN ('F', 'M') AND F.EM_PROCESS_FLAG IN ('S', 'M') ";
			
			if (brm_request_info.getTransType().equalsIgnoreCase("NBSALL")) {
				sql = sql + " AND F.[EM_POL_TRAN_CODE] IN ("
						+ env.getRequiredProperty("select.transaction.nbs.types.NBSALL") + ")";
				// sql = sql + " AND F.[EM_POL_TRAN_CODE] IN ("
				// +
				// env.getRequiredProperty("select.transaction.nbs.types.NBSALL")+")
				// order by NEWID()";
			} else if (brm_request_info.getTransType().equalsIgnoreCase("XLCALL")) {
				sql = sql + " AND F.[EM_POL_TRAN_CODE] IN ('RWX','XLC')";
			} else if (brm_request_info.getTransType().equalsIgnoreCase("ALL")) {
				sql = sql + " AND F.[EM_POL_TRAN_CODE] IN (" + env.getRequiredProperty("select.transaction.types.ALL")
						+ ")";
			} else {
				sql = filterQryByType(sql, brm_request_info.getTransType());
			}

			rows = jdbcTemplate_iir.queryForList(sql);
		}

		logger.debug("Source Input Query:" + sql);

		for (Map row : rows) {
			// Loan Line
			Brm_processing_info proc = new Brm_processing_info();
			proc.setAccountNumber(row.get("AccountNumber") == null ? "" : row.get("AccountNumber").toString().trim());

			proc.setTransaction_loan_no(
					row.get("TransactionLoanNo") == null ? "" : row.get("TransactionLoanNo").toString().trim());

			proc.setTansactionLoanSuffix(
					row.get("TransactionLoanSuffix") == null ? "" : row.get("TransactionLoanSuffix").toString().trim());

			proc.setTransaction_cov_type(
					row.get("CoverageTypeIIR") == null ? "" : row.get("CoverageTypeIIR").toString().trim());

			proc.setTransaction_id(row.get("TransactionID") == null ? "" : row.get("TransactionID").toString().trim());

			proc.setTransaction_type(row.get("DocumentType") == null ? "" : row.get("DocumentType").toString().trim());

			proc.setTransaction_policy_no(row.get("PolicyNo") == null ? "" : row.get("PolicyNo").toString().trim());

			proc.setTransaction_policy_reason(row.get("TransactionCancelReason") == null ? ""
					: row.get("TransactionCancelReason").toString().trim());

			try {
				proc.setTransaction_cancel_date((java.util.Date) row.get("TransactionCancelDate") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("TransactionCancelDate"));
			} catch (ParseException e) {

				logger.debug(" TransactionCancelDate:" + e.getMessage().toString());
			}

			try {
				proc.setTransaction_reinstatement_date((java.util.Date) row.get("TransactionReinstatementDate") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("TransactionReinstatementDate"));
			} catch (ParseException e) {

				logger.debug(" TransactionReinstatementDate:" + e.getMessage().toString());
			}

			// EM_POL_PROCESS_DATE
			// proc.setTransaction_doc_issue_date((java.util.Timestamp)
			// row.get("DocIssueDate"));
			try {
				proc.setTransaction_doc_issue_date((java.util.Date) row.get("DocIssueDate") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("DocIssueDate"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
				logger.debug(" DocIssueDate:" + e.getMessage().toString());
			}

			// proc.setTransaction_doc_issue_date((java.sql.Timestamp)
			// row.get("DocIssueDate"));

			proc.setTransaction_mortgagee_name(
					row.get("MortageeName") == null ? "" : row.get("MortageeName").toString().trim());

			proc.setTransaction_status(
					row.get("final_decision") == null ? "" : row.get("final_decision").toString().trim());

			proc.setTransactionPolicyDecision(
					row.get("PolicyDecision") == null ? "" : row.get("PolicyDecision").toString().trim());

			// Transaction Effective Date and Expiration Date
			// proc.setTransaction_effective_date((java.sql.Timestamp)
			// row.get("TransactionEffectiveDate"));
			try {
				proc.setTransaction_effective_date(row.get("TransactionEffectiveDate").toString().trim().length() == 0
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("TransactionEffectiveDate"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
				logger.debug(" TransactionEffectiveDate:" + e.getMessage().toString());
			}

			// proc.setTransaction_expiration_date((java.sql.Timestamp)
			// row.get("TransactionExpirationDate"));
			try {
				proc.setTransaction_expiration_date((java.util.Date) row.get("TransactionExpirationDate") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("TransactionExpirationDate"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
				logger.debug(" TransactionExpirationDate:" + e.getMessage().toString());
			}

			// Transaction Company Name
			proc.setTransactionInsurer(row.get("EM_INSURER") == null ? "" : row.get("EM_INSURER").toString().trim());

			proc.setTransaction_impairment_code(
					row.get("EM_IMPAIR_CD") == null ? "" : row.get("EM_IMPAIR_CD").toString().trim());

			proc.setTransaction_flood_zone(
					row.get("EM_FLOOD_ZONE") == null ? "" : row.get("EM_FLOOD_ZONE").toString().trim());

			// proc.setTransaction_coverage_amt(Double.valueOf(row.get("EM_COV_AMT").toString().trim()));
			proc.setTransaction_coverage_amt(
					row.get("EM_COV_AMT") == null ? 0.0 : Double.valueOf(row.get("EM_COV_AMT").toString().trim()));

			// proc.setTransaction_premium_amt(Double.valueOf(row.get("EM_POL_PREM").toString().trim()));
			proc.setTransaction_premium_amt(
					row.get("EM_POL_PREM") == null ? 0.0 : Double.valueOf(row.get("EM_POL_PREM").toString().trim()));

			proc.setTransaction_premium_net_amt(
					row.get("EM_NET_AMT") == null ? 0.0 : Double.valueOf(row.get("EM_NET_AMT").toString().trim()));

			proc.setTransaction_edi_deductible_per(row.get("DEDUCTABLE_PERCENTAGE_EDI") == null ? 0.0
					: Double.valueOf(row.get("DEDUCTABLE_PERCENTAGE_EDI").toString().trim()));

			proc.setTransaction_non_edi_deductible_per(row.get("DEDUCTABLE_PERCENTAGE_NON_EDI") == null ? 0.0
					: Double.valueOf(row.get("DEDUCTABLE_PERCENTAGE_NON_EDI").toString().trim()));

			proc.setTransaction_deductible_amt(row.get("DEDUCTABLE_AMOUNT") == null ? 0.0
					: Double.valueOf(row.get("DEDUCTABLE_AMOUNT").toString().trim()));

			proc.setTransaction_operator_id(
					row.get("EM_OPERATOR_ID") == null ? "" : row.get("EM_OPERATOR_ID").toString().trim());

			proc.setTransaction_naic_code(row.get("EM_NAIC") == null ? "NA" : row.get("EM_NAIC").toString().trim());

			proc.setPolicy_type(row.get("EM_POL_TYPE") == null ? "" : row.get("EM_POL_TYPE").toString().trim());

			proc.setDelete_counter(row.get("delete_counter") == null ? 0
					: Integer.parseInt(row.get("delete_counter").toString().trim()));

			procInfo.add(proc);

		}

		return procInfo;

	}

	public void insertLoanTblData(List<Brm_loan_info> loanData) {

		if (loanData.get(0).getLoan_no().equalsIgnoreCase(NO_LOAN)) {
			logger.debug("No Loan Entry");
			for (Brm_loan_info brm_loan_info : loanData) {
				jdbcTemplate.update(env.getRequiredProperty("insert.loan.tbl"), null, null, null, null, null, null,
						null, null, null, null, null, brm_loan_info.getTransaction_id(), null, null,
						// Lookup Values
						null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
						null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
						null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,null,null,null,null);

				logger.debug("NULL Loan Record Inserted Successfully for Transaction ID:"
						+ brm_loan_info.getTransaction_id());
			}
		} else {
			for (Brm_loan_info brm_loan_info : loanData) {

				jdbcTemplate.update(env.getRequiredProperty("insert.loan.tbl"), brm_loan_info.getLoan_insur_type(),
						brm_loan_info.getLoan_no_suffix(), brm_loan_info.getLoan_no(),
						brm_loan_info.getLoan_account_no(), brm_loan_info.getLoan_cov_type(),
						brm_loan_info.getLoan_policy_no(), brm_loan_info.getLoan_expiration_date(),
						brm_loan_info.getLoan_doc_issue_date(), brm_loan_info.getLoan_insur_status(),
						brm_loan_info.getLoan_uninsured_date(), brm_loan_info.getLoan_escrow_code(),
						brm_loan_info.getTransaction_id(), brm_loan_info.getLoan_company_name(),
						brm_loan_info.getLoan_mortgagee_name(),
						// Lookup Values
						brm_loan_info.getLoan_escrow_client(), brm_loan_info.getLoan_pme_bill_date(),
						brm_loan_info.getLoan_his_rei_date(), brm_loan_info.getLoan_his_dual_policy_no(),
						brm_loan_info.getPolicyScore(), brm_loan_info.getPMEDays(), brm_loan_info.getREIDays(),
						brm_loan_info.getLoan_property_type(), brm_loan_info.getLoan_effective_date(),
						brm_loan_info.getRei_fmr_date_check(), brm_loan_info.getLoan_swbc_check(),
						brm_loan_info.getLoan_es_rcvd_date(), brm_loan_info.getLoan_es_check_no(),
						brm_loan_info.getLoan_es_eff_date(), brm_loan_info.getLoan_es_exp_date(),
						brm_loan_info.getLoan_pme_creation_date(),
						// Insurance Status Fields
						brm_loan_info.getLoan_is_waive_inititals(), brm_loan_info.getLoan_is_spare_code_1(),
						brm_loan_info.getLoan_is_waive_date(), brm_loan_info.getLoan_is_audit_code(),
						brm_loan_info.getLoan_is_letter_code(), brm_loan_info.getLoan_is_impairment_code(),
						brm_loan_info.getLoan_calculated_ins_status(), brm_loan_info.getLoan_pme_current_term().trim(),
						brm_loan_info.getLoan_pme_es_policy_no(), brm_loan_info.getLoan_pme_policy_score(),
						brm_loan_info.getLoan_ag_spare_code(), brm_loan_info.getLoan_flood_zone(),
						brm_loan_info.getLoan_pme_premium_amt(), brm_loan_info.getLoan_ag_coverage_amt(),
						brm_loan_info.getLoan_pme_effective_date(), brm_loan_info.getLoan_pme_expiration_date(),
						brm_loan_info.getLoan_dual_policy_score(), brm_loan_info.getLoan_transaction_id(),
						brm_loan_info.getDisbursementFlag(), brm_loan_info.getLoan_escrow_premium_amt(),
						brm_loan_info.getLoan_ag_deductible_amt(), brm_loan_info.getLoan_ag_deductible_pct(),
						brm_loan_info.getLoan_gap_line(), brm_loan_info.getLoan_gap_effective_date(),
						brm_loan_info.getLoan_gap_expiration_date(), brm_loan_info.getAs400_loan_ins_status_msg(),
						brm_loan_info.getVSIPolicyNo(), brm_loan_info.getEs_void(),
						brm_loan_info.getLoan_ag_spare_code3(), brm_loan_info.getbICEffectiveDate(),
						brm_loan_info.getbICExpirationDate(), brm_loan_info.getIs_Letter_cycle()
						,brm_loan_info.getWaive_code(),brm_loan_info.getLoan_board_date(),brm_loan_info.getMax_prem_amt(),brm_loan_info.getTol_prem_pct());

				logger.debug("Loan Record Inserted Successfully For " + brm_loan_info.getTransaction_id());

			}
		}

	}

	public List<Brm_app_info> getAppInfo(String userID, String transType) {

		String sql = env.getRequiredProperty("select.app.tbl.input.qur");

		// Filtering the query by user
		sql = sql.replaceAll("#U", userID);
		logger.debug("Source Input App Query:" + sql);

		List<Brm_app_info> appInfo = new ArrayList<Brm_app_info>();

		List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql, new Object[] { transType });

		for (Map row : rows) {

			Brm_app_info proc = new Brm_app_info();

			try {
				logger.debug("Transaction ID::::::::::::::::::::::" + row.get("transaction_id").toString().trim());
				proc.setAccountNumber(row.get("account_no") == null ? "" : row.get("account_no").toString().trim());

				proc.setAs400_post_date((java.sql.Date) row.get("as400_post_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("as400_post_date"));

				proc.setLoan_account_no(
						row.get("loan_account_no") == null ? "" : row.get("loan_account_no").toString().trim());

				proc.setTransactionInsurer(row.get("transaction_insurer_name") == null ? ""
						: row.get("transaction_insurer_name").toString().trim());

				proc.setLoan_begin_date((java.sql.Date) row.get("loan_begin_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("loan_begin_date"));

				proc.setLoan_cancel_date((java.sql.Date) row.get("loan_cancel_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("loan_cancel_date"));
				proc.setLoan_company_name(
						row.get("loan_company_name") == null ? "" : row.get("loan_company_name").toString().trim());
				proc.setLoan_cov_type(
						row.get("loan_cov_type") == null ? "" : row.get("loan_cov_type").toString().trim());
				proc.setLoan_doc_issue_date((java.sql.Date) row.get("loan_doc_issue_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("loan_doc_issue_date"));
				proc.setLoan_effective_date((java.sql.Date) row.get("loan_effective_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("loan_effective_date"));
				proc.setLoan_escrow_client(row.get("loan_escrow_client").toString().trim());
				proc.setLoan_escrow_code(row.get("loan_escrow_code").toString().trim());
				proc.setLoan_expiration_date((java.sql.Date) row.get("loan_expiration_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("loan_expiration_date"));
				proc.setLoan_his_rei_date((java.sql.Date) row.get("loan_his_rei_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("loan_his_rei_date"));
				proc.setLoan_insur_status(row.get("loan_insur_status").toString().trim());

				proc.setLoan_cov_type(
						row.get("loan_cov_type") == null ? "" : row.get("loan_cov_type").toString().trim());

				proc.setLoan_insur_type(
						row.get("loan_insur_type") == null ? "" : row.get("loan_insur_type").toString().trim());

				proc.setLoan_cov_type(
						row.get("loan_cov_type") == null ? "" : row.get("loan_cov_type").toString().trim());

				proc.setLoan_mortgagee_name(
						row.get("loan_mortgagee_name") == null ? "" : row.get("loan_mortgagee_name").toString().trim());

				proc.setLoan_cov_type(
						row.get("loan_cov_type") == null ? "" : row.get("loan_cov_type").toString().trim());

				proc.setLoan_no(row.get("loan_no") == null ? "" : row.get("loan_no").toString().trim());

				proc.setLoan_no_suffix(
						row.get("loan_no_suffix") == null ? "" : row.get("loan_no_suffix").toString().trim());

				proc.setLoan_pme_bill_date((java.sql.Date) row.get("loan_pme_bill_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("loan_pme_bill_date"));
				proc.setLoan_policy_no(
						row.get("loan_policy_no") == null ? "" : row.get("loan_policy_no").toString().trim());
				proc.setLoan_transaction_date((java.sql.Date) row.get("loan_transaction_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("loan_policy_no"));
				proc.setLoan_uninsured_date((java.sql.Date) row.get("loan_uninsured_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("loan_uninsured_date"));
				proc.setProc_user(row.get("proc_user").toString());
				proc.setRule_outcome(row.get("rule_outcome") == null ? "" : row.get("rule_outcome").toString().trim());
				proc.setTansactionLoanSuffix(row.get("loan_suffix").toString().trim());
				proc.setTransaction_cancel_date((java.sql.Date) row.get("transaction_cancel_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("transaction_cancel_date"));
				proc.setTransaction_cov_type(row.get("transaction_cov_type").toString().trim());
				proc.setTransaction_doc_issue_date((java.sql.Date) row.get("transaction_doc_issue_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("transaction_doc_issue_date"));

				proc.setTransaction_id(
						row.get("transaction_id") == null ? "" : row.get("transaction_id").toString().trim());

				proc.setTransaction_loan_no(
						row.get("transaction_loan_no") == null ? "" : row.get("transaction_loan_no").toString().trim());

				proc.setTransaction_mortgagee_name(row.get("transaction_mortgagee_name") == null ? ""
						: row.get("transaction_mortgagee_name").toString().trim());

				proc.setTransaction_policy_no(row.get("transaction_policy_no") == null ? ""
						: row.get("transaction_policy_no").toString().trim());

				proc.setTransaction_policy_reason(row.get("transaction_policy_reason") == null ? ""
						: row.get("transaction_policy_reason").toString().trim());
				proc.setTransaction_reinstatement_date((java.sql.Date) row.get("transaction_reinstatement_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("transaction_reinstatement_date"));
				// proc.setTransaction_type(row.get("transaction_type").toString());

				proc.setTransactionPolicyDecision(
						row.get("policy_decision") == null ? "" : row.get("policy_decision").toString().trim());

				proc.setLoan_his_dual_policy_no(row.get("loan_his_dual_policy_no") == null ? ""
						: row.get("loan_his_dual_policy_no").toString().trim());

				proc.setPolicyScore(row.get("policy_score") == null ? 0
						: Integer.parseInt(row.get("policy_score").toString().trim()));

				proc.setPMEDays(
						row.get("PMEDays") == null ? 0 : Integer.parseInt(row.get("PMEDays").toString().trim()));

				proc.setREIDays(
						row.get("REIDays") == null ? 0 : Integer.parseInt(row.get("REIDays").toString().trim()));

				proc.setTransaction_effective_date((java.sql.Date) row.get("transaction_effective_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("transaction_effective_date"));
				proc.setTransaction_expiration_date((java.sql.Date) row.get("transaction_expiration_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("transaction_expiration_date"));
				proc.setES_RCVD_DATE((java.sql.Date) row.get("ES_RCVD_DATE") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("ES_RCVD_DATE"));
				proc.setES_EFF_DATE((java.sql.Date) row.get("ES_EFF_DATE") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("ES_EFF_DATE"));
				proc.setES_EXP_DATE((java.sql.Date) row.get("ES_EXP_DATE") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("ES_EXP_DATE"));
				proc.setSwbc_chk(row.get("SWBC_CHECK") == null ? "" : row.get("SWBC_CHECK").toString().trim());

				proc.setES_CHECK_NO(
						row.get("SWBC_CHECK") == null ? 0 : Integer.parseInt(row.get("ES_CHECK_NO").toString()));

				proc.setTransaction_type(row.get("transaction_type").toString().trim());
				proc.setRei_fmr_date_check(
						row.get("rei_fmr_date_check") == null ? "" : row.get("rei_fmr_date_check").toString().trim());
				proc.setLoan_pme_current_term(row.get("loan_pme_current_term") == null ? ""
						: row.get("loan_pme_current_term").toString().trim());
				proc.setLoan_pme_es_policy_no(row.get("loan_pme_es_policy_no") == null ? ""
						: row.get("loan_pme_es_policy_no").toString().trim());

				proc.setLoan_pme_effective_date((java.util.Date) row.get("loan_pme_effective_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("loan_pme_effective_date"));

				proc.setTransaction_effective_date((java.util.Date) row.get("transaction_effective_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("transaction_effective_date"));

				proc.setTransaction_expiration_date((java.util.Date) row.get("transaction_expiration_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("transaction_expiration_date"));

				proc.setLoan_pme_expiration_date((java.util.Date) row.get("loan_pme_expiration_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("loan_pme_expiration_date"));

				proc.setTransaction_impairment_code(row.get("transaction_impairment_code") == null ? ""
						: row.get("transaction_impairment_code").toString().trim());

				proc.setTransaction_em_cov_amt(row.get("transaction_em_cov_amt") == null ? 0
						: Float.parseFloat(row.get("transaction_em_cov_amt").toString()));

				proc.setTransaction_premium_amt(row.get("transaction_premium_amt") == null ? 0
						: Float.parseFloat(row.get("transaction_premium_amt").toString()));

				proc.setTransaction_premium_net_amt(row.get("transaction_premium_net_amt") == null ? 0
						: Float.parseFloat(row.get("transaction_premium_net_amt").toString()));

				proc.setTransaction_em_flood_zone(row.get("transaction_em_flood_zone") == null ? ""
						: row.get("transaction_em_flood_zone").toString().trim());

				proc.setDisbursementFlag(
						row.get("disbursementFlag") == null ? "" : row.get("disbursementFlag").toString().trim());

				proc.setLoan_impairment_code(row.get("loan_impairment_code") == null ? ""
						: row.get("loan_impairment_code").toString().trim());

				proc.setLoan_ag_coverage_amt(row.get("loan_ag_coverage_amt") == null ? 0
						: Float.parseFloat(row.get("loan_ag_coverage_amt").toString()));

				proc.setLoan_ag_coverage_amt(row.get("loan_ag_coverage_amt") == null ? 0
						: Float.parseFloat(row.get("loan_ag_coverage_amt").toString()));

				proc.setLoan_pme_premium_amt(row.get("loan_pme_premium_amt") == null ? 0
						: Float.parseFloat(row.get("loan_pme_premium_amt").toString()));

				proc.setLoan_ag_flood_zone(
						row.get("loan_ag_flood_zone") == null ? "" : row.get("loan_ag_flood_zone").toString().trim());

				proc.setLoan_transaction_id(
						row.get("loan_transaction_id") == null ? "" : row.get("loan_transaction_id").toString().trim());

				proc.setTransaction_edi_deductible_per(row.get("transaction_edi_deductible_per") == null ? 0.0
						: Double.valueOf(row.get("transaction_edi_deductible_per").toString().trim()));
				proc.setTransaction_non_edi_deductible_per(row.get("transaction_non_edi_deductible_per") == null ? 0.0
						: Double.valueOf(row.get("transaction_non_edi_deductible_per").toString().trim()));
				proc.setTransaction_deductible_amt(row.get("transaction_deductible_amt") == null ? 0.0
						: Double.valueOf(row.get("transaction_deductible_amt").toString().trim()));
				proc.setLoan_escrow_premium_amt(row.get("loan_escrow_premium_amt") == null ? 0.0
						: Double.valueOf(row.get("loan_escrow_premium_amt").toString().trim()));

				proc.setLoan_ag_deductible_amt(row.get("loan_ag_deductible_amt") == null ? 0
						: Double.parseDouble(row.get("loan_ag_deductible_amt").toString()));
				proc.setLoan_ag_deductible_pct(row.get("loan_ag_deductible_pct") == null ? 0
						: Double.parseDouble(row.get("loan_ag_deductible_pct").toString()));

			}

			catch (Exception e) {
				e.printStackTrace();
			}

			appInfo.add(proc);
		}

		return appInfo;

	}

	public String getEscrowClient(String procAccountNo) {
		String escrowClient = "";

		// Check if the account exisits
		String sqlCount = env.getRequiredProperty("select.escrowClient.count");
		int total = jdbcTemplate_iir.queryForObject(sqlCount, new Object[] { procAccountNo }, Integer.class);

		// Get Default Flag
		String sqlGetFlag = env.getRequiredProperty("select.escrowClient.default");
		List<Map<String, Object>> rows = jdbcTemplate_iir.queryForList(sqlGetFlag);
		String defaultFlag = "";

		for (Map row : rows) {
			defaultFlag = row.get("DefaultFlag").toString().trim();
		}
		logger.debug("Default Client:" + defaultFlag);

		if (total == 0) {
			escrowClient = defaultFlag;
		} else {
			String sql = env.getRequiredProperty("select.escrowClient.flag");
			logger.debug("getEscrowClient:" + sql + " AND Account No. " + procAccountNo);
			escrowClient = jdbcTemplate_iir.queryForObject(sql, new Object[] { procAccountNo }, String.class);
		}

		return escrowClient;

	}

	public List<Map<String, Object>> getPMERecord(Brm_processing_info procInfoObj) {

		List<String> retValue = new ArrayList<String>();
		List<String> retValuePremium = new ArrayList<String>();
		// List to store each record
		Map<Integer, List<String>> hm = new HashMap<Integer, List<String>>();

		String tranPolicyNo = null;
		String pmePolicyNo = null;

		tranPolicyNo = procInfoObj.getTransaction_policy_no().trim()
				.replaceAll(env.getRequiredProperty("policy.number.zeros.regex"), "");
		tranPolicyNo = tranPolicyNo.trim().replaceAll(env.getRequiredProperty("policy.number.regex"), "").trim();

		// CK CHNAGED - procInfoObj.getTransaction_policy_no() ... to
		// ...tranPolicyNo

		String sql = env.getRequiredProperty("select.PMErecord") + " WHERE [ES_LOAN_NO] = '"
				+ procInfoObj.getTransaction_loan_no() + "' AND [ES_LOAN_SUFFIX] = '"
				+ procInfoObj.getTansactionLoanSuffix() + "' AND [ES_COV_TYPE] = '"
				+ procInfoObj.getTransaction_cov_type() + "' AND [ES_ACCOUNT_NO] = '" + procInfoObj.getAccountNumber()
				// + "' AND REPLACE(LTRIM(REPLACE(ES_POLICY_NO,'0',' ')),'
				// ','0') = '" + tranPolicyNo
				// procInfoObj.getTransaction_policy_no()
				+ "' ORDER BY ES_BILL_DATE DESC";

		String sqlCount = env.getRequiredProperty("select.PMErecord.count") + " WHERE [ES_LOAN_NO] = '"
				+ procInfoObj.getTransaction_loan_no() + "' AND [ES_LOAN_SUFFIX] = '"
				+ procInfoObj.getTansactionLoanSuffix() + "' AND [ES_COV_TYPE] = '"
				+ procInfoObj.getTransaction_cov_type() + "' AND [ES_ACCOUNT_NO] = '" + procInfoObj.getAccountNumber()
				+ "'";
		// + "' AND REPLACE(LTRIM(REPLACE(ES_POLICY_NO,'0',' ')),' ','0') = '" +
		// tranPolicyNo + "'";

		logger.debug("getPMERecord Record Count Query:" + sqlCount);
		int total = jdbcTemplate_iir.queryForObject(sqlCount, Integer.class);

		int counter = 1;
		logger.debug("getPMERecord Record Query:" + sql);
		int columnCount = 7;

		List<Map<String, Object>> rows = jdbcTemplate_iir.queryForList(sql);

		List<Map<String, Object>> dbRows = new ArrayList<Map<String, Object>>();

		if (total != 0) {
			double totalPremium = 0;
			for (Map map : rows) {

				// Cleanup PME Policy Number
				pmePolicyNo = map.get("ES_POLICY_NO").toString().trim()
						.replaceAll(env.getRequiredProperty("policy.number.zeros.regex"), "").trim();
				pmePolicyNo = pmePolicyNo.trim().replaceAll(env.getRequiredProperty("policy.number.regex"), "").trim();

				try {
					if ((BRMUtilities.isNullDate(
							new SimpleDateFormat(DATE_FORMAT).parse(map.get("ES_BILL_DATE").toString()), true)
							|| BRMUtilities.isNullDate(
									new SimpleDateFormat(DATE_FORMAT).parse(map.get("ES_DATE_ADDED").toString()), true))
							&& (procInfoObj.getTransaction_effective_date()
									.compareTo((Date) map.get("ES_EFF_DATE"))) == 0
							&& (procInfoObj.getTransaction_expiration_date()
									.compareTo((Date) map.get("ES_EXP_DATE"))) == 0
							&& BRMUtilities.getPolicyNumberScore(tranPolicyNo, pmePolicyNo) <= 2)

					{

						Map<String, Object> row = new HashMap<String, Object>(columnCount);

						row.put("ES_POLICY_NO", map.get("ES_POLICY_NO").toString());
						row.put("ES_BILL_DATE", map.get("ES_BILL_DATE").toString());
						row.put("PMEDays", map.get("PMEDays").toString());
						row.put("ES_DATE_ADDED", map.get("ES_DATE_ADDED").toString());
						row.put("ES_PREM_AMT", map.get("ES_PREM_AMT").toString());
						row.put("ES_EFF_DATE", map.get("ES_EFF_DATE").toString());
						row.put("ES_EXP_DATE", map.get("ES_EXP_DATE").toString());
						row.put("ES_CURRENT_TERM", "Y");
						row.put("ES_VOID", map.get("ES_VOID").toString().trim());

						logger.debug("getPMERecord ES_BILL_DATE Date:" + map.get("ES_BILL_DATE").toString());
						logger.debug("getPMERecord PMEDays:" + map.get("PMEDays").toString());
						logger.debug("getPMERecord ES_DATE_ADDED Date:" + map.get("ES_DATE_ADDED").toString());
						logger.debug("getPMERecord ES_POLICY_NO:" + map.get("ES_POLICY_NO").toString().trim());
						logger.debug("getPMERecord ES_PREM_AMT:" + map.get("ES_PREM_AMT").toString());
						logger.debug("getPMERecord ES_EFF_DATE Date:" + map.get("ES_EFF_DATE").toString());
						logger.debug("getPMERecord ES_EXP_DATE Date:" + map.get("ES_EXP_DATE").toString());
						logger.debug("getPMERecord ES_VOID:" + map.get("ES_VOID").toString().trim());

						try {
							insertFME001Info(procInfoObj.getTransaction_id().trim(),
									procInfoObj.getTransaction_type().trim(), procInfoObj.getAccountNumber().trim(),
									procInfoObj.getTransaction_loan_no().trim(),
									procInfoObj.getTansactionLoanSuffix().trim(),
									procInfoObj.getTransaction_cov_type().trim(),
									((String) map.get("ES_POLICY_NO")).trim(), (java.util.Date) map.get("ES_BILL_DATE"),
									(java.util.Date) map.get("ES_EFF_DATE"), (java.util.Date) map.get("ES_EXP_DATE"),
									(java.util.Date) map.get("ES_DATE_ADDED"), "Y",
									Double.valueOf(map.get("ES_PREM_AMT").toString().trim()),
									Integer.parseInt(map.get("PMEDays").toString()), map.get("ES_VOID").toString());
						} catch (NumberFormatException e) {
							logger.debug("getPMERecord() NumberFormatException:" + e.getMessage());
						}

						dbRows.add(row);

					} // END IF

					else {

						if (dbRows.isEmpty()) {

							Map<String, Object> row = new HashMap<String, Object>(columnCount);
							row.put("ES_POLICY_NO", "NA");
							row.put("ES_BILL_DATE", NULL_DATE_VALUE);
							row.put("PMEDays", "5000");
							row.put("ES_DATE_ADDED", NULL_DATE_VALUE);
							row.put("ES_PREM_AMT", "0");
							row.put("ES_EFF_DATE", NULL_DATE_VALUE);
							row.put("ES_EXP_DATE", NULL_DATE_VALUE);
							row.put("ES_CURRENT_TERM", "N");
							row.put("ES_VOID", "");

							logger.debug("getPMERecord ES_BILL_DATE Date:" + NULL_DATE_VALUE);
							logger.debug("getPMERecord PMEDays:" + "5000");
							logger.debug("getPMERecord ES_DATE_ADDED Date:" + NULL_DATE_VALUE);
							logger.debug("getPMERecord ES_POLICY_NO:" + "NA");
							logger.debug("getPMERecord ES_PREM_AMT:" + "0");
							logger.debug("getPMERecord ES_EFF_DATE Date:" + NULL_DATE_VALUE);
							logger.debug("getPMERecord ES_EXP_DATE Date:" + NULL_DATE_VALUE);
							logger.debug("getPMERecord ES_VOID:" + map.get("ES_VOID").toString().trim());

							dbRows.add(row);
						}

						try {
							insertFME001Info(procInfoObj.getTransaction_id().trim(),
									procInfoObj.getTransaction_type().trim(), procInfoObj.getAccountNumber().trim(),
									procInfoObj.getTransaction_loan_no().trim(),
									procInfoObj.getTansactionLoanSuffix().trim(),
									procInfoObj.getTransaction_cov_type().trim(),
									((String) map.get("ES_POLICY_NO")).trim(), (java.util.Date) map.get("ES_BILL_DATE"),
									(java.util.Date) map.get("ES_EFF_DATE"), (java.util.Date) map.get("ES_EXP_DATE"),
									(java.util.Date) map.get("ES_DATE_ADDED"), "N",
									Double.valueOf(map.get("ES_PREM_AMT").toString().trim()),
									Integer.parseInt(map.get("PMEDays").toString()), map.get("ES_VOID").toString());
						} catch (NumberFormatException e) {
							logger.debug("getPMERecord() NumberFormatException:" + e.getMessage());
						}

					}

				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}

		else {

			Map<String, Object> row = new HashMap<String, Object>(columnCount);
			row.put("ES_POLICY_NO", "NA");
			row.put("ES_BILL_DATE", NULL_DATE_VALUE);
			row.put("PMEDays", "5000");
			row.put("ES_DATE_ADDED", NULL_DATE_VALUE);
			row.put("ES_PREM_AMT", "0");
			row.put("ES_EFF_DATE", NULL_DATE_VALUE);
			row.put("ES_EXP_DATE", NULL_DATE_VALUE);
			row.put("ES_CURRENT_TERM", "N");
			row.put("ES_VOID", "");

			logger.debug("getPMERecord ES_BILL_DATE Date:" + NULL_DATE_VALUE);
			logger.debug("getPMERecord PMEDays:" + "5000");
			logger.debug("getPMERecord ES_DATE_ADDED Date:" + NULL_DATE_VALUE);
			logger.debug("getPMERecord ES_POLICY_NO:" + "NA");
			logger.debug("getPMERecord ES_PREM_AMT:" + "0");
			logger.debug("getPMERecord ES_EFF_DATE Date:" + NULL_DATE_VALUE);
			logger.debug("getPMERecord ES_EXP_DATE Date:" + NULL_DATE_VALUE);
			logger.debug("getPMERecord ES_VOID:" + "");

			dbRows.add(row);

			return dbRows;

		}

		return dbRows;
	}

	public List<String> get_FMM080_LoanHistory(Brm_processing_info procInfoObj) {

		String sql = env.getRequiredProperty("select.FMM080.REI") + " AND P.[loan_number_iir_match] = '"
				+ procInfoObj.getTransaction_loan_no() + "' AND P.[loan_suffix_iir_match] = '" + "00"
				+ "' AND P.[coverage_type_iir_match] = '" + procInfoObj.getTransaction_cov_type()
				+ "' AND P.[account_number_iir_match] = '" + procInfoObj.getAccountNumber() + "'";

		List<String> retValue = new ArrayList<String>();
		List<Map<String, Object>> rows = jdbcTemplate_iir.queryForList(sql);

		String REIDIFFDAYS = "";
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date reiDate = null;

		if (!rows.isEmpty()) {
			for (Map map : rows) {

				if (map.get("EM_POL_PROCESS_DATE").toString().isEmpty()
						|| map.get("EM_POL_PROCESS_DATE").toString().length() == 0
						|| map.get("EM_POL_PROCESS_DATE").toString() == null) {
					logger.debug("REI History Record Empty - Sanity Check");
					retValue.add(NULL_DATE_VALUE);
					retValue.add("5000");
				} else {
					// REIDAYs
					retValue.add(map.get("EM_POL_PROCESS_DATE").toString());
					retValue.add(map.get("REIDAYs").toString());
					/*
					 * int dateVal =
					 * Integer.parseInt(map.get("EM_POL_PROCESS_DATE").toString(
					 * )) + 19000000; String strDateVal =
					 * String.valueOf(dateVal);
					 * 
					 * try { Date todayDate = new Date(); reiDate = new
					 * SimpleDateFormat("yyyyMMdd").parse(strDateVal);
					 * 
					 * long reiDateDiff = todayDate.getTime() -
					 * reiDate.getTime();
					 * 
					 * int diffInDays = (int) reiDateDiff / (1000 * 60 * 60 *
					 * 24);
					 * 
					 * REIDIFFDAYS = String.valueOf(diffInDays);
					 * 
					 * } catch (ParseException e) { // TODO Auto-generated catch
					 * block e.printStackTrace(); }
					 */

					// retValue.add(formatter.format(reiDate));
					logger.debug("get_FMM080_LoanHistory Date:" + map.get("EM_POL_PROCESS_DATE").toString());
					// retValue.add(REIDIFFDAYS);
				}
			}

		} else {
			logger.debug("REI History Record Empty");
			retValue.add(NULL_DATE_VALUE);
			retValue.add("5000");
		}

		return retValue;

	}

	public void updateProcTbl(String tid, String loan_No, String loan_Suffix, String accnt_No, String cov_Type,
			String source) {
		if (source.equalsIgnoreCase("app")) {
			String sqlApp = env.getRequiredProperty("select.rule.outcome.app");
			String ruleOutcomeAPP = jdbcTemplate.queryForObject(sqlApp, new Object[] { tid, cov_Type }, String.class);
			String updateAppSql = env.getRequiredProperty("update.rule.outcome.app");
			if (ruleOutcomeAPP.length() > 0) {
				jdbcTemplate.update(updateAppSql, ruleOutcomeAPP, tid, accnt_No, loan_No, loan_Suffix, cov_Type);

			}
		} else if (source.equalsIgnoreCase("api")) {
			String sqlApi = env.getRequiredProperty("select.rule.outcome");
			String ruleOutcomeAPI = jdbcTemplate.queryForObject(sqlApi, new Object[] { tid, cov_Type }, String.class);
			String updateSql = env.getRequiredProperty("update.rule.outcome.api");
			if (ruleOutcomeAPI.length() > 0) {
				jdbcTemplate.update(updateSql, ruleOutcomeAPI, tid, accnt_No, loan_No, loan_Suffix, cov_Type);
			}
		}

	}

	public List<Brm_app_info> getAppSingleInfo(String tid, String t_loan_no, String l_suffix, String cov_type,
			String acc_no, String proc_user) {

		String sql = env.getRequiredProperty("select.app.tbl.single.input.qur");

		logger.debug("Source Input App Query:" + sql);

		List<Brm_app_info> appInfo = new ArrayList<Brm_app_info>();

		List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql,
				new Object[] { tid, t_loan_no, l_suffix, cov_type, acc_no, proc_user });

		for (Map row : rows) {
			// Loan Line
			Brm_app_info proc = new Brm_app_info();

			proc.setAccountNumber(row.get("account_no") == null ? "" : row.get("account_no").toString().trim());

			try {
				proc.setAs400_post_date((java.util.Date) row.get("as400_post_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("as400_post_date"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			proc.setLoan_account_no(
					row.get("loan_account_no") == null ? "" : row.get("loan_account_no").toString().trim());

			try {
				proc.setLoan_begin_date((java.util.Date) row.get("loan_begin_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("loan_begin_date"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				proc.setLoan_cancel_date((java.util.Date) row.get("loan_cancel_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("loan_cancel_date"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			proc.setLoan_company_name(
					row.get("loan_company_name") == null ? "" : row.get("loan_company_name").toString().trim());

			proc.setLoan_cov_type(row.get("loan_cov_type") == null ? "" : row.get("loan_cov_type").toString().trim());

			try {
				proc.setLoan_doc_issue_date((java.util.Date) row.get("loan_doc_issue_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("loan_doc_issue_date"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				proc.setLoan_effective_date((java.util.Date) row.get("loan_effective_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("loan_effective_date"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			proc.setLoan_escrow_client(
					row.get("loan_escrow_client") == null ? "" : row.get("loan_escrow_client").toString().trim());

			proc.setLoan_escrow_code(
					row.get("loan_escrow_code") == null ? "" : row.get("loan_escrow_code").toString().trim());

			try {
				proc.setLoan_expiration_date((java.util.Date) row.get("loan_expiration_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("loan_expiration_date"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				proc.setLoan_his_rei_date((java.util.Date) row.get("loan_his_rei_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("loan_his_rei_date"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			proc.setLoan_insur_status(
					row.get("loan_insur_status") == null ? "" : row.get("loan_insur_status").toString().trim());

			proc.setLoan_insur_type(
					row.get("loan_insur_type") == null ? "" : row.get("loan_insur_type").toString().trim());

			proc.setLoan_mortgagee_name(
					row.get("loan_mortgagee_name") == null ? "" : row.get("loan_mortgagee_name").toString().trim());

			proc.setLoan_no(row.get("loan_no") == null ? "" : row.get("loan_no").toString().trim());

			proc.setLoan_no_suffix(
					row.get("loan_no_suffix") == null ? "" : row.get("loan_no_suffix").toString().trim());

			try {
				proc.setLoan_pme_bill_date((java.util.Date) row.get("loan_pme_bill_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("loan_pme_bill_date"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			proc.setLoan_policy_no(
					row.get("loan_policy_no") == null ? "" : row.get("loan_policy_no").toString().trim());

			try {
				proc.setLoan_transaction_date((java.util.Date) row.get("loan_transaction_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("loan_transaction_date"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				proc.setLoan_uninsured_date((java.util.Date) row.get("loan_uninsured_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("loan_uninsured_date"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			proc.setProc_user(row.get("proc_user") == null ? "" : row.get("proc_user").toString().trim());

			proc.setRule_outcome(row.get("rule_outcome") == null ? "" : row.get("rule_outcome").toString().trim());

			proc.setTansactionLoanSuffix(
					row.get("loan_suffix") == null ? "" : row.get("loan_suffix").toString().trim());

			try {
				proc.setTransaction_cancel_date((java.util.Date) row.get("transaction_cancel_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("transaction_cancel_date"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			proc.setTransaction_cov_type(
					row.get("transaction_cov_type") == null ? "" : row.get("transaction_cov_type").toString().trim());

			try {
				proc.setTransaction_doc_issue_date((java.util.Date) row.get("transaction_doc_issue_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("transaction_doc_issue_date"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			proc.setTransaction_id(
					row.get("transaction_id") == null ? "" : row.get("transaction_id").toString().trim());

			proc.setTransaction_loan_no(
					row.get("transaction_loan_no") == null ? "" : row.get("transaction_loan_no").toString().trim());

			proc.setTransaction_mortgagee_name(row.get("transaction_mortgagee_name") == null ? ""
					: row.get("transaction_mortgagee_name").toString().trim());

			proc.setTransaction_policy_no(
					row.get("transaction_policy_no") == null ? "" : row.get("transaction_policy_no").toString().trim());

			proc.setTransaction_policy_reason(row.get("transaction_policy_reason") == null ? ""
					: row.get("transaction_policy_reason").toString().trim());

			try {
				proc.setTransaction_reinstatement_date(
						(java.util.Date) row.get("transaction_reinstatement_date") == null
								? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
								: (java.util.Date) row.get("transaction_reinstatement_date"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// proc.setTransaction_type(row.get("transaction_type").toString());

			proc.setTransactionPolicyDecision(
					row.get("policy_decision") == null ? "" : row.get("policy_decision").toString().trim());

			proc.setLoan_his_dual_policy_no(row.get("loan_his_dual_policy_no") == null ? ""
					: row.get("loan_his_dual_policy_no").toString().trim());

			proc.setPolicyScore(
					row.get("policy_score") == null ? 0 : Integer.parseInt(row.get("policy_score").toString().trim()));

			proc.setTransactionInsurer(row.get("transaction_insurer_name") == null ? ""
					: row.get("transaction_insurer_name").toString().trim());
			proc.setTransaction_type(row.get("transaction_type").toString().trim());
			proc.setRei_fmr_date_check(
					row.get("rei_fmr_date_check") == null ? "" : row.get("rei_fmr_date_check").toString().trim());

			proc.setPMEDays(row.get("PMEDays") == null ? 0 : Integer.parseInt(row.get("PMEDays").toString().trim()));

			proc.setREIDays(row.get("REIDays") == null ? 0 : Integer.parseInt(row.get("REIDays").toString().trim()));

			proc.setLoan_pme_current_term(
					row.get("loan_pme_current_term") == null ? "" : row.get("loan_pme_current_term").toString().trim());
			proc.setLoan_pme_es_policy_no(
					row.get("loan_pme_es_policy_no") == null ? "" : row.get("loan_pme_es_policy_no").toString().trim());

			try {

				proc.setES_RCVD_DATE((java.sql.Date) row.get("ES_RCVD_DATE") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("ES_RCVD_DATE"));
				proc.setES_EFF_DATE((java.sql.Date) row.get("ES_EFF_DATE") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("ES_EFF_DATE"));
				proc.setES_EXP_DATE((java.sql.Date) row.get("ES_EXP_DATE") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("ES_EXP_DATE"));
				proc.setSwbc_chk(row.get("SWBC_CHECK") == null ? "" : row.get("SWBC_CHECK").toString().trim());
				proc.setES_CHECK_NO((Integer) row.get("ES_CHECK_NO"));

				// proc.setRei_fmr_date_check(row.get("rei_fmr_date_check") ==
				// null ? "" : row.get("rei_fmr_date_check").toString().trim());
				proc.setLoan_pme_current_term(row.get("loan_pme_current_term") == null ? ""
						: row.get("loan_pme_current_term").toString().trim());
				proc.setLoan_pme_es_policy_no(row.get("loan_pme_es_policy_no") == null ? ""
						: row.get("loan_pme_es_policy_no").toString().trim());

				proc.setLoan_pme_effective_date((java.sql.Date) row.get("loan_pme_effective_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("loan_pme_effective_date"));

			} catch (Exception e) {
				// TODO: handle exception
			}

			try {
				proc.setLoan_effective_date((java.sql.Date) row.get("loan_effective_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("loan_effective_date"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				proc.setTransaction_effective_date((java.sql.Date) row.get("transaction_effective_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("transaction_effective_date"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				proc.setTransaction_expiration_date((java.sql.Date) row.get("transaction_expiration_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.sql.Date) row.get("transaction_expiration_date"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			/*
			 * try { proc.setLoan_pme_expiration_date(
			 * row.get("loan_pme_expiration_date") == null ? new
			 * SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE) :
			 * row.get("loan_pme_expiration_date")); } catch (ParseException e)
			 * { // TODO Auto-generated catch block e.printStackTrace(); }
			 */

			try {
				proc.setLoan_pme_expiration_date((java.util.Date) row.get("loan_pme_expiration_date") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("loan_pme_expiration_date"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			proc.setTransaction_impairment_code(row.get("transaction_impairment_code") == null ? ""
					: row.get("transaction_impairment_code").toString().trim());

			proc.setTransaction_em_cov_amt(row.get("transaction_em_cov_amt") == null ? 0
					: Double.parseDouble(row.get("transaction_em_cov_amt").toString()));

			proc.setTransaction_premium_amt(row.get("transaction_premium_amt") == null ? 0
					: Double.parseDouble(row.get("transaction_premium_amt").toString()));

			proc.setTransaction_premium_net_amt(row.get("transaction_premium_net_amt") == null ? 0
					: Float.parseFloat(row.get("transaction_premium_net_amt").toString()));

			proc.setTransaction_em_flood_zone(row.get("transaction_em_flood_zone") == null ? ""
					: row.get("transaction_em_flood_zone").toString().trim());

			proc.setDisbursementFlag(
					row.get("disbursementFlag") == null ? "" : row.get("disbursementFlag").toString().trim());

			proc.setLoan_impairment_code(
					row.get("loan_impairment_code") == null ? "" : row.get("loan_impairment_code").toString().trim());

			proc.setLoan_ag_coverage_amt(row.get("loan_ag_coverage_amt") == null ? 0
					: Double.parseDouble(row.get("loan_ag_coverage_amt").toString()));

			proc.setLoan_ag_coverage_amt(row.get("loan_ag_coverage_amt") == null ? 0
					: Double.parseDouble(row.get("loan_ag_coverage_amt").toString()));

			proc.setLoan_pme_premium_amt(row.get("loan_pme_premium_amt") == null ? 0
					: Double.parseDouble(row.get("loan_pme_premium_amt").toString()));

			proc.setLoan_ag_flood_zone(
					row.get("loan_ag_flood_zone") == null ? "" : row.get("loan_ag_flood_zone").toString().trim());

			proc.setLoan_transaction_id(
					row.get("loan_transaction_id") == null ? "" : row.get("loan_transaction_id").toString().trim());

			proc.setTransaction_edi_deductible_per(row.get("transaction_edi_deductible_per") == null ? 0.0
					: Double.valueOf(row.get("transaction_edi_deductible_per").toString().trim()));
			proc.setTransaction_non_edi_deductible_per(row.get("transaction_non_edi_deductible_per") == null ? 0.0
					: Double.valueOf(row.get("transaction_non_edi_deductible_per").toString().trim()));
			proc.setTransaction_deductible_amt(row.get("transaction_deductible_amt") == null ? 0.0
					: Double.valueOf(row.get("transaction_deductible_amt").toString().trim()));
			proc.setLoan_escrow_premium_amt(row.get("loan_escrow_premium_amt") == null ? 0.0
					: Double.valueOf(row.get("loan_escrow_premium_amt").toString().trim()));

			proc.setLoan_ag_deductible_amt(row.get("loan_ag_deductible_amt") == null ? 0
					: Float.parseFloat(row.get("loan_ag_deductible_amt").toString()));
			proc.setLoan_ag_deductible_pct(row.get("loan_ag_deductible_pct") == null ? 0
					: Float.parseFloat(row.get("loan_ag_deductible_pct").toString()));

			appInfo.add(proc);
		}

		return appInfo;

	}

	public List<String> getValidRuleList(String ruleSet) {
		String sql = "";
		List<String> ruleList = new ArrayList<String>();
		if (ruleSet.equalsIgnoreCase("100")) {
			sql = env.getRequiredProperty("select.app.valid.rules");
			sql = sql.replaceAll("#R", "[rule_version_1]");
			logger.debug("############ getValidRuleList() v100:" + sql + " ###############");
			ruleList = jdbcTemplate.queryForList(sql, String.class);
		} else if (ruleSet.equalsIgnoreCase("101")) {
			sql = env.getRequiredProperty("select.app.valid.rules");
			sql = sql.replaceAll("#R", "[rule_version_2]");
			logger.debug("########### getValidRuleList() v101:" + sql + " ###############");
			ruleList = jdbcTemplate.queryForList(sql, String.class);
		}

		return ruleList;
	}

	public List<Brm_loan_info> getLoanInfo(Brm_processing_info longLoanList) {

		List<Brm_loan_info> loanInfo = new ArrayList<Brm_loan_info>();
		String loanStatusFrmAS400 = null;

		Brm_loan_info loanRec = new Brm_loan_info();
		
		if(longLoanList.getAccountNumber().trim() == "" || longLoanList.getTransaction_loan_no() == "")
		{
			longLoanList.setAccountNumber("0000");
			longLoanList.setTransaction_loan_no("0000");
		}
		
		// Loan Lookup
		String sql = env.getRequiredProperty("select.loan.lookup.qur") + " WHERE [IS_ACCOUNT_NO] = "
				+ Integer.parseInt(longLoanList.getAccountNumber())
				// + " AND [IS_COVERAGE_TYPE] COLLATE DATABASE_DEFAULT = '" +
				// longLoanList.getTransaction_cov_type()
				// + "' AND [IS_ACCOUNT_NO] = '" +
				// Integer.parseInt(longLoanList.getAccountNumber())
				+ " AND [IS_LOAN_NO] like '" + "%" + longLoanList.getTransaction_loan_no() + "%" + "'";

		// String sql = env.getRequiredProperty("select.loan.lookup.qur") + "
		// WHERE [IS_LOAN_SUFFIX] = "
		// + Integer.parseInt(longLoanList.getTansactionLoanSuffix())
		// + " AND [IS_COVERAGE_TYPE] COLLATE DATABASE_DEFAULT = '" +
		// longLoanList.getTransaction_cov_type()
		// + "' AND [IS_ACCOUNT_NO] = '" +
		// Integer.parseInt(longLoanList.getAccountNumber())
		// + "' AND [IS_LOAN_NO] COLLATE DATABASE_DEFAULT ='" +
		// longLoanList.getTransaction_loan_no() + "'";

		logger.debug("Loan Lookup Query:" + sql);

		List<Map<String, Object>> rows = jdbcTemplate_iir.queryForList(sql);

		Map<String, String> disbMap = new HashMap<String, String>();

		if (rows.size() == 0) {
			logger.debug("NO Loan Record");
			loanRec.setTransaction_id(longLoanList.getTransaction_id());
			loanRec.setLoan_no("NO_LOAN");
			loanInfo.add(loanRec);

		} else {
			for (Map row : rows) {

				List<Map<String, Object>> bicRow = getBICData(Integer.parseInt(longLoanList.getAccountNumber()),
						longLoanList.getTransaction_loan_no(),longLoanList.getTransaction_cov_type());

				for (Map bicRows : bicRow) {

					loanRec.setbICEffectiveDate((Date) bicRows.get("bICEffectiveDate"));
					loanRec.setbICExpirationDate((Date) bicRows.get("bICExpirationDate"));
					loanRec.setIs_Letter_cycle(bicRows.get("is_Letter_cycle").toString());

				}
				
				
				List<Map<String, Object>> pymtDisbRow = getPymtDisbData(longLoanList.getAccountNumber());

				for (Map pymtDisbRows : pymtDisbRow) {

					loanRec.setMax_prem_amt(pymtDisbRows.get("max_prem_amt").toString().trim());
					loanRec.setTol_prem_pct(pymtDisbRows.get("tol_prem_pct").toString().trim());
					
				}
				

				disbMap = getDisbITCValues(longLoanList.getTransaction_id(), row.get("IS_LOAN_NO").toString(),
						row.get("IS_LOAN_SUFFIX").toString(), row.get("IS_ACCOUNT_NO").toString(),
						row.get("IS_COVERAGE_TYPE").toString());

				loanRec.setLoan_account_no(row.get("IS_ACCOUNT_NO").toString());
				loanRec.setLoan_no(row.get("IS_LOAN_NO").toString());
				loanRec.setLoan_no_suffix(row.get("IS_LOAN_SUFFIX").toString());
				loanRec.setLoan_cov_type(row.get("IS_COVERAGE_TYPE").toString());
				loanRec.setLoan_policy_no(row.get("IS_POLICY_NO").toString());

				// Loan Policy Number - Removing Special Characters + Leading
				// Zeros
				String loanPolicyNumber = loanRec.getLoan_policy_no().trim();
				loanPolicyNumber = loanPolicyNumber.trim()
						.replaceAll(env.getRequiredProperty("policy.number.zeros.regex"), "").trim();
				loanPolicyNumber = loanPolicyNumber.trim()
						.replaceAll(env.getRequiredProperty("policy.number.regex"), "").trim();

				String insurance_type = row.get("IS_INSUR_TYPE").toString();
				loanRec.setLoan_insur_type(insurance_type);
				loanRec.setLoan_expiration_date((java.sql.Timestamp) row.get("IS_EXPIRATION_DATE"));
				loanRec.setLoan_doc_issue_date((java.sql.Timestamp) row.get("IS_DOC_ISSUE_DT"));

				// Loan Status//// Modified to get from AS400
				// loanRec.setLoan_insur_status((String)
				// row.get("IS_INSUR_STATUS"));

				Map<String, String> mapInsStatus = getLoanStatusAS400(AS400Conn, longLoanList.getAccountNumber(),
						longLoanList.getTransaction_loan_no(), "00", longLoanList.getTransaction_cov_type(),
						env.getRequiredProperty("AS400_LIB_SET_CONST"), mortlibraryList);

				loanRec.setLoan_insur_status(mapInsStatus.get("Loan_Ins_Status"));
				loanRec.setAs400_loan_ins_status_msg(mapInsStatus.get("Error_Msg"));

				// switch (getLoanStatusAS400(AS400Conn,
				// longLoanList.getAccountNumber(),
				// longLoanList.getTransaction_loan_no(), "00",
				// longLoanList.getTransaction_cov_type()).get("Status")) {
				// case "EXPIRED":
				// loanStatusFrmAS400 = "E";
				// break;
				//
				// case "CANCEL":
				// loanStatusFrmAS400 = "C";
				// break;
				//
				// default:
				// loanStatusFrmAS400 = getLoanStatusAS400(AS400Conn,
				// longLoanList.getAccountNumber(),
				// longLoanList.getTransaction_loan_no(), "00",
				// longLoanList.getTransaction_cov_type()).get("Status");
				// break;
				// }
				//
				// loanRec.setLoan_insur_status(loanStatusFrmAS400);

				/*
				 * loanRec.setLoan_insur_status(getLoanStatusAS400(BRMUtilities.
				 * createDBConnection( AS400_SERVER_URL_MTG.trim(),
				 * AS400_USERID.trim(), AS400_PASSWORD.trim(),
				 * AS400_DRIVER_CLASS.trim()), longLoanList.getAccountNumber(),
				 * longLoanList.getTransaction_loan_no(), "00",
				 * longLoanList.getTransaction_cov_type()).get("Status"));
				 */

				loanRec.setLoan_uninsured_date((java.util.Date) row.get("IS_UNINSURED_DATE"));

				loanRec.setTransaction_id(longLoanList.getTransaction_id());
				loanRec.setLoan_escrow_code((String) row.get("IS_ESCROW_CODE"));
				loanRec.setLoan_company_name(row.get("IS_COMPANY_NAME").toString().trim());
				loanRec.setLoan_mortgagee_name(row.get("AC_ACCOUNT_NAME").toString().trim());
				// Loan Effective Date
				loanRec.setLoan_effective_date((java.sql.Timestamp) row.get("IS_BEGIN_DATE"));
				loanRec.setLoan_escrow_client(getEscrowClient(row.get("IS_ACCOUNT_NO").toString()));
				loanRec.setLoan_transaction_id(row.get("IS_DOCUMENT_NO").toString().trim());
				String loan_pme_policy_no = "";

				try {

					List<Map<String, Object>> pmeMap = getPMERecord(longLoanList);

					// double pmeTotPrem = 0;
					// Map<String, Object> pmeAmtMap = null;
					//
					//
					// for (int i = 0; i < pmeMap.size(); i++) {
					// pmeAmtMap = pmeMap.get(i);
					//
					// for (String key : pmeAmtMap.keySet()) {
					//
					// if(!pmeAmtMap.get("ES_EFF_DATE").toString().contains("1900")
					// )
					// {
					// pmeTotPrem +=
					// Double.parseDouble(pmeAmtMap.get("ES_PREM_AMT").toString());
					// loanRec.setLoan_pme_es_policy_no(pmeAmtMap.get("ES_POLICY_NO").toString().trim());
					// break;
					// }
					//
					// }
					//
					//
					// }

					double pmeTotPrem = 0;
					boolean isCurrentTermProcsd = false;
					boolean isLatest = false;

					for (Map pmeRows : pmeMap) {

						if (pmeRows.get("ES_CURRENT_TERM").toString().trim().equalsIgnoreCase("Y")) {

							pmeTotPrem += Double.parseDouble(pmeRows.get("ES_PREM_AMT").toString());
							loanRec.setLoan_pme_es_policy_no(pmeRows.get("ES_POLICY_NO").toString().trim());

							if (!isLatest) {
								loanRec.setLoan_pme_creation_date(new SimpleDateFormat(DATE_FORMAT)
										.parse(pmeRows.get("ES_BILL_DATE").toString()));
								loanRec.setLoan_pme_effective_date(
										new SimpleDateFormat(DATE_FORMAT).parse(pmeRows.get("ES_EFF_DATE").toString()));
								loanRec.setLoan_pme_expiration_date(
										new SimpleDateFormat(DATE_FORMAT).parse(pmeRows.get("ES_EXP_DATE").toString()));
								loanRec.setLoan_pme_bill_date(new SimpleDateFormat(DATE_FORMAT)
										.parse(pmeRows.get("ES_BILL_DATE").toString()));

								loanRec.setEs_void(pmeRows.get("ES_VOID").toString().trim());
								loanRec.setPMEDays(Integer.parseInt(pmeRows.get("PMEDays").toString()));
							}

							loanRec.setLoan_pme_current_term(pmeRows.get("ES_CURRENT_TERM").toString());

							loan_pme_policy_no = pmeRows.get("ES_POLICY_NO").toString();
							isCurrentTermProcsd = true;
							isLatest = true;

						}

						if (!isCurrentTermProcsd) {
							loanRec.setLoan_pme_es_policy_no(pmeRows.get("ES_POLICY_NO").toString().trim());
							loanRec.setLoan_pme_bill_date(
									new SimpleDateFormat(DATE_FORMAT).parse(pmeRows.get("ES_BILL_DATE").toString()));

							loanRec.setEs_void(pmeRows.get("ES_VOID").toString().trim());
							loanRec.setPMEDays(Integer.parseInt(pmeRows.get("PMEDays").toString()));
							loanRec.setLoan_pme_creation_date(
									new SimpleDateFormat(DATE_FORMAT).parse(pmeRows.get("ES_BILL_DATE").toString()));
							loanRec.setLoan_pme_current_term(pmeRows.get("ES_CURRENT_TERM").toString());

							loanRec.setLoan_pme_effective_date(
									new SimpleDateFormat(DATE_FORMAT).parse(pmeRows.get("ES_EFF_DATE").toString()));
							loanRec.setLoan_pme_expiration_date(
									new SimpleDateFormat(DATE_FORMAT).parse(pmeRows.get("ES_EXP_DATE").toString()));
							loan_pme_policy_no = pmeRows.get("ES_POLICY_NO").toString();
						}

					}

					loanRec.setLoan_pme_premium_amt(pmeTotPrem);

					List<String> agentRecord = getAgentInformation(longLoanList);

					// Replace Leading Zeros
					loan_pme_policy_no = loan_pme_policy_no.trim()
							.replaceAll(env.getRequiredProperty("policy.number.zeros.regex"), "").trim();
					loan_pme_policy_no = loan_pme_policy_no.trim()
							.replaceAll(env.getRequiredProperty("policy.number.regex"), "").trim();

					// REI History Info

					List<String> hisREIRecord = get_FMM080_LoanHistory(longLoanList);

					if (longLoanList.getTransaction_type().equalsIgnoreCase("XLC")) {

						loanRec.setLoan_his_rei_date(new SimpleDateFormat(DATE_FORMAT).parse(hisREIRecord.get(0)));
						loanRec.setREIDays(Integer.parseInt(hisREIRecord.get(1)));
					} else {
						loanRec.setLoan_his_rei_date(new SimpleDateFormat(DATE_FORMAT).parse("1900-01-01"));
						loanRec.setREIDays(Integer.parseInt("5000"));
					}

					// loanRec.setLoan_his_rei_date(new
					// SimpleDateFormat(DATE_FORMAT).parse("2018-05-12"));
					// loanRec.setREIDays(Integer.parseInt("2"));

					// Get Agent Information
					loanRec.setLoan_ag_spare_code(agentRecord.get(2).toString().trim());
					loanRec.setLoan_flood_zone(agentRecord.get(1).toString().trim());
					loanRec.setLoan_ag_coverage_amt(Double.valueOf(agentRecord.get(0).toString().trim()));
					loanRec.setLoan_ag_deductible_amt(Double.valueOf(agentRecord.get(3).toString().trim()));
					loanRec.setLoan_ag_deductible_pct(Double.valueOf(agentRecord.get(4).toString().trim()));
					loanRec.setLoan_ag_spare_code3(agentRecord.get(5).toString().trim());
				} catch (ParseException e) {
					logger.debug("Error Setting PME/REI History DATE:" + e.getMessage());
				}

				// setting history dual policy number
				loanRec.setLoan_his_dual_policy_no(get_FMI006_DualPolicy(longLoanList));

				// Loan Dual Policy
				String loan_dual_policy = loanRec.getLoan_his_dual_policy_no().trim();
				loan_dual_policy = loan_dual_policy.trim()
						.replaceAll(env.getRequiredProperty("policy.number.zeros.regex"), "").trim();
				loan_dual_policy = loan_dual_policy.trim()
						.replaceAll(env.getRequiredProperty("policy.number.regex"), "").trim();

				String transaction_policy_no = longLoanList.getTransaction_policy_no().trim();
				transaction_policy_no = transaction_policy_no.trim()
						.replaceAll(env.getRequiredProperty("policy.number.zeros.regex"), "").trim();
				transaction_policy_no = transaction_policy_no.trim()
						.replaceAll(env.getRequiredProperty("policy.number.regex"), "").trim();

				// Setting the Transaction-Loan Policy Score
				loanRec.setPolicyScore(BRMUtilities.getPolicyNumberScore(transaction_policy_no, loanPolicyNumber));

				// Set Loan Property Type
				loanRec.setLoan_property_type(getLoanPropertyType(row.get("IS_LOAN_NO").toString(),
						row.get("IS_LOAN_SUFFIX").toString(), row.get("IS_ACCOUNT_NO").toString()));

				// Setting the Transaction-Loan PME Policy Score
				loanRec.setLoan_pme_policy_score(
						BRMUtilities.getPolicyNumberScore(transaction_policy_no, loan_pme_policy_no));

				// Setting the Transaction-Loan Dual Policy Score
				loanRec.setLoan_dual_policy_score(
						BRMUtilities.getPolicyNumberScore(transaction_policy_no, loan_dual_policy));

				// Getting Policy Info for REI Docs
				ArrayList<String> VSIPolicyNos = new ArrayList<String>();
				VSIPolicyNos = getFMR001VSIPolicyNummber(longLoanList);

				loanRec.setVSIPolicyNo(getFMR001VSIPolicyNummber(longLoanList).get(0));

				logger.debug(
						"############### TRANSACTION Policy Number from FMM080 Table:" + transaction_policy_no.trim());

				logger.debug("############### PME Policy Number from FME001 Table:" + loan_pme_policy_no.trim());
				logger.debug("############### LOAN Policy Number from FMI002 Table:" + loanPolicyNumber.trim());
				// Capturing Policy Info only for REI Documents
				for (String obj : VSIPolicyNos) {
					logger.debug("############### VSI Policy Number from FMR Table:" + obj.trim());

					if (!obj.equalsIgnoreCase("NA")) {
						List<Brm_policy_info> policyInfo = getFMRPolicyInfo(longLoanList, obj.toString().trim());

						// Inserting Policy Info
						insertPolicyInfo(policyInfo);

						// Getting the dates
						if (longLoanList.getTransaction_type().equals("REI")) {
							if (reisntatetmentFMRCheck(longLoanList.getTransaction_reinstatement_date(), policyInfo)) {
								loanRec.setRei_fmr_date_check("true");
							} else {
								loanRec.setRei_fmr_date_check("false");
							}

							logger.debug("############### Policy Info Inserted Successfully for Transaction ID:"
									+ longLoanList.getTransaction_id().toString().trim());

						} else {
							if (reisntatetmentFMRCheck(longLoanList.getTransaction_effective_date(), policyInfo)) {
								loanRec.setRei_fmr_date_check("true");
							} else {
								loanRec.setRei_fmr_date_check("false");
							}

							logger.debug("############### Policy Info Inserted Successfully for Transaction ID:"
									+ longLoanList.getTransaction_id().toString().trim());
						}

					} else {
						loanRec.setRei_fmr_date_check("false");
					}
				}

				try {
					if (disbMap.size() > 0) {
						if (!disbMap.get("ES_CHECK_NO").isEmpty() || disbMap.get("ES_CHECK_NO").length() > 0
								|| disbMap.get("ES_CHECK_NO") != null) {
							loanRec.setLoan_es_check_no(Integer.parseInt(disbMap.get("ES_CHECK_NO")));
						} else {
							loanRec.setLoan_es_check_no(0);
						}

						loanRec.setLoan_es_eff_date(
								new SimpleDateFormat(DATE_FORMAT).parse(disbMap.get("ES_EFF_DATE")));
						loanRec.setLoan_es_exp_date(
								new SimpleDateFormat(DATE_FORMAT).parse(disbMap.get("ES_EXP_DATE")));
						loanRec.setLoan_es_rcvd_date(
								new SimpleDateFormat(DATE_FORMAT).parse(disbMap.get("ES_RCVD_DATE")));
					} else {
						loanRec.setLoan_es_check_no(0);
						loanRec.setLoan_es_eff_date((new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)));
						loanRec.setLoan_es_exp_date(new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE));
						loanRec.setLoan_es_rcvd_date(new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE));
					}

					loanRec.setLoan_swbc_check(getITCSWBCCheck(row.get("IS_ACCOUNT_NO").toString()));
					// loanRec.setLoan_swbc_check("NA");

				} catch (Exception e) {
					logger.debug("Error Setting ITC Check Info:" + e.getMessage());

				}

				// Loan Insurance Status Mapping Input Fields
				loanRec.setLoan_is_waive_inititals(row.get("IS_WAIVE_INITIALS").toString().trim());
				loanRec.setLoan_is_spare_code_1(row.get("IS_SPARE_CODE_1").toString().trim());
				loanRec.setLoan_is_waive_date((java.sql.Timestamp) row.get("IS_WAIVE_DATE"));
				loanRec.setLoan_is_audit_code(row.get("IS_AUDIT_CODE").toString().trim());
				loanRec.setLoan_is_letter_code(row.get("IS_LETTER_CODE").toString().trim());
				loanRec.setLoan_is_impairment_code(row.get("IS_IMPAIRMENT_CODE").toString().trim());
				// IS_ESC_PREM_AMT
				loanRec.setLoan_escrow_premium_amt(Double.valueOf(row.get("IS_ESC_PREM_AMT").toString()));
				// Set Disbursement Flag
				loanRec.setDisbursementFlag(getDisbursementFlag(row.get("IS_ACCOUNT_NO").toString()));

				// Get Gap Line
				loanRec.setLoan_gap_line(isGapLineAvailable(longLoanList).trim());
				loanRec.setLoan_gap_effective_date(getDatesFromLoanTable(longLoanList, "IS_BEGIN_DATE"));
				loanRec.setLoan_gap_expiration_date(getDatesFromLoanTable(longLoanList, "IS_EXPIRATION_DATE"));
				
				loanRec.setWaive_code(getWaiveCode(longLoanList.getAccountNumber(), longLoanList.getTransaction_loan_no(), longLoanList.getTransaction_cov_type()));
				loanRec.setLoan_board_date(getLoanBoardDate(longLoanList.getAccountNumber(), longLoanList.getTransaction_loan_no(), longLoanList.getTransaction_cov_type(), "01"));

				/*
				 * // Get Calculated Loan Status
				 * loanRec.setLoan_calculated_ins_status(
				 * getCalculatedInsuraneStatus(loanRec.
				 * getLoan_is_waive_inititals().toString(). trim(),
				 * loanRec.getLoan_is_spare_code_1().toString().trim(),
				 * loanRec.getLoan_is_waive_date(),
				 * loanRec.getLoan_is_audit_code().toString().trim(),
				 * loanRec.getLoan_is_letter_code().toString().trim(),
				 * loanRec.getLoan_is_impairment_code().toString().trim(),
				 * loanRec.getLoan_insur_status().toString().trim(),
				 * loanRec.getLoan_insur_type().toString().trim(),
				 * loanRec.getLoan_expiration_date()));
				 * 
				 * 
				 * 
				 */

				// Setting the Loan Objects
				loanInfo.add(loanRec);
			}
		}

		return loanInfo;

	}

	public void insertProcTbl(Brm_processing_info listProcTbl) {

		String sql = env.getRequiredProperty("insert.proc.tbl");
		// insert.proc.tbl
		jdbcTemplate.update(sql, listProcTbl.getTransaction_id(), listProcTbl.getTransaction_cov_type(),
				listProcTbl.getTransaction_type(), listProcTbl.getTransaction_policy_no(),
				listProcTbl.getTransaction_policy_reason(), listProcTbl.getTransaction_mortgagee_name(),
				listProcTbl.getTransaction_status(), listProcTbl.getTransaction_loan_no(),
				listProcTbl.getAccountNumber(), listProcTbl.getTansactionLoanSuffix(),
				listProcTbl.getTransaction_cancel_date(), listProcTbl.getTransaction_reinstatement_date(),
				listProcTbl.getTransaction_doc_issue_date(), listProcTbl.getTransactionPolicyDecision(),
				listProcTbl.getTransaction_effective_date(), listProcTbl.getTransaction_expiration_date(),
				listProcTbl.getTransactionInsurer(), listProcTbl.getTransaction_coverage_amt(),
				listProcTbl.getTransaction_impairment_code(), listProcTbl.getTransaction_flood_zone(),
				listProcTbl.getTransaction_premium_amt(), listProcTbl.getTransaction_premium_net_amt(),
				listProcTbl.getTransaction_edi_deductible_per(), listProcTbl.getTransaction_non_edi_deductible_per(),
				listProcTbl.getTransaction_deductible_amt(), listProcTbl.getTransaction_operator_id(),
				listProcTbl.getTransaction_naic_code(), listProcTbl.getPolicy_type(), listProcTbl.getDelete_counter());

		// jdbcTemplate.update(sql);
		logger.debug("Processing Record Inserted Successfully For " + listProcTbl.getTransaction_id());

	}

	public String get_FMI006_DualPolicy(Brm_processing_info procInfoObj) {
		String dualPolicy = "";
		String sql = env.getRequiredProperty("select.his.lookup.dualpolicy") + " WHERE [IH_LOAN_SUFFIX] = "
				+ Integer.parseInt(procInfoObj.getTansactionLoanSuffix())
				+ " AND [IH_COVERAGE_TYPE] COLLATE DATABASE_DEFAULT = '" + procInfoObj.getTransaction_cov_type()
				+ "' AND [IH_ACCOUNT_NO] = '" + Integer.parseInt(procInfoObj.getAccountNumber())
				+ "' AND [IH_LOAN_NO] COLLATE DATABASE_DEFAULT ='" + procInfoObj.getTransaction_loan_no() + "'";

		String sqlcount = env.getRequiredProperty("select.his.lookup.dualpolicy.count") + "  WHERE [IH_LOAN_SUFFIX] = "
				+ Integer.parseInt(procInfoObj.getTansactionLoanSuffix())
				+ " AND [IH_COVERAGE_TYPE] COLLATE DATABASE_DEFAULT = '" + procInfoObj.getTransaction_cov_type()
				+ "' AND [IH_ACCOUNT_NO] = '" + Integer.parseInt(procInfoObj.getAccountNumber())
				+ "' AND [IH_LOAN_NO] COLLATE DATABASE_DEFAULT ='" + procInfoObj.getTransaction_loan_no() + "'";

		logger.debug("get_FMI006_DualPolicy() Record Query:" + sql);
		logger.debug("get_FMI006_DualPolicy() Count Query:" + sqlcount);

		int count = jdbcTemplate_FMI006.queryForObject(sqlcount, Integer.class);
		if (count > 0) {
			dualPolicy = jdbcTemplate_FMI006.queryForObject(sql, String.class);
		} else {
			dualPolicy = "NODUALPOLICY";
		}

		return dualPolicy.toString().trim();
	}

	public boolean getRuleName(String transactionId, String ruleName) {
		/*
		 * insertLogTbl(transactionId, null, null, ruleName, null, null, null,
		 * null, null, null, null, 0, null, null);
		 */

		logger.debug(
				"##########  Rule Evaluated:" + ruleName + " for Transaction ID:" + transactionId + " ###############");

		return true;
	}

	public void printMsgDRL(String msg) {

		logger.debug("########## " + msg.toUpperCase() + " ###############");

	}

	public String getLoanPropertyType(String loanNo, String loanSuffix, String accountNo) {
		// select.loan.property.type
		String propertyType = "";
		String sql = env.getRequiredProperty("select.loan.property.type");
		propertyType = jdbcTemplate_iir.queryForObject(sql, new Object[] { loanNo, loanSuffix, accountNo },
				String.class);
		logger.debug("Property Type For Loan Number:" + loanNo + ", Account Number:" + accountNo + ", Property Type:"
				+ propertyType);
		return propertyType;
	}

	public List<String> getPolicyCancelReason() {

		List<String> reqList = new ArrayList<String>();

		String[] tempArr = env.getRequiredProperty("xlc.policy.cancel.reason.list.5.4").split(",");

		for (int i = 0; i < tempArr.length; i++) {

			reqList.add(tempArr[i].trim());
		}

		return reqList;
	}

	public List<String> getTransactionInsurer() {
		List<String> reqList = new ArrayList<String>();

		String[] tempArr = env.getRequiredProperty("xlc.policy.cancel.reason.list.5.2").split(",");

		for (int i = 0; i < tempArr.length; i++) {

			reqList.add(tempArr[i].trim());
		}

		return reqList;
	}

	public ArrayList<String> getFMR001VSIPolicyNummber(Brm_processing_info longLoanList) {
		String sql = env.getRequiredProperty("select.get.FMR001.policynumber") + " WHERE [PO_ACCOUNT_NO] ="
				+ Integer.parseInt(longLoanList.getAccountNumber()) + " AND [PO_LOAN_NO] COLLATE DATABASE_DEFAULT ='"
				+ longLoanList.getTransaction_loan_no() + "' AND [PO_LOAN_SUFFIX] ="
				+ Integer.parseInt(longLoanList.getTansactionLoanSuffix())
				+ " AND [PO_COVERAGE_TYPE] COLLATE DATABASE_DEFAULT ='" + longLoanList.getTransaction_cov_type() + "'";

		logger.debug("getFMR001VSIPolicyNummber Query:" + sql);

		String policyNo = "";

		List<Map<String, Object>> rows = jdbcTemplate_FMI006.queryForList(sql);

		ArrayList<String> VSIPolicyNumbers = new ArrayList<String>();

		if (rows.size() == 0) {
			// policyNo = "NA";
			VSIPolicyNumbers.add("NA");
		} else {
			for (Map row : rows) {
				VSIPolicyNumbers.add(row.get("PO_VSI_POLICY_NO").toString().trim());
			}
			// policyNo = rows.get(0).get("PO_VSI_POLICY_NO").toString().trim();
		}

		logger.debug("#########  getFMR001VSIPolicyNummber Policy Number:" + policyNo + " ##############");

		// policyNo
		return VSIPolicyNumbers;

	}

	public List<Brm_policy_info> getFMRPolicyInfo(Brm_processing_info longLoanList, String policyNo) {
		List<Brm_policy_info> policyInfo = new ArrayList<Brm_policy_info>();

		String sql = env.getRequiredProperty("select.get.FMR002.policyinfo") + " WHERE [PT_VSI_POLICY_NO] ='"
				+ policyNo.trim() + "' ORDER BY [PT_TRAN_SEQUENCE]";

		logger.debug("getFMRPolicyInfo Query:" + sql + " for Policy Number:" + policyNo);

		List<Map<String, Object>> rows = jdbcTemplate_FMI006.queryForList(sql);

		for (Map row : rows) {
			// Policy Info
			Brm_policy_info policyParams = new Brm_policy_info();

			try {
				policyParams.setPo_account_no(longLoanList.getAccountNumber().toString().trim());
				policyParams.setPo_coverage_type(longLoanList.getTransaction_cov_type().toString().trim());
				policyParams.setPo_loan_no(longLoanList.getTransaction_loan_no().toString().trim());
				policyParams.setPo_loan_suffix(longLoanList.getTansactionLoanSuffix());
				policyParams.setPo_vsi_policy_no(policyNo.toString().trim());
				policyParams.setTransaction_id(longLoanList.getTransaction_id().toString().trim());
				policyParams.setTransaction_type(longLoanList.getTransaction_type().toString().trim());

				// PT_EFFECTIVE_DATE
				String PT_EFFECTIVE_DATE = row.get("PT_EFFECTIVE_DATE").toString();
				if (PT_EFFECTIVE_DATE.length() > 0) {
					Date EFFECTIVE_DATE = BRMUtilities.convertAS400DateToDateStr(PT_EFFECTIVE_DATE);
					policyParams.setPt_effective_date(EFFECTIVE_DATE);
					logger.debug("PT_EFFECTIVE_DATE:" + policyParams.getPt_effective_date());
				} else {
					policyParams.setPt_effective_date(new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE));
					logger.debug("PT_EFFECTIVE_DATE:" + policyParams.getPt_effective_date());
				}

				// PT_EXPIRATION_DATE
				String PT_EXPIRATION_DATE = row.get("PT_EXPIRATION_DATE").toString();
				if (PT_EXPIRATION_DATE.length() > 0) {
					Date EXPIRATION_DATE = BRMUtilities.convertAS400DateToDateStr(PT_EXPIRATION_DATE);
					policyParams.setPt_expiration_date(EXPIRATION_DATE);
					logger.debug("PT_EXPIRATION_DATE:" + policyParams.getPt_expiration_date());
				} else {
					policyParams.setPt_effective_date(new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE));
					logger.debug("PT_EXPIRATION_DATE:" + policyParams.getPt_expiration_date());
				}

				policyParams.setPt_policy_status(row.get("PT_POLICY_STATUS").toString().trim());

				// PT_REFUND_DATE
				String PT_REFUND_DATE = row.get("PT_REFUND_DATE").toString();
				if (PT_REFUND_DATE.length() > 0) {
					Date REFUND_DATE = BRMUtilities.convertAS400DateToDateStr(PT_REFUND_DATE);
					policyParams.setPt_refund_date(REFUND_DATE);
					logger.debug("PT_REFUND_DATE:" + policyParams.getPt_refund_date());
				} else {
					policyParams.setPt_effective_date(new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE));
					logger.debug("PT_REFUND_DATE:" + policyParams.getPt_refund_date());
				}

				policyParams.setPt_refund_reason(row.get("PT_REFUND_REASON").toString().trim());
				policyParams
						.setPt_tran_sequence((Integer) Integer.parseInt(row.get("PT_TRAN_SEQUENCE").toString().trim()));

				// PT_VOIDED_DATE
				String PT_VOIDED_DATE = row.get("PT_VOIDED_DATE").toString();
				if (PT_VOIDED_DATE.length() > 0) {
					Date VOIDED_DATE = BRMUtilities.convertAS400DateToDateStr(PT_VOIDED_DATE);
					policyParams.setPt_voided_date(VOIDED_DATE);
					logger.debug("PT_VOIDED_DATE:" + policyParams.getPt_voided_date());
				} else {
					policyParams.setPt_effective_date(new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE));
					logger.debug("PT_VOIDED_DATE:" + policyParams.getPt_voided_date());
				}

				// Setting the transaction REI Date
				policyParams.setTransaction_rei_date(longLoanList.getTransaction_reinstatement_date());
			} catch (NumberFormatException e) {
				logger.debug("getFMRPolicyInfo NumberFormatException:" + e.getMessage());
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				logger.debug("getFMRPolicyInfo ParseException:" + e.getMessage());
			}

			policyInfo.add(policyParams);

		}

		return policyInfo;
	}

	public void insertPolicyInfo(List<Brm_policy_info> policyInfo) {
		if (policyInfo.isEmpty()) {
			logger.debug("No Policy Entry");
			for (Brm_policy_info policy : policyInfo) {
				jdbcTemplate.update(env.getRequiredProperty("insert.policy.info"), policy.getTransaction_id(),
						policy.getTransaction_type(), null, policy.getPo_account_no(), policy.getPo_loan_no(),
						policy.getPo_loan_suffix(), policy.getPo_coverage_type(), null, null, null, null, null, null,
						null, null);

				logger.debug(
						"NULL Policy Record Inserted Successfully for Transaction ID:" + policy.getTransaction_id());
			}
		} else {
			for (Brm_policy_info policy : policyInfo) {

				jdbcTemplate.update(env.getRequiredProperty("insert.policy.info"), policy.getTransaction_id(),
						policy.getTransaction_type(), policy.getPo_vsi_policy_no(), policy.getPo_account_no(),
						policy.getPo_loan_no(), policy.getPo_loan_suffix(), policy.getPo_coverage_type(),
						policy.getPt_tran_sequence(), policy.getPt_policy_status(), policy.getPt_voided_date(),
						policy.getPt_effective_date(), policy.getPt_expiration_date(), policy.getPt_refund_date(),
						policy.getPt_refund_reason(), policy.getTransaction_rei_date());

				logger.debug("Policy Record Inserted Successfully For " + policy.getTransaction_id());

			}
		}

	}

	public boolean reisntatetmentFMRCheck(Date reinstatementDate, List<Brm_policy_info> policyInfo) {
		int size = policyInfo.size();
		logger.debug("####### reisntatetmentFMRCheck SIZE:" + size);
		boolean isREIInFP = false;

		// Mon Jan 01 00:00:00 CST 1900
		int count = 0;

		logger.debug("####### Reinstatement Date:" + reinstatementDate);
		if (size > 0 && !reinstatementDate.toString().equalsIgnoreCase("1900-01-01 00:00:00.0")) {
			for (Brm_policy_info temp : policyInfo) {

				if (temp.getPt_voided_date().toString().equalsIgnoreCase("Mon Jan 01 00:00:00 CST 1900")
						&& temp.getPt_refund_date().toString().equalsIgnoreCase("Mon Jan 01 00:00:00 CST 1900")
						&& !temp.getPt_effective_date().toString().equalsIgnoreCase("Mon Jan 01 00:00:00 CST 1900")
						&& !temp.getPt_expiration_date().toString().equalsIgnoreCase("Mon Jan 01 00:00:00 CST 1900")
						&& reinstatementDate.compareTo(temp.getPt_effective_date()) > 1
						&& temp.getPt_expiration_date().compareTo(reinstatementDate) > 1) {
					isREIInFP = true;
					logger.debug("####### Loop EffectiveDate:" + temp.getPt_effective_date().toString());
					logger.debug("####### Loop ExpirationDate:" + temp.getPt_expiration_date().toString());
					logger.debug("####### Loop RefundDate:" + temp.getPt_refund_date().toString());
					logger.debug("####### Loop VoidedDate:" + temp.getPt_voided_date().toString());
					logger.debug("####### Loop REI Check IF Block:" + isREIInFP);
				} else if (!temp.getPt_voided_date().toString().equalsIgnoreCase("Mon Jan 01 00:00:00 CST 1900")
						&& temp.getPt_refund_date().toString().equalsIgnoreCase("Mon Jan 01 00:00:00 CST 1900")
						&& !temp.getPt_effective_date().toString().equalsIgnoreCase("Mon Jan 01 00:00:00 CST 1900")
						&& !temp.getPt_expiration_date().toString().equalsIgnoreCase("Mon Jan 01 00:00:00 CST 1900")
						&& temp.getPt_voided_date().compareTo(temp.getPt_effective_date()) > 1
						&& reinstatementDate.compareTo(temp.getPt_effective_date()) > 1
						&& temp.getPt_voided_date().compareTo(reinstatementDate) > 1) {
					isREIInFP = true;
					logger.debug("####### Loop EffectiveDate:" + temp.getPt_effective_date().toString());
					logger.debug("####### Loop ExpirationDate:" + temp.getPt_expiration_date().toString());
					logger.debug("####### Loop RefundDate:" + temp.getPt_refund_date().toString());
					logger.debug("####### Loop VoidedDate:" + temp.getPt_voided_date().toString());
					logger.debug("####### Loop REI Check ELSE IF Block 1:" + isREIInFP);
				} else if (temp.getPt_voided_date().toString().equalsIgnoreCase("Mon Jan 01 00:00:00 CST 1900")
						&& !temp.getPt_refund_date().toString().equalsIgnoreCase("Mon Jan 01 00:00:00 CST 1900")
						&& !temp.getPt_effective_date().toString().equalsIgnoreCase("Mon Jan 01 00:00:00 CST 1900")
						&& !temp.getPt_expiration_date().toString().equalsIgnoreCase("Mon Jan 01 00:00:00 CST 1900")
						&& temp.getPt_refund_date().compareTo(temp.getPt_effective_date()) > 1
						&& reinstatementDate.compareTo(temp.getPt_effective_date()) > 1
						&& temp.getPt_refund_date().compareTo(reinstatementDate) > 1) {
					isREIInFP = true;
					logger.debug("####### Loop EffectiveDate:" + temp.getPt_effective_date().toString());
					logger.debug("####### Loop ExpirationDate:" + temp.getPt_expiration_date().toString());
					logger.debug("####### Loop RefundDate:" + temp.getPt_refund_date().toString());
					logger.debug("####### Loop VoidedDate:" + temp.getPt_voided_date().toString());
					logger.debug("####### Loop REI Check ELSE IF Block 2:" + isREIInFP);
				} else if (!temp.getPt_voided_date().toString().equalsIgnoreCase("Mon Jan 01 00:00:00 CST 1900")
						&& !temp.getPt_effective_date().toString().equalsIgnoreCase("Mon Jan 01 00:00:00 CST 1900")
						&& temp.getPt_effective_date().compareTo(temp.getPt_voided_date()) == 0
						|| temp.getPt_effective_date().compareTo(temp.getPt_voided_date()) > 1
						|| temp.getPt_voided_date().compareTo(temp.getPt_effective_date()) > 1) {
					isREIInFP = false;
					logger.debug("####### Loop EffectiveDate:" + temp.getPt_effective_date().toString());
					logger.debug("####### Loop ExpirationDate:" + temp.getPt_expiration_date().toString());
					logger.debug("####### Loop RefundDate:" + temp.getPt_refund_date().toString());
					logger.debug("####### Loop VoidedDate:" + temp.getPt_voided_date().toString());
					logger.debug("####### Loop REI Check ELSE IF Block 3:" + isREIInFP);

				} // 1900-01-01 00:00:00.0
				else if (!temp.getPt_refund_date().toString().equalsIgnoreCase("Mon Jan 01 00:00:00 CST 1900")
						&& !temp.getPt_effective_date().toString().equalsIgnoreCase("Mon Jan 01 00:00:00 CST 1900")
						&& temp.getPt_effective_date().compareTo(temp.getPt_refund_date()) == 0
						|| temp.getPt_effective_date().compareTo(temp.getPt_refund_date()) > 1
						|| temp.getPt_refund_date().compareTo(temp.getPt_effective_date()) > 1) {
					isREIInFP = false;
					logger.debug("####### Loop EffectiveDate:" + temp.getPt_effective_date().toString());
					logger.debug("####### Loop ExpirationDate:" + temp.getPt_expiration_date().toString());
					logger.debug("####### Loop RefundDate:" + temp.getPt_refund_date().toString());
					logger.debug("####### Loop VoidedDate:" + temp.getPt_voided_date().toString());
					logger.debug("####### Loop REI Check ELSE IF Block 4:" + isREIInFP);
				} else {
					isREIInFP = false;
					logger.debug("####### Loop EffectiveDate:" + temp.getPt_effective_date().toString());
					logger.debug("####### Loop ExpirationDate:" + temp.getPt_expiration_date().toString());
					logger.debug("####### Loop RefundDate:" + temp.getPt_refund_date().toString());
					logger.debug("####### Loop VoidedDate:" + temp.getPt_voided_date().toString());
					logger.debug("####### Loop REI Check ELSE Block:" + isREIInFP);
				}

				count = count + 1;
				if (isREIInFP) {
					break;
				}
			}

		}

		logger.debug("####### reisntatetmentFMRCheck Output:" + isREIInFP);
		return isREIInFP;

	}

	public Map<String, String> getDisbITCValues(String tid, String loan_No, String loan_Suffix, String accnt_No,
			String cov_Type) {
		Map<String, String> disValMap = new HashMap<String, String>();

		String sql = env.getRequiredProperty("select.loan.disb.tbl.itc") + " WHERE [ES_LOAN_NO] = '" + loan_No
				+ "' AND [ES_LOAN_SUFFIX] = '" + loan_Suffix + "' AND [ES_COV_TYPE] = '" + cov_Type
				+ "' AND [ES_ACCOUNT_NO] = '" + accnt_No + "'";

		logger.debug("####### getDisbITCValues Query:" + sql);

		try {

			List<Map<String, Object>> rows = jdbcTemplate_iir.queryForList(sql);

			for (Map<String, Object> map : rows) {
				disValMap.put("ES_EFF_DATE", map.get("ES_EFF_DATE").toString().trim());
				disValMap.put("ES_EXP_DATE", map.get("ES_EXP_DATE").toString().trim());
				disValMap.put("ES_RCVD_DATE", map.get("ES_RCVD_DATE").toString().trim());
				disValMap.put("ES_CHECK_NO", map.get("ES_CHECK_NO").toString().trim());
			}

		} catch (Exception e) {

			logger.debug("####### getDisbITCValues Error:" + e.getMessage());
			// return null;
		}

		logger.debug("getDisbITCValues Record:" + disValMap.toString());
		return disValMap;
	}

	public String getITCSWBCCheck(String accNo) {
		String sql = env.getRequiredProperty("select.loan.swbc.chk.tbl.itc");
		sql = sql.replaceAll("#A", accNo);

		logger.debug("####### getITCSWBCCheck() Query:" + sql);

		String checkStatus = "";

		List<Map<String, Object>> rows = jdbcTemplate_iir.queryForList(sql);

		if (rows.size() > 0) {
			checkStatus = rows.get(0).get("SWBC_CHECK").toString().trim();
		} else {
			checkStatus = "N";
		}

		return checkStatus;

	}

	public String getCalculatedInsuraneStatus(String loan_is_waive_inititals, String loan_is_spare_code_1,
			Date loan_is_waive_date, String loan_is_audit_code, String loan_is_letter_code,
			String loan_is_impairment_code, String insuranceStatus, String insuranceType, Date expirationDate) {

		String calculatedStatus = "";

		// Impairment Code Mapping
		HashMap<String, String> code = new HashMap<String, String>();
		code.put("A", "AUD LTR");
		code.put("B", "BUILDING");
		code.put("C", "COV IMP");
		code.put("D", "DEDUCTIBLE");
		code.put("F", "NO FLD COV");
		code.put("L", "ELEV CERT");
		code.put("M", "MTG IMP");
		code.put("P", "DUAL IMP");
		code.put("S", "SPECIAL AU");
		code.put("R", "UNPAID PB");
		code.put("U", "INSF CONDO");
		code.put("NA", "IMPAIRED");

		if (loan_is_spare_code_1.length() > 0 && !loan_is_spare_code_1.equalsIgnoreCase("NA")) {
			calculatedStatus = "TRACK";
		} else if (loan_is_waive_inititals.length() > 0 && loan_is_waive_inititals.equalsIgnoreCase("ZZZ")) {
			calculatedStatus = "WV LOW BAL";
		} else if (loan_is_waive_inititals.length() > 0 && loan_is_waive_inititals.equalsIgnoreCase("YYY")) {
			calculatedStatus = "WV NON PAY";
		} else if (loan_is_waive_date.toString().equalsIgnoreCase("1900-01-01 00:00:00.0")
				|| loan_is_waive_date.toString().equalsIgnoreCase("Mon Jan 01 00:01:00 CST 1900")) {
			calculatedStatus = "WAIVED";
		}

		if (insuranceStatus.equalsIgnoreCase("C")) {
			calculatedStatus = "CANCEL";
		} else if (insuranceStatus.equalsIgnoreCase("N")) {
			calculatedStatus = "NEW LOAN";
		} else if (insuranceStatus.equalsIgnoreCase("A") && loan_is_audit_code.equalsIgnoreCase("A")) {
			calculatedStatus = "AUDIT";
		} else if (insuranceStatus.equalsIgnoreCase("A") && loan_is_audit_code.equalsIgnoreCase("M")) {
			calculatedStatus = "AUDIT REMA";
		} else if (insuranceStatus.equalsIgnoreCase("R")) {
			calculatedStatus = "DEL PEND";
		} else if (insuranceStatus.equalsIgnoreCase("I")) {
			if (code.containsKey(loan_is_impairment_code.trim())) {
				calculatedStatus = code.get(loan_is_impairment_code.trim());
			} else {
				calculatedStatus = "OTHER";
			}
		} else if (insuranceStatus.equalsIgnoreCase("E")) {
			if (insuranceType.equalsIgnoreCase("F")) {

				if (loan_is_letter_code.equalsIgnoreCase("9")) {
					calculatedStatus = "ISS PEN";
				} else {
					calculatedStatus = "FP EXPIRE";
				}
			} else {
				calculatedStatus = "EXPIRED";
			}
		} else if (insuranceStatus.isEmpty() || insuranceStatus.length() == 0) {
			if (insuranceType.equalsIgnoreCase("F")) {
				if (loan_is_letter_code.equalsIgnoreCase("9")) {
					calculatedStatus = "FP IS PEN";
				} else if (new Date().compareTo(expirationDate) > 1) {
					calculatedStatus = "FP IN FRC";
				} else {
					calculatedStatus = "FP EXPIRED";
				}
			} else if (insuranceType.equalsIgnoreCase("M")) {
				if (loan_is_letter_code.equalsIgnoreCase("9")) {
					calculatedStatus = "MTH IS PEN";
				} else {
					calculatedStatus = "MTH IN FRC";
				}
			} else if (insuranceType.equalsIgnoreCase("D")) {
				if (new Date().compareTo(expirationDate) > 1) {
					calculatedStatus = "EXPIRED";
				} else {
					calculatedStatus = "INSURED";
				}
			} else if (insuranceType.equalsIgnoreCase("C")) {
				calculatedStatus = "INS-CONT";
			} else {
				calculatedStatus = "NO-INS";
			}

		}

		return calculatedStatus;
	}

	public List<Brm_rule> getLogginhRuleList(String tType) {

		List<Brm_rule> ruleList = new ArrayList<Brm_rule>();

		String sql = env.getRequiredProperty("select.brm.rules");

		List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql, new Object[] { "%" + tType + "%" });

		for (Map row : rows) {

			Brm_rule ruleLookUpRow = new Brm_rule();
			ruleLookUpRow.setRule_name(row.get("rule_name").toString());
			ruleLookUpRow.setRule_outcome(row.get("rule_outcome").toString());
			ruleLookUpRow.setRule_msg(row.get("rule_message").toString());
			ruleList.add(ruleLookUpRow);
		}

		return ruleList;
	}

	public void insertPolicyHistory(String account_no, String loan_no, String loan_suffix, String cov_type,
			String loan_policy_no, String transaction_policy_no, Date transaction_effective_date,
			Date transaction_expiration_date, String transaction_insurer_name, String transaction_type,
			String transaction_id, Date transaction_document_date) {

		jdbcTemplate.update(env.getRequiredProperty("insert.policy.history.tbl"), account_no, loan_no, loan_suffix,
				cov_type, loan_policy_no, transaction_policy_no, transaction_effective_date,
				transaction_expiration_date, transaction_insurer_name, transaction_type, transaction_id,
				transaction_document_date);

		logger.debug("Policy History Inserted Successfully");
	}

	public List<String> getAgentInformation(Brm_processing_info procInfoObj) {
		List<String> retValue = new ArrayList<String>();

		String sql = env.getRequiredProperty("select.FMI102") + " WHERE [AG_LOAN_NO] = '"
				+ procInfoObj.getTransaction_loan_no() + "' AND [AG_LOAN_SUFFIX] = '"
				+ procInfoObj.getTansactionLoanSuffix() + "' AND [AG_COVERAGE_TYPE] = '"
				+ procInfoObj.getTransaction_cov_type() + "' AND [AG_ACCOUNT_NO] = '" + procInfoObj.getAccountNumber()
				+ "' ORDER BY [AG_TRAN_DATE] DESC";

		String sqlCount = env.getRequiredProperty("select.FMI102.count") + " WHERE [AG_LOAN_NO] = '"
				+ procInfoObj.getTransaction_loan_no() + "' AND [AG_LOAN_SUFFIX] = '"
				+ procInfoObj.getTansactionLoanSuffix() + "' AND [AG_COVERAGE_TYPE] = '"
				+ procInfoObj.getTransaction_cov_type() + "' AND [AG_ACCOUNT_NO] = '" + procInfoObj.getAccountNumber()
				+ "'";

		logger.debug("getAgentInformation Record Count Query:" + sqlCount);
		int total = jdbcTemplate_iir.queryForObject(sqlCount, Integer.class);

		logger.debug("getAgentInformation Record Query:" + sql);

		List<Map<String, Object>> rows = jdbcTemplate_iir.queryForList(sql);

		if (total != 0) {
			for (Map map : rows) {

				if (Double.parseDouble(map.get("AG_COVERAGE_AMOUNT").toString()) == 0) {
					retValue.add("0");
					retValue.add("NA");
					retValue.add("NA");
					retValue.add("0");
					retValue.add("0");
					retValue.add("NA");
					logger.debug("Agent Record Empty - Sanity Check");
				} else {
					retValue.add(map.get("AG_COVERAGE_AMOUNT").toString());
					logger.debug("getAgentInformation AG_COVERAGE_AMOUNT:" + map.get("AG_COVERAGE_AMOUNT").toString());
					retValue.add(map.get("AG_FLOOD_ZONE").toString());
					logger.debug("getAgentInformation AG_FLOOD_ZONE:" + map.get("AG_FLOOD_ZONE").toString());
					retValue.add(map.get("AG_SPARE_CODE_2").toString());
					logger.debug("getAgentInformation AG_SPARE_CODE_2:" + map.get("AG_SPARE_CODE_2").toString());
					retValue.add(map.get("AG_DEDUCTIBLE_AMT").toString());
					logger.debug("getAgentInformation AG_DEDUCTIBLE_AMT:" + map.get("AG_DEDUCTIBLE_AMT").toString());
					retValue.add(map.get("AG_DEDUCTIBLE_PCT").toString());
					logger.debug("getAgentInformation AG_DEDUCTIBLE_PCT:" + map.get("AG_DEDUCTIBLE_PCT").toString());
					retValue.add(map.get("AG_SPARE_CODE_3").toString());
					logger.debug("getAgentInformation AG_SPARE_CODE_3:" + map.get("AG_SPARE_CODE_3").toString());
				}

			}
		} else {
			retValue.add("0");
			retValue.add("NA");
			retValue.add("NA");
			retValue.add("0");
			retValue.add("0");
			retValue.add("NA");
			logger.debug("Agent Record Empty");
		}

		return retValue;
	}

	public String getDisbursementFlag(String procAccountNo) {
		String disbursementFlag = "";

		// Check if the account exisits
		String sqlCount = env.getRequiredProperty("select.disbursement.count");
		int total = jdbcTemplate_iir.queryForObject(sqlCount, new Object[] { procAccountNo }, Integer.class);

		// Get Default Flag
		String sqlGetFlag = env.getRequiredProperty("select.disbursement.default");
		List<Map<String, Object>> rows = jdbcTemplate_iir.queryForList(sqlGetFlag);
		String defaultFlag = "";
		for (Map row : rows) {
			defaultFlag = row.get("DefaultFlag").toString().trim();
		}
		logger.debug("Default Disbursement Flag:" + defaultFlag);

		if (total == 0) {
			disbursementFlag = defaultFlag;
		} else {
			String sql = env.getRequiredProperty("select.disbursement.flag");
			logger.debug("getdisbursementFlag:" + sql + " AND Account No. " + procAccountNo);
			disbursementFlag = jdbcTemplate_iir.queryForObject(sql, new Object[] { procAccountNo }, String.class);
		}

		return disbursementFlag;

	}

	public List<Brm_processing_info> getProcInfo(String loanno, String loanSuffix, String covType, String accno,
			String tid) {

		String sqlProcPCHApi = env.getRequiredProperty("select.api.pch.inp.qyr");
		List<Brm_processing_info> procInfo = new ArrayList<Brm_processing_info>();
		List<Map<String, Object>> rows = jdbcTemplate_iir.queryForList(sqlProcPCHApi,
				new Object[] { loanno, loanSuffix, covType, accno, tid });

		for (Map row : rows) {
			// Loan Line
			Brm_processing_info proc = new Brm_processing_info();
			proc.setAccountNumber(row.get("AccountNumber") == null ? "" : row.get("AccountNumber").toString().trim());

			proc.setTransaction_loan_no(
					row.get("TransactionLoanNo") == null ? "" : row.get("TransactionLoanNo").toString().trim());

			proc.setTansactionLoanSuffix(
					row.get("TransactionLoanSuffix") == null ? "" : row.get("TransactionLoanSuffix").toString().trim());

			proc.setTransaction_cov_type(
					row.get("CoverageTypeIIR") == null ? "" : row.get("CoverageTypeIIR").toString().trim());

			proc.setTransaction_id(row.get("TransactionID") == null ? "" : row.get("TransactionID").toString().trim());

			proc.setTransaction_type(row.get("DocumentType") == null ? "" : row.get("DocumentType").toString().trim());

			proc.setTransaction_policy_no(row.get("PolicyNo") == null ? "" : row.get("PolicyNo").toString().trim());

			proc.setPolicy_type(row.get("EM_POL_TYPE").toString().trim());

			proc.setTransaction_policy_reason(row.get("TransactionCancelReason") == null ? ""
					: row.get("TransactionCancelReason").toString().trim());

			// proc.setTransaction_cancel_date((java.sql.Timestamp)
			// row.get("TransactionCancelDate"));
			try {
				proc.setTransaction_cancel_date((java.util.Date) row.get("TransactionCancelDate") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("TransactionCancelDate"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// proc.setTransaction_reinstatement_date((java.sql.Timestamp)
			// row.get("TransactionReinstatementDate"));
			try {
				proc.setTransaction_reinstatement_date((java.util.Date) row.get("TransactionReinstatementDate") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("TransactionReinstatementDate"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// EM_POL_PROCESS_DATE
			// proc.setTransaction_doc_issue_date((java.util.Timestamp)
			// row.get("DocIssueDate"));
			try {
				proc.setTransaction_doc_issue_date((java.util.Date) row.get("DocIssueDate") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("DocIssueDate"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// proc.setTransaction_doc_issue_date((java.sql.Timestamp)
			// row.get("DocIssueDate"));

			proc.setTransaction_mortgagee_name(
					row.get("MortageeName") == null ? "" : row.get("MortageeName").toString().trim());

			proc.setTransaction_status(
					row.get("final_decision") == null ? "" : row.get("final_decision").toString().trim());

			proc.setTransactionPolicyDecision(
					row.get("PolicyDecision") == null ? "" : row.get("PolicyDecision").toString().trim());

			// Transaction Effective Date and Expiration Date
			// proc.setTransaction_effective_date((java.sql.Timestamp)
			// row.get("TransactionEffectiveDate"));
			try {
				proc.setTransaction_effective_date(row.get("TransactionEffectiveDate").toString().trim().length() == 0
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("TransactionEffectiveDate"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// proc.setTransaction_expiration_date((java.sql.Timestamp)
			// row.get("TransactionExpirationDate"));
			try {
				proc.setTransaction_expiration_date((java.util.Date) row.get("TransactionExpirationDate") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("TransactionExpirationDate"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// Transaction Company Name
			proc.setTransactionInsurer(
					row.get("TransactionInsurer") == null ? "" : row.get("TransactionInsurer").toString().trim());

			proc.setTransaction_impairment_code(
					row.get("EM_IMPAIR_CD") == null ? "" : row.get("EM_IMPAIR_CD").toString().trim());

			proc.setTransaction_flood_zone(
					row.get("EM_FLOOD_ZONE") == null ? "" : row.get("EM_FLOOD_ZONE").toString().trim());

			// proc.setTransaction_coverage_amt(Double.valueOf(row.get("EM_COV_AMT").toString().trim()));
			proc.setTransaction_coverage_amt(
					row.get("EM_COV_AMT") == null ? 0.0 : Double.valueOf(row.get("EM_COV_AMT").toString().trim()));

			// proc.setTransaction_premium_amt(Double.valueOf(row.get("EM_POL_PREM").toString().trim()));
			proc.setTransaction_premium_amt(
					row.get("EM_POL_PREM") == null ? 0.0 : Double.valueOf(row.get("EM_POL_PREM").toString().trim()));

			proc.setTransaction_naic_code(row.get("EM_NAIC") == null ? "NA" : row.get("EM_NAIC").toString().trim());

			procInfo.add(proc);

		}

		return procInfo;

		/*
		 * if (source.equalsIgnoreCase("app")) { String sqlApp =
		 * env.getRequiredProperty("select.rule.outcome.app"); String
		 * ruleOutcomeAPP = jdbcTemplate.queryForObject(sqlApp, new Object[] {
		 * tid, cov_Type }, String.class); String updateAppSql =
		 * env.getRequiredProperty("update.rule.outcome.app"); if
		 * (ruleOutcomeAPP.length() > 0) { jdbcTemplate.update(updateAppSql,
		 * ruleOutcomeAPP, tid, accnt_No, loan_No, loan_Suffix, cov_Type);
		 * 
		 * } } else if (source.equalsIgnoreCase("api")) { String sqlApi =
		 * env.getRequiredProperty("select.rule.outcome"); String ruleOutcomeAPI
		 * = jdbcTemplate.queryForObject(sqlApi, new Object[] { tid, cov_Type },
		 * String.class); String updateSql =
		 * env.getRequiredProperty("update.rule.outcome.api"); if
		 * (ruleOutcomeAPI.length() > 0) { jdbcTemplate.update(updateSql,
		 * ruleOutcomeAPI, tid, accnt_No, loan_No, loan_Suffix, cov_Type); } }
		 */

	}

	public void callNBSRule(String loan_No, String loan_Suffix, String acct_No, String covType, String trans_id) {

	}

	public String filterQryByType(String sql, String type) {
		sql = sql + " AND F.[EM_POL_TRAN_CODE] = '" + type + "'";
		return sql;
	}

	public List<Brm_processing_info> getProcInfoSingleAPI(String tid, String loan_No, String loan_Suffix,
			String accnt_No, String cov_Type) {

		String sqlProcSingleApi = env.getRequiredProperty("select.proc.tbl.single.input.qur");
		List<Brm_processing_info> procInfo = new ArrayList<Brm_processing_info>();

		List<Map<String, Object>> rows = jdbcTemplate_iir.queryForList(sqlProcSingleApi,
				new Object[] { tid.trim(), accnt_No.trim(), loan_No.trim(), cov_Type.trim(), loan_Suffix.trim() });

		for (Map row : rows) {

			Brm_processing_info proc = new Brm_processing_info();
			proc.setAccountNumber(row.get("AccountNumber") == null ? "" : row.get("AccountNumber").toString().trim());

			proc.setTransaction_loan_no(
					row.get("TransactionLoanNo") == null ? "" : row.get("TransactionLoanNo").toString().trim());

			proc.setTansactionLoanSuffix(
					row.get("TransactionLoanSuffix") == null ? "" : row.get("TransactionLoanSuffix").toString().trim());

			proc.setTransaction_cov_type(
					row.get("CoverageTypeIIR") == null ? "" : row.get("CoverageTypeIIR").toString().trim());

			proc.setTransaction_id(row.get("TransactionID") == null ? "" : row.get("TransactionID").toString().trim());

			proc.setTransaction_type(row.get("DocumentType") == null ? "" : row.get("DocumentType").toString().trim());

			proc.setTransaction_policy_no(row.get("PolicyNo") == null ? "" : row.get("PolicyNo").toString().trim());

			proc.setTransaction_policy_reason(row.get("TransactionCancelReason") == null ? ""
					: row.get("TransactionCancelReason").toString().trim());

			// proc.setTransaction_cancel_date((java.sql.Timestamp)
			// row.get("TransactionCancelDate"));
			try {
				proc.setTransaction_cancel_date((java.util.Date) row.get("TransactionCancelDate") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("TransactionCancelDate"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// proc.setTransaction_reinstatement_date((java.sql.Timestamp)
			// row.get("TransactionReinstatementDate"));
			try {
				proc.setTransaction_reinstatement_date((java.util.Date) row.get("TransactionReinstatementDate") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("TransactionReinstatementDate"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// EM_POL_PROCESS_DATE
			// proc.setTransaction_doc_issue_date((java.util.Timestamp)
			// row.get("DocIssueDate"));
			try {
				proc.setTransaction_doc_issue_date((java.util.Date) row.get("DocIssueDate") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("DocIssueDate"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// proc.setTransaction_doc_issue_date((java.sql.Timestamp)
			// row.get("DocIssueDate"));

			proc.setTransaction_mortgagee_name(
					row.get("MortageeName") == null ? "" : row.get("MortageeName").toString().trim());

			proc.setTransaction_status(
					row.get("final_decision") == null ? "" : row.get("final_decision").toString().trim());

			proc.setTransactionPolicyDecision(
					row.get("PolicyDecision") == null ? "" : row.get("PolicyDecision").toString().trim());

			// Transaction Effective Date and Expiration Date
			// proc.setTransaction_effective_date((java.sql.Timestamp)
			// row.get("TransactionEffectiveDate"));
			try {
				proc.setTransaction_effective_date(row.get("TransactionEffectiveDate").toString().trim().length() == 0
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("TransactionEffectiveDate"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// proc.setTransaction_expiration_date((java.sql.Timestamp)
			// row.get("TransactionExpirationDate"));
			try {
				proc.setTransaction_expiration_date((java.util.Date) row.get("TransactionExpirationDate") == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) row.get("TransactionExpirationDate"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// Transaction Company Name
			proc.setTransactionInsurer(row.get("EM_INSURER") == null ? "" : row.get("EM_INSURER").toString().trim());

			proc.setTransaction_impairment_code(
					row.get("EM_IMPAIR_CD") == null ? "" : row.get("EM_IMPAIR_CD").toString().trim());

			proc.setTransaction_flood_zone(
					row.get("EM_FLOOD_ZONE") == null ? "" : row.get("EM_FLOOD_ZONE").toString().trim());

			// proc.setTransaction_coverage_amt(Double.valueOf(row.get("EM_COV_AMT").toString().trim()));
			proc.setTransaction_coverage_amt(
					row.get("EM_COV_AMT") == null ? 0.0 : Double.valueOf(row.get("EM_COV_AMT").toString().trim()));

			// proc.setTransaction_premium_amt(Double.valueOf(row.get("EM_POL_PREM").toString().trim()));
			proc.setTransaction_premium_amt(
					row.get("EM_POL_PREM") == null ? 0.0 : Double.valueOf(row.get("EM_POL_PREM").toString().trim()));

			proc.setTransaction_premium_net_amt(
					row.get("EM_NET_AMT") == null ? 0.0 : Double.valueOf(row.get("EM_NET_AMT").toString().trim()));

			proc.setTransaction_edi_deductible_per(row.get("DEDUCTABLE_PERCENTAGE_EDI") == null ? 0.0
					: Double.valueOf(row.get("DEDUCTABLE_PERCENTAGE_EDI").toString().trim()));

			proc.setTransaction_non_edi_deductible_per(row.get("DEDUCTABLE_PERCENTAGE_NON_EDI") == null ? 0.0
					: Double.valueOf(row.get("DEDUCTABLE_PERCENTAGE_NON_EDI").toString().trim()));

			proc.setTransaction_deductible_amt(row.get("DEDUCTABLE_AMOUNT") == null ? 0.0
					: Double.valueOf(row.get("DEDUCTABLE_AMOUNT").toString().trim()));
			proc.setTransaction_naic_code(row.get("EM_NAIC") == null ? "NA" : row.get("EM_NAIC").toString().trim());

			proc.setPolicy_type(row.get("EM_POL_TYPE") == null ? "" : row.get("EM_POL_TYPE").toString().trim());

			proc.setDelete_counter(row.get("delete_counter") == null ? 0
					: Integer.parseInt(row.get("delete_counter").toString().trim()));

			proc.setTransaction_operator_id(
					row.get("EM_OPERATOR_ID") == null ? "" : row.get("EM_OPERATOR_ID").toString().trim());

			procInfo.add(proc);

		}

		return procInfo;

	}

	public void insertFME001Info(String transaction_id, String transaction_type, String es_account_no,
			String es_loan_no, String es_loan_suffix, String es_coverage_type, String es_policy_no, Date es_bill_date,
			Date es_eff_date, Date es_expiration_date, Date es_date_added, String es_current_term,
			Double es_premium_amt, int es_no_pme_days, String es_void) {

		jdbcTemplate.update(env.getRequiredProperty("insert.FME001.tbl"), transaction_id, transaction_type,
				es_account_no, es_loan_no, es_loan_suffix, es_coverage_type, es_policy_no, es_bill_date, es_eff_date,
				es_expiration_date, es_date_added, es_current_term, es_premium_amt, es_no_pme_days, es_void);

		logger.debug("PME Info Inserted Successfully");
	}

	public String isGapLineAvailable(Brm_processing_info procInfoObj) {
		String retValue = "";

		String sqlCount = env.getRequiredProperty("select.gap.count") + " AND [IS_LOAN_NO] = '"
				+ procInfoObj.getTransaction_loan_no() + "' AND [IS_LOAN_SUFFIX] = "
				+ procInfoObj.getTansactionLoanSuffix() + " AND [IS_ACCOUNT_NO] = " + procInfoObj.getAccountNumber();

		logger.debug("isGapLineAvailable Count Query: " + sqlCount);

		int total = jdbcTemplate_iir.queryForObject(sqlCount, Integer.class);

		if (total != 0) {
			logger.debug("GapLine Record Available");
			retValue = "Y";
		} else {
			logger.debug("isGapLineAvailable Record Empty");
			retValue = "N";
		}

		logger.debug("isGapLineAvailable Record:" + retValue);
		return retValue;
	}

	public Date getDatesFromLoanTable(Brm_processing_info procInfoObj, String fieldName) {

		Date gapDate = null;
		String sql = env.getRequiredProperty("select.gap.date");
		sql = sql.replaceAll("D1", fieldName);
		sql = sql + " AND [IS_LOAN_NO] = '" + procInfoObj.getTransaction_loan_no() + "' AND [IS_LOAN_SUFFIX] = "
				+ procInfoObj.getTansactionLoanSuffix() + " AND [IS_ACCOUNT_NO] = " + procInfoObj.getAccountNumber();

		logger.debug("GapLine Query For " + fieldName + ":" + sql);

		List<Map<String, Object>> rows = jdbcTemplate_iir.queryForList(sql);

		String sqlCount = env.getRequiredProperty("select.gap.count") + " AND [IS_LOAN_NO] = '"
				+ procInfoObj.getTransaction_loan_no() + "' AND [IS_LOAN_SUFFIX] = "
				+ procInfoObj.getTansactionLoanSuffix() + " AND [IS_ACCOUNT_NO] = " + procInfoObj.getAccountNumber();

		logger.debug("getDatesFromLoanTable Count Query: " + sqlCount);

		int total = jdbcTemplate_iir.queryForObject(sqlCount, Integer.class);

		if (total != 0) {
			for (Map map : rows) {

				gapDate = (java.sql.Timestamp) map.get(fieldName);
			}

		} else {
			logger.debug("getDatesFromLoanTable() Record Empty");
			try {
				gapDate = new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				logger.debug("Error From getDatesFromLoanTable:" + e.getMessage());
			}
			;
		}

		return gapDate;
	}

	public Map<String, String> getLoanStatusAS400(Connection as400_conn, String accountNumber, String loanNumber,
			String loanSuffix, String covType, String AS400LibPath, ArrayList<String> libraryList) {

		return com.SWBC.AS400SP.Procedures.getAS400MortgageLoanStatus(as400_conn, accountNumber, loanNumber, loanSuffix,
				covType, AS400LibPath, libraryList);
	}

	public Brm_rule_lookup_log getRuleRecord(String ruleName) {

		Brm_rule_lookup_log ruleLookUpRow = new Brm_rule_lookup_log();

		String sql = env.getRequiredProperty("select.rule.lookup.log");

		List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql, new Object[] { ruleName });

		for (Map row : rows) {

			ruleLookUpRow.setRule_name(row.get("rule_name").toString());
			ruleLookUpRow.setRule_msg(row.get("rule_message").toString());
			ruleLookUpRow.setRule_category(row.get("rule_category").toString());
			ruleLookUpRow.setRule_outcome(row.get("rule_outcome").toString());

		}

		return ruleLookUpRow;

	}

	public Brm_app_json_info getJSONOutput(String idCol) {

		Brm_app_json_info obj = new Brm_app_json_info();

		String sql = env.getRequiredProperty("select.app.json.out") + " where id ='" + idCol + "'";
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql);
		for (Map<String, Object> row : list) {

			obj.setInput_param(row.get("input_parameters").toString());
			obj.setJsonOut(row.get("jsonOutValue").toString());

		}

		return obj;

	}

	public List<Brm_rule> getSingleRuleList(String ruleName) {

		List<Brm_rule> ruleList = new ArrayList<Brm_rule>();

		String sql = env.getRequiredProperty("select.single.rule.outcome");

		List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql, new Object[] { ruleName });

		for (Map row : rows) {

			Brm_rule ruleLookUpRow = new Brm_rule();
			ruleLookUpRow.setRule_name(row.get("rule_name").toString());
			ruleLookUpRow.setRule_outcome(row.get("rule_outcome").toString());
			ruleLookUpRow.setRule_msg(row.get("rule_message").toString());
			ruleList.add(ruleLookUpRow);
		}

		return ruleList;

	}

	public List<Map<String, Object>> getACCTSubStr(int accountNo) {

		List<Map<String, Object>> dbRow = new ArrayList<Map<String, Object>>();

		String sql = env.getRequiredProperty("select.FMS057.substring") + accountNo;

		dbRow = jdbcTemplate_FMI006.queryForList(sql);

		return dbRow;
	}

	public List<Map<String, Object>> getCarrierFMS053() {

		List<Map<String, Object>> dbRow = new ArrayList<Map<String, Object>>();

		String sql = env.getRequiredProperty("select.FMS053.carrier");

		dbRow = jdbcTemplate_FMI006.queryForList(sql);

		return dbRow;
	}

	public IDfCollection executeDCTMQuery(IDfSession session, String query, String rObjID) {

		IDfCollection outputColl = null;

		try {
			IDfClientX cx = new DfClientX();
			IDfQuery idfQry = cx.getQuery();
			idfQry.setDQL(query + " where r_object_id = " + "'" + rObjID + "'");

			// Execute the query
			outputColl = idfQry.execute(session, IDfQuery.READ_QUERY);
		} catch (DfException dfe) {

			dfe.printStackTrace();
		}
		return outputColl;
	}

	
	public void saveEventAuditField(long event_id, String field_name, String value_before, String value_after) {

		jdbcTemplate.update(env.getRequiredProperty("insert.preproc.event.field"), event_id, field_name, value_before,
				value_after);

	}

	public List<Map<String, Object>> getShortNameFMS057(String format, int account_no) {

		List<Map<String, Object>> dbRow = new ArrayList<Map<String, Object>>();

		String sql = env.getRequiredProperty("select.FMS057.rule.preproc.short.name");

		dbRow = jdbcTemplate_FMI006.queryForList(sql, new Object[] { format, account_no });

		return dbRow;

	}

	
	public List<Map<String, Object>> getISAgentCode(String accno, String covType, String loanNo, String tranID,
			String suffix) {

		List<Map<String, Object>> dbRow = new ArrayList<Map<String, Object>>();

		String sql = env.getRequiredProperty("select.FMI002.agent.code");

		dbRow = jdbcTemplate_FMI006.queryForList(sql, new Object[] { accno, covType, loanNo, tranID, suffix });

		return dbRow;
	}


	public List<Map<String, Object>> getPayeePreProc3_2(String carrierState, String carrierName, String accountNo) {

		Map<String, String> carrierLookup = new HashMap<String, String>();
		carrierLookup.put("FARMERS", "EDIFAR");
		carrierLookup.put("AMERFAM", "EDIAMF");
		carrierLookup.put("ERIE", "EDIERI");
		carrierLookup.put("ERIE INSURANCE EXCHANGE", "EDIFAR");
		carrierLookup.put("STFARM", "CGSTF");
		carrierLookup.put("NWIDE", "EDINWI");
		carrierLookup.put("TRAVLER", "EDITRV");
		carrierLookup.put("ALLSTATE", "EDIALS");

		List<Map<String, Object>> dbRow = new ArrayList<Map<String, Object>>();
		String sql = null;

		if (carrierName.equalsIgnoreCase("STFARM")) {
			sql = env.getRequiredProperty("select.FMS057.STFARM.3.2");
			dbRow = jdbcTemplate_FMI006.queryForList(sql, new Object[] { carrierState, "CGSTF", accountNo });
		} else {
			if (!carrierLookup.containsKey(carrierName)) {
				sql = env.getRequiredProperty("select.FMS057.rule.preproc.short.name");
				dbRow = jdbcTemplate_FMI006.queryForList(sql, new Object[] { "CGOTHR", accountNo });
			} else {
				sql = env.getRequiredProperty("select.FMS057.rule.preproc.short.name");
				dbRow = jdbcTemplate_FMI006.queryForList(sql,
						new Object[] { carrierLookup.get(carrierName), accountNo });
			}

		}

		return dbRow;

	}

	public String getMasterPayee(String accountNo) {

		String sql = env.getRequiredProperty("select.FMS057.master.payee");

		String masterPayee = (String) jdbcTemplate_FMI006.queryForObject(sql, new Object[] { accountNo }, String.class);

		return masterPayee;

	}

	
	public String getPayeeIDFromAS4SP(String carrierName, String policyNo, String state, String covType, String accno) {

		return com.SWBC.AS400SP.Procedures.getPayeeList(AS400Conn, accno, "A", state, covType, policyNo,
				env.getRequiredProperty("AS400_LIB_SET_CONST"), mortlibraryList);
	}

	
	public void insertStagingTable(PreProc_Doca_Ucap preProc_Doca_Ucap) {

		try {
			jdbcTemplate.update(env.getRequiredProperty("insert.pre.proc.staging"), preProc_Doca_Ucap.getPp_flag(),
					preProc_Doca_Ucap.getInsurance_type(), preProc_Doca_Ucap.getFlood_zone(),
					preProc_Doca_Ucap.getHo_6_flag(), preProc_Doca_Ucap.getGrandfater_zone(),
					preProc_Doca_Ucap.getEarthquake_excluded(), preProc_Doca_Ucap.getGrandfather_zone(),
					preProc_Doca_Ucap.getDoc_scan_date(), preProc_Doca_Ucap.getReplace_cost_ind(),
					preProc_Doca_Ucap.getBill_indicator(), preProc_Doca_Ucap.getPercent_add_other_structure(),
					preProc_Doca_Ucap.getWind_excluded(), preProc_Doca_Ucap.getDocument_sub_type(),
					preProc_Doca_Ucap.getFollow_up_date(), preProc_Doca_Ucap.getFollow_up_reason(),
					preProc_Doca_Ucap.getAgent_email(), preProc_Doca_Ucap.getCov_type(),
					preProc_Doca_Ucap.getIs_qc_candidate(), preProc_Doca_Ucap.getDocument_type(),
					preProc_Doca_Ucap.getLoan_type(), preProc_Doca_Ucap.getPolicy_expiration_date(),
					preProc_Doca_Ucap.getPolicy_cancel_date(), preProc_Doca_Ucap.getCarrier_zip(),
					preProc_Doca_Ucap.getPremium_due_date(), preProc_Doca_Ucap.getTransaction_status(),
					preProc_Doca_Ucap.getOrig_file_name(), preProc_Doca_Ucap.getProperty_zip(),
					preProc_Doca_Ucap.getLoan_number(), preProc_Doca_Ucap.getPercent_primary_coverage(),
					preProc_Doca_Ucap.getPolicy_premium(), preProc_Doca_Ucap.getAgency_number(),
					preProc_Doca_Ucap.getEscrow_indicator(), preProc_Doca_Ucap.getMailing_address(),
					preProc_Doca_Ucap.getPercent_deductible(), preProc_Doca_Ucap.getAccount_number(),
					preProc_Doca_Ucap.getBatch_number(), preProc_Doca_Ucap.getCoverage_amount(),
					preProc_Doca_Ucap.getAccount_tax_id(), preProc_Doca_Ucap.getProperty_address_1(),
					preProc_Doca_Ucap.getProperty_address_2(), preProc_Doca_Ucap.getDoc_issue_date(),
					preProc_Doca_Ucap.getMailing_state(), preProc_Doca_Ucap.getPayee_code(),
					preProc_Doca_Ucap.getClient_number(), preProc_Doca_Ucap.getNumber_of_condos(),
					preProc_Doca_Ucap.getQc_response_code(), preProc_Doca_Ucap.getScan_id(),
					preProc_Doca_Ucap.getDoc_notice_effective_date(), preProc_Doca_Ucap.getDoc_delivery_date(),
					preProc_Doca_Ucap.getProperty_city(), preProc_Doca_Ucap.getPolicy_number(),
					preProc_Doca_Ucap.getMortgagee_zip(), preProc_Doca_Ucap.getMortgagee_name(),
					preProc_Doca_Ucap.getDoc_notice_date(), preProc_Doca_Ucap.getAgent_city(),
					preProc_Doca_Ucap.getImpairment_code(), preProc_Doca_Ucap.getAgent_name(),
					preProc_Doca_Ucap.getMailing_city(), preProc_Doca_Ucap.getPolicy_cancel_reason(),
					preProc_Doca_Ucap.getMortgagee_city(), preProc_Doca_Ucap.getAgent_zip(),
					preProc_Doca_Ucap.getAccount_name(), preProc_Doca_Ucap.getTransaction_id(),
					preProc_Doca_Ucap.getBatch_seq_no(), preProc_Doca_Ucap.getReinstatement_date(),
					preProc_Doca_Ucap.getTransaction_source(), preProc_Doca_Ucap.getCo_policy_holder_name(),
					preProc_Doca_Ucap.getPolicy_effective_date(), preProc_Doca_Ucap.getProperty_state(),
					preProc_Doca_Ucap.getCarrier_city(), preProc_Doca_Ucap.getAgent_phone(),
					preProc_Doca_Ucap.getCarrier_name(), preProc_Doca_Ucap.getLoan_suffix(),
					preProc_Doca_Ucap.getDoc_received_date(), preProc_Doca_Ucap.getMortgagee_address(),
					preProc_Doca_Ucap.getCarrier_state(), preProc_Doca_Ucap.getAs400_post_date(),
					preProc_Doca_Ucap.getAgent_address(), preProc_Doca_Ucap.getAdditional_coverage_amount(),
					preProc_Doca_Ucap.getAdditional_premium_amt(), preProc_Doca_Ucap.getInstitution_code(),
					preProc_Doca_Ucap.getCarrier_address_1(), preProc_Doca_Ucap.getAgent_state(),
					preProc_Doca_Ucap.getPolicy_holder_name(), preProc_Doca_Ucap.getDeductible(),
					preProc_Doca_Ucap.getTransaction_type(), preProc_Doca_Ucap.getMailing_zip(),
					preProc_Doca_Ucap.getMortgagee_state(), preProc_Doca_Ucap.getCarrier_phone(),
					preProc_Doca_Ucap.getBase_coverage_other_structs());

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	
	public List<String> getInputrObjID(String dqlQyr, IDfSession session) {

		List<String> inInpRObjID = new ArrayList<String>();

		IDfCollection outputColl = null;

		try {
			IDfClientX cx = new DfClientX();
			IDfQuery idfQry = cx.getQuery();
			idfQry.setDQL(dqlQyr);

			outputColl = idfQry.execute(session, IDfQuery.READ_QUERY);
		} catch (DfException dfe) {

			dfe.printStackTrace();
		}

		try {
			while (outputColl.next()) {
				inInpRObjID.add(outputColl.getId("r_object_id").toString());
			}
		} catch (DfException e) {

			e.printStackTrace();
		}

		return inInpRObjID;
	}

	
	public void insertBRM_EVENT_AUDIT_LOG(PreProc_Doca_Ucap preProc_Doca_Ucap, String ruleName) {

		try {

			jdbcTemplate.update(env.getRequiredProperty("insert.preproc.event"), preProc_Doca_Ucap.getLogJoinID(),
					"admin", "admin", ruleName, preProc_Doca_Ucap.getTransaction_id(),
					preProc_Doca_Ucap.getTransaction_type(), preProc_Doca_Ucap.getAccount_number(),
					preProc_Doca_Ucap.getLoan_number().trim(), preProc_Doca_Ucap.getLoan_suffix(),
					preProc_Doca_Ucap.getCov_type(), preProc_Doca_Ucap.getInsurance_type(),
					preProc_Doca_Ucap.getPolicy_holder_name(), preProc_Doca_Ucap.getCo_policy_holder_name(),
					preProc_Doca_Ucap.getProperty_address_1(), preProc_Doca_Ucap.getProperty_address_2(),
					preProc_Doca_Ucap.getProperty_city(), preProc_Doca_Ucap.getProperty_state(),
					preProc_Doca_Ucap.getPolicy_effective_date(), preProc_Doca_Ucap.getPolicy_expiration_date(),
					preProc_Doca_Ucap.getPayee_code()

			);

		} catch (Exception e) {

			System.out.println(ruleName + " " + preProc_Doca_Ucap.getLogJoinID() + " "
					+ preProc_Doca_Ucap.getTransaction_id() + " " + preProc_Doca_Ucap.getTransaction_type() + " "
					+ preProc_Doca_Ucap.getAccount_number() + " " + preProc_Doca_Ucap.getLoan_number() + " "
					+ preProc_Doca_Ucap.getLoan_suffix() + " " + preProc_Doca_Ucap.getCov_type() + " "
					+ preProc_Doca_Ucap.getInsurance_type() + " " + preProc_Doca_Ucap.getPolicy_holder_name() + " "
					+ preProc_Doca_Ucap.getCo_policy_holder_name() + " " + preProc_Doca_Ucap.getProperty_address_1()
					+ " " + preProc_Doca_Ucap.getProperty_address_2() + " " + preProc_Doca_Ucap.getProperty_city() + " "
					+ preProc_Doca_Ucap.getProperty_state() + " " + preProc_Doca_Ucap.getPolicy_effective_date() + " "
					+ preProc_Doca_Ucap.getPolicy_expiration_date() + " " + preProc_Doca_Ucap.getPayee_code());

			e.printStackTrace();
		}

	}

	
	public List<Map<String, Object>> getBICData(int account_no, String loanNo,String covType) {

		List<Map<String, Object>> dbRow = new ArrayList<Map<String, Object>>();

		String sql = env.getRequiredProperty("select.BIC.data");

		dbRow = jdbcTemplate_FMI006.queryForList(sql, new Object[] { account_no, loanNo, covType });

		return dbRow;
	}

	
	public void insertSchedularLog(Date startTime, Date endTime, String appName, String metrics, String status) {
	
		jdbcTemplate.update(env.getRequiredProperty("insert.schedular.log.tbl"), startTime, endTime,
				appName, metrics, status);

		
	}


	public String getWaiveCode(String accno, String loanno, String covType) {
		
		
		String sql = env.getRequiredProperty("select.pymt.waive.code");

		String masterPayee = (String) jdbcTemplate_iir.queryForObject(sql, new Object[] { accno,loanno,covType }, String.class);
		
		return masterPayee;
		
	}

	
	public Date getLoanBoardDate(String accno, String loanno, String covType, String tranCode) {
		
		Date lbdDate = null;
		String sql = env.getRequiredProperty("select.pymt.loan.board.date");

		String lbd = (String) jdbcTemplate_FMI006.queryForObject(sql, new Object[] { accno,loanno,covType,tranCode }, String.class);
		
		try {
			lbdDate =  new SimpleDateFormat("yyyy-MM-dd").parse(lbd);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return lbdDate;
		
	}

	
	public List<Map<String, Object>> getPymtDisbData(String accountNo) {
		
		List<Map<String, Object>> dbRow = new ArrayList<Map<String, Object>>();

		String sql = env.getRequiredProperty("select.pymt.disb.data") + accountNo;

		dbRow = jdbcTemplate_FMI006.queryForList(sql);

		return dbRow;
		
		
	}
}
