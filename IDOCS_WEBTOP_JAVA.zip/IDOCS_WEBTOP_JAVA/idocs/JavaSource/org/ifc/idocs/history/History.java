package org.ifc.idocs.history;

import java.util.Date;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.CollaborationService;
import com.documentum.web.form.control.DateTime;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.Panel;
import com.documentum.web.form.control.databound.DataDropDownList;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.form.control.databound.TableResultSet;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.docbase.FolderUtil;

public class History extends Component{

	public History(){
		m_ObjectId = null;
    }

    public void onInit(ArgumentList args){
    	super.onInit(args);
    	m_ObjectId = args.get(OBJECT_ID);
    	DfLogger.debug(this, "onInit : m_ObjectId="+m_ObjectId , null, null);
    	boolean fIsFolderType = FolderUtil.isFolderType(m_ObjectId);
        boolean bIsNotePageType = CollaborationService.isNotePageType(m_ObjectId);
    	if(fIsFolderType || bIsNotePageType){
    		((Panel)getControl(STR_VERSIONS_PANEL, Panel.class)).setVisible(false);
    	}else{
             String strVersionsComboQuery = getVersionsComboQuery(m_ObjectId);
             DataDropDownList versionsCombo = (DataDropDownList)getControl(STR_VERSIONS_FILTER, DataDropDownList.class);
             versionsCombo.getDataProvider().setQuery(strVersionsComboQuery);
             versionsCombo.getDataProvider().setDfSession(getDfSession());
             versionsCombo.setValue(m_ObjectId);
         }  	
    }
    
    private String getVersionsComboQuery(String strObjectId)
    {
        StringBuffer buf = new StringBuffer(256);
        buf.append("SELECT r_object_id,r_version_label FROM dm_sysobject (all) WHERE i_chronicle_id IN ")
        .append("(SELECT i_chronicle_id_i FROM dm_sysobject (all) WHERE r_object_id_i = '")
        .append(strObjectId).append("') ORDER BY r_modify_date DESC, r_object_id");
        return buf.toString();
    }

    public void onRender(){
    	updateDocumentHistoryTable();
    	updateWorkflowAuditTrail();
        super.onRender();
        try {
        	if(wfcounter <= 0 ){
        		Panel documentAuditDatagridPanel = (Panel) getControl(MIGRATED_WF_AUDIT_TRIAL_PANEL, Panel.class);
				documentAuditDatagridPanel.setVisible(false);
				DfLogger.debug(this, "Workflow Audit Trail Not Present: Disable the WF Audit Datagrid" , null, null);
				m_wfauditdatagrid.setVisible(false);
				m_wfauditdatagrid.setEnabled(false);
        	}else{
        		DfLogger.debug(this, "Workflow Audit Trails Found : Enable Wf Audit Trail Datagrid" , null, null);
        		m_wfauditdatagrid = (Datagrid)getControl(WF_AUDIT_GRID_NAME, Datagrid.class);
				Panel documentAuditDatagridPanel = (Panel) getControl(MIGRATED_WF_AUDIT_TRIAL_PANEL, Panel.class);
				documentAuditDatagridPanel.setVisible(true);
				Label lblAudittableCaption = (Label) getControl("wfaudittablecaption", Label.class);
				if (lblAudittableCaption != null)lblAudittableCaption.setVisible(true);
				m_wfauditdatagrid.setVisible(true);
				m_wfauditdatagrid.setEnabled(true);
        	}
        		DfLogger.debug(this, "Old Document Audit Trails Found : Enable Audit Trail Datagrid" , null, null);
        		m_wfauditdatagrid = (Datagrid)getControl(OLD_GRID_NAME, Datagrid.class);
				Panel documentAuditDatagridPanel = (Panel) getControl(MIGRATED_AUDIT_TRIAL_PANEL, Panel.class);
				documentAuditDatagridPanel.setVisible(true);
				m_wfauditdatagrid.setVisible(true);
				m_wfauditdatagrid.setEnabled(true);
        } catch (Exception e) {
        	DfLogger.debug(this, " onRender :: Exception :"+e.getMessage() , null, null);
		}
    }

    public void onSelectVersionFilter(DataDropDownList control, ArgumentList args){
    	m_ObjectId = control.getValue();
    	DfLogger.debug(this, "onSelectVersionFilter" + m_ObjectId , null, null);
    	updateDocumentHistoryTable();
    }

	private void updateDocumentHistoryTable() {
		m_objectdatagrid = (Datagrid)getControl(OLD_GRID_NAME, Datagrid.class);
		String strQuery = IdocsUtil.getMessage(QRY_AUDIT_HISTORY);
		strQuery = strQuery.replaceFirst(DOUBLE_QUOTES, SINGLE_QUOTES+m_ObjectId+SINGLE_QUOTES);
		DfLogger.debug(this, "History Table : Data Grid Query="+strQuery, null, null);
		try{
			TableResultSet typeResultSet = new TableResultSet(new String[] {STRING_ACTION,STRING_PERFORMER,STRING_TIME_STAMP});
			IDfCollection collection = IdocsUtil.executeQuery(getDfSession(), strQuery, IDfQuery.DF_READ_QUERY);
			while(collection.next()) {
		        String docName = collection.getString(STRING_ACTION);
		        String docType = collection.getString(STRING_PERFORMER);
		        String timestamp = collection.getString(STRING_TIME_STAMP);
		        typeResultSet.add(new String[] {docName, docType,convertToClientTime(timestamp)});
		        counter++;
		    }
		    if( collection != null )collection.close();
		    if(counter >0){
		    	m_objectdatagrid.setVisible(true);
		    	m_objectdatagrid.setEnabled(true);
		    	m_objectdatagrid.getDataProvider().setScrollableResultSet(typeResultSet);	
		    	DfLogger.debug(this, "History Table : Data Grid Has Values. DISPLAY It : Size="+counter , null, null);
		    }else{
		    	Label lblAudittableCaption = (Label)getControl("audittablecaption",Label.class);
		    	if(lblAudittableCaption!=null)lblAudittableCaption.setVisible(false);
		    	m_objectdatagrid.setVisible(false);
		    	m_objectdatagrid.setEnabled(false);
		    	DfLogger.debug(this, "History Table : Data Grid Is Empty. Hide It" , null, null);
		    }
		}catch (Exception e) {
			DfLogger.error(this, "History Table : Data Grid :Exception "+e.getMessage() , null, null);
		}	      		
	}
	
    static String convertToClientTime(String timeStamp)
    {
        String strValue = timeStamp;
        try {
			Date date = new Date(timeStamp);
			if(date != null)
			    strValue = DateTime.toValue(date);
		} catch (Exception e) {
			DfLogger.error(History.class, "Date Conversion Failed: Show US TIME", null, null);
		}
        return strValue;
    }

	private void updateWorkflowAuditTrail() {
		m_wfauditdatagrid = (Datagrid)getControl(WF_AUDIT_GRID_NAME, Datagrid.class);
        String strQuery = IdocsUtil.getMessage(QRY_MIG_WF_AUDIT_TRAIL);
        String chronicleId = IDocDocbaseAttributeTagUtility.getCurrentSysObjectAttribute(getDfSession(), m_ObjectId, IDocsConstants.MSG_I_CHRONICLE_ID);
        if(chronicleId !=null && chronicleId.trim().length() > 0){
        	strQuery = strQuery.replaceFirst(DOUBLE_QUOTES, SINGLE_QUOTES+chronicleId+SINGLE_QUOTES);
        }else{
        	strQuery = strQuery.replaceFirst(DOUBLE_QUOTES, SINGLE_QUOTES+m_ObjectId+SINGLE_QUOTES);
        }
        DfLogger.debug(this, "Workflow Audit Trail Table : Data Grid Query="+strQuery, null, null);
        try{
        	TableResultSet typeResultSet = new TableResultSet(new String[] {WORKFLOWNAME,ACTIVITY_NAME,ACTIVITY_AUDIT_TRAIL,STRING_TIME_STAMP});
	    	IDfCollection collection = IdocsUtil.executeQuery(getDfSession(), strQuery, IDfQuery.DF_READ_QUERY);
	    	while(collection.next()) {
	            String documentId = collection.getString(WORKFLOWNAME);
	            String activityName = collection.getString(ACTIVITY_NAME);
	            String activityAuditTrail = collection.getString(ACTIVITY_AUDIT_TRAIL);
	            String doctimestamp = collection.getString(STRING_TIME_STAMP);
	            typeResultSet.add(new String[] {documentId, activityName,activityAuditTrail,convertToClientTime(doctimestamp)});
	            wfcounter++;
		    }
		    if( collection != null )collection.close();
		    if(wfcounter >0){
		    	m_wfauditdatagrid.setVisible(true);
		    	m_wfauditdatagrid.setEnabled(true);
		    	m_wfauditdatagrid.getDataProvider().setScrollableResultSet(typeResultSet);	
		    	DfLogger.debug(this, "Workflow Audit Trail Table : Data Grid Has Values. DISPLAY It : Size="+counter , null, null);
		    }else{
		    	Label lblAudittableCaption = (Label)getControl("audittablecaption",Label.class);
		    	if(lblAudittableCaption!=null)lblAudittableCaption.setVisible(false);
		    	m_wfauditdatagrid.setVisible(false);
		    	m_wfauditdatagrid.setEnabled(false);
		    	DfLogger.debug(this, "Workflow Audit Trail Table : Data Grid Is Empty. Hide It" , null, null);
		    }
	    }catch (Exception e) {
	    	DfLogger.error(this, "Workflow Audit Trail Table : Data Grid :Exception "+e.getMessage() , null, null);
		}		
	}

	private static final String OBJECT_ID = "objectId";
	private static final String QRY_MIG_WF_AUDIT_TRAIL = "QRY_MIG_WF_AUDIT_TRAIL";
	private static final String ACTIVITY_AUDIT_TRAIL = "activity_audit_trail";
	private static final String ACTIVITY_NAME = "activity_name";
	private static final String WORKFLOWNAME = "workflowname";
	private static final String STRING_TIME_STAMP = "time_stamp";
	private static final String STRING_PERFORMER = "performer";
	private static final String STRING_ACTION = "action";
	private static final String QRY_AUDIT_HISTORY = "QRY_AUDIT_HISTORY";
	private static final String SINGLE_QUOTES = "'";
	private static final String DOUBLE_QUOTES = "''";
	private static final long serialVersionUID = 1L;
    public static final String OLD_GRID_NAME = "old_object_grid";
    public static final String WF_AUDIT_GRID_NAME="workflow_audit_trail_grid";
    public static final String MIGRATED_AUDIT_TRIAL_PANEL  = "documenthistorydatagrid";
    public static final String MIGRATED_WF_AUDIT_TRIAL_PANEL = "workflowaudittrialdatagrid";
    public static final String STR_VERSIONS_FILTER = "version_filter";
    public static final String STR_VERSIONS_PANEL = "versions_panel";
    Datagrid m_objectdatagrid = null;
    Datagrid m_wfauditdatagrid = null;
    private String m_ObjectId;
    int counter = 0;
    int wfcounter = 0;

}

