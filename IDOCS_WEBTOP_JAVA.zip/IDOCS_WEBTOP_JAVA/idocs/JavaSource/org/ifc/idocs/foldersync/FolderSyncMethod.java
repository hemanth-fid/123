package org.ifc.idocs.foldersync;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.LocaleService;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.Panel;
import com.documentum.web.form.control.databound.DataProvider;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.formext.component.Component;


public class FolderSyncMethod extends Component{

	/**
	 * 
	 */
	private static final long serialVersionUID = -263903744769906190L;
	NlsResourceBundle nlsBundle;
	private final String PANEL_SUCCESS = "success";
	private final String PANEL_FAILURE = "failure";
	
	public void onInit(ArgumentList argumentList) {
		try{
			
			// Success Panel
	        Panel successpanel = (Panel)getControl(PANEL_SUCCESS,Panel.class);
	        // Failure Panel
	        Panel failurepanel = (Panel)getControl(PANEL_FAILURE,Panel.class);
	        
			String folderObjectId = null;
			String countryCode = null;
			IDfSession dfSession = getDfSession();
			String folderSyncNlsProp = "org.ifc.idocs.foldersync.folderSyncNlsProp";
			nlsBundle = new NlsResourceBundle(folderSyncNlsProp);
			folderObjectId= argumentList.get("objectId");
			IDfFolder strFolderId = (IDfFolder) dfSession.getObject(new DfId(folderObjectId));
			strFolderId.getFolderPath(0);
			DfLogger.debug(this, "Primary Folder ID : : : "+strFolderId.getFolderPath(0), null, null);
			String strFoldername=strFolderId.getObjectName();
			DfLogger.debug(this, "Folder name of object id : : : "+strFoldername, null, null);
			String strFolder[]=strFolderId.getFolderPath(0).split("/");
			String strCountry=strFolder[2];
			DfLogger.debug(this, "Folder name at 1st level is : : : "+strCountry, null, null);
			if(!strFoldername.equalsIgnoreCase(strCountry)) {
				 failurepanel.setVisible(true);
			     successpanel.setVisible(false);
				 Label selectCountryLabel = (Label)getControl("selectCountry",Label.class);
				 selectCountryLabel.setVisible(true);
				 
			} else {
				DfLogger.info(this," : onInit : folder object id : " + folderObjectId,null,null);
				if(null != folderObjectId){
					failurepanel.setVisible(false);
			        successpanel.setVisible(true);
			        Label selectCountryLabel = (Label)getControl("selectCountry",Label.class);
			        selectCountryLabel.setVisible(false);
			        String countryQry = nlsBundle.getString("AS_COUNTRY_CODE_QRY", LocaleService.getLocale());
					countryQry = countryQry.replaceAll("%object_id%", folderObjectId);
					DfLogger.debug(this," : onInit : Country code Qry : " + countryQry,null,null);
					IDfQuery qryObj = new DfQuery();
					qryObj.setDQL(countryQry);
					try {
						IDfCollection countryColl = qryObj.execute(dfSession, IDfQuery.DF_READ_QUERY);
						try{
							while(countryColl.next()){
								countryCode = countryColl.getString("country_code");
								DfLogger.debug(this," : onInit : Country Code : " + countryCode,null,null);
							}
						}finally{
							if(countryColl != null){
								countryColl.close();
							}
						}

					} catch (DfException e) {
						e.printStackTrace();
					}

					if(null != countryCode){
						String folderSyncQry = nlsBundle.getString("AS_FOLDER_SYNC_QRY", LocaleService.getLocale());
						folderSyncQry = folderSyncQry.replaceAll("%country_code%", countryCode);
						DfLogger.debug(this, "Folder sync query  : : : " +folderSyncQry, null, null);
						Datagrid dataGrid = (Datagrid)getControl("folderSyncGrid", Datagrid.class);
						if(dataGrid == null){
							dataGrid = (Datagrid)createControl("folderSyncGrid", Datagrid.class);
						}
						DfLogger.debug(this," : onInit : DataGrid is created...  ",null,null);
						DataProvider dataprovider = dataGrid.getDataProvider();
						dataprovider.setDfSession(dfSession);
						dataprovider.setQuery(folderSyncQry);								
					
					}
				}
			}
		} catch (Exception e) {
			
		}
	}
	

	public void onRender() {
		super.onRender();
	}
	
	/**
     * 
     */
    public boolean onCommitChanges() {
    	return super.onCommitChanges();    	
    }
}
