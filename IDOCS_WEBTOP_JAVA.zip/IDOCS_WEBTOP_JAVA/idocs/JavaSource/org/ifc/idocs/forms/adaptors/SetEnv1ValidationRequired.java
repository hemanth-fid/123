
package org.ifc.idocs.forms.adaptors;

import com.documentum.fc.common.DfLogger;
import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.IAdaptorParameter;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.xforms.engine.adaptor.datasource.ISetValueAdaptor;
import java.io.PrintStream;

@SuppressWarnings("unused")
public class SetEnv1ValidationRequired
    implements ISetValueAdaptor
{

    public SetEnv1ValidationRequired()
    {
    }

    public Object execute(IAdaptorParameter parameters[])
        throws AdaptorException
    {
        DfLogger.info(this,"SetEnv1ValidationRequired:: SetEnv1ValidationRequired",null,null); 
        String validationRequired = "env1";
        return validationRequired;
    }

    public void destroy()
        throws AdaptorException
    {
    }

    public void init(IAdaptorConfiguration iadaptorconfiguration)
        throws AdaptorException
    {
    }
}
