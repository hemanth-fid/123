package sf.application.custcomm.ccs.core;

import static java.util.concurrent.TimeUnit.SECONDS;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ScheduledExecutorService;

import org.apache.log4j.Logger;

import sf.application.custcomm.ccs.constants.CleanUpConstants;
import sf.application.custcomm.ccs.constants.ExceptionConstants;
import sf.application.custcomm.ccs.constants.QueryConstants;
import sf.application.custcomm.ccs.dao.ICleanUpQueryDao;
import sf.application.custcomm.ccs.dao.impl.CleanUpQueryDao;
import sf.application.custcomm.ccs.exceptions.CleanUpServiceException;
import sf.application.custcomm.ccs.exceptions.QueryException;
import sf.application.custcomm.ccs.util.CleanUpHelper;
import sf.application.custcomm.ccs.util.DocumentumUtils;
import sf.application.custcomm.ccs.util.FileOperationUtils;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfLogger;
import com.emciig.utils.LogUtils;
import com.emciig.utils.SessionUtils;

public class PurgeDataWriterService implements Runnable {
	
	
	

	private Map<String, String> parameters;
	private ScheduledExecutorService scheduler;
	private static LogUtils logger = new LogUtils();
	private static final String NEW_LINE_SEPARATOR = "\n";
	ICleanUpQueryDao cleanUpQueryDao =null;
	private static final Logger LOGGER=DfLogger.getLogger(PurgeDataWriterService.class);
	//int numOfFolderIdsPerServer=0;
	

	/**
	 * Constructor
	 * 
	 * @param params
	 * @param scheduler
	 * @param registeredObject
	 */
	public PurgeDataWriterService(Map<String, String> params,
			ScheduledExecutorService scheduler) {

		this.parameters = params;
		this.scheduler = scheduler;
		

	}

	/**
	 * An unimplemented method inherited from class Runnable which gets
	 * automatically invoked when ExecuteTimerActivities class is instantiated
	 */
	public void run() {

		if (DfLogger.isTraceEnabled(this)) {
			DfLogger.trace(this, "Method CreateFilesService run() entry",
					null, null);
		}

		IDfSession idfSession = null;

		try {
			
			
           
			idfSession = DocumentumUtils.getSession(parameters);
			cleanUpQueryDao = new CleanUpQueryDao();
			performOperation(idfSession);
			
		} catch (CleanUpServiceException cleanUpServiceException) {

			DfLogger.error(this,
					ExceptionConstants.ERROR_IN_RETRIEVING_OBJECTS, null,
					cleanUpServiceException);
		} finally {

			SessionUtils.disconnect(idfSession);
			scheduleNextRun();
		}

		if (DfLogger.isTraceEnabled(this)) {
			DfLogger.trace(this, "Method CreateFilesService run() exit",
					null, null);
		}

	}

	/**
	 * It determines the next run time.
	 * 
	 * 
	 */
	private void scheduleNextRun() {

		if (DfLogger.isTraceEnabled(this)) {
			DfLogger.trace(this, "Method scheduleNextRun() entry", null, null);
		}

		int timerseconds = Integer.parseInt(parameters
				.get(CleanUpConstants.PARAM_NEXT_RUN_TIME));
		scheduler.schedule(new PurgeDataWriterService(parameters, scheduler),
				timerseconds, SECONDS);

		if (DfLogger.isTraceEnabled(this)) {
			DfLogger.trace(this, "Method scheduleNextRun() exit", null, null);
		}

	}
	
	
	

	private void performOperation(IDfSession session)
			throws CleanUpServiceException {

		if (DfLogger.isTraceEnabled(this)) {
			DfLogger.trace(this, "Method performOperation() entry", null, null);
		}

	
	performOperationOnExportedObjects(session);
	performOperationOnErrorObjects(session);
	 
	
		if (DfLogger.isTraceEnabled(this)) {
			DfLogger.trace(this, "Method performOperation() exit", null, null);
		}

	}
	
	
	
private void performOperationOnExportedObjects(IDfSession session) throws QueryException {
		
		
		int totalnumoffolders = cleanUpQueryDao.getQueryCount(
				QueryConstants.QRY_COUNT_EXPORTED_FOLDERS,new Object []{ parameters.get("exported_retention_period")},session);
		
		LOGGER.info("Total number of Exported folders to delete "+totalnumoffolders);
		assignToServers(session,totalnumoffolders,QueryConstants.QRY_GET_EXPORTED_FOLDERS,parameters.get("exported_retention_period"));
		
		
	}
	

	private void performOperationOnErrorObjects(IDfSession session) throws QueryException {
		
		
		int totalnumoffolders = cleanUpQueryDao.getQueryCount(
				QueryConstants.QRY_COUNT_ERRORED_FOLDERS,new Object []{ parameters.get("error_retention_period")},session);
		
		LOGGER.info("Total number of Error folders to delete "+totalnumoffolders);
		assignToServers(session,totalnumoffolders,QueryConstants.QRY_GET_ERROR_FOLDERS,parameters.get("error_retention_period"));
		
		
	}
	
	
	

	

	private void assignToServers(IDfSession session,int totalnumoffolders,String query,String days)  {
	
	
		try{
			
		int numofitemsperfile=Integer.valueOf(parameters.get("num_of_folderids_per_file")).intValue();
		LOGGER.info("Number of folderids per file  "+numofitemsperfile);
		String[] serverNames=CleanUpHelper.getServerNames(parameters);
		for(String serverName:serverNames){
			
			
		
			
			try{	
				
				
		    
		   
		    int numOfFolderIdsPerServer=totalnumoffolders/serverNames.length;
		    LOGGER.info("Number of folders assigned  to server "+serverName+" to delete "+numOfFolderIdsPerServer);
		    
			    
		    while(numofitemsperfile<=numOfFolderIdsPerServer){
		    	
		    	
		    	
		      	try{
		      		
		      		
		      		createFiles(session,numofitemsperfile,serverName,query,days);
		    	
		      		    	
		    	   }catch(Exception e){
		    		   
		    		   LOGGER.error("Error",e);
		    		  	    		
		    		  
		    		
		    	    }
		      	
		      	
		    	
		    	
		      	numOfFolderIdsPerServer=numOfFolderIdsPerServer-numofitemsperfile;
		    	
		    	
		    	
		    	
		    }//while
		    
		    
		    
		    
		    if((numOfFolderIdsPerServer!=0) && (numOfFolderIdsPerServer<numofitemsperfile)){
		    	
		    	try{
		    	
		    	    	
		    	 createFiles(session,numOfFolderIdsPerServer,serverName,query,days);
		    	}catch(Exception e){
		    		 LOGGER.error("Error",e);
		    	    }
		    	
		    	
		    }
	
			}//try
			catch(Exception e){
				
				 LOGGER.error("Error",e);
	
		}
			
	
		   
		}//main for
		
		
		}// main try
		
		catch(Exception e){
			
			 LOGGER.error("Error",e);
	 
		}
	
			
		}//method
	
	
	
	
	
private void createFiles(IDfSession session,int numofitemsperfile,String serverName,String query,String days) throws QueryException{
		
	    File file=null;
	    FileWriter fileWriter = null;
		List<String> objectIds = cleanUpQueryDao.getMarkedAsPurgeFolderIds(session,	query,new Object []{ days,numofitemsperfile});
		if(objectIds!=null && objectIds.size()>0){
		try{
		file=new File("\\\\"+serverName+"\\"+parameters.get("drive")+"$"+parameters.get("edc_cleanup_folder_path")+parameters.get("drop_off")+FileOperationUtils.getFileName());
  		fileWriter = new FileWriter(file);	
		
		for (String objectId : objectIds) {
			
    		
    		try{
			
			
			fileWriter.append(objectId);
			fileWriter.append(NEW_LINE_SEPARATOR);
		
    		}catch(Exception e){
    			
    			 LOGGER.error("Error",e);
    			
    			
    		}
		}//for
		
		}catch(Exception e){
			
			 LOGGER.error("Error",e);
			
		}finally{
			

			try {
				fileWriter.flush();
				fileWriter.close(); 
			} catch (IOException e) {
				
				 LOGGER.error("Error",e);
			} 
			
			
			
		}
		
		
		FileOperationUtils.fileMove(file.getAbsolutePath(), "\\\\"+serverName+"\\"+parameters.get("drive")+"$"+parameters.get("edc_cleanup_folder_path")+parameters.get("ready_to_process")+FileOperationUtils.getFileName());
		
		}//if close

		
	}
	

	

	
}