package org.ifc.idocs.migration.discussions;

import java.io.File;
import java.io.IOException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.ifc.idocs.migration.importUtility.ImportUtility;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.documentum.com.DfClientX;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfUser;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfId;
import com.documentum.services.collaboration.IComment;
import com.documentum.services.collaboration.ICommentManager;
import com.documentum.services.collaboration.ITopic;
import com.documentum.services.richtext.IRichText;
/**
 * GetDiscussionDocs - Discussion documents would be uploaded. 
 * @author HAnuganti
 * 
 * #############################################################################################
 * Author		            DateofChange	 Version	  ModificationHistory
 * ###########################################################################################
 * Hemachandra Anuganti 
 * ###########################################################################################
 * 
 */
public class GetDiscussionDocs extends ImportUtility {

	protected static String discXMLPath = "";
	
	private static MessageVO msgList[] = null;
	private static int msgCount = 0;
	private static int discussionsCreated = 0;
	static boolean flag = false;
	
	public static boolean getDiscussionXML(String r_object_id, String currentlegacyDocId, String legacyVersion, IDfSession dfSession)
	{
		// TODO Auto-generated method stub
		// Loading the Properties File
		try {
			discXMLPath = sourceRoot + currentlegacyDocId + "_"+ legacyVersion+"_"+idocsProperties.getProperty("MSG_DISC_DOC_XML_EXTN");
			File discXML = new File(discXMLPath);
			if (discXML.exists()) {
				importDocLogger.warning("Uploading discussion for the legacy id::["+currentlegacyDocId+"]Document id::["+r_object_id+"]");
				updateMessageVO(discXMLPath, "Message");		
				int parentEmptyCount = 0;
				String commentId = "";
				for (int i=0;i<msgCount;i++){			
					if (msgList[i].getParent().equalsIgnoreCase("Not Specified")){
						parentEmptyCount++;				
						commentId = createFirstDiscussion(r_object_id, msgList[i]);				
					}//end of If 
				}//end of for loop
				flag = true;
			} else {
				flag = true;
				//importDocLogger.info("XML does not Exists");
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("IOException occured for the discussion XML::"+discXMLPath);
			importDocLogger.warning("IOException ::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"IOException occured for the discussion XML::", e);
			e.printStackTrace();
			flag = false;
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("ParserConfigurationException occured for the discussion XML::"+discXMLPath);
			importDocLogger.warning("ParserConfigurationException ::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"IOException occured for the discussion XML::", e);
			e.printStackTrace();
			flag = false;
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("SAXException occured for the discussion XML::"+discXMLPath);
			importDocLogger.warning("SAXException ::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"IOException occured for the discussion XML::", e);
			e.printStackTrace();
			flag = false;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("Exception occured for the discussion XML::"+discXMLPath);
			importDocLogger.warning("Exception ::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"IOException occured for the discussion XML::", e);
			e.printStackTrace();
			flag = false;
		}
		return flag;

	}
	
	private static String createFirstDiscussion(String strParentId, MessageVO msgVO) throws DfServiceException, DfException{
		
		//importDocLogger.info("Inside createFirstDiscussion(String strParentId, MessageVO msgVO)");
		ICommentManager commentMgr =  (ICommentManager) DfClient.getLocalClient().newService(ICommentManager.class.getName(),dfSession.getSessionManager());
		
		//System.out.println("\t>>>>> createFirstDiscussion() :: topic exists!!! : "+strParentId);
		IDfId dfId = new DfId(strParentId);
		ITopic topic = null;
		if (commentMgr.hasTopic("topic", dfId )) {
			//importDocLogger.info("\t>>>>> createFirstDiscussion() :: topic exists!!!");
			//System.out.println("\t>>>>> createFirstDiscussion() :: topic exists!!! : "+strParentId);
			topic = commentMgr.getTopic("topic", dfId );
		} else {
			//importDocLogger.info("\t>>>>> createFirstDiscussion() :: creating topic for the dfId : "+strParentId);
			//System.out.println("\t>>>>> createFirstDiscussion() :: creating topic for the dfId : "+strParentId);
			topic = commentMgr.createTopic("topic", dfId , true);
//			topic = commentMgr.getTopic("topic", dfId);
		}

		topic.setIsDisabled(false);

		// Create comment object - Start
		String commentId = createComment(msgVO, strParentId, topic);		

		// Creating child discussions - Start
		createRecursiveComments(msgVO.getMessageId(), commentId, topic);

		return commentId;
	}
	
	private static void createRecursiveComments(String parentMsgId, String parentMsgObjectId, ITopic topic) throws DfException{
		//importDocLogger.info("Inside createRecursiveComments(String parentMsgId, String parentMsgObjectId, ITopic topic)");
		String commentId = "";	
		for (int j=0;j<msgCount;j++){
			if (msgList[j].getParent().equalsIgnoreCase(parentMsgId)){		
				commentId = createComment(msgList[j], parentMsgObjectId, topic);
				//importDocLogger.info("\tCalling createRecursiveComments() on Message Id : "+msgList[j].getMessageId());
				//System.out.println("\tCalling createRecursiveComments() on Message Id : "+msgList[j].getMessageId());
				createRecursiveComments(msgList[j].getMessageId(), commentId, topic);
			}
		}
	}
	
	private static String createComment(MessageVO msgVO, String strObjectId, ITopic topic) throws DfException{
		
		//importDocLogger.info("Inside createComment(MessageVO msgVO, String strObjectId, ITopic topic)");
		IDfId parentCommentId = new DfId(strObjectId);
		IDfSysObject sysComment = (IDfSysObject) topic.createComment(parentCommentId);
		String commentId = sysComment.getObjectId().getId();	
		
		String subject = msgVO.getSubject();
		String createdDate = msgVO.getCreatedDate();
		String bodyValue = msgVO.getBodyValue();
		String fromValue = msgVO.getFrom();
		
		//importDocLogger.info("subject before trimming::"+subject.toString().trim());
		//subject = subject.replaceAll("<![CDATA[", "");
		//importDocLogger.info("subject before one trimming::"+subject.toString().trim());
		//subject = subject.replaceAll("]]>", "");
		//importDocLogger.info("subject::"+subject.toString().trim());
		sysComment.setTitle(subject.toString().trim());
		////System.out.println("Setting title on the document : "+msgVO.getSubject());
		sysComment.setObjectName(subject.toString().trim());
		
		IDfUser userName = (IDfUser) dfSession.getObjectByQualification("dm_user where (user_os_name like '%"+fromValue+"' or user_name='"+fromValue+"')");
		String uName = "";	
			if(userName == null){
				//importDocLogger.info("User Name is NULL");
				uName = dfSession.getLoginUserName().toString();
				//importDocLogger.info("New Value(user Name)::"+uName);
				//Updating the body value
				bodyValue = "("+fromValue+" is no longer in IFC address book and will not be available for further communication.)"+bodyValue;
				//importDocLogger.info("Updated body value::"+bodyValue);
			}else{
				//String uName = dfSession.getUserByOSName(value, "").getUserName();
				//importDocLogger.info("User Name is not NULL");
				//System.out.println("User Name::"+userName.getUserName());
				uName = userName.getUserName();
				//importDocLogger.info("User Name is::"+uName);
			}
			
		////System.out.println("User Name::"+uName);
		
		sysComment.setOwnerName(uName);
		
		//Formatting the date
		Date date = new Date(createdDate);
		Format formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a");
		createdDate = formatter.format(date);
		
		sysComment.setString("comment_creation_date", createdDate);
		//SysComment.setTime("r_creation_date",new DfTime(msgList[msgIndex].getCreatedDate(), ""));		
		IRichText richText = ((IComment) sysComment).getBody();
		
		//importDocLogger.info("Body Value ::"+bodyValue.toString().trim());
			
		richText.setContentAsText(bodyValue.toString().trim());
		////System.out.println("Setting body value on the docuemnt : "+msgVO.getBodyValue());
		sysComment.save();
		//importDocLogger.info("\tMessage Id : "+msgVO.getMessageId());
		//System.out.println("\tMessage Id : "+msgVO.getMessageId());
		//importDocLogger.info("\tMessage Object Id : "+commentId);
		//System.out.println("\tMessage Object Id : "+commentId);
		discussionsCreated++;
		return commentId;
	}
	
	/**
	 * getXMLTagValue method is used to get the value associated with tag in XML file.		
	 * @param FileName
	 * @param Root
	 * @param TagName
	 * @return String
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	public static void updateMessageVO(String fileName, String root) throws Exception{
		//importDocLogger.info("Inside updateMessageVO(String fileName, String root)");
		try {
			File file = new File(fileName);
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(file);

			doc.getDocumentElement().normalize();
			NodeList nodeLst = doc.getElementsByTagName(root);
			msgCount = nodeLst.getLength();
			msgList = new MessageVO[msgCount];

			for (int s = 0; s < msgCount; s++)			
			{
				Node fstNode = nodeLst.item(s);
				msgList[s] = new MessageVO();

				msgList[s].setMessageId(fstNode.getAttributes().item(0).getNodeValue());
				msgList[s].setParent(getElementValue(fstNode, "Parent"));
				msgList[s].setBodyValue(getElementValue(fstNode, "Body"));
				msgList[s].setCicValue(getElementValue(fstNode, "CIC"));
				msgList[s].setCreatedDate(getElementValue(fstNode,"CreatedDate"));
				msgList[s].setDomdocVersion(getElementValue(fstNode, "DomDocVersion"));
				msgList[s].setFrom(getElementValue(fstNode, "From"));
				msgList[s].setSubject(getElementValue(fstNode, "Subject"));

			} // End of for loop

			file = null;
		} catch (Exception e) {			
			throw e;
		}				  
	} // End of updateMessageVO()

	public static String getElementValue(Node messageNode, String nodeName){
		//importDocLogger.info("Inside getElementValue(Node messageNode, String nodeName)");
		String nodeValue = "";
		
		if (messageNode.getNodeType() == Node.ELEMENT_NODE)
			{
			  Element fstElmnt = (Element) messageNode;
			  NodeList fstNmElmntLst = fstElmnt.getElementsByTagName(nodeName);
			  Element fstNmElmnt = (Element) fstNmElmntLst.item(0);						 
			  NodeList fstNm = fstNmElmnt.getChildNodes();
			  if(((Node) fstNm.item(0))!=null){ 
				  nodeValue = ((Node) fstNm.item(0)).getNodeValue();							  
			  }
			  else 
				  nodeValue="Not Specified";
			}			
			////System.out.println("nodeValue : "+nodeValue);
		return nodeValue;
	} // End of getElementValue()
}
