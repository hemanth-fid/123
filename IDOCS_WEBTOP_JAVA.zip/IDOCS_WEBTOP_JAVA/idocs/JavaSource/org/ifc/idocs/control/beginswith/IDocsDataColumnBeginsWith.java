package org.ifc.idocs.control.beginswith;


import com.documentum.web.form.control.databound.DataProvider;

import com.documentum.web.form.control.databound.filter.DataColumnBeginsWith;
import com.documentum.web.form.control.databound.filter.DataFilterSpec;
import com.documentum.web.form.control.databound.filter.UnaryValueDataColumnFilter;



public class IDocsDataColumnBeginsWith extends DataColumnBeginsWith {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

		public IDocsDataColumnBeginsWith()
	    {
	    }

	    public UnaryValueDataColumnFilter getUnaryValueDataColumnFilter()
	    {
	  
	        UnaryValueDataColumnFilter filter = null;
	        DataProvider dataProvider = getDataProvider();
	        if(dataProvider != null)
	        {
	            DataFilterSpec datafilter = dataProvider.getDataFilterSpec();
	            filter = (UnaryValueDataColumnFilter)datafilter.getDataFilterItem(getName());
	            if(filter == null)
	            {
	            	
	            	filter = DataFilterSpec.createContainsFilter(getColumn(),null, getName());
	                datafilter.addDataFilterItem(filter);
	                setValue(getPrompt());
	                filter.setValue(getPrompt());
	                filter.setEnabled(false);
	            }
	     
	        }
	        return filter;
	    }
	  	    
}

    

   