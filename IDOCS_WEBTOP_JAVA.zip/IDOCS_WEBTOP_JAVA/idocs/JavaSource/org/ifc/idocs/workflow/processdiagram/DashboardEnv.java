/**
* This class displays the status of Document in workflow.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.workflow.processdiagram;

import java.util.HashMap;

 
public abstract class DashboardEnv
{
private static HashMap dEnv = new HashMap(2);
public static void initEnv()
  {
    dEnv = new HashMap(2); 
  }

  public static Object getKeyValue(String paramString)
  {
    return dEnv.get(paramString);
  }

  public static String getKeyValueAsString(String paramString)
  {
    return ((String)(String)dEnv.get(paramString));
  }
public static void setKeyValue(String paramString, Object paramObject)
  {
    dEnv.put(paramString, paramObject);
  }
}