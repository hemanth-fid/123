/**
 * 
 */
package gov.iwa.fema.export.dctm.utils;

import gov.iwa.fema.export.bean.FemaObjectBean;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfList;
import com.documentum.operations.IDfExportNode;
import com.documentum.operations.IDfExportOperation;
import com.documentum.operations.IDfOperationError;



public class DctmUtils {

	private static Logger log = Logger.getLogger(DctmUtils.class);

	public static boolean exportObject(IDfSession session, String objId,String fileExportFullPath) throws Exception {

		StringBuffer errors = new StringBuffer();
		boolean flag = false;
		
		try {
			
			IDfSysObject obj=(IDfSysObject)session.getObject(new DfId(objId));
			IDfClientX cx = new DfClientX();
			IDfExportOperation expOperation = cx.getExportOperation();

			IDfExportNode expNode = (IDfExportNode) expOperation.add(obj);
			expNode.setFilePath(fileExportFullPath);

			if (expOperation.execute()) {
				if (new File(fileExportFullPath).exists())
					flag = true;
				else {
					flag = false;
					throw new Exception(
							IUtilConstants.MSG_ERROR_FILE_DOES_NOT_EXIST_AFTER_EXPORT);
				}
			} else {
				IDfList errlist = expOperation.getErrors();
				for (int i = 0; i < errlist.getCount(); i++) {
					IDfOperationError errOperation = (IDfOperationError) errlist.get(i);
					errors.append(errOperation.getMessage()).append("\n");
				}
				flag = false;
				throw new Exception(errors.toString());
			}
		} catch (DfException dfe) {
			flag = false;
			throw new Exception(dfe.getMessage());
		}

		return flag;
	}
	
	public static FemaObjectBean createFemaObjectBean(String r_object_id,String invoice_no,String vendor_name,String department,String po_no) throws Exception{
		
		FemaObjectBean fobBean=null;
		
		
			fobBean=new FemaObjectBean();
			
			fobBean.setR_object_id(r_object_id);
			fobBean.setInvoice_no(invoice_no);
			fobBean.setVendor_name(vendor_name);
			fobBean.setDepartment(department);
			fobBean.setPo_no(po_no);

		return fobBean;
	}
	
	public static IDfCollection executeQuery(IDfSession session, String dql, int queryExecType) throws DfException {

		IDfCollection collection = null;
		IDfQuery query = null;

		try {
			query = new DfQuery();
			log.debug("The query is " + dql);
			query.setDQL(dql);
			collection = query.execute(session, queryExecType);
		} catch (DfException dfe) {
			log.error("Error while executing the query ", dfe);
			throw dfe;
		}
		return collection;

	}
	
	
	public static void closeCollection(IDfCollection collection) {

		if (collection != null && collection.getState() != IDfCollection.DF_CLOSED_STATE) {
			try {
				collection.close();
			} catch (DfException dfe) {
				log.warn("Error while closing the collection ", dfe);
			}
		}
	}
	
	
	public static String extractFileName(String filePath) throws Exception{
		
		
		String fileName=null;
		
		if(StringUtils.isNotBlank(filePath)){
			
			fileName=FilenameUtils.getBaseName(filePath);
		}
		
		return fileName;
	}

	public static boolean isFileShareValid(String fileSharePath) throws IOException,Exception { 
		
		if(StringUtils.isNotBlank(fileSharePath)){
			File folder = new File(fileSharePath);

			if(folder!=null && folder.isDirectory()) {
				return true;
			}

		}
		return false;
	}
	
	public static String getExceptionStack(Exception e) {
		String message = e.getMessage() + IUtilConstants.NEWLINE;
		message = message + getStackTraceElements(e.getStackTrace(), null);
		return message;
	}
	
	public static String getStackTraceElements(StackTraceElement[] stackElements, String delimiter) {

		String ret = IUtilConstants.EMPTYSTRING;
		for (StackTraceElement element : stackElements) {
			if (ret.length() > 0) {
				ret = ret + IUtilConstants.NEWLINE;
			}
			ret = ret + element.toString();
		}
		return ret;
	}
	
	public static String trimStringtoLength(String message,int length) {

		if (message != null && message.length() > length) {
			message = message.substring(0, length);
			
		}
		return message;
	}
	
	public static String escapeSpecialChars(String strMsg) {

		strMsg=strMsg.replace(IUtilConstants.SINGLE_QUOTE,IUtilConstants.DOUBLE_SINGLE_QUOTE);
		return strMsg;
	}
	
}
