package org.ifc.idocs.migration.extract;

import java.util.Collection;
import java.util.Vector;

import lotus.domino.NotesError;
import lotus.domino.NotesException;

import org.ifc.idocs.migration.common.AppConfig;

/**
 * @author SPankajamsadanan
 *
 */
public class MetadataTemplateFactory {

	private MetadataTemplateFactory(){}

	/**
	 * @param md
	 * @param name
	 */
	private static void addAttribute(Metadata md, String name) {
		if (name.endsWith("*"))
			md.put(name, new Vector<String>(100));	//name=metadata,nxt para=metadata.common.attribute in loop
		else 
			md.put(name, "");
	}

	/**
	 * createSubjectMetadata method
	 * @param subject
	 * @return Metadata
	 */
	@SuppressWarnings("unchecked")
	private static Metadata createSubjectMetadata(String subject) {
		Metadata md = new Metadata(100);
		AppConfig config = AppConfig.getInstance();
		Object obj = config.getProperty("metadata." + subject + ".attribute");
		if (obj != null) {
			if (obj instanceof Collection) {
				int size = ((Collection) obj).size();
				for (int i = 0; i < size; i++) {
					addAttribute(md, config.getString(new StringBuilder("metadata.").append(subject).append(".attribute(").append(i).append(")").toString()));
				}
			} else if (obj instanceof String) {
				addAttribute(md, config.getString(new StringBuilder("metadata.").append(subject).append(".attribute").toString()));
			}
		}
		return md;
	}

	/**
	 * createMetadataByFileroom method
	 * @param fileroom
	 * @param email
	 * @return Metadata
	 * @throws NotesException
	 */
	public static Metadata createMetadataByFileroom(String fileroom, Boolean email) throws NotesException {
		Metadata md = new Metadata(100);
		md.putAll(createSubjectMetadata("common"));
		if (fileroom.equals("PROJECTS")) {
			md.putAll(createSubjectMetadata("project"));
		} else if (fileroom.equals("INSTITUTIONS")) {
			md.putAll(createSubjectMetadata("institution"));
		} else if (fileroom.equals("MISCELLANEOUS")) {
			md.putAll(createSubjectMetadata("country"));
		} else { 
			throw new NotesException(NotesError.NOTES_ERR_ERROR, "Unexpected fileroom value");
		}

		if (email) {
			md.putAll(createSubjectMetadata("email"));
		}	
		return md;
	}

	/**
	 * createCommonFolderMetadata method
	 * @return Metadata
	 */
	public static Metadata createCommonFolderMetadata() {
		Metadata md = new Metadata(2);
		md.put("Fileroom", "");
		md.put("Folderkey", "");
		return md;	
	}

	/**
	 * createProjectFolderMetadata method
	 * @return Metadata
	 */
	public static Metadata createProjectFolderMetadata() {
		Metadata md = new Metadata(3);
		md.putAll(createCommonFolderMetadata());
		md.put("Project_id", "");
		return md;
	}

	/**
	 * createInstitutionFolderMetadata method
	 * @return Metadata
	 */
	public static Metadata createInstitutionFolderMetadata() {
		Metadata md = new Metadata(3);
		md.putAll(createCommonFolderMetadata());
		md.put("Institution_nbr", "");
		return md;
	}

	/**
	 * createCountryFolderMetadata method
	 * @return Metadata
	 */
	public static Metadata createCountryFolderMetadata() {
		Metadata md = new Metadata(3);
		md.putAll(createCommonFolderMetadata());
		md.put("Country_name_code", "");
		return md;	
	}

	/**
	 * createFolderMetadataByFileroom method
	 * @return Metadata
	 */
	public static Metadata createFolderMetadataByFileroom(String fileroom) throws NotesException {
		if (fileroom.equals("PROJECTS")) {
			return createProjectFolderMetadata();
		} else if (fileroom.equals("INSTITUTIONS")) {
			return createInstitutionFolderMetadata();
		} else if (fileroom.equals("MISCELLANEOUS")) {
			return createCountryFolderMetadata();
		} else { 
			throw new NotesException(NotesError.NOTES_ERR_ERROR, "Unexpected fileroom value");
		}
	}

	/**
	 * createEmailMetadata method
	 * @return Metadata
	 */
	public static Metadata createEmailMetadata() {
		Metadata md = new Metadata(5);
		md.putAll(createSubjectMetadata("email"));
		return md;
	}
}
