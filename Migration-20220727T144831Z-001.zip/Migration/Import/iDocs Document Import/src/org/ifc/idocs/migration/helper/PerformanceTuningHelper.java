package org.ifc.idocs.migration.helper;

import java.util.Calendar;

import org.ifc.idocs.migration.importUtility.ImportUtility;

public class PerformanceTuningHelper extends ImportUtility{

	/* Time will be printed to the console */
	public static int printCurrentTime(String location) {
	Calendar cal = Calendar.getInstance();
//	SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss.SSS");
	int runTime = (int) cal.getTimeInMillis();
	return runTime;
	}
}
