/**
 * PCHW070Out_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W;

public class PCHW070Out_Type  implements java.io.Serializable {
    private java.lang.String statusMsg;

    private java.lang.String MSGTEXT;

    private java.lang.String PRESFX;

    private java.lang.String RETURNMSG;

    private java.lang.String[] arrayOfTCITY;

    private java.lang.String[] arrayOfTCOUNTRY;

    private java.lang.String[] arrayOfTDBANAME;

    private java.lang.String[] arrayOfTPONUM;

    private java.lang.String[] arrayOfTPOTITLE;

    private java.lang.String[] arrayOfTSTATE;

    private java.lang.String[] arrayOfTSTATUS;

    private java.lang.String[] arrayOfTSTREET;

    private java.lang.String[] arrayOfTVENNO;

    private java.lang.String[] arrayOfTVENSFX;

    private java.lang.String[] arrayOfTZIPCODE;

    private java.lang.String VENSFXOT;

    public PCHW070Out_Type() {
    }

    public PCHW070Out_Type(
           java.lang.String statusMsg,
           java.lang.String MSGTEXT,
           java.lang.String PRESFX,
           java.lang.String RETURNMSG,
           java.lang.String[] arrayOfTCITY,
           java.lang.String[] arrayOfTCOUNTRY,
           java.lang.String[] arrayOfTDBANAME,
           java.lang.String[] arrayOfTPONUM,
           java.lang.String[] arrayOfTPOTITLE,
           java.lang.String[] arrayOfTSTATE,
           java.lang.String[] arrayOfTSTATUS,
           java.lang.String[] arrayOfTSTREET,
           java.lang.String[] arrayOfTVENNO,
           java.lang.String[] arrayOfTVENSFX,
           java.lang.String[] arrayOfTZIPCODE,
           java.lang.String VENSFXOT) {
           this.statusMsg = statusMsg;
           this.MSGTEXT = MSGTEXT;
           this.PRESFX = PRESFX;
           this.RETURNMSG = RETURNMSG;
           this.arrayOfTCITY = arrayOfTCITY;
           this.arrayOfTCOUNTRY = arrayOfTCOUNTRY;
           this.arrayOfTDBANAME = arrayOfTDBANAME;
           this.arrayOfTPONUM = arrayOfTPONUM;
           this.arrayOfTPOTITLE = arrayOfTPOTITLE;
           this.arrayOfTSTATE = arrayOfTSTATE;
           this.arrayOfTSTATUS = arrayOfTSTATUS;
           this.arrayOfTSTREET = arrayOfTSTREET;
           this.arrayOfTVENNO = arrayOfTVENNO;
           this.arrayOfTVENSFX = arrayOfTVENSFX;
           this.arrayOfTZIPCODE = arrayOfTZIPCODE;
           this.VENSFXOT = VENSFXOT;
    }


    /**
     * Gets the statusMsg value for this PCHW070Out_Type.
     * 
     * @return statusMsg
     */
    public java.lang.String getStatusMsg() {
        return statusMsg;
    }


    /**
     * Sets the statusMsg value for this PCHW070Out_Type.
     * 
     * @param statusMsg
     */
    public void setStatusMsg(java.lang.String statusMsg) {
        this.statusMsg = statusMsg;
    }


    /**
     * Gets the MSGTEXT value for this PCHW070Out_Type.
     * 
     * @return MSGTEXT
     */
    public java.lang.String getMSGTEXT() {
        return MSGTEXT;
    }


    /**
     * Sets the MSGTEXT value for this PCHW070Out_Type.
     * 
     * @param MSGTEXT
     */
    public void setMSGTEXT(java.lang.String MSGTEXT) {
        this.MSGTEXT = MSGTEXT;
    }


    /**
     * Gets the PRESFX value for this PCHW070Out_Type.
     * 
     * @return PRESFX
     */
    public java.lang.String getPRESFX() {
        return PRESFX;
    }


    /**
     * Sets the PRESFX value for this PCHW070Out_Type.
     * 
     * @param PRESFX
     */
    public void setPRESFX(java.lang.String PRESFX) {
        this.PRESFX = PRESFX;
    }


    /**
     * Gets the RETURNMSG value for this PCHW070Out_Type.
     * 
     * @return RETURNMSG
     */
    public java.lang.String getRETURNMSG() {
        return RETURNMSG;
    }


    /**
     * Sets the RETURNMSG value for this PCHW070Out_Type.
     * 
     * @param RETURNMSG
     */
    public void setRETURNMSG(java.lang.String RETURNMSG) {
        this.RETURNMSG = RETURNMSG;
    }


    /**
     * Gets the arrayOfTCITY value for this PCHW070Out_Type.
     * 
     * @return arrayOfTCITY
     */
    public java.lang.String[] getArrayOfTCITY() {
        return arrayOfTCITY;
    }


    /**
     * Sets the arrayOfTCITY value for this PCHW070Out_Type.
     * 
     * @param arrayOfTCITY
     */
    public void setArrayOfTCITY(java.lang.String[] arrayOfTCITY) {
        this.arrayOfTCITY = arrayOfTCITY;
    }


    /**
     * Gets the arrayOfTCOUNTRY value for this PCHW070Out_Type.
     * 
     * @return arrayOfTCOUNTRY
     */
    public java.lang.String[] getArrayOfTCOUNTRY() {
        return arrayOfTCOUNTRY;
    }


    /**
     * Sets the arrayOfTCOUNTRY value for this PCHW070Out_Type.
     * 
     * @param arrayOfTCOUNTRY
     */
    public void setArrayOfTCOUNTRY(java.lang.String[] arrayOfTCOUNTRY) {
        this.arrayOfTCOUNTRY = arrayOfTCOUNTRY;
    }


    /**
     * Gets the arrayOfTDBANAME value for this PCHW070Out_Type.
     * 
     * @return arrayOfTDBANAME
     */
    public java.lang.String[] getArrayOfTDBANAME() {
        return arrayOfTDBANAME;
    }


    /**
     * Sets the arrayOfTDBANAME value for this PCHW070Out_Type.
     * 
     * @param arrayOfTDBANAME
     */
    public void setArrayOfTDBANAME(java.lang.String[] arrayOfTDBANAME) {
        this.arrayOfTDBANAME = arrayOfTDBANAME;
    }


    /**
     * Gets the arrayOfTPONUM value for this PCHW070Out_Type.
     * 
     * @return arrayOfTPONUM
     */
    public java.lang.String[] getArrayOfTPONUM() {
        return arrayOfTPONUM;
    }


    /**
     * Sets the arrayOfTPONUM value for this PCHW070Out_Type.
     * 
     * @param arrayOfTPONUM
     */
    public void setArrayOfTPONUM(java.lang.String[] arrayOfTPONUM) {
        this.arrayOfTPONUM = arrayOfTPONUM;
    }


    /**
     * Gets the arrayOfTPOTITLE value for this PCHW070Out_Type.
     * 
     * @return arrayOfTPOTITLE
     */
    public java.lang.String[] getArrayOfTPOTITLE() {
        return arrayOfTPOTITLE;
    }


    /**
     * Sets the arrayOfTPOTITLE value for this PCHW070Out_Type.
     * 
     * @param arrayOfTPOTITLE
     */
    public void setArrayOfTPOTITLE(java.lang.String[] arrayOfTPOTITLE) {
        this.arrayOfTPOTITLE = arrayOfTPOTITLE;
    }


    /**
     * Gets the arrayOfTSTATE value for this PCHW070Out_Type.
     * 
     * @return arrayOfTSTATE
     */
    public java.lang.String[] getArrayOfTSTATE() {
        return arrayOfTSTATE;
    }


    /**
     * Sets the arrayOfTSTATE value for this PCHW070Out_Type.
     * 
     * @param arrayOfTSTATE
     */
    public void setArrayOfTSTATE(java.lang.String[] arrayOfTSTATE) {
        this.arrayOfTSTATE = arrayOfTSTATE;
    }


    /**
     * Gets the arrayOfTSTATUS value for this PCHW070Out_Type.
     * 
     * @return arrayOfTSTATUS
     */
    public java.lang.String[] getArrayOfTSTATUS() {
        return arrayOfTSTATUS;
    }


    /**
     * Sets the arrayOfTSTATUS value for this PCHW070Out_Type.
     * 
     * @param arrayOfTSTATUS
     */
    public void setArrayOfTSTATUS(java.lang.String[] arrayOfTSTATUS) {
        this.arrayOfTSTATUS = arrayOfTSTATUS;
    }


    /**
     * Gets the arrayOfTSTREET value for this PCHW070Out_Type.
     * 
     * @return arrayOfTSTREET
     */
    public java.lang.String[] getArrayOfTSTREET() {
        return arrayOfTSTREET;
    }


    /**
     * Sets the arrayOfTSTREET value for this PCHW070Out_Type.
     * 
     * @param arrayOfTSTREET
     */
    public void setArrayOfTSTREET(java.lang.String[] arrayOfTSTREET) {
        this.arrayOfTSTREET = arrayOfTSTREET;
    }


    /**
     * Gets the arrayOfTVENNO value for this PCHW070Out_Type.
     * 
     * @return arrayOfTVENNO
     */
    public java.lang.String[] getArrayOfTVENNO() {
        return arrayOfTVENNO;
    }


    /**
     * Sets the arrayOfTVENNO value for this PCHW070Out_Type.
     * 
     * @param arrayOfTVENNO
     */
    public void setArrayOfTVENNO(java.lang.String[] arrayOfTVENNO) {
        this.arrayOfTVENNO = arrayOfTVENNO;
    }


    /**
     * Gets the arrayOfTVENSFX value for this PCHW070Out_Type.
     * 
     * @return arrayOfTVENSFX
     */
    public java.lang.String[] getArrayOfTVENSFX() {
        return arrayOfTVENSFX;
    }


    /**
     * Sets the arrayOfTVENSFX value for this PCHW070Out_Type.
     * 
     * @param arrayOfTVENSFX
     */
    public void setArrayOfTVENSFX(java.lang.String[] arrayOfTVENSFX) {
        this.arrayOfTVENSFX = arrayOfTVENSFX;
    }


    /**
     * Gets the arrayOfTZIPCODE value for this PCHW070Out_Type.
     * 
     * @return arrayOfTZIPCODE
     */
    public java.lang.String[] getArrayOfTZIPCODE() {
        return arrayOfTZIPCODE;
    }


    /**
     * Sets the arrayOfTZIPCODE value for this PCHW070Out_Type.
     * 
     * @param arrayOfTZIPCODE
     */
    public void setArrayOfTZIPCODE(java.lang.String[] arrayOfTZIPCODE) {
        this.arrayOfTZIPCODE = arrayOfTZIPCODE;
    }


    /**
     * Gets the VENSFXOT value for this PCHW070Out_Type.
     * 
     * @return VENSFXOT
     */
    public java.lang.String getVENSFXOT() {
        return VENSFXOT;
    }


    /**
     * Sets the VENSFXOT value for this PCHW070Out_Type.
     * 
     * @param VENSFXOT
     */
    public void setVENSFXOT(java.lang.String VENSFXOT) {
        this.VENSFXOT = VENSFXOT;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PCHW070Out_Type)) return false;
        PCHW070Out_Type other = (PCHW070Out_Type) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.statusMsg==null && other.getStatusMsg()==null) || 
             (this.statusMsg!=null &&
              this.statusMsg.equals(other.getStatusMsg()))) &&
            ((this.MSGTEXT==null && other.getMSGTEXT()==null) || 
             (this.MSGTEXT!=null &&
              this.MSGTEXT.equals(other.getMSGTEXT()))) &&
            ((this.PRESFX==null && other.getPRESFX()==null) || 
             (this.PRESFX!=null &&
              this.PRESFX.equals(other.getPRESFX()))) &&
            ((this.RETURNMSG==null && other.getRETURNMSG()==null) || 
             (this.RETURNMSG!=null &&
              this.RETURNMSG.equals(other.getRETURNMSG()))) &&
            ((this.arrayOfTCITY==null && other.getArrayOfTCITY()==null) || 
             (this.arrayOfTCITY!=null &&
              java.util.Arrays.equals(this.arrayOfTCITY, other.getArrayOfTCITY()))) &&
            ((this.arrayOfTCOUNTRY==null && other.getArrayOfTCOUNTRY()==null) || 
             (this.arrayOfTCOUNTRY!=null &&
              java.util.Arrays.equals(this.arrayOfTCOUNTRY, other.getArrayOfTCOUNTRY()))) &&
            ((this.arrayOfTDBANAME==null && other.getArrayOfTDBANAME()==null) || 
             (this.arrayOfTDBANAME!=null &&
              java.util.Arrays.equals(this.arrayOfTDBANAME, other.getArrayOfTDBANAME()))) &&
            ((this.arrayOfTPONUM==null && other.getArrayOfTPONUM()==null) || 
             (this.arrayOfTPONUM!=null &&
              java.util.Arrays.equals(this.arrayOfTPONUM, other.getArrayOfTPONUM()))) &&
            ((this.arrayOfTPOTITLE==null && other.getArrayOfTPOTITLE()==null) || 
             (this.arrayOfTPOTITLE!=null &&
              java.util.Arrays.equals(this.arrayOfTPOTITLE, other.getArrayOfTPOTITLE()))) &&
            ((this.arrayOfTSTATE==null && other.getArrayOfTSTATE()==null) || 
             (this.arrayOfTSTATE!=null &&
              java.util.Arrays.equals(this.arrayOfTSTATE, other.getArrayOfTSTATE()))) &&
            ((this.arrayOfTSTATUS==null && other.getArrayOfTSTATUS()==null) || 
             (this.arrayOfTSTATUS!=null &&
              java.util.Arrays.equals(this.arrayOfTSTATUS, other.getArrayOfTSTATUS()))) &&
            ((this.arrayOfTSTREET==null && other.getArrayOfTSTREET()==null) || 
             (this.arrayOfTSTREET!=null &&
              java.util.Arrays.equals(this.arrayOfTSTREET, other.getArrayOfTSTREET()))) &&
            ((this.arrayOfTVENNO==null && other.getArrayOfTVENNO()==null) || 
             (this.arrayOfTVENNO!=null &&
              java.util.Arrays.equals(this.arrayOfTVENNO, other.getArrayOfTVENNO()))) &&
            ((this.arrayOfTVENSFX==null && other.getArrayOfTVENSFX()==null) || 
             (this.arrayOfTVENSFX!=null &&
              java.util.Arrays.equals(this.arrayOfTVENSFX, other.getArrayOfTVENSFX()))) &&
            ((this.arrayOfTZIPCODE==null && other.getArrayOfTZIPCODE()==null) || 
             (this.arrayOfTZIPCODE!=null &&
              java.util.Arrays.equals(this.arrayOfTZIPCODE, other.getArrayOfTZIPCODE()))) &&
            ((this.VENSFXOT==null && other.getVENSFXOT()==null) || 
             (this.VENSFXOT!=null &&
              this.VENSFXOT.equals(other.getVENSFXOT())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getStatusMsg() != null) {
            _hashCode += getStatusMsg().hashCode();
        }
        if (getMSGTEXT() != null) {
            _hashCode += getMSGTEXT().hashCode();
        }
        if (getPRESFX() != null) {
            _hashCode += getPRESFX().hashCode();
        }
        if (getRETURNMSG() != null) {
            _hashCode += getRETURNMSG().hashCode();
        }
        if (getArrayOfTCITY() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTCITY());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTCITY(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArrayOfTCOUNTRY() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTCOUNTRY());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTCOUNTRY(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArrayOfTDBANAME() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTDBANAME());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTDBANAME(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArrayOfTPONUM() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTPONUM());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTPONUM(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArrayOfTPOTITLE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTPOTITLE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTPOTITLE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArrayOfTSTATE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTSTATE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTSTATE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArrayOfTSTATUS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTSTATUS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTSTATUS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArrayOfTSTREET() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTSTREET());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTSTREET(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArrayOfTVENNO() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTVENNO());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTVENNO(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArrayOfTVENSFX() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTVENSFX());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTVENSFX(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArrayOfTZIPCODE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTZIPCODE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTZIPCODE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getVENSFXOT() != null) {
            _hashCode += getVENSFXOT().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PCHW070Out_Type.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "PCHW070Out_Type"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusMsg");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "StatusMsg"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSGTEXT");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "MSGTEXT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PRESFX");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "PRESFX"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RETURNMSG");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "RETURNMSG"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTCITY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "ArrayOfTCITY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "TCITY"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTCOUNTRY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "ArrayOfTCOUNTRY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "TCOUNTRY"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTDBANAME");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "ArrayOfTDBANAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "TDBANAME"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTPONUM");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "ArrayOfTPONUM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "TPONUM"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTPOTITLE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "ArrayOfTPOTITLE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "TPOTITLE"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTSTATE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "ArrayOfTSTATE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "TSTATE"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTSTATUS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "ArrayOfTSTATUS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "TSTATUS"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTSTREET");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "ArrayOfTSTREET"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "TSTREET"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTVENNO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "ArrayOfTVENNO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "TVENNO"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTVENSFX");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "ArrayOfTVENSFX"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "TVENSFX"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTZIPCODE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "ArrayOfTZIPCODE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "TZIPCODE"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("VENSFXOT");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "VENSFXOT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
