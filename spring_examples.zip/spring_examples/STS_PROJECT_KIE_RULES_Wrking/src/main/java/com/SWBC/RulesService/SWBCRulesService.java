package com.SWBC.RulesService;

import java.io.IOException;
import java.lang.reflect.Field;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.drools.core.base.RuleNameEndsWithAgendaFilter;
import org.drools.core.base.RuleNameEqualsAgendaFilter;
import org.drools.core.base.RuleNameMatchesAgendaFilter;
import org.drools.core.base.RuleNameStartsWithAgendaFilter;
import org.drools.core.command.runtime.rule.FireAllRulesCommand;
import org.drools.core.definitions.rule.impl.RuleImpl;
import org.drools.core.event.AfterActivationFiredEvent;
import org.drools.core.rule.Pattern;
import org.json.JSONObject;
import org.kie.api.definition.rule.Rule;
import org.kie.api.event.rule.AfterMatchFiredEvent;
import org.kie.api.event.rule.DefaultAgendaEventListener;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.StatelessKieSession;
import org.kie.api.runtime.rule.FactHandle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.stereotype.Service;

import com.SWBC.DataService.TrecService;
import com.SWBC.model.Brm_app_info;
import com.SWBC.model.Brm_app_json_info;
//import com.SWBC.model.Brm_app_json_info;
import com.SWBC.model.Brm_loan_info;
import com.SWBC.model.Brm_processing_info;
import com.SWBC.model.Brm_request_info;
import com.SWBC.model.Brm_rule;
import com.SWBC.model.Brm_rule_lookup_log;
import com.SWBC.model.Trec;
import com.SWBC.utilities.BRMUtilities;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

@Service
public class SWBCRulesService extends DefaultAgendaEventListener {

	private KieContainer kieContainer;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SetAPIAttributeValues setAPIAttributeValues;
	@Autowired
	private SetAPPAttributeValues setAPPAttributeValues;
	@Autowired
	private TrecService trecService;
	@Autowired
	private Trec trec;
	@Autowired
	private Environment env;

	@Autowired
	private ArrayList<String> getLoanLineTrecAttr;

	boolean isExitFlag = false;
	boolean isExceptionCase = false;
	boolean isCommentCase = false;

	@Autowired
	public SWBCRulesService(KieContainer kieContainer) {
		this.kieContainer = kieContainer;
	}

	public void getRulesOutput(Brm_request_info brm_request_info) {

		Map<String, KieSession> kieSessionMap = getSessionMap(brm_request_info.getRuleVersion());

		List<Brm_rule> myRuleList = null;

		List<Brm_processing_info> proc_info = null;
		String transactionType = brm_request_info.getTransType().trim();

		List<Brm_app_info> appinputRecords = null;

		KieSession kieSession = null;
		KieSession kieSession_comm = kieContainer.newKieSession("default_rulesSession");

		if (brm_request_info.getSource().equals("api")) {
			if (brm_request_info.getSingleAPITrec().equals("true")) {

				proc_info = trecService.getProcInfoSingleAPI(brm_request_info.getTid(), brm_request_info.getLoan_no(),
						brm_request_info.getLoan_suffix(), brm_request_info.getAcc_no(),
						brm_request_info.getCov_type());
			} else {
				proc_info = trecService.getProcInfo(brm_request_info.getTransType());
			}

			logger.debug("############### Total Records Picked:" + proc_info.size() + " #######################");
			try {
				for (int i = 0; i < proc_info.size(); i++) {

					isExitFlag = false;
					isExceptionCase = false;
					isCommentCase = false;

					myRuleList = trecService.getLogginhRuleList(proc_info.get(i).getTransaction_type());

					logger.debug("############### Processing Record:" + i + " for Transaction Type:"
							+ proc_info.get(i).getTransaction_type().trim() + " #######################");
					trecService.insertProcTbl(proc_info.get(i));
					List<Brm_loan_info> loan_info = trecService.getLoanInfo(proc_info.get(i));
					trecService.insertLoanTblData(loan_info);

					if (loan_info.get(0).getLoan_no().equalsIgnoreCase("NO_LOAN")) {
						continue;

					} else {

						trec = setAPIAttributeValues.checkTransType(proc_info.get(i).getTransaction_type().trim(),
								proc_info.get(i), loan_info, trecService, trec);

						kieSession = (KieSession) kieSessionMap.get(proc_info.get(i).getTransaction_type().trim());

						for (int j = 0; j < myRuleList.size(); j++) {

							Map<String, String> infer = new HashMap<String, String>();

							if (myRuleList.get(j).getRule_name().substring(0, 3).equalsIgnoreCase("CR_")) {

								executeRules(infer, kieSession_comm, myRuleList.get(j), brm_request_info, trec);
							}

							else {

								executeRules(infer, kieSession, myRuleList.get(j), brm_request_info, trec);

							}

						}

					}
				}

				if (!(kieSession == null)) {
					kieSession.dispose();
				}

				else {
					logger.debug("############### No Records to Process for " + transactionType
							+ " #######################");
				}

			} catch (Exception ex) {
//				logger.debug(
//						"############### evaluateRuleDRL() Exception:" + ex.getMessage() + " #######################");
				
				ex.printStackTrace();

			}

		}

		// BRM App xCP operation
		else

		{

			List<Trec> trecList = setAPPAttributeValues.setApp(trec, brm_request_info);

			if (!trecList.isEmpty()) {

				if (brm_request_info.getTransType().equalsIgnoreCase("NBSALL")) {
					myRuleList = trecService.getLogginhRuleList("NBS");
				} else {
					myRuleList = trecService.getLogginhRuleList(brm_request_info.getTransType());
				}

				try {
					for (int i = 0; i < trecList.size(); i++) {

						isExitFlag = false;
						isExceptionCase = false;
						isCommentCase = false;

						kieSession = (KieSession) kieSessionMap
								.get(brm_request_info.getTransType().equalsIgnoreCase("NBSALL") ? "NBS"
										: brm_request_info.getTransType());

						for (int j = 0; j < myRuleList.size(); j++) {

							Map<String, String> infer = new HashMap<String, String>();

							if (myRuleList.get(j).getRule_name().substring(0, 3).equalsIgnoreCase("CR_")) {

								executeRules(infer, kieSession_comm, myRuleList.get(j), brm_request_info,
										trecList.get(i));
							}

							else {

								executeRules(infer, kieSession, myRuleList.get(j), brm_request_info, trecList.get(i));
							}

						}

					}

					if (!(kieSession == null)) {
						kieSession.dispose();
					}

					else {
						logger.debug("############### No Records to Process for " + transactionType
								+ " #######################");
					}

				} catch (Exception ex) {
//					logger.debug("############### evaluateRuleDRL() Exception:" + ex.getMessage()
//							+ " #######################");
					ex.printStackTrace();

				}
			}

		}

	}

	public void executeRules(Map<String, String> infer, KieSession kieSession_comm, Brm_rule myRuleList,
			Brm_request_info brm_request_info, Trec trec) throws JsonProcessingException {

		// JSONObject json = new JSONObject();

		ObjectMapper json = new ObjectMapper();
		// json.enable(SerializationFeature.INDENT_OUTPUT);

		//Map<String, String> logMap = new TreeMap<String, String>();
		
		JSONObject logMap = new JSONObject();

		ObjectMapper paramMapJson = new ObjectMapper();
		// paramMapJson.enable(SerializationFeature.INDENT_OUTPUT);
		ObjectMapper paramMap = new ObjectMapper();
		// paramMap.enable(SerializationFeature.INDENT_OUTPUT);

		ExpressionParser parser = new SpelExpressionParser();

		Date dNow = new Date();
		SimpleDateFormat ft = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
		boolean islookup = Boolean.parseBoolean(brm_request_info.getEnableLookup());

		trec.setPolicyCancelReasonList(trecService.getPolicyCancelReason());
		trec.setTransactionInsurerList(trecService.getTransactionInsurer());

		infer = getParamList(kieSession_comm, myRuleList, trec, paramMap, paramMapJson, parser);
		RuleNameEqualsAgendaFilter rn_comm = new RuleNameEqualsAgendaFilter(myRuleList.getRule_name().trim());

	
		
		ObjectMapper mapper = new ObjectMapper();
		Object jsonParam = null;
		try {
			jsonParam = mapper.readValue(infer.get("paramList"), Object.class);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		logMap.put("Parameters", new JSONObject(infer.get("paramList")));
		//logMap.put("Parameters", jsonParam.toString());
		//logMap.put("Parameters", infer.get("paramList").toString().substring(1, infer.get("paramList").toString().length()-1));

		logMap.put("rule", infer.get("pattern"));
		logMap.put("ruleName", myRuleList.getRule_name().trim());

		FactHandle handle_comm = kieSession_comm.insert(trec);
		kieSession_comm.insert(trec);

		if (kieSession_comm.fireAllRules(rn_comm) != 0) {

			logMap.put("time stamp", ft.format(dNow));

			if (myRuleList.getRule_outcome().equalsIgnoreCase("CONTINUE")) {

			}

			else if (myRuleList.getRule_outcome().equalsIgnoreCase("EXCEPTION") && isCommentCase == false
					&& isExitFlag == false) {

				isExceptionCase = true;

				trecService.insertLogTbl(trec.getTransaction_id(), trec.getTransaction_type(), infer.get("paramList"),
						myRuleList.getRule_name(), myRuleList.getRule_outcome().toString(),
						myRuleList.getRule_msg().toString(), brm_request_info.getUser(), trec.getTransaction_cov_type(),
						trec.getAccount_no(), trec.getLoanNo(), trec.getTransactionSuffix(),
						trec.getPolicyNumberScore(), brm_request_info.getSource(), "main",
						logMap.toString());
						
						//json.writeValueAsString(logMap)

				// json.writeValueAsString(logMap)

			} else if (myRuleList.getRule_outcome().equalsIgnoreCase("COMMENT") && isExceptionCase == false
					&& isExitFlag == false) {

				isCommentCase = true;
				isExitFlag = true;

				trecService.insertLogTbl(trec.getTransaction_id(), trec.getTransaction_type(), infer.get("paramList"),
						myRuleList.getRule_name(), myRuleList.getRule_outcome().toString(),
						myRuleList.getRule_msg().toString(), brm_request_info.getUser(), trec.getTransaction_cov_type(),
						trec.getAccount_no(), trec.getLoanNo(), trec.getTransactionSuffix(),
						trec.getPolicyNumberScore(), brm_request_info.getSource(), "main",
						logMap.toString());

				return;

			} else if (myRuleList.getRule_outcome().equalsIgnoreCase("UPDATE") && isExceptionCase == false
					&& isCommentCase == false) {

				isExitFlag = true;

				trecService.insertLogTbl(trec.getTransaction_id(), trec.getTransaction_type(), infer.get("paramList"),
						myRuleList.getRule_name(), myRuleList.getRule_outcome().toString(),
						myRuleList.getRule_msg().toString(), brm_request_info.getUser(), trec.getTransaction_cov_type(),
						trec.getAccount_no(), trec.getLoanNo(), trec.getTransactionSuffix(),
						trec.getPolicyNumberScore(), brm_request_info.getSource(), "main",
						logMap.toString());

				return;

			}

		} else {

			if (islookup) {

				logMap.put("time stamp", ft.format(dNow));

				trecService.insertLogTbl(trec.getTransaction_id(), trec.getTransaction_type(), infer.get("paramList"),
						myRuleList.getRule_name(), "SKIPPED", myRuleList.getRule_msg().toString(), brm_request_info.getUser(),
						trec.getTransaction_cov_type(), trec.getAccount_no(), trec.getLoanNo(),
						trec.getTransactionSuffix(), trec.getPolicyNumberScore(), brm_request_info.getSource(), "main",
						logMap.toString());
			}

		}

		kieSession_comm.delete(handle_comm);

	}

	public Map<String, String> getParamList(KieSession kieSession3, Brm_rule brm_rule, Trec trec, ObjectMapper paramMap,
			ObjectMapper paramMapJson, ExpressionParser parser) {

		Map<String, String> tempMap = new TreeMap<String, String>();

		Map<String, String> paramSortedMap = new TreeMap<String, String>();

		if (brm_rule.getRule_outcome().equalsIgnoreCase("UPDATE")) {
			EvaluationContext eContext = new StandardEvaluationContext(trec);

			for (String string : getLoanLineTrecAttr) {

				Expression exp = parser.parseExpression(string);
				
				paramSortedMap.put(string.toString(), exp.getValue(eContext, String.class).toString());
				// paramMapJson.put(string, exp.getValue(eContext,
				// String.class));

			}
			try {
				tempMap.put("paramList", paramMap.writeValueAsString(paramSortedMap).toString());
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else {

			RuleImpl ri = (RuleImpl) kieSession3.getKieBase().getRule("rules", brm_rule.getRule_name());

			

			Pattern rce = (Pattern) ri.getLhs().getChildren().get(0);

			tempMap.put("pattern", rce.getConstraints().toString());

			EvaluationContext eContext = new StandardEvaluationContext(trec);

			for (Field attr : new Trec().getClass().getDeclaredFields()) {

				try {

					if (rce.getConstraints().toString().contains(attr.getName())) {
						Expression exp = parser.parseExpression(attr.getName());
						
						paramSortedMap.put(attr.getName().toString(), exp.getValue(eContext, String.class).toString());
					

					}

				} catch (Exception e) {

					e.printStackTrace();
				}

			}

			try {
				tempMap.put("paramList", paramMap.writeValueAsString(paramSortedMap).toString());
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return tempMap;

	}

	public Map<String, KieSession> getSessionMap(String ruleVersion) {
		List<String> reqList = new ArrayList<String>();

		Map<String, KieSession> sessionMap = new HashMap();

		String[] tempArr = env.getRequiredProperty("select.transaction.types").split(",");

		for (int i = 0; i < tempArr.length; i++) {
			sessionMap.put(tempArr[i].trim(),
					kieContainer.newKieSession(BRMUtilities.getKIESessionName(ruleVersion, tempArr[i].trim())));
		}

		return sessionMap;
	}

	public void releaseKIE(Map sessionMap) {
		KieSession session = null;

		String[] tempArr = env.getRequiredProperty("select.transaction.types").split(",");

		for (int i = 0; i < tempArr.length; i++) {
			session = (KieSession) sessionMap.get(tempArr[i]);
			session.dispose();
		}

	}

	public Brm_app_json_info getJsonApp(String dbId) {

		Brm_app_json_info obj = new Brm_app_json_info();
		
		return obj = trecService.getJSONOutput(dbId);

	}
	
	public String getTestRule(Brm_request_info brm_request_info) {

		Brm_app_json_info obj = new Brm_app_json_info();
		
		
		Map<String, KieSession> kieSessionMap = getSessionMap(brm_request_info.getRuleVersion());

		List<Brm_rule> myRuleList = null;

		List<Brm_processing_info> proc_info = null;
		String transactionType = brm_request_info.getTransType().trim();

		List<Brm_app_info> appinputRecords = null;

		KieSession kieSession = null;
		KieSession kieSession_comm = kieContainer.newKieSession("default_rulesSession");
		
		
		proc_info = trecService.getProcInfoSingleAPI(brm_request_info.getTid(), brm_request_info.getLoan_no(),
				brm_request_info.getLoan_suffix(), brm_request_info.getAcc_no(),
				brm_request_info.getCov_type());
		
		List<Brm_loan_info> loan_info = trecService.getLoanInfo(proc_info.get(0));
		
		myRuleList = trecService.getSingleRuleList(brm_request_info.getSingleAPITrec());
		Map<String, String> infer = new HashMap<String, String>();
		
		
		trec = setAPIAttributeValues.checkTransType(proc_info.get(0).getTransaction_type().trim(),
				proc_info.get(0), loan_info, trecService, trec);

		kieSession = (KieSession) kieSessionMap.get(proc_info.get(0).getTransaction_type().trim());
		
		
	
		ObjectMapper json = new ObjectMapper();
		// json.enable(SerializationFeature.INDENT_OUTPUT);

		//Map<String, String> logMap = new TreeMap<String, String>();
		
		JSONObject logMap = new JSONObject();

		ObjectMapper paramMapJson = new ObjectMapper();
		// paramMapJson.enable(SerializationFeature.INDENT_OUTPUT);
		ObjectMapper paramMap = new ObjectMapper();
		// paramMap.enable(SerializationFeature.INDENT_OUTPUT);

		ExpressionParser parser = new SpelExpressionParser();

		Date dNow = new Date();
		SimpleDateFormat ft = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
		boolean islookup = Boolean.parseBoolean(brm_request_info.getEnableLookup());

		trec.setPolicyCancelReasonList(trecService.getPolicyCancelReason());
		trec.setTransactionInsurerList(trecService.getTransactionInsurer());

		if (myRuleList.get(0).getRule_name().substring(0, 3).equalsIgnoreCase("CR_"))
		{
			infer = getParamList(kieSession_comm, myRuleList.get(0), trec, paramMap, paramMapJson, parser);
		}
		else
		{
			infer = getParamList(kieSession, myRuleList.get(0), trec, paramMap, paramMapJson, parser);
		}
		
		
		
	
		logMap.put("Parameters", new JSONObject(infer.get("paramList")));
		//logMap.put("Parameters", jsonParam.toString());
		//logMap.put("Parameters", infer.get("paramList").toString().substring(1, infer.get("paramList").toString().length()-1));

		logMap.put("rule", infer.get("pattern"));
		logMap.put("ruleName", myRuleList.get(0).getRule_name().trim());
		
		
		return logMap.toString();

	}
	
	
	
}