/**
* The class is provided to add a new child document from the file selector to a virtual document.
*
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created
* #######################################################################################################
*/

package org.ifc.idocs.library.vdm.addcomponent;

import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.*;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.LocaleService;

public class AddVirtualDocumentNodeFromFileSelector extends com.documentum.webcomponent.library.vdm.addcomponent.AddVirtualDocumentNodeFromFileSelector
{
    private static String m_addVirtualDocumentNlsProp;
    private static String m_folderId;
	private static NlsResourceBundle m_nlsResourceBundle;
	
    public AddVirtualDocumentNodeFromFileSelector()
    {
    }

    public void onInit(ArgumentList arg)
    {
        try {
        	super.onInit(arg);
	        DfLogger.info(this," :: onInit : "+getDfSession().getLoginUserName(), null, null);
	        String objectIdArg = arg.get("objectId");
	        m_folderId=updateFolderDetails(objectIdArg);
	        arg.add("folderId",m_folderId);
	        arg.add("multiselect", "true");
	        arg.add("vdmRootObjectId", objectIdArg);
	        setComponentNested("addchildsysobjectlocatorcontainer", arg, getContext(), this);
        } catch(Exception e) {
        	DfLogger.error(this, " :: onInit Exception >> "+e.getMessage(), null, e);
        }
    }

    private String updateFolderDetails(String objectIdArg) {
        IDfSession dfsess = getDfSession();
        String folderId="";
		try {
			DfLogger.info(this," :: updateFolderDetails : "+getDfSession().getLoginUserName(), null, null);
	        IDfDocument newDoc = (IDfDocument)getDfSession().getObject(new DfId(objectIdArg));
	        IDfFolder docFolder = (IDfFolder)dfsess.getObject(newDoc.getFolderId(0));
	        IDfFolder parentFolder;
			if(docFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_PROJ_FOLDER", LocaleService.getLocale())) || docFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_INSTIT_FOLDER", LocaleService.getLocale())) || docFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_COUNTRY_FOLDER", LocaleService.getLocale())))
	        {
		        parentFolder = docFolder;
	        }
	        else
	        {
		        docFolder = (IDfFolder)dfsess.getObject(docFolder.getFolderId(0));
		        if(docFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_PROJ_FOLDER", LocaleService.getLocale())) || docFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_INSTIT_FOLDER", LocaleService.getLocale())) || docFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_COUNTRY_FOLDER", LocaleService.getLocale())))
		        {
		        	parentFolder = docFolder;
		        }
		        else
		        {
		        	parentFolder=(IDfFolder)dfsess.getObject(docFolder.getFolderId(0));
		        }
	        }
			folderId = parentFolder.getObjectId().getId();
		} catch (DfException e) {
			DfLogger.error(this," :: updateFolderDetails Exception>> "+e.getMessage(),null,e);
		}
		DfLogger.info(this," :: updateFolderDetails : folderId : "+folderId, null, null);
		return folderId;
	}
    static
    {
        m_addVirtualDocumentNlsProp = "org.ifc.idocs.vdm.addcomponent.AddVirtualDocumentNodeNlsProp";
        m_nlsResourceBundle = new NlsResourceBundle(m_addVirtualDocumentNlsProp);
    }
}
