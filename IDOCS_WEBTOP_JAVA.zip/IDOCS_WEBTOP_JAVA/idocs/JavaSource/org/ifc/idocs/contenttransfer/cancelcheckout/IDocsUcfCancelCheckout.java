package org.ifc.idocs.contenttransfer.cancelcheckout;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.docbase.ObjectCacheUtil;
import com.documentum.webcomponent.library.contenttransfer.cancelcheckout.UcfCancelCheckout;

public class IDocsUcfCancelCheckout extends UcfCancelCheckout {

	private static final String UNDERSCORE = "_";
	private static final String PRODUCT_WF_NBR = "product_wf_nbr";
	private static final String BLANK_STRING = "";
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String messageId="MSG_OPERATION_SUCCESSFUL";
	private String failedDocObjectName = null;
	
	public boolean onCommitChanges() {
		String asServletURL = null;
		String strServletURL = null;
		 try {
			 
			IDfDocument docObject = (IDfDocument)ObjectCacheUtil.getObject(getDfSession(),getObjectId());
			if(docObject.findString(IDocsConstants.MSG_R_VERSION_LABEL,IDocsConstants.MSG_INITIALVERSION_LABEL) != -1){
                DfLogger.debug(this, " : Document Is An Initial Version ", null, null);
				
				String objectType = docObject.getString(IDocsConstants.MSG_R_OBJECT_TYPE);
                if(objectType != null && objectType.trim().length() > 0
                		&& objectType.equals(IDocsConstants.MSG_IDOCS_PROJECT_DOC)){
                    String strTemplateName = null;
                    String strDocName = docObject.getObjectName();
                    if(strDocName.indexOf(UNDERSCORE) != -1){
                        strTemplateName = strDocName.substring(strDocName.indexOf(UNDERSCORE) + 1);
                    }
                    
                    IdocsUtil idocsUtil = new IdocsUtil();
                    int pdtWfTypeCode = idocsUtil.getProductTypeCode(getDfSession(), strTemplateName);
                    String strPdtWfNbr = docObject.getString(PRODUCT_WF_NBR);
                    if(IdocsUtil.ifProductIntegrationRequired(strTemplateName) && strPdtWfNbr != null && !BLANK_STRING.equals(strPdtWfNbr)){
                        strServletURL = IdocsUtil.buildServletURL((Component)this, getDfSession(), docObject, strPdtWfNbr, String.valueOf(pdtWfTypeCode), getPageContext(),true);
                        DfLogger.debug(this, (new StringBuilder(" :: This is an Initial version Of Product Template. Cannot Cancel Checkout : ")).toString(), null, null);
                        setObjectId(BLANK_STRING);
                        setFailedObjectName(strDocName);
        				setFailureMessageId();
                    }

    				/*
    				 * This is code has been added for Advisory Services
    				 * CODE : START
    				 */
//    				try {
//    					if(("Advisory Services").equals(docObject.getString("doc_category"))){
//    						DfLogger.debug(this, (new StringBuilder(" :: Advisory Services : Calling Servlet : ")).toString(), null, null);
//    						asServletURL = IdocsUtil.asBuildServletURL(docObject, strTemplateName, getDfSession(),);
//    						DfLogger.debug(this, (new StringBuilder(" ::  Servlet URL :::: ")).append(asServletURL).toString(), null, null);
//    						DfLogger.debug(this, (new StringBuilder(" :: Advisory Services : Servlet Executed  : ")).toString(), null, null);
//    					}
//    				} catch (Exception e) {
//    					DfLogger.error(this, (new StringBuilder(" ::  Exception occured in executing Servlet>> ")).append(e.getMessage()).toString(), null, e);
//    				}

    				/*
    				 * CODE : END 
    				 */
                }
                
			}
			
		} catch (DfException e) {
			DfLogger.error(this, " : Update IDESK on Cancel Check Out Failed", null, null);
		}
		if(super.onCommitChanges() == true){
		    try {
		    	if(strServletURL != null && strServletURL.trim().length() > 0){
		    		IdocsUtil.buildAndExecuteServlet(strServletURL);
		    		/** AS Team has not Confirmed to Do this while Cancel Checkout.*/
//				    IdocsUtil.buildAndExecuteServlet(asServletURL);
		    		DfLogger.debug(this, " : Update IDESK on Cancel Check Out Done.", null, null);
		    	}else{
		    		DfLogger.debug(this, " : Update IDESK on Cancel Check Out is not required as its not a Product Template", null, null);
		    	}
			} catch (Exception e) {
				DfLogger.error(this, " : Update IDESK on Cancel Check Out Failed", null, null);
				e.printStackTrace();
			}
			return true;
		}else{
			return false;
		}
	}

	private void setFailedObjectName(String strDocName) {
		failedDocObjectName = strDocName;
		
	}

	private void setFailureMessageId() {
		messageId = "MSG_OPERATION_NOT_ALLOWED_PDT_WF_LOSS";
		
	}
	
	public String getFailureMessageId() {
		return messageId;
	}
	
	public String getFailedObjectName() {
		return failedDocObjectName;
	}
}
