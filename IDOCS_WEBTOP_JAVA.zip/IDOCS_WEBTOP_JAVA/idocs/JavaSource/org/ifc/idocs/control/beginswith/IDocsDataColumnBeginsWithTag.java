package org.ifc.idocs.control.beginswith;

import com.documentum.web.form.control.databound.filter.DataColumnBeginsWith;


public class IDocsDataColumnBeginsWithTag extends com.documentum.web.form.control.databound.filter.DataColumnBeginsWithTag {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    
	 public IDocsDataColumnBeginsWithTag()
	    {
	    }
	 
	    protected Class getControlClass()
	    {
	        if(getFullTextStatus())
	        	return org.ifc.idocs.control.beginswith.IDocsDataColumnBeginsWith.class;
	        else 
	            return DataColumnBeginsWith.class;
	    }
	    
	    public boolean getFullTextStatus()
	    {
	        return m_strFullTextStatus;
	    }

	    public void setFullTextStatus(boolean fullTextStatus)
	    {
	    	
	    	m_strFullTextStatus = fullTextStatus;
	    }
	    public static boolean  m_strFullTextStatus=false; 
  }
 