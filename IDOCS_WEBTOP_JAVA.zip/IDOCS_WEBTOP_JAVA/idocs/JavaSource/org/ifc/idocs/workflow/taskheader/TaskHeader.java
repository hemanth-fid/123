/**
* 
* This class
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.workflow.taskheader;

import com.documentum.fc.client.IDfWorkflow;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.services.workflow.inbox.ITask;
import com.documentum.services.workflow.inbox.IWorkflowTask;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.Label;
import com.documentum.webcomponent.library.workflow.taskmanager.ITaskStateContainer;

public class TaskHeader extends	com.documentum.webcomponent.library.workflow.taskheader.TaskHeader {
	private static final long serialVersionUID = 1L;

	public TaskHeader() {
	}

    public void onInit(ArgumentList arg)
    {
        super.onInit(arg);
        String taskId = arg.get("objectId");
        try
        {
        	DfLogger.info(this, " :: onInit : "+getDfSession().getLoginUserName(), null, null);
            boolean isProcess = taskId.startsWith(Integer.toHexString(75));
            if(isProcess)
            {
                updateControlsProcess();
            } else
            {
                updateControlsTask();
            }
        }
        catch(DfException e)
        {
            DfLogger.error(this, " :: onInit : Exception >> "+e.getMessage(), null, e);
        }
    }

    protected void updateControlsTask()
    {
    	try 
    	{
			super.updateControlsTask();
	        ITask task = getInboxTask();
	        int taskType = task.getType();
	        if(taskType == 4)
	        {
		        Label labelDescr = (Label)getControl(TASK_DESCR_CONTROL_NAME);
	            IWorkflowTask wtask = (IWorkflowTask)task;
	            IDfWorkflow wf = (IDfWorkflow) getDfSession().getObject(wtask.getWorkflowId());
	            String processName = getDfSession().getObject(wf.getProcessId()).getString("object_name");
	            String startDate = getDfSession().getObject(wtask.getWorkflowId()).getString("r_start_date");
	            DfLogger.info(this, " :: updateControlsTask : processName : "+processName+" : startDate : "+startDate, null, null);
	            labelDescr.setLabel(processName+" Date: "+startDate);
	        }
		}
    	catch (DfException e) 
    	{
    		DfLogger.error(this, " :: updateControlsTask Exception >> "+e.getMessage(), null, e);
		}
    }

    private ITask getInboxTask()
    {
        return ((ITaskStateContainer)getTopForm()).getTaskState();
    }
}
