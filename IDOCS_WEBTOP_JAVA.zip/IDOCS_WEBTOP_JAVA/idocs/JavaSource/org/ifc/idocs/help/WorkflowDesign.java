/**
* The custom class is used to get list of workflows 
* and its corresponding design to display in workflowdesign jsp.
* 
* #######################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################
* Parag Doshi 			11/12/2010		1.0				created
* #######################################################################
*/
package org.ifc.idocs.help;


import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.Button;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.formext.component.Component;

public class WorkflowDesign extends Component
{
	private static final long serialVersionUID = 1L;
	
    public WorkflowDesign()
    {
    }

    public void onInit(){
		try {
			DfLogger.info(this, " :: onInit : "+getDfSession().getLoginUserName(), null, null);
		} catch (DfException e) {
			DfLogger.error(this, " :: onInit Exception >> "+e.getMessage(), null, e);
		}
    }

    public void onRender()
    {
        Datagrid datagrid = null;
        try{
			DfLogger.info(this, " :: onRender : "+getDfSession().getLoginUserName(), null, null);
		        datagrid = (Datagrid)getControl("mygrid", Datagrid.class);
        }catch(Exception ex){
            DfLogger.info(this," :: onRender : Creating a new Datagrid Control",null,null);
            if(datagrid == null){
                datagrid = (Datagrid)createControl("mygrid", Datagrid.class);
            }
        }
        datagrid.getDataProvider().setDfSession(getDfSession());
        datagrid.getDataProvider().setQuery(IdocsUtil.getMessage("QUERY_OBJECT_DETAILS"));        
    }

    public void onClose(Button control, ArgumentList args){
        setComponentReturn();
    }
}
