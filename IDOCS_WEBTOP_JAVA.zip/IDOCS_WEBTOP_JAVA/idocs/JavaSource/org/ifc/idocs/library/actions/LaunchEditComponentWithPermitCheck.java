/**
* This class to check the permissions for the component to validate.
* #######################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################
*/
package org.ifc.idocs.library.actions;

import java.util.HashMap;
import java.util.Map;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.ErrorMessageService;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

public class LaunchEditComponentWithPermitCheck extends
		com.documentum.web.formext.action.LaunchComponentWithPermitCheck {

	private static final long serialVersionUID = 1L;
    private static final NlsResourceBundle s_lookup = new NlsResourceBundle("org.ifc.idocs.action.ValidateGroupMembershipNlsProp");
	private static final String MSG_EDITED = "Checked Out";
	String accessRole = null;
	boolean isWorkflowRestartable;
	private String documentAspectType = null;
	
	private String strObjectType = null;
	private String strDocumentState = null;
	private String strOwnerName = null;
	private String strObjectName = null;
	private String templateCode = null;
	private String isWorkflowRequired = null;
	private String STR_REPLACE_OBJECT_ID="<objectId>"; 

	
	public String[] getRequiredParams(){
    	DfLogger.info(this, " :: LaunchEditComponent : getRequiredParams ",null,null);
        return (new String[] {
            "objectId"
        });
    }
    
	/**
	 * This method is called both from Edit Document and from DRL.
	 * this two routes are specifically handled in the code.
	 * Input strAction shall be used to distinguish this
	 *  if(strAction !=null){  --> THis is coming from Edit Component
	 *  						For Success - return super.execute(strAction, config, args, context, component, completionArgs);
	 *  						For Failure -  Set the Exception ErrorMessageService and return false.
	 *  
	 *  if(strAction ==null) --> This is called from DRL Component
	 *  						For Success - return true
	 *  						For Failure - return false
	 *  
	 */
	public boolean execute(String strAction, IConfigElement config, 
			ArgumentList args, Context context, Component component, Map completionArgs){
		
		String strObjectId = args.get("objectId");
		String isEditAfterNew=args.get("isEditAfterNew");
		if(isEditAfterNew != null && isEditAfterNew.trim().length() >0 && isEditAfterNew.equalsIgnoreCase("yes")){
			/** Document Create Newly So No Need of any additional Checks */
			DfLogger.info(this, " :: execute : request is from New Doc Creation",null,null);
			return super.execute(strAction, config, args, context, component, completionArgs);
		}else{
			setRequiredAttributes(strObjectId, component.getDfSession());
			DfLogger.info(this, " :: execute : component ID :"+component.getComponentId(),null,null);
			if(IdocsUtil.MSG_TASK_ATTACHMENT_COMPONENT_ID.equalsIgnoreCase(component.getComponentId())){
				DfLogger.info(this, " :: LaunchEditComponent : ALLOWED : This is from Workflow Task :",null,null);
				return super.execute(strAction, config, args, context, component, completionArgs);
			}else{
				DfLogger.info(this, " :: execute : This is Not from Workflow Task : Continue With further tests",null,null);
			}
			
			DfLogger.info(this, " :: execute : Object ID "+strObjectId,null,null);
			boolean validated = false;
			try{
				if(strObjectId != null && strObjectId.trim().length()>0 && strObjectId.startsWith(IDocsConstants.MSG_DM_DOC_TYPE_PREF_CODE)){
					if(strObjectType == null && strObjectName == null && strDocumentState == null && strOwnerName == null
							&& !(strObjectType.trim().length() == 0) && !(strObjectName.trim().length() == 0) 
							&& !(strDocumentState.trim().length() == 0)
							&& !(strOwnerName.trim().length() == 0)){
								setRequiredAttributes(strObjectId, component.getDfSession());
							}
					if(currentVersionCheck(strObjectId,component.getDfSession())==false){
						if(strAction !=null){
							DfLogger.info(this, " :: execute : currentVersionCheck : From Action : "+strAction, null, null);
					        ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_NOT_CURRENT_VERSION_ACTION_DENIED", component, new String[]{"Edit",strObjectName,IdocsUtil.handleLDAPEnvVariable(accessRole, component.getDfSession())}, null);
					        return false;
						}else{
							DfLogger.info(this, " :: execute : currentVersionCheck : From DRL : ", null, null);
							return false;
						}
					}
					
					/** SKIP IOM checks and allow only owner_name to Edit if its tried from Object list not from Task */
					String templateName = IdocsUtil.getTemplateTitle(component.getDfSession(), strObjectId);
					if(IdocsUtil.getMessage("MSG_INTERNAL_OFFICE_MEMORANDUM").equals(templateName)){
						if(strOwnerName.equalsIgnoreCase(component.getDfSession().getLoginUserName())== true){
							if(strDocumentState!=null && strDocumentState.equalsIgnoreCase(IdocsConstants.DOC_STATE_RELEASED)){
								if(strAction !=null){
									ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_RELEASED_ACTION_DENIED", component, new String[]{"Edit",strObjectName}, null);
									return false;
								}else{
									DfLogger.info(this, " :: execute : IOM Check : From DRL : canEdit = false", null, null);
									return false;
								}
							}else{
								if(strAction !=null){
									return super.execute(strAction, config, args, context, component, completionArgs);
								}else{
									DfLogger.info(this, " :: execute : IOM Check : From DRL : canEdit = true", null, null);
									return true;
								}														
							}						
						}
						/** Allowing Edit role to come from APP SEC Table */
					}
					
					validated = validateUserPermissionsForEdit(strObjectId,completionArgs,component,component.getDfSession(),strAction);
					DfLogger.info(this, " :: execute : validated ="+validated,null,null);
					if(validated == true ){
						/** For 'Released' documents, edit can done only if isWfRestartable is true */
						if(strDocumentState!=null && strDocumentState.equalsIgnoreCase(IDocsConstants.MSG_STATE_RELEASED) == true){
							DfLogger.info(this, " :: validateProjUserAccess : Document is in Released State : " + strDocumentState, null, null);
							if(isWorkflowRestartable == true){
								DfLogger.info(this, " :: validateProjUserAccess : Allow Action  isWorkflowRestartable : " + isWorkflowRestartable, null, null);
								if(strAction !=null){
									DfLogger.info(this, " :: validateProjUserAccess : From Action : "+strAction, null, null);
									IdocsUtil.auditIDocsActivity(MSG_EDITED,strObjectId,component.getDfSession());
									return super.execute(strAction, config, args, context, component, completionArgs);
								}else{
									DfLogger.info(this, " :: validateProjUserAccess : From DRL/Properties : ", null, null);
									return true;
								}							
							}else{
								if(strAction !=null ){
									DfLogger.info(this, " :: validateProjUserAccess : MSG_RELEASED_ACTION_DENIED : From Action :"+strAction, null, null);
									DfLogger.info(this, " :: validateProjUserAccess : DONOT Allow Action as  isWorkflowRestartable : " + isWorkflowRestartable, null, null);
							        ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_RELEASED_ACTION_DENIED", component, new String[]{"Edit",strObjectName,IdocsUtil.handleLDAPEnvVariable(accessRole, component.getDfSession())}, null);
									return false;
								}else{
									DfLogger.info(this, " :: validateProjUserAccess : MSG_RELEASED_ACTION_DENIED : From DRL/Properties :", null, null);
									return false;
								}
							}
						}else{
							if(strAction !=null ){
								DfLogger.info(this, " :: validateProjUserAccess : WF Not Completed : From Action :"+strAction, null, null);
								IdocsUtil.auditIDocsActivity(MSG_EDITED,strObjectId,component.getDfSession());
								return super.execute(strAction, config, args, context, component, completionArgs);
							}else{
								DfLogger.info(this, " :: validateProjUserAccess : WF Not Completed : From DRL/Properties :", null, null);
								return true;
							}
						}
					}else{
						if(documentAspectType != null && documentAspectType.trim().length() > 0
								&& ((IdocsConstants.EMAIL.equals(documentAspectType) || IdocsConstants.SCANNING.equals(documentAspectType)) == true)){
							if(strAction !=null ){
								ErrorMessageService.getService().setNonFatalError(s_lookup, "EMAIL_SCANNING_EDIT_NOT_ALLOWED", component, null, null);
								DfLogger.info(this, " :: validateProjUserAccess : Did not Validate for Email/Scanned Doc : From Action :"+strAction, null, null);
								return false;
							}else{
								DfLogger.info(this, " :: validateProjUserAccess : WF Not Completed : From DRL/Properties :", null, null);
								return true;
							}
						}
						
						/** Validated can be false even if the document is in released State. Show custom message if the document is Released.*/
						if (templateCode != null && templateCode.trim().equalsIgnoreCase(IDocsConstants.MSG_SNAPSHOT_DOC)) {
							if(strAction !=null ){
								ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_SNAPSHOT_ACTION_DENIED", component, new String[]{"Edit",strObjectName}, null);
								DfLogger.info(this, " :: validateProjUserAccess : Did not Validate for Snapshot Doc : From Action :"+strAction, null, null); 
								return false;
							}else{
								DfLogger.info(this, " :: validateProjUserAccess : Did not Validate for Snapshot Doc : From DRL/Properties :", null, null);
								return false;
							}
						}
						
						/** Validated can be false even if the document is in released State. Show custom message if the document is Released.*/
						if(strDocumentState!=null && strDocumentState.equalsIgnoreCase(IDocsConstants.MSG_STATE_RELEASED) == true){
							if(strAction !=null ){
								if(isWorkflowRestartable == true){
								 ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_ACTION_PERMISSION_DENIED", component, new String[]{"Edit",strObjectName,IdocsUtil.handleLDAPEnvVariable(accessRole, component.getDfSession())}, null);
								}else{
								 ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_RELEASED_ACTION_DENIED", component, new String[]{"Edit",strObjectName,IdocsUtil.handleLDAPEnvVariable(accessRole, component.getDfSession())}, null);
								}
								DfLogger.info(this, " :: validateProjUserAccess : Did not Validate for Completed Doc : From Action :"+strAction, null, null); 
								return false;
							}else{
								DfLogger.info(this, " :: validateProjUserAccess : Did not Validate for Completed Doc : From DRL/Properties :", null, null);
								return false;
							}
						}else{
							if(accessRole != null && accessRole.trim().length() > 0){
							}else{
								accessRole=" Authorised ";
							}
							if(templateCode !=null && templateCode.trim().length()>0){
								if(strAction !=null ){
									DfLogger.info(this, " :: validateProjUserAccess : Not Authorised : From Action :"+strAction, null, null);
							        ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_ACTION_PERMISSION_DENIED", component, new String[]{"Edit",strObjectName,IdocsUtil.handleLDAPEnvVariable(accessRole, component.getDfSession())}, null);
									return false;
								}else{
									DfLogger.info(this, " :: validateProjUserAccess : Not Authorised : From DRL/Properties :", null, null);
									return false;
								}
							}else{
								if(strAction !=null ){
									DfLogger.info(this, " :: validateProjUserAccess : Not Authorised : From Action :"+strAction, null, null);
									ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_ACTION_PERMISSION_DENIED", component, new String[]{"Edit",strObjectName,IdocsUtil.handleLDAPEnvVariable(accessRole, component.getDfSession())}, null);
									return false;
								} else {
									DfLogger.info(this, " :: validateProjUserAccess : Not Authorised : From DRL/Properties :", null, null);
									return false;
								}
							}
						}
					}			
				} else{
					if(strAction !=null ){
						DfLogger.info(this, " :: validateProjUserAccess : Not Authorised : From Action :"+strAction, null, null);
						IdocsUtil.auditIDocsActivity(MSG_EDITED,strObjectId,component.getDfSession());
						return super.execute(strAction, config, args, context, component, completionArgs);
					}else{
						DfLogger.info(this, " :: validateProjUserAccess : Not Authorised : From DRL/Properties :", null, null);
						return true;
					}
				}
			}catch (Exception e) {
				DfLogger.error(this, " :: execute : Exception :"+e.getMessage(),null,null);
			}
			return false;
		}
		
    }

	/**
	 * Checks if the objectId got is of the CURRENT Version of the document.
	 * @param strObjectId - Selected ObjectId
	 * @param session - Documentum Session
	 * @return 	- true if the object Id is of the CURRENT Version.
	 * 			- false if the Object id is NOT of CURRENT Version.
	 */
	public static boolean currentVersionCheck(String strObjectId,IDfSession session) {
		String currentObjectId = IDocDocbaseAttributeTagUtility.getCurrentSysObjectAttribute(session, strObjectId, IDocsConstants.MSG_R_OBJECT_ID);
		if(currentObjectId != null && strObjectId !=null
				&& strObjectId.equalsIgnoreCase(currentObjectId)){
			DfLogger.info(LaunchEditComponentWithPermitCheck.class, " :: currentVersionCheck : "+strObjectId+" is the CURRENT Version",null,null);
			return true;			
		}else{
			DfLogger.info(LaunchEditComponentWithPermitCheck.class, " :: currentVersionCheck : "+strObjectId+" is NOT the CURRENT Version",null,null);
			return false;			
		}
	}

	/**
	 * Validates whether the current user can edit this document.
	 * @param strObjectId - Object Id of the document
	 * @param completionArgs - Component arguments
	 * @param component - Current component
	 * @param session - Documentum session.
	 * @return
	 * @throws DfException
	 */
	private boolean validateUserPermissionsForEdit(String strObjectId,Map completionArgs,
			Component component,IDfSession session, String strAction) throws DfException {
		boolean validated = false;
		//Need to remove all these queries ..
		
		if(strObjectType == null 
				&& strDocumentState == null 
				&& strObjectName == null 
				&& templateCode == null
				&& isWorkflowRequired == null
				&& !(strObjectType.trim().length() == 0) 
				&& !(strObjectName.trim().length() == 0)
				&& !(strDocumentState.trim().length() == 0) 
				&& !(templateCode.trim().length() == 0)
				&& !(isWorkflowRequired.trim().length() == 0)){
					setRequiredAttributes(strObjectId, component.getDfSession());
				}else{
					
				}
		String admingGroupName = IdocsUtil.getMessage("MSG_IDOCS_ADMIN_GRP");
		DfLogger.debug(this, " :: MSG_IDOCS_ADMIN_GRP : "+admingGroupName, null, null);
		if(admingGroupName != null && admingGroupName.trim().length() > 0 
				&& IdocsUtil.isMemberOfGroup(admingGroupName, session)){
			DfLogger.debug(this, " :: validateUserPermissionsForEdit : IDocs Admin : Allow Edit", null, null);
			return true;
		}
		
		if (null != templateCode && templateCode.trim().length() > 0 &&
				templateCode.trim().equalsIgnoreCase(IDocsConstants.MSG_SNAPSHOT_DOC)) {
			DfLogger.debug(this, " :: validateUserPermissionsForEdit : templatecode is 420. So cannot Edit", null, null);
			return false;
		}
		
		/** Check whether the document is email or Scanned.
		 * Email and Scanning documents shall not be editable even in draft state.*/
		documentAspectType = IdocsUtil.isThisEmailOrScanned(strObjectId,component.getDfSession());
		if(documentAspectType !=null 
				&& (IdocsConstants.EMAIL.equals(documentAspectType) || IdocsConstants.SCANNING.equals(documentAspectType)) == true){
			return false;				
		}
		
		/**
		 * Conflict of interest role wont be allowed to edit documents with in the project.
		 */
		String projectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(session, strObjectId, IDocsConstants.PROJECT_ID, IDocsConstants.MSG_IDOCS_PROJECT_DOC);
		if(IdocsUtil.isUserPresentInConflictOfInterest(projectId,session) || IdocsUtil.isUserMemberofLDAPGroup(
				 IdocsUtil.getMessage(IdocsConstants.CONFLICT_OF_INTEREST_ROLE), projectId, session)){
			DfLogger.info(LaunchViewComponentWithPermitCheck.class,"::validateUserPermissionsForEdit :  User is Present in Conflict Of Interest.", null, null);
			return false;
		}
		
		/** IFCDocs Writer group will be given write access across the projects. */
		String writersGroupName = IdocsUtil.getMessage("MSG_IFCDOCS_WRITERS_GRP");
		DfLogger.debug(this, " :: MSG_IFCDOCS_WRITERS_GRP : "+writersGroupName, null, null);
		if(writersGroupName != null && writersGroupName.trim().length() > 0 
				&& IdocsUtil.isMemberOfGroup(writersGroupName, session)){
			DfLogger.debug(this, " :: validateUserPermissionsForEdit : Validated Idocs Admin", null, null);
			return true;
		}
		
		/** Project Reader group will be used to give write access on any specific project's documents */
		String projWritersGroup = IdocsUtil.getMessage("MSG_IFCDOCS_PROJ_WRITER_GRP");
		if(strObjectType != null 
       			&& strObjectType.equals(IDocsConstants.MSG_IDOCS_PROJECT_DOC) && validated==false){
			if(projectId != null && projectId.trim().length() > 0 
					&& projWritersGroup != null && projWritersGroup.trim().length() > 0
					&& IdocsUtil.isMemberOfGroup(projWritersGroup.replace("#", projectId), session)){
				DfLogger.debug(this, " :: validateUserPermissionsForEdit : Validated Against Proj Writer Group", null, null);
				return true;
			}			
		}
		
		if(strObjectType != null 
       			&& strObjectType.equals(IDocsConstants.MSG_IDOCS_COUNTRY_DOC) && validated==false){
			DfLogger.debug(this, " :: validateUserPermissionsForEdit : Process Country Document", null, null);
			validated = validateCoreGroupMemberShip(component,session, validated);
		}
		
		
		if(templateCode!=null && templateCode.trim().length() > 0 && validated == false){
			String strTemplateTitle = IdocsUtil.getTemplateTitle(session, strObjectId);
			/** Handle Workflow Documents . Wherever is document is having template code and 
			 * workflow required attribute on the document is set to 1 are workflow documents. */
			if((isWorkflowRequired != null && (isWorkflowRequired.equalsIgnoreCase(IdocsConstants.MSG_WORKFLOW_IS_REQUIRED)==true))
					|| IdocsUtil.isSpecialNonWorkflowDocument(strTemplateTitle)){

				if(strTemplateTitle != null && strTemplateTitle.trim().length() >0 ){
					validated = validateIdocsTemplate(strObjectId,completionArgs, component, session, validated,
							strObjectType, strDocumentState, strObjectName,strTemplateTitle,strAction);
				}else{
					if(strAction != null){
						DfLogger.debug(this, " :: validateUserPermissionsForEdit : Unknown Template :"+ strTemplateTitle,null,null);
						//ActionExecutionUtil.setCompletionError(completionArgs, s_lookup, "MSG_INVALID_TEMPLATE_CODE", component, new String[]{templateCode,strObjectName}, null);
						ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_INVALID_TEMPLATE_CODE", component, new String[]{templateCode,strObjectName}, null);
						throw new DfException("Unkown template Title " + strTemplateTitle +" for template Code :"+ templateCode);
					}else{
						DfLogger.debug(this, " :: validateUserPermissionsForEdit : Unknown Template : From DRL/Properties",null,null);
					}
					
				}
			}else{
				/** Non Workflow document deletion permissions are fixed based on Security Classification
				 * Official					: Team Members + Department Admins
				 * Confidential				: Team Members
				 * Strictly Confidential 	: Read from IdocsProperties */
				/** Allow users to edit Non Workflow Document even if in released state. */
				isWorkflowRestartable = true;
				/** Pemission for View Normal Documents and Edit Imported Document Are Same.*/
				if(docValuesMap != null && docValuesMap.size() >0){
					//don't care
				}else{
					docValuesMap=IdocsUtil.getRequiredAttributesValues(strObjectId, component.getDfSession());
				}
				validated = LaunchViewComponentWithPermitCheck.validateUserPermissionsForView(true,strObjectId, session,docValuesMap);
				DfLogger.debug(this, " :: validateUserPermissionsForEdit : Unknown Template :"+ templateCode,null,null);				
			}
			
		}else{
			/** This is to make sure that the Imported documents where the template code is not available
				 * is editable even in the released state. Allow users to edit imported document even if in released state. */
				isWorkflowRestartable = true;
				/** Pemission for View Normal Documents and Edit Imported Document Are Same.*/
				if(docValuesMap != null && docValuesMap.size() >0){
					//don't care
				}else{
					docValuesMap=IdocsUtil.getRequiredAttributesValues(strObjectId, component.getDfSession());
				}
				validated = LaunchViewComponentWithPermitCheck.validateUserPermissionsForView(true,strObjectId, session,docValuesMap);
				DfLogger.debug(this, " :: validateUserPermissionsForEdit : Unknown Template :"+ templateCode,null,null);			
		}
		return validated;
	}

	/**
	 * Fetches the authorized roles and role types and validation messages who
	 * can create the document in IDOCS.
	 * @param strObjectId - Object Id of the current document.
	 * @param completionArgs - Context Arguments.
	 * @param component - Current wdk component.
	 * @param session - Documentum session
	 * @param validated - Flag representing whether the document is validated or not.
	 * @param strObjectType - Object Type of the document.
	 * @param strDocumentState - Document state of the current document.
	 * @param strObjectName - Object name of the document.
	 * @param strTemplateTitle - Title of the template.
	 * @return
	 * @throws DfException
	 */
	private boolean validateIdocsTemplate(String strObjectId,
			Map completionArgs, Component component, IDfSession session,
			boolean validated, String strObjectType, String strDocumentState,
			String strObjectName, String strTemplateTitle,String strAction) throws DfException {
		String templateAccessQry=IdocsUtil.getMessage("QRY_APP_SEC_CONFIG_EDIT");	
		templateAccessQry=templateAccessQry.replaceAll("''", "'"+strTemplateTitle+"'");
		DfLogger.info(this, " :: validateProjUserAccess : templateAccessQry : " + templateAccessQry, null, null);
		IDfCollection editRoleCollection = IdocsUtil.executeQuery(session, templateAccessQry, IDfQuery.DF_READ_QUERY);
		boolean enteredRoleCheck = false;
		while(editRoleCollection.next() && validated==false){
			enteredRoleCheck = true;
			validated = validateIdocsDocuments(strObjectId,completionArgs, component, session, validated,
					strObjectType, strDocumentState, strObjectName,editRoleCollection,strAction);
		}
		if(editRoleCollection!=null)editRoleCollection.close();
		if(validated ==false && enteredRoleCheck == false){
			if(docValuesMap != null && docValuesMap.size() >0){
				//don't care
			}else{
				docValuesMap=IdocsUtil.getRequiredAttributesValues(strObjectId, component.getDfSession());
			}
			DfLogger.info(this, " :: validateProjUserAccess : NO ROWS Entered : SKIP Validation ", null, null);
			validated = LaunchViewComponentWithPermitCheck.validateUserPermissionsForView(true,strObjectId, session,docValuesMap);
		}
		return validated;
	}

	/**
	 * Validates the IDocs document against templates.
	 * @param strObjectId - Object Id of the document
	 * @param completionArgs - Context arguments
	 * @param component - Current component
	 * @param session - Documentum session
	 * @param validated - Flag whether document is validated
	 * @param strObjectType - Object type of the document
	 * @param strDocumentState - Document state of the document.
	 * @param strObjectName - Object Name of the document.
	 * @param editRoleCollection - IDfCollection object representing the authorised create roles.
	 * @return
	 * @throws DfException
	 */
	private boolean validateIdocsDocuments(String strObjectId,
			Map completionArgs, Component component, IDfSession session,
			boolean validated, String strObjectType, String strDocumentState,
			String strObjectName, IDfCollection editRoleCollection,String strAction)
			throws DfException {
		String createRole;
		String createRoleType;
		String errorMsg;
		createRole = editRoleCollection.getString(IdocsConstants.MSG_EDIT_ROLE);
		if(accessRole == null) {
			accessRole = createRole;
		}else{
			accessRole +=IdocsConstants.MSG_COMMA +createRole;
		}
		DfLogger.info(this, " :: validateUserPermissionsForEdit : accessRole :"+ accessRole,null,null);
		createRoleType = editRoleCollection.getString(IdocsConstants.MSG_EDIT_ROLE_TYPE);
		isWorkflowRestartable = editRoleCollection.getBoolean(IDocsConstants.MSG_IS_WORKFLOW_RESTARTABLE);
		errorMsg=editRoleCollection.getString(IdocsConstants.MSG_ERROR_MESSAGES);			
		DfLogger.info(this, " :: validateUserPermissionsForEdit : Document Object Type ="+strObjectType,null,null);
		if(strObjectType != null 
		   		&& strObjectType.equals(IDocsConstants.MSG_IDOCS_PROJECT_DOC)){
			validated = validateProjectTemplates(strObjectId,completionArgs, component, session,
					createRole, createRoleType, errorMsg,isWorkflowRestartable, validated,strDocumentState, strObjectName,strAction);
		}else if(strObjectType != null 
				&& strObjectType.equals(IDocsConstants.MSG_IDOCS_INSTITUTION_DOC) && validated==false){
			validated = validateInstitutionTemplate(
					strObjectId, component, session,createRole, createRoleType, errorMsg,isWorkflowRestartable, validated,strDocumentState);
		}else{
			validated = validateCoreGroupMemberShip(component,session, validated);
		}
		return validated;
	}

	/**
	 * Validates the Project Templates
	 * @param strObjectId - ObjectId of the document
	 * @param completionArgs - Context arguments
	 * @param component - Current Component
	 * @param session - Documentum  session
	 * @param createRole - Role who can create the document.
	 * @param createRoleType- Role type of the role string
	 * @param errorMsg - Pre configured error messages.
	 * @param isWorkflowRestartable - Flag representing whether workflow is restartable.
	 * @param validated - Document is validated or not
	 * @param strDocumentState - Document state of the current document.
	 * @param strObjectName - Name of the current document.
	 * @return
	 * @throws DfException
	 */
	private boolean validateProjectTemplates(String strObjectId,
			Map completionArgs, Component component, IDfSession session,
			String createRole, String createRoleType, String errorMsg,
			boolean isWorkflowRestartable, boolean validated,
			String strDocumentState, String strObjectName,String strAction) throws DfException {
		String projectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(session, strObjectId, "project_id", IDocsConstants.MSG_IDOCS_PROJECT_DOC);
		DfLogger.info(this, " :: validateProjUserAccess : projectId : " + projectId, null, null);
		if(projectId !=null && projectId.trim().length() > 0){
			DfLogger.info(this, " :: validateProjectTemplates : Validate :"+ projectId+","+createRole+","+createRoleType+","+strDocumentState+","+isWorkflowRestartable,null,null);
			validated = IdocsUtil.validateRole(projectId,createRole,createRoleType,strDocumentState,isWorkflowRestartable,errorMsg,component.getDfSession());
		}else{
			if(strAction != null){
	//			ActionExecutionUtil.setCompletionError(completionArgs, s_lookup, "MSG_INVALID_PROJECT_ID", component, new String[]{projectId,strObjectName}, null);
			    ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_INVALID_PROJECT_ID", component, new String[]{projectId,strObjectName}, null);
				DfLogger.info(this, " :: validateProjectTemplates : Project ID is NULL  :"+ projectId,null,null);
				throw new DfException("Invalid Project Id" + projectId);
			}else{
				DfLogger.info(this, " :: validateProjectTemplates : Project ID is NULL  : From DRL/Properties"+ projectId,null,null);
			}			
		}
		return validated;
	}

	/**
	 * Validate client institution template
	 * @param strObjectId - ObjectId of the document.
	 * @param component - Current component.
	 * @param session - Documentum session
	 * @param createRole - Role who can create the document.
	 * @param createRoleType - Type of the role who can create the document
	 * @param errorMsg - Pre configured validation message
	 * @param isWorkflowRestartable - Flag representing whether the workflow can be restarted
	 * @param validated - flag representing whether the user has been validated
	 * @param strDocumentState - Document state of the current document.
	 * @return
	 * @throws DfException
	 */
	private boolean validateInstitutionTemplate(String strObjectId,
			Component component, IDfSession session, String createRole,
			String createRoleType, String errorMsg,
			boolean isWorkflowRestartable, boolean validated,
			String strDocumentState) throws DfException {
		String strInstiRoleType = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(session,  strObjectId, "instit_role_type_code", IDocsConstants.MSG_IDOCS_INSTITUTION_DOC);
		DfLogger.info(this,"Value of Institution Role type "+strInstiRoleType,null,null);     		
		if(strInstiRoleType!=null && strInstiRoleType.trim().length() > 0 
				&& strInstiRoleType == IDocsConstants.MSG_INTITUTION_CLIENT_ROLE){
			validated = validateClientInstitution( strObjectId, component, session,
					createRole, createRoleType, errorMsg,isWorkflowRestartable, validated,strDocumentState);			
		}else{	        			
			validated = validateCoreGroupMemberShip(component, session, validated);
		}
		return validated;
	}

	/**
	 * This method check the login user is member of Ifc_core_group.
	 * @param component - Current component
	 * @param session -	Documentum session
	 * @param validated - Flag to check whether the user is validated.
	 * @return
	 * @throws DfException
	 */
	private boolean validateCoreGroupMemberShip(Component component,
			IDfSession session, boolean validated) throws DfException {
		String query = "select i_all_users_names from dm_group where group_name='"+IdocsUtil.getMessage("MSG_IFC_CORE_GROUP")+"' and any i_all_users_names='"+IdocsUtil.handleSingleQuote(component.getDfSession().getLoginUserName())+"'"; 
		IDfCollection userMemberShipCollection = IdocsUtil.executeQuery(session, query, IDfQuery.DF_READ_QUERY);
		while(userMemberShipCollection.next() && validated==false){     
			validated = true;
		}
		if(userMemberShipCollection != null)userMemberShipCollection.close();
		return validated;
	}

	/**
	 * This method checks if the user id validated against all client project team
	 * @param strObjectId - ObjectId of the current document
	 * @param component - Current component
	 * @param session - Documentum Session Object
	 * @param createRole - Role String representing who can create the document.
	 * @param createRoleType - Role type string representing who can create the document
	 * @param errorMsg - Preconfigured validaton message in case of error.
	 * @param isWorkflowRestartable - Flag representing this work flow can be restarted or not.
	 * @param validated - flag representing whether current user is validated.
	 * @param strDocumentState - Document state of the current document.
	 * @return
	 * @throws DfException
	 */
	private boolean validateClientInstitution(String strObjectId,
			Component component, IDfSession session, String createRole,
			String createRoleType, String errorMsg,
			boolean isWorkflowRestartable, boolean validated,
			String strDocumentState) throws DfException {
		String strInstitutionNumber = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(session,  strObjectId, "institution_nbr", IDocsConstants.MSG_IDOCS_INSTITUTION_DOC);
		DfLogger.info(this,"Value of Institution Number "+strInstitutionNumber,null,null);
		String frameClientProjects = IdocsUtil.getMessage("QRY_CLIE_INSTI_PROJECTS").replaceFirst("''", strInstitutionNumber);
		IDfCollection projectIdCollection = IdocsUtil.executeQuery(session, frameClientProjects, IDfQuery.DF_READ_QUERY);
		while(projectIdCollection.next() && validated==false){
			String subProjectid = projectIdCollection.getString("project_id");
			DfLogger.info(this," Sub ProjectId="+subProjectid,null,null);
			validated = IdocsUtil.validateRole(subProjectid,createRole,createRoleType,strDocumentState,isWorkflowRestartable,errorMsg,component.getDfSession());
		}
		if(projectIdCollection!=null)projectIdCollection.close();
		return validated;
	}
	
	/**
	 * Purpose : To set required attributes info  
	 * @param strObjectId
	 * @param dfSession
	 */
	
	private void setRequiredAttributes(String strObjectId,IDfSession dfSession){
		docValuesMap=IdocsUtil.getRequiredAttributesValues(strObjectId,dfSession);
		strObjectType 	   = docValuesMap.get(IDocsConstants.MSG_R_OBJECT_TYPE);
		strObjectName 	   = docValuesMap.get(IDocsConstants.MSG_OBJECT_NAME);
		strDocumentState   = docValuesMap.get(IDocsConstants.MSG_DOC_STATE);
		strOwnerName       = docValuesMap.get(IDocsConstants.MSG_OWNER_NAME);
		templateCode       = docValuesMap.get(IDocsConstants.MSG_TEMPLATE_CODE);
		isWorkflowRequired = docValuesMap.get(IDocsConstants.MSG_IS_WORKFLOW_REQUIRED);
		}
	
	private HashMap<String, String> docValuesMap = new HashMap<String, String>();
}