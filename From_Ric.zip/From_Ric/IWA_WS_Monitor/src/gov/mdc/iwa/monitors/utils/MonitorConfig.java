package gov.mdc.iwa.monitors.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

public class MonitorConfig {
	
	private  ArrayList<String> recipients = new ArrayList<String>();
	private  String smtp = "";	
	private  String url = "";
	private  String po = "";		
	private  String usr = "";
	private  String pw = "";
	private  String from = "";
	private  String subject = "";
	
	public MonitorConfig(){		
	}
	
	public MonitorConfig(String configFile){
		populateMonitorConfig(configFile);
	}
	
	public ArrayList<String> getRecipients() {
		return recipients;
	}
	public void setRecipients(ArrayList<String> recipients) {
		this.recipients = recipients;
	}
	public String getSmtp() {
		return smtp;
	}
	public void setSmtp(String smtp) {
		this.smtp = smtp;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getPo() {
		return po;
	}
	public void setPo(String po) {
		this.po = po;
	}
	public String getUsr() {
		return usr;
	}
	public void setUsr(String usr) {
		this.usr = usr;
	}
	public String getPw() {
		return pw;
	}
	public  void setPw(String pw) {
		this.pw = pw;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	public void populateMonitorConfig(String configFile)
	{  
		//MonitorConfig config = new MonitorConfig();
		
		try{
			ArrayList<String> recipients = new ArrayList<String>();
			StringBuffer msg = new StringBuffer(); 
			BufferedReader in = null;
			String line = "";
			String key = "";
			String value = "";
			String[] stringArray = null;
			File file = new File(configFile);
			String path = file.getAbsolutePath();

			// Check if the file exists
			if ( file.exists()) {    	
				try{
					in = new BufferedReader(new FileReader(file));
					while (in.ready()) {
						line = in.readLine();
						stringArray = line.split("=");
						if(stringArray.length > 0){
							key = stringArray[0].trim();
							value = stringArray[1].trim();

							if(key.equalsIgnoreCase("EMAIL")){
								recipients.add(value);
							}else if (key.equalsIgnoreCase("SMTP")) {
								this.setSmtp(value);
							}else if (key.equalsIgnoreCase("URL")) {
								this.setUrl(value);
							}else if (key.equalsIgnoreCase("PO")) {
								this.setPo(value);
							}else if (key.equalsIgnoreCase("USR")) {
								this.setUsr(value);
							}else if (key.equalsIgnoreCase("PW")) {
								this.setPw(value);
							}else if (key.equalsIgnoreCase("FROM")) {
								this.setFrom(value);
							}else if (key.equalsIgnoreCase("SUBJECT")) {
								this.setSubject(value);
							}
						}
					}
					this.setRecipients(recipients);
					in.close();
				}catch(Exception e){
					e.printStackTrace();
					msg.append("Unable to parse " + path + "\n");
					msg.append("Host: " + Host.getHostName() + "\n");
					msg.append("Program: PoGLLookupMonitor\n") ;
					msg.append("Resolution: Check config file\n") ;
					msg.append("Error: " + e.getMessage()) ;
					Email.SendToSupport(msg.toString());
				}
			}else{
				msg.append("Config file   " + path + "   NOT found.\n");
				msg.append("Host: " + Host.getHostName() + "\n");
				msg.append("Program: PoGLLookupMonitor.\n") ;			
				Email.SendToSupport(msg.toString());
			}
			
		}catch(Exception e){			
		}		
	}
}
