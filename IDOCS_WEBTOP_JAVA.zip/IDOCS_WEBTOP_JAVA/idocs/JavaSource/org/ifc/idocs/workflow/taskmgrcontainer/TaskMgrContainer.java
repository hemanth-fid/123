/**
 * The customized component class is used to set visibility of the controls in the taskmanagarcontainer. 
 * #######################################################################################################
 * Author		 	  DateofChange	 Version		ModificationHistory
 * #######################################################################################################
 * Parag Doshi			01/12/2011		1.1				created
 * #######################################################################################################
 */
package org.ifc.idocs.workflow.taskmgrcontainer;

import java.util.Calendar;
import java.util.Map;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.bpm.IDfWorkitemEx;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfQueueItem;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfWorkflow;
import com.documentum.fc.client.IDfWorkitem;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfList;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfList;
import com.documentum.services.workflow.common.IWorkflowTaskAttachment;
import com.documentum.services.workflow.inbox.ITask;
import com.documentum.services.workflow.inbox.IWorkflowTask;
import com.documentum.services.workflow.inbox.IWorkflowTaskInfo;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.SessionState;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.Button;
import com.documentum.web.form.control.Panel;
import com.documentum.web.form.control.Tabbar;
import com.documentum.web.formext.control.action.ActionControl;
import com.documentum.web.formext.control.xforms.XForms;
import com.documentum.web.formext.docbase.ObjectCacheUtil;
import com.documentum.webcomponent.common.WebComponentErrorService;
import com.documentum.webcomponent.library.messages.MessageService;
import com.documentum.webcomponent.library.workflow.WorkflowFormsUtil;
import com.documentum.webcomponent.library.workflow.WorkflowUtil;
import com.documentum.webcomponent.library.workflow.taskmanager.TaskManager;

public class TaskMgrContainer
		extends
		com.documentum.webcomponent.library.workflow.taskmgrcontainer.TaskMgrContainer{
	private static final String START = "start";
	private static final String TASKCONFIRMATION = "taskconfirmation";
	private static final String MSG_TASK_UNCLAIM_SUCCESS = "MSG_TASK_UNCLAIM_SUCCESS";
	private static final String MSG_TASK_UNCLAIM_FAILED = "MSG_TASK_UNCLAIM_FAILED";

	public void onInit(ArgumentList args) {
		try {
			DfLogger.info(this, " TaskMgrContainer : "+Calendar.getInstance().getTimeInMillis()+" args"+args,null,null);
			loginUserName = getDfSession().getLoginUserName();
			DfLogger.info(this, " TaskMgrContainer : "+Calendar.getInstance().getTimeInMillis()+" loginUserName"+loginUserName,null,null);			
			projectId = IDocsConstants.MSG_EMPTY_STRING;
			projectName = IDocsConstants.MSG_EMPTY_STRING;
			institutionNumber = IDocsConstants.MSG_EMPTY_STRING;
			institutionShortName = IDocsConstants.MSG_EMPTY_STRING;
			projectType=false;
			institutionType=false;
			countryType=false;
			packageDocumentFound = false;
			m_taskId = args.get("objectId");
			SessionState.setAttribute(IDocsConstants.DIRECT_TASK_ID, m_taskId);
			source = args.get("source");
			DfLogger.info(this, " :: source : "+ source, null, null);
			if (STR_ASPORTAL.equals(source)){
				DfLogger.info(this, " :: This is an ASOP TASK : "+ source, null, null);
			}else{
				String type = args.get("documentType");
				if(type!=null && type.trim().length() > 0){
					if(IdocsConstants.PROJ_DOC_TYPE.equals(type)){
						projectType = true;
						projectId=args.get("projectId");
						projectName=args.get("projectShortName");
						countryNameFromArguments = args.get("countryName");
						strFormLockOwner = args.get(STR_LOCKOWNER);
						packageDocumentFound = true;
						isQueryRequired = false;
					}else if(IdocsConstants.INSTITUTION_DOC_TYPE.equals(type)){
						institutionType = true;
						institutionNumber=args.get("projectId");
						institutionShortName=args.get("projectShortName");
						countryNameFromArguments = args.get("countryName");
						strFormLockOwner = args.get(STR_LOCKOWNER);
						packageDocumentFound = true;
						isQueryRequired = false;
					}else if(IdocsConstants.COUNTRY_DOC_TYPE.equals(type)){
						countryType = true;
						countryCode = args.get("projectId");
						countryNameFromArguments = args.get("countryName");
						strFormLockOwner = args.get(STR_LOCKOWNER);
						packageDocumentFound = true;
						isQueryRequired = false;
					}
				}
			}
			super.onInit(args);
			if(canPeformOnThisTask()){
				DfLogger.debug(this, " :: onInit : MY CHECK : Check whether can Proceed ",null, null);
			}else{
				displayErrorMessages();
				setComponentReturn();
			}
		} catch (Exception e) {
			DfLogger.error(this, " :: onInit Exception >> " + e.getMessage(),null, e);
		}
	}
	
	 public void onaction(ActionControl actionControl, ArgumentList args){
		 super.onaction(actionControl, args);   
		 String action = null;
	        if(actionControl != null)
	            action = actionControl.getAction();
	        if(ACCEPT_WRK_TASK.equals(action)){
	        	Tabbar tabs = (Tabbar)getControl("tabs",Tabbar.class);
				if(tabs!= null){
					if(!tabs.getValue().equalsIgnoreCase(TASK_MGRCLASSIC_COMPNENT)){
						tabs.setValue(TASK_MGRCLASSIC_COMPNENT);
						 setCurrentComponent(TASK_MGRCLASSIC_COMPNENT);
					}
				}
	        }
	   }
	 
	public void onRender() {
		super.onRender();
		try {		
			DfLogger.info(this, " :: onRender : "+ loginUserName, null, null);
			updatebuttons();
			} catch (DfException e) {
			DfLogger.error(this, " :: onRender Exception >> " + e.getMessage(),null, null);
		}		
	}
	
	public void updatebuttons() throws DfException {
		// getting the workflow task to update its buttons
		IWorkflowTask wfTask = (IWorkflowTask) getTaskState();
		IWorkflowTaskInfo wftaskinfo = wfTask.getTaskInfo();
		int performertype = wftaskinfo.getCurrentActivityPerformerType();
		
		Panel unclaimPanelCtrl = (Panel) getControl(UNCLAIM_BUTTON_PANEL_CONTROL_NAME, Panel.class);
		Panel savePanelCtrl = (Panel) getControl(SAVE_BUTTON_PANEL_CONTROL_NAME, Panel.class);
		Panel finishPanelCtrl = (Panel) getControl(FINISH_BUTTON_PANEL_CONTROL_NAME, Panel.class);
		unclaimPanelCtrl.setVisible(false);
		savePanelCtrl.setVisible(false);
		if (wfTask.isRepeatable() && (!wfTask.isGroupOwned()) && (performertype == 5)) {
			unclaimPanelCtrl.setVisible(true);
		}
		
		int finishTaskpreconditiontaskState = wfTask.getTaskState();		
		String taskOwner = wfTask.getPerformerName();
        if(finishTaskpreconditiontaskState==1 
        		&& taskOwner!=null && taskOwner.trim().length() > 0 
        		&& taskOwner.equals(loginUserName)){
        	DfLogger.debug(this , "This task is acquired by "+taskOwner+" . Enable the Finish Panel", null, null);
        	finishPanelCtrl.setVisible(true);
        }else{
        	DfLogger.debug(this , "This task is NOT acquired by "+taskOwner+" . Disable the Finish Panel", null, null);
        	finishPanelCtrl.setVisible(false);
        }

		XForms xFormControl = (XForms) getControl(TaskManager.XFORM_CONTROL_NAME, XForms.class);
		if ((!wfTask.isGroupOwned()) && (xFormControl.getForm().getId() != null)) {
			savePanelCtrl.setVisible(true);
		}
	}

	/**
	 * 
	 * @param strAction
	 * @param bSuccess
	 * @param map
	 */
	public void onSaveReturn(String strAction, boolean bSuccess, Map map) {
		ArgumentList args = getInitArgs();
		setIsOnactionTriggered(false);
		if (!bSuccess) {
			return;
		}
		try {
			ITask task = getTaskState();
			if (task.getType() == 4) {
				IDfQueueItem qitem = (IDfQueueItem) getDfSession().getObject(new DfId(m_taskId));
				IDfWorkitem witem = qitem.getWorkitem();
				m_taskId = witem.getQueueItemId().toString();
				args.remove("objectId");
				args.add("objectId", m_taskId);
			}
		} catch (DfException e) {
			throw new WrapperRuntimeException(e);
		}
		setComponentJump("taskmanagercontainer", args, getContext());
	}
	
	/**
	 * 
	 * @param strAction
	 * @param bSuccess
	 * @param map
	 */
	public void onFinishReturn(String strAction, boolean bSuccess, Map map) {
		ArgumentList args = getInitArgs();
		setIsOnactionTriggered(false);
		super.onCommitChanges();
		if (!bSuccess) {
			return;
		}
		redirectToConfirmPage();
	}
	
	
	private void redirectToConfirmPage() {
		if (STR_ASPORTAL.equals(source)) {
			setComponentJump(TASKCONFIRMATION, START, getContext());
		} else {
			setComponentReturnJump(STR_INBOX_COMPONENT, START, getContext());
		}

	}

	/**
	 * 
	 * @param strAction
	 * @param bSuccess
	 * @param map
	 */
	private void setErrorMessage(String id) {
		setReturnError(id, null, null);
		WebComponentErrorService.getService().setNonFatalError(this, id, null);
	}

	public void onAcceptReturn(String strAction, boolean bSuccess, Map map) {
		DfLogger.info(this, "Testing claim button",null,null);	
		super.onAcceptReturn(strAction, bSuccess, map);	
	}
	
	/**
	 * Purpose : Custom Validation on Task (Locked by any other user or not)
	 * @return
	 */

	private boolean canPeformOnThisTask(){
		try {
			if(isQueryRequired == true || (source!=null && source.trim().length() > 0 
					&& STR_ASPORTAL.equals(source))){ 
				computeTaskInformationWithQuery();
			}else{
				computeTaskInformationIFCDocs();
			}
				
			DfLogger.info(this, "Form Lock owner :: " + strFormLockOwner,null,null);
			DfLogger.info(this, "countryNameFromPackageDoc ::" + countryNameFromPackageDoc,null,null);
			DfLogger.info(this, "packageDocumentFound ::"+ packageDocumentFound,null,null );
			DfLogger.info(this, "Current User Name  : : :: : :"+ loginUserName,null,null);
			
			if(packageDocumentFound == false ){
				return false;
			}else if(countryNameFromPackageDoc == null){
				DfLogger.info(this, "packageDocumentFound :"+packageDocumentFound +" :: Country Name is Blank ",null,null);
				return false;
			}else if (strFormLockOwner != null && strFormLockOwner.trim().length() > 0 && loginUserName.equalsIgnoreCase(strFormLockOwner) == false){
				DfLogger.info(this, "strLockOwner :"+strFormLockOwner,null,null);
				return false;
			}else {
				return true;
			}		
		} catch (DfException e) {
			DfLogger.error(this, "DfException : "+e.getMessage(),null,null);
			throw new WrapperRuntimeException(e);
		}	
	}

	private void computeTaskInformationIFCDocs() throws DfException {
		countryNameFromPackageDoc = countryNameFromArguments;
		IWorkflowTask wfTask = (IWorkflowTask) getTaskState();
		String launchPkg = wfTask.getLaunchImmediatePackageName();
		String m_showingFormId = null;
		DfLogger.info(this, "wfTask.getLaunchImmediatePackageName() : " + launchPkg,null,null);
		if(launchPkg != null && launchPkg.length() > 0){
			IWorkflowTaskAttachment attachment = WorkflowUtil.findAttachmentByName(wfTask,launchPkg);
			if(launchPkg.startsWith("Wf_Form")){
				IDfId docId = attachment.getDocumentId(0);
				m_showingFormId = docId.toString();
				DfLogger.info(this, "wfTask. got a Wf_Form : m_showingFormId =" + m_showingFormId,null,null);
			}else if(attachment != null && attachment.getStatus() != 4 && attachment.getDocumentCount() > 0){
				IDfId docId = attachment.getDocumentId(0);
				if(docId != null && WorkflowFormsUtil.isFormInstance(getDfSession(), docId.toString())){
					m_showingFormId = docId.toString();
				}
			}
		}
		IDfSysObject sysObject = (IDfSysObject)ObjectCacheUtil.getObject(getDfSession(), m_showingFormId);
		if(sysObject !=null){
			strFormLockOwner = sysObject.getLockOwner();
		}
		DfLogger.info(this, "strFormLockOwner  :"+strFormLockOwner,null,null);		
	}

	private void computeTaskInformationWithQuery()
			throws DfException {
		IDfCollection dfCollection = null;
		countryNameFromPackageDoc = null;
		ArgumentList args = getInitArgs();
		ITask task = getTaskState();
		if (task.getType() == 4) {
			DfLogger.info(this, "Queue Item ID : :" + args.get("objectId"),null,null);
			String formId = EMPTY_STRING;
			String formType=EMPTY_STRING;
			StringBuilder queryBuilder= new StringBuilder();
			String strQuery = queryBuilder.append(R_COMPONENT_ID_QUERY).append(task.getItemId()).append(STR_QUERY_END_STR).toString();
			DfLogger.info(this, "r_component_chron_id query    Id : : :: : : strQuery  :::   " + strQuery,null,null);
			dfCollection = IdocsUtil.executeQuery(getDfSession(), strQuery,IDfQuery.DF_READ_QUERY ); 
			while (dfCollection.next()) {
				formId = dfCollection.getString(R_COMPONENT_CHRON_ID);
				formType = dfCollection.getString(R_PACKAGE_TYPE);
				DfLogger.info(this, " Package ID = " + formId +"  ::  Package Type = "+formType,null,null);
				if(formType.equals(IdocsConstants.INSTITUTION_DOC_TYPE) 
						|| formType.equals(IdocsConstants.PROJ_DOC_TYPE)
						|| formType.equals(IdocsConstants.COUNTRY_DOC_TYPE)){
						DfLogger.info(this, "Document  Id : : :: : :" + formId,null,null);
						if(formType.equals(IdocsConstants.PROJ_DOC_TYPE)){
					    	projectType=true;
					    	projectId=IdocsUtil.getSingleAttributeValueUsingChronicleId(getDfSession(), formId, IDocsConstants.PROJECT_ID, IdocsConstants.PROJ_DOC_TYPE);
					    	projectName=IdocsUtil.getSingleAttributeValueUsingChronicleId(getDfSession(), formId, IDocsConstants.PROJECT_NAME, IdocsConstants.PROJ_DOC_TYPE);
					    	countryNameFromPackageDoc=IdocsUtil.getSingleAttributeValueUsingChronicleId(getDfSession(), formId, IDocsConstants.MSG_COUNTRY_NME, IdocsConstants.PROJ_DOC_TYPE);
					    	if(projectId != null && projectId.trim().length() > 0)packageDocumentFound = true;
					    }else if(formType.equals(IdocsConstants.INSTITUTION_DOC_TYPE)){
					    	institutionType=true;
					    	institutionNumber=IdocsUtil.getSingleAttributeValueUsingChronicleId(getDfSession(), formId, IDocsConstants.INSTITUTION_NBR, IdocsConstants.INSTITUTION_DOC_TYPE);
					    	institutionShortName=IdocsUtil.getSingleAttributeValueUsingChronicleId(getDfSession(), formId, IDocsConstants.MSG_INSTIT_SHORT_NME, IdocsConstants.INSTITUTION_DOC_TYPE);
					    	countryNameFromPackageDoc=IdocsUtil.getSingleAttributeValueUsingChronicleId(getDfSession(), formId, IDocsConstants.MSG_COUNTRY_NME, IdocsConstants.INSTITUTION_DOC_TYPE);
					    	if(institutionNumber != null && institutionNumber.trim().length() > 0)packageDocumentFound = true;
					    }else if(formType.equals(IdocsConstants.COUNTRY_DOC_TYPE)){
					    	countryType=true;					    	
					    	countryCode=IdocsUtil.getSingleAttributeValueUsingChronicleId(getDfSession(), formId, IDocsConstants.COUNTRY_CODE, IdocsConstants.COUNTRY_DOC_TYPE);
					    	countryNameFromPackageDoc=IDocDocbaseAttributeTagUtility.getSingleAttributeValue(getDfSession(), formId, IDocsConstants.MSG_COUNTRY_NME, IdocsConstants.COUNTRY_DOC_TYPE);
					    	if(countryCode != null && countryCode.trim().length() > 0)packageDocumentFound = true;
					    }else{
					    	packageDocumentFound = false;
					    	DfLogger.info(this, "Unknown Type :: formType = " + formType,null,null);
					    }												
				}else{
					strFormLockOwner =IDocDocbaseAttributeTagUtility.getSysObjectAttribute(getDfSession(), formId, IDocsConstants.MSG_R_LOCK_OWNER);
					DfLogger.info(this, "Form Id : : :: : :" + formId,null,null);
				}
			}
			if(dfCollection!=null)dfCollection.close();
		}				
	}
 
	
	
	/**
	 * Purpose: Is to build  dynamic ErrorMessage
	 */
	
	private void displayErrorMessages() {
		DfException ex = new DfException();
		if(packageDocumentFound == false){
			ex.setMessage("You dont have sufficient privileges to perform on this task. Please contact Administrator.");
			} else if(strFormLockOwner != null && strFormLockOwner.trim().length() > 0){
				ex.setMessage("The task is locked by " + strFormLockOwner + "."+ " Please try after sometime.");
			}else{
				ex.setMessage("An unexpected exception has occurred. Please contact Administrator.");
			}
		setReturnError("MSG_TITLE", null, ex);
		WebComponentErrorService.getService().setNonFatalError(this,"MSG_ERROR", ex);
		}
	
    /**
	  * Purpose : Is to Navigate back to appropriate component(Depends on Criteria  AS or IFCDocs) 
	  * @param button
	  * @param args
	  */
	
	public void closeWindow(Button button, ArgumentList args){
		try {
			if(STR_ASPORTAL.equals(source)){
				setComponentJump(TASKCONFIRMATION, START, getContext());
			}else{
				super.onClose(button, args);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/**
	 * User list - group name who will get the activity back on unclaim
	 * @param unclaimControl
	 * @param args
	 */
	public void unclaimWorkflowTask(Control unclaimControl, ArgumentList args){
		try {
			String workflowName = null;
			String performer_group = null;
			IDfList m_usersToRepeat = new DfList();
			IWorkflowTask wfTask = (IWorkflowTask) getTaskState();
			IDfWorkitem objWorkItem = (IDfWorkitem) getDfSession().getObject((DfId) wfTask.getItemId());
			IDfWorkflow objWorkflow = (IDfWorkflow) getDfSession().getObject((DfId) objWorkItem.getWorkflowId());
			workflowName = objWorkflow.getObjectName();
			String wfObjectId = objWorkflow.getObjectId().getId();
			DfLogger.info(this, "onNextComponent :: Workflow Name : "+ workflowName, null, null);
			DfLogger.info(this, "onNextComponent :: Workflow ID : " + wfObjectId,null, null);
			String actDefId = objWorkItem.getActDefId().toString();
			/*
			 * Advisory Services changes : Start
			 */
			if (workflowName.startsWith(STR_AS_WORKFLOW_PREFIX)) {
				performer_group = STR_AS_GROUP_PREFIX + wfObjectId + STR_UNDERSCORE + actDefId.substring(10);
			} else if (workflowName.startsWith(SUB_WORKFLOW)) {
				try {
					IDfWorkitemEx workItemEx = (IDfWorkitemEx) getDfSession().getObject(objWorkItem.getObjectId());
					performer_group = (String) workItemEx.getStructuredDataTypeAttrValue("SubProcessVariables","groupName");
				} catch (DfException e) {
					DfLogger.error(this, "Exception in unclaiming activity", null,null);
					e.printStackTrace();
				}
			} else {
				performer_group = STR_IDOCS_GROUP_PREFIX + wfObjectId + STR_UNDERSCORE+ actDefId.substring(10);
			}
			DfLogger.info(this,"Unclaim() :: Performer Group : " + performer_group,null, null);
			m_usersToRepeat.append(performer_group);
			wfTask.setDelegateUser(performer_group);
			wfTask.completeTask();
			MessageService.addMessage(this, MSG_TASK_UNCLAIM_SUCCESS);
			
			if(STR_ASPORTAL.equals(source)){
				redirectToConfirmPage();
			}
			else{
				super.onClose(unclaimControl, args);
			}
		} catch (DfException e) {
			setReturnError(MSG_TASK_UNCLAIM_FAILED, null, null);
			DfLogger.info(this,"Exceptin : Unclaim task failed : " + e.getMessage(),null, null);
		}

	}
	
	private String source;
	private String m_taskId;
	private String loginUserName = null;
	private String STR_QUERY_END_STR="')";
	private boolean isQueryRequired = true;
	private static final String EMPTY_STRING = "";
	private String strFormLockOwner = EMPTY_STRING;
	private static final String STR_LOCKOWNER="lockOwner"; 
	private static final String STR_INBOX_COMPONENT="inboxclassic"; 
	public boolean projectType=false;
	public boolean countryType=false;
	public boolean institutionType=false;
	public String  projectId =EMPTY_STRING;
	public String  projectName=EMPTY_STRING;
	public String  countryCode=EMPTY_STRING;
	public boolean packageDocumentFound = false;
	public String  countryNameFromArguments=null;
	public String  countryNameFromPackageDoc=null;
	public String  institutionNumber = EMPTY_STRING;
	public String  institutionShortName = EMPTY_STRING;
		
	private static final long serialVersionUID = 1L;
	private static final String STR_UNDERSCORE = "_";
	private static final String STR_ASPORTAL = "asportal";
	private static final String STR_AS_GROUP_PREFIX = "as_";
	private static final String SUB_WORKFLOW = "Sub Workflow";
	private static final String STR_AS_WORKFLOW_PREFIX = "AS ";
	private static final String R_PACKAGE_TYPE="r_package_type";
	private static final String STR_IDOCS_GROUP_PREFIX = "idocs_";
	private static final String R_COMPONENT_CHRON_ID = "r_component_chron_id";
		
	public static final String ACCEPT_WRK_TASK="acceptworkflowtask";
	public static final String TASK_MGRCLASSIC_COMPNENT="taskmgrclassic";
		
	public static final String UNCLAIM_BUTTON_PANEL_CONTROL_NAME = "__UNCLAIM_BUTTON_PANEL_CONTROL_NAME";
	public static final String SAVE_BUTTON_PANEL_CONTROL_NAME = "__SAVE_BUTTON_PANEL_CONTROL_NAME";
	
	private String R_COMPONENT_ID_QUERY="select distinct r_component_chron_id,r_package_type from dmi_package where r_workflow_id in(select r_workflow_id from dmi_workitem where r_object_id='";
}