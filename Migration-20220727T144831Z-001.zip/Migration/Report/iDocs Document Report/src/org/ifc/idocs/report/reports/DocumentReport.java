package org.ifc.idocs.report.reports;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Logger;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.CellRangeAddress;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.ifc.idocs.report.ReportUtility;
import org.ifc.idocs.report.common.AppConfig;
import org.ifc.idocs.report.common.LogHelper;
import org.ifc.idocs.report.db.ExportDAOImpl;
import org.ifc.idocs.report.db.ReportDAOImpl;
import org.ifc.idocs.report.model.DocumentReportDisplay;


@SuppressWarnings("deprecation")
public class DocumentReport extends ReportUtility{
	
	private static String folderValue = "", folderCount = "", folderSize = "";
	private static Row newRow = null;
	private static Workbook newWb = null;
	private static Sheet newSheet = null;
	private static CellStyle newStyle = null, colorStyle = null;
	private static DocumentReportDisplay drd = null;
	private static AppConfig config = AppConfig.getInstance();
	private static Logger reportLogger = LogHelper.getLogger(DocumentReport.class);
	private static ArrayList<DocumentReportDisplay> docReportList = new ArrayList<DocumentReportDisplay>();
	
	public static void createDocumentReport(String reportType){
		String extractionQuery = config.getString("filters.extractioncriteriacode");
		String[] extCriteria = extractionQuery.split(";");
		for(int k = 0; k < extCriteria.length; k++){
			String extractionId = extCriteria[k];
			String utilityId = ExportDAOImpl.utilityIdIsExists(extractionId);
			if(utilityId != null){
				documentReport(utilityId, reportType);
			}else{
				reportLogger.warning("No records found for '" + extractionId + "' Extraction Criteria.");
			}
		}
	}
	
	public static void documentReport(String utilityId, String reportType){

//		if(utilityId == null || utilityId.length() == 0){
//			reportLogger.warning("Please specify Report Utility Code in config.xml file");
//			System.exit(0);
//		}
		
//		File theDir = new File(config.getString("repository.exportPath"));
//		if (!theDir.exists()){
//			reportLogger.warning("Export path not found!!!. Please update config.xml with a valid extraction path");
//			System.exit(0);
//		}

		reportLogger.info("DocumentReport :: createDocumentReport() : Execution Started..");
		ResultSet rs = ReportDAOImpl.getDocumentReport(utilityId);
		try {
			boolean invalidResultSet = true;
			while (rs.next()){
				drd = new DocumentReportDisplay();
				drd.setFolderValueCode1(rs.getString("FOLDER_VALUE_CODE"));
				drd.setDocumentCount1(rs.getString("SOURCE_DOC_CNT"));
				drd.setFolderSize1(rs.getString("SOURCE_DOC_SIZE_NBR"));
				drd.setFolderValueCode2(rs.getString("FOLDER_VALUE_CODE"));
				drd.setDocumentCount2(rs.getString(reportType + "_DOC_CNT"));
				drd.setFolderSize2(rs.getString(reportType + "_DOC_SIZE_NBR"));
				docReportList.add(drd);
				invalidResultSet = false;
			}
			if(invalidResultSet){
				reportLogger.warning("Invalid Report Utility Code. Please check config.xml file");
				System.exit(0);
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			createXLReport();
			reportLogger.info("DocumentReport :: Executed Successfully..");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	protected static void createXLReport() throws IOException {
		
		int i = 2;
		String sheetName = "", colHeaders = "";
		reportLogger.info("DocumentReport :: createDocumentReport() : Execution Started..");
		
		sheetName = idocsProperties.getProperty("Document_report_name");
		colHeaders = idocsProperties.getProperty("Document_report_columns");
		
		newWb = createXLSheet.createReportSheet(sheetName,colHeaders);
		newStyle = createXLSheet.createStyle(newWb, HSSFCellStyle.ALIGN_LEFT, "Calibri", 11, Font.BOLDWEIGHT_NORMAL);
		colorStyle = createXLSheet.createStyle(newWb, HSSFCellStyle.ALIGN_LEFT, "Calibri", 11, Font.BOLDWEIGHT_NORMAL, HSSFColor.ORANGE.index);

		newSheet = newWb.getSheet(sheetName);
		setReportHeaders(sheetName);

		for(DocumentReportDisplay drd : docReportList){
			i++;

	    	newRow = newSheet.createRow((short)i);
	    	createRow(0,drd.getFolderValueCode1());
	    	createRow(1,drd.getDocumentCount1());
	    	createRow(2,drd.getFolderSize1() + " KB");
	    	
	    	folderValue = (drd.getDocumentCount2() == null) ? "" : drd.getFolderValueCode2();
	    	folderCount = (drd.getDocumentCount2() == null) ? "" : drd.getDocumentCount2();
	    	folderSize = (drd.getFolderSize2() == null) ? "" :  drd.getFolderSize2() + " KB";
	    	
	    	createRow(3,folderValue);
	    	if(folderCount.equals(drd.getDocumentCount1())){
	    		createRow(4,folderCount);
			}else{
				createRow(4,folderCount,colorStyle);
			}
	    	createRow(5,folderSize);
		}		
		
		//Write data onto the XL Sheet.
		reportLogger.info("DocumentReport :: createDocumentReport() : sheetName : "+sheetName);
		createXLSheet.writeData(newWb,sheetName,idocsProperties, config);
		
		reportLogger.info("DocumentReport :: createDocumentReport() : Execution Completed..");
	}

	private static void setReportHeaders(String sheetName) {

		String header1 = idocsProperties.getProperty("REPORT_HEADERS1");
		String header2 = idocsProperties.getProperty("REPORT_HEADERS2");
		CellStyle headerStyle = createXLSheet.createStyle(newWb, HSSFCellStyle.ALIGN_CENTER, "Calibri", 12, Font.BOLDWEIGHT_BOLD);
		
		newRow = newSheet.createRow((short) 0);
	    Cell cell = newRow.createCell((short) 0);
	    cell.setCellValue(sheetName);
	    cell.setCellStyle(headerStyle);
	    newSheet.addMergedRegion(new CellRangeAddress( 0, 0, 0, 5));
		
		newRow = newSheet.createRow((short) 1);
	    cell = newRow.createCell((short) 0);
	    cell.setCellValue(header1);
	    cell.setCellStyle(headerStyle);
	    newSheet.addMergedRegion(new CellRangeAddress( 1, 1, 0, 2));
	    
	    cell = newRow.createCell((short) 3);
	    cell.setCellValue(header2);
	    cell.setCellStyle(headerStyle);
	    newSheet.addMergedRegion(new CellRangeAddress( 1, 1, 3, 5));
	    // first row (0-based) last row  (0-based) first column (0-based) last column  (0-based)
	}

	private static void createRow(int j, String folderValueCode1) {
		createRow(j, folderValueCode1, newStyle);
	}

	private static void createRow(int j, String folderValueCode1, CellStyle style) {
		createXLSheet.createCell(newWb, newRow, j, folderValueCode1, style);
		newSheet.autoSizeColumn((short)j);
	}

}
