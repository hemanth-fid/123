package org.ifc.idocs.migration.common;

import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.View;

import org.ifc.idocs.migration.extract.LogHelper;
import org.ifc.idocs.migration.extract.NotesSession;
import org.ifc.idocs.migration.transform.IFCNAB;
import org.ifc.idocs.migration.transform.WBNAB;

/**
 * @author VVellakkattumana
 *
 */
public class CommonUtils{

	private static Database ifcDatabse = null;
	private static Database wbnabDatabse = null;
	private static View ifcDbview = null;
	private static View wbnabDbview = null;
	
	CommonUtils(){
	}
	
	private static final AppConfig config = AppConfig.getInstance();
	private static final Logger exportDocLogger = LogHelper.getLogger(CommonUtils.class);

	/**
	 * extractUPI method extract UPI from a string : CN=Mihir Swain Kumar/OU=FO/O=IFC -> 9876541
	 * @param fullName
	 * @return String - UPI id
	 * @throws NotesException
	 */
	public static String extractUPI(String fullName) throws  NotesException {
		String UPI = "NA";
		String name = "";
		Document entryDoc = null;
		try{
			name = getCommonName(fullName);
			if (name != null){
				UPI = name;
			}else{
				name = fullName;
				exportDocLogger.warning("FullName of user not found. [name = "  +name+"]");
			}
			try{
				if(ifcDatabse == null){
					ifcDatabse = IFCNAB.getInstance();
					wbnabDatabse = WBNAB.getInstance();
				}
				if(ifcDbview == null){
					ifcDbview = ifcDatabse.getView("($Users)");
					wbnabDbview = wbnabDatabse.getView("($Users)");
				}
			}catch(NotesException ne){
				exportDocLogger.warning("NotesException : Unable to open NAB database");
			}

			if (ifcDbview !=null) { 
				try{
				 entryDoc = ifcDbview.getDocumentByKey(fullName, true);
				}catch(NotesException e){
					if(e.id == 4000 || e.id == 4678){
						exportDocLogger.warning("NotesException while trying to get Full Name from IFCNAB.Waiting to refresh the view");
//						Added to resolve the issue 'NotesCollection has become invalid'
						ifcDbview.refresh();
					}else
						exportDocLogger.log(Level.WARNING,"Error in ifcDbview.getDocumentByKey", e);
				}
				if (entryDoc == null) {
					try{
					entryDoc = wbnabDbview.getDocumentByKey(fullName, true);
					}catch(NotesException e){
						if(e.id == 4000 || e.id == 4678){
							exportDocLogger.warning("NotesException while trying to get Full Name from WBNAB.Waiting to refresh the view");
							wbnabDbview.refresh();
						}else
							exportDocLogger.log(Level.WARNING,"Error in wbnabDbview.getDocumentByKey", e);
					}
					if(entryDoc == null){
						UPI = name;
						exportDocLogger.info("Name \"" + fullName + "\" was not found in the WBNAB during UPI lookup.");
					}else{
						UPI = entryDoc.getItemValueString("UPI");
						if (UPI.length() == 0) {
							UPI = name;
							exportDocLogger.info("UPI for the name \"" + fullName + "\" is blank or was not found during UPI lookup.");
						}
						entryDoc.recycle();						
					}
				}else {
					UPI = entryDoc.getItemValueString("UPI");
					if (UPI.length() == 0) {
						UPI = name;
						exportDocLogger.info("UPI for the name \"" + fullName + "\" is blank or was not found during UPI lookup.");
					}
					
					entryDoc.recycle();
				}
			}else{
				exportDocLogger.warning("user view not found");
			}
		}catch(Exception e){
			exportDocLogger.log(Level.WARNING, "Exception : FullName of user not found", e);
		}
		return UPI;
	}

	/**
	 * getCommonName method extracts common name from Notes
	 * @param name
	 * @return String - name
	 * @throws NotesException
	 */
	public static String getCommonName(String name) throws NotesException {		
		String[] name1 = name.split("/");
		String name2 = name1[0];
		String name3 = (String) (name2.contains("CN=") ? name2.subSequence(3, name2.length()) : name2);
		return name3;
	}

	/**
	 * extractName method returns the name from fullName : CN=Mihir Swain Kumar -> Mihir Swain Kumar
	 * @param fullName
	 * @return String - name
	 * @throws NotesException
	 */
	public static String extractName(String fullName) throws NotesException {
		String name = NotesSession.getInstance().createName(fullName).getCommon();
		if (name.length() == 0) {
			return fullName;
		} else {
			if(name.contains("CN=")){
				String[] str = name.split("CN=");
				return str[0] + str[1];
			}else{
				return name;
			}
		}
	}

	/**
	 * DateFormatUtil method formats the date in to : dd-MMM-yy hh:mm:ss a Z
	 * @param dateStr
	 * @return String formatted date
	 */
	@SuppressWarnings("deprecation")
	public static String DateFormatUtil(String dateStr) {
		dateStr = convertTimezone(dateStr);
		Date date = new Date(dateStr);
		DateFormat df = new SimpleDateFormat("dd-MMM-yy hh:mm:ss a Z"); 
		String dStr = df.format(date); 
		String str = dStr.substring(0, dStr.length()-2);
		str = str + ":";
		dStr = str + dStr.substring(dStr.length()-2, dStr.length());
		return dStr;  
	}

	/**
	 * convertTimezone method converts the lotus notus time stamp to java time stamp : 01/05/2011 04:59:01 PM ZE5B -> 01/05/2011 04:59:01 PM +0530
	 * @param timeStamp
	 * @return String java timeStamp
	 */
	private static String convertTimezone(String timeStamp) {
		String zone = timeStamp.substring(22, timeStamp.length());
		if (zone.equals(" AST")) { zone = " -0400"; }
		else if (zone.equals(" BST")) { zone = " -1100"; }
		else if (zone.equals(" CDT")) { zone = " -0600"; }
		else if (zone.equals(" CEDT")){ zone = " +0100"; }
		else if (zone.equals(" CET")) { zone = " +0100"; }
		else if (zone.equals(" CST")) { zone = " -0600"; }
		else if (zone.equals(" EDT")) { zone = " -0500"; }
		else if (zone.equals(" EST")) { zone = " -0500"; }
		else if (zone.equals(" GDT")) { zone = " -0000"; }
		else if (zone.equals(" ")) { zone = " -0000"; }
		else if (zone.equals(" HST")) { zone = " -1000"; }
		else if (zone.equals(" MDT")) { zone = " -0700"; }
		else if (zone.equals(" MST")) { zone = " -0700"; }
		else if (zone.equals(" NDT")) { zone = " -0330"; }
		else if (zone.equals(" NST")) { zone = " -0330"; }
		else if (zone.equals(" PDT")) { zone = " -0800"; }
		else if (zone.equals(" PST")) { zone = " -0800"; }
		else if (zone.equals(" YDT")) { zone = " -0900"; }
		else if (zone.equals(" YST")) { zone = " -0900"; }
		else if (zone.equals(" YW1")) { zone = " -0100"; }
		else if (zone.equals(" YW2")) { zone = " -0200"; }
		else if (zone.equals(" Z-13")) { zone = " +1300"; }
		else if (zone.equals(" ZE10")) { zone = " +1000"; }
		else if (zone.equals(" ZE11")) { zone = " +1100"; }
		else if (zone.equals(" ZE12")) { zone = " +1200"; }
		else if (zone.equals(" ZE2")) { zone = " +0200"; }
		else if (zone.equals(" ZE3")) { zone = " +0300"; }
		else if (zone.equals(" ZE3B")) { zone = " +0330"; }
		else if (zone.equals(" ZE4")) { zone = " +0400"; }
		else if (zone.equals(" ZE4B")) { zone = " +0430"; }
		else if (zone.equals(" ZE5")) { zone = " +0500"; }
		else if (zone.equals(" ZE5B")) { zone = " +0530"; }
		else if (zone.equals(" ZE5C")) { zone = " +0545"; }
		else if (zone.equals(" ZE6")) { zone = " +0600"; }
		else if (zone.equals(" ZE6B")) { zone = " +0630"; }
		else if (zone.equals(" ZE7")) { zone = " +0700"; }
		else if (zone.equals(" ZE8")) { zone = " +0800"; }
		else if (zone.equals(" ZE9")) { zone = " +0900"; }
		else if (zone.equals(" ZE9B")) { zone = " +0930"; }
		else if (zone.equals(" ZW1")) { zone = " -0100"; }
		else if (zone.equals(" ZW12")) { zone = " -1200"; }
		else if (zone.equals(" ZW2")) { zone = " -0200"; }
		else if (zone.equals(" ZW3")) { zone = " -0300"; } 
		else { zone = " -0000"; }
		timeStamp = (String) timeStamp.subSequence(0, 22);
		timeStamp += zone;
		return timeStamp;
	}

	public static void checkForConfigFile(Properties idocsProperties, InputStream inputStream, String inputType, boolean isExit){
		if(inputStream != null){
			try{
				idocsProperties.load(inputStream);
			}catch(Exception e){
				exportDocLogger.warning("Exception occured " + e);
				exportDocLogger.log(Level.WARNING,"RuntimeException-", e);
				System.exit(0);
			}
			finally{
				idocsProperties = null;
				inputStream =  null;
			}
		}else{
			print("Cannot locate " + inputType + " Properties file. Please check the file name or the file location", isExit);
		}
	}

	public static void checkConfigAttributes(String attribute, String message, boolean isExit) {
		String element = config.getString(attribute);
		if(element == null || element.length() == 0){
			print("Please specify " + message + " in config.xml file", true);
		}
	}

	private static void print(String message, boolean isExit){
		exportDocLogger.warning(message);
		if(isExit){
			System.exit(0);
		}		
	}
}
