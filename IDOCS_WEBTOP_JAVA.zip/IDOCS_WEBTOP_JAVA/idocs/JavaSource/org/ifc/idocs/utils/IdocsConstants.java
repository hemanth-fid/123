/**
* This class is used to provide constants used in iDocsUtil and TopicPageView class
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.utils;

public class IdocsConstants {

	public static final String IDOCS_PROPERTY_FILE = "/idocsProps.properties";
	
	public static final String PROJ_FOLDER_TYPE="idocs_project_folder";
	public static final String INSTITUTION_FOLDER_TYPE = "idocs_institution_folder";
	public static final String COUNTRY_FOLDER_TYPE = "idocs_country_folder";
	public static final String SUB_FOLDER_TYPE = "idocs_sub_folder";
	public static final String PROJ_DOC_TYPE="idocs_project_doc";
	public static final String INSTITUTION_DOC_TYPE = "idocs_institution_doc";
	public static final String COUNTRY_DOC_TYPE = "idocs_country_doc";
	public static final String IDOCS_DOC_TYPE = "idocs_document";
	public static final String IDOCS_FOLDER_TYPE = "idocs_folder";
	public static final String IDOCS_LIFECYCLE="iDocs_lifecycle";
	public static final String MSG_OBJECTID = "objectId";
	public static final String MSG_FOLDERID="folderId";
	// ==========================Aspect Name ==============================
  	public static final String R_ASPECT_NAME = "r_aspect_name";
  	public static final String IDOCS_EMAIL_DOC_ASPECT = "idocs_email_doc_aspect";
  	public static final String IDOCS_SCANNING_DOC_ASPECT = "idocs_scanning_doc_aspect";
	
  	// ====================================================================
	public static final String DOC_STATE_DRAFT="Draft";
	public static final String DOC_STATE_RELEASED="Released";
	
	public static final int PROJECT_TYPE=1;
	public static final char INSTITUTION_TYPE = 2;
	public static final char COUNTRY_TYPE = 3;

	public static final String STR_CRU_APPROVER = "COC/VP Response";
    public static final String STR_TOKEN_SEPERATOR = "@@";
    public static final String STR_COC_ASSISTANTS_GRP = "COC Assistants";
    public static final String STR_COC_MEMBERS_GRP = "COC Members";
    public static String STR_REAL_PATH = null;
    public static final String STR_LOGGER_FILE_PATH = "custom/idocsfiles/idocsdocumentum.log";
    public static final String STR_ERROR_MESSAGES_XML_FILE_PATH = "custom/idocsfiles/ErrorMessagesConfig.xml";
	
	public static final String MAIL_TO = "TO";
	public static final String MAIL_CC = "CC";
	public static final String MAIL_BCC = "BCC";
	public static final String MAIL_BODY = "body";
	public static final String MAIL_SUBJECT = "subject";
	public static final String MAIL_CONTENT_TYPE="contentType";
	
	public static final String MSG_ITEM_VALUE = "item_value";
	public static final String MSG_ITEM_KEY = "item_key";
	public static final String MSG_CREATE_ROLE = "create_role";
	public static final String MSG_CREATE_ROLE_TYPE = "create_role_type";
	public static final String MSG_EDIT_ROLE = "edit_role";
	public static final String MSG_EDIT_ROLE_TYPE = "edit_role_type";
	public static final String MSG_ERROR_MESSAGES = "error_messages";
	public static final String MSG_IDESK_PROJECT_ROLE_TYPE = "0";
	public static final String MSG_LDAP_GROUP_TYPE = "1";
	public static final String MSG_DM_GROUP_TYPE = "2";
	public static final String MSG_DM_USER_TYPE = "3";
	public static final String MSG_PROJECT_TEAM_TYPE = "4";
	
	
	public static final String COC_ASSISTANTS = "COC Assistants";
	public static final String COC_MEMBERS = "COC Members";
	public static final String DOC_DISCUSSION_COC_VP_TITLE="DOC_DISCUSSION_COC_VP_TITLE";
	
	public static final String DOC_DISCUSSION_EMAIL_BODY_DIV = "DOC_DISCUSSION_EMAIL_BODY_DIV";
	public static final String DOC_DISCUSSION_STATIC_MESSAGE_1 = "DOC_DISCUSSION_STATIC_MESSAGE_1";
	public static final String DOC_DISCUSSION_STATIC_MESSAGE_2 = "DOC_DISCUSSION_STATIC_MESSAGE_2";
	public static final String DOC_DISCUSSION_STATIC_MESSAGE_2_1="DOC_DISCUSSION_STATIC_MESSAGE_2_1";
	public static final String COCVP_GRP_MEMBER_QUERY = "COCVP_GRP_MEMBER_QUERY";
	public static final String PROJDOC_DETAILS_QRY="PROJDOC_DETAILS_QRY";
	public static final String INSTITUTION_DOC_DETAILS_QRY="INSTITUTION_DOC_DETAILS_QRY";
	public static final String COUNTRYDOC_DETAILS_QRY = "COUNTRY_DOC_QRY";
	public static final String USER_ADDRESS_QUERY="USER_ADDRESS_QUERY";
	public static final String DOC_PROJID_QUERY= "DOC_PROJECT_ID_QUERY";
	public static final String INSTIT_FOLDER_PROJID_QUERY ="INSTIT_FOLDER_PROJID_QUERY";
	
	
	public static final String OBJECT_NAME = "object_name";
	public static final String PROJ_SHORT_NAME = "project_short_nme";
	public static final String PROJ_ID = "project_id";
	public static final String MSG_INSTITUTION_NBR = "institution_nbr";
	public static final String MSG_INSTITUTION_ROLE_TYPE_CODE= "instit_role_type_code";
	public static final String R_OBJECT_TYPE="r_object_type";
	public static final String R_OBJECT_ID="r_object_id";
	public static final String USER_EMAIL = "user_address";
	public static final String USER_NAME = "user_name";
	public static final String MSG_COMMA=",";
	public static final String MSG_Q_COMMA_Q="','";
	public static final String MSG_QUOTES = "'";
	public static final String MSG_C_DQ_C ="''";
	public static final String MSG_UNDERSCORE = "_";
	
	public static final String MSG_PROJECT_TIER_NME="project_tier_nme";
	public static final String MSG_PROJECT_TIER_CODE="project_tier_code";
	public static final String INSTITUTION_ID = "institution_nbr";
	public static final String INSTITUTION_SHORT_NAME = "instit_short_nme";
	
	public static final String COUNTRY_CODE = "country_code";
	public static final String COUNTRY_NAME = "country_nme";
	
	//Constants for VIEW PROJECT/PARTNER Folders component
    public static final String CLIENT_COMPANY_FOLDER_QRY = "CLIENT_COMPANY_FOLDER_QRY";
    public static final String PROJECT_FOLDER_QRY = "PROJECT_FOLDER_QRY";
    public static final String STR_SEARCH_COUNT_INSTIT_RESULTS_QRY="SEARCH_COUNT_INSTIT_QRY";
    public static final String STR_SEARCH_COUNT_PROJECT_RESULTS_QRY="SEARCH_COUNT_PROJECT_QRY";
    public static final String STR_ORIG_QRY="strOriginalQuery";

	// Process Diagram Constant.Added by Brajesh on 28-SEP-2010
    
    public static final String STR_INPUT_TIME_PATTERN = "yyyy-MM-dd'T'HH:mm:ss'Z'"; 
    public static final String STR_OUTPUT_TIME_PATTERN= "MM-dd-yyyy hh:mm a ";
    public static final String STR_SVG_IMAGE_ICON_LOCATION ="svgImageIconLocation";
    public static final String STR_SVG_IMAGE_ICON_LOCATION_REAL_PATH ="svgImageIconLocationRealPath";
    public static final String STR_SVG_EXTENSION = ".svg";
    public static final String STR_SVG_PROCESS_DIAGRAM_FILES_LOCATION = "SvgProcessDiagramFilesLocation";
    public static final String STR_SVG_PROCESS_DIAGRAM_VIRTUAL_LOCATION = "virtualLocation";
    public static final String STR_XSL_TO_SVG = "XslToSvgTemp";
    
    //Constants for invoking search component
    public static final String CUSTOM_SEARCH = "search";
    public static final String SEARCH_QRYTYPE_ARG_NME="queryType";
    public static final String DQL_QRYTYPE="dql";
    public static final String SEARCH_QRY_ARG_NME="query";
    
    //Constants for PRODUCT INTEGRATION
    public static final String MSG_PRODUCT_TYPE_CODE = "product_wf_type_code";
    public static final String PRODUCT_DRL_UPDATE_SERVLET_URL="PRODUCT_DRL_UPDATE_SERVLET_URL";
    public static final String QRY_WORKFLOW_PRODUCT = "QRY_WORKFLOW_PRODUCT";
    
    
    
   	public static final String USER_ID = "userid";
   	public static final String MAIN_RESOURCE_ID = "mainresourceid";
   	public static final String WORKFLOW_NBR = "workflow_nbr";
   	public static final String MSG_WORKFLOW_STATUS = "workflow_status";
   	public static final String WORKFLOW_TYPE_CODE = "workflow_type_code";
   	public static final String DOC_URL = "doc_url";
	
	public static final String QRY_INSERT_AUDIT_REPORT = "";
	//Added for TRIP integration
	public static final String SUBMISSION_NBR = "submission_nbr";
	public static final String QRY_TEMPLATE_CODE = "QRY_TEMPLATE_CODE";
	public static final String TEMPLATE_CODE ="template_code";
	public static final String MSG_YES = "YES";
	public static final String MSG_IS_LOADED_FROM_CREATE = "is_loaded_from_create";


	public static final String MSG_FOLDER_CATEGORY = "folder_category_suggestions";

	public static final String MSG_INSTIT_ROLE_TYPE_CODE = "instit_role_type_code";

	public static final String PROJECT_STATUS_CODE = "project_status_code";

	public static final String MSG_HASH = "#";

	public static final String R_PACKAGE_TYPE = "r_package_type";
	public static final String R_LOCK_OWNER = "r_lock_owner";
	public static final String R_PACKAGE_NAME = "r_package_name";

	public static final String R_COMPONENT_ID = "r_component_id";
	public static final String R_COMPONENT_CHRON_ID = "r_component_chron_id";

	public static final String MSG_WORKFLOW_IS_REQUIRED = "1";

	public static final String MSG_WORKFLOW_IS_NOT_REQUIRED = "0";
	public static final String EMAIL = "EMAIL";
	public static final String SCANNING = "SCANNING";
	public static final String CONFLICT_OF_INTEREST_ROLE = "CONFLICT_OF_INTEREST_ROLE";

	public static final String MSG_I_CHRONICLE_ID = "i_chronicle_id";	
	public static final String MSG_IS_CREATED_FROM_BIZ_TEMPLATE="iscreatedfrombiztemplate";
	public static final String STR_A_CONTENT_TYPE="a_content_type";
	public static final String QRY_LDAP_GROUP_MEMBER="QRY_LDAP_GROUP_MEMBER"; 
}
