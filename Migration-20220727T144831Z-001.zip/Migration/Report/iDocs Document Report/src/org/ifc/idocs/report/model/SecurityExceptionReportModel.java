package org.ifc.idocs.report.model;

import java.sql.Timestamp;

public class SecurityExceptionReportModel {
	
	private String reportUtilityCode;
	private String folderValueCode;
	private String folderTypeCode;
	private String sourceDocId;
	private String sourceDocUniqueId;
	private String sourceDocName;
	private String sourceSecurityClassCode;
	private String sourceDocVerNbr;
	private String targetDocId;
	private String targetDocUniqueId;
	private String targetDocName;
	private String targetSecurityClassCode;
	private String targetDocVerNbr;
	private Timestamp docLastModDate;
	private String countryCode;
	private String regionName;
	private String projectCategoryNameCode;

	public SecurityExceptionReportModel(){}
	
	public SecurityExceptionReportModel(SecurityExceptionReportModel ser){
		this.reportUtilityCode = ser.reportUtilityCode;
		this.folderValueCode = ser.folderValueCode;
		this.folderTypeCode = ser.folderTypeCode;		
		this.sourceDocId = ser.sourceDocId;
		this.sourceDocName = ser.sourceDocName;
		this.sourceSecurityClassCode = ser.sourceSecurityClassCode;
		this.sourceDocVerNbr = ser.sourceDocVerNbr;
		this.targetDocId = ser.targetDocId;
		this.targetDocName = ser.targetDocName;
		this.targetSecurityClassCode = ser.targetSecurityClassCode;
		this.targetDocVerNbr = ser.targetDocVerNbr;
		this.sourceDocUniqueId = ser.sourceDocUniqueId;
		this.targetDocUniqueId = ser.targetDocUniqueId;
		this.docLastModDate = ser.docLastModDate;
		this.countryCode = ser.countryCode;
	}
	
	public String getFolderValueCode() {
		return folderValueCode;
	}
	public void setFolderValueCode(String folderValueCode) {
		this.folderValueCode = folderValueCode;
	}
	public String getReportUtilityCode() {
		return reportUtilityCode;
	}
	public void setReportUtilityCode(String reportUtilityCode) {
		this.reportUtilityCode = reportUtilityCode;
	}
	public String getFolderTypeCode() {
		return folderTypeCode;
	}
	public void setFolderTypeCode(String folderTypeCode) {
		this.folderTypeCode = folderTypeCode;
	}
	public String getSourceDocId() {
		return sourceDocId;
	}
	public void setSourceDocId(String sourceDocId) {
		this.sourceDocId = sourceDocId;
	}
	public String getSourceDocName() {
		return sourceDocName;
	}
	public void setSourceDocName(String sourceDocName) {
		this.sourceDocName = sourceDocName;
	}
	public String getSourceSecurityClassCode() {
		return sourceSecurityClassCode;
	}
	public void setSourceSecurityClassCode(String sourceSecurityClassCode) {
		this.sourceSecurityClassCode = sourceSecurityClassCode;
	}
	public String getSourceDocVerNbr() {
		return sourceDocVerNbr;
	}
	public void setSourceDocVerNbr(String sourceDocVerNbr) {
		this.sourceDocVerNbr = sourceDocVerNbr;
	}
	public String getTargetDocId() {
		return targetDocId;
	}
	public void setTargetDocId(String targetDocId) {
		this.targetDocId = targetDocId;
	}
	public String getTargetDocName() {
		return targetDocName;
	}
	public void setTargetDocName(String targetDocName) {
		this.targetDocName = targetDocName;
	}
	public String getTargetSecurityClassCode() {
		return targetSecurityClassCode;
	}
	public void setTargetSecurityClassCode(String targetSecurityClassCode) {
		this.targetSecurityClassCode = targetSecurityClassCode;
	}
	public String getTargetDocVerNbr() {
		return targetDocVerNbr;
	}
	public void setTargetDocVerNbr(String targetDocVerNbr) {
		this.targetDocVerNbr = targetDocVerNbr;
	}
	public String getSourceDocUniqueId() {
		return sourceDocUniqueId;
	}
	public void setSourceDocUniqueId(String sourceDocUniqueId) {
		this.sourceDocUniqueId = sourceDocUniqueId;
	}
	public String getTargetDocUniqueId() {
		return targetDocUniqueId;
	}
	public void setTargetDocUniqueId(String targetDocUniqueId) {
		this.targetDocUniqueId = targetDocUniqueId;
	}
	public Timestamp getDocLastModDate() {
		return docLastModDate;
	}
	public void setDocLastModDate(Timestamp docLastModDate) {
		this.docLastModDate = docLastModDate;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getRegionName() {
		return regionName;
	}
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	public String getProjectCategoryNameCode() {
		return projectCategoryNameCode;
	}
	public void setProjectCategoryNameCode(String projectCategoryNameCode) {
		this.projectCategoryNameCode = projectCategoryNameCode;
	}
}
