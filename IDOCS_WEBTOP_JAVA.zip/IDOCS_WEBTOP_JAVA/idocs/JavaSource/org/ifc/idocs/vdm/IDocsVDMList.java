package org.ifc.idocs.vdm;


import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.form.common.BreadcrumbService;
import com.documentum.web.formext.action.ActionService;
import com.documentum.web.formext.control.action.ActionControl;
import com.documentum.web.formext.control.docbase.VDMTreeGrid;
import com.documentum.web.formext.docbase.ObjectCacheUtil;
import com.documentum.webtop.webcomponent.vdm.VDMList;

public class IDocsVDMList extends VDMList {
	private String virtualdocumentObjectId="";
	public boolean aspectExistance=false;
	public static final String STR_A_CONTENT_TYPE="a_content_type"; 
	/**
	 * 
	 */
	private static final long serialVersionUID = 2664480336502542859L;
    public  String setFormatStrig="";
    IDfSysObject dfSysObject= null;
    public void onInit(ArgumentList args) {
		super.onInit(args);
		virtualdocumentObjectId=args.get("objectId");
		try {
			dfSysObject = (IDfSysObject)ObjectCacheUtil.getObject(getDfSession(), virtualdocumentObjectId);
			DfLogger.info(this, " onInit objectId"+virtualdocumentObjectId, null, null);
			aspectExistance=getAspectExistance(virtualdocumentObjectId);
			if(aspectExistance && dfSysObject != null){
				setFormatStrig=dfSysObject.getString(IdocsConstants.STR_A_CONTENT_TYPE);
			}else{
				setFormatStrig=getRootDocumentFormat(virtualdocumentObjectId);
			}
		} catch (DfException e) {
			DfLogger.error(this, " onInit :"+e.getMessage(), null, e);
		}
	}
 /**
  * 
  */
	protected void updateCurrentVdm(String strCurrentVdmId, String strCurrentVdmPath)
    {
		super.updateCurrentVdm(strCurrentVdmId,strCurrentVdmPath);
        m_strCurrentVdmPath = strCurrentVdmPath;
        
    }

    /**
	 * 
	 */
	
	public void onaction(ActionControl actionControl, ArgumentList args)
    {
        BreadcrumbService breadcrumbService = BreadcrumbService.getBreadcrumbService();
        if(breadcrumbService.getMode() == com.documentum.web.form.common.BreadcrumbService.BreadcrumbMode.RELATIVE)
        {
            String selection = args.get("selection");
            if(selection != null && selection.charAt(0) == '1')
            {
                int index = m_strCurrentVdmPath.lastIndexOf("/");
                if(index > 0){
                    args.add("objectNamePrefix", m_strCurrentVdmPath.substring(0, index).concat("/"));
                    System.out.println("m_strCurrentVdmPath.substring(0, index).concat( ::"+m_strCurrentVdmPath.substring(0, index).concat("/"));
                }
            } else
            {
                args.add("objectNamePrefix", m_strCurrentVdmPath.concat("/"));
            }
        }
       
        String actionList=IdocsUtil.getMessage("DOC_ACTION_LIST");
        if(actionControl != null && actionControl.getName().trim().length() >0){
        	String actionValue= args.get("action");
        	if(actionValue != null
        			&& actionValue.length() >0
        			&& actionList != null
        			&& actionList.trim().length() >0
        			&& IdocsUtil.checkIfTokenPresent(actionList,actionValue.trim(),",")){
            	args.add(CALLER_COMPONENT,VDMLIST);
            	args.add(VDM_ROOT,virtualdocumentObjectId);
            	DfLogger.info(this, "Action Name "+actionValue,null,null);
        	}else{
        		//DfLogger.info(this, "Not in required actionlist",null,null);
        	}
        		super.onaction(actionControl, args);
        }else{
        	super.onaction(actionControl, args);
        }
        VDMTreeGrid treegrid = (VDMTreeGrid)getControl("vdmgrid", VDMTreeGrid.class);
        treegrid.setRefreshNeeded(true);
    }
	
	/**
	 * 
	 * @param objectId
	 * @return
	 */
	private boolean getAspectExistance(String objectId){
		boolean aspectExistanceValue=false;
		if(dfSysObject != null){
			try {
				if(dfSysObject.getBoolean("is_emaildoc") ||	dfSysObject.getBoolean("is_scandoc")){
					aspectExistanceValue=true;
				}
			} catch (DfException e) {
				DfLogger.info(this, "", null, null);
			}
		}else{
			String aspectQuery=IdocsUtil.getMessage("QRY_ASPECT");
			aspectQuery=aspectQuery.replace(STRING_REPLACE_OBJECTID,("'"+objectId+"'"));
			IDfCollection docAspectsCollection = null;
			String aspectStrValue = "";
			DfLogger.info(this, " getAspectExistance VDM doc("+objectId+") aspects checking Query :: "+aspectQuery, null, null);
	    	try {
	    		docAspectsCollection = IdocsUtil.executeQuery(getDfSession(),aspectQuery,IDfQuery.DF_EXEC_QUERY);
	    		int i=0;
	    		while(docAspectsCollection.next()){
	    			if(i>0){
	    				aspectStrValue=aspectStrValue+",";
	    			}
	    			aspectStrValue = aspectStrValue+docAspectsCollection.getString(IdocsConstants.R_ASPECT_NAME);
	    			i++;
	    		}    		
	    		DfLogger.info(this, "getAspectExistance VDM doc("+objectId+") aspectStrValue :: "+aspectStrValue, null, null);
	    	
			} catch (Exception e) {
	    		DfLogger.error(this, "getAspectExistance  : " + e.getMessage(), null, null);
	    	}finally{
	    			try {
					if(docAspectsCollection != null)
						   docAspectsCollection.close();
					} catch (DfException e) {
						DfLogger.error(this, " getAspectExistance : " + e.getMessage(), null, null);
					}
	    	 }
	    	if(aspectStrValue != null 
					&& aspectStrValue.trim().length() >0){
						aspectExistanceValue=IdocsUtil.checkIfTokenPresent(aspectStrValue, IdocsUtil.getMessage("STR_ASPECT_EMAIL"), IdocsConstants.MSG_COMMA);		
			}else{
				aspectExistanceValue=false;
				DfLogger.info(this, " getAspectExistance aspectExistance:"+aspectExistance, null, null);
			}
		}
		return 	aspectExistanceValue;
	}
	
	public String getRootDocumentFormat(String objectId){
		String formatTypeStr=IdocsUtil.getMessage("QRY_CONENTTYPE");
		formatTypeStr=formatTypeStr.replace(STRING_REPLACE_OBJECTID,("'"+objectId+"'"));
		IDfCollection docFormatCollection = null;
		String contentType=null;
    	try {
    		docFormatCollection = IdocsUtil.executeQuery(getDfSession(),formatTypeStr,IDfQuery.DF_EXEC_QUERY);
    		while(docFormatCollection.next()){
    			contentType=docFormatCollection.getString(A_CONTENT_TYPE);
    		}    		
    			DfLogger.info(this,  "getRootDocumentFormat VDM doc("+objectId+") contentType :: "+contentType, null, null);
		} catch (Exception e) {
    		DfLogger.error(this, "getRootDocumentFormat  : " + e.getMessage(), null, null);
    	}finally{
    		try {
				if(docFormatCollection != null)
					docFormatCollection.close();
				} catch (DfException e) {
					DfLogger.error(this, " getRootDocumentFormat : " + e.getMessage(), null, null);
				}
    	 }
         if(contentType != null && contentType.trim().length()>0){
        	  DfLogger.info(this, "getRootDocumentFormat VDM doc("+objectId+") retrun contentType :: "+contentType, null, null);
        	  return contentType;
		 }else  return UNKNOWN_FORMAT;
	}
	
	public void onClickRootDocument(Control control, ArgumentList args)
    {
		    if( virtualdocumentObjectId != null 
		    		&& virtualdocumentObjectId.trim().length() >0 
		    		&& ! virtualdocumentObjectId.equals(IDocsConstants.BLANK_OBJECT_ID)){
		    	args.replace("objectId",virtualdocumentObjectId);
		    	ActionService.execute(actionToInvoke, args, this.getContext(), this, null);
		    }
	 }
		    
	
	private static final String UNKNOWN_FORMAT="unknown";
	private static final String A_CONTENT_TYPE="a_content_type";
	private static final String actionToInvoke="viewcontent";
	private static final String VDMLIST="vdmlist";
	private static final String VDM_ROOT="vdmRootObject";
	private static final String CALLER_COMPONENT="callerComponent";
	private String m_strCurrentVdmPath="";
	private static final String STRING_REPLACE_OBJECTID="'<objectId>'";
	
 }
