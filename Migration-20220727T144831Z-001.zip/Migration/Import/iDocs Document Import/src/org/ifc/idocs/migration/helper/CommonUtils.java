package org.ifc.idocs.migration.helper;

import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * @author VVellakkattumana
 *
 */
public class CommonUtils{


	CommonUtils(){
	}
	/**
	 * DateFormatUtil method formats the date in to : dd-MMM-yy hh:mm:ss a Z
	 * @param dateStr
	 * @return String formatted date
	 */
	@SuppressWarnings("deprecation")
	public static String DateFormatUtil(String dateStr) {
		dateStr = convertTimezone(dateStr);
		Date date = new Date(dateStr);
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a"); 
		String dStr = df.format(date); 
		String str = dStr.substring(0, dStr.length()-2);
		str = str + ":";
		dStr = str + dStr.substring(dStr.length()-2, dStr.length());
		return dStr;  
	}

	/**
	 * convertTimezone method converts the lotus notus time stamp to java time stamp : 01/05/2011 04:59:01 PM ZE5B -> 01/05/2011 04:59:01 PM +0530
	 * @param timeStamp
	 * @return String java timeStamp
	 */
	private static String convertTimezone(String timeStamp) {
		String zone = timeStamp.substring(22, timeStamp.length());
		if (zone.equals(" AST")) { zone = " -0400"; }
		else if (zone.equals(" BST")) { zone = " -1100"; }
		else if (zone.equals(" CDT")) { zone = " -0600"; }
		else if (zone.equals(" CEDT")){ zone = " +0100"; }
		else if (zone.equals(" CET")) { zone = " +0100"; }
		else if (zone.equals(" CST")) { zone = " -0600"; }
		else if (zone.equals(" EDT")) { zone = " -0500"; }
		else if (zone.equals(" EST")) { zone = " -0500"; }
		else if (zone.equals(" GDT")) { zone = " -0000"; }
		else if (zone.equals(" ")) { zone = " -0000"; }
		else if (zone.equals(" HST")) { zone = " -1000"; }
		else if (zone.equals(" MDT")) { zone = " -0700"; }
		else if (zone.equals(" MST")) { zone = " -0700"; }
		else if (zone.equals(" NDT")) { zone = " -0330"; }
		else if (zone.equals(" NST")) { zone = " -0330"; }
		else if (zone.equals(" PDT")) { zone = " -0800"; }
		else if (zone.equals(" PST")) { zone = " -0800"; }
		else if (zone.equals(" YDT")) { zone = " -0900"; }
		else if (zone.equals(" YST")) { zone = " -0900"; }
		else if (zone.equals(" YW1")) { zone = " -0100"; }
		else if (zone.equals(" YW2")) { zone = " -0200"; }
		else if (zone.equals(" Z-13")) { zone = " +1300"; }
		else if (zone.equals(" ZE10")) { zone = " +1000"; }
		else if (zone.equals(" ZE11")) { zone = " +1100"; }
		else if (zone.equals(" ZE12")) { zone = " +1200"; }
		else if (zone.equals(" ZE2")) { zone = " +0200"; }
		else if (zone.equals(" ZE3")) { zone = " +0300"; }
		else if (zone.equals(" ZE3B")) { zone = " +0330"; }
		else if (zone.equals(" ZE4")) { zone = " +0400"; }
		else if (zone.equals(" ZE4B")) { zone = " +0430"; }
		else if (zone.equals(" ZE5")) { zone = " +0500"; }
		else if (zone.equals(" ZE5B")) { zone = " +0530"; }
		else if (zone.equals(" ZE5C")) { zone = " +0545"; }
		else if (zone.equals(" ZE6")) { zone = " +0600"; }
		else if (zone.equals(" ZE6B")) { zone = " +0630"; }
		else if (zone.equals(" ZE7")) { zone = " +0700"; }
		else if (zone.equals(" ZE8")) { zone = " +0800"; }
		else if (zone.equals(" ZE9")) { zone = " +0900"; }
		else if (zone.equals(" ZE9B")) { zone = " +0930"; }
		else if (zone.equals(" ZW1")) { zone = " -0100"; }
		else if (zone.equals(" ZW12")) { zone = " -1200"; }
		else if (zone.equals(" ZW2")) { zone = " -0200"; }
		else if (zone.equals(" ZW3")) { zone = " -0300"; } 
		else { zone = " -0000"; }
		timeStamp = (String) timeStamp.subSequence(0, 22);
		timeStamp += zone;
		return timeStamp;
	}
}
