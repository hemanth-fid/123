/**
* Class to store all IDocs Constants for better useablility.
* 
* ########################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* ########################################################################
* Parag Doshi			10/12/2010		1.0					created 
* ########################################################################
*/
package org.ifc.idocs.constants;

public class IDocsConstants
{
    public static final String STR_CRU_APPROVER = "COC/VP Response";
    public static final String STR_TOKEN_SEPERATOR = "@@";
    public static final String STR_COC_ASSISTANTS_GRP = "COC Assistants";
    public static final String STR_COC_MEMBERS_GRP = "COC Members";
    public static String STR_REAL_PATH = null;
    public static final String STR_LOGGER_FILE_PATH = "custom/idocsfiles/idocsdocumentum.log";
    public static final String STR_ERROR_MESSAGES_XML_FILE_PATH = "custom/idocsfiles/ErrorMessagesConfig.xml";
    public static final String STR_CABINETS_PATH="/cabinets";
    public static final String STR_IDOCS_CELLLIST_ATTRIBUTE="taskName";
    
    
    
    public static final String NEW_VERSION = "_NEW_";
    public static final String BLANK_OBJECT_ID = "0000000000000000";
    public static final String POLICY_ID = "r_policy_id";
    public static final String MINOR_VERSION_ID = "0.1";
    
    
	public static final String MSG_IDOCS_COUNTRY_DOC="idocs_country_doc";
	public static final String MSG_IDOCS_INSTITUTION_DOC = "idocs_institution_doc";
	public static final String MSG_IDOCS_PROJECT_DOC = "idocs_project_doc";
	public static final String QRY_GRUOP_FROM = "select i_all_users_names from dm_group where group_name='" ;
	public static final String QRY_SUFF_ALLUSER_NAMES = "' and ANY i_all_users_names='";
	public static final String MSG_OFFICIAL_CODE="O";
	public static final String MSG_CONFIDENTIAL_CODE="C";
	public static final String MSG_STRICTLY_CONFIDENTIAL_CODE="S";
	public static final String MSG_DOC_SUBTYPE_CODE="doc_subtype_code";
	public static final String MSG_IDOCS_PROJ_FOLDER="idocs_project_folder";
	public static final String MSG_IDOCS_INSTIT_FOLDER="idocs_institution_folder";
	public static final String MSG_IDOCS_COUNTRY_FOLDER="idocs_country_folder";
	public static final String MSG_IDOCS_DOCUMENT = "idocs_document";
	public static final String MSG_IDOCS_FOLDER = "idocs_folder";
	public static final String MSG_CONTENT_MODIFIED_DATE="content_modify_date";
	public static final String SELECTED_TRIP_NBR_HIDDEN = "selectedTripNo";
	public static final String TEMPLATE_DATAGRID="tripgrid";
	public static final String STR_R_PACKAGE_NME="r_package_name";
	public static final String STR_R_COMPONENT_ID="r_component_id";
	public static String MSG_IDOCS_LIFECYCLE = "iDocs_lifecycle";
    public static final String MSG_SEC_CLASSIFICATION = "security_classification";
	public static final String MSG_STATE_RELEASED="Released";
	public static final String MSG_SEC_CLASSIFICATION_CODE="sec_classification_code";
	public static final String MSG_RELEASED_STATE_NUMBER = "1"; 
	public static final String MSG_DRAFT_STATE_NUMBER = "0"; // Change it to 5 For testing this since we dont have any document in Released state
	
	public static final boolean FLAG_RENDER_READONLY = true;
	public static final String MSG_I_CHRONICLE_ID="i_chronicle_id";
	public static final String MSG_OBJECT_NAME = "object_name";
	public static final String MSG_DOC_STATE =  "doc_state";
	public static final String MSG_COUNTRY_NME = "country_nme";
	public static final String MSG_PROJECT_SHORT_NME="project_short_nme";
	public static final String MSG_ONE = "1";
	public static final String MSG_IS_VIRTUAL_DOC = "r_is_virtual_doc";
	public static final String MSG_DM_DOC_TYPE_PREF_CODE = "09";
	
	public static final String MSG_OBJECTID = "objectId";
	public static final String MSG_R_LOCK_OWNER = "r_lock_owner";
	public static final String MSG_OWNER_NAME = "owner_name";
	public static final String MSG_R_OBJECT_ID = "r_object_id";
	public static final String MSG_PROJ_TIER_CODE="project_tier_code";
	public static final String MSG_TEMPLATE_CODE = "template_code";
	public static final String MSG_TEMPLATE_TITLE ="template_title";
	public static final String MSG_WORKFLOW_STATUS = "workflow_status";
	public static final String MSG_EMPTY_STRING = "" ;
	
	public static final String MSG_PR_ED_OFF_GROUP = "idocs_pr_#_ed_off_grp";
	public static final String MSG_INST_ED_OFF_GRUP = "idocs_inst_#_ed_off_grp";
	public static final String MSG_PR_ED_CON_GROUP = "idocs_pr_#_ed_con_grp";
	public static final String MSG_INST_ED_CON_GROUP = "idocs_inst_#_ed_con_grp";
	public static final String MSG_PR_TL_GROUP = "idocs_pr_#_tl_grp";
	public static final String MSG_PR_PO_GROUP = "idocs_pr_#_po_grp";
	public static final String MSG_INST_TL_GROUP = "idocs_inst_#_tl_grp";
	public static final String MSG_INST_PO_GROUP = "idocs_inst_#_po_grp";
	public static final String MSG_R_OBJECT_TYPE = "r_object_type";
	public static final String MSG_INTITUTION_CLIENT_ROLE="104";
	public static final String MSG_WORKFLOW_RESTARTABLE = "1";
	
	public static String MSG_IS_WORKFLOW_REQUIRED = "isworkflowrequired";
	public static String MSG_IS_WORKFLOW_RESTARTABLE= "isworkflowrestartable";
	public static String MSG_COMPLETED= "Completed";
	public static final String R_WORKFLOW_ID = "r_workflow_id";
	public static final String MSG_IS_MIGRATED = "is_migrated";
	public static final String MSG_IDOCS_PREFIX = "idocs_";
	public static final String MSG_SOU_CODE = "sou_code";
	
	public static final String MSG_DMS_ENTITY_ID = "701";
	public static final String MSG_CRR_ENTITY_ID = "301";
	public static final String MSG_PSR_ENTITY_ID = "302";
	public static final String MSG_GHG_ENTITY_ID = "253";
	public static final String MSG_LABEL_CLOSE =  "Close";
	public static final String SELECTED_WF_NBR_HIDDEN = "selectedWfNbr";
	public static final String MSG_IDOCS = "idocs";
	public static final String MSG_OFFICIAL_USE_ONLY = "Official Use Only";
	public static final String MSG_CONFIDENTIAL = "Confidential";
	public static final String MSG_STRICTLY_CONFIDENTIAL = "Strictly Confidential";
	public static final String MSG_FOLDER_CATEGORY = "folder_category";
	public static final String PROJECT_ID = "project_id";
	public static final String PROJECT_NAME = "project_nme";
	public static final String PROJECT_SHORT_NME="project_short_nme";
	public static final String MSG_INSTITUTION_NBR = "institution_nbr";
	public static final String MSG_INSTIT_SHORT_NME="instit_short_nme";
	public static final String MSG_COUNTRY_LONG_NME="country_long_nme";
	public static final String COUNTRY_CODE = "country_code";
	public static final String INSTITUTION_NBR = "institution_nbr";
	public static final String DOC_TYPE_CODE = "doc_type_code";
	public static final String DOC_CATEGORY = "doc_category";
	public static final String MSG_DOC_SUBTYPE_NAME = "doc_subtype_nme";
	public static final String MSG_FOLDER_TITLE = "folder_title";
	public static final String IDOCS_MOVE_OPERATION = "MOVE_OPERATION";
	public static final String IDOCS_COPY_OPERATION = "COPY_OPERATION";
	public static final String MSG_SINGLE_SPACE = " ";
	public static final String MSG_IFCDOCS_AUTHORS = "ifcdocs_authors";
	public static final String MSG_PRODUCT_NBR = "product_nbr";
	public static final String MSG_DISBURSEMENT_WF_NBR = "disbursement_workflow_nbr";
	public static final String MSG_COMMITMENT_WF_NBR = "commitment_workflow_nbr";
	public static final String MSG_UNDISBURSED_WORKFLOW_USD_AMT = "UNDISBURSED_WORKFLOW_USD_AMT";
	public static final String MSG_DISBURSEMENT_USD_AMT = "DISBURSEMENT_USD_AMT";
	public static final String ATTR_DISBURSEMENT_USD_AMT ="disbursement_usd_amt";
	public static final String UNDISBURSED_WORKFLOW_USD_AMT="undisbursed_workflow_usd_amt";
	
	public static final String MSG_PROJECT_SUB_CATEGORY_NME = "project_sub_category_nme";
	public static final String MSG_INITIALVERSION_LABEL = "_NEW_";
	public static final String MSG_R_VERSION_LABEL = "r_version_label";
	public static final String MSG_UNRECOGNIZED_PACKAGE="UnRecognizedPackage";
	public static final String MSG_ADVISORY_SERVICES="Advisory Services";
	
	public static String MSG_IDOCS_PROMPT_COMPONENT = "idocsprompt_component";
	public static String MSG_PROMPT_COMPONENT = "prompt";
	
	public static String MSG_USER_OBJ_TYPE="11";
	public static final String MSG_STAGE_NBR = "stage_nbr";
	public static final String MSG_TEMPLATE_PATH="/Templates/IFCDocs";
	/*
	 * Advisory Services Templates
	 */
	
	public static final String MSG_AS_CONCEPT_NOTE = "AS Concept Note";
	public static final String MSG_AS_PLAN = "AS Plan";
	public static final String MSG_AS_IMPLEMENTATION_PLAN = "AS Implementation Plan";
	public static final String MSG_AS_SUPERVISION = "AS Supervision";
	public static final String MSG_AS_COMPLETION="AS Completion";
	public static final String MSG_AS_DROPPAGE_NOTE="AS Droppage-Termination Note";
	public static final String MSG_AS_DROPPAGE_MEMO="AS Droppage Termination Memo";
	public static final String MSG_AS_PDP_IMPL_PLAN="AS PDP Implementation Plan";
	public static final String MSG_AS_PDP_SUPERVISION="AS PDP Supervision";
	
	
	public static final String MSG_AS_CONCEPT_NOTE_TEMPCODE="100";
	public static final String MSG_AS_IMPLEMENTATION_PLAN_TEMPCODE = "200";
	public static final String MSG_AS_SUPERVISION_TEMPCODE = "300";
	public static final String MSG_AS_COMPLETION_TEMPCODE="400";
	public static final String MSG_AS_DROPPAGE_NOTE_TEMPCODE="500";
	public static final String MSG_AS_PDP_IMPL_PLAN_TEMPCODE="600";
	public static final String MSG_AS_PDP_SUPERVISION_TEMPCODE="700";
	public static final String MSG_DOCX_EXTENSION="docx";
	public static final String MSG_RESTART_ONLY = "RO";
	public static final int MSG_PRODUCT_WF_TYPE_CODE_VAL = 100;
	public static final String MSG_TYPE_PRODUCT = "Products";
	public static final String MSG_TYPE_DISBURSEMENT = "Disbursement";
	public static final String MSG_TYPE_COMMITMENT = "Commitment";
	public static final String MSG_TYPE_ADJUSTMENT = "Adjustments";
	public static final String MSG_PROJECT_TEAM = "Team";
	
	public static final String MSG_ACCESSOR_ID = "accessor_id";
	public static final String USER_OS_NAME = "user_os_name";
	
	// PARTNER - TIER CODES
	public static final String MSG_TIER_1="01";
	public static final String MSG_TIER_2="02";
	public static final String MSG_TIER_CRR_NOT_FOUND="99";
	public static final Object MSG_DOCUMENT_DATE = "document_date";
	
	public static final String MSG_SNAPSHOT_DOC = "420";
	public static final String MSG_PROJECT_TIER_1 = "1";
	public static final String MSG_PROJECT_TIER_2 = "2";
	public static final String MSG_PROJECT_TIER_3 = "3";
	public static final String MSG_PROJECT_TIER_NA = "0";
	
	public static final String INBOX_PROJECT_ID_QRY ="SELECT r_object_id, object_name, project_short_nme, project_id, country_nme from idocs_project_doc where i_chronicle_id in (SELECT r_component_chron_id FROM dmi_package WHERE r_workflow_id='";
	public static final String INBOX_COUNTRY_CODE_QRY = "SELECT r_object_id, object_name, country_nme from idocs_country_doc where i_chronicle_id in (SELECT r_component_chron_id FROM dmi_package WHERE r_workflow_id='";
	public static final String INBOX_INSTITUTION_NBR_QRY = "SELECT r_object_id, object_name, institution_nbr,instit_short_nme ,country_nme from idocs_institution_doc where i_chronicle_id in (SELECT r_component_chron_id FROM dmi_package WHERE r_workflow_id='";
	public static final String ROUTER_ID="router_id";
	public static final String QUERY_STR_SUFF="')";
	public static final String MSG_NON_CSO = "NonCSO";
	public static final String MSG_CSO = "CSO";
	public static final String MSG_RIGHTS_ISSUE_INVALID_SOU = "InvalidSOU";
	public static final String MSG_OTHER = "OtherTemplates";
	public static final String MSG_EXCEPTION = "Exception";
	
	public static final String ITEM_VALUE = "item_value";
	
	public static final String AS_CONCEPT_NOTE = "AS Concept Note";
	public static final String AS_IMPLEMENTATION_PLAN = "AS Implementation Plan";
	public static final String AS_SUPERVISION = "AS Supervision";
	public static final String AS_COMPLETION = "AS Completion";
	public static final String AS_DROPPAGE_TERMINATION = "AS Droppage-Termination Note";

	public static final String MSG_IDOCS_IOM_FORM = "idocs_iom_form";
	public static final String MSG_DM_USER = "dm_user";
	public static final String MSG_USER_ADDRESS = "user_address";
	public static final String MSG_KEYWORD_DISTINCT = "distinct";
	public static final String MSG_KEYWORD_ANY = "any";
	public static final String MSG_DMI_PACKAGE="dmi_package";
	public static final String MSG_R_COMPONENT_CHRON_ID = "r_component_chron_id";
	public static final String MSG_R_PERFORMER_NAME = "r_performer_name";
	public static final String MSG_GROUPS_NAMES = "groups_names";
	public static final String MSG_TASK_STATE = "task_state";
	public static final String MSG_TASK_ACQUIRED = "acquired";
	public static final String A_IS_HIDDEN ="a_is_hidden";
	
	public static final String IDOCS_ESRS_FORM="idocs_esrs_form";
	public static final String IDOCS_SPI_FORM="idocs_spi_form";
	public static final String DISCLOSURE_TYPE="disclosure_type";
	public static final String DIRECT_TASK_ID = "DIRECT_TASK_ID";
	public static final String STR_I_ALL_USER_NAME="i_all_users_names";
	public static final String DIRECT_NAVIGATION_IDESK = "DIRECT_NAVIGATION_IDESK";
    public IDocsConstants() {
    }
}

