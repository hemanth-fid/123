/**
* This precondition class is to provides the document to virtual.
* #######################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created
* #######################################################################
*/
package org.ifc.idocs.library.actions;

import org.ifc.idocs.constants.IDocsConstants;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.action.IActionPrecondition;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

public class AddVirtualDocumentCustomPrecondition
    implements IActionPrecondition
{
    public AddVirtualDocumentCustomPrecondition()
    {
    }

    public String[] getRequiredParams()
    {
        return null;
    }

    public boolean queryExecute(String strAction, IConfigElement config, ArgumentList arg, Context context, Component component)
    {
        boolean bExecute=false;
        try {
            String strObjectId = arg.get("objectId");
            String isVirtualDoc = arg.get("isVirtualDoc");
    		if(strObjectId !=  null && strObjectId.trim().length() > 0 
					&& (IDocsConstants.MSG_ONE.equalsIgnoreCase(isVirtualDoc) == true
							|| Boolean.TRUE.toString().equalsIgnoreCase(isVirtualDoc) == true)){
				bExecute = true;
			}
		} catch (Exception e) {
			DfLogger.error(this, " :: queryExecute Exception >> "+e.getMessage(), null, e);
		}
        return bExecute;
    }
}