package org.ifc.idocs.forms.adaptors;

import java.io.InputStream;

import java.util.Properties;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfLogger;
import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.IAdaptorParameter;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import com.documentum.xforms.engine.adaptor.datasource.ISetValueAdaptor;

/**
* CheckIPSEventDate - Adaptor to check IPS Event date in Project Event table.
* @author DShivnani
* 
* #####################################################################
* Author		DateofChange 		Version 	ModificationHisotry
* #####################################################################
* 
* #####################################################################
*/

public class CheckIPSEventBoolean implements ISetValueAdaptor {

	public Object execute(IAdaptorParameter[] parameters) throws AdaptorException {
		Boolean ipsCheck = false;
		
		String propertiesFile = "/idocsProps.properties";
		Properties idocsProperties = new Properties();
	    InputStream inputStream = CheckIPSEventDate.class.getResourceAsStream(propertiesFile);
	    String strQuery = null;
	    IDfSession session = null;
	    try
		{
	        idocsProperties.load(inputStream);
	        strQuery = idocsProperties.getProperty("IPS_EVENT_QRY");
			strQuery = strQuery.replaceFirst("''", "'"+parameters[0].getValue()+"'");
			strQuery = strQuery.replaceFirst("''", "'"+parameters[1].getValue()+"'");
			DfLogger.info(this," :: Query : "+strQuery,null,null);
			IDfQuery strDQL = new DfQuery();
			IDfCollection dfCollection = null;
			
			strDQL.setDQL(strQuery);
			session = SessionManagerHttpBinding.getSessionManager().getSession(SessionManagerHttpBinding.getCurrentDocbase());
			dfCollection = strDQL.execute(session,IDfQuery.DF_READ_QUERY);
			DfLogger.info(this," :: Query Executed ",null,null);
			String  date1=null;
			if(!dfCollection.equals(null)){
				if (dfCollection.next()) {				
					date1 =  dfCollection.getString("actual_date");
					DfLogger.info(this," :: Date1 : "+date1.length(),null,null);
					dfCollection.close();				
				}else{
					DfLogger.info(this," :: dfCollection is Empty... : ",null,null);
				}
				if (date1.length() > 0){
					ipsCheck=true;
					DfLogger.info(this," :: date exists  : "+ipsCheck,null,null);
				}				
			}
		}
		catch(Exception e)
		{
		     DfLogger.error(this,": <<Exception>> : "+e.getMessage(),null,e);
		}
		finally
		{
			SessionManagerHttpBinding.getSessionManager().release(session);
		}
		DfLogger.info(this," ::Date (return)finalllllllll : "+ipsCheck,null,null);
		return ipsCheck;
	}
		
	public void destroy() throws AdaptorException {
		}
	
	public void init(IAdaptorConfiguration arg0) throws AdaptorException {
		DfLogger.info(this," :: Init() ",null,null);
	}	
}