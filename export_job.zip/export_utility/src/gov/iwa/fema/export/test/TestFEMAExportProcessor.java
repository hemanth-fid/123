/**
 * 
 */
package gov.iwa.fema.export.test;

import gov.iwa.fema.export.processor.FEMAExportProcessor;

import java.util.HashMap;
import java.util.Map;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfDocbaseMap;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfLoginInfo;

/**
 * @author hemanth.muppalanara
 *
 */
public class TestFEMAExportProcessor {

	/**
	 * @param args
	 */
	
	
	
	static IDfClient m_client = null;
	protected static IDfSessionManager m_sessionMgr = null;
	protected static String m_docbase = null;
	protected static String m_userName = null;
	protected static String m_password = null;
	protected static String m_domain = null;
	protected static IDfSession m_session = null;
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		FEMAExportProcessor femaProcessor=new FEMAExportProcessor();
		
		try {
			
			m_docbase="";
			m_userName="";
			m_password="";

			
			m_sessionMgr = getSessionMgr();
			m_session=m_sessionMgr.getSession(m_docbase);
			
			
			Map<String, String> params=new HashMap<String, String>();
			
			params.put("file_share_location", "C:\\Users\\hemanth.muppalanara\\Geronimo\\SWBC\\Claims\\Ingest_checks_letters\\letters");
		
			femaProcessor.setSession(m_session);
			
			femaProcessor.setCustomArguments(params);
			
			femaProcessor.execute(null, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			m_sessionMgr.release(m_session);
		}
		
		
	}
	
	protected static IDfSessionManager getSessionMgr() throws DfException {
		
		if (m_docbase == null || m_userName == null)
			return null;
		// now login
		System.out.println("Login()");
		m_client = new DfClientX().getLocalClient();

		if (m_client != null) {
			IDfLoginInfo li = new DfLoginInfo();
			li.setUser(m_userName);
			li.setPassword(m_password);
			li.setDomain(m_domain);

			IDfSessionManager sessionMgr = m_client.newSessionManager();
			sessionMgr.setIdentity(m_docbase, li);

			IDfClientX clientx = new DfClientX();
			IDfClient client = clientx.getLocalClient();

			IDfDocbaseMap myMap = client.getDocbaseMap();
			System.out.println("Docbases for Docbroker: " + myMap.getHostName());
			System.out.println("Total number of Docbases: " + myMap.getDocbaseCount());
			for(int i = 0; i < myMap.getDocbaseCount(); i++) {
				System.out.println("Docbase " + (i + 1)  + ": " + myMap.getDocbaseName(i));
			}

			return sessionMgr;			
		}
		return null;
	}

}
