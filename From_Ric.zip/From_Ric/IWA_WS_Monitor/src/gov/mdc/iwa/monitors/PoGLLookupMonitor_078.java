package gov.mdc.iwa.monitors;

import gov.mdc.iwa.monitors.utils.Email;
import gov.mdc.iwa.monitors.utils.Host;
import gov.mdc.iwa.monitors.utils.MonitorConfig;
import gov.mdc.iwa.monitors.utils.Result;
import gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078InHdr_Type;
import gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078In_Type;
import gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078Out_Type;
import gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078Request_Type;
import gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078Response_Type;
import gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078ServiceBindingStub;
import gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078ServiceLocator;

import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import org.apache.log4j.Logger;

public class PoGLLookupMonitor_078 {

	private static String className =  PoGLLookupMonitor_078.class.getName();
	private static Logger log = Logger.getLogger(className);
	private static final String CONFIG_FILE = "monitor078.config";
	private static String hostname = Host.getHostName();
	private static StringBuffer msg = new StringBuffer("IWA WEB SERVICE MONITOR - " + className + "\n\n");
	
	public static void main(String[] args) throws Throwable
	{
		log.info(className + " - START");			
		MonitorConfig config = new MonitorConfig(CONFIG_FILE); 
		Result result = doPoLookup(config);
		
		// If connection to the web service failed 
		if( ! result.getConnectionOk()  ){
			msg.append("Unable to connect to Web Service   " + config.getUrl() +   "\n");
			msg.append("Error: " + result.getMessage() + "\n\n") ;
			msg.append("Host: " + hostname  + "\n");
			msg.append("Program: PoGLLookupMonitor_078 - Web Service PCHW078W\n") ;			
			Email.Send(config, msg.toString());
		}else{
			if( result.getMessage().toUpperCase().indexOf("SUCCESS") > -1 || 
				result.getMessage().toUpperCase().indexOf("PLEASE TRY AGAIN") > -1)
			{
				// OK, dont do anything   -- SendEmail(config, "SUCCESS");
			}else{
				msg.append("Web service  " + config.getUrl() + " is not returning the correct values.\n");
				msg.append("Error  : " + result.getMessage() + "\n\n") ;
				msg.append("Host: " + hostname  + "\n");
				msg.append("Program: PoGLLookupMonitor_078 - Web Service PCHW078W\n");
				Email.Send(config, msg.toString() );
			}
		}
		log.info(className + " - END");
	}

	//public static Result doPoLookup(String url, String po, String un, String pw) throws ServiceException, RemoteException
	public static Result doPoLookup(MonitorConfig config) throws ServiceException, RemoteException
	{
		/* MESSAGES RETURNED BY THE WEB SERVICE
		 * OK (msgText): SUCCESS (when the parameters passed return a valid value)
		 * OK (msgText): G461 - RECORD DOES NOT EXIST, PLEASE TRY AGAIN (when the parameters passed do NOT return a valid value)
		 */
		Result result = new Result();

		try{
			PCHW078ServiceLocator serviceLoc = new PCHW078ServiceLocator();
			if(config.getUrl() != null && config.getUrl().length() > 0) serviceLoc.setPCHW078ServicePortEndpointAddress(config.getUrl());
			PCHW078ServiceBindingStub stub = (PCHW078ServiceBindingStub)serviceLoc.getPCHW078ServicePort();
			if(config.getUsr() != null && config.getUsr().length() > 0 && config.getPw() != null && config.getPw().length() > 0)
			{
				stub._setProperty("javax.xml.rpc.security.auth.username", config.getUsr());
				stub._setProperty("javax.xml.rpc.security.auth.password", config.getPw());				
			}
			PCHW078Request_Type request = new PCHW078Request_Type();
			PCHW078InHdr_Type pht = new PCHW078InHdr_Type();
			PCHW078In_Type params = new PCHW078In_Type();
			pht.setStreamInputSessionId("");
			params.setPCHW078InHdr(pht);
			params.setPONUM2360(config.getPo());
			request.setPCHW078In(params);
			PCHW078Response_Type response = stub.PCHW078(request);
			PCHW078Out_Type respD = response.getPCHW078Out();
			String msgText = respD.getMSGTEXT();
			String retMsg = respD.getRETURNMSG();
			result.setMessage(msgText);
			log.warn((new StringBuilder("Return value is ")).append(retMsg).append(" ").append(msgText).toString());
		}catch(Exception e){
			result.setMessage(e.getMessage());
			result.setConnectionOk(false);    	
			log.warn("ERROR - " + e.getMessage());
		}
		return result;
	}
}
