/***************************************************************************
 * State Farm
 * Version Template: 2012
 *
 * File Name: CommonUtils.java
 *
 * Version     ChgDate          Author           Comments
 * ________   __________       ________         ___________
 * 1.0        05/19/2013         t1or         Initial Creation 
 *
 ***************************************************************************/
package sf.application.custcomm.ccs.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import sf.application.custcomm.ccs.constants.CleanUpConstants;
import sf.application.custcomm.ccs.constants.ExceptionConstants;
import sf.application.custcomm.ccs.exceptions.CleanUpServiceException;

import com.documentum.fc.common.DfLogger;

/**
 * <i> CommonUtils </i> is a utility class contains the reusable methods which
 * are used in implementing the export service module components.
 * 
 */
public final class CommonUtils {

	/**
	 * private constructor
	 */
	private CommonUtils() {

	}

	/**
	 * It is to concatenate the input Strings
	 * 
	 * @param message
	 *            Message String
	 * @param description
	 *            Description to concatenate
	 * 
	 * @return String result of the concatenated string
	 * 
	 */
	public static String frameMessage(Object message, Object description) {

		if(DfLogger.isTraceEnabled(CommonUtils.class)) {
			DfLogger.trace(CommonUtils.class, "Method frameMessage() entry", null, null);
		}

		StringBuilder messageBuilder = new StringBuilder();
		messageBuilder.append(message);
		messageBuilder.append(CleanUpConstants.SEPARATOR);
		messageBuilder.append(description);

		if(DfLogger.isTraceEnabled(CommonUtils.class)) {
			DfLogger.trace(CommonUtils.class, "Method frameMessage() exit", null, null);
		}

		return messageBuilder.toString();
	}

	/**
	 * To verify if the input object is null
	 * 
	 * @param object
	 *            input object
	 * @return boolean result of null check
	 */
	public static boolean isNull(Object object) {
		return(object == null);
	}
	
	
	
  public static String getDate() {
	
	
	DateFormat dateFormat=new SimpleDateFormat("MM-dd-yyyy");
	return dateFormat.format(new Date());
	
	
}
  
  
  
        
	public static String getLocalHostName() throws CleanUpServiceException{

		if(DfLogger.isTraceEnabled(CommonUtils.class)) {
			DfLogger.trace(CommonUtils.class, "Method getLocalHostName() entry", null, null);
		}
		try {
			if(DfLogger.isTraceEnabled(CommonUtils.class)) {
				DfLogger.trace(CommonUtils.class, "Method getLocalHostName() entry", null, null);
			}
			return java.net.InetAddress.getLocalHost().getCanonicalHostName();
		} catch(UnknownHostException unknownHostException) {
			throw new CleanUpServiceException("Unknown Host", unknownHostException);
		}
	}

	
	
	/**
	 * It writes the content to a file.
	 * 
	 * @param fileLocation
	 *            location of the file
	 * @param content
	 *            Content of the file
	 * @throws ServerMethodException
	 *             Custom Exception used within the cleanup module
	 */
	public static void writeToFile(String fileLocation, String content) throws CleanUpServiceException {

		if (DfLogger.isTraceEnabled(CommonUtils.class)) {
			DfLogger.trace(CommonUtils.class, "Method writeToFile() entry", null, null);
		}
		Writer writer= null;
		try {
			
			String directory = StringUtils.substring(fileLocation, CleanUpConstants.INDEX_ZERO,
					StringUtils.lastIndexOf(fileLocation, CleanUpConstants.FOLDER_SEPARATOR));
			File inputDirectory = new File(directory);
			if(!inputDirectory.exists() && (!inputDirectory.mkdirs()))	{
					throw new CleanUpServiceException(frameMessage(ExceptionConstants.ERROR_WHILE_CREATING_DIRECTORY,directory));
			}
			File inputFile = new File(fileLocation);
			writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(inputFile.getAbsoluteFile()),
					CleanUpConstants.FORMAT_UTF8));
			
			writer.write(content);
			}

		 catch (IOException ioException) {
			throw new  CleanUpServiceException(ExceptionConstants.ERROR_WHILE_WRITING_CONTENT, ioException);
		} finally {
			closeWriter(writer);
		}
		if (DfLogger.isTraceEnabled(CommonUtils.class)) {
			DfLogger.trace(CommonUtils.class, "Method writeToFile() exit", null, null);
		}

	}

	/**
	 * It closes the Writer stream.
	 * 
	 * @param writer
	 */
	public static void closeWriter(Writer writer){
		if (!isNull(writer)) {
			try {
				writer.flush();
				writer.close();
			} catch (IOException ioException) {
				DfLogger.error(CommonUtils.class, ioException.getMessage(), null, ioException);
			}
		}
	}
	
	

}
