package org.ifc.idocs.library.contenttransfer.view;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.commons.beanutils.BeanUtils;

import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfType;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.operations.IDfXMLUtils;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.docbase.ObjectCacheUtil;
import com.documentum.web.util.DfcUtils;
import com.documentum.webcomponent.library.contenttransfer.view.View;

public class IDocsView extends View {
	
	/**
	 * @author LVudatha
	 * purpose :To Changing default view of virtual document(Removing "Down load descendants" page)
	 * @category view component
	 */
	
	private static final long serialVersionUID = -7934732480271043204L;
	
	protected void initControls()
    {
        initHeaderControls();
    }
	
	public boolean isIgnoreDescendents()
	{
	   return true;
	}
	
	protected void initFromSysobject(IDfSysObject obj)
	{
	        resetContentType();
	        DfLogger.info(this, " :: inside initFromSysobject(IDfSysObject obj) :: ", null, null);
	}

    protected void initFromSysobject()
	  {
	        try
	        {
	        	DfLogger.info(this, " ::inside  initFromSysobject() :: ", null, null);
	            com.documentum.fc.client.IDfSession dfSession = getDfSession();
	            IDfSysObject sysObj = (IDfSysObject)ObjectCacheUtil.getObject(dfSession, getObjectId());
	            setObjectVirtualDoc(false);
	            DfLogger.info(this, " ::initFromSysobject() ::sysobject Object Id "+sysObj.getObjectId().toString(), null, null);
	            setObjectAssemblyDoc(!sysObj.getAssembledFromId().isNull());
	            setObjectACategory(sysObj.getString("a_category"));
	            IDfXMLUtils xmlUtils = DfcUtils.getClientX().getXMLUtils();
	            xmlUtils.setSession(getDfSession());
	            com.documentum.fc.client.IDfFormat format = sysObj.getFormat();
	            setObjectXmlDoc(format != null && xmlUtils.isXML(format));
	            IDfType dfType = sysObj.getType();
	            setObjectContentType(sysObj.getContentType());
	            setObjectType(dfType.getName());
	            initFromSysobject(sysObj);
	            DfLogger.info(this, " ::exit  initFromSysobject() :: ", null, null);
	        }
	        catch(DfException e)
	        {
	            throw new WrapperRuntimeException(e);
	        }
	    }
	
	protected void initControlsFromConfig()
	    {
		 DfLogger.info(this, " ::inside  initControlsFromConfig() :: ", null, null);
	        try
	        {
	            IConfigElement initControls = lookupElement("init-controls");
	            if(initControls != null)
	            {
	            	DfLogger.info(this, " ::inside  initControlsFromConfig()  if(initControls != null) :: ", null, null);	
	                for(Iterator controls = initControls.getChildElements(); controls.hasNext();)
	                {
	                	DfLogger.info(this, " ::inside  initControlsFromConfig()  for iteration :: ", null, null);	
	                    IConfigElement ctrl = (IConfigElement)controls.next();
	                    String ctrlName = ctrl.getAttributeValue("name");
	                    String ctrlType = ctrl.getAttributeValue("type");
	                    if(ctrlName != null && ctrlName.length() > 0 && ctrlType != null && ctrlType.length() > 0)
	                    {
	                    	DfLogger.info(this, " ::inside  initControlsFromConfig() ctrlName:: "+ctrlName, null, null);
	                    	
	                        Class cl = Class.forName(ctrlType);
	                        com.documentum.web.form.Control control = getControl(ctrlName, cl);
	                        Iterator props = ctrl.getChildElements();
	                        if(control != null)
                        		DfLogger.info(this, " ::inside  initControlsFromConfig() props.hasNext()::control.getName() "+control.getName(), null, null);
                        	else
                        		DfLogger.info(this, " ::inside  initControlsFromConfig() props.hasNext()::control.getName() null", null, null);
	                        while(props.hasNext()) 
	                        {
	                            IConfigElement initProp = (IConfigElement)props.next();
	                            String propName = initProp.getChildValue("property-name");
	                            DfLogger.info(this, " ::inside  initControlsFromConfig() props.hasNext():: "+propName, null, null);
	                            IConfigElement valueElem = initProp.getChildElement("property-value");
	                            if(propName != null && propName.length() > 0 && valueElem != null)
	                            {
	                                String propValue = valueElem.getValue();
	                                HashMap propMap = new HashMap(1);
	                                propMap.put(propName, propValue);
	                                DfLogger.info(this, " ::calling   BeanUtils.populate() :: "+propName, null, null);
	                                BeanUtils.populate(control, propMap);
	                            }
	                        }
	                    }
	                }

	            }
	        }
	        catch(ClassNotFoundException e)
	        {
	        	DfLogger.info(this, " ::inside  initControlsFromConfig() ClassNotFoundException "+e.getMessage(), null, null);
	            throw new WrapperRuntimeException(e);
	        }
	        catch(IllegalAccessException e)
	        {
	        	DfLogger.info(this, " ::inside  initControlsFromConfig() IllegalAccessException "+e.getMessage(), null, null);
	            throw new WrapperRuntimeException(e);
	        }
	        catch(InvocationTargetException e)
	        {
	        	DfLogger.info(this, " ::inside  initControlsFromConfig() InvocationTargetException "+e.getMessage(), null, null);
	            throw new WrapperRuntimeException(e);
	        }
	    }
}
