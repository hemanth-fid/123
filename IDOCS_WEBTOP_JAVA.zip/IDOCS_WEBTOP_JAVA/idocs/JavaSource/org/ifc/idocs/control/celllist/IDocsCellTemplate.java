package org.ifc.idocs.control.celllist;

public class IDocsCellTemplate extends com.documentum.web.form.control.databound.CellTemplate{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public IDocsCellTemplate()
    {
        m_strType = null;
        m_strField = null;
    }

    public String getField()
    {
        return m_strField;
    }

    public void setField(String strField)
    {
        m_strField = strField;
    }

    public String getType()
    {
        return m_strType;
    }

    public void setType(String strType)
    {
        m_strType = strType;
    }

    private String m_strType;
    private String m_strField;
}
