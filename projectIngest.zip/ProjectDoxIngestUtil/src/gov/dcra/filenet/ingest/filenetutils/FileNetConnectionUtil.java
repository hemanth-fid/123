package gov.dcra.filenet.ingest.filenetutils;

import gov.dcra.filenet.ingest.constants.IngestConstants;

import java.util.Iterator;
import java.util.Properties;

import javax.security.auth.Subject;

import org.apache.log4j.Logger;

import com.filenet.api.collection.ObjectStoreSet;
import com.filenet.api.core.Connection;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.util.UserContext;

public class FileNetConnectionUtil {
	
	@SuppressWarnings("unused")
	private final static Logger log=Logger.getLogger(FileNetConnectionUtil.class);
	private static  Properties credentialsProps = new Properties();
	
	private static Connection getConnection() throws Exception {
		
		
		credentialsProps.load(FileNetConnectionUtil.class.getResourceAsStream(IngestConstants.CREDENTAILS_PROPS));
		
		String uri = credentialsProps.getProperty(IngestConstants.MSG_URL);
		String username = credentialsProps.getProperty(IngestConstants.MSG_USERNAME);
		String password = credentialsProps.getProperty(IngestConstants.MSG_PWD);
		@SuppressWarnings("unused")
		String stanza = credentialsProps.getProperty(IngestConstants.MSG_STANZA);
		Connection conn = Factory.Connection.getConnection(uri);
		Subject subject = UserContext.createSubject(conn, username, password, null);
		UserContext uc = UserContext.get();
		uc.pushSubject(subject);
		return conn;
	}
	
	public static Domain getDomain() throws Exception {
		
		String domainName = credentialsProps.getProperty(IngestConstants.MSG_DOMAIN);
		Domain domain = Factory.Domain.fetchInstance(getConnection(), domainName, null);
		return domain;
		
	}
	
	public static ObjectStore getObjectStore (Domain domain, String objectStoreName) throws Exception {
		ObjectStore os = null;
		os = Factory.ObjectStore.fetchInstance(domain, objectStoreName, null);
		return os;
	}

	
}
