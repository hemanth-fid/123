/**
* This class to check the permitions for the component to validate.
* ########################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* ########################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created
* 
* ########################################################################
*/
package org.ifc.idocs.library.actions;

import java.util.Map;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.ErrorMessageService;
import com.documentum.web.common.LocaleService;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.docbase.ObjectCacheUtil;

public class LaunchComponentWithPermitCheck extends
		com.documentum.web.formext.action.LaunchComponentWithPermitCheck {

	private static final long serialVersionUID = 1L;
    private static final NlsResourceBundle s_lookup = new NlsResourceBundle("org.ifc.idocs.action.ValidateGroupMembershipNlsProp");
    public String[] getRequiredParams(){
        return (new String[] {
            "objectId"
        });
    }
    
    /**
     * 
     */
	public boolean execute(String strAction, IConfigElement config, 
			ArgumentList args, Context context, Component component, Map completionArgs){
    	try {
			DfLogger.info(this," :: execute : "+component.getDfSession().getLoginUserName(),null,null);
		} catch (DfException e) {
			DfLogger.error(this, " :: execute Exception >> "+e.getMessage(), null, e);
		}
        boolean bExecutionSucceded = false;
        bExecutionSucceded=super.execute(strAction, config, args, context, component, completionArgs);
    	DfLogger.info(this," :: execute() : bExecutionSucceded : "+bExecutionSucceded,null,null); 
    	if(bExecutionSucceded){
        	try{
		        IDfSession dfSession = component.getDfSession();
	        	String strObjectId = args.get("objectId");
	            IDfDocument newDoc =(IDfDocument) ObjectCacheUtil.getObject(dfSession, strObjectId);
	            String strType = args.get("type");
	            String strDocState=newDoc.getString(IDocsConstants.MSG_DOC_STATE);
	            String project_id="0";
	            if(strType.equals(s_lookup.getString("MSG_PROJ_DOC", LocaleService.getLocale())) 
	            		&& strDocState.equals(s_lookup.getString("MSG_RELEASED", LocaleService.getLocale()))){
	            	project_id=newDoc.getString(s_lookup.getString("MSG_PROJECT_ID", LocaleService.getLocale()));

	            	boolean isGroupMember=validateUserAccess(dfSession,project_id);
	            	if(isGroupMember){
	            		bExecutionSucceded=false;
	        	        ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_PERMISSION_DENIED", component, null, null);
	        	        return false;
	            	}
	            }
        	}catch(DfException e){
    			DfLogger.error(this, " :: execute Exception >> "+e.getMessage(), null, e);
        	}
        }
    	DfLogger.info(this," :: execute : bExecutionSucceded : "+bExecutionSucceded,null,null); 
    	return bExecutionSucceded;
    }

	private boolean validateUserAccess(IDfSession dfSession, String projectId) {
		boolean isGroupMember=false;
    	try{
			String userName=IdocsUtil.handleSingleQuote(dfSession.getLoginUserName());
			String groupNames=s_lookup.getString("MSG_GROUPS", LocaleService.getLocale());
			groupNames=groupNames.replaceAll(IdocsConstants.MSG_HASH, projectId);
			groupNames=groupNames.replaceAll(IdocsConstants.MSG_COMMA, IdocsConstants.MSG_Q_COMMA_Q);
    		String strQry = IDocsConstants.MSG_EMPTY_STRING;
    		strQry = IdocsUtil.getMessage("QRY_GROUP_VALIDATION");
			strQry = strQry.replaceFirst(IdocsConstants.MSG_C_DQ_C,IdocsConstants.MSG_QUOTES+groupNames+IdocsConstants.MSG_QUOTES);
			strQry = strQry.replaceFirst(IdocsConstants.MSG_C_DQ_C,IdocsConstants.MSG_QUOTES+userName+IdocsConstants.MSG_QUOTES);
			IDfCollection coll=IdocsUtil.executeQuery(dfSession,strQry,IDfQuery.DF_READ_QUERY);
			if(coll.next()){
				coll.getString(IDocsConstants.STR_I_ALL_USER_NAME);
				isGroupMember=true;
				coll.close();
			}
			if(coll != null )coll.close();
    	}catch(DfException e){
			DfLogger.error(this,": <<Exception>> : "+e.getMessage(),null,e);
    	}
		return isGroupMember;
	}
}