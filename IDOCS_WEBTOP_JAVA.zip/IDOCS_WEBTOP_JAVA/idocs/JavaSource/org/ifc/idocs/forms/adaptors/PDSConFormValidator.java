package org.ifc.idocs.forms.adaptors;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;

import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.Pointer;
import org.w3c.dom.Document;

import com.documentum.fc.common.DfLogger;
import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.xforms.engine.XFormsProcessorException;
import com.documentum.xforms.engine.adaptor.validator.IDocumentValidator;

@SuppressWarnings("unused")
public class PDSConFormValidator implements IDocumentValidator {

	public boolean validate(Document document) throws XFormsProcessorException {
		boolean retvalue = true;
		String exception = "";
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		System.out
				.println("PDSConFormValidator:: Inside PDSConFormValidator");
		
		JXPathContext validateContext = JXPathContext.newContext(document);
		Pointer nodePointer5 = validateContext
				.getPointer("/IDOCS_PDSConcept_Form/TLInitiateReviewGrp/HorizontalBox1/ValidationFilter");
		DfLogger.info(this,"PDSConFormValidator:: IsValidatorRequired"+nodePointer5.getValue().toString(),null,null);
		if (nodePointer5.getValue().toString().equals("true")) {
			System.out
			.println("PDSConFormValidator:: Inside PDS Con Transaction Leader Validation");
			Pointer nodePointer1 = validateContext
					.getPointer("/IDOCS_PDSConcept_Form/TLInitiateReviewGrp/date_concept_review_meet");
			Pointer nodePointer2 = validateContext
					.getPointer("/IDOCS_PDSConcept_Form/TLInitiateReviewGrp/date_client_request");
			
			Date now = new Date();
			
			Date dateofConcept = new Date();
			Date dateofClientRequest = new Date();
			try 
			{
				dateofConcept = dateFormat.parse(nodePointer1.getValue().toString());
				DfLogger.info(this,"ConceptDateValidator:: Concept Date from XPath is "+ dateofConcept,null,null);
				dateofClientRequest = 	dateFormat.parse(nodePointer2.getValue().toString());
				DfLogger.info(this,"ClientRequestDateValidator:: Client Request Date from XPath is "+ dateofClientRequest,null,null);
				} 
			catch (java.text.ParseException e) {
					DfLogger.error(this,": <<Exception>> : "+e.getMessage(),null,e);
				}
			if (dateofConcept.after(now)) {
					retvalue = false;
					exception = exception
							.concat("\nConcept Review Date cannot be future date.");
			}
			else if (dateofClientRequest.after(now)){
				retvalue = false;
				exception = exception
						.concat("\nClient Request Date cannot be future date.");
			}
			} 

			if (retvalue == false) {
				XFormsProcessorException e = new XFormsProcessorException(
						exception);
				throw e;
			}
			DfLogger.info(this,"PDSConFormValidator:: No validation required",null,null);
		return retvalue;
	}

	public void destroy() throws AdaptorException {
	}

	public void init(IAdaptorConfiguration arg0) throws AdaptorException {
	}
}