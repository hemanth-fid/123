/**
 * PCHW078Out_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W;

public class PCHW078Out_Type  implements java.io.Serializable {
    private java.lang.String MAPNAME;

    private java.lang.String STATUSMSG;

    private java.lang.String PORMAMT;

    private java.lang.String POUAP;

    private java.lang.String POIGFEE;

    private java.lang.String RETAPCT;

    private java.lang.String MSGTEXT;

    private java.lang.String[] arrayOfTAMTINDX;

    private java.lang.String[] arrayOfTGRANT;

    private java.lang.String[] arrayOfTGRNTDTL;

    private java.lang.String[] arrayOfTINDX;

    private java.lang.String[] arrayOfTLIQDAMT;

    private java.lang.String[] arrayOfTPRJDTL;

    private java.lang.String[] arrayOfTPROJCT;

    private java.lang.String[] arrayOfTSFX;

    private java.lang.String[] arrayOfTSUBOBJ;

    private java.lang.String[] arrayOfTUSRCODE;

    private java.lang.String RETURNMSG;

    private java.lang.String TRETAPCT;

    private java.lang.String INDAMT1;

    private java.lang.String LQDAMT1;

    public PCHW078Out_Type() {
    }

    public PCHW078Out_Type(
           java.lang.String MAPNAME,
           java.lang.String STATUSMSG,
           java.lang.String PORMAMT,
           java.lang.String POUAP,
           java.lang.String POIGFEE,
           java.lang.String RETAPCT,
           java.lang.String MSGTEXT,
           java.lang.String[] arrayOfTAMTINDX,
           java.lang.String[] arrayOfTGRANT,
           java.lang.String[] arrayOfTGRNTDTL,
           java.lang.String[] arrayOfTINDX,
           java.lang.String[] arrayOfTLIQDAMT,
           java.lang.String[] arrayOfTPRJDTL,
           java.lang.String[] arrayOfTPROJCT,
           java.lang.String[] arrayOfTSFX,
           java.lang.String[] arrayOfTSUBOBJ,
           java.lang.String[] arrayOfTUSRCODE,
           java.lang.String RETURNMSG,
           java.lang.String TRETAPCT,
           java.lang.String INDAMT1,
           java.lang.String LQDAMT1) {
           this.MAPNAME = MAPNAME;
           this.STATUSMSG = STATUSMSG;
           this.PORMAMT = PORMAMT;
           this.POUAP = POUAP;
           this.POIGFEE = POIGFEE;
           this.RETAPCT = RETAPCT;
           this.MSGTEXT = MSGTEXT;
           this.arrayOfTAMTINDX = arrayOfTAMTINDX;
           this.arrayOfTGRANT = arrayOfTGRANT;
           this.arrayOfTGRNTDTL = arrayOfTGRNTDTL;
           this.arrayOfTINDX = arrayOfTINDX;
           this.arrayOfTLIQDAMT = arrayOfTLIQDAMT;
           this.arrayOfTPRJDTL = arrayOfTPRJDTL;
           this.arrayOfTPROJCT = arrayOfTPROJCT;
           this.arrayOfTSFX = arrayOfTSFX;
           this.arrayOfTSUBOBJ = arrayOfTSUBOBJ;
           this.arrayOfTUSRCODE = arrayOfTUSRCODE;
           this.RETURNMSG = RETURNMSG;
           this.TRETAPCT = TRETAPCT;
           this.INDAMT1 = INDAMT1;
           this.LQDAMT1 = LQDAMT1;
    }


    /**
     * Gets the MAPNAME value for this PCHW078Out_Type.
     * 
     * @return MAPNAME
     */
    public java.lang.String getMAPNAME() {
        return MAPNAME;
    }


    /**
     * Sets the MAPNAME value for this PCHW078Out_Type.
     * 
     * @param MAPNAME
     */
    public void setMAPNAME(java.lang.String MAPNAME) {
        this.MAPNAME = MAPNAME;
    }


    /**
     * Gets the STATUSMSG value for this PCHW078Out_Type.
     * 
     * @return STATUSMSG
     */
    public java.lang.String getSTATUSMSG() {
        return STATUSMSG;
    }


    /**
     * Sets the STATUSMSG value for this PCHW078Out_Type.
     * 
     * @param STATUSMSG
     */
    public void setSTATUSMSG(java.lang.String STATUSMSG) {
        this.STATUSMSG = STATUSMSG;
    }


    /**
     * Gets the PORMAMT value for this PCHW078Out_Type.
     * 
     * @return PORMAMT
     */
    public java.lang.String getPORMAMT() {
        return PORMAMT;
    }


    /**
     * Sets the PORMAMT value for this PCHW078Out_Type.
     * 
     * @param PORMAMT
     */
    public void setPORMAMT(java.lang.String PORMAMT) {
        this.PORMAMT = PORMAMT;
    }


    /**
     * Gets the POUAP value for this PCHW078Out_Type.
     * 
     * @return POUAP
     */
    public java.lang.String getPOUAP() {
        return POUAP;
    }


    /**
     * Sets the POUAP value for this PCHW078Out_Type.
     * 
     * @param POUAP
     */
    public void setPOUAP(java.lang.String POUAP) {
        this.POUAP = POUAP;
    }


    /**
     * Gets the POIGFEE value for this PCHW078Out_Type.
     * 
     * @return POIGFEE
     */
    public java.lang.String getPOIGFEE() {
        return POIGFEE;
    }


    /**
     * Sets the POIGFEE value for this PCHW078Out_Type.
     * 
     * @param POIGFEE
     */
    public void setPOIGFEE(java.lang.String POIGFEE) {
        this.POIGFEE = POIGFEE;
    }


    /**
     * Gets the RETAPCT value for this PCHW078Out_Type.
     * 
     * @return RETAPCT
     */
    public java.lang.String getRETAPCT() {
        return RETAPCT;
    }


    /**
     * Sets the RETAPCT value for this PCHW078Out_Type.
     * 
     * @param RETAPCT
     */
    public void setRETAPCT(java.lang.String RETAPCT) {
        this.RETAPCT = RETAPCT;
    }


    /**
     * Gets the MSGTEXT value for this PCHW078Out_Type.
     * 
     * @return MSGTEXT
     */
    public java.lang.String getMSGTEXT() {
        return MSGTEXT;
    }


    /**
     * Sets the MSGTEXT value for this PCHW078Out_Type.
     * 
     * @param MSGTEXT
     */
    public void setMSGTEXT(java.lang.String MSGTEXT) {
        this.MSGTEXT = MSGTEXT;
    }


    /**
     * Gets the arrayOfTAMTINDX value for this PCHW078Out_Type.
     * 
     * @return arrayOfTAMTINDX
     */
    public java.lang.String[] getArrayOfTAMTINDX() {
        return arrayOfTAMTINDX;
    }


    /**
     * Sets the arrayOfTAMTINDX value for this PCHW078Out_Type.
     * 
     * @param arrayOfTAMTINDX
     */
    public void setArrayOfTAMTINDX(java.lang.String[] arrayOfTAMTINDX) {
        this.arrayOfTAMTINDX = arrayOfTAMTINDX;
    }


    /**
     * Gets the arrayOfTGRANT value for this PCHW078Out_Type.
     * 
     * @return arrayOfTGRANT
     */
    public java.lang.String[] getArrayOfTGRANT() {
        return arrayOfTGRANT;
    }


    /**
     * Sets the arrayOfTGRANT value for this PCHW078Out_Type.
     * 
     * @param arrayOfTGRANT
     */
    public void setArrayOfTGRANT(java.lang.String[] arrayOfTGRANT) {
        this.arrayOfTGRANT = arrayOfTGRANT;
    }


    /**
     * Gets the arrayOfTGRNTDTL value for this PCHW078Out_Type.
     * 
     * @return arrayOfTGRNTDTL
     */
    public java.lang.String[] getArrayOfTGRNTDTL() {
        return arrayOfTGRNTDTL;
    }


    /**
     * Sets the arrayOfTGRNTDTL value for this PCHW078Out_Type.
     * 
     * @param arrayOfTGRNTDTL
     */
    public void setArrayOfTGRNTDTL(java.lang.String[] arrayOfTGRNTDTL) {
        this.arrayOfTGRNTDTL = arrayOfTGRNTDTL;
    }


    /**
     * Gets the arrayOfTINDX value for this PCHW078Out_Type.
     * 
     * @return arrayOfTINDX
     */
    public java.lang.String[] getArrayOfTINDX() {
        return arrayOfTINDX;
    }


    /**
     * Sets the arrayOfTINDX value for this PCHW078Out_Type.
     * 
     * @param arrayOfTINDX
     */
    public void setArrayOfTINDX(java.lang.String[] arrayOfTINDX) {
        this.arrayOfTINDX = arrayOfTINDX;
    }


    /**
     * Gets the arrayOfTLIQDAMT value for this PCHW078Out_Type.
     * 
     * @return arrayOfTLIQDAMT
     */
    public java.lang.String[] getArrayOfTLIQDAMT() {
        return arrayOfTLIQDAMT;
    }


    /**
     * Sets the arrayOfTLIQDAMT value for this PCHW078Out_Type.
     * 
     * @param arrayOfTLIQDAMT
     */
    public void setArrayOfTLIQDAMT(java.lang.String[] arrayOfTLIQDAMT) {
        this.arrayOfTLIQDAMT = arrayOfTLIQDAMT;
    }


    /**
     * Gets the arrayOfTPRJDTL value for this PCHW078Out_Type.
     * 
     * @return arrayOfTPRJDTL
     */
    public java.lang.String[] getArrayOfTPRJDTL() {
        return arrayOfTPRJDTL;
    }


    /**
     * Sets the arrayOfTPRJDTL value for this PCHW078Out_Type.
     * 
     * @param arrayOfTPRJDTL
     */
    public void setArrayOfTPRJDTL(java.lang.String[] arrayOfTPRJDTL) {
        this.arrayOfTPRJDTL = arrayOfTPRJDTL;
    }


    /**
     * Gets the arrayOfTPROJCT value for this PCHW078Out_Type.
     * 
     * @return arrayOfTPROJCT
     */
    public java.lang.String[] getArrayOfTPROJCT() {
        return arrayOfTPROJCT;
    }


    /**
     * Sets the arrayOfTPROJCT value for this PCHW078Out_Type.
     * 
     * @param arrayOfTPROJCT
     */
    public void setArrayOfTPROJCT(java.lang.String[] arrayOfTPROJCT) {
        this.arrayOfTPROJCT = arrayOfTPROJCT;
    }


    /**
     * Gets the arrayOfTSFX value for this PCHW078Out_Type.
     * 
     * @return arrayOfTSFX
     */
    public java.lang.String[] getArrayOfTSFX() {
        return arrayOfTSFX;
    }


    /**
     * Sets the arrayOfTSFX value for this PCHW078Out_Type.
     * 
     * @param arrayOfTSFX
     */
    public void setArrayOfTSFX(java.lang.String[] arrayOfTSFX) {
        this.arrayOfTSFX = arrayOfTSFX;
    }


    /**
     * Gets the arrayOfTSUBOBJ value for this PCHW078Out_Type.
     * 
     * @return arrayOfTSUBOBJ
     */
    public java.lang.String[] getArrayOfTSUBOBJ() {
        return arrayOfTSUBOBJ;
    }


    /**
     * Sets the arrayOfTSUBOBJ value for this PCHW078Out_Type.
     * 
     * @param arrayOfTSUBOBJ
     */
    public void setArrayOfTSUBOBJ(java.lang.String[] arrayOfTSUBOBJ) {
        this.arrayOfTSUBOBJ = arrayOfTSUBOBJ;
    }


    /**
     * Gets the arrayOfTUSRCODE value for this PCHW078Out_Type.
     * 
     * @return arrayOfTUSRCODE
     */
    public java.lang.String[] getArrayOfTUSRCODE() {
        return arrayOfTUSRCODE;
    }


    /**
     * Sets the arrayOfTUSRCODE value for this PCHW078Out_Type.
     * 
     * @param arrayOfTUSRCODE
     */
    public void setArrayOfTUSRCODE(java.lang.String[] arrayOfTUSRCODE) {
        this.arrayOfTUSRCODE = arrayOfTUSRCODE;
    }


    /**
     * Gets the RETURNMSG value for this PCHW078Out_Type.
     * 
     * @return RETURNMSG
     */
    public java.lang.String getRETURNMSG() {
        return RETURNMSG;
    }


    /**
     * Sets the RETURNMSG value for this PCHW078Out_Type.
     * 
     * @param RETURNMSG
     */
    public void setRETURNMSG(java.lang.String RETURNMSG) {
        this.RETURNMSG = RETURNMSG;
    }


    /**
     * Gets the TRETAPCT value for this PCHW078Out_Type.
     * 
     * @return TRETAPCT
     */
    public java.lang.String getTRETAPCT() {
        return TRETAPCT;
    }


    /**
     * Sets the TRETAPCT value for this PCHW078Out_Type.
     * 
     * @param TRETAPCT
     */
    public void setTRETAPCT(java.lang.String TRETAPCT) {
        this.TRETAPCT = TRETAPCT;
    }


    /**
     * Gets the INDAMT1 value for this PCHW078Out_Type.
     * 
     * @return INDAMT1
     */
    public java.lang.String getINDAMT1() {
        return INDAMT1;
    }


    /**
     * Sets the INDAMT1 value for this PCHW078Out_Type.
     * 
     * @param INDAMT1
     */
    public void setINDAMT1(java.lang.String INDAMT1) {
        this.INDAMT1 = INDAMT1;
    }


    /**
     * Gets the LQDAMT1 value for this PCHW078Out_Type.
     * 
     * @return LQDAMT1
     */
    public java.lang.String getLQDAMT1() {
        return LQDAMT1;
    }


    /**
     * Sets the LQDAMT1 value for this PCHW078Out_Type.
     * 
     * @param LQDAMT1
     */
    public void setLQDAMT1(java.lang.String LQDAMT1) {
        this.LQDAMT1 = LQDAMT1;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PCHW078Out_Type)) return false;
        PCHW078Out_Type other = (PCHW078Out_Type) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.MAPNAME==null && other.getMAPNAME()==null) || 
             (this.MAPNAME!=null &&
              this.MAPNAME.equals(other.getMAPNAME()))) &&
            ((this.STATUSMSG==null && other.getSTATUSMSG()==null) || 
             (this.STATUSMSG!=null &&
              this.STATUSMSG.equals(other.getSTATUSMSG()))) &&
            ((this.PORMAMT==null && other.getPORMAMT()==null) || 
             (this.PORMAMT!=null &&
              this.PORMAMT.equals(other.getPORMAMT()))) &&
            ((this.POUAP==null && other.getPOUAP()==null) || 
             (this.POUAP!=null &&
              this.POUAP.equals(other.getPOUAP()))) &&
            ((this.POIGFEE==null && other.getPOIGFEE()==null) || 
             (this.POIGFEE!=null &&
              this.POIGFEE.equals(other.getPOIGFEE()))) &&
            ((this.RETAPCT==null && other.getRETAPCT()==null) || 
             (this.RETAPCT!=null &&
              this.RETAPCT.equals(other.getRETAPCT()))) &&
            ((this.MSGTEXT==null && other.getMSGTEXT()==null) || 
             (this.MSGTEXT!=null &&
              this.MSGTEXT.equals(other.getMSGTEXT()))) &&
            ((this.arrayOfTAMTINDX==null && other.getArrayOfTAMTINDX()==null) || 
             (this.arrayOfTAMTINDX!=null &&
              java.util.Arrays.equals(this.arrayOfTAMTINDX, other.getArrayOfTAMTINDX()))) &&
            ((this.arrayOfTGRANT==null && other.getArrayOfTGRANT()==null) || 
             (this.arrayOfTGRANT!=null &&
              java.util.Arrays.equals(this.arrayOfTGRANT, other.getArrayOfTGRANT()))) &&
            ((this.arrayOfTGRNTDTL==null && other.getArrayOfTGRNTDTL()==null) || 
             (this.arrayOfTGRNTDTL!=null &&
              java.util.Arrays.equals(this.arrayOfTGRNTDTL, other.getArrayOfTGRNTDTL()))) &&
            ((this.arrayOfTINDX==null && other.getArrayOfTINDX()==null) || 
             (this.arrayOfTINDX!=null &&
              java.util.Arrays.equals(this.arrayOfTINDX, other.getArrayOfTINDX()))) &&
            ((this.arrayOfTLIQDAMT==null && other.getArrayOfTLIQDAMT()==null) || 
             (this.arrayOfTLIQDAMT!=null &&
              java.util.Arrays.equals(this.arrayOfTLIQDAMT, other.getArrayOfTLIQDAMT()))) &&
            ((this.arrayOfTPRJDTL==null && other.getArrayOfTPRJDTL()==null) || 
             (this.arrayOfTPRJDTL!=null &&
              java.util.Arrays.equals(this.arrayOfTPRJDTL, other.getArrayOfTPRJDTL()))) &&
            ((this.arrayOfTPROJCT==null && other.getArrayOfTPROJCT()==null) || 
             (this.arrayOfTPROJCT!=null &&
              java.util.Arrays.equals(this.arrayOfTPROJCT, other.getArrayOfTPROJCT()))) &&
            ((this.arrayOfTSFX==null && other.getArrayOfTSFX()==null) || 
             (this.arrayOfTSFX!=null &&
              java.util.Arrays.equals(this.arrayOfTSFX, other.getArrayOfTSFX()))) &&
            ((this.arrayOfTSUBOBJ==null && other.getArrayOfTSUBOBJ()==null) || 
             (this.arrayOfTSUBOBJ!=null &&
              java.util.Arrays.equals(this.arrayOfTSUBOBJ, other.getArrayOfTSUBOBJ()))) &&
            ((this.arrayOfTUSRCODE==null && other.getArrayOfTUSRCODE()==null) || 
             (this.arrayOfTUSRCODE!=null &&
              java.util.Arrays.equals(this.arrayOfTUSRCODE, other.getArrayOfTUSRCODE()))) &&
            ((this.RETURNMSG==null && other.getRETURNMSG()==null) || 
             (this.RETURNMSG!=null &&
              this.RETURNMSG.equals(other.getRETURNMSG()))) &&
            ((this.TRETAPCT==null && other.getTRETAPCT()==null) || 
             (this.TRETAPCT!=null &&
              this.TRETAPCT.equals(other.getTRETAPCT()))) &&
            ((this.INDAMT1==null && other.getINDAMT1()==null) || 
             (this.INDAMT1!=null &&
              this.INDAMT1.equals(other.getINDAMT1()))) &&
            ((this.LQDAMT1==null && other.getLQDAMT1()==null) || 
             (this.LQDAMT1!=null &&
              this.LQDAMT1.equals(other.getLQDAMT1())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMAPNAME() != null) {
            _hashCode += getMAPNAME().hashCode();
        }
        if (getSTATUSMSG() != null) {
            _hashCode += getSTATUSMSG().hashCode();
        }
        if (getPORMAMT() != null) {
            _hashCode += getPORMAMT().hashCode();
        }
        if (getPOUAP() != null) {
            _hashCode += getPOUAP().hashCode();
        }
        if (getPOIGFEE() != null) {
            _hashCode += getPOIGFEE().hashCode();
        }
        if (getRETAPCT() != null) {
            _hashCode += getRETAPCT().hashCode();
        }
        if (getMSGTEXT() != null) {
            _hashCode += getMSGTEXT().hashCode();
        }
        if (getArrayOfTAMTINDX() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTAMTINDX());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTAMTINDX(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArrayOfTGRANT() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTGRANT());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTGRANT(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArrayOfTGRNTDTL() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTGRNTDTL());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTGRNTDTL(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArrayOfTINDX() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTINDX());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTINDX(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArrayOfTLIQDAMT() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTLIQDAMT());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTLIQDAMT(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArrayOfTPRJDTL() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTPRJDTL());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTPRJDTL(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArrayOfTPROJCT() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTPROJCT());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTPROJCT(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArrayOfTSFX() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTSFX());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTSFX(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArrayOfTSUBOBJ() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTSUBOBJ());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTSUBOBJ(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArrayOfTUSRCODE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArrayOfTUSRCODE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArrayOfTUSRCODE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRETURNMSG() != null) {
            _hashCode += getRETURNMSG().hashCode();
        }
        if (getTRETAPCT() != null) {
            _hashCode += getTRETAPCT().hashCode();
        }
        if (getINDAMT1() != null) {
            _hashCode += getINDAMT1().hashCode();
        }
        if (getLQDAMT1() != null) {
            _hashCode += getLQDAMT1().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PCHW078Out_Type.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "PCHW078Out_Type"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MAPNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "MAPNAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STATUSMSG");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "STATUSMSG"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PORMAMT");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "PORMAMT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("POUAP");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "POUAP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("POIGFEE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "POIGFEE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RETAPCT");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "RETAPCT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MSGTEXT");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "MSGTEXT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTAMTINDX");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "ArrayOfTAMTINDX"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "TAMTINDX"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTGRANT");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "ArrayOfTGRANT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "TGRANT"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTGRNTDTL");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "ArrayOfTGRNTDTL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "TGRNTDTL"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTINDX");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "ArrayOfTINDX"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "TINDX"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTLIQDAMT");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "ArrayOfTLIQDAMT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "TLIQDAMT"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTPRJDTL");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "ArrayOfTPRJDTL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "TPRJDTL"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTPROJCT");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "ArrayOfTPROJCT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "TPROJCT"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTSFX");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "ArrayOfTSFX"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "TSFX"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTSUBOBJ");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "ArrayOfTSUBOBJ"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "TSUBOBJ"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrayOfTUSRCODE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "ArrayOfTUSRCODE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "TUSRCODE"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RETURNMSG");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "RETURNMSG"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TRETAPCT");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "TRETAPCT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("INDAMT1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "INDAMT1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LQDAMT1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "LQDAMT1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
