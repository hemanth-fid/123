/**
* This class is for displaying to provide datagrid for history details of selected task.
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.workflow.taskhistory;

import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfQueueItem;
import com.documentum.fc.client.IDfWorkitem;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.formext.component.Component;
import com.documentum.webcomponent.library.workflow.WorkflowService;

public class TaskHistory extends Component
{
	private static final long serialVersionUID = 1L;
	private String m_workflowIdStr;
    public static final String AUDIT_HISTORY_GRID_CONTROL_NAME = "__AUDIT_HISTORY_GRID_CONTROL_NAME";
    String taskId = ""; 
    	
    public TaskHistory()
    {
    }

    public void onInit(ArgumentList arg)
    {
		taskId = arg.get("objectId");
		DfLogger.info(this," :: onInit() : taskId : "+taskId,null,null);
    	super.onInit(arg);
    }
    
    public void onRender() {
            DfLogger.info(this," :: onRender() : taskId : "+taskId,null,null);
        try
        {
        	DfLogger.info(this, " :: onRender : "+getDfSession().getLoginUserName(), null, null);
            if(WorkflowService.isWorkflowId(taskId))
            {
                m_workflowIdStr = taskId;
            } else 
            	if(WorkflowService.isWorkitemId(taskId))
            {
                IDfWorkitem workItemObj = (IDfWorkitem)getDfSession().getObject(new DfId(taskId));
                m_workflowIdStr = workItemObj.getWorkflowId().toString();
            } else
            {
                IDfQueueItem queueItemObj = (IDfQueueItem)getDfSession().getObject(new DfId(taskId));
                m_workflowIdStr = queueItemObj.getRouterId().toString();
            }
            DfLogger.info(this," :: onRender() : m_workflowIdStr : "+m_workflowIdStr,null,null);
            Datagrid datagrid = (Datagrid)getControl("newgrid", Datagrid.class);
            datagrid.getDataProvider().setDfSession(getDfSession());
            String strGetHistoryQuery = null;
            if(IdocsUtil.isAdvisoryServicesWF(m_workflowIdStr, getDfSession())){
            	strGetHistoryQuery = IdocsUtil.getMessage("QRY_GET_ASOP_TASK_PROGRESS").replace(IdocsConstants.MSG_C_DQ_C, IdocsConstants.MSG_QUOTES+m_workflowIdStr+IdocsConstants.MSG_QUOTES);            	
            }else{
            	strGetHistoryQuery = IdocsUtil.getMessage("QRY_GET_TASK_PROGRESS").replace(IdocsConstants.MSG_C_DQ_C, IdocsConstants.MSG_QUOTES+m_workflowIdStr+IdocsConstants.MSG_QUOTES);            	
            }
            datagrid.getDataProvider().setQuery(strGetHistoryQuery);
//            updateControls();
        }
        catch(DfException e)
        {
        	DfLogger.error(this, " :: onInit Exception >> "+e.getMessage(), null, e);
            throw new WrapperRuntimeException(e);
        }
    	super.onRender();
    }
}
