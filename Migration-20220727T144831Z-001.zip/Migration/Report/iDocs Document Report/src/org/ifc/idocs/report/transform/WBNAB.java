package org.ifc.idocs.report.transform;

import lotus.domino.Database;
import lotus.domino.NotesException;

import org.ifc.idocs.report.common.AppConfig;
import org.ifc.idocs.report.common.NotesSession;

/**
 * @author SPankajamsadanan
 *
 */
public class WBNAB {
	
	private WBNAB(){}
	private static Database db = null;
	
	/**
	 * @return Database object
	 * @throws NotesException
	 */
	public static Database getInstance() throws NotesException {
		if (db == null) {
			String server = "";
			if (!NotesSession.getInstance().isOnServer()) {
				server = AppConfig.getInstance().getString("repository.server");
			}
			db = NotesSession.getInstance().getDatabase(server, "wbnames.nsf");
		}
		return db;
	}

	/**
	 * recycle method
	 * @return void
	 */
	public static void recycle() {
		if (db != null) {
			try {
				db.recycle();
			} catch (NotesException e) {
				e.printStackTrace();
			}
			db = null;
		}
	}
}
