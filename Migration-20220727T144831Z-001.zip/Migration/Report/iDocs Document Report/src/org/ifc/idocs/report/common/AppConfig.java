package org.ifc.idocs.report.common;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;

public class AppConfig extends XMLConfiguration {

	private static final long serialVersionUID = 239973206750886170L;
	private static AppConfig instance;
	private static String configFile = "config.xml";

	// Singleton initializer
	static {
		instance = new AppConfig(configFile);
	}

	private AppConfig(String fileName) {
		init(fileName);
	}

	private void init(String fileName) {
		setFileName(fileName);
		try {
			load();
		} catch (ConfigurationException configEx) {
//			configEx.printStackTrace();
			System.out.println("Cannot locate configuration xml file. Please check the file name or the file location");
			System.exit(0);
		}
	}

	public static AppConfig getInstance() {
		return instance;
	}
}

