package org.ifc.idocs.migration.common;

import java.io.File;

import lotus.domino.Database;
import lotus.domino.DbDirectory;
import lotus.domino.NotesException;

import org.ifc.idocs.migration.extract.NotesSession;

public class DeleteTempDatabase {

	public static void main(String[] args) throws NotesException {
		String tempDbPath = args[0] + "\\";
		File files = new File(tempDbPath);
		String[] children = files.list();
		for (int i=0; i<children.length; i++) {
			if(children[i].contains("extraction_temp_")){
				System.out.println("Deleting ... " + children[i]);
				DbDirectory dbdir = NotesSession.getInstance().getDbDirectory(null);
				Database db = dbdir.openDatabase(tempDbPath+children[i]);
				db.remove();
				System.out.println(children[i] +  " deleted...!!!");
			}
		}
	}
}
