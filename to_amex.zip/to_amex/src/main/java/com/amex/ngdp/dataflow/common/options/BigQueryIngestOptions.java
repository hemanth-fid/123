package com.amex.ngdp.dataflow.common.options;


import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.options.PipelineOptions;

public interface BigQueryIngestOptions extends PipelineOptions {

 @Default.String("my-project:my_dataset.my_table")
  String getBqTableName();

  void setBqTableName(String tableName);
  
  @Default.String("gs://my-bucket")
  String getBucketUrl();

  void setBucketUrl(String bucketUrl);

}
