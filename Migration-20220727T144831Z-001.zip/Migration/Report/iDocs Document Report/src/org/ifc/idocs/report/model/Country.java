package org.ifc.idocs.report.model;

/**
 * @author SPankajamsadanan
 * @category Country is a java template class for development
 *
 */
public class Country {

	private String countryName;
	private String countryCode;

	/**
	 * Constructor for Country
	 * @param countryCode
	 * @param countryName
	 */
	public Country(String countryCode, String countryName) {
		super(); 
		this.countryCode = countryCode;
		this.countryName = countryName;
	}
		
	public String getCountryName() {
		return countryName;
	}
	
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	
	public String getCountryCode() {
		return countryCode;
	}
	
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
}
