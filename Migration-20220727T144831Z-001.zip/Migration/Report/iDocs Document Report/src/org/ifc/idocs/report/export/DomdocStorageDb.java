package org.ifc.idocs.report.export;

import lotus.domino.Database;
import lotus.domino.DateTime;
import lotus.domino.DbDirectory;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesError;
import lotus.domino.NotesException;

import org.ifc.idocs.report.common.NotesSession;
import org.ifc.idocs.report.model.DomdocRepository;

/**
 * @author SPankajamsadanan
 *
 */
public class DomdocStorageDb {
	
	private Database db;

	/**
	 * DomdocStorageDb constructor
	 * @param domdoc
	 * @param replicaId
	 * @throws NotesException
	 */
	public DomdocStorageDb(DomdocRepository domdoc, String replicaId) throws NotesException {
		DbDirectory dbdir = NotesSession.getInstance().getDbDirectory(domdoc.getServerName());//commented soumya
		this.db = dbdir.openDatabaseByReplicaID(replicaId);
		if (db == null) {
			throw new NotesException(NotesError.NOTES_ERR_ERROR, "Could not open database by replica id-Database is Null " + replicaId);
		}
		if (!db.isOpen()) {
			throw new NotesException(NotesError.NOTES_ERR_ERROR, "Could not open database by replica id -DatabaseB Not opening-" + replicaId);
		}
	}

	/**
	 * @throws NotesException
	 */
	public void recycle() throws NotesException {
		this.db.recycle();
	}

	/**
	 * findDocuments method
	 * @param query
	 * @param cutoff
	 * @return DocumentCollection
	 * @throws NotesException
	 */
	public DocumentCollection findDocuments(String query, DateTime cutoff) throws NotesException {
		String baseQuery = "ObjectType='Document'";
		String searchStr;
		if (query != null) {
			searchStr = baseQuery + " & " + query;
		} else {
			searchStr = baseQuery;
		}
//		System.out.println("Document Query : " + searchStr);
		return this.db.search(searchStr, cutoff);
	}
}
