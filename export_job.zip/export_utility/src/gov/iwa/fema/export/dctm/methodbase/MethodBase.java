package gov.iwa.fema.export.dctm.methodbase;


import gov.iwa.fema.export.dctm.utils.IUtilConstants;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfModule;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.fc.methodserver.IDfMethod;




public abstract class MethodBase implements IDfModule, IDfMethod {


	private static Logger log = DfLogger.getLogger(MethodBase.class);
	

	//Default parameters passed by invocation of the job
	private static final String KEY_USER = "user_name";
	private static final String KEY_DOCBASE = "docbase_name";
	private static final String KEY_PASSWORD = "password";
	private static final String KEY_DOMAIN = "domain";
	private static final String METHOD_ARGUMENTS="method_arguments";
	private static final String JOB_ID = "job_id";

	

	private Map<String, Object> params;
	private String docbase;
	private String userName;
	private String password;
	private String domain;
	private PrintWriter output;
	private IDfSessionManager sessionManager;
	private IDfSession session;
	
	private String jobId;

	public Map<String,String> customArguments;

	/**
	 * Initialize all member variables to null
	 *
	 * @param options
	 */
	public MethodBase() {
		super();
		this.params = null;
		this.docbase = null;
		this.userName = null;
		this.password = null;
		this.domain = null;
		this.output = null;
		this.session = null;
	}


	@SuppressWarnings("unchecked")
	public int execute(Map params, PrintWriter output) throws Exception {
		int returnValue = -1;
		try {

			log.debug("Method base.....");
			this.output = output;
			
			log.debug("Initializing parameters");
			initParams(params);
			
			log.debug("Initializing Session");
			initSession();

			log.debug("Populating Custom Arguments");
			populateCustomArguments();

			log.debug("Start doExecute()");
			
			doExecute();
			
			log.debug("End doExecute()");
			
			returnValue = 0;
		}catch (IOException e) {
			log.error(prefixError(), e);
			writeToOutput(prefixError(), e);
			throw e;
		} catch (Exception e) {
			log.error(prefixError(), e);
			writeToOutput(prefixError(), e);
			throw e;
		} catch (Throwable t) {
			log.error(prefixError(), t);
			writeToOutput(prefixError(),  new RuntimeException(t));
			throw new RuntimeException(t);
		} finally {
			try {
				closeSession();
			} catch (Exception e) {
				log.warn("Error while closing session", e);
			}
		}


		return returnValue;
	}


	/**
	 *
	 * @param message
	 * @param t
	 */
	protected void writeToOutput(String message, Throwable t) {
		if (output != null) {
			output.println(message);
			if (t != null) {
				t.printStackTrace(output);
			}
		} else {
			log.debug(message, t);
		}
	}


	/**
	 * Parse the standard method arguments
	 *
	 * @param params
	 *        Standard parameter pairs passed in from the method server.
	 */
	protected void initParams(Map<String, Object> params) throws Exception {
		this.params = params;


		Set<String> keys = params.keySet();
		String key = null;
		Iterator<String> iter = keys.iterator();
		String[] value = null;

		while (iter.hasNext()) {
			key = iter.next();
			if ((key == null) || (key.length() == 0)) {
				continue;
			}
			log.debug("Key  ...."+key);
			value = (String[]) params.get(key);
			if(value != null && value.length>0) {
				writeToOutput("Key  "+key+"Value --"+Arrays.toString(value),null);
			} else {
				writeToOutput("Key is "+key,null);           
			}
			if (key.equalsIgnoreCase(KEY_USER)) {
				userName = (value != null && value.length > 0) ? value[0] : "";


				writeToOutput("User name is "+userName,null);
			} else if ( key.equalsIgnoreCase(KEY_DOCBASE)) {
				docbase = (value != null && value.length > 0) ? value[0] : "";
				writeToOutput("Docbase is "+docbase,null);
			} else if (key.equalsIgnoreCase(KEY_PASSWORD)) {
				password = (value != null && value.length > 0) ? value[0] : "";
			}else if (key.equalsIgnoreCase(KEY_DOMAIN)) {
				domain = (value != null && value.length > 0) ? value[0] : "";
			} else if(key.equalsIgnoreCase(JOB_ID)) {
				jobId = (value != null && value.length > 0) ? value[0] : "";
			}
		}

	}


	/**
	 * Populate the custom arguments in map.
	 */
	protected void populateCustomArguments() throws Exception {

		Iterator<String> ite = null;
		String arguments = null;
		int count =0;
		String key = null;
		try {

			IDfSysObject jobObject = (IDfSysObject) session.getObject((IDfId)new DfId(jobId));
			customArguments = new HashMap<String, String>();
			count = jobObject.getValueCount(METHOD_ARGUMENTS);
			for(int i=0;i<count;i++) {
				arguments=StringUtils.substringAfter(jobObject.getRepeatingString(METHOD_ARGUMENTS, i),IUtilConstants.HYPHEN);
				customArguments.put(StringUtils.substringBefore(arguments, IUtilConstants.SINGLE_SPACE),
						StringUtils.remove(StringUtils.substringAfter(arguments,IUtilConstants.SINGLE_SPACE ),"\""));
			}


			if(!customArguments.isEmpty()) {
				ite = customArguments.keySet().iterator();
				log.debug("Custom Arguments are ");
				while(ite.hasNext()) {
					key = ite.next();
					log.debug(key+"  "+customArguments.get(key));
				}
			}

		} catch(Exception e) {
			log.error("Error while populating the custom arguments ",e);
			throw e;
		}


	}


	/**
	 * Helper method to close DfCollection, closing exceptions will be logged.
	 *
	 * @param collection
	 */
	protected void closeCollection(IDfCollection collection) {
		if (collection != null &&  collection.getState()!=IDfCollection.DF_CLOSED_STATE) {
			try {
				collection.close();
			} catch (DfException e) {
				log.warn( "Error while closing collection", e);
			}
		}
	}

	protected String getDocbase() {
		return docbase;
	}


	protected String getUserName() {
		return userName;
	}


	/**
	 * The base implementation returns the parameters that were passed.
	 *
	 * @return
	 */
	protected String prefixError() {
		StringBuffer sb = new StringBuffer("\nMethod Params:");


		Iterator<String> keys = params.keySet().iterator();
		Object key, value;


		while (keys.hasNext()) {
			key = keys.next();
			value = params.get(key);


			sb.append(" ");
			sb.append(key);
			sb.append("=");
			if (key instanceof String && (KEY_PASSWORD.equalsIgnoreCase((String) key))) {
				// don't output password to the logs
				sb.append("****");
			} else {
				if (value instanceof String[]) {
					String[] values = (String[]) value;
					sb.append("[");
					for (int i = 0; i < values.length; i++) {
						if (i > 0) {
							sb.append(", ");
						}
						sb.append(values[i]);
					}
					sb.append("]");
				} else {
					sb.append(value);
				}
			}
			sb.append(";");
		}


		return sb.toString();
	}


	/**
	 * Initialize Session This method logs the user in, and then gets the session object for the given docbase.
	 *
	 * @throws DfException
	 */
	private void initSession() throws DfException {
		sessionManager = createSessionManager();
		session = sessionManager.getSession(docbase);
	}


	private  IDfSessionManager createSessionManager() throws DfException {
		IDfClient dfClient = null;
		IDfLoginInfo li = null;
		IDfSessionManager sessionMgr = null;

		//password does not need to be specified because the job object is 'run as server'
		if ((this.docbase != null) && (this.userName != null)) {
			dfClient = DfClient.getLocalClient();

			if (dfClient != null) {
				li = new DfLoginInfo();
				li.setUser(this.userName);
				li.setDomain(null);

				sessionMgr = dfClient.newSessionManager();
				this.docbase=StringUtils.substringBefore(this.docbase, IUtilConstants.DOT);
				sessionMgr.setIdentity(this.docbase, li);
				log.debug("Created session manager");

			}
		} else {
			throw new DfException("Missing required login field: docbase=" + this.docbase + ", username=" + this.userName);
		}


		return sessionMgr;
	}


	/**
	 * This method performs the session cleanup by closing both the session and session manager
	 *
	 * @throws DfException
	 */
	private void closeSession() throws DfException {
		
		if (session != null) {
			sessionManager.release(session);
			log.debug("Releases session");
			session = null;
		}

	}

	/**
	 * This is the method the classes extending this class should perform their work.
	 *
	 * @throws Exception
	 */
	protected abstract void doExecute() throws Exception;

	
	protected IDfSession getSession() {
		return session;
	}

	
	// TODO : Change public to protected when deploying to server
	public void setSession(IDfSession session) {
		this.session= session;
	}

	
	protected IDfSessionManager getSessionManager() {
		return sessionManager;
	}

	protected Map<String, Object> getParams() {
		return params;
	}


	public String getStringProperty(String propertyName) {
		String value = null;
		value = customArguments.get(propertyName);
		log.debug("The value for property "+propertyName+" --- "+value);
		return value;
	}


	public PrintWriter getOutput() {
		return output;
	}

	public String getJobId() {
		return jobId;
	}


	public void setJobId(String jobId) {
		this.jobId = jobId;
	}


	public void setDocbase(String docbase) {
		this.docbase = docbase;
	}

	

	//TODO : Remove setter and getter when deploying to server(Added for local TESTING)
	public Map<String, String> getCustomArguments() {
		return customArguments;
	}


	public void setCustomArguments(Map<String, String> customArguments) {
		this.customArguments = customArguments;
	}


	
}