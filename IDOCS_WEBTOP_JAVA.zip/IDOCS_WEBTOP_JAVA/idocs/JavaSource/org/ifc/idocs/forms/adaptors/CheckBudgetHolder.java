package org.ifc.idocs.forms.adaptors;


import org.ifc.idocs.utils.IdocsUtil;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfLogger;
import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.IAdaptorParameter;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import com.documentum.xforms.engine.adaptor.datasource.ISetValueAdaptor;


/**
 * 
 * @author SSubramanian11
 *
 */

public class CheckBudgetHolder implements ISetValueAdaptor{

	public Object execute(IAdaptorParameter[] parameter) throws AdaptorException {
		
		String projectId = null;		
		IDfCollection userExistanceColl;
		IDfSession session = null;
		String userExistanceQry = null;
		boolean isExist = false;
		
		try{
			projectId = parameter[0].getValue().toString();
			DfLogger.info(this," : Project Id : "+projectId,null,null);
			userExistanceQry = IdocsUtil.getMessage("CHK_BUDGET_HOLDER_QRY_ADAPTER");
			userExistanceQry = userExistanceQry.replaceAll("%projectId%", projectId);
			DfLogger.info(this," :: Check Budget Qry : "+userExistanceQry,null,null);
			
			IDfQuery qryObj =  new DfQuery();
			qryObj.setDQL(userExistanceQry);
			
			session = SessionManagerHttpBinding.getSessionManager().getSession(SessionManagerHttpBinding.getCurrentDocbase());
			userExistanceColl = qryObj.execute(session, IDfQuery.DF_READ_QUERY);
			
			try{
				while(userExistanceColl.next()){
					DfLogger.info(this, " : Inside Collection.. ", null, null);
					isExist = true;					
				}
			}
			finally{
				if(userExistanceColl != null){
					userExistanceColl.close();
				}
			}
			DfLogger.info(this, " : Is User Exists for BH : " + isExist, null, null);
			
		}
		catch(Exception e){
			DfLogger.info(this, " : <Exception Occured> : " + e.getMessage(), null, null);
		}
		finally{
			SessionManagerHttpBinding.getSessionManager().release(session);
		}
		
		return isExist;
	}

	public void destroy() throws AdaptorException {
		DfLogger.info(this, " : Inside the destroy method...", null, null);
	}

	public void init(IAdaptorConfiguration arg0) throws AdaptorException {		
		DfLogger.info(this, " : Inside the init method...", null, null);
	}

	
}
