package org.ifc.idocs.foldersync;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.env.EnvironmentService;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.Button;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.Panel;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.component.DialogContainer;

public class FolderSyncContainer extends DialogContainer{

	public static final String CONTROL_HELPBUTTON = "help";
    public static final String NLSIDTITLEPANEL = "nlsidTitlePanel";
    public static final String PARAMTITLEPANEL = "ParamTitlePanel";
    public static final String SUBTITLE = "subTitle";
    public static final String TITLE = "title";
    public static final String NLSIDSUBTITLEPANEL = "nlsidSubTitlePanel";
    public static final String PARAMSUBTITLEPANEL = "paramSubTitlePanel";

    public FolderSyncContainer()
    {
    }

    public void onInit(ArgumentList args)
    {
        super.onInit(args);
        initHelpButton();
        initControls(args);
    }

    private void initControls(ArgumentList args)
    {
        if(args.get("title") == null)
        {
            showPanel("ParamTitlePanel", false);
        } else
        {
            setLabel("title", args.get("title"));
            showPanel("nlsidTitlePanel", false);
        }
        if(args.get("subTitle") == null)
        {
            showPanel("paramSubTitlePanel", false);
        } else
        {
            setLabel("subTitle", args.get("subTitle"));
            showPanel("nlsidSubTitlePanel", false);
        }
    }

    private void setLabel(String strLabelName, String strLabelValue)
    {
        Label label = (Label)getControl(strLabelName, com.documentum.web.form.control.Label.class);
        if(label != null)
        {
            label.setLabel(strLabelValue);
        }
    }

    private void showPanel(String strPanelName, boolean blnShow)
    {
        Panel panel = (Panel)getControl(strPanelName, com.documentum.web.form.control.Panel.class);
        if(panel != null)
        {
            panel.setVisible(blnShow);
        }
    }

    public void onRender()
    {
        super.onRender();
        initHelpButton();
    }

    public boolean canCommitChanges()
    {
        Component component = getContainedComponent();
        return component.canCommitChanges();
    }

    public boolean canCancelChanges()
    {
        Component component = getContainedComponent();
        return component.canCancelChanges();
    }

    public boolean onCommitChanges()
    {
        Component component = getContainedComponent();
        return component.onCommitChanges();
    }

    public boolean onCancelChanges()
    {
        Component component = getContainedComponent();
        return component.onCancelChanges();
    }

    public void onOk(Control button, ArgumentList args)
    {
        if(canCommitChanges() && onCommitChanges() && getTopForm().getCallerForm() != null)
        {
            setComponentReturn();
        }
    }

   

    public void updateControls()
    {
        super.updateControls();
        Component component = getContainedComponent();
        if(component != null)
        {
            boolean bCanCommitChanges = canCommitChanges();
            boolean bCanCancelChanges = canCancelChanges();
            boolean bShowOkCancel = bCanCommitChanges || bCanCancelChanges;
            getControl("ok", com.documentum.web.form.control.Button.class).setVisible(bShowOkCancel);
            getControl("close", com.documentum.web.form.control.Button.class).setVisible(!bShowOkCancel);
            getControl("ok", com.documentum.web.form.control.Button.class).setEnabled(bCanCommitChanges);
           
        }
    }

    protected void initHelpButton()
    {
        Button helpButton = (Button)getControl("help", com.documentum.web.form.control.Button.class);
        if(helpButton != null)
        {
            if(EnvironmentService.getEnvironment().isPortalEnvironment())
            {
                helpButton.setVisible(false);
            } else
            {
                helpButton.setVisible(true);
            }
        }
    }
}
