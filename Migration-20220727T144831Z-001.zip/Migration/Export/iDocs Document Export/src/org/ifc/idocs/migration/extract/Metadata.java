package org.ifc.idocs.migration.extract;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import lotus.domino.Document;
import lotus.domino.NotesError;
import lotus.domino.NotesException;

import org.w3c.dom.Element;

/**
 * @author SPankajamsadanan
 *
 */
public class Metadata extends HashMap<String, Object> {

	private static final long serialVersionUID = 4808277321742539576L;

	/**
	 * Metadata constructor with argument
	 * @param i
	 */
	public Metadata(int i) {
		super(i);
	}

	/**
	 * Metadata constructor
	 */
	public Metadata() {
		super();
	}

	/**
	 * populateFromNotesDocument method
	 * @param doc
	 * @throws NotesException
	 */
	@SuppressWarnings("unchecked")
	public void populateFromNotesDocument(Document doc) throws NotesException {
		Iterator<String> it = keySet().iterator();
		while (it.hasNext()) {
			String fieldname = it.next();
			if (fieldname.endsWith("*")) {
				String fn = fieldname.substring(0, fieldname.length() - 1);
				int i = 1;
				while (doc.hasItem(fn + i)) {
					Vector v1 = doc.getItemValue(fn + i);	//ActivityLog1,ActivityLog2...etc
					((Vector)get(fieldname)).addAll(v1);
					i++;
				} 				
			} else {	//if fieldname doesnt end with *
				Vector v = doc.getItemValue(fieldname);
//				System.out.println("%%%%%%%%%%vector="+fieldname+"~"+v);
//				start
//				DateTime createdDate= doc.getCreated();
//				DateTime lastModContent = doc.getLastModified();
//				if (fieldname.equals("CreatedDate") &&  v.equals("[]")) {
//					System.out.println("created data is empty"+createdDate);
//					put(fieldname, createdDate);
//				}
//				if(fieldname.equals("LastModContent") &&  v.equals("")){
//					put(fieldname,lastModContent);
//				}
//				else
//					put(fieldname, v.elementAt(0).toString());
//				end
//				end
				if (v != null) {
					if (v.size()==1) {
						//single-value string
						if (v.elementAt(0) instanceof Double) {
							if (((Double)v.elementAt(0)).intValue() == (Double)v.elementAt(0) ) {
								//int value
								put(fieldname, (new Integer(((Double)v.elementAt(0)).intValue())).toString());
							} else {
								//float or double
								put(fieldname, v.elementAt(0).toString());
							}
						} else {
							//string or date
							put(fieldname, v.elementAt(0).toString());
//							
						}
					} else if (v.size()>1) {
						//multi-value string
						put(fieldname, doc.getItemValue(fieldname));
//						
					}	
				}
			}		
		}
	}

	/**
	 * getFileroomId method
	 * @return String file room id
	 * @throws NotesException
	 */
	public String getFileroomId() throws NotesException {
		if (get("Fileroom").equals("PROJECTS"))
			return "Projects\\" + get("Project_id");
		else if (get("Fileroom").equals("INSTITUTIONS"))
			return "Institutions\\" + get("Institution_nbr");
		else if (get("Fileroom").equals("MISCELLANEOUS"))
			return "Countries\\" + get("Country_name_code");
		else 
			throw new NotesException(NotesError.NOTES_ERR_ERROR, "Unexpected fileroom value");
	}

	/**
	 * exportToXML method
	 * @param xmlnode
	 * @throws NotesException
	 */
	@SuppressWarnings("unchecked")
	public void exportToXML(Element xmlnode) throws NotesException {
		org.w3c.dom.Document xmldoc = xmlnode.getOwnerDocument();
		Iterator<String> it = keySet().iterator();
		while (it.hasNext()) {
			String fieldname = it.next();
			Vector v;
			if (get(fieldname) instanceof Vector) 
				v = (Vector)get(fieldname);
			else {
				v = new Vector();
				if (get(fieldname).toString().length()>0){
					v.add(get(fieldname));
				}
			}		
			if (fieldname.endsWith("*")) {
				fieldname = fieldname.substring(0, fieldname.length()-1);
			}  
//			TODO Dollar value
			if (fieldname.startsWith("$")) {
				fieldname = fieldname.substring(1, fieldname.length());
			} 

			Element xmlfield = xmldoc.createElement(fieldname);
			int vSize = v.size();
			for (int i=0; i < vSize; i++){
				Element fvalue = xmldoc.createElement("value");
				org.w3c.dom.Text vvalue = xmldoc.createTextNode(v.elementAt(i).toString());

				fvalue.appendChild(vvalue);
				xmlfield.appendChild(fvalue);
			}
			xmlnode.appendChild(xmlfield);
		}
	}
}
