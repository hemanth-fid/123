package org.ifc.idocs.migration;

import java.util.logging.Logger;

import org.ifc.idocs.migration.extract.DBConnection;
import org.ifc.idocs.migration.extract.LogHelper;

import lotus.domino.*;
public class Deletion {
	static boolean utilityIdFlag = false;
	protected static String utilityId = "";
public static void main(String[] args) {
	Logger exportDocLogger = LogHelper.getLogger(Deletion.class);
	String password="sp62127816ifc";
	 String path="C:\\Users\\SPankajamsadanan\\AppData\\Local\\Lotus\\Notes\\Data\\EDMSLog.nsf";
    	try
	    {
		if(utilityIdFlag){ // Multiple log files will be created when a new extraction criteria code exists
			ExportUtilityMain.getNewUtilityId();
			LogHelper.loggerMap.put("loggerMap",null);
		}
		utilityId = WorkflowAuditTrial.workflowMap.get("utilityId");
			exportDocLogger.info("Extraction Utility ID for Delta  Deletion Upload is : " + utilityId);
			exportDocLogger.info("Uploading deletion entries to migration table-Started");
			NotesThread.sinitThread();
	          Session s= NotesFactory.createSession((String)null, (String)null, password);
	       //    Database db=s.getDatabase(null,path);	
	          DbDirectory dir =s.getDbDirectory(null);
	          Database DbLog =dir.openDatabase(path);
	          exportDocLogger.info("Database is:"+DbLog);
	          //above code bundle needs to be changed when code is moved to server. this code is for local copy of a particular database
	         View mainView  =  DbLog.getView("Delete_Agent_Activity");	//getting the main view from lib database
	         ViewEntryCollection viewcol=mainView.getAllEntries();
	         Integer totalCount=viewcol.getCount();
	         exportDocLogger.info("Total entries in the deletion view="+totalCount);
	          Document doc = mainView.getFirstDocument();
	          String action=null,search="Notes Document Universal ID =";
	      	Integer i=0,len=0;
			String[] unid=null;
			String id,idForUpload = null;
	          while(doc!=null)
	  		{
				action=doc.getItemValueString("A$ACTION");
				i=action.indexOf(search);
					if(i!=-1)
					{
						System.out.println("action="+action);
								unid=action.split("Notes Document Universal ID =");
							len=unid.length;
							for(int j=0;j<len;j++)
							{
							id=unid[j];
							idForUpload=unid[1];
							idForUpload=idForUpload.trim();
							}
							 exportDocLogger.info("UNID of the document that needs to be deleted="+idForUpload);
							//uploading into deletion table
							DBConnection.updateDeltaDeletedDocs(idForUpload);
					}
				doc=mainView.getNextDocument(doc);
			}
	          exportDocLogger.info("Uploading deletion entries to migration table-Completed");
	       }
	       catch(Exception e)
	       {
	           e.printStackTrace();
	       }
	       finally
	       {
	           NotesThread.stermThread();
	           
	       }
	}

}
