/***************************************************************************
 * State Farm
 * Version Template: 2012
 *
 * File Name: WorkflowConstants.java
 *
 * Version     ChgDate          Author           Comments
 * ________   __________       ________         ___________
 * 1.0        03/19/2013         t1or         Initial Creation 
 * 
 * Version     ChgDate          Author           Comments
 * ________   __________       ________         ___________
 * 2.0        07/07/2014         diw6,tysi        Updated
 *
 ***************************************************************************/
package sf.application.custcomm.ccs.constants;

/**
 * <i> ExportProcessConstants </i> contains all the messages as constants that
 * are commonly used in Export Process components
 * 
 * 
 */
public final class CleanUpConstants {
	
	
	/**
	 * private Constructor
	 */
	private CleanUpConstants() {

	}

	// Credential for getting session
	public static final String USERNAME = "username";
	public static final String PASSWORD = "password";
	public static final String DOCBASE = "docbase";
	public static final String SEPARATOR = "--";
	public static final String PARAM_TICKET = "documentum_ticket";
	public static final String PARAM_KEY_LOCATION = "documentum_key_location";
	
	public static final String SVC_EDC_EXPORT_KEY = "SVC_EDC_EXPORT_KEY";
	public static final String PARAM_HOST_NAME = null;
	
	//public static final String SYSTEM_PROPERTIES = "C:\\temp\\system.properties";
	public static final String SYSTEM_PROPERTIES = "D:\\APPS\\EDC\\EDC Purge Services\\System\\system.properties";
	public static final String FORMAT_UTF8 = "UTF-8";
	public static final int NUMBER_OF_BITS = 8;
	// Crypto Util constants
	public static final String CRYPTO_ALGORITHM_NAME = "DESede";
	public static final String CRYPTO_ALGORITM_TRANSFORMAION = "DESede/CBC/PKCS5Padding";
	public static final int NUMBER_ONE = 1;
	public static final Object PARAM_BATCH_PROCESSING_TIMER = null;
	public static final String R_OBJECT_ID = "r_object_id";
	public static final String TIMER_ACTIVITIES = "timer_activities";
	public static final String  PARAM_NEXT_RUN_TIME = "next_run_time";
	public static final String NEW_LINE = "\r\n";
	public static final String FOLDER_SEPARATOR = "\\" ;
	public static final int INDEX_ZERO = 0;

	

	
	
	
}
