package org.ifc.idocs.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.library.actions.LaunchViewComponentWithPermitCheck;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfException;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfList;
import com.documentum.nls.NlsResourceClass;
import com.documentum.operations.IDfCopyNode;
import com.documentum.operations.IDfCopyOperation;
import com.documentum.operations.IDfOperationError;
import com.documentum.services.collaboration.IRoom;
import com.documentum.services.subscriptions.ISubscriptions;
import com.documentum.tools.nls.NlsResourceBundle;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.ConfigService;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigLookup;
import com.documentum.web.formext.control.rooms.Governance;
import com.documentum.web.formext.docbase.FolderUtil;
import com.documentum.web.formext.docbase.TypeUtil;
import com.documentum.web.formext.docbase.VdmStore;
import com.documentum.web.util.DfcUtils;
import com.documentum.webcomponent.library.messages.MessageService;
import com.documentum.webcomponent.library.subscription.SubscriptionsHttpBinding;
import com.documentum.webcomponent.navigation.ClipboardPasteHandler;

public class IDocsClipboardPasteHandler  extends ClipboardPasteHandler{

	private Component m_component;
	public static NlsResourceBundle s_nameBundle = new NlsResourceBundle("com.documentum.web.formext.clipboard.ObjectNameNlsProp");
    
	public IDocsClipboardPasteHandler(Component component, String strDestId) {
		super(component, strDestId);
		this.m_component = component;
		s_nameBundle = new NlsResourceBundle("com.documentum.web.formext.clipboard.ObjectNameNlsProp");
	}
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4997532122124035336L;
	public static final String COPY_OPERATION_NAME = "Copy";
	//public static final String COPY_OPERATION_NAME ="Reference";
	private static final String MSG_COPIED = "Document Copied";
	private static final String MSG_PNP_CABINET_NAME = "MSG_PNP_CABINET_NAME";
	
	protected void copyObject(String strObjectId, String strObjectName,
			int copyPreference) throws DfException {
		//copyPreference=VDM_COPY_PREFRENCE_COPY_ROOTNLINK;
		IDfSession dfSession = m_component.getDfSession();
		// check Email aspect 
		DfLogger.info(this, " :: copyObject: Enter", null, null);
		String newObjects[] = copyObjectEx(dfSession, strObjectId,
				getDestinationId(), copyPreference,m_component);
		for (int i = 0; i < newObjects.length; i++) {
			DfLogger.info(this, " :: copyObjects: "+newObjects[i], null, null);
		}
		DfLogger.info(this, " :: copyObject: Exit", null, null);
		ISubscriptions subscriptions = (new SubscriptionsHttpBinding()).getSubscriptionsService();
		if (subscriptions != null)
				subscriptions.clearCache(dfSession.getDocbaseName());
		if (FolderUtil.isFolderType(strObjectId) && newObjects.length > 0) {
			DfLogger.info(this, " :: copyObjects: are folder type", null, null);
			IDfId destFolderId = new DfId(getDestinationId());
			IDfPersistentObject destFolder = dfSession.getObject(destFolderId);
			if (Governance.isGoverned(destFolder)) {
				IRoom theRoom = (IRoom) dfSession.getObject(Governance.getRoomId(destFolder));
				IDfId newFolderId = new DfId(newObjects[0]);
				IDfSysObject newFolder = (IDfSysObject) dfSession.getObject(newFolderId);
				if (!(newFolder instanceof IRoom)) {
					theRoom.govern(newFolder, true);
					newFolder.save();
				}
			/*}*/
		}
		NlsResourceClass lookup = NlsResourceClass
				.getResource("com.documentum.webcomponent.ClipboardNlsProp");

		MessageService.addMessage(lookup, "MSG_CLIPBOARD_COPY_SUCCESS",
				m_component.getForm(), new Object[] { strObjectName });

		DfLogger.info(this, " :: copyObject: Exit", null, null);
		}
	}
	


	/**
	 * 
	 * @param dfSession
	 * @param strSourceId
	 * @param strDestFolderId
	 * @param vdmCopyPreference
	 * @param mComponent
	 * @return
	 * @throws DfException
	 */
	public static String[] copyObjectEx(IDfSession dfSession,
			String strSourceId, String strDestFolderId, int vdmCopyPreference, Component mComponent)
			throws DfException {
		
		IDfCopyNode node = null;
		ArrayList<String> arrResult = new ArrayList<String>();
		IDfSysObject copyObject = (IDfSysObject) dfSession.getObject(new DfId(
				strSourceId));
		List<String> emailVirtualdocChilds= null;
	
		
		ArrayList<String> aspectNames= new ArrayList<String>();	
		boolean aspectExistance=false;
		int aspectCount=copyObject.getValueCount(IdocsConstants.R_ASPECT_NAME);
		
		if(aspectCount > 0){
			for (int iter1 = 0; iter1 < aspectCount; iter1++) {
				aspectNames.add(copyObject.getRepeatingString(IdocsConstants.R_ASPECT_NAME, iter1));
			}
		}else {
			DfLogger.debug(IDocsClipboardPasteHandler.class, "copyObjectEx :: Aspect are not attached on this docuemnt ", null, null);
			DfLogger.info(IDocsClipboardPasteHandler.class, "copyObjectEx :: Aspect are not attached on this docuemnt ", null, null);
		}
		
		if(aspectNames != null && aspectNames.size() > 0){
			if(aspectNames.contains(IdocsConstants.IDOCS_EMAIL_DOC_ASPECT)){
				aspectExistance=true;
				DfLogger.debug(IDocsClipboardPasteHandler.class, "copyObjectEx :: Email virtual document aspectNames "+aspectNames, null, null);
			}else{
				DfLogger.debug(IDocsClipboardPasteHandler.class, "copyObjectEx :: Email aspect is not attached ::"+aspectNames, null, null);
			}
		}else{
			DfLogger.debug(IDocsClipboardPasteHandler.class, "copyObjectEx :: aspectNames are none ", null, null);
		}
		
		/** Check whether the User is Authenticated to Copy */

		HashMap<String, String> docValuesMap = new HashMap<String, String>();
		docValuesMap=IdocsUtil.getRequiredAttributesValues(copyObject.getObjectId().getId(),mComponent.getDfSession());
		
		if(LaunchViewComponentWithPermitCheck.validateUserPermissionsForView(true,copyObject.getObjectId().getId(), mComponent.getDfSession(),docValuesMap) == false){
			throw new DfException("You are not Authorised to Copy '"+copyObject.getObjectName()+"'.");
		}
		
		/** Validate IDOCS COPY/MOVE Operation Rules */
		checkIDocsDocumentCopyOperationRule(copyObject,strDestFolderId,dfSession,COPY_OPERATION_NAME);
		
		IDfCopyOperation operation = DfcUtils.getClientX().getCopyOperation();
		IDfId destinationFolderId = new DfId(strDestFolderId);
		IDfFolder currentFolder = (IDfFolder)dfSession.getObject(destinationFolderId);
	
		IDfFolder parentTargetFolder = getParentFolder(dfSession,currentFolder);
		DfLogger.info(IDocsClipboardPasteHandler.class,"copyObjectEx :: currentFolder "+currentFolder.getTypeName(),null,null);
		DfLogger.info(IDocsClipboardPasteHandler.class,"copyObjectEx :: parentTargetFolder "+parentTargetFolder.getTypeName(),null,null);
		operation.setDestinationFolderId(destinationFolderId);
		if (retainStorageAreas()){
			operation.setRetainStorageAreas(true);
			DfLogger.info(IDocsClipboardPasteHandler.class,"copyObjectEx  :: retainStorageAreas() ::"+parentTargetFolder.getTypeName(),null,null);
		}
		//check email aspect 
		if (copyObject.isVirtualDocument() && vdmCopyPreference != 0) {
	 		VdmStore vdmStore = VdmStore.getInstance();
			com.documentum.fc.client.IDfVirtualDocument virdoc = vdmStore.get(dfSession, strSourceId, true);
			operation.setCopyPreference(vdmCopyPreference);
			
			if(!getTemplateDocStatus(copyObject.getObjectId().toString(),dfSession)){
				if(aspectExistance){
					 node = (IDfCopyNode) operation.add(virdoc);
				}else{
					 operation.add(virdoc);
				}
				DfLogger.info(IDocsClipboardPasteHandler.class,"No template documents in side the virtual documents",null,null);
			}else {
				DfLogger.info(IDocsClipboardPasteHandler.class,"Copy / Move Opration on \"Template Documents\" not possible in IFCDocs application",null,null);
				throw new DfException("Copy/Move Opration on this virtual document is not possible in IFCDocs, this document contains \"Template Document(s)\"...");
			}
		} else {
			if (!copyObject.getAssembledFromId().isNull()){
				operation.setCopyPreference(0);
		  	}
			operation.add(copyObject);
		}
		
		boolean isMsgArch = false;
		String objectType = copyObject.getType().getName();
		
		if (TypeUtil.isSubtypeOf(objectType, "dm_message_archive")) {
			isMsgArch = true;
			dfSession.beginTrans();
		}
		if (!operation.execute()) {
			if (isMsgArch){
			   dfSession.abortTrans();
			}
			StringBuffer error = new StringBuffer(128);
			error.append("Copy Error : ");
			IDfList list = operation.getErrors();
			if (list.getCount() > 0) {
				IDfOperationError opErr = (IDfOperationError) list.get(0);
				error.append(opErr.getMessage());
				IDfException ex = opErr.getException();
				if (ex != null)
					error.append((new StringBuilder()).append("\n\n").append(
							ex.getMessage()).toString());
			}
			throw new DfException(error.toString());
		}
		if (isMsgArch)
			dfSession.commitTrans();
		try {
			
			IDfList listSysObjectNew = operation.getNewObjects();
			//IDfFolder projectHiddenFolder=null;
			String hiddenFolderObjectId= null;
			if(aspectExistance && copyObject.isVirtualDocument() && node != null 
					&& node.getNewObjectId() != null 
					&& node.getNewObjectId().toString().trim().length()> 0 
					&& !node.getNewObjectId().toString().equals(IDocsConstants.BLANK_OBJECT_ID)){
			   String rootObjectId=node.getNewObjectId().toString();
			   emailVirtualdocChilds=getChildDocumentIds(rootObjectId, dfSession);
			   DfLogger.info(IDocsClipboardPasteHandler.class, "emailVirtualdocChilds ::"+emailVirtualdocChilds, null, null);
			   
			   String hiddenFolderQuery="select r_object_id from dm_folder where any i_folder_id='"+strDestFolderId+"'";
			   IDfCollection templateDocCollection = IdocsUtil.executeQuery(dfSession,hiddenFolderQuery,IDfQuery.DF_EXEC_QUERY);
			   if(templateDocCollection != null){
			    	while (templateDocCollection.next()){
			    	 hiddenFolderObjectId =templateDocCollection.getString(IDocsConstants.MSG_R_OBJECT_ID);
			    	}
			    }
			} 
			for (int idxNewObj = 0; idxNewObj < listSysObjectNew.getCount(); idxNewObj++) {
				IDfSysObject newObj = (IDfSysObject) listSysObjectNew.get(idxNewObj);
				if (newObj.getRepeatingString("i_folder_id", 0).equals(strDestFolderId)){
					try{
						if(aspectExistance
								&& copyObject.isVirtualDocument() 
								&& emailVirtualdocChilds != null 
								&& emailVirtualdocChilds.size() >0
								&& emailVirtualdocChilds.contains(newObj.getObjectId().toString())){
							if(hiddenFolderObjectId != null 
									&& hiddenFolderObjectId.trim().length() >0
									&& !hiddenFolderObjectId.equals(IDocsConstants.BLANK_OBJECT_ID)){
								DfLogger.info(IDocsClipboardPasteHandler.class, "copyObjectEx :: Updating Attributes and root doc childs destination", null, null);
								IdocsUtil.updateAttributeAndchildDocDestination(dfSession, newObj, parentTargetFolder,IDocsConstants.IDOCS_COPY_OPERATION,hiddenFolderObjectId,strDestFolderId);
							}else {
								DfLogger.info(IDocsClipboardPasteHandler.class, "copyObjectEx :: Hidden folder not is Existed ", null, null); 
								 /**
								  * Creating Hidden folder  
								  */
								  String category=null;
								 // check if it s an allowed folder
								  
								if (newObj.getTypeName().equals(IdocsConstants.PROJ_DOC_TYPE)){
										category="PROJECT_"+newObj.getString(IDocsConstants.PROJECT_ID);
								}else if(newObj.getTypeName().equals(IdocsConstants.INSTITUTION_DOC_TYPE)){
										category="PARTNER_"+newObj.getString(IDocsConstants.INSTITUTION_NBR);
								}
								if(category != null && category.trim().length() > 0){
									DfLogger.info(IDocsClipboardPasteHandler.class, "copyObjectEx ::category ::"+category, null, null);
									String folderId = createFolder(category,parentTargetFolder.getObjectId(),dfSession);
									if(folderId != null && folderId.trim().length() >0 && !folderId.equals(IDocsConstants.BLANK_OBJECT_ID)){
										
										DfLogger.info(IDocsClipboardPasteHandler.class, "copyObjectEx :: new-folder (Hidden) folderId ::"+folderId, null, null);
									    IdocsUtil.updateAttributeAndchildDocDestination(dfSession, newObj, parentTargetFolder,IDocsConstants.IDOCS_COPY_OPERATION,folderId,parentTargetFolder.getObjectId().toString());
									  }else {
										 DfLogger.info(IDocsClipboardPasteHandler.class, "copyObjectEx :: new folder Creation got failed :: Updating Attributes and listing in parent folder", null, null);
										 IdocsUtil.updateAttribute(dfSession, newObj, parentTargetFolder,IDocsConstants.IDOCS_COPY_OPERATION);
									  }
								}else{
									 DfLogger.info(IDocsClipboardPasteHandler.class, "copyObjectEx :: new  folder category Creation got failed :: Updating Attributes and listing in parent folder", null, null);
									 IdocsUtil.updateAttribute(dfSession, newObj, parentTargetFolder,IDocsConstants.IDOCS_COPY_OPERATION);
								}
							}
						}else{
						   IdocsUtil.updateAttribute(dfSession, newObj, parentTargetFolder,IDocsConstants.IDOCS_COPY_OPERATION);
						}
						/**
						 * Updating Audit Info
						 */
					    IdocsUtil.auditIDocsActivity(MSG_COPIED,newObj.getObjectId().getId(),dfSession);
					}catch (Exception e) {
						DfLogger.error(IDocsClipboardPasteHandler.class, "Copy Attribute Updating Failed", null, null);
					}
				}
				arrResult.add(newObj.getObjectId().toString());
			}
		
		} catch (Exception regexperr) {
			DfLogger.error(IDocsClipboardPasteHandler.class, " Error Message "+regexperr.getMessage(), null, null);
			throw new WrapperRuntimeException(regexperr);
		}
		String strResult[] = new String[arrResult.size()];
		arrResult.toArray(strResult);
		
		return strResult;
	}

   /**
	 * 
	 * @param objectName
	 * @param folderPath
	 * @return
	 * @throws IOException
	 */
	
	private static String createFolder(String objectName, IDfId  parentFolder, IDfSession dfSession) throws IOException {
		try {
			DfLogger.error(IDocsClipboardPasteHandler.class, " createFolder ::  creating a new folder for Emailed virtual document child ::", null, null);
			IDfSysObject newFolder = (IDfFolder) dfSession.newObject("dm_folder");
			newFolder.setObjectName(objectName);
			newFolder.link(parentFolder.getId());
			newFolder.setBoolean(IDocsConstants.A_IS_HIDDEN, true);
			newFolder.save();
			DfLogger.error(IDocsClipboardPasteHandler.class, " createFolder ::  New folder for Emailed virtual document child ("+newFolder.getObjectId().toString()+") ::", null, null);
			return newFolder.getObjectId().toString();
		} catch(DfException e){
			DfLogger.error(IDocsClipboardPasteHandler.class, " createFolder ::"+e.getMessage(), null, null);
			return null;
		}
	}	
	
	/**
	 * 
	 * @param copyObject
	 * @param strDestFolderId
	 * @param dfSession
	 * @return
	 * @throws DfException
	 */
	public static boolean checkIDocsDocumentCopyOperationRule(
			IDfSysObject copyObject, String strDestFolderId,IDfSession dfSession,String operationName) throws DfException {
		/** Check if the document is a template based document or not */
		if(copyObject !=null){
			String currentObjectTypeName = copyObject.getTypeName();
			if(currentObjectTypeName != null && currentObjectTypeName.trim().length() > 0){
				if(copyObject.hasAttr(IDocsConstants.MSG_TEMPLATE_CODE) && (
						currentObjectTypeName.equalsIgnoreCase(IdocsConstants.PROJ_DOC_TYPE) == true 
						|| currentObjectTypeName.equalsIgnoreCase(IdocsConstants.INSTITUTION_DOC_TYPE) == true
						|| currentObjectTypeName.equalsIgnoreCase(IdocsConstants.COUNTRY_DOC_TYPE)) == true
						){
					String template_code = copyObject.getString(IDocsConstants.MSG_TEMPLATE_CODE);
					if(template_code!=null && template_code.trim().length() > 0){
						DfLogger.debug(IDocsClipboardPasteHandler.class, "Cannot Copy template documents in IFCDocs ", null, null);
						throw new DfException("Cannot Copy / Move template documents in IFCDocs.");
					}
				}
			}
		}
		
		IDfFolder currentFolder = (IDfFolder)copyObject.getObjectSession().getObject(copyObject.getFolderId(0));
		IDfFolder destinationFolder = (IDfFolder)copyObject.getObjectSession().getObject(new DfId(strDestFolderId));
		if(currentFolder != null && destinationFolder != null){
			String currentFolderPath = currentFolder.getFolderPath(0);
			String destinationFolderPath = destinationFolder.getFolderPath(0);
			if(currentFolderPath != null && currentFolderPath.trim().length() > 0
					&& destinationFolderPath != null && destinationFolderPath.trim().length() > 0 ){
				String pnpCabinetName = IdocsUtil.getMessage(MSG_PNP_CABINET_NAME);
				if(pnpCabinetName != null && pnpCabinetName.trim().length() > 0 
						&&(currentFolderPath.startsWith(pnpCabinetName) == true  || destinationFolderPath.startsWith(pnpCabinetName) == true) ){
					DfLogger.debug(IDocsClipboardPasteHandler.class, "PNP Copy/Move is not Allowed", null, null);
					throw new DfException("This operation is not supported.");
				}
			}
			IDfFolder currentParentFolder = getParentFolder (copyObject.getObjectSession(),currentFolder);
			IDfFolder destinationParentFolder = getParentFolder (copyObject.getObjectSession(),destinationFolder);
			String currentParentFolderType = currentParentFolder.getTypeName();
			String destinationParentFolderType = destinationParentFolder.getTypeName();
			String currentFolderCategory = currentParentFolder.getString(IDocsConstants.MSG_FOLDER_CATEGORY);
			String destinationFolderCategory = destinationParentFolder.getString(IDocsConstants.MSG_FOLDER_CATEGORY);
			DfLogger.debug(IDocsClipboardPasteHandler.class, ":: currentParentFolderType: "+ currentParentFolderType, null, null);
			DfLogger.debug(IDocsClipboardPasteHandler.class, ":: destinationParentFolderType: "+ destinationParentFolderType, null, null);
			DfLogger.debug(IDocsClipboardPasteHandler.class, ":: currentFolderCategory: "+ currentFolderCategory, null, null);
			DfLogger.debug(IDocsClipboardPasteHandler.class, ":: destinationFolderCategory: "+ destinationFolderCategory, null, null);
			
//			if(currentFolderCategory!=null && currentFolderCategory.trim().length() > 0
//					&& destinationFolderCategory!=null && destinationFolderCategory.trim().length() > 0
//					&& currentFolderCategory.equalsIgnoreCase(destinationFolderCategory)){
			if(currentParentFolderType!=null && currentParentFolderType.trim().length() > 0
					&& destinationParentFolderType!=null && destinationParentFolderType.trim().length() > 0
					&& currentParentFolderType.equalsIgnoreCase(destinationParentFolderType)){
				/** Handle the Copy Operation among similar folder type */
				if(destinationParentFolder.getTypeName().equalsIgnoreCase(IDocsConstants.MSG_IDOCS_COUNTRY_FOLDER)){
					String currentCountryCode = currentParentFolder.getString(IDocsConstants.COUNTRY_CODE);
					if(currentCountryCode!=null && currentCountryCode.trim().length() > 0){
						DfLogger.debug(IDocsClipboardPasteHandler.class, operationName+ " Operation Source Country Code ="+currentCountryCode, null, null);
					}else{
						throw new DfException(operationName+ " Operation Source Country Code '"+currentCountryCode+"' is invalid for "+currentParentFolder.getObjectName());
					}

					String destinationCountryCode = destinationParentFolder.getString(IDocsConstants.COUNTRY_CODE);
					if(destinationCountryCode!=null && destinationCountryCode.trim().length() > 0){
						DfLogger.debug(IDocsClipboardPasteHandler.class, operationName+ " Operation Destination Country Code ="+destinationCountryCode, null, null);
					}else{
						throw new DfException(operationName+ " Operation Destination Country Code '"+destinationCountryCode+"' is invalid for "+destinationParentFolder.getObjectName());
					}
					
					if(destinationCountryCode.equalsIgnoreCase(currentCountryCode) == true ){
						/** Country to Country */		
						throw new DfException(operationName+ " Operation is not allowed because destination Country Code '"+destinationCountryCode+"' and source Country Code "+currentCountryCode + " are same");
					}else{
						/** One Country to another Country 
						 * If the document is getting moved from one country to another
						 * the doctype code and subfolder titles should be the same */
//							doesDocumentShareSameDocType(currentFolder,destinationFolder);
					}						
				}else if(destinationParentFolder.getTypeName().equalsIgnoreCase(IDocsConstants.MSG_IDOCS_INSTIT_FOLDER)){
					String currentInstitutionNumber = currentParentFolder.getString(IDocsConstants.INSTITUTION_NBR);
					DfLogger.debug(IDocsClipboardPasteHandler.class, operationName+ " Operation Institution Number ="+currentInstitutionNumber, null, null);
					if(currentInstitutionNumber!=null && currentInstitutionNumber.trim().length() > 0){
						DfLogger.debug(IDocsClipboardPasteHandler.class, operationName+ " Operation Source Institution Number ="+currentInstitutionNumber, null, null);
					}else{
						throw new DfException(operationName+ " Operation Source Institution Number '"+currentInstitutionNumber+"' is invalid for "+currentParentFolder.getObjectName());
					}

					String destinationInstitutionNumber = destinationParentFolder.getString(IDocsConstants.INSTITUTION_NBR);
					if(destinationInstitutionNumber!=null && destinationInstitutionNumber.trim().length() > 0){
						DfLogger.debug(IDocsClipboardPasteHandler.class, operationName+ " Operation Destination Institution Number ="+destinationInstitutionNumber, null, null);
					}else{
						throw new DfException(operationName+ " Operation Destination  Institution Number '"+destinationInstitutionNumber+"' is invalid for "+destinationParentFolder.getObjectName());
					}
					
					if(destinationInstitutionNumber.equalsIgnoreCase(currentInstitutionNumber) == true ){
						/** Institution to Institution */	
						throw new DfException(operationName+ " Operation is not allowed because destination Institution Number '"+destinationInstitutionNumber+"' and source Institution Number "+currentInstitutionNumber + " are same.");
					}else{
						/** One Institution to another Institution 
						 * If the document is getting moved from one Institution to another
						 * the doctype code and subfolder titles should be the same */
//							doesDocumentShareSameDocType(currentFolder,destinationFolder);
					}	
				}else if(destinationParentFolder.getTypeName().equalsIgnoreCase(IDocsConstants.MSG_IDOCS_PROJ_FOLDER)){
					String currentProjectId = currentParentFolder.getString(IDocsConstants.PROJECT_ID);
					DfLogger.debug(IDocsClipboardPasteHandler.class, operationName+ " Operation Project Id ="+currentProjectId, null, null);
					if(currentProjectId!=null && currentProjectId.trim().length() > 0){
						DfLogger.debug(IDocsClipboardPasteHandler.class, operationName+ " Operation Source Project Id ="+currentProjectId, null, null);
					}else{
						throw new DfException(operationName+ " Operation Source Project Id '"+currentProjectId+"' is invalid for "+currentParentFolder.getObjectName());
					}

					String destinationProjectId = destinationParentFolder.getString(IDocsConstants.PROJECT_ID);
					if(destinationProjectId!=null && destinationProjectId.trim().length() > 0){
						DfLogger.debug(IDocsClipboardPasteHandler.class, operationName+ " Operation Destination Project Id ="+destinationProjectId, null, null);
					}else{
						throw new DfException(operationName+ " Operation Destination Project Id '"+destinationProjectId+"' is invalid for "+destinationParentFolder.getObjectName());
					}
					
					if(destinationProjectId.equalsIgnoreCase(currentProjectId) == true ){
						/** Project to Project */	
						throw new DfException(operationName+ " Operation is not allowed because destination Project Id '"+destinationProjectId+"' and source Project Id "+currentProjectId + " are same.");
					}else{
						/** One Project to another Project 
						 * If the document is getting moved from one Project to another
						 * the doctype code and subfolder titles should be the same */
//							doesDocumentShareSameDocType(currentFolder,destinationFolder);
					}						
				}else{
					throw new DfException("Cannot "+operationName+" document to '"+destinationParentFolder.getTypeName()+"'");
				}
				 
				/** Partner to Partner */
					/** One Partner to another Partner */
				/** Project to Project */
					/** One Project to another Project */
				
			} else{
				/** Handle the Copy Operation of Files across Project n Its Partners */
				/** Project to Partner*/
				/** One Project to Client Partner */
				/** One Project to nonClient Partner */
				String sourceMessage = getCurrentFolderName(currentParentFolder.getTypeName());
				String targetMessage = getDestinationFolderName(destinationParentFolder.getTypeName());
				String projectId = null;
				String institutionNumber = null;
				if(currentParentFolder.getTypeName().equalsIgnoreCase(IDocsConstants.MSG_IDOCS_PROJ_FOLDER)){
					projectId = currentParentFolder.getString(IDocsConstants.PROJECT_ID);
				}
				if(destinationParentFolder.getTypeName().equalsIgnoreCase(IDocsConstants.MSG_IDOCS_INSTIT_FOLDER)){
					institutionNumber = destinationParentFolder.getString(IDocsConstants.MSG_INSTITUTION_NBR);
				}
				
				if(destinationParentFolder.getTypeName().equalsIgnoreCase(IDocsConstants.MSG_IDOCS_PROJ_FOLDER)){
					projectId = destinationParentFolder.getString(IDocsConstants.PROJECT_ID);
				}
				
				if(currentParentFolder.getTypeName().equalsIgnoreCase(IDocsConstants.MSG_IDOCS_INSTIT_FOLDER)){
					institutionNumber = currentParentFolder.getString(IDocsConstants.MSG_INSTITUTION_NBR);
				}
				
				if(institutionNumber!=null && institutionNumber.trim().length() > 0
						&& projectId!=null && projectId.trim().length() > 0){
					
				}else{
					if (sourceMessage != null && sourceMessage.trim().length() > 0 &&
							targetMessage != null && targetMessage.trim().length() > 0 ) {
						throw new DfException("Cannot perform "+operationName+" operation from '"+sourceMessage+"' to '"+targetMessage+"'.");
					} else {
						throw new DfException("Cannot "+operationName+" Documents from '"+currentFolderCategory+"' to '"+destinationFolderCategory+"'.");
					}
				}
				
				if(projectId != null && projectId.trim().length() > 0){
					DfLogger.debug(IDocsClipboardPasteHandler.class, operationName+ " Operation Project Id ="+projectId, null, null);
				}else{
					throw new DfException(operationName+ " operation failed: Invalid Project Id '"+projectId+"'");
				}
				
				if(institutionNumber!= null && institutionNumber.trim().length() > 0){
					DfLogger.debug(IDocsClipboardPasteHandler.class, operationName + " Operation Institution Number ="+institutionNumber, null, null);
				}else{
					throw new DfException(operationName + " operation failed: Invalid Institution Number '"+institutionNumber+"'");
				}
				/** Copy is allowed only across the Project and Client Intitution .
				 * Movement across Country-Partner ,Country-project are not allowed. */
				isRelatedInClientRole(projectId,institutionNumber,dfSession,currentParentFolder.getTypeName());
			}
		}
		return true;		
	}

	private static String getDestinationFolderName(String currentFolderTypeName) {
		if(currentFolderTypeName.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_PROJ_FOLDER)) {
			return "Project";
		} else if(currentFolderTypeName.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_COUNTRY_FOLDER)) {
			return "Country";
		} else if (currentFolderTypeName.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_INSTIT_FOLDER)) {
			return "Partner";
		} else {
			return currentFolderTypeName;
		}
		
	}

	private static String getCurrentFolderName(String targetFolderTypeName) {
		
		if(targetFolderTypeName.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_PROJ_FOLDER)) {
			return "Project";
		} else if(targetFolderTypeName.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_COUNTRY_FOLDER)) {
			return "Country";
		} else if (targetFolderTypeName.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_INSTIT_FOLDER)) {
			return "Partner";
		} else {
			return targetFolderTypeName;
		}
	}

	/**
	 * 
	 * @param currentFolder
	 * @param destinationFolder
	 * @throws DfException
	 */
	private static void doesDocumentShareSameDocType(IDfFolder currentFolder,
			IDfFolder destinationFolder)throws DfException {
		String currentFolderPath = currentFolder.getFolderPath(0);
		String destinationFolderPath = destinationFolder.getFolderPath(0);
		if(currentFolderPath !=null && currentFolderPath.trim().length()>0
				&& destinationFolderPath !=null && destinationFolderPath.trim().length() > 0){
			String currentFolderPathArray[] = currentFolderPath.split("/");
			String destinationFolderPathArray[] = destinationFolderPath.split("/");
			if(currentFolderPathArray !=null && currentFolderPathArray.length == 5
					&& destinationFolderPathArray!=null && destinationFolderPathArray.length == 5){
				/** Creation allowed */
				DfLogger.info(IDocsClipboardPasteHandler.class, "Document movement is allowed as per New Folder Structure ", null, null);
			}else if(currentFolderPathArray !=null && currentFolderPathArray.length == 7
					&& destinationFolderPathArray!=null && destinationFolderPathArray.length == 7 
					&& destinationFolderPathArray[5].equals(currentFolderPathArray[5]) == true){
				if(destinationFolderPathArray[6].equals(currentFolderPathArray[6]) == true){
					/** Creation allowed */
					DfLogger.info(IDocsClipboardPasteHandler.class, "Document movement is allowed as the Document shares the same folder structure", null, null);
				}else{
					String currentSubFoldePath = null;
					String destinationSubFolderPath = null;
					boolean showDefaultErrorMessage = true;
					try{
						currentSubFoldePath= currentFolderPathArray[5];
						destinationSubFolderPath= destinationFolderPathArray[5];
						showDefaultErrorMessage = false;
					}catch (Exception e) {
						
					}
					if(showDefaultErrorMessage){
						throw new DfException("Cannot copy documents from ''"+currentSubFoldePath+"'' to ''"+destinationSubFolderPath+"''");
					}else{
						throw new DfException("Cannot copy documents from ''"+currentFolderPath+"'' to ''"+destinationFolderPath+"''.");	
					}					
				}				
			}else{
				String currentSubFoldePath = null;
				String destinationSubFolderPath = null;
				boolean showDefaultErrorMessage = true;
				try{
					currentSubFoldePath= currentFolderPathArray[5];
					destinationSubFolderPath= destinationFolderPathArray[5];
					showDefaultErrorMessage = false;
				}catch (Exception e) {
					
				}
				if(showDefaultErrorMessage){
					throw new DfException("Cannot copy documents from ''"+currentSubFoldePath+"'' to ''"+destinationSubFolderPath+"''");
				}else{
					throw new DfException("Cannot copy documents from ''"+currentFolderPath+"'' to ''"+destinationFolderPath+"''.");
				}
			}
		}else{
			throw new DfException("Cannot copy documents to this folder ''"+destinationFolder.getObjectName()+"''.");
		}		
	}
	
	private static boolean getTemplateDocStatus(String vdmRootObjectId,IDfSession dfSession){
		
		boolean templateExistance=false;
		String templateQryForVD=IdocsUtil.getMessage("VDM_TEMPLATE_DOCS_QRY");
		templateQryForVD=templateQryForVD.replace(STR_REPLACE_FROMQUERY,("'"+vdmRootObjectId+"'"));
		DfLogger.info(IDocsClipboardPasteHandler.class, "getTemplateDocStatus query :: "+templateQryForVD , null, null);
		IDfCollection templateDocCollection = null;
		String value=null;
		int i=0;
    	try {
    		templateDocCollection = IdocsUtil.executeQuery(dfSession,templateQryForVD,IDfQuery.DF_EXEC_QUERY);
    		while(templateDocCollection.next()){
    			value=null;
    			value=templateDocCollection.getString(IDocsConstants.MSG_R_OBJECT_ID);
    			if(value  != null && value.length() >0){
    				i++;	
    			}
    		} 
    		DfLogger.info(IDocsClipboardPasteHandler.class, "getTemplateDocStatus VDM doc("+vdmRootObjectId+") objectId :: ", null, null);
    		if(i == 0){
    			  templateExistance=false;
    		}else templateExistance= true;
    		DfLogger.info(IDocsClipboardPasteHandler.class, "getTemplateDocStatus templateExistance "+templateExistance + " iteration value "+i, null, null);
    	} catch (Exception e) {
    		DfLogger.error(IDocsClipboardPasteHandler.class, "getTemplateDocStatus  : " + e.getMessage(), null, null);
    	}finally{
    		if(templateDocCollection != null)
				try {
					templateDocCollection.close();
				} catch (DfException e) {
					// TODO Auto-generated catch block
					DfLogger.error(IDocsClipboardPasteHandler.class, " getTemplateDocStatus : " + e.getMessage(), null, null);
				}
    	 }
     	return templateExistance; 
	}
	
	/**
	 * 
	 * @param objectId
	 * @param dfSession
	 * @return
	 */
	private static List<String> getChildDocumentIds(String objectId,IDfSession dfSession){
		String childDocuemntsQuery= IdocsUtil.getMessage("VDM_CHILDQUERY");
		childDocuemntsQuery =childDocuemntsQuery.replace(STR_REPLACE_FROMQUERY,("'"+objectId+"'"));
	    IDfCollection childCollection= null;
	    List<String> childObjectIds = new ArrayList<String>();
	    try {
			childCollection= IdocsUtil.executeQuery(dfSession,childDocuemntsQuery,IDfQuery.DF_EXEC_QUERY);
			DfLogger.info(IDocsClipboardPasteHandler.class, " getChildDocumentIds : childObjectIds query "+childDocuemntsQuery, null, null);
			String childObjectId=null;
			if(childCollection != null){
				while (childCollection.next()){
					childObjectId  =childCollection.getString(IDocsConstants.MSG_R_OBJECT_ID);
					if(childObjectId != null && childObjectId.trim().length() >0 && !childObjectId.equals(IDocsConstants.BLANK_OBJECT_ID))
						childObjectIds.add(childObjectId);
				}
				DfLogger.info(IDocsClipboardPasteHandler.class, " getChildDocumentIds : childObjectIds for("+objectId+")"+childObjectIds, null, null);
			}
		} catch (DfException e) {
			// TODO Auto-generated catch block
			DfLogger.error(IDocsClipboardPasteHandler.class, " getChildDocumentIds : " + e.getMessage(), null, null);
		}
		return childObjectIds;
	}
	
   /**
    * 
    * @param virtualDocObjectId
    * @param currentFolderObjectId
    * @param dfSession
    * @return
    */
	/*private static void moveToHiddenFolders(String virtualDocObjectId,String currentFolderObjectId,IDfSession dfSession){
	String hiddenFolderQuery="select r_object_id from dm_folder where any i_folder_id='"+currentFolderObjectId+"'";
	DfLogger.info(IDocsClipboardPasteHandler.class, " moveToHiddenFolders Start ::" , null, null);
	IDfCollection templateDocCollection= null;
	//STR_REPLACE_HIDDENFOLDER_OBJECTIDFROMQUERY
	//templateQryForVD=templateQryForVD.replace(STR_REPLACE_FROMQUERY,("'"+vdmRootObjectId+"'"));
   try {
	    String hiddenFolderObjectId= null;
	    templateDocCollection = IdocsUtil.executeQuery(dfSession,hiddenFolderQuery,IDfQuery.DF_EXEC_QUERY);
	    if(templateDocCollection != null){
	    	while (templateDocCollection.next()){
	    	 hiddenFolderObjectId =templateDocCollection.getString(IDocsConstants.MSG_R_OBJECT_ID);
	    	}
	      }
	    if(hiddenFolderObjectId != null && hiddenFolderObjectId.length() >0 && !(hiddenFolderObjectId.equals(IDocsConstants.BLANK_OBJECT_ID))){
	      *//**
	        * Moving all child documents into another hidden folder   		
	        *//*
	    	String childDocUpdateQuery = IdocsUtil.getMessage("VDM_DOCUMENT_SELECT_TEMPLATEQUERY"); 
	    	childDocUpdateQuery=childDocUpdateQuery.replace(STR_REPLACE_HIDDENFOLDER_OBJECTIDFROMQUERY, ("'"+hiddenFolderObjectId+"'"));
	    	childDocUpdateQuery=childDocUpdateQuery.replaceAll(STR_REPLACE_FROMQUERY,"'"+virtualDocObjectId+"'");
	    	DfLogger.info(IDocsClipboardPasteHandler.class,"Update Child documents query"+childDocUpdateQuery,null, null);
	    	templateDocCollection =null;
	    	templateDocCollection = IdocsUtil.executeQuery(dfSession,hiddenFolderQuery,IDfQuery.DF_EXEC_QUERY);
	    	if(templateDocCollection != null){
	    		while(templateDocCollection.next()){
	    			if(templateDocCollection.hasAttr("objects_updated") ){
	    				DfLogger.info(IDocsClipboardPasteHandler.class, " Number of objects updated : "+templateDocCollection.getInt("objects_updated"), null, null);
	    			}
	    		}
	    	}
	     }
	   } catch (DfException e) {
		// TODO Auto-generated catch block
		 DfLogger.error(IDocsClipboardPasteHandler.class, " moveToHiddenFolders : " + e.getMessage(), null, null);
	}finally{
			try {
			if(templateDocCollection != null)
				templateDocCollection.close();
			} catch (DfException e) {
				// TODO Auto-generated catch block
				DfLogger.error(IDocsClipboardPasteHandler.class, " moveToHiddenFolders : " + e.getMessage(), null, null);
			}
 	}
	DfLogger.info(IDocsClipboardPasteHandler.class, " moveToHiddenFolders Exit ::" , null, null);
	}*/
	
	/**
	 * 
	 * @param projectId
	 * @param institutionNumber
	 * @param dfSession
	 * @return
	 * @throws DfException
	 */
	private static boolean isRelatedInClientRole(String projectId,
			String institutionNumber,IDfSession dfSession, String CurrentParentFolderType) throws DfException {
			String message = "";
			if (CurrentParentFolderType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_PROJ_FOLDER)) {
				message = "Project to Partner";
			} else {
				message = "Partner to Project";
			}
			String strQryClientValidation = IdocsUtil.getMessage("QRY_IS_RELATED_VIA_CLIENT_RULE");
			strQryClientValidation = strQryClientValidation.replaceAll("<projectId>", projectId);
			strQryClientValidation = strQryClientValidation.replaceAll("<institutionNumber>", institutionNumber);
			IDfCollection collection = IdocsUtil.executeQuery(dfSession, strQryClientValidation, IDfQuery.DF_READ_QUERY);
			String projectIdInRelation = null;
			while(collection.next()){
				projectIdInRelation = collection.getString(IDocsConstants.PROJECT_ID);
			}
			if(collection != null)collection.close();
			if(projectIdInRelation!=null && projectIdInRelation.trim().length() > 0){
				
				//DONOT ALLOW
				DfLogger.debug(IDocsClipboardPasteHandler.class, ":: isRelatedInClientRole:: Cannot perform Copy / Move operation from " + message, null, null);
				throw new DfException("Cannot perform Copy / Move operation from " + message);
				// ALOW return true;
			}else{
				throw new DfException("Cannot perform Copy / Move operation from " + message);
			}		
	}

	/**
	 * 
	 * @param session
	 * @param currentFolder
	 * @return
	 */
	public static IDfFolder getParentFolder(IDfSession session,IDfFolder currentFolder) {
		IDfFolder docFolder = currentFolder;
		IDfFolder parentFolder = docFolder;
		try {	
			DfLogger.info(IDocsClipboardPasteHandler.class, " :: getParentFolder() :  foldername : "+currentFolder.getFolderPath(0),null,null);
			if(currentFolder.getTypeName().equals(IDocsConstants.MSG_IDOCS_COUNTRY_FOLDER) 
					|| currentFolder.getTypeName().equals(IDocsConstants.MSG_IDOCS_INSTIT_FOLDER)
					|| currentFolder.getTypeName().equals(IDocsConstants.MSG_IDOCS_PROJ_FOLDER)){
				
				parentFolder = currentFolder;
			}else{
				docFolder = (IDfFolder)session.getObject(docFolder.getFolderId(0));
			    if((docFolder.getTypeName().equals(IDocsConstants.MSG_IDOCS_COUNTRY_FOLDER)
			    		|| currentFolder.getTypeName().equals(IDocsConstants.MSG_IDOCS_INSTIT_FOLDER)
						|| currentFolder.getTypeName().equals(IDocsConstants.MSG_IDOCS_PROJ_FOLDER)
			    		) && (!docFolder.getFolderId(0).getId().equals("0000000000000000"))){
			    	parentFolder = docFolder;
			    } else{
			    	if(!docFolder.getFolderId(0).getId().equals("0000000000000000")){
			    		parentFolder = (IDfFolder)session.getObject(docFolder.getFolderId(0));
			    	}
			    }
			}
			DfLogger.info(IDocsClipboardPasteHandler.class, "Parent folder Name for Current folder("+currentFolder.getObjectName()+") ::"+parentFolder.getObjectName(), null, null);
		} catch (DfException e) {
			
			DfLogger.info(IDocsClipboardPasteHandler.class, "Idocs Copy Operation Updated Attribute Failed in fetching the folder ", null, null);
		}
		return parentFolder;
	}
	
	/**
	 * 
	 * @return
	 */
	
	private static boolean retainStorageAreas() {
		IConfigLookup lookup = ConfigService.getConfigLookup();
		String strValue = lookup.lookupString(
				"application.copy_operation.retainstorageareas", Context
						.getApplicationContext());
		Boolean bRetainStorageAreas = Boolean.valueOf(strValue != null
				&& strValue.equalsIgnoreCase("true"));
		return bRetainStorageAreas.booleanValue();
	}

//	private static void setNewObjectName(IDfSysObject newObj,
//			String strDestFolderId) throws DfException, RESyntaxException {
//		if (!checkCopyOfNthCopy(newObj, strDestFolderId)
//				&& !checkCopyOfFirstCopy(newObj, strDestFolderId)
//				&& !checkNthCopy(newObj, strDestFolderId, null)
//				&& !checkFirstCopy(newObj, strDestFolderId))
//			checkCopy(newObj, strDestFolderId);
//	}

//	private static boolean checkCopyOfNthCopy(IDfSysObject newObj,
//			String strDestFolderId) throws DfException, RESyntaxException {
//		boolean fHandled = false;
//		s_nameBundle = new NlsResourceBundle("com.documentum.web.formext.clipboard.ObjectNameNlsProp");
//		String strNameFormat = s_nameBundle.getString("MSG_NTH_COPY_OF",
//				LocaleService.getLocale());
//		String strNameRePattern = MessageFormat.format(strNameFormat,
//				new String[] { "\n", "\r" });
//		strNameRePattern = RE
//				.simplePatternToFullRegularExpression(strNameRePattern);
//		strNameRePattern = StringUtil.replace(strNameRePattern, "\n",
//				"([0-9]+)");
//		strNameRePattern = StringUtil.replace(strNameRePattern, "\r", "(.+)");
//		RE regexpr = new RE(strNameRePattern);
//		String strNewObjName = newObj.getObjectName();
//		if (regexpr.match(strNewObjName)) {
//			String strNth = null;
//			String strName = null;
//			if (strNameFormat.indexOf("{0}") < strNameFormat.indexOf("{1}")) {
//				strNth = regexpr.getParen(1);
//				strName = regexpr.getParen(2);
//			} else {
//				strNth = regexpr.getParen(2);
//				strName = regexpr.getParen(1);
//			}
//			int nth = Integer.parseInt(strNth);
//			if (nth > 1 && strName != null && strName.length() > 0)
//				fHandled = checkNthCopy(newObj, strDestFolderId, strName);
//		}
//		return fHandled;
//	}

//	private static boolean checkCopyOfFirstCopy(IDfSysObject newObj,
//			String strDestFolderId) throws DfException, RESyntaxException {
//		boolean fHandled = false;
//		s_nameBundle = new NlsResourceBundle("com.documentum.web.formext.clipboard.ObjectNameNlsProp");
//		String strNameRePattern = s_nameBundle.getString("MSG_COPY_OF",
//				new String[] { "\r" }, LocaleService.getLocale());
//		strNameRePattern = RE
//				.simplePatternToFullRegularExpression(strNameRePattern);
//		strNameRePattern = StringUtil.replace(strNameRePattern, "\r", "(.+)");
//		RE regexpr = new RE(strNameRePattern);
//		String strNewObjName = newObj.getObjectName();
//		if (regexpr.match(strNewObjName)) {
//			String strName = regexpr.getParen(1);
//			if (strName != null && strName.length() > 0
//					&& !checkNthCopy(newObj, strDestFolderId, strName)) {
//				strName = s_nameBundle.getString("MSG_NTH_COPY_OF",
//						new String[] { "2", strName }, LocaleService
//								.getLocale());
//				if (isNewObjectNameValid(strName, newObj)) {
//					newObj.setObjectName(strName);
//					newObj.save();
//				}
//				fHandled = true;
//			}
//		}
//		return fHandled;
//	}

//	private static boolean checkCopy(IDfSysObject newObj, String strDestFolderId)
//			throws DfException {
//		boolean fHandled;
//		String strNewObjName;
//		IDfCollection idfColl;
//		fHandled = false;
//		strNewObjName = newObj.getObjectName();
//		StringBuffer bufQuery = new StringBuffer(256);
//		bufQuery.append("select r_object_id from dm_sysobject where");
//		bufQuery.append(" r_object_id != '").append(
//				newObj.getObjectId().getId()).append('\'');
//		bufQuery.append(" and object_name = '").append(
//				DfUtil.escapeQuotedString(strNewObjName)).append('\'');
//		bufQuery.append(" and folder(ID('").append(strDestFolderId).append(
//				"'))");
//		IDfQuery dfQuery = DfcUtils.getClientX().getQuery();
//		dfQuery.setDQL(bufQuery.toString());
//		idfColl = dfQuery.execute(newObj.getSession(), 0);
//		if (idfColl.next()) {
//			String strName = s_nameBundle.getString("MSG_COPY_OF",
//					new String[] { strNewObjName }, LocaleService.getLocale());
//			if (isNewObjectNameValid(strName, newObj)) {
//				newObj.setObjectName(strName);
//				newObj.save();
//			}
//			fHandled = true;
//		}
//		if (idfColl != null)
//			idfColl.close();
//		return fHandled;
//	}

//	private static boolean checkNthCopy(IDfSysObject newObj,
//			String strDestFolderId, String strBaseName) throws DfException,
//			RESyntaxException {
//		boolean fHandled;
//		String strNewObjName;
//		IDfCollection idfColl;
//		fHandled = false;
//		strNewObjName = strBaseName;
//		if (strNewObjName == null)
//			strNewObjName = newObj.getObjectName();
//		s_nameBundle = new NlsResourceBundle("com.documentum.web.formext.clipboard.ObjectNameNlsProp");
//		String strNthQueryFormat = s_nameBundle.getString("MSG_NTH_COPY_OF",
//				new String[] { "{0}", strNewObjName }, LocaleService
//						.getLocale());
//		strNthQueryFormat = Expression.escape(strNthQueryFormat);
//		strNthQueryFormat = DfUtil.escapeQuotedString(strNthQueryFormat);
//		String strNameQueryPattern = MessageFormat.format(strNthQueryFormat,
//				new String[] { "%" });
//		StringBuffer bufQuery = new StringBuffer(256);
//		bufQuery.append("select object_name from dm_sysobject where");
//		bufQuery.append(" r_object_id != '").append(
//				newObj.getObjectId().getId()).append('\'');
//		bufQuery.append(" and object_name like '").append(
//				DfUtil.escapeQuotedString(strNameQueryPattern)).append(
//				"' ESCAPE '\\' ");
//		bufQuery.append(" and folder(ID('").append(strDestFolderId).append(
//				"'))");
//		IDfQuery dfQuery = DfcUtils.getClientX().getQuery();
//		dfQuery.setDQL(bufQuery.toString());
//		idfColl = dfQuery.execute(newObj.getSession(), 0);
//		String strNameRePattern = s_nameBundle
//				.getString("MSG_NTH_COPY_OF", new String[] { "\n",
//						strNewObjName }, LocaleService.getLocale());
//		strNameRePattern = RE
//				.simplePatternToFullRegularExpression(strNameRePattern);
//		strNameRePattern = StringUtil.replace(strNameRePattern, "\n",
//				"([0-9]+)");
//		RE regexpr = new RE(strNameRePattern);
//		int nLastCopyId = -1;
//		do {
//			if (!idfColl.next())
//				break;
//			String strRowObjName = idfColl.getString("object_name");
//			if (regexpr.match(strRowObjName)) {
//				String strNth = regexpr.getParen(1);
//				int nth = Integer.parseInt(strNth);
//				if (nth > nLastCopyId && nth > 1)
//					nLastCopyId = nth;
//			}
//		} while (true);
//		if (nLastCopyId > 1) {
//			String strName = s_nameBundle.getString("MSG_NTH_COPY_OF",
//					new String[] { Integer.toString(nLastCopyId + 1),
//							strNewObjName }, LocaleService.getLocale());
//			if (isNewObjectNameValid(strName, newObj)) {
//				newObj.setObjectName(strName);
//				newObj.save();
//			}
//			fHandled = true;
//		}
//		if (idfColl != null)
//			idfColl.close();
//		return fHandled;
//	}
//	
//	private static boolean isNewObjectNameValid(String strNewName,
//			IDfSysObject sysobj) {
//		boolean fValid = false;
//		try {
//			IDfValidator validator = sysobj.getValidator();
//			if (validator != null) {
//				IDfProperties props = new DfProperties();
//				DfList values = new DfList(2);
//				values.appendString(strNewName);
//				props.putList("object_name", values);
//				validator.validateAll(props, true);
//			}
//			fValid = true;
//		} catch (DfException e) {
//		}
//		return fValid;
//	}
	
  //private static final int VDM_COPY_PREFRENCE_COPY_ROOTNLINK=1; 
	private static final String STR_REPLACE_FROMQUERY="'<objectId>'";
	//private static final String STR_REPLACE_HIDDENFOLDER_OBJECTIDFROMQUERY="'<hiddenFolder>'";


	
	 
    
}
