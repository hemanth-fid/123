package org.ifc.idocs.migration.rollback;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

import org.ifc.idocs.migration.importUtility.ImportUtility;

public class PrintValues extends ImportUtility{

	/**
	 * @param args
	 */
	public static void PrintID(String legacyDocId, String objectId) {

		String filename = "C:\\Temp\\try2.xls";
		File file = new File(filename);
		BufferedWriter bufferedWriter = null;
		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			
			try {
				
				bufferedWriter = new BufferedWriter(new FileWriter(filename,
						true));
				bufferedWriter.write(legacyDocId + "\t" + objectId + "\n");
				System.out.println("printed");
				//importDocLogger.info("printed");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				// Close the BufferedWriter
				try {
					if (bufferedWriter != null) {
						bufferedWriter.flush();
						bufferedWriter.close();
					}
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		

	}

}
