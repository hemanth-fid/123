package gov.mdc.iwa.monitors.utils;

import java.net.InetAddress;

public class Host {

	public static String getHostName(){
		String hostName = "";
		
		try{
			InetAddress iAddress = InetAddress.getLocalHost();
	        hostName = iAddress.getHostName();
		}catch(Exception e){
			// do nothign, if error then the hostname is empty
		}
		return hostName;
	}

}
