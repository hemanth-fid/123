/**
* This class will returns the error code for a particular IDocsException objects
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created
* #######################################################################################################
*/
package org.ifc.idocs.exception;

import javax.servlet.jsp.PageContext;
import org.apache.log4j.Logger;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.component.Component;

public class IDocsException extends Exception{
	public static final String ERROR_COMPONENT_PARAM_CODE = "code";
	public static final String ERROR_COMPONENT_PARAM_DESCRIPTION = "description";
	private static Logger logger = Logger.getLogger(IDocsException.class);
	public int intErrorCode = 0;
	public String strErrorDescription = null;
	
	/**
	 * Constructor with Exception object as a aparameter to handle ordinary exceptions
	 * @param intCode
	 * @param exception
	 */
	public IDocsException(int intCode, Exception exception) {
		logger.info(" ***** Start IDocsException() ***** ");
		intErrorCode = intCode;
		strErrorDescription = exception.getMessage();
		logException(0);
		logger.info("Exception Object : ",exception);		
		intErrorCode = intCode;
		logger.info(" ***** End IDocsException() ***** ");
	}
	
	/**
	 * Constructor with DfException object as a aparameter to handle DfException
	 * @param intCode
	 * @param dfException
	 */
	public IDocsException(int intCode, DfException dfException) {
		logger.info(" ***** Start IDocsException() *****  ");
		intErrorCode = intCode;
		strErrorDescription = dfException.getMessage();
		logException(dfException.getErrorCode());
		logger.info("Stack As String : "+dfException.getStackTraceAsString());
		logger.info("IDocsException Object :",dfException); 
		intErrorCode = intCode;
		logger.info(" ***** End IDocsException() ***** ");
	}
	
	
	/**
	 * This is the method which launches the error component.
	 * @param objIDocsException
	 * @param component
	 * @param pc
	 */
	public static void launchErrorComponent(IDocsException objIDocsException, Component component,PageContext pc) {
		logger.info(" Start launchErrorComponent() ");
		ArgumentList argumentList = new ArgumentList();
		logger.info(" Launch componnet Error code : " + objIDocsException.getErrorCode());
		IDocsErrorMessageFactory iDocsErrorMessageFactory = IDocsErrorMessageFactory.getFactory(pc);
		argumentList.add(ERROR_COMPONENT_PARAM_CODE, "" + objIDocsException.getErrorCode());
		argumentList.add(ERROR_COMPONENT_PARAM_DESCRIPTION, iDocsErrorMessageFactory.getErrorMessage(objIDocsException));
		try {
			component.setComponentNested("errorpage", argumentList, component.getContext(), null);
		} catch (Exception exception) {
			logger.info("launch error component catch block error is : " + exception.getMessage());
			DfLogger.error(IDocsException.class,": <<Exception>> : "+exception.getMessage(),null,exception);
		}
		logger.info(" End launchErrorComponent()  ");
	}
	
	/**
	 * This method will returns the error code for a particular IDocsException objects	
	 * @return
	 */
	public int getErrorCode() {
		logger.info(" Start getErrorCode() ");
		return intErrorCode;
	}
	
	/**
	 * This method will logs the Excpeion in the logger.
	 * @param intErrorCode
	 */
	public void logException(int intErrorCode) {
		try {
			logger.info("Error code is : " + intErrorCode);
			logger.info("Exception Message  is : " + strErrorDescription);
		} catch (Exception objException) {
			DfLogger.error(IDocsException.class,": <<Exception>> : "+objException.getMessage(),null,objException);
		}
	}
}
