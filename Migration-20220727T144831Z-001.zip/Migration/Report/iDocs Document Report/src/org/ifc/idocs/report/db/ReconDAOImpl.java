package org.ifc.idocs.report.db;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.ifc.idocs.report.common.LogHelper;

import com.documentum.fc.common.DfException;

public class ReconDAOImpl extends DBFactory{
	
	private Logger exportDocLogger = LogHelper.getLogger(ImportDAOImpl.class);
			
	

	public void updateReconTables(String prefix, String extractionId, String folderTypeCode, String exportPath) throws DfException{
		Integer docCount = 0;
		Statement stmt = null;
		String folderValueCode = null, docId = null, docUnid = null;		
		Map<String,Integer> documentCountMap = new HashMap<String,Integer>();

		try {
			getConnection();
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
	        conn.setAutoCommit(false);
			StringBuffer sb = new StringBuffer("");
			File dir = new File(exportPath);
			String[] children = dir.list();
			for (int i=0; i<children.length; i++) {
				String criteria = children[i].substring(0,children[i].length()-4);
				if(extractionId.contains(criteria)){
					exportDocLogger.warning("Processing : " + extractionId);
					try{
						String utilityId = getReportUtilityId(extractionId);
						FileInputStream fis = new FileInputStream(exportPath + "\\" + children[i]);
						DataInputStream in = new DataInputStream(fis);
						BufferedReader br = new BufferedReader(new InputStreamReader(in));
						String strLine;
						while ((strLine = br.readLine()) != null)   {
							String[] docIds = strLine.split(",");
							docId = docIds[1];
							docUnid = docIds[2];
							folderValueCode = docIds[0];

							sb.append("INSERT INTO IMPORT_COMPLETED_DOCS VALUES ('").append(utilityId).append("', '");
							sb.append(folderTypeCode).append("', '").append(folderValueCode).append("', '").append(docId);
							sb.append("', '").append(docUnid).append("')");
							stmt.addBatch(sb.toString());
							sb.delete(0, sb.length());
							
							docCount = documentCountMap.get(folderValueCode);
							if(docCount == null){
								docCount = 0;
							}
							docCount++;
							documentCountMap.put(folderValueCode, docCount);	
						}
						in.close();
					}catch (Exception e){
						System.err.println("Error: " + e.getMessage());
					}
					System.out.println("Executing executing batch");
					int[] updateCounts = stmt.executeBatch();
					exportDocLogger.warning("Document Report saved : " +  updateCounts.length);
					stmt.close();
					conn.commit();
					System.gc();
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			print("SQLException occurred while saving in Report tables", true);
		}
	}

	public String getReportUtilityId(String extractionQuery) {
		String utilCode = null;
		try {
			getConnection();			
			final String query1 = "select REPORT_UTILITY_ID from report_utility_map where EXTRACTION_CRITERIA_CODE='" + extractionQuery + "'";
			PreparedStatement stmt1 = conn.prepareStatement(query1);
			ResultSet rs = stmt1.executeQuery();
			if(	rs.next()){
				utilCode = rs.getString("REPORT_UTILITY_ID");
			}
			rs.close();
			stmt1.close();
		} catch (SQLException e) {
			exportDocLogger.warning("Please enter a valid extraction criteria present in table " + e);
			exportDocLogger.log(Level.WARNING,"updateReportUtilityMap-SQLException", e);
		}
		return utilCode;
	}

}
