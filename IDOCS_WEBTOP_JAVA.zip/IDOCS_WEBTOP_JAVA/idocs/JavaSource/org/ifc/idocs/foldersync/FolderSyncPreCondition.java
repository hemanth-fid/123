package org.ifc.idocs.foldersync;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.action.IActionPrecondition;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

public class FolderSyncPreCondition implements IActionPrecondition{

	public String[] getRequiredParams() {
		return null;
	}

	public boolean queryExecute(String strAction, IConfigElement config,
			ArgumentList arg, Context context, Component component) {
		
		boolean isCountry =false;
		IDfSession dfSession = null;
		dfSession = component.getDfSession();
		String folderObjId = null;
		String countryCode = null;
		
		folderObjId = arg.get("objectId");
		DfLogger.info(this, ": queryExecute : object id : " + folderObjId, null, null);
		
		String folderQry = "select country_code from idocs_folder where folder('/IFCDocs') and r_object_id ='"+folderObjId+"'";
		DfLogger.info(this, ": queryExecute : Folder query : " + folderQry, null, null);
		
		IDfQuery qryObj = new DfQuery();
		qryObj.setDQL(folderQry);
		
		try {
			IDfCollection countryCodeColl = qryObj.execute(dfSession, IDfQuery.DF_READ_QUERY);
			
			try{
				while(countryCodeColl.next()){
					countryCode = countryCodeColl.getString("country_code");
					DfLogger.info(this, ": queryExecute : Country Code : " + countryCode, null, null);
				}
			}
			finally{
				if(countryCodeColl != null){
					countryCodeColl.close();
				}
			}
			
			if(null != countryCode){
				isCountry = true;
			}
			
		} catch (DfException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return isCountry;
	}

}
