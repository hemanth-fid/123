package org.ifc.idocs.report.model;

public class SecurityExceptionReportDisplay {
	
	private String folderValueCode1;
	private String docName1;
	private String version1;
	private String securityClassification1;
	private String legacyId1;
	private String docUniqueId1;
	
	private String folderValueCode2;
	private String docName2;
	private String version2;
	private String securityClassification2;
	private String legacyId2;
	private String docUniqueId2;
	
	public String getFolderValueCode1() {
		return folderValueCode1;
	}
	public void setFolderValueCode1(String folderValueCode1) {
		this.folderValueCode1 = folderValueCode1;
	}
	public String getFolderValueCode2() {
		return folderValueCode2;
	}
	public void setFolderValueCode2(String folderValueCode2) {
		this.folderValueCode2 = folderValueCode2;
	}
	public String getDocName1() {
		return docName1;
	}
	public void setDocName1(String docName1) {
		this.docName1 = docName1;
	}
	public String getVersion1() {
		return version1;
	}
	public void setVersion1(String version1) {
		this.version1 = version1;
	}
	public String getSecurityClassification1() {
		return securityClassification1;
	}
	public void setSecurityClassification1(String securityClassification1) {
		this.securityClassification1 = securityClassification1;
	}
	public String getDocName2() {
		return docName2;
	}
	public void setDocName2(String docName2) {
		this.docName2 = docName2;
	}
	public String getVersion2() {
		return version2;
	}
	public void setVersion2(String version2) {
		this.version2 = version2;
	}
	public String getSecurityClassification2() {
		return securityClassification2;
	}
	public void setSecurityClassification2(String securityClassification2) {
		this.securityClassification2 = securityClassification2;
	}
	public String getLegacyId1() {
		return legacyId1;
	}
	public void setLegacyId1(String legacyId1) {
		this.legacyId1 = legacyId1;
	}
	public String getLegacyId2() {
		return legacyId2;
	}
	public void setLegacyId2(String legacyId2) {
		this.legacyId2 = legacyId2;
	}
	public String getDocUniqueId1() {
		return docUniqueId1;
	}
	public void setDocUniqueId1(String docUniqueId1) {
		this.docUniqueId1 = docUniqueId1;
	}
	public String getDocUniqueId2() {
		return docUniqueId2;
	}
	public void setDocUniqueId2(String docUniqueId2) {
		this.docUniqueId2 = docUniqueId2;
	}
}
