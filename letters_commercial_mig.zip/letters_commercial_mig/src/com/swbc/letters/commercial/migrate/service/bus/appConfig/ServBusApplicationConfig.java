/**
 * 
 */
package com.swbc.letters.commercial.migrate.service.bus.appConfig;

/**
 * @author hemanth.muppalanara
 *
 */
public class ServBusApplicationConfig {

	
	  private String userid;
	  private String password;
	  private String hostname;
	  private String hostport;
	  private String virtualhost;
	  private String exchangename;
	  private String contenttype;
	  private String commandtype;
	  
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getHostname() {
		return hostname;
	}
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	public String getHostport() {
		return hostport;
	}
	public void setHostport(String hostport) {
		this.hostport = hostport;
	}
	public String getVirtualhost() {
		return virtualhost;
	}
	public void setVirtualhost(String virtualhost) {
		this.virtualhost = virtualhost;
	}
	public String getExchangename() {
		return exchangename;
	}
	public void setExchangename(String exchangename) {
		this.exchangename = exchangename;
	}
	public String getContenttype() {
		return contenttype;
	}
	public void setContenttype(String contenttype) {
		this.contenttype = contenttype;
	}
	public String getCommandtype() {
		return commandtype;
	}
	public void setCommandtype(String commandtype) {
		this.commandtype = commandtype;
	}
	
}
