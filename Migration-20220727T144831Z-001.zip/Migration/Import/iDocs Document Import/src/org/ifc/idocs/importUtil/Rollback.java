package org.ifc.idocs.importUtil;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.StringTokenizer;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfId;

public class Rollback extends ImportUtility
{
	protected static IDfQuery queryObj=new DfQuery();
	protected static void startExecution() throws DfException, IOException, ParseException, ParserConfigurationException, SAXException
	{
		StringTokenizer st;
		int choice=0;
		dominoDocLogger.info("Rollback :: startExecution() : Rollback Operation started");
		System.out.println("");
		System.out.println("*******************************************************************");
		System.out.println("*              iDocs - Rollback Documents                         *");
		System.out.println("*******************************************************************");
		System.out.println("");
		System.out.println("\t 1. Rollback For Failed Documents from Database");
		System.out.println("\t 2. Rollback From Properties File");
		System.out.println("\t 3. Back to Main Menu");
		System.out.println("\t 4. Exit from Import Utility");
		System.out.println("");
		System.out.println("*******************************************************************");
		System.out.print("Enter your Choice : ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String menuChoice = br.readLine();
		System.out.println("");
		if(!menuChoice.isEmpty()){
			try{
				choice = Integer.parseInt(menuChoice);
			}catch(NumberFormatException nfe){
				choice=0;
			}
		}
//		System.out.println("Choice : "+choice);
		switch(choice)
		{
			case 1 :System.out.println("Executing Rollback for Failed Imports...");				
						StringBuilder idQuery=null;
						idQuery=new StringBuilder(idocsProperties.getProperty("MSG_ID_QUERY"));
						queryObj.setDQL(idQuery.toString());
						IDfCollection idCollection=null;
						idCollection = queryObj.execute(dfSession, IDfQuery.DF_EXEC_QUERY);
						while(idCollection.next())
						{
							dominoDocLogger.info("Rollback :: startExecution() : Delete Operation started for ID : "+idCollection.getString("idocs_id"));			
							rollbackIds(idCollection.getString("idocs_id"));
						}
						if(idCollection!=null)
						idCollection.close();
					break;

			case 2 : System.out.println("Executing Rollback Imports mentioned in Properties file...");
						st=new StringTokenizer(idocsProperties.getProperty("MSG_IDS_TO_BE_ROLLBACK"), ",");
						for(int j=0;j<st.countTokens();j++)
				    	{
							rollbackIds(st.nextToken());
						}
					break;

			case 3 : System.out.println("Back to Main Menu");
						String[] args = null;
						ImportUtility.main(args);
					break;
			case 4 : System.out.println("Exit - Execution Ended."); 
						System.exit(0);
						dfSession.disconnect();
			default: System.out.println("Invalid Entry Please provide your selection again...");
		}

		if(choice != 4)
		{			
			Rollback.startExecution();
		}
		dominoDocLogger.info("Rollback :: startExecution() : Rollback Operation Finished.");
	}

	protected static void rollbackIds(String token) throws DfException, ParseException 
	{
//		System.out.println("Token Id : "+token);
		StringBuilder categoryQry=null;
		//Fetch the idocs_folder_category for each token
		categoryQry=new StringBuilder(idocsProperties.getProperty("MSG_CATEGORY_QRY")).append(token).append("'");
		queryObj.setDQL(categoryQry.toString());
		IDfCollection collection=null;
		collection = queryObj.execute(dfSession, IDfQuery.DF_EXEC_QUERY);
		while(collection.next())
		{
			String folderCategory=collection.getString("idocs_folder_category");
			if(folderCategory.equalsIgnoreCase(idocsProperties.getProperty("MSG_COUNTRIES_FOLDER")))
			{
				countryData(folderCategory,token);
			}
			else if(folderCategory.equalsIgnoreCase(idocsProperties.getProperty("MSG_PROJECTS_FOLDER")))
			{
				projectData(folderCategory,token);
			}
			else
			{
				institutionData(folderCategory,token);
			}
		}
		if(collection!=null)
		collection.close();
	}

	private static void institutionData(String folderCategory, String token) throws DfException, ParseException 
	{
		StringBuilder institDocQry=new StringBuilder(idocsProperties.getProperty("MSG_INSTITUTION_DOC_QRY")).append(token).append("'");
		queryObj.setDQL(institDocQry.toString());
		IDfCollection documentCollection = queryObj.execute(dfSession, IDfQuery.DF_EXEC_QUERY);
		int docCount=0;
		while(documentCollection.next())
		{
			docCount++;
			IDfId objectid=new DfId(documentCollection.getString("r_object_id").toString());
			IDfSysObject sysObj = (IDfSysObject) dfSession.getObject(objectid);
			dominoDocLogger.info("Rollback :: institutionData() : Deleting the Document : "+documentCollection.getString("file_name"));
			sysObj.destroyAllVersions();
		}
		if(docCount!=0)
		{
			//update migration report table
			updateMigrationReport(token);
		}
		if(documentCollection!=null)
		documentCollection.close();
		dominoDocLogger.info("Rollback :: institutionData() : Done deleting "+docCount+" Documents");
	}

	private static void projectData(String folderCategory, String token) throws DfException, ParseException
	{
		StringBuilder projectDocQry=new StringBuilder(idocsProperties.getProperty("MSG_PROJECT_DOC_QRY")).append(token).append("'");
		queryObj.setDQL(projectDocQry.toString());
//		System.out.println(queryObj.getDQL());
		IDfCollection documentCollection  = queryObj.execute(dfSession, IDfQuery.DF_EXEC_QUERY);
		int docCount=0;	
		while(documentCollection.next())
		{
			docCount++;	
			IDfId objectid=new DfId(documentCollection.getString("r_object_id").toString());
			IDfSysObject sysObj = (IDfSysObject) dfSession.getObject(objectid);
			dominoDocLogger.info("Rollback :: projectData() : Deleting the Document : "+documentCollection.getString("file_name"));		
			sysObj.destroyAllVersions();
		}
		if(docCount!=0)
		{
			updateMigrationReport(token);
		}
		if(documentCollection!=null)
		documentCollection.close();
		dominoDocLogger.info("Rollback :: projectData() : Done deleting "+docCount+" Documents");
	}

	private static void countryData(String folderCategory, String token) throws DfException, ParseException
	{
		StringBuilder countryDocQry=null;
		countryDocQry=new StringBuilder(idocsProperties.getProperty("MSG_COUNTRY_DOC_QRY")).append(token).append("'");
		queryObj.setDQL(countryDocQry.toString());
//		System.out.println("Country Query : "+countryDocQry.toString());
		IDfCollection documentCollection = queryObj.execute(dfSession, IDfQuery.DF_EXEC_QUERY);
		int docCount=0;
		while(documentCollection.next())
		{
			docCount++;
			IDfId objectid=new DfId(documentCollection.getString("r_object_id").toString());
			IDfSysObject sysObj = (IDfSysObject) dfSession.getObject(objectid);
			dominoDocLogger.info("Rollback :: countryData() : Deleting the Document : "+documentCollection.getString("file_name"));
			sysObj.destroyAllVersions();
		}
		if(docCount!=0)
		{
			//update migration report table
			updateMigrationReport(token);
		}
		if(documentCollection!=null)
		documentCollection.close();
		dominoDocLogger.info("Rollback :: countryData() : Done deleting "+docCount+" Documents");
	}

	protected static void updateMigrationReport(String idocs_id) throws DfException 
	{
		IDfQuery queryObj=new DfQuery();
		StringBuilder update=null;
		update=new StringBuilder(idocsProperties.getProperty("MSG_MIGRATION_UPDATE")).append(idocs_id).append("'");
		queryObj.setDQL(update.toString());
		queryObj.execute(dfSession, IDfQuery.DF_EXEC_QUERY);
		dominoDocLogger.info("Rollback :: updateMigrationReport() : Updation Completed For : "+idocs_id);
	}
}
