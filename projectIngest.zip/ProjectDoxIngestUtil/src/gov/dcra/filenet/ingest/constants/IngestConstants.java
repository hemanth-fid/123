package gov.dcra.filenet.ingest.constants;

//import com.filenet.api.constants.PropertyNames;

public class IngestConstants {

	public static final String CREDENTAILS_PROPS = "credentials.properties";
	public static final String APPLICATION_PROPS = "application.properties";
	
	
	public static final String DB_DRIVER_NAME="config.jdbc.driverClassName";
	public static final String DB_URL="config.db.url";
	public static final String DB_USER_NAME="config.db.username";
	public static final String DB_PASSWORD="config.db.password";
	
	
	public static final String MSG_URL = "config.filenet.host.url";
	public static final String MSG_USERNAME = "config.filenet.admin.user.name";
	public static final String MSG_PWD = "config.filenet.admin.password";
	public static final String MSG_STANZA = "config.filenet.stanza";
	public static final String MSG_DOMAIN = "config.filenet.domain.name";
	
	public static final String MSG_OBJECTSTORE_NAME = "config.filenet.objectstore.name";
	public static final String MSG_EXPORT_DIR = "config.filenet.export.dir";
	public static final String MSG_EXPORT_FILENAME = "config.filenet.export.filename";
	public static final String MSG_COLUMN_NAME = "config.filenet.export.column.name";
	
	public static final String TARGET_FOLDER_PATH = "config.filenet.target.folder.path";
	
	
	//Add the required properties
	public static final String PROPERTY_PERMIT_TYPE = "Permit_Type";
	public static final String PROPERTY_FILE_NUMBER = "File_Number";
	public static final String PROPERTY_ADDRESS = "Address";
	public static final String PROPERTY_CREATOR = "Creator";
	public static final String PROPERTY_DOCUMENT_TYPE = "Document_Type";
	//public static final String PROPERTY_DOCUMENTNAME = "DocumentName";
	public static final String PROPERTY_PAGES = "pages";
	public static final String PROPERTY_DOCUMENTTITLE = "DocumentTitle";
	public static final String PROPERTY_STORAGEAREA = "StorageArea";
	public static final String PROPERTY_MIMETYPE = "MimeType";
	public static final String PROPERTY_DOCUMENT_DATE = "Document_Date";
	public static final String PROPERTY_ENTITY = "Entity";
 


	//Queries
	public static final String QRY_SELECT_ALL_INGST_SRC_TABLE="";
	
	
	public static final String NEWLINE = System.getProperty("line.separator");
	public static final String FILESEPARATOR = System.getProperty("file.separator");
	public static final String EMPTYSTRING = "";
}
