package org.ifc.idocs.migration.updateReferences;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.ifc.idocs.migration.helper.UpdateReferenceDB;
import org.ifc.idocs.migration.helper.Utilities;
import org.ifc.idocs.migration.importUtility.ImportUtility;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfRelation;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfUser;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
/**
 * CreateFavourites - Creating subscriptions in documentum. 
 * @author HAnuganti
 * 
 * #############################################################################################
 * Author		            DateofChange	 Version	  ModificationHistory
 * ###########################################################################################
 * Hemachandra Anuganti 
 * ###########################################################################################
 * 
 */
public class CreateFavourites extends ImportUtility{

	static String documentObjectID = "";
	static String fldObjectID = "";
	public static void runSubscriptions(IDfSession dfSession) {
		// TODO Auto-generated method stub
		
		String strQuery = "";
		try {
			UpdateReferenceDB.getConnection();
			ResultSet rSet = UpdateReferenceDB.selectRecords(idocsProperties.getProperty("MSG_PREFERENCE_GETTYPES_QUERY"), idocsProperties.getProperty("MSG_FAVOURITES_IDENTITY"));
			while(rSet.next()){
				String entityID = rSet.getString(idocsProperties.getProperty("MSG_RESOURCE_ENTITY_ID"));

				//checking whether entity ID is a folder or the document
				if(entityID.equalsIgnoreCase(idocsProperties.getProperty("MSG_PREFERENCE_DOCUMENT"))){
					importDocLogger.info("Processing Resource Entity id::["+entityID+"]");
					strQuery = idocsProperties.getProperty("MSG_PREFERENCE_TYPE_QUERY");
					strQuery = strQuery.replaceFirst("<resource_entity_id>", idocsProperties.getProperty("MSG_PREFERENCE_DOCUMENT"));
					ResultSet resultSet = UpdateReferenceDB.selectRecords(strQuery,idocsProperties.getProperty("MSG_FAVOURITES_IDENTITY"));
					while(resultSet.next()){
						String accessor_id = resultSet.getString(idocsProperties.getProperty("MSG_PREFERENCE_ACCESSOR"));
						String legacyDocID = resultSet.getString(idocsProperties.getProperty("MSG_PREFERENCE_RESOURCE_KEY"));

						//Check if the document exists in iDocs or not
						importDocLogger.info("Processing Subscriptions for the Legacy ID::["+legacyDocID+"]::For the User::["+accessor_id+"]");
						if(chkDocumentExists(legacyDocID)){
							String userObjId = getUserObjectID(accessor_id);
							if(userObjId != null && userObjId != ""){

								//Call function to create the subscription of the document
								//calling the Relation service to create the relation Object
								String idocsObjectID = documentObjectID;
								createRelationObj(idocsObjectID,userObjId);
							}else{
								importDocLogger.info("User not found in iDocs to create the relation object::["+accessor_id+"]");
							}
						}else{
							importDocLogger.info("Document does not exist in IFCDocs for the Legacy ID::["+legacyDocID+"]");
						}
					}//end of IF
					if(resultSet != null){
						resultSet.close();
					}
				}else if (entityID.equalsIgnoreCase(idocsProperties.getProperty("MSG_PREFERENCE_FOLDER"))) {
					importDocLogger.info("Processing Resource Entity id::["+entityID+"]");
					strQuery = idocsProperties.getProperty("MSG_PREFERENCE_TYPE_QUERY");
					strQuery = strQuery.replaceFirst("<resource_entity_id>", idocsProperties.getProperty("MSG_PREFERENCE_FOLDER"));
					ResultSet resultSet = UpdateReferenceDB.selectRecords(strQuery,idocsProperties.getProperty("MSG_FAVOURITES_IDENTITY"));
					while(resultSet.next()){
						String accessor_id = resultSet.getString(idocsProperties.getProperty("MSG_PREFERENCE_ACCESSOR"));
						String folderID = resultSet.getString(idocsProperties.getProperty("MSG_PREFERENCE_RESOURCE_KEY"));

						//Call function to create the subscription of the document
						importDocLogger.info("Processing Subscriptions for the Project/Institution/Country::["+folderID+"]::For the User::["+accessor_id+"]");
						if(chkFolderExists(folderID)){
							String userObjId = getUserObjectID(accessor_id);
							if(userObjId != null && userObjId != ""){

								//Call function to create the subscription of the document
								//calling the Relation service to create the relation Object
								String idocsObjectID = fldObjectID;
								createRelationObj(idocsObjectID,userObjId);
							}else{
								importDocLogger.info("User not found in iDocs to create the relation object");
							}
						}else{
							importDocLogger.info("Folder does not exist in IFCDocs for the Legacy ID::["+folderID+"]");
						}
					}
					if(resultSet != null){
						resultSet.close();
					}
				}else {
					importDocLogger.info("Provided Resource entity ID is neither document nor the folder::["+entityID+"]");
				}
			}
			if(rSet != null){
				rSet.close();
			}
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException::"+e.getMessage());
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("SQLException::"+e.getMessage());
			e.printStackTrace();
		}
	}

	private static boolean chkFolderExists(String folderID) {
		// TODO Auto-generated method stub
		String fldID = folderID;
		//importDocLogger.info("Checking in folders for the project id::"+fldID);
		if(!chkFldInProjects(fldID)){
			if(!chkFldInInstitutions(fldID)){
				if(!chkFldInCountries(fldID)){
					return false;
				}//end of IF check in Country documents
			}//end of IF check in Institution documents
		}//end of IF check in projects documents
		
		return true;
	}

	private static boolean chkFldInCountries(String ctryCODE) {

		// TODO Auto-generated method stub
		boolean flagFldCtry = true;
		//importDocLogger.info("Checking in Country folders::"+ctryCODE);
		IDfCollection collection2 = null;
		String queryStr1 = idocsProperties.getProperty("MSG_COUNTRY_FOLDER_ID");
		queryStr1 = queryStr1.replaceFirst("<country_code>", ctryCODE);
		try {
			collection2 = Utilities.executeQuery(dfSession, queryStr1, DfQuery.EXECREAD_QUERY);
			if(collection2 != null && collection2.next()){
				fldObjectID = collection2.getString(idocsProperties.getProperty("MSG_DOC_OBJECT_ID"));
				return flagFldCtry;
			}else{
				flagFldCtry = false;
			}
			
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException::"+e.getMessage());
			importDocLogger.warning("Problem in Fetching the folder Object id");
			e.printStackTrace();
			flagFldCtry = false;
		}finally{
			if(collection2 != null){
				try {
//					collection2 = null;
					collection2.close();
				} catch (DfException e) {
					// TODO Auto-generated catch block
					importDocLogger.warning("DfException::"+e.getMessage());
					importDocLogger.warning("Problem in closing the collection2");
					e.printStackTrace();
				}
			}
		}
		return flagFldCtry;
	}

	private static boolean chkFldInInstitutions(String instNBR) {

		// TODO Auto-generated method stub
		boolean flagFldInst = true;
		//importDocLogger.info("Checking in Institutions folders::"+instNBR);
		IDfCollection collection2 = null;
		String queryStr1 = idocsProperties.getProperty("MSG_INSTITUTION_FOLDER_ID");
		queryStr1 = queryStr1.replaceFirst("<institution_nbr>", instNBR);
		try {
			collection2 = Utilities.executeQuery(dfSession, queryStr1, DfQuery.EXECREAD_QUERY);
			if(collection2 != null && collection2.next()){
				fldObjectID = collection2.getString(idocsProperties.getProperty("MSG_DOC_OBJECT_ID"));
				return flagFldInst;
			}else{
				flagFldInst = false;
			}
			
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException::"+e.getMessage());
			importDocLogger.warning("Problem in Fetching the folder Object id");
			e.printStackTrace();
			flagFldInst = false;
		}finally{
			if(collection2 != null){
				try {
//					collection2 = null;
					collection2.close();
				} catch (DfException e) {
					// TODO Auto-generated catch block
					importDocLogger.warning("DfException::"+e.getMessage());
					importDocLogger.warning("Problem in closing the collection2");
					e.printStackTrace();
				}
			}
		}
		return flagFldInst;
	}

	private static boolean chkFldInProjects(String projID) {

		// TODO Auto-generated method stub
		boolean flagFldProj = true;
		//importDocLogger.info("Checking in Projects folders::"+projID);
		IDfCollection collection2 = null;
		String queryStr1 = idocsProperties.getProperty("MSG_PROJECT_FOLDER_ID");
		queryStr1 = queryStr1.replaceFirst("<project_id>", projID);
		try {
			collection2 = Utilities.executeQuery(dfSession, queryStr1, DfQuery.EXECREAD_QUERY);
			if(collection2 != null && collection2.next()){
				fldObjectID = collection2.getString(idocsProperties.getProperty("MSG_DOC_OBJECT_ID"));
				return flagFldProj;
			}else{
				flagFldProj = false;
			}
			
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException::"+e.getMessage());
			importDocLogger.warning("Problem in Fetching the folder Object id");
			e.printStackTrace();
			flagFldProj = false;
		}finally{
			if(collection2 != null){
				try {
//					collection2 = null;
					collection2.close();
				} catch (DfException e) {
					// TODO Auto-generated catch block
					importDocLogger.warning("DfException::"+e.getMessage());
					importDocLogger.warning("Problem in closing the collection2");
					e.printStackTrace();
				}
			}
		}
		return flagFldProj;
	}

	public static void createRelationObj(String docObjectID, String userObjId) {
		// TODO Auto-generated method stub
		try {
			//importDocLogger.info("Creating the Relationship object for Document ID::"+docObjectID+" and the User ID::"+userObjId);
			IDfRelation relation = (IDfRelation) dfSession.newObject("dm_relation");
			relation.setRelationName("dm_subscription");
			relation.setParentId(new DfId(docObjectID));
			relation.setChildId(new DfId(userObjId));
			relation.save();
			//importDocLogger.info("Created the Relation object and saved Successfully::"+relation.getObjectId());
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException::"+e.getMessage());
			importDocLogger.warning("Problem in creating the relation object for Document ID::"+docObjectID+" and the User ID::"+userObjId);
			e.printStackTrace();
		}
		
	}

	private static String getUserObjectID(String accessor_id) throws DfException {
		// TODO Auto-generated method stub
		//importDocLogger.info("Getting User object ID for the UPI ID::"+accessor_id);
		String uObjectID = "";
		IDfUser userName = (IDfUser) dfSession.getObjectByQualification("dm_user where user_os_name like'%"+accessor_id+"'");
			if(userName != null){
				uObjectID = userName.getObjectId().toString();
			}else{
				//importDocLogger.info("User object ID not found for the UPI ID::"+accessor_id);
			}
			//importDocLogger.info("User object ID found::"+uObjectID);	
		return uObjectID;
	}

	private static boolean chkDocumentExists(String legacyDocID) {
		// TODO Auto-generated method stub
		String legacyDocumentID = legacyDocID;
		//importDocLogger.info("Checking in Documents for the Legacy ID::"+legacyDocumentID);
		if(!chkInProjects(legacyDocumentID)){
			if(!chkInInstitutions(legacyDocumentID)){
				if(!chkInCountries(legacyDocumentID)){
					return false;
				}//end of IF check in Country documents
			}//end of IF check in Institution documents
		}//end of IF check in projects documents
		
		return true;
	}

	private static boolean chkInCountries(String legacyID) {
		// TODO Auto-generated method stub
		boolean flagCountry = true;
		//importDocLogger.info("Checking in Projects Documents::"+legacyID);
		IDfCollection collection1 = null;
		String queryStr1 = idocsProperties.getProperty("MSG_CHECK_LEGACY_ID");
		queryStr1 = queryStr1.replaceAll("<r_object_type>", idocsProperties.getProperty("MSG_COUNTRY_DOC"));
		queryStr1 = queryStr1.replaceFirst("<orig_doc_unique_id>", legacyID);
		try {
			collection1 = Utilities.executeQuery(dfSession, queryStr1, DfQuery.EXECREAD_QUERY);
			if(collection1 != null && collection1.next()){
				documentObjectID = collection1.getString(idocsProperties.getProperty("MSG_DOC_OBJECT_ID"));
				return flagCountry;
			}else{
				flagCountry = false;
			}
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException::"+e.getMessage());
			e.printStackTrace();
			flagCountry = false;
		}finally{
			if(collection1 != null){
				try {
					collection1.close();
				} catch (DfException e) {
					// TODO Auto-generated catch block
					importDocLogger.warning("DfException::"+e.getMessage());
					importDocLogger.warning("Problem in closing the collection1");
					e.printStackTrace();
				}
			}
		}
		return flagCountry;
	}

	private static boolean chkInInstitutions(String legacyID) {
		// TODO Auto-generated method stub
		boolean flagInst = true;
		//importDocLogger.info("Checking in Projects Documents::"+legacyID);
		IDfCollection collection1 = null;
		String queryStr1 = idocsProperties.getProperty("MSG_CHECK_LEGACY_ID");
		queryStr1 = queryStr1.replaceAll("<r_object_type>", idocsProperties.getProperty("MSG_INSTITUTION_DOC"));
		queryStr1 = queryStr1.replaceFirst("<orig_doc_unique_id>", legacyID);
		try {
			collection1 = Utilities.executeQuery(dfSession, queryStr1, DfQuery.EXECREAD_QUERY);
			if(collection1 != null && collection1.next()){
				documentObjectID = collection1.getString(idocsProperties.getProperty("MSG_DOC_OBJECT_ID"));
				return flagInst;
			}else{
				flagInst = false;
			}
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException::"+e.getMessage());
			e.printStackTrace();
			flagInst = false;
		}finally{
			if(collection1 != null){
				try {
//					collection1 = null;
					collection1.close();
				} catch (DfException e) {
					// TODO Auto-generated catch block
					importDocLogger.warning("DfException::"+e.getMessage());
					importDocLogger.warning("Problem in closing the collection1");
					e.printStackTrace();
				}
			}
		}
		return flagInst;
	}

	private static boolean chkInProjects(String legacyID) {
		// TODO Auto-generated method stub
		boolean flagProj = true;
		//importDocLogger.info("Checking in Projects Documents::"+legacyID);
		IDfCollection collection1 = null;
		String queryStr1 = idocsProperties.getProperty("MSG_CHECK_LEGACY_ID");
		queryStr1 = queryStr1.replaceAll("<r_object_type>", idocsProperties.getProperty("MSG_PROJECTS_DOC"));
		queryStr1 = queryStr1.replaceFirst("<orig_doc_unique_id>", legacyID);
		try {
			collection1 = Utilities.executeQuery(dfSession, queryStr1, DfQuery.EXECREAD_QUERY);
			if(collection1 != null && collection1.next()){
				documentObjectID = collection1.getString(idocsProperties.getProperty("MSG_DOC_OBJECT_ID"));
				return flagProj;
			}else{
				flagProj = false;
			}
			
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException::"+e.getMessage());
			e.printStackTrace();
			flagProj = false;
		}finally{
			if(collection1 != null){
				try {
//					collection1 = null;
					collection1.close();
				} catch (DfException e) {
					// TODO Auto-generated catch block
					importDocLogger.warning("DfException::"+e.getMessage());
					importDocLogger.warning("Problem in closing the collection1");
					e.printStackTrace();
				}
			}
		}
		return flagProj;
	}

}

/*Algorithm

1.Take the legacy document ID
2.check document uploaded in documentum or not
3.Query for documentum doc ID
4.Create dm_relation object
5.set relation_name='dm_subscription'
6.set parent_id=e_object_id of the document
7.set child_id=r_object_id of the user who subscribed it
8.save the relation object

*/