package org.ifc.idocs.migration.extract;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import lotus.domino.Document;
import lotus.domino.NotesError;
import lotus.domino.NotesException;

import org.ifc.idocs.migration.ExtractCommon;
import org.ifc.idocs.migration.transform.DocumentTransformer;

/**
 * @author SPankajamsadanan
 *
 */
public class DomdocDocument extends ExtractCommon{

	private iDocsContent content;
	private Document doc;
	private Metadata metadata;

	/**
	 * DomdocDocument method 
	 * @param notesdoc
	 * @throws NotesException
	 */
	public DomdocDocument(Document notesdoc) throws NotesException {
		this.doc = notesdoc;
		String docFormat = doc.getItemValueString("docformat");
		String unid = doc.getUniversalID();

		errorCode = "";
		errorMsg = "";

		if (doc.getItemValueString("fileroom").length() == 0) {
			errorCode = "ER_020";
			errorMsg = "Missing FILEROOM attribute";
			throw new NotesException(NotesError.NOTES_ERR_ERROR, "Document " + doc.getUniversalID() + " : missing FILEROOM attribute.");
		} else {
			this.metadata = MetadataTemplateFactory.createMetadataByFileroom(notesdoc.getItemValueString("fileroom"), docFormat.equals("Notes"));
			this.metadata.populateFromNotesDocument(doc);
		}
		if (docFormat.equals("Notes")) {
			this.content = new RichtextContent(doc);
			Metadata emd = MetadataTemplateFactory.createEmailMetadata();
			((RichtextContent) this.content).populateEmailMetadata(emd);
			this.metadata.putAll(emd);
			this.metadata.put("Filename", unid + ".pdf");
		} else if (docFormat.length() == 0){				
			this.content = new DomdocContent(doc);				
		} else if (docFormat.equals("RichText")) {
			this.content = new QuicknoteContent(doc);
			metadata.put("Filename", unid + ".html");
		} else {
			errorCode = "ER_046";
			errorMsg = "Doc format not supported";
			throw new NotesException(NotesError.NOTES_ERR_ERROR, "Document " + notesdoc.getUniversalID() + ": Content type " + doc.getItemValueString("docformat") + " is not supported.");
		}
	}

	/**
	 * export method
	 * @param path
	 * @throws Exception
	 */
	public void export(String path) throws Exception {
		StringBuilder exportPath = new StringBuilder(path);
		String unid = doc.getUniversalID();
		exportPath.append("\\").append(metadata.get("DocID"));
		exportPath.append("_").append(metadata.get("Version")).append(".").append(metadata.get("Draft")).append("_");

		//export content
		if (content == null) {
			throw new NotesException(NotesError.NOTES_ERR_ERROR, "Document " + unid + ": missing content at extraction.");
		}
		String exportedFilename = content.export(exportPath.toString());
		this.metadata.put("ExportedFilename", exportedFilename);

		//export metadata
		DocumentBuilderFactory dbfac = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = dbfac.newDocumentBuilder();
		org.w3c.dom.Document xmldoc = docBuilder.newDocument();
		org.w3c.dom.Element root = xmldoc.createElement("DomdocDocument");
		root.setAttribute("docunid", unid);
		root.setAttribute("version", (String)metadata.get("Version") + "." + (String)metadata.get("Draft"));
		xmldoc.appendChild(root);
		this.metadata.exportToXML(root);
		DocumentTransformer.transformMetadataXML(root);
		DocumentTransformer.exportToSharedMetadataFile(path,(String)metadata.get("DocID"), root);
	}

	/**
	 * @throws NotesException
	 */
	public void recycle() throws NotesException {
		this.doc.recycle();		
	}

	/**
	 * @param ndoc
	 * @return DomdocDocument
	 * @throws NotesException
	 */
	public static DomdocDocument getDomdocDocument(Document ndoc) throws NotesException {
		return new DomdocDocument(ndoc);
	}

}
