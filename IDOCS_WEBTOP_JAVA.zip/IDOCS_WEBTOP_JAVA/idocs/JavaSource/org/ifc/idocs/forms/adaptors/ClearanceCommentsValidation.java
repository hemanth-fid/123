package org.ifc.idocs.forms.adaptors;

import com.documentum.fc.common.DfLogger;
import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.IAdaptorParameter;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.xforms.engine.adaptor.datasource.ISetValueAdaptor;

public class ClearanceCommentsValidation
    implements ISetValueAdaptor
{
    public ClearanceCommentsValidation()
    {
    }

    public Object execute(IAdaptorParameter parameters[]) throws AdaptorException
    {
        DfLogger.info(this,"ClearanceCommentsValidation :: Inside ClearanceCommentsValidation",null,null);
        boolean errorValue = true;
        IAdaptorParameter parameter1 = parameters[0];
        String comments = parameter1.getValue();
        char eachChar[] = comments.toCharArray();
        for(int i = 0; i < eachChar.length; i++)
        {
            if(Character.isLetter(eachChar[i]) || Character.isWhitespace(eachChar[i]) || Character.isDigit(eachChar[i]))
            {
                continue;
            }
            DfLogger.info(this,Character.toString(eachChar[i]),null,null);
            errorValue = false;
            break;
        }

        if(errorValue)
        {
            DfLogger.info(this,"you have entered a valid comment",null,null);
        } else {
            DfLogger.info(this,"Please enter non numerical comments",null,null);
        }
        return Boolean.valueOf(errorValue);
    }

    public void destroy() throws AdaptorException
    {
    }

    public void init(IAdaptorConfiguration iadaptorconfiguration) throws AdaptorException
    {
    }
}
