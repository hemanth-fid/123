/**
 * 
 */
package org.ifc.idocs.workflow.workflowreport;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.LocaleService;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.databound.DataProvider;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.webcomponent.library.newwindow.NewWindow;

/**
 * @author SSubramanian11
 *
 */
public class WorkflowReport extends NewWindow {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9092342827280648534L;
	NlsResourceBundle nlsBundle;
	@Override
	public void onInit(ArgumentList argumentList) {
		
		super.onInit(argumentList);
		IDfSession dfSession = getDfSession();
		String workflowNlsProp = "org.ifc.idocs.workflow.workflowreport.WorkflowReportNlsProp";
		String projectId = argumentList.get("projectId");
		if(projectId == null){
			try {
				throw new DfException("Project ID is NULL");
			} catch (DfException e) {
				e.printStackTrace();
			}
		}
		DfLogger.debug(this, "Project ID is : "+projectId, null, null);
		nlsBundle = new NlsResourceBundle(workflowNlsProp);
		String workflowQry = nlsBundle.getString("AS_WORKFLOW_QRY", LocaleService.getLocale());
		workflowQry = workflowQry.replaceAll("%projectId%", projectId);
		DfLogger.debug(this, "Workflow Query : " + workflowQry, null, null);
		Datagrid dataGrid = (Datagrid)getControl("myGrid", Datagrid.class);
		
		if(dataGrid == null){
			dataGrid = (Datagrid)createControl("myGrid", Datagrid.class);
		}
		
		DataProvider dataprovider = dataGrid.getDataProvider();
		dataprovider.setDfSession(dfSession);
		dataprovider.setQuery(workflowQry);
		dataprovider.refresh();
		
	}
	
	public void callWorkflowReportDetail(Control ctrl, ArgumentList argList){
		Locale locale = LocaleService.getLocale();
		HttpServletRequest request= (HttpServletRequest)this.getPageContext().getRequest();
		String reqUrl = request.getRequestURL().toString();
		String newUrl = reqUrl.replace(getUrl(), "").concat(getBaseUrl());
		StringBuffer urlBuffer = new StringBuffer(newUrl);
		urlBuffer.append("/component").append("/").append(nlsBundle.getString("SUMMARY_LIST_COMPONENT", locale)).
		append("?objectId=").append(argList.get("objectId"));
		setRedirectUrl(urlBuffer.toString());
		
	}
}
