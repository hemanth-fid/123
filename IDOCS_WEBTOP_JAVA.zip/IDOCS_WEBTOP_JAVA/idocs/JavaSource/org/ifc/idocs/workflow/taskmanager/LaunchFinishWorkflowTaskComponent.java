/**
* 
* #######################################################################################################
* Author		 	  	DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Sleeba Kurian			09/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.workflow.taskmanager;

import java.util.HashMap;
import java.util.Map;

import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.utils.IdocsConstants;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQueueItem;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfWorkitem;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceClass;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.ErrorMessageService;
import com.documentum.web.formext.action.ActionExecutionUtil;
import com.documentum.web.formext.action.LaunchComponent;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.docbase.ObjectCacheUtil;

/**
 * This to handle the work flow getting paused because user finished the task before checking in the document.
 * @author SKurian1
 *
 */
public class LaunchFinishWorkflowTaskComponent extends LaunchComponent {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String lockOwner = null;
	
	public boolean execute(String strAction, IConfigElement config,
			ArgumentList args, Context context, Component component,
			Map completionArgs) {
		String objectId = args.get(IdocsConstants.MSG_OBJECTID);
		DfLogger.debug(this, " :: taskId =" +objectId,null, null);
		lockOwner = isIDocsPackageCheckedOut(objectId, component.getDfSession());
		if( lockOwner != null && lockOwner.trim().length() > 0 ){
			NlsResourceClass lookup = NlsResourceClass.getResource("org.ifc.idocs.workflow.taskmgrcontainer.TaskMgrContainerNlsProp");
			try {
				if(lockOwner.equals(component.getDfSession().getLoginUserName()) == true){
					ActionExecutionUtil.setCompletionError(completionArgs, lookup, "MSG_DOCUMENT_IS_LOCKED_BY_YOU", component, null, null);
					ErrorMessageService.getService().setNonFatalError(lookup, "MSG_DOCUMENT_IS_LOCKED_BY_YOU", component, null, null);
	                return false;
				}else if(lockOwner.equals(component.getDfSession().getDocbaseOwnerName()) == true){
					DfLogger.debug(this, " :: Document is locked by Workflow. Go ahead and Finish the Task. " +args,null, null);
					return super.execute(strAction, config, args, context, component, completionArgs);
				}else{
					ActionExecutionUtil.setCompletionError(completionArgs, lookup, "MSG_DOCUMENT_IS_LOCKED_BY_ANOTHER_USER", component, new String[]{lockOwner}, null);
					ErrorMessageService.getService().setNonFatalError(lookup, "MSG_DOCUMENT_IS_LOCKED_BY_ANOTHER_USER", component, new String[]{lockOwner}, null);
					return false;
				}
			} catch (DfException e) {
				DfLogger.error(this, " :: Exception :"+e.getMessage(),null, e);
				ActionExecutionUtil.setCompletionError(completionArgs, lookup, "MSG_UNKNOWN_EXCEPTION", component,null,null);
				ErrorMessageService.getService().setNonFatalError(lookup, "MSG_UNKNOWN_EXCEPTION", component,null,null);
				return false;
			}
		}else{
			DfLogger.debug(this, " :: Document is not locked. Go ahead and Finish the Task. " +args,null,null);
			return super.execute(strAction, config, args, context, component, completionArgs);
		}
	}
/**
 * 
 * @param m_taskId
 * @param dfSession
 * @return
 */
	private String isIDocsPackageCheckedOut(String m_taskId,IDfSession dfSession ) {
		DfLogger.debug(this, " :: isIDocsPackageCheckedOut >> m_taskId="+m_taskId,null, null);
		String documentLockOwner = null;
		HashMap<String,String> pakageMap = new HashMap<String,String>();
		try {
			IDfQueueItem qitem = (IDfQueueItem) ObjectCacheUtil.getObject(dfSession,m_taskId);
			IDfWorkitem witem = qitem.getWorkitem();
			IDfCollection collection = witem.getPackages(null);
			while(collection.next()){
				String packageName = collection.getString(IdocsConstants.R_PACKAGE_NAME);
				String packageType = collection.getString(IdocsConstants.R_PACKAGE_TYPE);
				String componentId = collection.getString(IdocsConstants.R_COMPONENT_ID);
				if(packageType !=null && packageType.trim().length() > 0
						&& componentId !=null && componentId.trim().length() > 0
						&& (packageType.equals(IdocsConstants.PROJ_DOC_TYPE) == true
								|| packageType.equals(IdocsConstants.INSTITUTION_DOC_TYPE) == true
								|| packageType.equals(IdocsConstants.COUNTRY_DOC_TYPE) == true )){
					String chronicleId = IDocDocbaseAttributeTagUtility.getSysObjectAttribute(dfSession,componentId,IdocsConstants.MSG_I_CHRONICLE_ID);
					documentLockOwner = IDocDocbaseAttributeTagUtility.getCurrentSysObjectAttributeFromChronicleId(dfSession,chronicleId,IdocsConstants.R_LOCK_OWNER);
					DfLogger.debug(this, " :: packageType=" +packageType +"  : chronicleId="+chronicleId+"  :documentLockOwner="+documentLockOwner,null, null);
					if(documentLockOwner !=null && documentLockOwner.trim().length() > 0 ){
						DfLogger.debug(this, " :: packageType=" +packageType +"  : objectId="
									+chronicleId+"  :documentLockOwner="+documentLockOwner,null, null);								        
						return  documentLockOwner; 
						
					}
				}			    
			}
			if(collection != null)collection.close();
		} catch (Exception e) {
			DfLogger.error(this, " :: Exception :"+e.getMessage(),null, null);	
		}
		DfLogger.debug(this, " :: isIDocsPackageCheckedOut <<"+documentLockOwner,null, null);
		return null;
	}
}

