package com.swbc.letters.commercial.migrate.utils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfRelation;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfTime;
import com.documentum.fc.common.IDfTime;


public class DctmUtil {

	private static Logger log = Logger.getLogger(DctmUtil.class);
	
	
	public static void createEvent(IDfSession mSess,String transId,String eventData,String tranObjectId) throws DfException{
		
			
			IDfClientX clientx = new DfClientX();
		  	String now = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new Date());
		  	IDfTime timeStamp = clientx.getTime(now, IDfTime.DF_TIME_PATTERN44);
		  	
		  	//Create Event
			IDfSysObject eventObj=  (IDfSysObject)mSess.newObject("itk_transaction_event");
			eventObj.setObjectName("RM Comment_" + transId);
			eventObj.setString("event_name", "RM Comment");
		  	eventObj.setTime("event_datetime", timeStamp);
		  	eventObj.setString("event_source", "DCTM");
		  	eventObj.setString("transaction_id", transId);
			eventObj.setString("operator_id", "dmadmin");
			eventObj.setString("event_data", eventData);
			eventObj.setString("event_group", "Auto");
		  	eventObj.save();
		  	
		  	//Create Transaction and Event Relationship
		  /*	IDfRelation eventRelObj=  (IDfRelation)mSess.newObject("itk_event_relationship");
			eventRelObj.setParentId(new DfId(tranObjectId));
			eventRelObj.setChildId(eventObj.getObjectId());
			eventRelObj.setRelationName("itk_event_relationship");
			eventRelObj.save();*/
		
			log.debug( "Complete create event");
			
	}	
	
	
	public static List<File>  getfilesFromDirectory(String srcFileDirPath) throws Exception{

		List<File> fileList=null;

		File srcFolder = new File(srcFileDirPath.toString());
		
		if(srcFolder!=null){

			if(srcFolder.isDirectory()){

				File[] subFiles=srcFolder.listFiles();
				
				if(subFiles!=null && subFiles.length>0){
					fileList = Arrays.asList(subFiles);

				}else{

					throw new Exception("Directory -->"+srcFileDirPath +" Empty");
				}
			}
		}

		
		return fileList;
	}
	
	public static boolean isDirectoryExists(String directoryPath){

		boolean isExists=false;
		File srcFolder = null;

		if(StringUtils.isNotEmpty(directoryPath)){
			srcFolder = new File(directoryPath);

			if(srcFolder!=null){

				if(srcFolder.isDirectory()){
					isExists=true;
				}

			}
		}
		return isExists;
		
	}
	
	public static String createAutoRecord(IDfSession dfSession,String target_account_no,String buildingNo,String  target_coverage_type,
			Date file_modified_date,String letterCode,String target_loan_no,String sequence_number,String target_transaction_date, String  filePath,
			String target_letter_code,String target_seq_no) throws DfException,Exception {
					
		
		IDfDocument document = (IDfDocument) dfSession.newObject("par_paris_letters");
		
		
		document.setObjectName(FilenameUtils.getBaseName(filePath));
		document.setTitle(FilenameUtils.getBaseName(filePath));
		document.setSubject("Commercial Migrated Letters_"+target_letter_code+"_"+target_seq_no);
		
		
		if(StringUtils.isNotBlank(target_account_no) && StringUtils.length(target_account_no)<4){

			target_account_no=StringUtils.leftPad(target_account_no, 4, "0");
		}
		
		document.setString("account_number", target_account_no);
		document.setTime("transaction_date", AS400DateConverter.convertAS400DateToIDfTime(Integer.parseInt(target_transaction_date)));
		
		if(StringUtils.isNotBlank(target_loan_no) && StringUtils.length(target_loan_no)<35){

			target_loan_no=StringUtils.leftPad(target_loan_no, 35, "0");
		}
		
		document.setString("loan_number", target_loan_no);
		document.setString("coverage_type", target_coverage_type);
		document.setTime("doc_creation_date", new DfTime(file_modified_date));
		document.setString("letter_code", letterCode);
		//document.setTime("as400_post_date", new DfTime());
		document.setString("business_type", "MTG");
		document.setString("loan_suffix", "00");
		document.setString("agency_number", "01");
		document.setString("building", buildingNo);
		document.setString("sequence_number", sequence_number);
		
		document.setContentType("pdf");
 		document.setFile(filePath);
 		
 		if(document.isDirty()) {
			document.save();
			
		}
 		
 		return document.getString("transaction_id");
		
	}
	
	
	public static String createMTGRecord(IDfSession dfSession,String account_number,String loan_number,String coverage_type,String loan_suffix,String filePath) throws DfException {
					
		
		IDfDocument document = (IDfDocument) dfSession.newObject("par_paris_letters");
		
		
		document.setObjectName(FilenameUtils.getBaseName(filePath));
		document.setTitle(FilenameUtils.getBaseName(filePath));
		document.setSubject("Letters");
		document.setString("account_number", account_number);
		document.setTime("transaction_date", new DfTime());
		document.setString("loan_number", loan_number);
		document.setString("coverage_type", coverage_type);
		document.setTime("doc_creation_date", new DfTime());
		document.setString("letter_code", "99");
		document.setTime("as400_post_date", new DfTime());
		document.setString("business_type", "MTG");
		document.setString("loan_suffix", loan_suffix);
		
		document.setContentType("pdf");
 		document.setFile(filePath);
 		
 		if(document.isDirty()) {
			document.save();
			
		}
 		
 		return document.getString("transaction_id");
		
	}
	


	public static IDfCollection executeQuery(IDfSession session, String dql) throws DfException {

		IDfCollection collection = null;
		
			//log.debug("The query is " + dql);
			collection = executeQuery(session, dql, IDfQuery.DF_EXEC_QUERY);
		
		return collection;

	}
	
	
	public static IDfCollection executeQuery(IDfSession session, String dql, int queryExecType) throws DfException {

		IDfCollection collection = null;
		IDfQuery query = null;

		try {
			query = new DfQuery();
			log.debug("The query is " + dql);
			query.setDQL(dql);
			collection = query.execute(session, queryExecType);
		} catch (DfException dfe) {
			log.error("Error while executing the query ", dfe);
			throw dfe;
		}
		return collection;

	}
	
	
	public static void closeCollection(IDfCollection collection) throws DfException {

		if (collection != null && collection.getState() != IDfCollection.DF_CLOSED_STATE) {
			try {
				collection.close();
			} catch (DfException dfe) {
				log.warn("Error while closing the collection ", dfe);
				throw dfe;
			}
		}
	}

}
