package org.ifc.idocs.migration.helper;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;


public class TimeZoneTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
        // TODO Auto-generated method stub
        Date ESTDate = new Date("02/16/2007 00:00:00");
        Date EDTDate = new Date("07/19/2011 08:55:48 AM");

        DateFormat utcFormat = new SimpleDateFormat();

        TimeZone utcTime = TimeZone.getTimeZone("UTC");
        utcFormat.setTimeZone(utcTime);

        System.out.println("UTC for EST Time: " + utcFormat.format(ESTDate));
        System.out.println(" offset " + ESTDate.getTimezoneOffset() + " Min");

        System.out.println("UTC for EDT Time: " + utcFormat.format(EDTDate));
        System.out.println(" offset " + EDTDate.getTimezoneOffset() + " Min");

        System.out.println(TimeZone.getDefault().inDaylightTime(new Date()));
	}

}
