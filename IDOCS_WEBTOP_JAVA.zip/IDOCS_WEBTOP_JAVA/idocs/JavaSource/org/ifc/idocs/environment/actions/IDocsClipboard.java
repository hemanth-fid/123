package org.ifc.idocs.environment.actions;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.ifc.idocs.utils.IDocsClipboardPasteHandler;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.formext.Trace;
import com.documentum.web.formext.clipboard.Clipboard;
import com.documentum.web.formext.clipboard.IClipboardCutHandler;


public class IDocsClipboard extends Clipboard {
	
	

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final class ClipboardEntry
        implements Serializable
    {

        IClipboardCutHandler handler;
        String docbase;
        final Clipboard this$0;

        ClipboardEntry(IClipboardCutHandler handler, String strDocbase)
        {
        	super();
            this$0 = IDocsClipboard.this;
            this.handler = handler;
            docbase = strDocbase;
        }
    }


    public IDocsClipboard()
    {
        m_hashItems = new HashMap(31, 1.0F);
        m_bOperationComplete = false;
    }

    public void pasteAsCopy(String strObjectId, IDocsClipboardPasteHandler handler)
    {
        if(!contains(strObjectId) && !isAuxiliaryObject(strObjectId))
        {
            throw new IllegalArgumentException("Can only paste items that exist on the clipboard!");
        } else
        {
            super.pasteAsCopy(strObjectId, handler);
            m_bOperationComplete = true;
            return;
        }
    }

    public void setOperationComplete(boolean bOperationComplete)
    {
        m_bOperationComplete = bOperationComplete;
    }

    public boolean pasteAsLinkEx(String strObjectId, IDocsClipboardPasteHandler handler)
    {
        if(!contains(strObjectId) && !isAuxiliaryObject(strObjectId))
        {
            throw new IllegalArgumentException("Can only paste items that exist on the clipboard!");
        } else
        {
            boolean bStatus = super.pasteAsLinkEx(strObjectId, handler);
            m_bOperationComplete = true;
            return bStatus;
        }
    }

    public void pasteAsMove(String strObjectId, IDocsClipboardPasteHandler handler)
    {
        super.pasteAsMove(strObjectId, handler);
        DfLogger.info(this, " :: pasteAsMove : strObjectId: " + strObjectId,null,null);
        m_bOperationComplete = true;
    }

    public void remove(String strObjectId)
    {
        if(strObjectId == null)
            throw new IllegalArgumentException("Object Id must be valid!");
        if(Trace.CLIPBOARD)
            Trace.println((new StringBuilder()).append("Clipboard: Removing item id: ").append(strObjectId).toString());
        m_hashItems.remove(strObjectId);
    }

    public void remove(String strObjectIds[])
    {
        if(strObjectIds == null)
            throw new IllegalArgumentException("Object Ids must be valid!");
        for(int iIndex = 0; iIndex < strObjectIds.length; iIndex++)
            remove(strObjectIds[iIndex]);

    }

    public void removeAll()
    {
        for(Iterator itrItems = ids(); itrItems.hasNext(); remove((String)itrItems.next()));
    }

    public static boolean canCut(IDocsClipboard clipboard, String strDocbase)
    {
        String items[] = clipboard.getItemIds();
        String strItemDocbase = null;
        for(int iIndex = 0; iIndex < items.length; iIndex++)
        {
            strItemDocbase = items[iIndex];
            if((strDocbase == null || strDocbase.equals(clipboard.getDocbaseForItem(strItemDocbase))) && clipboard.getCutHandler(strItemDocbase).getSourceFolderId() != null)
                return true;
        }

        return false;
    }

    public boolean contains(String strObjectId)
    {
        return m_hashItems.containsKey(strObjectId);
    }

    public boolean hasItems()
    {
    	DfLogger.info(this, " :: hasItems : m_hashItems.size(): " + m_hashItems.size(),null,null);
        return m_hashItems.size() > 0;
    }

    public String getDocbaseForItem(String strObjectId)
    {
        String strDocbase = null;
        ClipboardEntry entry = (ClipboardEntry)m_hashItems.get(strObjectId);
        if(entry != null)
            strDocbase = entry.docbase;
        return strDocbase;
    }

    public String[] getItemIds()
    {
        String items[] = new String[m_hashItems.size()];
        int index = 0;
        for(Iterator itrIds = m_hashItems.keySet().iterator(); itrIds.hasNext();)
            items[index++] = (String)itrIds.next();

        return items;
    }

    public Iterator ids()
    {
        ArrayList items = new ArrayList(m_hashItems.size());
        for(Iterator itrIds = m_hashItems.keySet().iterator(); itrIds.hasNext(); items.add(itrIds.next()));
        return items.iterator();
    }

    public int size()
    {
        return m_hashItems.size();
    }

    public IClipboardCutHandler getCutHandler(String strObjectId)
    {
        ClipboardEntry entry = (ClipboardEntry)m_hashItems.get(strObjectId);
        return entry.handler;
    }

    protected void handleObjectNotExistInDocbase(String strObjectId)
    {
        remove(strObjectId);
    }

    protected void onSuccessfulMove(String strObjectId)
    {
        remove(strObjectId);
    }

    private Map m_hashItems;
    private boolean m_bOperationComplete;


}
