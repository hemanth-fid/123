/**
* This precondition class to displays the Document state.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created
* #######################################################################################################
*/
package org.ifc.idocs.library.actions;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.AccessibilityService;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.action.IActionPrecondition;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.docbase.FolderUtil;

public class ViewVirtualDocumentPrecondition
    implements IActionPrecondition
{

    public ViewVirtualDocumentPrecondition()
    {
    }

    public String[] getRequiredParams()
    {
        return (new String[] {
            "objectId"
        });
    }

    public boolean queryExecute(String strAction, IConfigElement config,
			ArgumentList arg, Context context, Component component) {
        boolean bExecute=false;
        String strObjectId = arg.get("objectId");
		boolean bAccessibilityOn = AccessibilityService.isAllAccessibilitiesEnabled();
		String strComponentId = component.getComponentId(bAccessibilityOn);
		DfLogger.info(this," :: strComponentId : "+strComponentId,null,null);
		if(!FolderUtil.isFolderType(strObjectId)){
            String strLinkCount = arg.get("linkCount");
            double dLinkCount = 0.0D;
            boolean bIsVirtual = false;
            if(strLinkCount != null && strLinkCount.length() > 0){
                dLinkCount = Double.parseDouble(strLinkCount);
                if(dLinkCount > 0.59999999999999998D){
                    bIsVirtual = true;
                }
            }
            if(bIsVirtual == false){
                String strIsVirtual = arg.get("isVirtualDoc");
                if(strIsVirtual != null){
                    if(strIsVirtual.equals("true")){
                        bIsVirtual = true;
                    } else{
                        try{
                            if(Double.parseDouble(strIsVirtual) > 0.59999999999999998D){
                                bIsVirtual = true;
                            }
                        }catch(NumberFormatException e) { }
                    }
                }
            }
            String strIsCurrentVDMNode = arg.get("isCurrentVDMNode");
            if(bIsVirtual && (strIsCurrentVDMNode == null 
            		|| strIsCurrentVDMNode != null && strIsCurrentVDMNode.equals("false"))){
                bExecute = true;
            }
        }
        return bExecute;
    }
}