/**
*  This class  returns the IDocsErrorMessageFactory object if it does not exist.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    11/17/2010	     1.0          Created
* #######################################################################################################
*/
package org.ifc.idocs.exception;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.jsp.PageContext;

import org.apache.log4j.Logger;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.common.DfLogger;

public class IDocsErrorMessageFactory {
	public static final String STR_PARENT_NODE_NAME_IN_ERROR_XML_FILE = "errormessages";
	public static final String STR_MSG_NOT_FOUND = "Message Not Found";
	private static Logger logger = Logger.getLogger(IDocsErrorMessageFactory.class);
	private static IDocsErrorMessageFactory objIDocsErrorMessageFactory = null;
	private HashMap hmpErrorBundle = null;
	// Constructor which will loads the errorcodes,error messages from xml file
	private IDocsErrorMessageFactory(PageContext pc) {
		logger.info(" Start IDocsErrorMessageFactory()");
		ArrayList arrValues = null;
		try {
			InputStream streamErrorXML = pc.getServletContext().getResourceAsStream(IdocsConstants.STR_ERROR_MESSAGES_XML_FILE_PATH);
			hmpErrorBundle = (HashMap) new IdocsUtil().parseXML(STR_PARENT_NODE_NAME_IN_ERROR_XML_FILE, false,streamErrorXML);
			logger.info("XML Error code values  in IDocsErrorMessageFactory : " + arrValues);
		} catch (IDocsException objException) {
			logger.info("IDocsErrorMessageFactory's IDocsException catch block ",objException);			
			DfLogger.error(this,": <<Exception>> : "+objException.getMessage(),null,objException);
			logger.debug("Error in IDocsErrorMessageFactory() while loading default values from XML");
		} catch (Exception exception) {
			logger.info("IDocsErrorMessageFactory's IDocsException catch block ",exception);
			DfLogger.error(this,": <<Exception>> : "+exception.getMessage(),null,exception);
		}
		logger.info(" End IDocsErrorMessageFactory() ");
	}
	
	/**
	 * This method  returns the IDocsErrorMessageFactory object if it does not exist
	 */
	public synchronized static IDocsErrorMessageFactory getFactory(PageContext pc) {
		return objIDocsErrorMessageFactory = (objIDocsErrorMessageFactory == null ? new IDocsErrorMessageFactory(pc) : objIDocsErrorMessageFactory);
	}
	
	/**
	 * This method will return the error message
	 */
	public String getErrorMessage(IDocsException objIDocsException) {
		logger.info(" Start getErrorMessage()  ");
		String strMessage = STR_MSG_NOT_FOUND;
		try {
			strMessage = hmpErrorBundle.get("" + objIDocsException.getErrorCode()).toString();
		} catch (Exception exception) {
			logger.debug(" Exception while getting message from error bundle  ",exception);
		}
		logger.info(" End getErrorMessage() ");
		return strMessage;
	}
}
