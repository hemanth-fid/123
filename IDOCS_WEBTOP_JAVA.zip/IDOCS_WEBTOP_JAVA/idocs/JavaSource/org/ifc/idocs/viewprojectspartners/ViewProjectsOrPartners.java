/**
* This class is for displaying project folders for a partner OR partner folders for a project.
* This component will be invoked when user clicks on 'View Projects/Partners' action menu on a folder .
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.viewprojectspartners;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.component.Component;


public class ViewProjectsOrPartners extends Component{	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String foldertype=null;
	public String strFolderObjID = null;
	public String strFolderPath = null;
	static IdocsUtil idocsUtil = new IdocsUtil();
	IDfFolder dfFolder=null;
	
	public void onInit(ArgumentList args){
		super.onInit(args);		
	}
	
    public void onRender(){
    	super.onRender();
    }
	
	
	/**
	 * This method returns the DQL Query which will be used to fetch the client company/project folders
	 * @param strFolderObjID
	 * @param validInstitFolderFlag 
	 * @param validProjFolderFlag 
	 * @return dqlQry
	 */
	public String getQuery(String strFolderObjID,String typeofFolder){
		String dqlQry = null;
		DfLogger.debug(this,"Inside getQuery method",null,null);
		if(typeofFolder !=null && typeofFolder.trim().length() > 0){
			if(typeofFolder.equals(IDocsConstants.MSG_IDOCS_INSTIT_FOLDER)){
				dqlQry = IdocsUtil.getMessage(IdocsConstants.PROJECT_FOLDER_QRY);
			}else if(typeofFolder.equals(IDocsConstants.MSG_IDOCS_PROJ_FOLDER)){
				dqlQry = IdocsUtil.getMessage(IdocsConstants.CLIENT_COMPANY_FOLDER_QRY);
			}
		}
		dqlQry = dqlQry.replaceFirst("''", "'"+strFolderObjID+"'");		
		DfLogger.debug(this,": getQuery :DQL Query : : : "+dqlQry,null,null);
		
		return dqlQry;
	} 
	
	/**
	 * This utility method is to find whether the Partner Project Relationship is 1 TO 1 or not.
	 * If there is only one result that method shall be returning the Resultant Project/Partner ID.
	 * And if there are multiple results null will be returned. 
	 * @param strFolderObjID - Current Folder Object Id
	 * @param validProjFolderFlag - Flag to indicate whether strFolderObjID belongs to a Project Folder 
	 * @param validInstitFolderFlag - Flag to indicate whether strFolderObjID belongs to a Partner Folder
	 * @return 
	 * @throws DfException
	 */
	public String isSingletonRelationship(String strFolderObjID,String typeofFolder) {
		String strQrygetcount=null;
		String firstResultObjectId= null;
		int count = 0;
		DfLogger.debug(this,"Inside method singletonrelationship",null,null);
		try {
			if(typeofFolder !=null && typeofFolder.trim().length() > 0){
			if(typeofFolder.equals("idocs_institution_folder")){
				strQrygetcount = IdocsUtil.getMessage(IdocsConstants.STR_SEARCH_COUNT_PROJECT_RESULTS_QRY);
			}
			else if(typeofFolder.equals("idocs_project_folder")){
			strQrygetcount = IdocsUtil.getMessage(IdocsConstants.STR_SEARCH_COUNT_INSTIT_RESULTS_QRY);
			}
			}
				strQrygetcount=strQrygetcount.replace("''","'"+strFolderObjID+"'");
				IDfCollection countCollection = executeQuery(strQrygetcount);
				count = 0;
				while(countCollection.next()) {
					firstResultObjectId = countCollection.getString(IdocsConstants.R_OBJECT_ID);
					if(firstResultObjectId  != null && firstResultObjectId .trim().length()>0){
						count++;
					}
				}
				if(countCollection!=null)countCollection.close();
		} catch (DfException e) {
			e.printStackTrace();
		}
			
		if(count == 1){
			return firstResultObjectId;
		}else{
			return null;
		}
	} 
	private IDfCollection executeQuery(String queryString) throws DfException{
		IDfCollection collectionObj = null;
		DfLogger.info(this, " :: executeQuery :: queryString: " + queryString , null, null);
		IDfQuery query = new DfQuery();
		query.setDQL(queryString);		
		collectionObj = query.execute(getDfSession(), DfQuery.EXECREAD_QUERY);
		return collectionObj;
	}
	
	
}
