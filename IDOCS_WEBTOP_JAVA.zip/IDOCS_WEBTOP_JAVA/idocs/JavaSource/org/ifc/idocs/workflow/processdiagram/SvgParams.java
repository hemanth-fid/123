/**
* This class displays the attribute values of the Workflow process diagram
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.workflow.processdiagram;
public abstract class SvgParams 
{
  public static final String SVG_WIDTH = "_svgWidth";
  public static final String SVG_HEIGHT = "_svgHeight";
  public static final String ASPECT_RATIO = "_exPreserveAspectRatio";
  public static final String XML_DOC_NAME = "_exDocName";
  public static final String DOC_DESC = "_exDocDescription";
  public static final String IMAGES_ROOT = "_exImagesRoot";
  public static final String CLASSIC_DIAGRAM_VIEW = "_classicView";
  public static final String SVG_ERROR_FILE = "svgError.svg";
  public static final String SVG_EMPTY_FILE = "svgEmpty.svg";
  public static final String ACTIVITY_COMPLETE = "_complete";
  public static final String ACTIVITY_FAILED = "_failed";
  public static final String ACTIVITY_FAULT = "_fault";
  public static final String SUB_PROCESS = "_subProcess";
  public static final String ACTIVITY_RUNNING = "_running";
  public static final String ACTIVITY_TIMER = "_timer";
  public static final String ALERT_HIGH = "_alert_high";
  public static final String ALERT_MED = "_alert_med";
  public static final String ALERT_LOW = "_alert_low";
  public static final String PROCESSES = "processes";
  public static final String PROCESS = "process";
  public static final String PROCESS_NAME = "processName";
  public static final String ID = "id";
  public static final String R_OBJECT_ID = "r_object_id";
  public static final String NODE_ID = "nodeId";
  public static final String NODES = "nodes";
  public static final String NODE = "node";
  public static final String INSTANCEID = "instanceId";
  public static final String PROCESSID = "processId";
  public static final String NAME = "name";
  public static final String SVGWIDTH = "svgWidth";
  public static final String SVGHEIGHT = "svgHeight";
  public static final String SVGVIEWTYPE = "svgViewType";
  public static final String SVGLOCATION = "svgLocation";
  public static final String SVGCONTENT = "svgContent";
  public static final String CONTENTTYPEREQUIRED = "contentTypeRequired";
  public static final String EXEC_DATA = "executionData";
  public static final String INSTANCE_NODE = "instance";
  public static final String IS_ALARMA_EXIST = "isAlarmExist";
  public static final String ALARMA_SEVERITY = "alarmSeverity";
  public static final String ACTIVITY_INSTANCE_ID = "activityInstanceId";
  public static final String START_DATE_TIME = "startDateTime";
  public static final String END_DATE_TIME = "endDateTime";
  public static final String STATUS = "status";
  public static final String ALRT_EXIST = "alert";
  public static final String NUMBER_OF_ACT_INS = "numInstances";
  public static final String PROCESS_INSTANCE_INVOCATION = "invokeProcessInstance";
  public static final String STATUS_IN_PROGRESS = "in_progress";
  public static final String STATUS_FUTURE = "future";
  public static final String STATUS_COMPLETE = "complete";
  public static final String STATUS_FAILED = "failed"; 
  public static final String XML_DEF_PRO_WIDTH = "@width";
  public static final String XML_DEF_PRO_HEIGHT = "@height";
  public static final String XML_DEF_PRO_NAME = "@name";
  public static final int STARTED = 0;
  public static final int COMPLETED = 1;
  public static final int PROCESS_ABORTED = 3;
  public static final int ACQUIRED = 5;
  public static final int UN_ACQUIRED = 6;
  public static final int DELEGATED = 7;
  public static final int SUSPENDED = 8;
  public static final int UN_USPENDED = 9;
  public static final int FAILED = 18;
}