/**
* This custom component class provides query for the users in selective project.
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
*  Parag Doshi			11/15/2010		1.0				created
* #######################################################################################################
*/
package org.ifc.idocs.locator;

import java.io.IOException;
import java.util.Properties;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.DfAuthenticationException;
import com.documentum.fc.client.DfIdentityException;
import com.documentum.fc.client.DfPrincipalException;
import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfGroup;
import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfUser;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfUtil;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.query.ExpressionSet;
import com.documentum.web.form.query.ParsedExpression;
import com.documentum.web.formext.docbase.ServerUtil;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import com.documentum.webcomponent.library.locator.LocatorItemResultSet;
import com.documentum.webcomponent.library.locator.LocatorQuery;

public class UserOrGroupLocatorQuery extends LocatorQuery
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Properties idocsProperties = new Properties();

	static class UserOrGroupLocatorItemResultSet extends LocatorItemResultSet
	{

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		protected Object getObjectAttributeValue(IDfPersistentObject iObject, String strAttrName)
		{
			Object objVal = null;
			try
			{
				if(iObject instanceof IDfUser)
				{
					IDfUser iuser = (IDfUser)iObject;
					if(strAttrName.equals("object_name"))
						objVal = iuser.getUserName();
					else
						if(strAttrName.equals("address_"))
							objVal = iuser.getUserAddress();
						else
							if(strAttrName.equals(IDocsConstants.MSG_R_OBJECT_TYPE))
								objVal = "dm_user";
							else
								if(strAttrName.equals("owner_name"))
									objVal = "";
								else
									if(strAttrName.equals("workflow_disabled"))
										objVal = String.valueOf(iuser.isWorkflowDisabled());
									else
										objVal = super.getObjectAttributeValue(iObject, strAttrName);
				} else
					if(iObject instanceof IDfGroup)
					{
						IDfGroup igroup = (IDfGroup)iObject;
						if(strAttrName.equals("object_name"))
							objVal = igroup.getGroupName();
						else
							if(strAttrName.equals("address_"))
								objVal = igroup.getGroupAddress();
							else
								if(strAttrName.equals(IDocsConstants.MSG_R_OBJECT_TYPE))
									objVal = "dm_group";
								else
									if(strAttrName.equals("user_os_name"))
										objVal = "";
									else
										if(strAttrName.equals("workflow_disabled"))
											objVal = "";
										else
											objVal = super.getObjectAttributeValue(iObject, strAttrName);
					}
			}
			catch(DfException e)
			{
				throw new WrapperRuntimeException("Failed to get folder path", e);
			}
			return objVal;
		}

		public UserOrGroupLocatorItemResultSet(String strType)
		{
			/*super(strType, new String[] {
					"object_name", IDocsConstants.MSG_R_OBJECT_TYPE, "address_", "owner_name", "user_os_name", "workflow_disabled"
			});*/
			super(strType, new String[] {
					"object_name", IDocsConstants.MSG_R_OBJECT_TYPE});
		}

		protected UserOrGroupLocatorItemResultSet(String strType, String strExtraColumns[])
		{
			//super(strType, strExtraColumns);
			super(strType, new String[] {
					"object_name", IDocsConstants.MSG_R_OBJECT_TYPE});
		}
	}

	private boolean m_fShowPrivateGroups;
	private boolean m_fShowWorkQueueGroups;
	protected boolean m_fIs53Docbase;
	private boolean m_showUnlistedUsers;
	private String m_documentId;
	private String m_roleType;
	private boolean m_isIOMeditPerformers;
	public UserOrGroupLocatorQuery()
	{
		super("a");
		m_fShowPrivateGroups = false;
		m_fShowWorkQueueGroups = false;
		m_fIs53Docbase = false;
		m_showUnlistedUsers = false;
		setViewDocbaseType("dm_user");
		m_documentId = null;
		m_fIs53Docbase = ServerUtil.compareDocbaseVersion(5, 3);
	}


	public void setPrivateGroupVisible(boolean fShowPrivateGroups)
	{
		m_fShowPrivateGroups = fShowPrivateGroups;
	}

	public boolean isPrivateGroupVisible()
	{
		return m_fShowPrivateGroups;
	}

	public void setWorkQueueGroupVisible(boolean fShowWorkQueueGroups)
	{
		m_fShowWorkQueueGroups = fShowWorkQueueGroups;
	}

	public boolean isWorkQueueGroupVisible()
	{
		return m_fShowWorkQueueGroups;
	}

	public void setShowUnlistedUsers(boolean showUnlistedUsers)
	{
		m_showUnlistedUsers = showUnlistedUsers;
	}

	public boolean getShowUnlistedUsers()
	{
		return m_showUnlistedUsers;
	}

	public LocatorItemResultSet createItemResultSet()
	{
		return new UserOrGroupLocatorItemResultSet(getSelectableDocbaseType());
	}

	public void setDocumentId(String strDocumentId)
	{
		m_documentId=strDocumentId;
	}

	public void setIsIOMEditPerformers(boolean isIOMEditPerformers){
		m_isIOMeditPerformers = isIOMEditPerformers;
	}
	public void setRoleType(String roleType) 
	{
		m_roleType = roleType;
	}

	protected String getRootViewStatement() {
		boolean fUnion = false;
		StringBuffer bufStatement = new StringBuffer(512);

		try {
			idocsProperties.load(UserOrGroupLocator.class.getResourceAsStream(IdocsConstants.IDOCS_PROPERTY_FILE));

			SessionManagerHttpBinding httpBinding = new SessionManagerHttpBinding();
			IDfSessionManager sessionManager = httpBinding.getSessionManager();
			IDfSession dfSession = sessionManager.getSession(httpBinding.getCurrentDocbase());
			if (m_isIOMeditPerformers == false){
				DfLogger.info(this, "UserOrGroupLocatorQuery :: getRootViewStatement : "+m_documentId, null, null);
				if(!isTypeExcluded("dm_group")) {
					fUnion = true;
					setFromClause("dm_group a");
					ExpressionSet predicate = new ExpressionSet();
					if(!isPrivateGroupVisible())
						predicate.addExpression("AND", new ParsedExpression("(a.is_private=0 or a.owner_name=user)"));
					if(m_fIs53Docbase)
					{
						predicate.addExpression("AND", new ParsedExpression("(a.group_native_room_id = '0000000000000000')"));
						if(!isWorkQueueGroupVisible())
							predicate.addExpression("AND", new ParsedExpression("(a.group_class IS NULL OR a.group_class!='queue')"));
						if(!getShowUnlistedUsers())
							predicate.addExpression("AND", new ParsedExpression("(a.group_name!='dce_hidden_users')"));
					}
					if(predicate.getExpressionSet().size() == 0)
						setBaseViewExpression(null);
					else
						setBaseViewExpression(predicate);
					processNameStartsWith("a.group_name");
					setGroupSelectAttributes();
					bufStatement.append("SELECT").append(" ").append(getSelectForPermitSnippet()).append(" ").append(getSelectType()).append(" ");
					bufStatement.append(prepareSelectValuesSnippet());
					bufStatement.append(" ").append("FROM").append(" ");
					bufStatement.append(getFromClause());
					bufStatement.append(" ");
					bufStatement.append(prepareWhereClauseSnippet());
					DfLogger.info(this, "dfSession Session Login User : " + dfSession.getLoginUserName(), null, null);
					// Query is updated to get proper list of users custom
					// Fetch users from table project_team
					String strObjectType =  IDocDocbaseAttributeTagUtility.getSysObjectAttribute(dfSession, m_documentId, IdocsConstants.R_OBJECT_TYPE);
					DfLogger.info(this," :: getRootViewStatement: Value of Object type: "+strObjectType,null,null);
					if(strObjectType != null 
							&& strObjectType.equals(IDocsConstants.MSG_IDOCS_PROJECT_DOC)){	  
						String strProjectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(dfSession,  m_documentId, IdocsConstants.PROJ_ID, IDocsConstants.MSG_IDOCS_PROJECT_DOC);
						if(m_roleType.equals("project_members")){
							DfLogger.info(this,"Value of Role type "+m_roleType,null,null);
							bufStatement.append(" AND a.description IN (");
							String projTeamMemQry = idocsProperties.getProperty("QRY_PROJ_TEAM_MEMBER_DISCUSSION").replaceFirst("''","'"+strProjectId+"'");
							DfLogger.info(this," :: getRootViewStatement: projTeamMemQry:  " + projTeamMemQry,null,null);
							String projTeamMemQryValues = getProjTeamMembers(dfSession, projTeamMemQry);
							DfLogger.info(this, ":: getRootViewStatement: projTeamMemQryValues: " + projTeamMemQryValues, null, null);
							bufStatement.append(projTeamMemQryValues);
							bufStatement.append(" )");
						}else{
							bufStatement.append(" AND a.description IN (");
							String projGrpMemQry = idocsProperties.getProperty("QRY_PROJ_GROUP_MEMBER").replaceFirst("''","'"+strProjectId+"'").replaceFirst("''","'"+m_roleType+"'");
							DfLogger.info(this," :: getRootViewStatement: projGrpMemQry:  " + projGrpMemQry,null,null);
							String projGrpMemQryValues = getProjTeamMembers(dfSession, projGrpMemQry);
							DfLogger.info(this, ":: getRootViewStatement: projGrpMemQryValues: " + projGrpMemQryValues, null, null);
							bufStatement.append(projGrpMemQryValues);
							bufStatement.append(" )");
						}
					} else if(strObjectType != null 
							&& strObjectType.equals(IDocsConstants.MSG_IDOCS_INSTITUTION_DOC)){
						String strInstiRoleType = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(dfSession,  m_documentId, IdocsConstants.MSG_INSTITUTION_ROLE_TYPE_CODE, IDocsConstants.MSG_IDOCS_INSTITUTION_DOC);
						DfLogger.info(this,"Value of Institution Role type "+strInstiRoleType,null,null);     		
						if(strInstiRoleType!=null && strInstiRoleType.trim().length() > 0 
								&& strInstiRoleType.equals(IDocsConstants.MSG_INTITUTION_CLIENT_ROLE)){
							String strInstitutionNumber = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(dfSession,  m_documentId, IdocsConstants.MSG_INSTITUTION_NBR, IDocsConstants.MSG_IDOCS_INSTITUTION_DOC);
							DfLogger.info(this,"Value of Institution Number "+strInstitutionNumber,null,null);
							String frameClientProjects = idocsProperties.getProperty("QRY_CLIE_INSTI_PROJECTS").replaceFirst("''", strInstitutionNumber);
							bufStatement.append(" AND a.description IN (");
							String projTeamMemMultiQry = idocsProperties.getProperty("QRY_PROJ_TEAM_MEMBER_MULTI_DISCUSSION").replaceFirst("''",frameClientProjects);
							DfLogger.info(this," :: getRootViewStatement: projTeamMemMultiQry:  " + projTeamMemMultiQry,null,null);
							String projTeamMemMultiValues = getProjTeamMembers(dfSession, projTeamMemMultiQry);
							DfLogger.info(this, ":: getRootViewStatement: projTeamMemMultiValues: " + projTeamMemMultiValues, null, null);
							bufStatement.append(projTeamMemMultiValues);
							bufStatement.append(" )");
						}else{	        			
							bufStatement.append(" AND a.description IN (");
							String coreGrpMembersQry = "select i_all_users_names from dm_group where group_name='" + idocsProperties.getProperty("MSG_IFC_CORE_GROUP") + "'";
							//String coreGrpMembers = getGroupMembers(coreGrpMembersQry, dfSession);
							//DfLogger.info(this,":: getRootViewStatement:: coreGrpMembers: " + coreGrpMembers, null, null);
							//bufStatement.append(coreGrpMembers);
							bufStatement.append(coreGrpMembersQry);
							bufStatement.append(" )");
						}
					}else if (strObjectType != null 
							&& strObjectType.equals(IDocsConstants.MSG_IDOCS_COUNTRY_DOC)){

						bufStatement.append(" AND a.group_name IN ('"+idocsProperties.getProperty("MSG_IFC_CORE_GROUP")+"')");
					}else{	        	
						DfLogger.info(this,"getRootViewStatement:: Document doesnt belongs to any above types" ,null,null);
					}
					String appendQry = getPresetEntriesAsQueryString();
					if(appendQry != null && appendQry.length() > 0)
					{
						bufStatement.append(" ");
						bufStatement.append("AND");
						bufStatement.append(" ");
						bufStatement.append("a.group_name in");
						bufStatement.append(" ");
						bufStatement.append(appendQry);
					}
				}
			}

			if(getViewDocbaseType().equals("dm_user")) {
				setFromClause("dm_user a");
				setBaseViewExpression(new ParsedExpression("a.r_is_group=0"));
				processNameStartsWith("a.user_name");
				if(fUnion)
					bufStatement.append(" union ");
				setUserSelectAttributes();
				bufStatement.append("SELECT").append(" ").append(getSelectForPermitSnippet()).append(" ").append(getSelectType()).append(" ");
				bufStatement.append(prepareSelectValuesSnippet());
				bufStatement.append(" ").append("FROM").append(" ");
				bufStatement.append(getFromClause());
				bufStatement.append(" ");
				bufStatement.append(prepareWhereClauseSnippet());
				if (m_isIOMeditPerformers == false) {
					DfLogger.info(this, ":: getRootViewStatement::dfSession Session Login User : " + dfSession.getLoginUserName(), null, null);

					// Query is updated to get proper list of users custom
					// Fetch users from table project_team
					String strObjectType =  IDocDocbaseAttributeTagUtility.getSysObjectAttribute(dfSession, m_documentId, IdocsConstants.R_OBJECT_TYPE);
					DfLogger.info(this,"Value of Object type "+strObjectType,null,null);
					if(strObjectType != null 
							&& strObjectType.equals(IDocsConstants.MSG_IDOCS_PROJECT_DOC)){	  
						String strProjectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(dfSession,  m_documentId, IdocsConstants.PROJ_ID, IDocsConstants.MSG_IDOCS_PROJECT_DOC);
						if(m_roleType.equals("project_members")){
							DfLogger.info(this,"Value of Role type "+m_roleType,null,null);
							bufStatement.append(" AND a.user_name IN (");
							String projTeamMemQry = idocsProperties.getProperty("QRY_PROJ_TEAM_MEMBER_DISCUSSION").replaceFirst("''","'"+strProjectId+"'");
							DfLogger.info(this," :: getRootViewStatement: projTeamMemQry:  " + projTeamMemQry,null,null);
							String projTeamMemQryValues = getProjTeamMembers(dfSession, projTeamMemQry);
							DfLogger.info(this, ":: getRootViewStatement: projTeamMemQryValues: " + projTeamMemQryValues, null, null);
							bufStatement.append(projTeamMemQryValues);
							bufStatement.append(" )");
						}else{
							bufStatement.append(" AND a.user_name IN (");
							String projGroupMemQry = idocsProperties.getProperty("QRY_PROJ_GROUP_MEMBER").replaceFirst("''","'"+strProjectId+"'").replaceFirst("''","'"+m_roleType+"'");
							DfLogger.info(this," :: getRootViewStatement: projTeamMemQry:  " + projGroupMemQry,null,null);
							String projGroupMemQryValues = getProjTeamMembers(dfSession, projGroupMemQry);
							DfLogger.info(this, ":: getRootViewStatement: projTeamMemQryValues: " + projGroupMemQryValues, null, null);
							bufStatement.append(projGroupMemQryValues);
							bufStatement.append(" )");
						}
					}else if(strObjectType != null 
							&& strObjectType.equals(IDocsConstants.MSG_IDOCS_INSTITUTION_DOC)){
						String strInstiRoleType = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(dfSession,  m_documentId, IdocsConstants.MSG_INSTITUTION_ROLE_TYPE_CODE, IDocsConstants.MSG_IDOCS_INSTITUTION_DOC);
						DfLogger.info(this,"Value of Institution Role type "+strInstiRoleType,null,null);     		
						if(strInstiRoleType!=null && strInstiRoleType.trim().length() > 0 
								&& strInstiRoleType.equals(IDocsConstants.MSG_INTITUTION_CLIENT_ROLE)){
							String strInstitutionNumber = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(dfSession,  m_documentId, IdocsConstants.MSG_INSTITUTION_NBR, IDocsConstants.MSG_IDOCS_INSTITUTION_DOC);
							DfLogger.info(this,"Value of Institution Number "+strInstitutionNumber,null,null);
							String frameClientProjects = idocsProperties.getProperty("QRY_CLIE_INSTI_PROJECTS").replaceFirst("''", strInstitutionNumber);
							bufStatement.append(" AND a.user_name IN (");
							String projTeamMemMultiQry = idocsProperties.getProperty("QRY_PROJ_TEAM_MEMBER_MULTI_DISCUSSION").replaceFirst("''",frameClientProjects);
							DfLogger.info(this," :: getRootViewStatement: projTeamMemMultiQry:  " + projTeamMemMultiQry,null,null);
							String projTeamMemMultiValues = getProjTeamMembers(dfSession, projTeamMemMultiQry);
							DfLogger.info(this, ":: getRootViewStatement: projTeamMemMultiValues: " + projTeamMemMultiValues, null, null);
							bufStatement.append(projTeamMemMultiValues);
							bufStatement.append(" )");
						}else{	        			
							bufStatement.append(" AND a.user_name IN (");
							String coreGrpMembersQry = "select i_all_users_names from dm_group where group_name='" + idocsProperties.getProperty("MSG_IFC_CORE_GROUP") + "'";
							//String coreGrpMembers = getGroupMembers(coreGrpMembersQry, dfSession);
							//DfLogger.info(this,":: getRootViewStatement:: coreGrpMembers: " + coreGrpMembers, null, null);
							//bufStatement.append(coreGrpMembers);
							bufStatement.append(coreGrpMembersQry);
							bufStatement.append(" )");
						}
					}else if (strObjectType != null 
							&& strObjectType.equals(IDocsConstants.MSG_IDOCS_COUNTRY_DOC)){
						bufStatement.append(" AND a.user_name IN (");
						String coreGrpMembersQry = "select i_all_users_names from dm_group where group_name='" + idocsProperties.getProperty("MSG_IFC_CORE_GROUP") + "'";
						//String coreGrpMembers = getGroupMembers(coreGrpMembersQry, dfSession);
						//DfLogger.info(this,":: getRootViewStatement:: coreGrpMembers: " + coreGrpMembers, null, null);
						//bufStatement.append(coreGrpMembers);
						bufStatement.append(coreGrpMembersQry);
						bufStatement.append(" )");
					}else{	        	
						DfLogger.info(this,"Document doesnt belongs to any above types" ,null,null);
					}
					String appendQry = getPresetEntriesAsQueryString();
					DfLogger.info(this,":: getRootViewStatement:: appendQry: " + appendQry, null, null);
					if(appendQry != null && appendQry.length() > 0)
					{
						bufStatement.append(" ");
						bufStatement.append("AND");
						bufStatement.append(" ");
						bufStatement.append("a.user_name IN (Select i_all_users_names from dm_group where group_name in ");
						bufStatement.append(appendQry);
						bufStatement.append(")");
					}
					/*if(!getShowUnlistedUsers())
						bufStatement.append(" AND  a.user_name NOT IN (");
	            		String dceHiddenUsersQry = "select i_all_users_names from dm_group where group_name='dce_hidden_users'";
	            		String dceHiddenUsers = getGroupMembers(dceHiddenUsersQry, dfSession);
	            		DfLogger.info(this,":: getRootViewStatement:: dceHiddenUsers: " + dceHiddenUsers, null, null);
	            		bufStatement.append(dceHiddenUsers);
	            		bufStatement.append(" )");*/
				} else {
					bufStatement.append(" AND  a.user_name in (select i_all_users_names from dm_group where group_name='ifc_core_grp')");
				}
			}

			removeAllOrderByAttributes();
			addOrderByAttribute("idunion", "ASC");
			addOrderByAttribute("objname", "ASC");
			bufStatement.append(" ");
			bufStatement.append(prepareOrderBySnippet());

		} catch (DfIdentityException e) {
			DfLogger.error(this," :: UserOrGroupLocatorQuery :: getRootViewStatement : "+e.getMessage(),null,null);
		} catch (DfAuthenticationException e) {
			DfLogger.error(this," :: UserOrGroupLocatorQuery :: getRootViewStatement : "+e.getMessage(),null,null);
		} catch (DfPrincipalException e) {
			DfLogger.error(this," :: UserOrGroupLocatorQuery :: getRootViewStatement : "+e.getMessage(),null,null);
		} catch (DfServiceException e) {
			DfLogger.error(this," :: UserOrGroupLocatorQuery :: getRootViewStatement : "+e.getMessage(),null,null);
		} catch (DfException e) {
			DfLogger.error(this," :: UserOrGroupLocatorQuery :: getRootViewStatement : "+e.getMessage(),null,null);
		} catch (IOException e) {
			DfLogger.error(this," :: UserOrGroupLocatorQuery :: getRootViewStatement : "+e.getMessage(),null,null);
		}
		DfLogger.info(this,":: getRootViewStatement:: bufStatement.toString(): " + bufStatement.toString(),null,null);
		return bufStatement.toString();
	}


	private String getProjTeamMembers(IDfSession dfSession,	String projTeamMemQry) {
		
		String projTeamMemQryValues="'";
		IDfCollection projTeamMemQryColl = null;
		try {
			projTeamMemQryColl = IdocsUtil.executeQuery(dfSession, projTeamMemQry, IDfQuery.DF_READ_QUERY);
			while (projTeamMemQryColl.next()) {
				projTeamMemQryValues = projTeamMemQryValues + IdocsUtil.handleSingleQuote(projTeamMemQryColl.getString("accessor_nme"))+"','";
			}
			if (projTeamMemQryValues.length() > 1) {
				projTeamMemQryValues = projTeamMemQryValues.substring(0, (projTeamMemQryValues.length()-2));
			} else {
				projTeamMemQryValues = projTeamMemQryValues + "'";
			}
		} catch (Exception e) {
			DfLogger.error(this," :: getProjTeamMembers :: Exception : "+e.getMessage(),null,null);
		} finally {
			try {
				if (projTeamMemQryColl!= null) projTeamMemQryColl.close();
			} catch (DfException e) {
				DfLogger.error(this," :: getProjTeamMembers :: Exception : Unable to close collection" + e.getMessage(), null, null);
			}
		}
		DfLogger.info(this," :: getProjTeamMembers: projTeamMemQryValues:  " + projTeamMemQryValues,null,null);
		return projTeamMemQryValues;
	}

	/**
     * 
     * @param grpMembersQry
     * @param dfSession
     * @return
     */
    private String getGroupMembers(String grpMembersQry,
			IDfSession dfSession) {
    	
		String groupMembers = "'";
		IDfCollection grpMembersQryColl = null;
		DfLogger.info(this," :: getGroupMembers: grpMembersQry:  " + grpMembersQry,null,null);
		try {
			grpMembersQryColl = IdocsUtil.executeQuery(dfSession, grpMembersQry, IDfQuery.DF_READ_QUERY);
			while (grpMembersQryColl.next()) {
				String userOfGroup = IdocsUtil.handleSingleQuote(grpMembersQryColl.getString("i_all_users_names"));
				groupMembers = groupMembers + userOfGroup +"','";
			}
			if (groupMembers.length() > 1) {
				groupMembers = groupMembers.substring(0, (groupMembers.length()-2));
			} else {
				groupMembers = groupMembers + "'";
			}
		} catch (DfException e) {
			DfLogger.error(this, " :: getGroupMembers:: Exception  " + e.getMessage(), null, null);
		} finally {
			if (grpMembersQryColl!= null){ 
				try {
					grpMembersQryColl.close();
				} catch (DfException e) {
					DfLogger.error(this, " :: getGroupMembers:: Exception :: Unable to close collection" + e.getMessage(), null, null);
				}
			}			
		}
		DfLogger.info(this," :: getGroupMembers: groupMembers:  " + groupMembers,null,null);
		return groupMembers;
	}
	protected String getGroupNameExpression(String fromGroupSymbol) {
		StringBuffer rv = new StringBuffer();
		if(fromGroupSymbol != null && fromGroupSymbol.length() != 0) {
			rv.append(fromGroupSymbol);
			rv.append(".");
		}
		rv.append((new StringBuilder()).append("group_name = '").append(getGroupName()).append("'").toString());
		return rv.toString();
	}

	protected String getGroupBaseExpression() {
		return (new StringBuilder()).append("exists (select * from dm_group b where ").append(getGroupNameExpression("b")).append(" and any b.groups_names = a.group_name)").toString();
	}

	protected String getUserBaseExpression() {
		return (new StringBuilder()).append("exists (select * from dm_group b where ").append(getGroupNameExpression("b")).append(" and any b.users_names = a.user_name) ").toString();
	}

	protected String getContainerViewStatement() {
		boolean fUnion = false;
		StringBuffer bufStatement = new StringBuffer(512);
		if (m_isIOMeditPerformers == false) {
			if(!isTypeExcluded("dm_group")) {
				fUnion = true;
				setFromClause("dm_group a");
				String strBaseExpression = "";
				if(!isPrivateGroupVisible())
					strBaseExpression = "(a.is_private=0 or a.owner_name=user) and ";
				if(m_fIs53Docbase && !isWorkQueueGroupVisible())
					strBaseExpression = (new StringBuilder()).append(strBaseExpression).append("(a.group_class IS NULL OR a.group_class!='queue') and ").toString();
				strBaseExpression = (new StringBuilder()).append(strBaseExpression).append(getGroupBaseExpression()).toString();
				setBaseViewExpression(new ParsedExpression(strBaseExpression));
				processNameStartsWith("a.group_name");
				setGroupSelectAttributes();
				bufStatement.append("SELECT").append(" ").append(getSelectForPermitSnippet()).append(" ").append(getSelectType()).append(" ");
				bufStatement.append(prepareSelectValuesSnippet());
				bufStatement.append(" ").append("FROM").append(" ");
				bufStatement.append(getFromClause());
				bufStatement.append(" ");
				bufStatement.append(prepareWhereClauseSnippet());
			}
		}
		
		if(getViewDocbaseType().equals("dm_user")) {
			setFromClause("dm_user a");
			String strBaseExpression = "";
			if(!isPrivateGroupVisible())
				strBaseExpression = "a.r_is_group=0 and ";
			strBaseExpression = (new StringBuilder()).append(strBaseExpression).append(getUserBaseExpression()).toString();
			setBaseViewExpression(new ParsedExpression(strBaseExpression));
			processNameStartsWith("a.user_name");
			if(fUnion)
				bufStatement.append(" union ");
			setUserSelectAttributes();
			bufStatement.append("SELECT").append(" ").append(getSelectForPermitSnippet()).append(" ").append(getSelectType()).append(" ");
			bufStatement.append(prepareSelectValuesSnippet());
			bufStatement.append(" ").append("FROM").append(" ");
			bufStatement.append(getFromClause());
			bufStatement.append(" ");
			bufStatement.append(prepareWhereClauseSnippet());
		}
		removeAllOrderByAttributes();
		addOrderByAttribute("idunion", "ASC");
		addOrderByAttribute("objname", "ASC");
		bufStatement.append(" ");
		bufStatement.append(prepareOrderBySnippet());
		return bufStatement.toString();
	}

	protected String getFlatListViewStatement() {
		return getRootViewStatement();
	}

	protected String getGroupName() {
		String strGroup = m_strFolderPath;
		int iSlash = m_strFolderPath.lastIndexOf('/');
		if(iSlash >= 0)
			strGroup = m_strFolderPath.substring(iSlash + 1);
		return DfUtil.escapeQuotedString(strGroup);
	}

	protected void setGroupSelectAttributes() {
		if (m_isIOMeditPerformers == false) {
			addSelectValue("1", "idunion");
			addSelectValue("upper(a.group_name)", "objname");
			addSelectValue("a.group_name", "object_name");
			addSelectValue("a.group_address", "address_");
			addSelectValue("a.description", null);
			addSelectValue("a.r_modify_date", null);
			addSelectValue("a.r_object_id", null);
			addSelectValue("'dm_group'", IDocsConstants.MSG_R_OBJECT_TYPE);
			addSelectValue("''", "user_os_name");
			addSelectValue("a.owner_name", "owner_name");
			addSelectValue("-1", "workflow_disabled");
			if(!isContainerSelectable())
				addSelectValue("''", "selectable");
			else
				addSelectValue("'y'", "selectable");
			if(isFlatListEnabled()) {
				addSelectValue("''", "navigatable");
				addSelectValue("'y'", "notnavigatable");
			} else {
				addSelectValue("'y'", "navigatable");
				addSelectValue("''", "notnavigatable");
			}
		}
		
	}

	protected void setUserSelectAttributes() {

		addSelectValue("2", "idunion");
		addSelectValue("upper(a.user_name)", "objname");
		addSelectValue("a.user_name", "object_name");
		addSelectValue("a.user_address", "address_");
		addSelectValue("a.description", null);
		addSelectValue("a.r_modify_date", null);
		addSelectValue("a.r_object_id", null);
		addSelectValue("'dm_user'", IDocsConstants.MSG_R_OBJECT_TYPE);
		addSelectValue("a.user_os_name", "user_os_name");
		addSelectValue("''", "owner_name");
		addSelectValue("a.workflow_disabled", "workflow_disabled");
		addSelectValue("'y'", "selectable");
		addSelectValue("''", "navigatable");
		addSelectValue("'y'", "notnavigatable");
	}
}


