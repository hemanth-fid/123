/**
* Error handler component class is used to provide errorhandling for workflowstatus.
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* CVattathara			10/14/2010		1.0					created
* #######################################################################################################
*/
package org.ifc.idocs.workflow;

import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.Button;
import com.documentum.web.formext.component.Component;

public class ErrorHandler extends Component
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param args
	 */
	public void onInit(ArgumentList args) {
		try {
			DfLogger.info(this, " :: onInit : "+getDfSession().getLoginUserName(), null, null);
		} catch (DfException e) {
			DfLogger.error(this, " :: onInit Exception >> "+e.getMessage(), null, e);
		}	
	}
	
    //OK button on the message window
    public void onClose(Button control, ArgumentList args)
    {
    	try {
	    	DfLogger.info(this, " :: onClose : "+getDfSession().getLoginUserName(), null, null);
	    	setComponentReturnJump("objectlist", getContext());
    	} catch(Exception e) {
    		DfLogger.error(this, " :: onClose Exception >> "+e.getMessage(), null, e);
    	}
    }
}
