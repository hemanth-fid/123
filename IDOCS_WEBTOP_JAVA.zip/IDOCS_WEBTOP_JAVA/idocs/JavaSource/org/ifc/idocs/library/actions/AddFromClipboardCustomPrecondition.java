/**
* This precondition class is provide the status of virtual Document. 
* #######################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created
* #######################################################################
*/
package org.ifc.idocs.library.actions;

import org.ifc.idocs.constants.IDocsConstants;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.action.IActionPrecondition;
import com.documentum.web.formext.clipboard.IClipboard;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

public class AddFromClipboardCustomPrecondition implements IActionPrecondition{
	public AddFromClipboardCustomPrecondition(){
	}
	
	public String[] getRequiredParams(){
		return null;
	}

    /**
     * 
     */
    public boolean queryExecute(String strAction, IConfigElement config,
		ArgumentList arg, Context context, Component component){
    	boolean bExecute = false;
	    IDfSession dfSession = component.getDfSession();
        String strObjectId = arg.get("objectId");
        String isVirtualDoc = arg.get("isVirtualDoc");
		if(strObjectId !=  null && strObjectId.trim().length() > 0 
				&& strObjectId.startsWith(IDocsConstants.MSG_DM_DOC_TYPE_PREF_CODE)
				&& (IDocsConstants.MSG_ONE.equalsIgnoreCase(isVirtualDoc) == true
						|| Boolean.TRUE.toString().equalsIgnoreCase(isVirtualDoc) == true)){
			IClipboard clipboard = component.getClipboard();
            if(clipboard.hasItems()){
                try{
                    String docbase = dfSession.getDocbaseName();
                    boolean clipboardItemsFromSameDocbase = true;
                    String clipboardItemIds[] = clipboard.getItemIds();
                    int index = 0;
                    do{
                    	if(index >= clipboardItemIds.length){
                            break;
                        }
                        String itemId = clipboardItemIds[index];
                        String clipboardItemDocbase = clipboard.getDocbaseForItem(itemId);
                        if(!docbase.equals(clipboardItemDocbase)){
                            clipboardItemsFromSameDocbase = false;
                            break;
                        }
                        index++;
                    } while(true);
                    if(clipboardItemsFromSameDocbase){
                        bExecute = true;
                    }
                }catch(DfException e) {
        			DfLogger.error(this, " :: queryExecute Ignore Exception >> "+e.getMessage(), null, e);
                }
            }
		}
	    return bExecute;
	 }
}