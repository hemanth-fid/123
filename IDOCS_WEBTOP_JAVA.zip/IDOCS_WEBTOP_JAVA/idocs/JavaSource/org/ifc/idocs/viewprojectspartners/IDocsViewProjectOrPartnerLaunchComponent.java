package org.ifc.idocs.viewprojectspartners;

import java.util.Map;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.form.Form;
import com.documentum.web.formext.action.LaunchComponent;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.webtop.app.ApplicationNavigation;

public class IDocsViewProjectOrPartnerLaunchComponent extends LaunchComponent {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6306934905873499642L;
	private static final String QRY_FOLDER_TYPE_ID="QRY_FOLDER_TYPE_ID";
	private static final String QRY_FOLDER_TYPE="QRY_FOLDER_TYPE";
	public String foldertype=null;
	
    public boolean execute(String strAction, IConfigElement config, ArgumentList args, Context context, Component component, Map completionArgs)
    {
    	String strFolderObjID=args.get("objectId");
    	String strFolderPath =  args.get("folderPath");
    	String projectPartnerRelationType= null;
    	String STR_PROJ_INSTIT_QRY = null;
    	String strgetdocfolderType=null;
    	DfLogger.debug(this,"on Render of ViewProjectsOrPartners component..",null,null);
    	try{
    		if(strFolderObjID.startsWith(IDocsConstants.MSG_DM_DOC_TYPE_PREF_CODE)){
    			DfLogger.debug(this,"Document",null,null);
    			DfLogger.debug(this,"Document ID : "+strFolderObjID,null,null);
    			DfLogger.debug(this,"Folder Path : "+strFolderPath,null,null);
    			strgetdocfolderType= IdocsUtil.getMessage(QRY_FOLDER_TYPE_ID);
    			strgetdocfolderType=strgetdocfolderType.replace("''","'"+strFolderObjID+"'");
    			IDfCollection folderIdCollection =executeQuery(strgetdocfolderType,component.getDfSession());
    			if(folderIdCollection.next()) {
    				strFolderObjID=folderIdCollection.getString("i_folder_id");
    				}
    			if(folderIdCollection != null )
    				folderIdCollection.close();
    			}
    		Component componentLocation = null;
            String strComponentLocation = config.getChildValue("location");
    		if(strComponentLocation != null && strComponentLocation.equalsIgnoreCase("parentcomponent"))
            {
                Object componentParent = component.getContainer();
                if(componentParent != null && (componentParent instanceof Component))
                    componentLocation = (Component)componentParent;
            }
            if(componentLocation == null)
            {
                Form topForm = component.getTopForm();
                if(topForm != null && (topForm instanceof Component))
                    componentLocation = (Component)topForm;
            }
    		DfLogger.debug(this,"ViewProjectsOrPartners : Folder object ID : " +strFolderObjID,null,null);    
    		//Get folder type using folder id
			String strQrygetfolderType= IdocsUtil.getMessage(QRY_FOLDER_TYPE);
			strQrygetfolderType=strQrygetfolderType.replace("''","'"+strFolderObjID+"'");
			IDfCollection folderCollection = executeQuery(strQrygetfolderType,component.getDfSession());
			if(folderCollection.next()) {
				foldertype=folderCollection.getString(IdocsConstants.R_OBJECT_TYPE);
			}
			if(folderCollection != null )
				folderCollection.close();
	        DfLogger.debug(this,"Folder Category :" +foldertype,null,null);         
    		
    			
    		STR_PROJ_INSTIT_QRY = getQuery(strFolderObjID,foldertype);  
	    	DfLogger.debug(this," onRender : STR_PROJ_INSTIT_QRY :"+STR_PROJ_INSTIT_QRY,null,null);
		   	projectPartnerRelationType=isSingletonRelationship(strFolderObjID,foldertype,component.getDfSession());
			DfLogger.debug(this," onRender : Singleton relationship :"+projectPartnerRelationType,null,null);

			/**
			 * Check the query Result if its not null pass SetComponent Return Jump. else setcomponentJump to avoid error
			 * @ TODO Investigate
			 */
			if(projectPartnerRelationType != null && projectPartnerRelationType.trim().length() >0){
    			ArgumentList argsSearch = new ArgumentList();
    	    	argsSearch.add(IdocsConstants.MSG_FOLDERID, projectPartnerRelationType);
    	    	ApplicationNavigation.navigateToFolderId(component, projectPartnerRelationType);
    		}else{
    			ArgumentList argsSearch = new ArgumentList();
		    	argsSearch.add(IdocsConstants.SEARCH_QRYTYPE_ARG_NME, IdocsConstants.DQL_QRYTYPE);
		    	argsSearch.add(IdocsConstants.SEARCH_QRY_ARG_NME, STR_PROJ_INSTIT_QRY);
		    	componentLocation.setComponentJump(IdocsConstants.CUSTOM_SEARCH, argsSearch, context);
		    		
    	  }
    	}catch (Exception e) {
    		DfLogger.error(this," ViewProjectsOrPartners : Exception :"+e.getMessage(),null,e);
    		e.printStackTrace();
		}  
    	
        return false;
    }
    
    /**
	 * This method returns the DQL Query which will be used to fetch the client company/project folders
	 * @param strFolderObjID
	 * @param validInstitFolderFlag 
	 * @param validProjFolderFlag 
	 * @return dqlQry
	 */
	public String getQuery(String strFolderObjID,String typeofFolder){
		String dqlQry = null;
		DfLogger.debug(this,"Inside getQuery method",null,null);
		if(typeofFolder !=null && typeofFolder.trim().length() > 0){
			if(typeofFolder.equals(IDocsConstants.MSG_IDOCS_INSTIT_FOLDER)){
				dqlQry = IdocsUtil.getMessage(IdocsConstants.PROJECT_FOLDER_QRY);
			}else if(typeofFolder.equals(IDocsConstants.MSG_IDOCS_PROJ_FOLDER)){
				dqlQry = IdocsUtil.getMessage(IdocsConstants.CLIENT_COMPANY_FOLDER_QRY);
			}
		}
		dqlQry = dqlQry.replaceFirst("''", "'"+strFolderObjID+"'");		
		DfLogger.debug(this,": getQuery :DQL Query : : : "+dqlQry,null,null);
		return dqlQry;
	} 
	
	/**
	 * This utility method is to find whether the Partner Project Relationship is 1 TO 1 or not.
	 * If there is only one result that method shall be returning the Resultant Project/Partner ID.
	 * And if there are multiple results null will be returned. 
	 * @param strFolderObjID - Current Folder Object Id
	 * @param validProjFolderFlag - Flag to indicate whether strFolderObjID belongs to a Project Folder 
	 * @param validInstitFolderFlag - Flag to indicate whether strFolderObjID belongs to a Partner Folder
	 * @return 
	 * @throws DfException
	 */
	public String isSingletonRelationship(String strFolderObjID,String typeofFolder,IDfSession dfSession) {
		String strQrygetcount=null;
		String firstResultObjectId= null;
		int count = 0;
		DfLogger.debug(this,"Inside method singletonrelationship",null,null);
		try {
			if(typeofFolder !=null && typeofFolder.trim().length() > 0){
				if(typeofFolder.equals(IdocsConstants.INSTITUTION_FOLDER_TYPE)){
					strQrygetcount = IdocsUtil.getMessage(IdocsConstants.STR_SEARCH_COUNT_PROJECT_RESULTS_QRY);
				}else if(typeofFolder.equals(IdocsConstants.PROJ_FOLDER_TYPE)){
					strQrygetcount = IdocsUtil.getMessage(IdocsConstants.STR_SEARCH_COUNT_INSTIT_RESULTS_QRY);
				}
			}
			strQrygetcount=strQrygetcount.replace("''","'"+strFolderObjID+"'");
			IDfCollection countCollection = executeQuery(strQrygetcount,dfSession);
			count = 0;
			while(countCollection.next()) {
				firstResultObjectId = countCollection.getString(IdocsConstants.R_OBJECT_ID);
				if(firstResultObjectId  != null && firstResultObjectId .trim().length()>0){
					count++;
				}
			}
			if(countCollection!=null)countCollection.close();
		} catch (DfException e) {
			e.printStackTrace();
		}
			
		if(count == 1){
			return firstResultObjectId;
		}else{
			return null;
		}
	} 
    
	private IDfCollection executeQuery(String queryString,IDfSession dfSession) throws DfException{
		IDfCollection collectionObj = null;
		DfLogger.info(this, " :: executeQuery :: queryString: " + queryString , null, null);
		IDfQuery query = new DfQuery();
		query.setDQL(queryString);		
		collectionObj = query.execute(dfSession, DfQuery.EXECREAD_QUERY);
		return collectionObj;
	}

}
