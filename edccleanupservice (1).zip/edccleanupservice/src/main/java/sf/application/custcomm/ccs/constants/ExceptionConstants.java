/***************************************************************************
 * State Farm
 * Version Template: 2012
 *
 * File Name: ExceptionConstants.java
 *
 * Version     ChgDate          Author           Comments
 * ________   __________       ________         ___________
 * 1.0        03/19/2013         t1or         Initial Creation 
 *
 ***************************************************************************/

package sf.application.custcomm.ccs.constants;
/**
 * <i>ExceptionConstants</i> contains all the exception messages as constants
 * that are commonly used in export process components
 * 
 */
public final class ExceptionConstants {

	/**
	 * private Constructor
	 */
	private ExceptionConstants() {

	}

	
	public static final String ERROR_WHILE_LOADING_PROPERTIES = "Error occured while decrypting the password.";
	public static final String UNABLE_TO_GET_SESSION = "Unable to get session";
	public static final String ERROR_IN_READING_PROPERTIES = "Error while reading property file";
	public static final String ERROR_IN_RETRIEVING_OBJECTS = "Error in retrieving objects";
	public static final String ERROR_IN_CREATE_FILES_SERVICE = "Error in creating file service";
	public static final String ERROR_IN_RETRIEVING_QUERY_COUNT = "Error in retrieving query count";
	public static final String ERROR_WHILE_WRITING_CONTENT = "Unable to write the object's content to the file";
	public static final String ERROR_WHILE_CREATING_DIRECTORY = "Error While creating directory" ;
}
