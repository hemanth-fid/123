/**
* This class to process the workflow document.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created
* #######################################################################################################
*/
package org.ifc.idocs.workflow.processdiagram;

import com.documentum.bpm.IDfProcessEx;
import com.documentum.bpm.utils.ExecutionDataHelper;
import com.documentum.bpm.utils.ProcessDesignManager;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfActivity;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfGroup;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfWorkitem;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import org.ifc.idocs.utils.IdocsConstants;

import org.ifc.idocs.workflow.processdiagram.DashboardEnv;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.dom4j.Attribute;
import org.dom4j.DocumentFactory;
import org.dom4j.Element;

import org.ifc.idocs.utils.IdocsUtil;

public class Process extends SvgParams
{
	private static final String DORMANT = "dormant";
	private static final String STRING_QUOTES_COMMA = "',";
	private static final String EMPTY_STRING = "";
	private static final String QRY_ACTIVITY_EXEC_TYPE = "QRY_ACTIVITY_EXEC_TYPE";
	private static final String EXEC_TYPE = "exec_type";
	private static final String OBJECT_NAME = "object_name";
	private static final String PROCESS_ID = "process_id";
	private static final String REGEX_SINGLE_QUOTES = "'";
	private static final String REGEX_DOUBLE_QUOTES = "''";
	public String Id;
	public String instanceId;
	public String name;
	public String startDateTime;
	public String endDateTime;
	public String svgWidth;
	public String svgHeight;
	public String svgViewType;
	public String svgLocation;
	public String svgContent;
	public String contentTypeRequired;
	public String svgError = EMPTY_STRING;
	public boolean refresh = false;
	public boolean error = false;
	public boolean empty = false;
	public Map activityInstances;
	public boolean subProcess = false;
	public String subProcessName = EMPTY_STRING;
	public String parentId;
	public String parentInstanceId;
	public String parentProcessName;
	public String processXmlInfo;

	IdocsUtil idocs_util = null;
	public String getId()
	{
		return this.Id;
	}

	public void setId(String paramString)
	{
		this.Id = paramString;
	}

	public String getInstanceId()
	{
		return this.instanceId;
	}

	public void setInstanceId(String paramString)
	{
		this.instanceId = paramString;
	}

	public String getName()
	{
		return this.name;
	}

	public void setName(String paramString)
	{
		this.name = paramString;
	}

	public String getStartDateTime()
	{
		return this.startDateTime;
	}

	public void setStartDateTime(String paramString)
	{
		this.startDateTime = paramString;
	}

	public String getEndDateTime()
	{
		return this.endDateTime;
	}

	public void setEndDateTime(String paramString)
	{
		this.endDateTime = paramString;
	}

	public Map getActivities()
	{
		return this.activityInstances;
	}
	public void setActivities(Map paramMap)
	{
		this.activityInstances = paramMap;
	}

	public String getSvgWidth()
	{
		return this.svgWidth;
	}

	public void setSvgWidth(String paramString)
	{
		this.svgWidth = paramString;
	}

	public String getSvgHeight()
	{
		return this.svgHeight;
	}

	public void setSvgHeight(String paramString)
	{
		this.svgHeight = paramString;
	}

	public String getSvgLocation()
	{
		return this.svgLocation;
	}

	public void setSvgLocation(String paramString)
	{
		this.svgLocation = paramString;
	}

	public Process(){
		try{
			idocs_util = new IdocsUtil();
		}catch(Exception localException){
			DfLogger.error(this," :: Process Exception >> " + localException.getMessage(), null, localException);
		}
	}


	public String getProcessXmlInfo()
	{
		org.dom4j.Document localDocument = DocumentFactory.getInstance().createDocument();
		Element localElement = localDocument.addElement("process");
		localElement.addAttribute("id", this.Id).addAttribute("instanceId", this.instanceId).addAttribute("name", this.name).addAttribute("svgLocation", this.svgLocation).addAttribute("startDateTime", this.startDateTime).addAttribute("endDateTime", this.endDateTime).addAttribute("svgWidth", this.svgWidth).addAttribute("svgHeight", this.svgHeight).addAttribute("svgViewType", this.svgViewType);
		this.processXmlInfo = localElement.getDocument().asXML();
		DfLogger.info(this," :: getProcessXmlInfo : processXmlInfo : "+this.processXmlInfo,null,null);
		return this.processXmlInfo;
	}


	public void setProcessXmlInfo(String paramString)
	{
		this.processXmlInfo = paramString;
	}


	protected org.dom4j.Document getProcessXmlDefinition(IDfSession dfSession)
	throws Exception
	{
		return getProcessXmlDefintion(dfSession);
	}


	public org.dom4j.Document appendExcutionDataXml(IDfSession dfSession) {
		org.dom4j.Document objDocument = null;
		try {
			DfLogger.info(this," :: appendExcutionDataXml : instanceId : " + this.instanceId,null,null);
			org.dom4j.Document localDocument = getProcessXmlDefinition(dfSession);
			if ((this.instanceId == null) || (this.instanceId.equals(EMPTY_STRING)))
				return localDocument;
			Element localElement1 = localDocument.getRootElement();

			localElement1.add(getExecutionDataFromProcessConsole(dfSession).getRootElement());

			objDocument = updateImage(localElement1.getDocument());
			DfLogger.info(this," :: appendExcutionDataXml : objDocument : " + objDocument,null,null);
		} catch (Exception e) {
			DfLogger.error(this, " :: appendExcutionDataXml Exception>>>>  " + e.getMessage(), null, null);
		}
		return objDocument;
	}
	private org.dom4j.Document updateImage(org.dom4j.Document objDocument){
		String strNodeId =EMPTY_STRING;
		String strNodeStatus = EMPTY_STRING;
		String strImageURL=EMPTY_STRING;
		String strActivityExecType=EMPTY_STRING;
		String strActivityId= EMPTY_STRING;
		Attribute attrIcon = null;
		Attribute attrImageURL = null;
		String strTempURL=EMPTY_STRING;
		HashMap objInstance = new HashMap();
		List listInstance = objDocument.selectNodes("//instance" );
		Iterator iterInstance=listInstance.iterator();

		while(iterInstance.hasNext()){
			Element elementInstance=(Element)iterInstance.next();
			strNodeId= elementInstance.attributeValue("nodeId");
			strNodeStatus= elementInstance.attributeValue("status");
			strActivityId = elementInstance.attributeValue("activityId");
			if(!objInstance.containsKey(strNodeId)){
				objInstance.put(strNodeId, strNodeStatus);
			}else{
				String strTmpStatus = (String)objInstance.get(strNodeId);
				if(strTmpStatus.equals("complete") && strNodeStatus.equals("in_progress")){
					objInstance.remove(strNodeId);
					objInstance.put(strNodeId, strNodeStatus);
				} else if(strTmpStatus.equals("complete") && strNodeStatus.equals(DORMANT)){
					objInstance.remove(strNodeId);
					objInstance.put(strNodeId, strNodeStatus);
				}
			}

		}
		List listNode = objDocument.selectNodes("//node" );
		Iterator iterNode=listNode.iterator();

		while(iterNode.hasNext()){
			Element elementNode=(Element)iterNode.next();
			strNodeId= elementNode.attributeValue("objectId");
			strActivityExecType= elementNode.attributeValue("activityExecType");
			if(objInstance.containsKey(strNodeId) && strActivityExecType.equals("0")  ){
				Iterator iterIcon=elementNode.elementIterator("icon");
				strNodeStatus = (String)objInstance.get(strNodeId);
				while(iterIcon.hasNext()){
					Element elementIcon=(Element)iterIcon.next();
					attrIcon =(Attribute)elementIcon.selectSingleNode("@name");
					attrImageURL =(Attribute)elementIcon.selectSingleNode("@imageURL"); 
					strImageURL =attrImageURL.getValue();
					int intIndex = strImageURL.lastIndexOf("/");
					strTempURL = strImageURL.substring(0, intIndex+1);
					if(strNodeStatus.equals(DORMANT)){
						attrIcon.setValue(STR_DORMANT_ACTIVITY_GIF_FILE);
						attrImageURL.setValue(strTempURL+STR_DORMANT_ACTIVITY_GIF_FILE);
					}else if(strNodeStatus.equals("in_progress")){
						attrIcon.setValue(STR_IN_PROGRESS_ACTIVITY_GIF_FILE);
						attrImageURL.setValue(strTempURL+STR_IN_PROGRESS_ACTIVITY_GIF_FILE);
					}else if(strNodeStatus.equals("complete")){
						attrIcon.setValue(STR_COMPLETED_ACTIVITY_GIF_FILE);
						attrImageURL.setValue(strTempURL+STR_COMPLETED_ACTIVITY_GIF_FILE);
					}
				}
			}
		}
		DfLogger.info(this," :: updateImage : objDocument : "+objDocument,null,null);
		return objDocument;
	}

	private org.dom4j.Document getExecutionDataFromProcessConsole(IDfSession localIDfSession)
	throws Exception
	{
		try
		{
			DfId localDfId = new DfId(this.instanceId);
			org.w3c.dom.Document localDocument = ExecutionDataHelper.getExecutionData(localIDfSession, localDfId);
			org.dom4j.Document localDocument1 = PaXMLDom4JUtil.convertW3cDocumentToDom4jDocument(localDocument);
			localDocument1 = appendPerformerName(localDocument1,localIDfSession);
			DfLogger.info(this," :: getExecutionDataFromProcessConsole : localDocument1 : "+localDocument1,null,null);
			return localDocument1;
		}
		catch (Exception localException)
		{
			DfLogger.error(this," :: getExecutionDataFromProcessConsole Exception >> "+localException.getMessage(), null, localException);
			throw new Exception(localException);
		}
	}
	public org.dom4j.Document appendPerformerName(org.dom4j.Document localDocument1,IDfSession localIDfSession){
		String strInstanceId = EMPTY_STRING;
		String strStartDateTime =EMPTY_STRING;
		String strEndDateTime =EMPTY_STRING;
		String strActivityStatus=EMPTY_STRING;
		String strPerformerName =EMPTY_STRING;
		Date objDate = null;
		String strActivitySeqNo = EMPTY_STRING;
		Attribute attrStartDateTime =null;
		Attribute attrEndDateTime = null;
		String strActivityID=EMPTY_STRING;
		IDfWorkitem objWorkItem = null;
		IDfActivity activity = null;
		List list = localDocument1.selectNodes("//executionData//instance" );
		Iterator iter=list.iterator();

		try{
			SimpleDateFormat parser = new SimpleDateFormat(IdocsConstants.STR_INPUT_TIME_PATTERN); 
			parser.setTimeZone(TimeZone.getTimeZone(STR_TIME_ZONE));
			SimpleDateFormat formatter = new SimpleDateFormat(IdocsConstants.STR_OUTPUT_TIME_PATTERN);
			while(iter.hasNext()){
				Element element=(Element)iter.next();
				strInstanceId =(String) element.attributeValue("activityInstanceId");
				strActivityID =(String) element.attributeValue("activityId");
				strActivityStatus =(String) element.attributeValue("status");
				attrEndDateTime = (Attribute)element.selectSingleNode("@endDateTime");
				strEndDateTime =attrEndDateTime.getValue();
				if(strEndDateTime != null && strEndDateTime.trim() != EMPTY_STRING){
					objDate = parser.parse(strEndDateTime);
					strEndDateTime = formatter.format(objDate);
					attrEndDateTime.setValue(strEndDateTime);
				}
				attrStartDateTime =(Attribute)element.selectSingleNode("@startDateTime");
				strStartDateTime = attrStartDateTime.getValue();
				if(strStartDateTime != null && strStartDateTime.trim() != EMPTY_STRING){
					objDate = parser.parse(strStartDateTime);
					strStartDateTime= formatter.format(objDate);
					attrStartDateTime.setValue(strStartDateTime);
				}
				if(strInstanceId != null &&  strInstanceId != EMPTY_STRING){
					objWorkItem = (IDfWorkitem)localIDfSession.getObject(new DfId(strInstanceId));

					strPerformerName = objWorkItem.getPerformerName(); 
					Integer seq = objWorkItem.getActSeqno();
					strActivitySeqNo = seq.toString();
					if(strActivityStatus.equals(DORMANT)){

						IDfGroup objGroup =null;
						String qryGroupMember =IdocsUtil.getMessage("QRY_GROUP_MEMBER");
						qryGroupMember = qryGroupMember.replaceFirst(REGEX_DOUBLE_QUOTES, REGEX_SINGLE_QUOTES+strPerformerName.trim()+REGEX_SINGLE_QUOTES);
						try{
							objGroup= (IDfGroup)localIDfSession.getObjectByQualification(qryGroupMember);
						}catch(Exception e){
							e.printStackTrace();
							objGroup= null;
						}
						activity = objWorkItem.getActivity();
						if(objGroup !=  null){
							strPerformerName = "     <BR>"+objGroup.getAllRepeatingStrings("i_all_users_names", "     <BR>");
						}
					}
				}
//				DfLogger.info(this," :: getExecutionDataFromProcessConsole : strPerformerName : "+strPerformerName,null,null);
				element.addAttribute("performerName", strPerformerName.replaceAll(REGEX_SINGLE_QUOTES, EMPTY_STRING));
//				DfLogger.info(this," :: getExecutionDataFromProcessConsole : strPerformerName : "+strPerformerName.replaceAll("'", ""),null,null);
				element.addAttribute("activitySeqNo", strActivitySeqNo);
			}

		}catch(Exception localException){
			DfLogger.error(this," :: appendPerformerName Exception >> "+localException.getMessage(), null, null);
		}
		DfLogger.info(this," :: appendPerformerName : localDocument1 : "+localDocument1,null,null);
		return localDocument1;
	}
	
	private org.dom4j.Document getProcessXmlDefintion(IDfSession localIDfSession) {
	
		org.dom4j.Document localDocument1 = null;
		try {
			ProcessDesignManager localProcessDesignManager = ProcessDesignManager.getInstance();
			DfId localDfId = new DfId(this.Id);
			String str2 = (String)DashboardEnv.getKeyValue(IdocsConstants.STR_SVG_IMAGE_ICON_LOCATION);
			String str3 = (String)DashboardEnv.getKeyValue(IdocsConstants.STR_SVG_IMAGE_ICON_LOCATION_REAL_PATH);
			org.w3c.dom.Document localDocument = localProcessDesignManager.getProcessXMLDocument(localIDfSession, localDfId, str3, str2);
			DfLogger.info(this," :: getProcessXmlDefintion :: this.Id :: " + this.Id, null, null);
			HashMap activityMap = (HashMap)localProcessDesignManager.getActNameToIdMap(this.Id); 
			localDocument1 = PaXMLDom4JUtil.convertW3cDocumentToDom4jDocument(localDocument);
			if (activityMap != null){
				DfLogger.info(this," :: getProcessXmlDefintion :: activityMap size:: " + activityMap.size(), null, null);
			}
			localDocument1 = appendActivityExecType(localDocument1,activityMap,localIDfSession);
//			DfLogger.info(this," :: getProcessXmlDefintion : localDocument1 : " + localDocument1, null, null);
		}
		catch (Exception localException){
			DfLogger.error(this," :: getProcessXmlDefintion Exception >> " + localException.getMessage(), null, null);
		}
		return localDocument1;
	}
	public org.dom4j.Document appendActivityExecType(org.dom4j.Document localDoc,HashMap  Actname,	IDfSession localIDfSession){

		Set s = Actname.keySet();
		Iterator t= s.iterator();
		HashMap temp = new HashMap(2);
		String strTempIDList = EMPTY_STRING;
		DfQuery localDfQuery = new DfQuery();
		IDfCollection localIDfCollection = null;
		String strTempID=EMPTY_STRING;
		String strActivityExecType=EMPTY_STRING;
		boolean enteredInnerIf = false;
		try
		{
			while(t.hasNext()){
				String str =(String)t.next();
				String strActivityId = (String) Actname.get(str);
				if(str != null && strActivityId != null && strActivityId !=EMPTY_STRING){
					strTempIDList = strTempIDList + REGEX_SINGLE_QUOTES + strActivityId + STRING_QUOTES_COMMA;
					enteredInnerIf = true;
				}
			}
			int size = strTempIDList.length();
			DfLogger.info(this," :: appendActivityExecType:: strTempIDList size:: " + size, null, null);
			if(enteredInnerIf){
				strTempIDList = strTempIDList.substring(0, size-1);
				DfLogger.info(this," :: appendActivityExecType:: Removing extra comma. " + strTempIDList, null, null);
			}else{
				strTempIDList=REGEX_DOUBLE_QUOTES;
				DfLogger.info(this," :: appendActivityExecType:: No extra Comma. So no removing " + strTempIDList, null, null);
			}
			String qryActivityExecType =IdocsUtil.getMessage(QRY_ACTIVITY_EXEC_TYPE);
			qryActivityExecType = qryActivityExecType.replaceFirst(REGEX_DOUBLE_QUOTES, strTempIDList.trim());
			DfLogger.info(this," :: appendActivityExecType:: qryActivityExecType " + qryActivityExecType, null, null);
			localDfQuery.setDQL(qryActivityExecType);
			localIDfCollection = localDfQuery.execute(localIDfSession, 0);
			while (localIDfCollection.next())
			{
				strActivityExecType = localIDfCollection.getString(EXEC_TYPE);
				strTempID =localIDfCollection.getString(OBJECT_NAME);
				temp.put(strTempID, strActivityExecType);
			}
			if (localIDfCollection != null) {
				localIDfCollection.close();
			}

			List list = localDoc.selectNodes("//process//nodes//node" );
			Iterator iter=list.iterator();
			while(iter.hasNext()){
				Element element=(Element)iter.next();
				strActivityExecType =(String) temp.get(element.attributeValue("name"));
				element.addAttribute("activityExecType", strActivityExecType);
			}
		}
		catch (Exception localException) {
			DfLogger.error(this," :: appendActivityExecType Exception >> "+localException.getMessage(), null, null);
		}	
		DfLogger.info(this," :: appendActivityExecType : localDoc : "+localDoc,null,null);
		return localDoc;
	}

	public String getProcessIdByInstanceId(String paramString,IDfSession localIDfSession)
	throws Exception
	{
		String str1 = "0";
		if ((paramString == null) || (paramString.equals("0")))
			return str1;
		String str2 = IdocsUtil.getMessage("QRY_PROCESS_ID");

		str2 = str2.replaceFirst(REGEX_DOUBLE_QUOTES, REGEX_SINGLE_QUOTES+paramString.trim()+REGEX_SINGLE_QUOTES);

		DfQuery localDfQuery = new DfQuery();
		IDfCollection localIDfCollection = null;
		try
		{
			localDfQuery.setDQL(str2);
			localIDfCollection = localDfQuery.execute(localIDfSession, 0);
			if (localIDfCollection.next())
			{
				str1 = localIDfCollection.getString(PROCESS_ID);
				localIDfCollection.close();
			}
			if(localIDfCollection != null)localIDfCollection.close();
		}
		catch (Exception localException)
		{
			DfLogger.error(this," :: getProcessIdByInstanceId Exception >> " + localException.getMessage(), null, null);
			throw new Exception(localException);
		}
		DfLogger.info(this," :: getProcessIdByInstanceId : str1 : "+str1,null,null);
		return str1;
	}

	public static String getRealSubprocessId(String paramString1, String paramString2)
	throws DfException
	{
		if ((paramString1 == null) || (paramString2 == null) || (paramString1.length() < 0) || (paramString2.length() < 0))
			return null;
		IDfSessionManager localIDfSessionManager = SessionManagerHttpBinding.getSessionManager();
		String str1 = SessionManagerHttpBinding.getCurrentDocbase();
		IDfSession localIDfSession = null;
		try
		{
			localIDfSession = localIDfSessionManager.getSession(str1);
			IDfProcessEx localIDfProcessEx = (IDfProcessEx)localIDfSession.getObject(new DfId(paramString1));
			String str2 = localIDfProcessEx.getActGroupIdByName(paramString2).getId();
			DfLogger.info(Process.class," :: getProcessIdByInstanceId : str2 : "+str2,null,null);
			return str2;
		}
		finally
		{
			localIDfSessionManager.release(localIDfSession);
		}
	}

	public static void printXML(org.w3c.dom.Document localDocument1){
		try{
			StringWriter stw1 = new StringWriter(); 
			Transformer serializer1 = TransformerFactory.newInstance().newTransformer(); 
			serializer1.transform(new DOMSource(localDocument1), new StreamResult(stw1)); 
		}catch (Exception e){
			DfLogger.error(Process.class," :: printXML Exception >> " + e.getMessage(), null, null);
		}
	}

	public static void printDOM4JXML(org.dom4j.Document localDocument1){
		try{
			DfLogger.info(Process.class,localDocument1.asXML(),null,null);
		}catch (Exception e){
			DfLogger.error(Process.class," :: printDOM4JXML Exception >> " + e.getMessage(), null, e);
		}
	}

	public static final String STR_DORMANT_ACTIVITY_GIF_FILE ="dormant_activity.gif";
	public static final String STR_IN_PROGRESS_ACTIVITY_GIF_FILE ="in_progress_activity.gif";
	public static final String STR_COMPLETED_ACTIVITY_GIF_FILE ="completed_activity.gif";
	public static final String STR_TIME_ZONE ="GMT";
}