package com.SWBC.model;

import java.util.Date;

public class Brm_processing_info {
	
	private String accountNumber; //account_number_iir_match
	private Date as400_post_date;
	private String comments;
	private String id;
	private Date rec_created_on;
	private Date rec_modified_on;
	private String rule_outcome;
	private String tansactionLoanSuffix; //EM_LOAN_SUFFIX
	private Date transaction_cancel_date; //EM_POL_CANCEL_DATE
	private String transaction_cov_type; //EM_COV_TYPE
	private Date transaction_doc_issue_date; //EM_TRAN_DATE
	private String transaction_id; //EM_DOC_NO
	private String transaction_loan_no; //loan_number_iir_match , TransactionLoanNo
	private String transaction_mortgagee_name; //EM_MORTGAGE_COMPANY
	private String transaction_policy_no; //EM_POLICY_NO
	
	private String transaction_policy_reason; //EM_POL_CXL_RSN
	private Date transaction_reinstatement_date; //EM_POL_REINST_DATE
	private String transaction_status; //final_decision
	private String transaction_type; //EM_POL_TRAN_CODE
	private String transactionPolicyDecision; 
	
	private Date transaction_effective_date;
	private Date transaction_expiration_date;
	private String transactionInsurer;
	
	private String transaction_impairment_code;
	private String transaction_flood_zone;
	private double transaction_coverage_amt;
	private double transaction_premium_amt;
	private double transaction_premium_net_amt;
	
	private double transaction_edi_deductible_per;
	private double transaction_non_edi_deductible_per;
	private double transaction_deductible_amt;
	
	private String transaction_operator_id;
	
	private String transaction_naic_code;
	
	private int delete_counter;
	
	
	private String policy_type;
	
	
	
	public int getDelete_counter() {
		return delete_counter;
	}
	public void setDelete_counter(int delete_counter) {
		this.delete_counter = delete_counter;
	}
	public String getPolicy_type() {
		return policy_type;
	}
	public void setPolicy_type(String policy_type) {
		this.policy_type = policy_type;
	}
	public String getTransaction_naic_code() {
		return transaction_naic_code;
	}
	public void setTransaction_naic_code(String transaction_naic_code) {
		this.transaction_naic_code = transaction_naic_code;
	}
	public String getTransactionInsurer() {
		return transactionInsurer;
	}
	public void setTransactionInsurer(String transactionInsurer) {
		this.transactionInsurer = transactionInsurer;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public Date getAs400_post_date() {
		return as400_post_date;
	} 
	public String getComments() {
		return comments;
	} 
	
	public String getId() {
		return id;
	}
	public Date getRec_created_on() {
		return rec_created_on;
	}
	public Date getRec_modified_on() {
		return rec_modified_on;
	}
	public String getRule_outcome() {
		return rule_outcome;
	}
	
	
	public String getTansactionLoanSuffix() {
		return tansactionLoanSuffix;
	}
	public Date getTransaction_cancel_date() {
		return transaction_cancel_date;
	}
	public String getTransaction_cov_type() {
		return transaction_cov_type;
	}
	public Date getTransaction_doc_issue_date() {
		return transaction_doc_issue_date;
	}
	public String getTransaction_id() {
		return transaction_id;
	}
	public String getTransaction_loan_no() {
		return transaction_loan_no;
	}
	public String getTransaction_mortgagee_name() {
		return transaction_mortgagee_name;
	}
	public String getTransaction_policy_no() {
		return transaction_policy_no;
	}
	public String getTransaction_policy_reason() {
		return transaction_policy_reason;
	}
	public Date getTransaction_reinstatement_date() {
		return transaction_reinstatement_date;
	}
	public String getTransaction_status() {
		return transaction_status;
	}
	public String getTransaction_type() {
		return transaction_type;
	}
	public String getTransactionPolicyDecision() {
		return transactionPolicyDecision;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public void setAs400_post_date(Date as400_post_date) {
		this.as400_post_date = as400_post_date;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setRec_created_on(Date rec_created_on) {
		this.rec_created_on = rec_created_on;
	}
	public void setRec_modified_on(Date rec_modified_on) {
		this.rec_modified_on = rec_modified_on;
	}
	public void setRule_outcome(String rule_outcome) {
		this.rule_outcome = rule_outcome;
	}
	public void setTansactionLoanSuffix(String tansactionLoanSuffix) {
		this.tansactionLoanSuffix = tansactionLoanSuffix;
	}
	public void setTransaction_cancel_date(Date transaction_cancel_date) {
		this.transaction_cancel_date = transaction_cancel_date;
	}
	public void setTransaction_cov_type(String transaction_cov_type) {
		this.transaction_cov_type = transaction_cov_type;
	}
	public void setTransaction_doc_issue_date(Date transaction_doc_issue_date) {
		this.transaction_doc_issue_date = transaction_doc_issue_date;
	}
	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}
	public void setTransaction_loan_no(String transaction_loan_no) {
		this.transaction_loan_no = transaction_loan_no;
	}
	public void setTransaction_mortgagee_name(String transaction_mortgagee_name) {
		this.transaction_mortgagee_name = transaction_mortgagee_name;
	}
	public void setTransaction_policy_no(String transaction_policy_no) {
		this.transaction_policy_no = transaction_policy_no;
	}
	public void setTransaction_policy_reason(String transaction_policy_reason) {
		this.transaction_policy_reason = transaction_policy_reason;
	}
	public void setTransaction_reinstatement_date(Date transaction_reinstatement_date) {
		this.transaction_reinstatement_date = transaction_reinstatement_date;
	}
	public void setTransaction_status(String transaction_status) {
		this.transaction_status = transaction_status;
	}
	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}
	public void setTransactionPolicyDecision(String transactionPolicyDecision) {
		this.transactionPolicyDecision = transactionPolicyDecision;
	}
	public Date getTransaction_effective_date() {
		return transaction_effective_date;
	}
	public void setTransaction_effective_date(Date transaction_effective_date) {
		this.transaction_effective_date = transaction_effective_date;
	}
	public Date getTransaction_expiration_date() {
		return transaction_expiration_date;
	}
	public void setTransaction_expiration_date(Date transaction_expiration_date) {
		this.transaction_expiration_date = transaction_expiration_date;
	}
	public String getTransaction_impairment_code() {
		return transaction_impairment_code;
	}
	public void setTransaction_impairment_code(String transaction_impairment_code) {
		this.transaction_impairment_code = transaction_impairment_code;
	}
	public String getTransaction_flood_zone() {
		return transaction_flood_zone;
	}
	public void setTransaction_flood_zone(String transaction_flood_zone) {
		this.transaction_flood_zone = transaction_flood_zone;
	}
	public double getTransaction_coverage_amt() {
		return transaction_coverage_amt;
	}
	public void setTransaction_coverage_amt(double transaction_coverage_amt) {
		this.transaction_coverage_amt = transaction_coverage_amt;
	}
	public double getTransaction_premium_amt() {
		return transaction_premium_amt;
	}
	public void setTransaction_premium_amt(double transaction_premium_amt) {
		this.transaction_premium_amt = transaction_premium_amt;
	}
	public double getTransaction_premium_net_amt() {
		return transaction_premium_net_amt;
	}
	public void setTransaction_premium_net_amt(double transaction_premium_net_amt) {
		this.transaction_premium_net_amt = transaction_premium_net_amt;
	}
	public double getTransaction_edi_deductible_per() {
		return transaction_edi_deductible_per;
	}
	public void setTransaction_edi_deductible_per(double transaction_edi_deductible_per) {
		this.transaction_edi_deductible_per = transaction_edi_deductible_per;
	}
	public double getTransaction_non_edi_deductible_per() {
		return transaction_non_edi_deductible_per;
	}
	public void setTransaction_non_edi_deductible_per(double transaction_non_edi_deductible_per) {
		this.transaction_non_edi_deductible_per = transaction_non_edi_deductible_per;
	}
	public double getTransaction_deductible_amt() {
		return transaction_deductible_amt;
	}
	public void setTransaction_deductible_amt(double transaction_deductible_amt) {
		this.transaction_deductible_amt = transaction_deductible_amt;
	}
	public String getTransaction_operator_id() {
		return transaction_operator_id;
	}
	public void setTransaction_operator_id(String transaction_operator_id) {
		this.transaction_operator_id = transaction_operator_id;
	}

}
