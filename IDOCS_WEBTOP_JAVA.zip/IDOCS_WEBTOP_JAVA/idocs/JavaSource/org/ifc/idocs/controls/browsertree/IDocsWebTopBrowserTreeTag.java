/**
* This is the tag library class for the custom browser tree control - IDocsWebTopBrowserTree.
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* CVattathara			09/10/2010		1.0					created
* #######################################################################################################
*/
package org.ifc.idocs.controls.browsertree;

import com.documentum.webtop.control.WebTopBrowserTreeTag;

public class IDocsWebTopBrowserTreeTag extends WebTopBrowserTreeTag
{
	private static final long serialVersionUID = 1L;

	/**
	 * This method is to return the custom browser tree control class
	 * @return Class
	 */
	protected Class getControlClass(){
		return org.ifc.idocs.controls.browsertree.IDocsWebTopBrowserTree.class;
	}
}
