package org.ifc.idocs.report.model;

import lotus.domino.NotesException;

import org.ifc.idocs.report.export.DomdocLibrary;
import org.ifc.idocs.report.export.FoldermanDb;

/**
 * @author SPankajamsadanan
 *
 */
public class DomdocRepository {

	private String serverName;
	private String foldermanPath;
	private DomdocLibrary library;
	private FoldermanDb folderman;

	/**
	 * Constructor for DomdocRepository
	 * @param initparams
	 * @throws NotesException
	 */
	public DomdocRepository(DomdocRepositoryDescriptor initparams) throws NotesException{
		this.serverName = initparams.getServername();
		this.foldermanPath = initparams.getFoldermanpath();
	}

	public FoldermanDb getFoldermanDb() throws NotesException {
		if (this.folderman == null) {
			this.folderman = new FoldermanDb(this, this.foldermanPath);
		}
		return this.folderman;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	/**
	 * recycle method recycles the library object and folderman object
	 * @throws NotesException
	 */
	public void recycle() throws NotesException {
		if (this.library != null) {
			library.recycle();
		}
		if (this.folderman != null) {
			folderman.recycle();
		}
	}

	/**
	 * getLibrary method returns the library object. create new object if current object is null
	 * @return DomdocLibrary object
	 * @throws NotesException
	 */
	public DomdocLibrary getLibrary() throws NotesException {
		if (this.library == null) {
			this.library = new DomdocLibrary(this);
		} 
		return this.library;	
	}

}
