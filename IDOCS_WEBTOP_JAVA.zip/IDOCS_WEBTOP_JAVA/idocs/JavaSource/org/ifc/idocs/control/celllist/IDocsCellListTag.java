package org.ifc.idocs.control.celllist;


import com.documentum.web.form.Control;

import com.documentum.web.form.control.databound.CellListTag;

import java.io.IOException;
import java.util.Map;
import javax.servlet.jsp.JspWriter;

import org.ifc.idocs.constants.IDocsConstants;


public class IDocsCellListTag extends CellListTag
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

    public IDocsCellListTag()
    {
        m_strFields = null;
        m_strLabels = null;
        m_strNlsids = null;
        m_strHasCustomAttr = null;
    }

    public void setFields(String strFields)
    {
        m_strFields = strFields;
    }

    public void setLabels(String strLabels)
    {
        m_strLabels = strLabels;
    }

    public void setNlsids(String strNlsids)
    {
        m_strNlsids = strNlsids;
    }

    public void setHascustomattr(String strHasCustomAttr)
    {
        m_strHasCustomAttr = strHasCustomAttr;
    }

    public void release()
    {
        super.release();
        m_strFields = null;
        m_strLabels = null;
        m_strNlsids = null;
        m_strHasCustomAttr = null;
    }

    protected Class getControlClass()
    {
        return IDocsCellList.class;
    }

    protected void setControlProperties(Control control)
    {
        super.setControlProperties(control);
        
        IDocsCellList cellList = (IDocsCellList)control;
        if(m_strFields != null && m_strFields.length() != 0)
            cellList.setFields(m_strFields);
        if(m_strLabels != null && m_strLabels.length() != 0)
            cellList.setLabels(m_strLabels);
        else
        if(m_strNlsids != null && m_strNlsids.length() != 0)
            cellList.setNlsids(m_strNlsids);
        if(m_strHasCustomAttr != null && m_strHasCustomAttr.length() != 0)
            cellList.setHasCustomAttributes(Boolean.valueOf(m_strHasCustomAttr));
    }

    protected void renderEnd(JspWriter out) throws IOException
    {
    	IDocsCellList cellList = (IDocsCellList)getControl();
        String fields[] = cellList.getFields();
        if(fields == null || fields.length == 0)
            throw new IllegalArgumentException("IDocsCellListTag requires valid 'fields' argument!");
        javax.servlet.jsp.tagext.Tag parent = findAncestorWithClass(this, com.documentum.web.form.control.databound.IDataboundControlTag.class);
        if(parent != null)
        {
            Map columnOutputMap = cellList.getCellTemplateOutputMap();
            for(int iColumnCount = 0; iColumnCount < fields.length; iColumnCount++)
            {
                String strColumn = fields[iColumnCount];
                String strOutput = (String)columnOutputMap.get(strColumn);
                if(strOutput != null)
                	if(!strColumn.equals(IDocsConstants.STR_IDOCS_CELLLIST_ATTRIBUTE))
                       out.print(strOutput);
            }

            cellList.clearCellTemplateOutputMap();
        }
    }

    protected void preStartTag()
    {
    	IDocsCellList cellList = (IDocsCellList)getControl();
        cellList.init();
        super.preStartTag();
    }

    private String m_strFields;
    private String m_strLabels;
    private String m_strNlsids;
    private String m_strHasCustomAttr;
	
}
