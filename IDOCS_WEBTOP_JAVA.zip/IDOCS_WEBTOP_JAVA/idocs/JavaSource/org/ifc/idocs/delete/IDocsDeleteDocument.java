package org.ifc.idocs.delete;

import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;
import org.ifc.idocs.workflow.IDocsWorkflowService;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfException;
import com.documentum.fc.common.IDfList;
import com.documentum.operations.IDfDeleteOperation;
import com.documentum.operations.IDfDeleteOperationInternal;
import com.documentum.operations.IDfOperationError;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.env.Trace;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.Panel;
import com.documentum.web.form.control.Radio;
import com.documentum.web.formext.docbase.ObjectCacheUtil;
import com.documentum.web.formext.docbase.VdmUtil;
import com.documentum.web.util.DfcUtils;
import com.documentum.webcomponent.common.WebComponentErrorService;
import com.documentum.webcomponent.library.messages.MessageService;
import com.documentum.webtop.webcomponent.delete.DeleteDocument;

/**
 * 
 * @author SKurian1
 *
 */
public class IDocsDeleteDocument extends DeleteDocument {

	private static final String DELETEFILEANDDESCENDENTS = "deletefileanddescendents";
	private static final String DELETEALLVERSIONS = "deleteallversions";
	private static final String MSG_RUNNING_WORKFLOW_ACTION_FAILED = "MSG_RUNNING_WORKFLOW_ACTION_FAILED";
	private static final String MSG_DELETE_SUCCESS = "MSG_DELETE_SUCCESS";
	private static final String MSG_DELETE_ERROR = "MSG_DELETE_ERROR";
	private static final String QRY_UPDATE_WORKFLOW_STATUS = "QRY_UPDATE_WORKFLOW_STATUS";
	private static final long serialVersionUID = 1L;
	private static final String MSG_DELETED = "Deleted";
	private static final String MSG_AS_WORKFLOW_CODE = "105";
	String m_strObjectId = null;
	String templateTitle = null;
	public boolean VirtualDocStatus=false;
	
	public void onInit(ArgumentList arg) {
		m_strObjectId = arg.get("objectId");
		/* Advisory Services Code : Start */
		try {
			templateTitle = IdocsUtil.getTemplateTitle(getDfSession(), m_strObjectId);
			updateASWorkflowTable(templateTitle);
		} catch (DfException e) {
			DfLogger.debug(this, " Exception occured while updating AS Workflow Table for ::"+m_strObjectId, null, null);
		}
		/* Advisory Services Code : End */
		super.onInit(arg);
		
		Radio deleteSelectedVersion = (Radio) getControl("deleteselectedversion", com.documentum.web.form.control.Radio.class);
		Radio radioDeleteAllVersions = (Radio)getControl(DELETEALLVERSIONS, Radio.class);
		Panel panelVersionOptions = (Panel)getControl("versionoptions", com.documentum.web.form.control.Panel.class);
		panelVersionOptions.setVisible(true);
		
		deleteSelectedVersion.setEnabled(true);
		deleteSelectedVersion.setVisible(true);
		deleteSelectedVersion.setValue(true);
		
		radioDeleteAllVersions.setEnabled(true);
		radioDeleteAllVersions.setVisible(true);
		radioDeleteAllVersions.setValue(false);
		
		ispartofWorkFlowdoc=isDocumentPartOfWorkflow(m_strObjectId,getDfSession());
		if(ispartofWorkFlowdoc){
		  Label message = (Label)getControl("message", Label.class);
		  message.setVisible(true);
		  message.setLabel("Selected document is in workflow. On clicking OK, Selected Document and associated workflow will be deleted");
		}
		
		//checking virtual doc status or not
		VirtualDocStatus=getVirtualDocumentStatus(m_strObjectId);
		if(VirtualDocStatus){
		// disabling delete root only
			Panel panelVdmOptions = (Panel)getControl("vdmoptions", com.documentum.web.form.control.Panel.class);
			panelVdmOptions.setVisible(true);
			((Radio)getControl("deletefilenotdescendents", com.documentum.web.form.control.Radio.class)).setEnabled(false);
			((Radio)getControl("deletefilenotdescendents", com.documentum.web.form.control.Radio.class)).setVisible(false);
			((Radio)getControl(DELETEFILEANDDESCENDENTS, com.documentum.web.form.control.Radio.class)).setEnabled(true);
			((Radio)getControl(DELETEFILEANDDESCENDENTS, com.documentum.web.form.control.Radio.class)).setValue(true);
			((Radio)getControl(DELETEFILEANDDESCENDENTS, com.documentum.web.form.control.Radio.class)).setVisible(true);
		}
		Label messagelabel = (Label) getControl("deleteversionmessage", com.documentum.web.form.control.Label.class);
		messagelabel.setEnabled(false);
		messagelabel.setVisible(false);
	}
	
	/**
	 * 
	 * @param objectId
	 * @return
	 */
     private boolean getVirtualDocumentStatus(String objectId){
    	// Needs to change with new attributes
    	String VirtualdocOrnotQryStr= IdocsUtil.getMessage("QRY_VIRTUAL_DOC");
    	VirtualdocOrnotQryStr=VirtualdocOrnotQryStr.replace("''",("'"+objectId+"'"));
    	DfLogger.info(this, "getVirtualDocumentStatus VDM doc("+objectId+") VirtualdocOrnotQryStr :: "+VirtualdocOrnotQryStr, null, null);
    	IDfCollection virtualdocCollection = null;
 		boolean virtualDocStatus=false;
 	 	try {
     		virtualdocCollection = IdocsUtil.executeQuery(getDfSession(),VirtualdocOrnotQryStr,IDfQuery.DF_EXEC_QUERY);
     		if(virtualdocCollection != null){
     			while(virtualdocCollection.next()){
         			virtualDocStatus=virtualdocCollection.getBoolean(R_IS_VIRTUAL_DOC);
         		}	
     		} else virtualDocStatus= false; 
 	 		    		
     		DfLogger.info(this, "getVirtualDocumentStatus VDM doc("+objectId+") virtualDocStatus :: "+virtualDocStatus, null, null);
     	
 		} catch (Exception e) {
     		DfLogger.error(this, "getVirtualDocumentStatus  : " + e.getMessage(), null, null);
     	}finally{
     		if(virtualdocCollection != null)
 				try {
 					virtualdocCollection.close();
 				} catch (DfException e) {
 					DfLogger.error(this, " getRootDocumentFormat : " + e.getMessage(), null, null);
 				}
     	}
 		return virtualDocStatus;		
     }
     
     /**
	  * 
	  * @param templateTitle
	  * @throws DfException
	  */
     private void updateASWorkflowTable(String templateTitle) throws DfException{
		DfLogger.debug(this, " Object ID ::"+m_strObjectId, null, null);
		IDfDocument documentObject = (IDfDocument)ObjectCacheUtil.getObject(getDfSession(), m_strObjectId);
		/*
		 * This is code has been added for Advisory Services
		 * CODE : START
		 */
		try {
			if(templateTitle != null && IdocsUtil.isAdvisoryTemplate(templateTitle)){
				DfLogger.info(this, (new StringBuilder(" :: Advisory Services : Calling Servlet : ")).toString(), null, null);
				DfLogger.info(this, (new StringBuilder(" :: Template tile  : ").append(templateTitle)).toString(), null, null);
				String asServletURL = IdocsUtil.asBuildServletURL(documentObject,templateTitle,getDfSession(),MSG_AS_WORKFLOW_CODE);
				DfLogger.info(this, (new StringBuilder(" ::  Servlet URL :::: ")).append(asServletURL).toString(), null, null);
				IdocsUtil.buildAndExecuteServlet(asServletURL);
				DfLogger.info(this, (new StringBuilder(" :: Advisory Services : Servlet Executed  : ")).toString(), null, null);
			}
		} catch (Exception e) {
			DfLogger.error(this, (new StringBuilder(" ::  Exception occured in executing Servlet>> ")).append(e.getMessage()).toString(), null, e);
		}

		/*
		 * CODE : END 
		 */
	}

	public boolean onCommitChanges(){
		IDfSessionManager sessionManager = null;
		IDfSession deleteSession = null;
		try {
			sessionManager = IdocsUtil.getAdminSessionManager(getDfSession());
			deleteSession = sessionManager.getSession(getDfSession().getDocbaseName());
			DfLogger.debug(this, " :: onCommitChanges : AdminSession got on : " + getDfSession().getDocbaseName(), null, null);
			Radio radioDeleteAllVersions = (Radio)getControl(DELETEALLVERSIONS, Radio.class);
			boolean bDescendantsFlag = false;
			boolean bAllVersionsFlag = false;
			Radio radioDeleteFileAndDescendents = (Radio)getControl(DELETEFILEANDDESCENDENTS, Radio.class);
		    if(radioDeleteFileAndDescendents.getValue()){
		    	bDescendantsFlag = true;
		    }
		    if(radioDeleteAllVersions.getValue()){
		    	bAllVersionsFlag = true;
		    }
		    IDfSysObject adminSysObject = (IDfSysObject)deleteSession.getObject(new DfId(m_strObjectId));
		    String m_lockOwner=adminSysObject.getString(IdocsConstants.R_LOCK_OWNER);
		    DfLogger.debug(this, " :: onCommitChanges : getting Admin Session object  : " + adminSysObject.getObjectName(), null, null);
			if(adminSysObject != null){
				Object params[] = new Object[1];
	            params[0] = adminSysObject.getObjectName();
	           /****** To Delete The Work flow Document *******/
	        	/**updated on 09/28/2012 by L V Sudhakar */
	            boolean documentLockstatus=false;
	            if(m_lockOwner != null && m_lockOwner.trim().length()>0){
	            	documentLockstatus=true;
	            }else{
	            	documentLockstatus=false;
	            }
	            
	            if(ispartofWorkFlowdoc){
	              //boolean moreVersionsExisted=false;
	            	if(checkASValidationForDeleteWorkFlow(getDfSession(),m_strObjectId)){
	            		DfLogger.debug(this, " :: onCommitChanges :Advisory templete not allowed workflow document to delete", null, null);
	            		DfException exceptionforAdvisory= new DfException("Advisory Service template document not allowed to delete, while it is in workflow.");
	            		WebComponentErrorService.getService().setNonFatalError(this, MSG_DELETE_ERROR,exceptionforAdvisory);
	            	}else{
	            		String strObjectType = adminSysObject.getTypeName(); 
	            		DfLogger.debug(this, " :: onCommitChanges : strObjectType "+strObjectType, null, null);
	            		if(bDescendantsFlag){
		            			if(startWorkFlowCleanUpActivity(m_strObjectId,deleteSession,strObjectType)){
		            			   /**document lock status verifying */
		            				  if(documentLockstatus){
		            					  DfLogger.debug(this, " :: onCommitChanges : is locked by system or locked by user: ", null, null);
		            					  adminSysObject.cancelCheckout();
		            				   }else {
		            					   DfLogger.debug(this, " :: onCommitChanges : not locked by system or by user: ", null, null);
		            				   }
		            				   deleteObject(adminSysObject,bAllVersionsFlag , bDescendantsFlag);
		            				   MessageService.addMessage(this, MSG_DELETE_SUCCESS, params);
		            		           IdocsUtil.auditIDocsActivity(MSG_DELETED,m_strObjectId,getDfSession());
		            			   }else{
		            				   DfLogger.debug(this, " :: onCommitChanges : Workflow clean up activity failed ", null, null);
		            				   MessageService.addMessage(this, MSG_RUNNING_WORKFLOW_ACTION_FAILED, params);
		            			   }
	            		}else{
	            			DfLogger.debug(this, " :: onCommitChanges : entered into deleting single version part   ", null, null);
	            				if(startWorkFlowCleanUpActivity(m_strObjectId,deleteSession,strObjectType)){
			            			if(documentLockstatus){
			            				DfLogger.debug(this, " :: onCommitChanges : is locked by system or locked by user: ", null, null);
			            				adminSysObject.cancelCheckout();
			            			}else {
			            				DfLogger.debug(this, " :: onCommitChanges : not locked by system or by user: ", null, null);
			            			}
			            			String chronicleId=adminSysObject.getChronicleId().getId();
			            			deleteObject(adminSysObject,bAllVersionsFlag , bDescendantsFlag);
			            			updateNextVersionDocWorkFloStatus(deleteSession,strObjectType,chronicleId);
			            			IdocsUtil.auditIDocsActivity(MSG_DELETED,m_strObjectId,getDfSession());
			            			MessageService.addMessage(this, MSG_DELETE_SUCCESS, params);
			            		}else {
			            			DfLogger.debug(this, " :: onCommitChanges : clean up Activity Failed : ", null, null);
			            			MessageService.addMessage(this, MSG_RUNNING_WORKFLOW_ACTION_FAILED, params);
			            		}	
	            		}
	            	}
	            }else {
	            	DfLogger.debug(this, " :: onCommitChanges : not in workflow allowing user directly to delete " , null, null);
	            	deleteObject(adminSysObject,bAllVersionsFlag , bDescendantsFlag);
		        	MessageService.addMessage(this, MSG_DELETE_SUCCESS, params);
		        	IdocsUtil.auditIDocsActivity(MSG_DELETED,m_strObjectId,getDfSession());
		        	}
			}else{
				DfLogger.debug(this, " :: onCommitChanges : Error in Deletion  : document object is null " , null, null);
				setReturnError(MSG_DELETE_ERROR, null, null);
	            WebComponentErrorService.getService().setNonFatalError(this, MSG_DELETE_ERROR, null);
			}
		}catch (Exception e) {
			setReturnError(MSG_DELETE_ERROR, null, e);
		    WebComponentErrorService.getService().setNonFatalError(this, MSG_DELETE_ERROR, e);
         	e.printStackTrace();
		}finally{
			if(deleteSession !=null && sessionManager!=null)sessionManager.release(deleteSession);
		}
         return true;
    }
	
	/**
	 * 
	 * @param deleteSession
	 * @param objectType
	 * @param chronicleId
	 */
	private void updateNextVersionDocWorkFloStatus(IDfSession deleteSession,String objectType,String chronicleId) {
		DfLogger.debug(this,"updateNextVersionDocWorkFloStatus :: entred",null,null);
		DfLogger.debug(this,"updateNextVersionDocWorkFloStatus :: not restartable WorkFlow need to Update workflowstatus on Document",null,null);
		String updateWorkFLowSatusQuery =IdocsUtil.getMessage(QRY_UPDATE_WORKFLOW_STATUS);
		updateWorkFLowSatusQuery=updateWorkFLowSatusQuery.replaceAll(STR_REPLACE_OBJECT_TYPE, objectType);
		updateWorkFLowSatusQuery=updateWorkFLowSatusQuery.replace(STR_REPLACE_CHRONICLE_ID, IdocsConstants.MSG_QUOTES+chronicleId+IdocsConstants.MSG_QUOTES);
		try {
			IDfCollection dfCollection=IdocsUtil.executeQuery(deleteSession, updateWorkFLowSatusQuery, IDfQuery.DF_READ_QUERY);
			if(dfCollection != null)dfCollection.close();
		} catch (DfException e) {
			DfLogger.error(this, e.getMessage(),null,e);
		}	
		DfLogger.debug(this,"updateNextVersionDocWorkFloStatus :: end",null,null);
		
	}
	
	/**
	 * 
	 * @param session
	 * @param strObjectId
	 * @return
	 */
	public boolean checkASValidationForDeleteWorkFlow(IDfSession session,String strObjectId){
		String strTemplateTitle = IdocsUtil.getTemplateTitle(session, strObjectId);
		if(IdocsUtil.isAdvisoryTemplate(strTemplateTitle)){
		 return true;
		}else{
			return false;
		}
	}
	
	 
	/**
	 * 
	 * @param strObjectId
	 * @param dfSession
	 * @return
	 */

	 private boolean isDocumentPartOfWorkflow(String strObjectId,IDfSession dfSession) {
	 	String workflowId = IdocsUtil.getWorkflowId(dfSession, strObjectId);
		if(workflowId!=null && workflowId.trim().length()>0){
			DfLogger.debug(this, " :: Document is part of workflow :",null,null);
			m_strWorkFolwId=workflowId;
			return true;
		}else{
			DfLogger.debug(this, " :: Document is NOT part of workflow :",null,null);
			return false;
		}
	}
	
	
	/**
	 * 
	 * @param strObjectId
	 * @param dfSession
	 * @param strObjectType
	 * @return
	 * @throws DfException
	 */
	/** Added / Updated by L V Sudhakar */
	private boolean startWorkFlowCleanUpActivity(String strObjectId,IDfSession dfSession,String strObjectType) throws DfException{

	if(m_strWorkFolwId != null){
			IDfSession admSession = null;
			IDfSessionManager admSMgr = null;
		  try {
				admSMgr = IdocsUtil.getAdminSessionManager(dfSession);
				DfQuery query = new DfQuery();
				StringBuilder deleteWfGroupsQry = new StringBuilder(IdocsUtil.getMessage("WF_GROUPS_DELETE_QRY"));
				deleteWfGroupsQry.append(m_strWorkFolwId).append("_%'");
				query.setDQL(deleteWfGroupsQry.toString());
				DfLogger.info(this,": Delete Groups Query : " + deleteWfGroupsQry.toString(), null, null);
					admSession = admSMgr.getSession(dfSession.getDocbaseName());
					IDfCollection collection = query.execute(admSession, IDfQuery.DF_READ_QUERY);
					if (collection.next()) {
						collection.close();
					}
					if (collection != null) {
						collection.close();
					}
					IDocsWorkflowService.abort(m_strWorkFolwId);
					IDocsWorkflowService.delete(m_strWorkFolwId);
				} catch(DfException e) {
					DfLogger.error(this, (new StringBuilder(" :: deleteWorkFlowdocument Exception >> ")).append(e.getMessage()).toString(), null, e);
					return false;
				} finally {
					if (admSMgr != null && admSession != null) {
						admSMgr.release(admSession);
						DfLogger.info(this, "Admin Session Released", null, null);
				}
				else {
					  DfLogger.info(this, "Unable to release Admin Session", null, null);
					}
		        }			
			  }
			return true;
		   }

	
	/**
	 * 
	 * @param sysObj
	 * @param bDeleteAllVersions
	 * @param bDeleteDescendants
	 * @throws Exception
	 */
	private void deleteObject(IDfSysObject sysObj, boolean bDeleteAllVersions,boolean bDeleteDescendants) throws Exception {
		if (Trace.WDK_API_TRACE)
			Trace.println((new StringBuilder()).append("deleteObject: ")
					.append(sysObj.getObjectName())
					.append(", DeleteAllVersions=")
					.append(bDeleteAllVersions)
					.append(", DeleteDescendents=")
					.append(bDeleteDescendants).toString());
		
		IDfDeleteOperation deleteOperation = DfcUtils.getClientX().getDeleteOperation();
		if (deleteOperation instanceof IDfDeleteOperationInternal) {
			IDfDeleteOperationInternal deleteOperationInt = (IDfDeleteOperationInternal) deleteOperation;
			deleteOperationInt.enableRemoteMode(true);
		}
		if (bDeleteAllVersions) {
			IDfDeleteOperation _tmp = deleteOperation;
			deleteOperation.setVersionDeletionPolicy(2);
		} else {
			IDfDeleteOperation _tmp1 = deleteOperation;
			deleteOperation.setVersionDeletionPolicy(0);
		}
		if (sysObj.isReference())
			deleteOperation.enablePopulateWithReferences(true);
		if (sysObj.isVirtualDocument() && bDeleteDescendants) {
			com.documentum.fc.client.IDfVirtualDocument virtualDoc = VdmUtil
					.getVirtualDocumentFromSysObject(sysObj);
			deleteOperation.add(virtualDoc);
		} else {
			deleteOperation.add(sysObj);
		}
		sysObj.getSession().getMessage(2);
		boolean executeSucceeded = deleteOperation.execute();
		if (!executeSucceeded) {
			String strDeleteExecuteError = "";
			IDfList list = deleteOperation.getErrors();
			int count = list.getCount();
			if (count > 0) {
				IDfOperationError opErr = (IDfOperationError) list.get(0);
				strDeleteExecuteError = opErr.getMessage();
				IDfException exceptSrc = opErr.getException();
				if (exceptSrc != null) {
					String strSrcException = exceptSrc.getMessage();
					if (strSrcException != null
							&& !strSrcException.equals(strDeleteExecuteError))
						strDeleteExecuteError = (new StringBuilder()).append(
								strDeleteExecuteError).append(" ").append(
								strSrcException).toString();
				}
			}
			throw new WrapperRuntimeException(strDeleteExecuteError);
		}
		m_strWarningMessage = sysObj.getSession().getMessage(2);
		if (Trace.WDK_API_TRACE)
			Trace.println("DeleteObject completed.");
	}

	public String getDeleteWarningMessages() {
		return m_strWarningMessage;
	}

	private String m_strWarningMessage;
	protected void postDelete(){
        super.postDelete();
        IdocsUtil.auditIDocsActivity(MSG_DELETED,m_strObjectId,getDfSession());
        DfLogger.debug(this, " Object Deleted Audit Updated.", null, null);
    }
	
	/**
	 * 
	 * @param control
	 * @param list
	 */
	public void changeLableField(Radio control,ArgumentList list){
		Label message = (Label)getControl("message", Label.class);
		message.setVisible(true);
		if(ispartofWorkFlowdoc){
			if(control.getName().equalsIgnoreCase("deleteselectedversion") ){
				message.setLabel("Selected document is in workflow. On clicking OK, Selected Document and associated workflow will be deleted");
		    }
		    if(control.getName().equalsIgnoreCase(DELETEALLVERSIONS)){
		    	message.setLabel("Selected document is in workflow. On clicking OK, Selected Document All Vesions and associated workflow will be deleted");
		    }
		    }else{
			DfLogger.debug(this,"Not Required to Update ", null,null);
			}
		
	}
	
	  public boolean ispartofWorkFlowdoc=false;
	  private String STR_REPLACE_CHRONICLE_ID="'<chronicleId>'";
	  private String STR_REPLACE_OBJECT_TYPE="<objectType>";
	  private String m_strWorkFolwId=null; 
	  private String R_IS_VIRTUAL_DOC="r_is_virtual_doc";
}
