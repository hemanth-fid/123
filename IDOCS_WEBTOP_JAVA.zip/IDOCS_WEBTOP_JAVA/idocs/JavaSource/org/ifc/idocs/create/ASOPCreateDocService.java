/**
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* L V Sudhakar           25/09/2012	     1.0          Created
* #######################################################################################################
*/

package org.ifc.idocs.create;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Calendar;
import java.util.HashMap;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.library.actions.LaunchViewComponentWithPermitCheck;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;
import org.w3c.dom.Document;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.ErrorMessageService;
import com.documentum.web.form.FormActionReturnListener;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.component.Prompt;
import com.documentum.web.formext.session.DocbaseUtils;
import com.documentum.webcomponent.common.WebComponentErrorService;

public class ASOPCreateDocService{

	private static final String ASOP_INTG_SERVLET_URL = "ASOP_INTG_SERVLET_URL";

	public HashMap<String,String> forAdvisoryServicesTemplatesForNewDocContainer(String strTemplateName,String projectID,Component component,IDfSession m_dfSesssion,HttpServletRequest servletRequest) throws DfException{
		HashMap<String,String> advisoryValidationMap= new HashMap<String,String>();
		 	StringBuffer asDocumentName = new StringBuffer();
	        DfLogger.debug(this," :: Project id::  " + projectID,null,null);
	        String tempCategory = null;
	      /**Checking COI Group for AS templates*/	   
	        if(projectID!= null && (IdocsUtil.isUserPresentInConflictOfInterest(projectID,component.getDfSession()) 
					|| IdocsUtil.isUserMemberofLDAPGroup(
							IdocsUtil.getMessage(IdocsConstants.CONFLICT_OF_INTEREST_ROLE), projectID, component.getDfSession()))){
				DfLogger.info(LaunchViewComponentWithPermitCheck.class,"::validateUserPermissionsForDelete  User is Present in Conflict Of Interest:", null, null);
				ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_COI_CREATE_DENIED", component, new String[]{"Create",strTemplateName}, null);
				
			}else{
				DfLogger.info(this, "User Not in Conflict of interest group", null,null);
			}
	        
	        tempCategory=getTemplateCategoryCode(strTemplateName);
	    /**If AS SuperVision Template Add Name field with Financial data*/	
	        if(tempCategory.equals(IDocsConstants.MSG_AS_SUPERVISION_TEMPCODE) && tempCategory.equals(IDocsConstants.MSG_AS_PDP_SUPERVISION_TEMPCODE)){
				asDocumentName=appendFinancialDataOnDocumentName(asDocumentName,m_dfSesssion,projectID,strTemplateName,tempCategory);
			}else{
				asDocumentName = new StringBuffer(projectID).append("_").append(strTemplateName);
				DfLogger.info(this,":: No Need To Add Financial Data on Other than Supervision template  Template >> :"+strTemplateName+"  Code "+tempCategory ,null,null);
			}
	     /**Checking for Same Named document existence */
	        boolean isDocExist =checkDocNameExistance(asDocumentName, m_dfSesssion);
	        
	        if(isDocExist){
					Object params[] = new Object[1];
					String msg = strTemplateName + " document cannot be created, as the document already exist";;
					params[0] = DocbaseUtils.getValidationExceptionMsg(new DfException(msg));			            	   	
					WebComponentErrorService.getService().setNonFatalError(component.getTopForm(), "MSG_VALIDATION_ERROR", params, null);
					advisoryValidationMap.put(IASOPConstants.STR_STATUS,IASOPConstants.STR_FALSE);
					advisoryValidationMap.put(IASOPConstants.STR_NAME,null);
					return advisoryValidationMap;
	        }else{
	        	 Document taskCanCreate = IdocsUtil.canCreateServletCall(projectID, m_dfSesssion, tempCategory);
	        	 boolean xmlValidationStatus=validateXMLValues(taskCanCreate,projectID,strTemplateName,tempCategory,component.getDfSession(),servletRequest,component);
	        	 if(xmlValidationStatus){
	        		 advisoryValidationMap.put(IASOPConstants.STR_STATUS,IASOPConstants.STR_TRUE);
		    	 }else{
	        		 advisoryValidationMap.put(IASOPConstants.STR_STATUS,IASOPConstants.STR_FALSE);
	        		 }
	        	 advisoryValidationMap.put(IASOPConstants.STR_NAME,asDocumentName.toString());
	        	 return advisoryValidationMap;
	        }
	 
	}
	
	/**
	 * to Validate Template from servlet calls and With XML Element Values
	 * @param taskCanCreate
	 * @param projectID
	 * @param strTemplateName
	 * @param tempCategory
	 * @param m_dfSession
	 * @param servletRequest
	 * @param component
	 * @return
	 */
	private boolean validateXMLValues(Document taskCanCreate,String projectID,String strTemplateName,String tempCategory,IDfSession m_dfSession,HttpServletRequest servletRequest,Component component){
		XPathFactory xPathFactory = XPathFactory.newInstance();
		XPath xPath = xPathFactory.newXPath();
		try{
			XPathExpression permExpression = xPath.compile(IASOPConstants.STR_CREATE_PERMISSION);
			String createPermission = permExpression.evaluate(taskCanCreate);
			DfLogger.debug(this, " :: validateXMLValues : create permission : " + createPermission,null,null);
			XPathExpression msgExpression = xPath.compile(IASOPConstants.STR_CREATE_MESSAGE);
			String message = msgExpression.evaluate(taskCanCreate);
			DfLogger.debug(this, " :: validateXMLValues : message: " + message,null,null);
			// check document creation
			if(createPermission.equalsIgnoreCase(IASOPConstants.STR_CREATE_NOTPOSSIBLE)){
				DfLogger.debug(this,":: Document create permission Denied",null,null);
				Object params[] = new Object[1];             
				params[0] = DocbaseUtils.getValidationExceptionMsg(new DfException(message));
				if(message == null || !(message.trim().length()>0)){
					message = "Document can not be created,Please check with Admin Team";
				}
				params[0] = DocbaseUtils.getValidationExceptionMsg(new DfException(message));
				ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_VALIDATION_ERROR", component, new String[]{message}, null);
				return false;
			}else
			  if(createPermission.equalsIgnoreCase("yes")){
					DocumentBuilderFactory buildFactory = DocumentBuilderFactory.newInstance();
					DocumentBuilder docBuilder = buildFactory.newDocumentBuilder();
					DfLogger.info(this, " :: validateXMLValues : Request object created : ",null,null);
					Cookie[] cookies = servletRequest.getCookies();
					DfLogger.info(this, " :: validateXMLValues : Obtained Cookies from request : ",null,null);
					String cookieValue  =null;
					/**getting required info from Request Parameter*/
					HashMap<String,String> userMapDetails =getSMUserDetails(servletRequest);
					/**getting required info from Cookies*/
					cookieValue=getCoockieSMSessionValue(cookies);
				 	try{
					 	String servletBasicUrl = IdocsUtil.getIdocsConfigInfoValue(m_dfSession, ASOP_INTG_SERVLET_URL);
						DfLogger.debug(IdocsUtil.class, (new StringBuilder(" :: Advisory Services : build Servlet URL  : ")).toString(), null, null);
						StringBuffer strBuffer = new StringBuffer();
						if(servletBasicUrl != null && servletBasicUrl.trim().length() >0){
							strBuffer.append(servletBasicUrl);
						}
					    /*
						 * MANDATORY - CHANGE THIS CODE TO MAKE IT GENERIC FOR ALL TEMPLATES
						 */
						String servletURL = getServletNameForASOPortal(tempCategory);
						servletURL = servletURL + "?task=createdocument&project_id="+projectID+"&temp_cat="+tempCategory;
						//String servletURL = "IFCDocsIntegrationServlet?task=createdocument&project_id="+projectID+"&temp_cat="+IDocsConstants.MSG_AS_SUPERVISION_TEMPCODE;
						strBuffer.append(servletURL);
						URL testServlet = new URL(strBuffer.toString());
						DfLogger.info(this, " :: validateXMLValues : URL Object created : ",null,null);
						URLConnection urlConnection = testServlet.openConnection();
						DfLogger.info(this, " :: validateXMLValues : Opened Connection : ",null,null);
						((HttpURLConnection)urlConnection).setRequestMethod("GET");
						((HttpURLConnection)urlConnection).setRequestProperty("Cookie", "SMSESSION="+cookieValue);
						((HttpURLConnection)urlConnection).setRequestProperty("sm_user", userMapDetails.get(IASOPConstants.STR_SM_USER_NAME));
						((HttpURLConnection)urlConnection).setRequestProperty("SM_USERDN", userMapDetails.get(IASOPConstants.STR_SM_UPI_NUMBER));
						DfLogger.info(this, " :: validateXMLValues : Added Cookies to the request : ",null,null);
						urlConnection.setDoOutput(true);
						try {
							InputStream is  = urlConnection.getInputStream();
							Document documentObj = docBuilder.parse(is);
							try {
								XPathExpression responseXML = xPath.compile("/");
								String servletResponse = responseXML.evaluate(documentObj);
								DfLogger.info(this, " :: validateXMLValues : Response XML : " + servletResponse ,null,null);
							} catch (Exception e) {
								DfLogger.error(this, " :: EXCEPTION :: onNextComponent : Response XML : " ,null,null);
								Object params[] = new Object[1];
								String msg = "Can not create " + strTemplateName + " document, ";
								params[0] = DocbaseUtils.getValidationExceptionMsg(new DfException(msg+"\n Error :: "+e.getMessage()));
								WebComponentErrorService.getService().setNonFatalError(component.getTopForm(), "MSG_VALIDATION_ERROR", params, null);
								e.printStackTrace();
								return false;
							}
							DfLogger.info(this, " :: validateXMLValues : After connection estabilished : ",null,null);
							XPathExpression result = xPath.compile("/root/resultInfo");
							String servletResult = result.evaluate(documentObj);
							DfLogger.info(this, " :: validateXMLValues : Result info : "+servletResult,null,null);
							XPathExpression servletMsg = xPath.compile("/root/message");
							String msgString = servletMsg.evaluate(documentObj);
							DfLogger.info(this, " :: validateXMLValues : Message : "+msgString,null,null);
							Object params[] = new Object[1];
							params[0] = DocbaseUtils.getValidationExceptionMsg(new DfException(msgString));
							XPathExpression docObjectId = xPath.compile("/root/documentURL");
							String docURL = docObjectId.evaluate(documentObj);
							DfLogger.info(this, " :: validateXMLValues : Document id : "+docURL,null,null);
						} catch (Exception e) {
							Object params[] = new Object[1];
							DfLogger.error(this, " :: EXCEPTION :: validateXMLValues : reading inputstream  to get result info: " ,null,null);
							String msg = "Can not create " + strTemplateName + " document, ";
							params[0] = DocbaseUtils.getValidationExceptionMsg(new DfException(msg+"\n Error :: "+e.getMessage()));
							WebComponentErrorService.getService().setNonFatalError(component.getTopForm(), "MSG_VALIDATION_ERROR", params, null);
							e.printStackTrace();
							return false;
						}
						String componentId= component.getComponentId();
						ArgumentList promptArguments = new ArgumentList();
						promptArguments.add(Prompt.ARG_TITLE,"Message");
						promptArguments.add(Prompt.ARG_MESSAGE,strTemplateName+"Document Created - Successfully");
						promptArguments.add(Prompt.ARG_BUTTON,new String[] { Prompt.OK });
						DfLogger.debug(this, "componentId"+componentId,null,null);
						if(componentId.equalsIgnoreCase("objectlist")){
						    component.setComponentNested(IDocsConstants.MSG_PROMPT_COMPONENT,promptArguments, component.getContext(),component.getReturnListener());
							component.onRefreshData();
						}else{
							component.setComponentNested(IDocsConstants.MSG_PROMPT_COMPONENT,promptArguments, component.getContext(),new FormActionReturnListener(component,"onReturnFromPromptInput"));
						}
						
						return false;
						
				 	} catch (MalformedURLException e1) {
						Object params[] = new Object[1];
						DfLogger.error(this,e1.getMessage(),null,e1);
						String msg = "Can not create " + strTemplateName + " document, ";
						params[0] = DocbaseUtils.getValidationExceptionMsg(new DfException(msg+"\n Error :: "+e1.getMessage()));
						WebComponentErrorService.getService().setNonFatalError(component.getTopForm(), "MSG_VALIDATION_ERROR", params, null);
						return false;
					} catch (Exception e) {
						Object params[] = new Object[1];
						String msg = "Can not create " + strTemplateName + " document, ";
						DfLogger.error(this,e.getMessage(),null,e);
						params[0] = DocbaseUtils.getValidationExceptionMsg(new DfException(msg+"\n Error :: "+e.getMessage()));
						WebComponentErrorService.getService().setNonFatalError(component.getTopForm(), "MSG_VALIDATION_ERROR", params, null);
						return false;
					}
			}else {
				return false;
			}
		}catch(XPathExpressionException e){
			e.printStackTrace();
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return true;
	}
	
 
	
	
	/**
	 * To Get SMUser Session Value 
	 * @param cookies
	 * @return
	 */
	private String getCoockieSMSessionValue(Cookie[] cookies){
		String cookieValue="";
		if(cookies!=null)
		{
			DfLogger.info(this, " :: getCoockieSMSessionValue : Cookie object not null.. and lenght : " + cookies.length,null,null);
			for (int i = 0; i < cookies.length; i++) {
				String name = cookies[i].getName();
				if (name.equalsIgnoreCase("SMSESSION")) {
					cookieValue = cookies[i].getValue();
					DfLogger.info(this, " :: getCoockieSMSessionValue : Cookie : SMSESSION Value : " + cookieValue,null,null);
				}
			}
		}
		return cookieValue;
	}
	
	
	/**
	 * 
	 * @param asDocumentName
	 * @param m_dfSesssion
	 * @param projectID
	 * @param strTemplateName
	 * @return
	 */
	private StringBuffer appendFinancialDataOnDocumentName(StringBuffer asDocumentName,IDfSession m_dfSesssion, String projectID, Object strTemplateName,String tempCategory) {
		Document documentObject = null;
		try {
			documentObject = IdocsUtil.getFinancialData(projectID,m_dfSesssion,tempCategory);
		} catch (DfException e1) {
			DfLogger.debug(IdocsUtil.class,":Unable to fetch Financial Data from servlet : ",null,null);
			e1.printStackTrace();
		}
		String financialYear = null;
		String quarter = null;
		try{
			XPathFactory xPathFactory = XPathFactory.newInstance();
			XPath xPath = xPathFactory.newXPath();
			XPathExpression fyExpression = xPath.compile("/as_supervision/spv_fy");
			financialYear = fyExpression.evaluate(documentObject);
			DfLogger.debug(IdocsUtil.class,": Financial Year : "+financialYear,null,null);
			/** servlet to retrieve the financial data */
			XPathExpression qtrExpression = xPath.compile("/as_supervision/spv_qtr");
			quarter = qtrExpression.evaluate(documentObject);
			DfLogger.debug(IdocsUtil.class,": Financial Quater : "+quarter,null,null);

		}
		catch (XPathExpressionException e) {
			e.printStackTrace();
		}
		if(financialYear==null){
			Integer integerObj = new Integer(Calendar.YEAR);
			financialYear = integerObj.toString();
			DfLogger.debug(this, " :: onNextComponent : Financial Year Data from XML is NULL so new financialYear: " + financialYear,null,null);
		}
		if(quarter==null){
			quarter = "";
			DfLogger.debug(this, " :: onNextComponent : quarter Data from XML is NULL so new quarter " + quarter,null,null);
		}
		asDocumentName = new StringBuffer(projectID).append("_").append(strTemplateName).append("_FY").append(financialYear).append(quarter);
		DfLogger.debug(this, " :: onNextComponent : Document Name for Supervision is  " + asDocumentName,null,null);
		return asDocumentName;
	}
	
	/**
	 * To Get the info of Same Named Document existence
	 * @param asDocumentName
	 * @param m_dfSesssion
	 * @return
	 */
	private boolean checkDocNameExistance(StringBuffer asDocumentName,IDfSession m_dfSesssion){
		boolean isDocExist =false;
		IDfCollection docExistColl = null;
        try{
      	  String asTempExistQry = IdocsUtil.getMessage("AS_DOC_EXIST_QRY");
      	  asTempExistQry = asTempExistQry.replaceAll("%object_name%", asDocumentName.toString());
      	  docExistColl = IdocsUtil.executeQuery(m_dfSesssion,asTempExistQry, IDfQuery.DF_READ_QUERY);
      	  while(docExistColl.next()){
      		  isDocExist = true;
      	  }
      	  }catch(Exception e){
      		  DfLogger.error(this," :: EXCEPTION OCCURRED IN CHECKING DUPLICATES OF DOCUMENTS",null,null);
      	  }finally{
      		  if(docExistColl != null){
      			  try {
      				  docExistColl.close();
      				  } catch (DfException e) {
      					  // TODO Auto-generated catch block
      					  DfLogger.error(this," :: EXCEPTION OCCURRED IN CHECKING DUPLICATES OF DOCUMENTS",null,null);
      					  }
      				  }
      		  }
      	  return isDocExist;
      	  }
  
  /**
    * To Get the SMUser UPI and User Name Details
    * @param servletRequest
    * @return
    */
	private HashMap<String,String> getSMUserDetails(HttpServletRequest servletRequest){
		HashMap <String,String> smUserMap= new HashMap<String,String>();
		if(servletRequest.getHeader("SM_USERDN")!=null){
			smUserMap.put(IASOPConstants.STR_SM_UPI_NUMBER,servletRequest.getHeader(IASOPConstants.STR_SM_UPI_NUMBER));
		}
		if(servletRequest.getHeader("SM_USER")!=null){
			smUserMap.put(IASOPConstants.STR_SM_USER_NAME,servletRequest.getHeader(IASOPConstants.STR_SM_USER_NAME));
		}
		return smUserMap;
		}
	/**
	 * 
	 * @param tempCategory
	 * @return
	 */
	private String getServletNameForASOPortal(String tempCategory) {
		if(tempCategory.equals(IDocsConstants.MSG_AS_PDP_IMPL_PLAN_TEMPCODE)||tempCategory.equals(IDocsConstants.MSG_AS_PDP_SUPERVISION_TEMPCODE)) 
			return(IdocsUtil.getMessage("STR_SERVLET_NAME_ASOP_PDP"));
		else 
			return(IdocsUtil.getMessage("STR_SERVLET_NAME_ASOP_OTHERTHAN_PDP"));
	
	}
	
	/**
	 * To Get the Advisory Services Template Code Value 
	 * @param strTemplateName
	 * @return
	 */
	private String getTemplateCategoryCode(String strTemplateName) {
		if(strTemplateName.equals(IDocsConstants.MSG_AS_CONCEPT_NOTE)){
			return IDocsConstants.MSG_AS_CONCEPT_NOTE_TEMPCODE;
		}else if (strTemplateName.equals(IDocsConstants.MSG_AS_PLAN) || strTemplateName.equals(IDocsConstants.MSG_AS_IMPLEMENTATION_PLAN)) {
			return IDocsConstants.MSG_AS_IMPLEMENTATION_PLAN_TEMPCODE;
		}else if (strTemplateName.equals(IDocsConstants.MSG_AS_COMPLETION)) {
			return IDocsConstants.MSG_AS_COMPLETION_TEMPCODE;
		}else if (strTemplateName.equals(IDocsConstants.MSG_AS_SUPERVISION)) {
			return IDocsConstants.MSG_AS_SUPERVISION_TEMPCODE;
		}else if (strTemplateName.equals(IDocsConstants.MSG_AS_DROPPAGE_NOTE) || strTemplateName.equals(IDocsConstants.MSG_AS_DROPPAGE_MEMO)) {
			return IDocsConstants.MSG_AS_DROPPAGE_NOTE_TEMPCODE;
		}else if (strTemplateName.equals(IDocsConstants.MSG_AS_PDP_IMPL_PLAN)) {
			return IDocsConstants.MSG_AS_PDP_IMPL_PLAN_TEMPCODE;
		}else if (strTemplateName.equals(IDocsConstants.MSG_AS_PDP_SUPERVISION)) {
			return IDocsConstants.MSG_AS_PDP_SUPERVISION_TEMPCODE;
		}else{
			return "";
		}
	}
	
	private static final NlsResourceBundle s_lookup = new NlsResourceBundle("org.ifc.idocs.create.NewDocumentNlsProp");
 }
