package org.ifc.idocs.create;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.services.collaboration.ICommentManager;
import com.documentum.services.collaboration.ITopic;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.session.DocbaseUtils;
import com.documentum.webcomponent.common.WebComponentErrorService;
import com.documentum.webcomponent.library.create.CreateService;

public class CreateNewDoc extends CreateService
{
	IDfFolder docFolder=null;
	public CreateNewDoc(String templateNamearg, IDfSession aoDfSession,
			Component componentObject,IDfFolder docFolder,HttpServletRequest servletReq) {
		strTemplateName = templateNamearg;
		//strFolderId = folderObjectId;
		this.docFolder=docFolder;
		m_dfSesssion = aoDfSession;
		component = componentObject;
		servletRequest = servletReq;
	}
	
	public String getDocumentCreator()
	{
		String newDocID = EMPTY_STRING;
		String docPrefix=null;
		IDfCollection dfCollection=null;
		try {
			if (docFolder != null) {
				String ObjectType = docFolder.getString(R_OBJECT_TYPE);
				if (ObjectType != null) {
					if (ObjectType.equals(IDOCS_PROJECT_FOLDER)) {
						docPrefix = docFolder.getString(PROJECT_ID);
					} else if (ObjectType.equals(IDOCS_INSTITUTION_FOLDER)) {
						docPrefix = docFolder.getString(INSTITUTION_NBR);
					} else if (ObjectType.equals(IDOCS_COUNTRY_FOLDER)) {
						docPrefix = docFolder.getString(COUNTRY_CODE);
					}
				}
			}
			DfLogger.info(this, "Documnent Prefixed with :: "+docPrefix, null, null);
			String strTemplateObjId=null;
			if(docFolder != null && !docFolder.getObjectId().getId().equals(IDocsConstants.BLANK_OBJECT_ID)){
				StringBuilder templateQueryBuilder= new StringBuilder();
				templateQueryBuilder.append(SELECT_R_OBJECT_ID_FROM_IDOCS_DOCUMENT_WHERE_OBJECT_NAME+strTemplateName+QUOTES);
				if(docFolder.getString(R_OBJECT_TYPE).equals(IDocsConstants.MSG_IDOCS_PROJ_FOLDER)){
					templateQueryBuilder.append(AND_R_OBJECT_TYPE+IDocsConstants.MSG_IDOCS_PROJECT_DOC+QUOTES);
				}else if(docFolder.getString(R_OBJECT_TYPE).equals(IDocsConstants.MSG_IDOCS_INSTIT_FOLDER)){
					templateQueryBuilder.append(AND_R_OBJECT_TYPE+IDocsConstants.MSG_IDOCS_INSTITUTION_DOC+QUOTES);
				}else if(docFolder.getString(R_OBJECT_TYPE).equals(IDocsConstants.MSG_IDOCS_COUNTRY_FOLDER)){
					templateQueryBuilder.append(AND_R_OBJECT_TYPE+IDocsConstants.MSG_IDOCS_COUNTRY_DOC+QUOTES);
				}
				templateQueryBuilder.append("  and folder('"+IDocsConstants.MSG_TEMPLATE_PATH+"')");
				DfLogger.info(CreateNewDoc.class,"strTemplateQry..."+templateQueryBuilder.toString(),null,null);
				dfCollection = IdocsUtil.executeQuery(m_dfSesssion, templateQueryBuilder.toString(),IDfQuery.DF_EXEC_QUERY);
				if(null!=dfCollection){
					while (dfCollection.next())
					{
						strTemplateObjId = dfCollection.getString(R_OBJECT_ID);
					}
				} 
			}else{
				//don't care about this block ..
				Object params[] = new Object[1];
				String msgString="Unable to find the Catelog to create a new document for you in IFCDocs application.Please try again later";
				params[0] = DocbaseUtils.getValidationExceptionMsg(new DfException(msgString));
				WebComponentErrorService.getService().setNonFatalError(component.getTopForm(), MSG_VALIDATION_ERROR, params, null);
				strTemplateObjId=null;
			}
			if(strTemplateObjId ==  null){
				return null;
			}else{
				String newDocName=null;
				DfLogger.info(this, "Doc Template Name ::" +strTemplateName, null, null);
				boolean isAdvisory=IdocsUtil.isAdvisoryTemplate(strTemplateName);
				if(isAdvisory){
					/** To validate and build ASOP Name modified on 09/17/2012**/
					HashMap<String,String> advisoryValidationMap= new ASOPCreateDocService().forAdvisoryServicesTemplatesForNewDocContainer(strTemplateName, docPrefix, component, m_dfSesssion, servletRequest);
					if(advisoryValidationMap != null && advisoryValidationMap.size()>0){
						DfLogger.debug(this,"Advisory Services return Map Values "+advisoryValidationMap,null,null);
					}
					newDocName= IASOPConstants.STR_ADVISORY_VALUE;;
				}else{
					newDocName = new StringBuilder(docPrefix).append("_").append(strTemplateName).toString();
				}
				try {
					if (newDocName != null && newDocName.length() > 0
							&& newDocName.equalsIgnoreCase(IASOPConstants.STR_ADVISORY_VALUE)==false) {
						CreateService createSvc = new CreateService();
						newDocID=createSvc.createObjectFromTemplate(strTemplateObjId,docFolder.getObjectId().toString(),newDocName,true);
						IdocsUtil.auditIDocsActivity(MSG_CREATED,newDocID,component.getDfSession());
						/** To Enable  discussions on new Created document(s)  added on 04/18/2012  **/
						ICommentManager commentMgr = (ICommentManager) DfClient.getLocalClient().newService(ICommentManager.class.getName(),m_dfSesssion.getSessionManager());
						ITopic topic=commentMgr.createTopic("topic",new DfId(newDocID), true);
						topic.setIsDisabled(false);
						/**End of the code */
					}else{
						if(isAdvisory){
							DfLogger.debug(this,"This is As Related Templape Doc Creation",null,null);
						}else{
							Object params[] = new Object[1];
							String msgString="Unexpected problem occured with Network,Please Try after Some time.";
							params[0] = DocbaseUtils.getValidationExceptionMsg(new DfException(msgString));
							WebComponentErrorService.getService().setNonFatalError(component.getTopForm(), MSG_VALIDATION_ERROR, params, null);
						}
					}
				} catch (CreateException e) {
					Object params[] = new Object[1];
					String msgString=e.getMessage();
					params[0] = DocbaseUtils.getValidationExceptionMsg(new DfException(msgString));
					WebComponentErrorService.getService().setNonFatalError(component.getTopForm(), MSG_VALIDATION_ERROR, params, null);
					DfLogger.error(this,e.getMessage(),null,e);
				}
				return newDocID;
			}
		} catch (DfException e) {
			DfLogger.error(this,e.getMessage(),null,e);
		}finally{
			try {
				if(null!=dfCollection){
					dfCollection.close();
				}
			} catch (DfException e) {
				DfLogger.error(this,e.getMessage(),null,e);
			}
		}
		return newDocID;
	}
	
	
	private Component component;
	private IDfSession m_dfSesssion=null;
    private String strTemplateName=EMPTY_STRING;
	private HttpServletRequest servletRequest = null;
	
	private static final String QUOTES = "'";
	private static final String EMPTY_STRING = "";
	private static final long serialVersionUID = 1L;
	private static final String MSG_CREATED = "Created";
	private static final String PROJECT_ID = "project_id";
	private static final String R_OBJECT_ID = "r_object_id";
	private static final String COUNTRY_CODE = "country_code";
	private static final String R_OBJECT_TYPE = "r_object_type";
	private static final String INSTITUTION_NBR = "institution_nbr";
	private static final String AND_R_OBJECT_TYPE = " and r_object_type ='";
	private static final String MSG_VALIDATION_ERROR = "MSG_VALIDATION_ERROR";
	private static final String IDOCS_COUNTRY_FOLDER = "idocs_country_folder";
	private static final String IDOCS_PROJECT_FOLDER = "idocs_project_folder";
	private static final String IDOCS_INSTITUTION_FOLDER = "idocs_institution_folder";
	private static final String SELECT_R_OBJECT_ID_FROM_IDOCS_DOCUMENT_WHERE_OBJECT_NAME = "select r_object_id from idocs_document where object_name='";
	
    public String docId;
    public boolean m_bNeedCreate = false;
    
 }
	
  