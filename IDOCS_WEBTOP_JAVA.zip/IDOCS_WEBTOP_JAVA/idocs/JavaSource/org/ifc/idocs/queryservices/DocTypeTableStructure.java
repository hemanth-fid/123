package org.ifc.idocs.queryservices;


import java.util.ArrayList;


import com.documentum.fc.common.DfLogger;
import com.documentum.web.form.control.databound.TableResultSet;

public class DocTypeTableStructure {

	private ArrayList<String []> dataValues = new ArrayList<String[]> ();
	private ArrayList<String []> templateNameTableDataValues = new ArrayList<String[]> ();
	
    public DocTypeTableStructure(ArrayList<String []> dataValues){
        this.dataValues=dataValues;
        this.templateNameTableDataValues=IDocsQRYVO.templateNameTableDataValues;
        
    }
     
    public ArrayList<String []>  getObject( String [] matrix) {
       return this.dataValues ;
    }
    
    public void setObject( ArrayList<String []> valuesObject) {
        this.dataValues  = valuesObject;
     }
    
    public void addRow( String [] matrix) {
        this.dataValues.set(dataValues.size(),matrix) ;
    }
   /**
    * 
    * @param iterationValue
    */
    public void getRow(int iterationValue){
    	try {
			dataValues.get(iterationValue);
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
   /**
    * 
    * @param columnName
    * @return
    */
    public TableResultSet getTableResultSet(String columnName){
    	int columnNumber = getColumnNumber(columnName);
    	TableResultSet typeResultSet = null;
    	typeResultSet =new TableResultSet(new String[] {columnName});
    	ArrayList<String> existedEnbtries = new ArrayList<String>(); 
    	for (int j = 0; j < dataValues.size(); j++) {
    		String[] arrayValues= dataValues.get(j);
    		existedEnbtries.add(arrayValues[columnNumber]);
    		if(checkValueExistance(existedEnbtries,arrayValues[columnNumber])){
    			existedEnbtries.add(arrayValues[columnNumber]);
    			typeResultSet.add(new String[] {arrayValues[columnNumber]});
    		}
    	}
    	return typeResultSet;
    }
    
    /**
     * 
     * @param columnName
     * @param whereClauseName1
     * @param whereCaluseValue1
     * @param whereClauseName2
     * @param whereClauseValue2
     * @param whereClauseName3
     * @param whereClauseValue3
     * @return
     */
    public TableResultSet getTableResultSetColumnWithWhereClauses(String columnName,String whereClauseName1,String whereCaluseValue1,String whereClauseName2,String whereClauseValue2,String whereClauseName3,String whereClauseValue3){
    	int columnNumber = getColumnNumber(columnName);
    	TableResultSet typeResultSet = null;
    	typeResultSet =new TableResultSet(new String[] {columnName});
    	ArrayList<String> existedEntries = new ArrayList<String>(); 
    	for (int j = 0; j < dataValues.size(); j++) {
    		String[] arrayValues= dataValues.get(j);
    		if(whereClauseName1 != null && whereClauseName1.length() >0){
    			//only one where clause is existed
    			if(whereCaluseValue1 != null && whereCaluseValue1.equals(arrayValues[getColumnNumber(whereClauseName1)])){
    				if(whereClauseName2 != null){
    					// two where clauses are existed
    					if(whereClauseValue2.equals(arrayValues[getColumnNumber(whereClauseName2)])){
    						if(whereClauseName3 != null){
    							if(whereClauseValue3.equals(arrayValues[getColumnNumber(whereClauseName3)])){
    								if(!checkValueExistance(existedEntries,arrayValues[columnNumber])){
    									existedEntries.add(arrayValues[columnNumber]);
    									typeResultSet.add(new String[] {arrayValues[columnNumber]});	
    								}
    							}else{
    								//don'tcare
    								// Value not matched no need to add into ResultSet
    							}
    						}else{
    							if(!checkValueExistance(existedEntries,arrayValues[columnNumber])){
    								existedEntries.add(arrayValues[columnNumber]);
    								typeResultSet.add(new String[] {arrayValues[columnNumber]});	
    							}
    						}
    					}else{
    						//don't care
    						// Value not matched no need to add into ResultSet
    					}	
    				}else{
    					if(!checkValueExistance(existedEntries,arrayValues[columnNumber])){
    						existedEntries.add(arrayValues[columnNumber]);
    						typeResultSet.add(new String[] {arrayValues[columnNumber]});	
    					}
    				}        				
    			}else{
    				//don't care
    				// Value not matched no need to add into ResultSet
    			}
    		}else{
    			///No Where Clause existed
    			if(!checkValueExistance(existedEntries,arrayValues[columnNumber])){
    				existedEntries.add(arrayValues[columnNumber]);
    				typeResultSet.add(new String[] {arrayValues[columnNumber]});	
    			}
    		}
    	}
    	return typeResultSet;
    }
    /**
     * 
     * @param columnName
     * @param whereClauseName1
     * @param whereCaluseValue1
     * @param whereClauseName2
     * @param whereClauseValue2
     * @return
     */
    public TableResultSet getTableResultSetColumnWithWhereClauses(String columnName,String whereClauseName1,String whereCaluseValue1,String whereClauseName2,String whereClauseValue2){
     return getTableResultSetColumnWithWhereClauses(columnName, whereClauseName1, whereCaluseValue1, whereClauseName2, whereClauseValue2,null,null);	
    }
    /**
     * 
     * @param columnName
     * @param whereClauseName1
     * @param whereCaluseValue1
     * @return
     */
    public TableResultSet getTableResultSetColumnWithWhereClauses(String columnName,String whereClauseName1,String whereCaluseValue1){
     return getTableResultSetColumnWithWhereClauses(columnName, whereClauseName1, whereCaluseValue1,null,null,null,null);	
    }
    /**
     * 
     * @param values
     * @param token
     * @return
     */
    public boolean checkValueExistance(ArrayList<String> values,String token){
    	for (int itet1 = 0; itet1 < values.size(); itet1++) {
    		if(token.equals(values.get(itet1))){
    			return true;
    		}
    	}

    	return false;
    }
  
    /**
     * 
     */
    public TableResultSet getTableResultSetMultipleColumnsWithWhereClauses(String[] columnNames,String folderType,String folderTypeValue){
    	TableResultSet typeResultSet = null;
    	if(folderType != null && folderType.length() >0){
    		typeResultSet =new TableResultSet(columnNames);	
    		for (int j = 0; j < dataValues.size(); j++) {
    			String[] arrayValues= dataValues.get(j);
    			if(folderTypeValue.equals(arrayValues[getColumnNumber(folderType)])){
    				String valuesArray[]=new String[columnNames.length];
    				for (int i = 0; i < columnNames.length; i++) {
    					valuesArray[i]=arrayValues[getColumnNumber(columnNames[i])];
					}
    				typeResultSet.add(valuesArray);
    			}else{
    				//don't care
    			}
    		}
    	}
    	return typeResultSet;
    }
    /**
     * 
     * @param columnNames
     * @param whereClauseName1
     * @param whereCaluseValue1
     * @return
     */
    public TableResultSet getTableResultSetColumnWithWhereClauses(String columnNames[],String whereClauseName1,String whereCaluseValue1){
    	return getTableResultSetColumnWithWhereClauses(columnNames,whereClauseName1,whereCaluseValue1,null,null,null,null);	
    }
    /**
     * 
     * @param columnNames
     * @param whereClauseName1
     * @param whereCaluseValue1
     * @param whereClauseName2
     * @param whereCaluseValue2
     * @return
     */
    public TableResultSet getTableResultSetColumnWithWhereClauses(String columnNames[],String whereClauseName1,String whereCaluseValue1,String whereClauseName2,String whereCaluseValue2){
    	return getTableResultSetColumnWithWhereClauses(columnNames,whereClauseName1,whereCaluseValue1,whereClauseName2,whereCaluseValue2,null,null);	
    }
    /**
     * 
     * @param columnNames
     * @param whereClauseName1
     * @param whereCaluseValue1
     * @param whereClauseName2
     * @param whereClauseValue2
     * @param whereClauseName3
     * @param whereClauseValue3
     * @return
     */
    public TableResultSet getTableResultSetColumnWithWhereClauses(String columnNames[],String whereClauseName1,String whereCaluseValue1,String whereClauseName2,String whereClauseValue2,String whereClauseName3,String whereClauseValue3){
    	TableResultSet typeResultSet = null;
    	typeResultSet =new TableResultSet(columnNames);
    	for (int j = 0; j < dataValues.size(); j++) {
    		String[] arrayValues= dataValues.get(j);
    		if(whereClauseName1 != null && whereClauseName1.length() >0){
    			//only one where clause is existed
    			if(whereCaluseValue1 != null && whereCaluseValue1.equals(arrayValues[getColumnNumber(whereClauseName1)])){
    				if(whereClauseName2 != null){
    					// two where clauses are existed
    					if(whereClauseValue2.equals(arrayValues[getColumnNumber(whereClauseName2)])){
    						if(whereClauseName3 != null){
    							if(whereClauseValue3.equals(arrayValues[getColumnNumber(whereClauseName3)])){
    								String valuesArray[]=new String[columnNames.length];
    								for (int i = 0; i < columnNames.length; i++) {
    									valuesArray[i]=arrayValues[getColumnNumber(columnNames[i])];
    								}
    								typeResultSet.add(valuesArray);	
    							}else{
    								//don'tcare
    								// Value not matched no need to add into ResultSet
    							}
    						}else{
    							String valuesArray[]=new String[columnNames.length];
    							for (int i = 0; i < columnNames.length; i++) {
    								valuesArray[i]=arrayValues[getColumnNumber(columnNames[i])];
    							}
    							typeResultSet.add(valuesArray);	
    						}
    					}else{
    						//don't care
    						// Value not matched no need to add into ResultSet
    					}	
    				}else{
    					String valuesArray[]=new String[columnNames.length];
    					for (int i = 0; i < columnNames.length; i++) {
    						valuesArray[i]=arrayValues[getColumnNumber(columnNames[i])];
    					}
    					typeResultSet.add(valuesArray);	
    				}        				
    			}else{
    				//don't care
    				// Value not matched no need to add into ResultSet
    			}
    		}else{
    			///No Where Clause existed
    			String valuesArray[]=new String[columnNames.length];
    			for (int i = 0; i < columnNames.length; i++) {
    				valuesArray[i]=arrayValues[getColumnNumber(columnNames[i])];
    			}
    			typeResultSet.add(valuesArray);	
    		}
    	}
    	return typeResultSet;
    }
    /**
     * 
     * @param columnNames
     * @param whereClauseName1
     * @param whereCaluseValue1
     * @param distinctColumn
     * @return
     */
    public TableResultSet getTableResultSetColumnWithWhereClausesWithDistinct(String columnNames[],String whereClauseName1,String whereCaluseValue1,String distinctColumn){
    	return getTableResultSetColumnWithWhereClausesWithDistinct(columnNames,whereClauseName1,whereCaluseValue1,null,null,null,null,distinctColumn);	
    }
    /**
     * 
     * @param columnNames
     * @param whereClauseName1
     * @param whereCaluseValue1
     * @param whereClauseName2
     * @param whereClauseValue2
     * @param distinctColumn
     * @return
     */
    public TableResultSet getTableResultSetColumnWithWhereClausesWithDistinct(String columnNames[],String whereClauseName1,String whereCaluseValue1,String whereClauseName2,String whereClauseValue2,String distinctColumn){
    	return getTableResultSetColumnWithWhereClausesWithDistinct(columnNames,whereClauseName1,whereCaluseValue1,whereClauseName2,whereClauseValue2,null,null,distinctColumn);	
    }
    /**
     * 
     * @param columnNames
     * @param whereClauseName1
     * @param whereCaluseValue1
     * @param whereClauseName2
     * @param whereClauseValue2
     * @param whereClauseName3
     * @param whereClauseValue3
     * @param distinctColumn
     * @return
     */
    public TableResultSet getTableResultSetColumnWithWhereClausesWithDistinct(String columnNames[],String whereClauseName1,String whereCaluseValue1,String whereClauseName2,String whereClauseValue2,String whereClauseName3,String whereClauseValue3,String distinctColumn){

    	TableResultSet typeResultSet = null;
    	typeResultSet =new TableResultSet(columnNames);
    	ArrayList<String> existedEntries = new ArrayList<String>(); 
    	for (int j = 0; j < dataValues.size(); j++) {
    		String[] arrayValues= dataValues.get(j);
    		if(whereClauseName1 != null && whereClauseName1.length() >0){
    			//only one where clause is existed
    			if(whereCaluseValue1 != null && whereCaluseValue1.equals(arrayValues[getColumnNumber(whereClauseName1)])){
    				if(whereClauseName2 != null){
    					// two where clauses are existed
    					if(whereClauseValue2.equals(arrayValues[getColumnNumber(whereClauseName2)])){
    						if(whereClauseName3 != null){
    							if(whereClauseValue3.equals(arrayValues[getColumnNumber(whereClauseName3)])){
    								if(!checkValueExistance(existedEntries,arrayValues[getColumnNumber(distinctColumn)])){
    									existedEntries.add(arrayValues[getColumnNumber(distinctColumn)]);
    									String valuesArray[]=new String[columnNames.length];
    									for (int i = 0; i < columnNames.length; i++) {
    										valuesArray[i]=arrayValues[getColumnNumber(columnNames[i])];
    									}
    									typeResultSet.add(valuesArray);	
    								}
    							}else{
    								//don'tcare
    								// Value not matched no need to add into ResultSet
    							}
    						}else{
    							if(!checkValueExistance(existedEntries,arrayValues[getColumnNumber(distinctColumn)])){
    								existedEntries.add(arrayValues[getColumnNumber(distinctColumn)]);
    								String valuesArray[]=new String[columnNames.length];
    								for (int i = 0; i < columnNames.length; i++) {
    									valuesArray[i]=arrayValues[getColumnNumber(columnNames[i])];
    								}
    								typeResultSet.add(valuesArray);	
    							}
    						}
    					}else{
    						//don't care
    						// Value not matched no need to add into ResultSet
    					}	
    				}else{
    					if(!checkValueExistance(existedEntries,arrayValues[getColumnNumber(distinctColumn)])){
    						existedEntries.add(arrayValues[getColumnNumber(distinctColumn)]);
    						String valuesArray[]=new String[columnNames.length];
    						for (int i = 0; i < columnNames.length; i++) {
    							valuesArray[i]=arrayValues[getColumnNumber(columnNames[i])];
    						}
    						typeResultSet.add(valuesArray);	
    					}
    				}        				
    			}else{
    				//don't care
    				// Value not matched no need to add into ResultSet
    			}
    		}else{
    			///No Where Clause existed
    			if(!checkValueExistance(existedEntries,arrayValues[getColumnNumber(distinctColumn)])){
    				existedEntries.add(arrayValues[getColumnNumber(distinctColumn)]);
    				String valuesArray[]=new String[columnNames.length];
    				for (int i = 0; i < columnNames.length; i++) {
    					valuesArray[i]=arrayValues[getColumnNumber(columnNames[i])];
    				}
    				typeResultSet.add(valuesArray);	
    			}
    		}
    	}
    	return typeResultSet;
    }
   
    /**
     * 
     * @param columnName
     * @param whereClauseName1
     * @param whereCaluseValue1
     * @return
     */
    public String getTemplateInfoTableValue(String columnName,String whereClauseName1,String whereCaluseValue1){
    	return getTemplateInfoTableValue( columnName, whereClauseName1, whereCaluseValue1,null,null,null,null);
    }
    /**
     * 
     * @param columnName
     * @param whereClauseName1
     * @param whereCaluseValue1
     * @param whereClauseName2
     * @param whereClauseValue2
     * @return
     */
    public String getTemplateInfoTableValue(String columnName,String whereClauseName1,String whereCaluseValue1,String whereClauseName2,String whereClauseValue2){
    	return getTemplateInfoTableValue( columnName, whereClauseName1, whereCaluseValue1,whereClauseName2,whereClauseValue2,null,null);
    }
   /**
    * 
    * @param columnName
    * @param whereClauseName1
    * @param whereCaluseValue1
    * @param whereClauseName2
    * @param whereClauseValue2
    * @param whereClauseName3
    * @param whereClauseValue3
    * @return
    */
    public String getTemplateInfoTableValue(String columnName,String whereClauseName1,String whereCaluseValue1,String whereClauseName2,String whereClauseValue2,String whereClauseName3,String whereClauseValue3){
 	   String  resultValue = "";
 	   for (int dataValuesIterator = 0; dataValuesIterator < templateNameTableDataValues.size(); dataValuesIterator++) {
 		   String[] arrayValues= templateNameTableDataValues.get(dataValuesIterator);
 		   if(whereClauseName1 != null && whereClauseName1.length() >0){
 			   //only one where clause is existed
 			   if(whereCaluseValue1 != null && whereCaluseValue1.equals(arrayValues[getTemplateDetailsColumnNumber(whereClauseName1)])){
 				   if(whereClauseName2 != null){
 					   // two where clauses are existed
 					   if(whereClauseValue2.equals(arrayValues[getTemplateDetailsColumnNumber(whereClauseName2)])){
 						   if(whereClauseName3 != null){
 							   if(whereClauseValue3.equals(arrayValues[getTemplateDetailsColumnNumber(whereClauseName3)])){
 								   resultValue=arrayValues[getTemplateDetailsColumnNumber(columnName)];
 								   }else{
 									   //don'tcare
 									   //Value not matched no need to add into ResultSet
 									   }
 							   }else{
 								      resultValue=arrayValues[getTemplateDetailsColumnNumber(columnName)];
 								   }
 						   }else{
 							   //don't care
 							   //Value not matched no need to add into ResultSet
 							   }
 					   }else{
 						   resultValue=arrayValues[getTemplateDetailsColumnNumber(columnName)];
 						   }
 				   }else{
 					   //don't care
     				   // Value not matched no need to add into ResultSet
     			   }
 			   }else{
     				//No Where Clause existed
     				resultValue=arrayValues[getTemplateDetailsColumnNumber(columnName)];
     			}
     		}
     	return resultValue;
     } 
    
   /**
    * 
    * @param columnName
    * @param whereClauseName1
    * @param whereCaluseValue1
    * @param whereClauseName2
    * @param whereClauseValue2
    * @param distinctColumn
    * @return
    */
   public String getTemplateInfoTableValuesWithDistinct(String columnName,String whereClauseName1,String whereCaluseValue1,String whereClauseName2,String whereClauseValue2,String distinctColumn){
    	return getTemplateInfoTableValuesWithDistinct( columnName, whereClauseName1, whereCaluseValue1,whereClauseName2,whereClauseValue2,null,null, distinctColumn);
   }
   /**
    * 
    * @param columnName
    * @param whereClauseName1
    * @param whereCaluseValue1
    * @param distinctColumn
    * @return
    */
   public String getTemplateInfoTableValuesWithDistinct(String columnName,String whereClauseName1,String whereCaluseValue1,String distinctColumn){
    	return getTemplateInfoTableValuesWithDistinct( columnName, whereClauseName1, whereCaluseValue1,null,null,null,null, distinctColumn);
   }
    /**
     * 
     * @param columnName
     * @param whereClauseName1
     * @param whereCaluseValue1
     * @param whereClauseName2
     * @param whereClauseValue2
     * @param whereClauseName3
     * @param whereClauseValue3
     * @param distinctColumn
     * @return
     */
   public String getTemplateInfoTableValuesWithDistinct(String columnName,String whereClauseName1,String whereCaluseValue1,String whereClauseName2,String whereClauseValue2,String whereClauseName3,String whereClauseValue3,String distinctColumn){
	   String  resultValue = "";
	   ArrayList<String> existedEntries = new ArrayList<String>();
	   for (int dataValuesIterator = 0; dataValuesIterator < dataValues.size(); dataValuesIterator++) {
		   String[] arrayValues= dataValues.get(dataValuesIterator);
		   if(whereClauseName1 != null && whereClauseName1.length() >0){
			   //only one where clause is existed
			   if(whereCaluseValue1 != null && whereCaluseValue1.equals(arrayValues[getColumnNumber(whereClauseName1)])){
				   if(whereClauseName2 != null){
					   // two where clauses are existed
					   if(whereClauseValue2.equals(arrayValues[getColumnNumber(whereClauseName2)])){
						   if(whereClauseName3 != null){
							   if(whereClauseValue3.equals(arrayValues[getColumnNumber(whereClauseName3)])){
								   if(!checkValueExistance(existedEntries,arrayValues[getColumnNumber(distinctColumn)])){
									   existedEntries.add(arrayValues[getColumnNumber(distinctColumn)]);
									   resultValue=arrayValues[getColumnNumber(columnName)];
									   }
								   }else{
									   //don'tcare
									   //Value not matched no need to add into ResultSet
									   }
							   }else{
								   if(!checkValueExistance(existedEntries,arrayValues[getColumnNumber(distinctColumn)])){
									   existedEntries.add(arrayValues[getColumnNumber(distinctColumn)]);
									   resultValue=arrayValues[getColumnNumber(columnName)];
									   }
								   }
						   }else{
							   //don't care
							   //Value not matched no need to add into ResultSet
							   }
					   }else{
						   if(!checkValueExistance(existedEntries,arrayValues[getColumnNumber(distinctColumn)])){
							   existedEntries.add(arrayValues[getColumnNumber(distinctColumn)]);
							   resultValue=arrayValues[getColumnNumber(columnName)];
							   }
						   }
				   }else{
					   //don't care
    				   // Value not matched no need to add into ResultSet
    			   }
			   }else{
    				//No Where Clause existed
    			if(!checkValueExistance(existedEntries,arrayValues[getColumnNumber(distinctColumn)])){
    				existedEntries.add(arrayValues[getColumnNumber(distinctColumn)]);
    				resultValue=arrayValues[getColumnNumber(columnName)];
    				}
    			}
    		}
    	return resultValue;
    }
    /**
     * 
     * @param columnNames
     * @param whereClauseName1
     * @param whereCaluseValue1
     * @param whereClauseName2
     * @param whereClauseValue2
     * @param whereClauseName3
     * @param whereClauseValue3
     * @param distinctColumn
     * @return
     */
    public String[] getTableResultSetColumnWithWhereClausesWithDistinctAsArray(String columnNames[],String whereClauseName1,String whereCaluseValue1,String whereClauseName2,String whereClauseValue2,String whereClauseName3,String whereClauseValue3,String distinctColumn){
    	String[] typeResultSet = new String[columnNames.length];
    	ArrayList<String> existedEntries = new ArrayList<String>(); 
    	for (int j = 0; j < dataValues.size(); j++) {
    		String[] arrayValues= dataValues.get(j);
    		if(whereClauseName1 != null && whereClauseName1.length() >0){
    			//only one where clause is existed
    			if(whereCaluseValue1 != null && whereCaluseValue1.equals(arrayValues[getColumnNumber(whereClauseName1)])){
    				if(whereClauseName2 != null){
    					// two where clauses are existed
    					if(whereClauseValue2.equals(arrayValues[getColumnNumber(whereClauseName2)])){
    						if(whereClauseName3 != null){
    							if(whereClauseValue3.equals(arrayValues[getColumnNumber(whereClauseName3)])){
    								if(!checkValueExistance(existedEntries,arrayValues[getColumnNumber(distinctColumn)])){
    									existedEntries.add(arrayValues[getColumnNumber(distinctColumn)]);
    									for (int i = 0; i < columnNames.length; i++) {
    										typeResultSet[i]=arrayValues[getColumnNumber(columnNames[i])];;
    									}
    										
    								}
    							}else{
    								//don'tcare
    								// Value not matched no need to add into ResultSet
    							}
    						}else{
    							if(!checkValueExistance(existedEntries,arrayValues[getColumnNumber(distinctColumn)])){
    								existedEntries.add(arrayValues[getColumnNumber(distinctColumn)]);
    								for (int i = 0; i < columnNames.length; i++) {
										typeResultSet[i]=arrayValues[getColumnNumber(columnNames[i])];;
									}
    							}
    						}
    					}else{
    						//don't care
    						// Value not matched no need to add into ResultSet
    					}	
    				}else{
    					if(!checkValueExistance(existedEntries,arrayValues[getColumnNumber(distinctColumn)])){
    						existedEntries.add(arrayValues[getColumnNumber(distinctColumn)]);
    						for (int i = 0; i < columnNames.length; i++) {
								typeResultSet[i]=arrayValues[getColumnNumber(columnNames[i])];;
							}
    					}
    				}        				
    			}else{
    				//don't care
    				// Value not matched no need to add into ResultSet
    			}
    		}else{
    			///No Where Clause existed
    			if(!checkValueExistance(existedEntries,arrayValues[getColumnNumber(distinctColumn)])){
    				existedEntries.add(arrayValues[getColumnNumber(distinctColumn)]);
    				for (int i = 0; i < columnNames.length; i++) {
						typeResultSet[i]=arrayValues[getColumnNumber(columnNames[i])];;
					}
    			}
    		}
    	}
    	return typeResultSet;
    }
    /**
     * 
     * @param columnNames
     * @param folderType
     * @return
     */
    public TableResultSet getTableResultSetMultipleColumnsWithWhereClauses(String[] columnNames,String folderType){
    	TableResultSet typeResultSet = null;
    	if(folderType != null && folderType.length() >0){
    		typeResultSet =new TableResultSet(columnNames);	
    		for (int j = 0; j < dataValues.size(); j++) {
    			String[] arrayValues= dataValues.get(j);
    			if(folderType.equals(arrayValues[getColumnNumber(folderType)])){
    				String valuesArray[]=new String[columnNames.length];
    				for (int i = 0; i < columnNames.length; i++) {
    					valuesArray[i]=arrayValues[getColumnNumber(columnNames[i])];
					}
    				typeResultSet.add(valuesArray);
    			}else{
    				//don't care
    			}
    		}
    	}
    	return typeResultSet;
    }
    /**
     * 
     * @param columnName
     * @return
     */
    private int getColumnNumber(String columnName){
    	if(columnName.equals(STR_DOC_TYPE_CODE)){
    		return Integer.parseInt(doc_type_code);	
    	}else if(columnName.equals(STR_DOC_TYPE_NUMBER)){
    		return Integer.parseInt(doc_type_name);
    	}if(columnName.equals(STR_SUB_FOLDER_TITLE)){
    		return Integer.parseInt(subfolder_title);
    	}else if(columnName.equals(STR_IS_ACTIVE)){
    		return Integer.parseInt(is_active);
    	}else if(columnName.equals(STR_FOLDER_CATEGORY)){
    		return Integer.parseInt(folder_category);
    	}else if(columnName.equals(STR_DATE_TIME_STAMP)){
    		return Integer.parseInt(datetime_stamp);
    	}else if(columnName.equals(STR_USER_ID)){
    		return Integer.parseInt(user_id);
    	}else  return -1;
    	
    	
    }
    
    private int getTemplateDetailsColumnNumber(String columnName){
    	if(columnName.equals(ATTR_TEMPLATE_TITLE)){
    		return template_details_template_title;
    	}else if(columnName.equals(ATTR_TEMPLATE_CODE)){
    		return template_details_template_code;
    	}else if(columnName.equals(ATTR_FOLDER_CATEGORY)){
    		return template_details_folder_category;
    	}else return -1;	
    }
    
    
    /**
     * 
     * @param folderCategory
     * @return
     */
    public static int getFolderCategoryNumber(String folderCategory){
		  int faloderCategoryNumber=0;
		  if(folderCategory.equals(NON_OPERATIONAL)){
			  faloderCategoryNumber=NON_OPERATIONAL_NUMBER;
		  }else if(folderCategory.equals(INSTITUTION)){
			  faloderCategoryNumber= INSTITUTION_NUMBER;
		  }else if(folderCategory.equals(MANAGEMENT_AND_ADMIN)){
			  faloderCategoryNumber= MANAGEMENT_AND_ADMIN_NUMBER;
		  }else if(folderCategory.equals(COUNTRY_DOCUMENTS)){
			  faloderCategoryNumber=COUNTRY_DOCUMENTS_NUMBER;
		  }else if(folderCategory.equals(ADVISORY_SERVICES)){
			  faloderCategoryNumber= ADVISORY_SERVICES_NUMBER;
		  }else if(folderCategory.equals(INVESTMENT_OPERATION)){
			  faloderCategoryNumber= INVESTMENT_OPERATION_NUMBER;
		  }else if(folderCategory.equals(NON_INVESTMENT_OPERATION)){
			  faloderCategoryNumber= NON_INVESTMENT_OPERATION_NUMBER;
		  }
		  DfLogger.debug(DocTypeTableStructure.class,"Folder Category "+folderCategory +"  Return folder category Number "+faloderCategoryNumber ,null,null);
		  return faloderCategoryNumber;
	}
    
    private static int template_details_template_title =0;
    private static int template_details_folder_category=1;
    private static int template_details_template_code =2;
    
    private String doc_type_code ="0";
    private String doc_type_name ="1";
    private String subfolder_title ="2";
    private String is_active ="3";
    private String folder_category ="4";
    private String datetime_stamp="5";
    private String user_id="6";
     
    private static String ATTR_TEMPLATE_TITLE="template_title";
    private static String ATTR_TEMPLATE_CODE="template_code";
    private static String ATTR_FOLDER_CATEGORY="folder_category";
     
    private String STR_DOC_TYPE_CODE="doc_type_code";
    private String STR_DOC_TYPE_NUMBER="doc_type_name";
    private String STR_SUB_FOLDER_TITLE="subfolder_title";
    private String STR_IS_ACTIVE="is_active";
    private String STR_FOLDER_CATEGORY="folder_category";
    private String STR_DATE_TIME_STAMP="datetime_stamp";
    private String STR_USER_ID="user_id";
     
    public static final int NON_OPERATIONAL_NUMBER=1;
    public static final int INSTITUTION_NUMBER =2;  
	public static final int MANAGEMENT_AND_ADMIN_NUMBER=3;
	public static final int COUNTRY_DOCUMENTS_NUMBER=4;
	public static final int ADVISORY_SERVICES_NUMBER=5;
	public static final int INVESTMENT_OPERATION_NUMBER=6;
	public static final int NON_INVESTMENT_OPERATION_NUMBER=7;
	 
	 
	public static String NON_OPERATIONAL="Non-Operational";
	public static String INSTITUTION ="Institution";  
	public static String MANAGEMENT_AND_ADMIN="Management & Admin";
	public static String COUNTRY_DOCUMENTS="Country Documents";
	public static String ADVISORY_SERVICES="Advisory Services";
	public static String INVESTMENT_OPERATION="Investment Operations";
	public static String NON_INVESTMENT_OPERATION="Non-Investment Projects";
}
