package org.ifc.idocs.migration.common;

/**
 * @author VVellakkattumana
 * @category MigWfAuditReport is a java template class for easy implementation of workflows
 *
 */
public class MigWfAuditReport {
	
	private String workflowId;
	private String workflowName;
	private String documentName;
	private String documentId;	
	
	public String getWorkflowId() {
		return workflowId;
	}
	public void setWorkflowId(String workflowId) {
		this.workflowId = workflowId;
	}
	public String getWorkflowName() {
		return workflowName;
	}
	public void setWorkflowName(String workflowName) {
		this.workflowName = workflowName;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
}
