/**
* This class displays the workflow process diagram template
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.workflow.processdiagram;

import java.io.File;

import javax.servlet.http.HttpServletRequest;

import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfQueueItem;
import com.documentum.fc.client.IDfWorkitem;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.services.workflow.inbox.ITask;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.formext.component.Component;
import com.documentum.webcomponent.library.workflow.WorkflowService;
import com.documentum.webcomponent.library.workflow.taskmanager.ITaskStateContainer;
public class ProcessDiagram extends Component
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String m_workflowIdStr;
	private String strWorkflowid="";
	private String strProcessid="";
	private String strHeight="";
	private String strWidth="";
	private String strProcessName="";
	private Process process= null; 
	private String strSvgLocation= ""; 
	private String strSvgProcessDiagramFileLocation= ""; 
	String strTaskId = "";
	private String strSVGLocationToDelete = "";
	
	public ProcessDiagram(){
		
	}

	public void onInit(ArgumentList arg){
		super.onInit(arg);
		strTaskId = arg.get("objectId");	
	}
	
	public void onRender() {
		DfLogger.info(this," :: onInit :: strTaskId : " + strTaskId, null, null);
		try{
			DfLogger.info(this, " :: onInit : "+getDfSession().getLoginUserName(), null, null);
			if (WorkflowService.isWorkflowId(strTaskId) == true)
			{
				this.m_workflowIdStr = strTaskId;
			}
			else if (WorkflowService.isWorkitemId(strTaskId) == true)
			{
				IDfWorkitem workItemObj = (IDfWorkitem)getDfSession().getObject(new DfId(strTaskId));
				this.m_workflowIdStr = workItemObj.getWorkflowId().toString();
			}
			else
			{
				IDfQueueItem queueItemObj = (IDfQueueItem)getDfSession().getObject(new DfId(strTaskId));
				this.m_workflowIdStr = queueItemObj.getRouterId().toString();
			}
			strWorkflowid=this.m_workflowIdStr;
			process = new Process();  
			DfLogger.info(this," :: onInit :: strWorkflowid :: " + strWorkflowid, null, null);
			strProcessid=process.getProcessIdByInstanceId(strWorkflowid, getDfSession());
			DfLogger.info(this," :: onInit :: strProcessid :: " + strProcessid, null, null);
			process.setInstanceId(strWorkflowid);
			process.setId(strProcessid);
			WFProcessDiagram objWFProcessDiagram = new WFProcessDiagram();
			loadXslToSvg();
			process = objWFProcessDiagram.transformProcessDiagram(process,getDfSession());
			strHeight=process.getSvgHeight();
			strWidth=process.getSvgWidth();
			strProcessName=process.getName();
			strSVGLocationToDelete = process.svgLocation;
		}catch(Exception localException){
			DfLogger.error(this," :: onInit Exception >> "+localException.getMessage(), null, localException);
		}
		super.onRender();
	}
	
	public void noSVGSupport(Control control, ArgumentList args){
		setComponentPage("nosvg");
	}
	
	
	public void onExit() {
		super.onExit();
		try {
			File tempSVGFile = new File(strSVGLocationToDelete);
			DfLogger.info(this, "strSvgLocation"+strSVGLocationToDelete, null,null);
			tempSVGFile.deleteOnExit();
		} catch (Exception e) {
			DfLogger.info(this, "<<Exception>>"+e.getMessage(), null, e);
		}
	    
	} 
	
	public void onRefreshData()
	{
		super.onRefreshData();
	}

	private void loadXslToSvg()
	{
		try{
			HttpServletRequest req = (HttpServletRequest) getPageContext().getRequest();
			String strContextPath =req.getContextPath();
			String strAppRealPath=getPageContext().getServletContext().getRealPath("/");
			String str1 = IdocsUtil.getMessage(IdocsConstants.STR_XSL_TO_SVG); 
			String str2 = getPageContext().getServletContext().getRealPath(str1);
			DashboardEnv.setKeyValue(IdocsConstants.STR_XSL_TO_SVG, str2);
			String str3 = IdocsUtil.getMessage(IdocsConstants.STR_SVG_PROCESS_DIAGRAM_FILES_LOCATION);
			DashboardEnv.setKeyValue(IdocsConstants.STR_SVG_PROCESS_DIAGRAM_VIRTUAL_LOCATION, str3);
			this.strSvgProcessDiagramFileLocation = str3;
			str2 = getPageContext().getServletContext().getRealPath(str3);
			DashboardEnv.setKeyValue(IdocsConstants.STR_SVG_PROCESS_DIAGRAM_FILES_LOCATION, str2);
			String str4 = IdocsUtil.getMessage(IdocsConstants.STR_SVG_IMAGE_ICON_LOCATION);
			DfLogger.info(this, getPageContext().getServletContext().getRealPath(str4).toString(), null, null);
			DfLogger.info(this, "====>"+strContextPath+str4, null, null);
			
			DashboardEnv.setKeyValue(IdocsConstants.STR_SVG_IMAGE_ICON_LOCATION, strContextPath+str4);
			DashboardEnv.setKeyValue(IdocsConstants.STR_SVG_IMAGE_ICON_LOCATION_REAL_PATH, getPageContext().getServletContext().getRealPath(str4));
		}catch(Exception localException){
			DfLogger.error(this," :: loadXslToSvg Exception >> " + localException.getMessage(), null, localException);
		}	
	}
	private ITask getInboxTask()
	{
		return ((ITaskStateContainer)getTopForm()).getTaskState();
	}

	public String getSvgProcessDiagramFileLocation()
	{
		return this.strSvgProcessDiagramFileLocation;
	}
	public String getWorkflowid()
	{
		return this.strWorkflowid;
	}
	public String getProcessid()
	{
		return this.strProcessid;
	}

	public String getHeight()
	{
		return this.strHeight;
	}
	public String getWidth()
	{
		return this.strWidth;
	}
	public String getProcessName()
	{
		return this.strProcessName;
	}
	public String getSvgLocation()
	{
		return this.strSvgLocation;
	}
	
	
}
