package org.ifc.idocs.migration.extract;

import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Vector;
import java.util.logging.Level;

import lotus.domino.Document;
import lotus.domino.EmbeddedObject;
import lotus.domino.NotesError;
import lotus.domino.NotesException;
import lotus.domino.RichTextItem;

import org.ifc.idocs.migration.ExtractCommon;
import org.ifc.idocs.migration.ExtractDocuments;
/**
 * @author SPankajamsadanan
 *
 */
class DomdocContent implements iDocsContent {

	private String filename;
	private Document doc;
	private static ExtractCommon fileNull = null;
	private java.util.logging.Logger exportDocLogger = LogHelper.getLogger(ExtractDocuments.class);
	String docid= null;
	/**
	 * DomdocContent constructor
	 * @param doc
	 * @throws UnsupportedEncodingException 
	 */
	
	DomdocContent(Document doc){
		try {
//			*Added by soumya to capture filename null into extraction skipped table
			fileNull = new ExtractCommon(); //*
			this.doc = doc;
			this.filename = doc.getItemValueString("Filename");
			if (this.filename.length() == 0) {
				throw new NotesException(NotesError.NOTES_ERR_ERROR, "Document " + doc.getUniversalID() + ": File name field is blank");
			}
		} catch (NotesException e) {
			try {
				fileNull.listSkipDocuments(this.doc, docid , "FileName of the document is null", "ER_033");//*
			} catch (NotesException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"Exception", e);
		}
	}

	/**
	 * export method 
	 * @see org.ifc.idocs.migration.extract.iDocsContent#export(java.lang.String)
	 * @param path
	 */
	@SuppressWarnings("unchecked")
	public String export(String path) throws NotesException {
		String extractFilename = null, docid = doc.getItemValueString("docid");
		fileNull = new ExtractCommon();
		if (doc.hasItem("Body")) { 
			if (path.length() > max_path - 4) {
				throw new NotesException(NotesError.NOTES_ERR_ERROR, "Exceeding maximum path length on path " + path);
			}
			if (path.length() + filename.length() > max_path) {
				extractFilename = filename.substring(0, max_path - 5 - path.length()) + filename.substring(filename.length() - 4, filename.length());
				exportDocLogger.warning("Truncating filename from " + filename + " to " + extractFilename);
			} else {
				extractFilename = filename;
			}
			
			try{
//				Extracting document content here 
				doc.getAttachment(filename).extractFile(path + extractFilename);					
			}
			catch(NullPointerException ne){
//				if file name contains special char
				RichTextItem body = (RichTextItem)doc.getFirstItem("Body");
				Vector v = body.getEmbeddedObjects();
				Enumeration enm = v.elements();
				while (enm.hasMoreElements()) {
					EmbeddedObject eo = (EmbeddedObject) enm.nextElement();
					eo.extractFile(path + extractFilename);
				}
			}
		} else {			
			fileNull.listSkipDocuments(this.doc, docid , "Document does not have the item body", "ER_037");
			exportDocLogger.log(Level.WARNING, docid + " ~ Document does not have the item body"); 
		}
		return path.substring(path.lastIndexOf("\\") + 1, path.length()) + extractFilename;
	}
}
