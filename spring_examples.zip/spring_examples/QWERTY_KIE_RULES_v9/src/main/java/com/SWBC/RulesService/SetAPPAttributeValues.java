package com.SWBC.RulesService;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.sql.DataSource;

import org.apache.commons.dbutils.BasicRowProcessor;
import org.apache.commons.dbutils.BeanProcessor;
import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.SWBC.DataService.TrecService;
import com.SWBC.model.Brm_app_info;
import com.SWBC.model.Brm_request_info;
import com.SWBC.model.Trec;
import com.SWBC.utilities.BRMUtilities;



import com.SWBC.model.Brm_request_info;
import com.SWBC.model.Trec;

@Service("SetAPPAttributeValues")
public class SetAPPAttributeValues extends BeanListHandler<Trec> {

	@Autowired
	private Environment env;
	@Autowired
	private TrecService trecService;

	@Autowired
	private DataSource dataSource;

	public static Map<String, String> getAppColMap() {
		Map<String, String> myMap = new HashMap<String, String>();

		Properties prop = new Properties();
		InputStream input = null;

		try {

			input = SetAPPAttributeValues.class.getClassLoader().getResourceAsStream("appinfo_trec_mapping.properties");

			prop.load(input);

			Enumeration<?> e = prop.propertyNames();
			while (e.hasMoreElements()) {
				String key = (String) e.nextElement();
				String value = prop.getProperty(key);

				myMap.put(key, value);

			}

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return myMap;
	}

	public SetAPPAttributeValues() {
		super(Trec.class, new BasicRowProcessor(new BeanProcessor(mapColumnsToFields())));
	}

	public static Map<String, String> mapColumnsToFields() {
		Map<String, String> columnsToFieldsMap = new HashMap<String, String>();
		


		for (Map.Entry<String, String> entry : getAppColMap().entrySet()) {

			columnsToFieldsMap.put(entry.getKey(), entry.getValue());

		}

		return columnsToFieldsMap;
	}

	public List<Trec> setApp(Trec trec, Brm_request_info brm_request_info) {

		SetAPPAttributeValues appObj = new SetAPPAttributeValues();
		
		List<Trec> trecList = new ArrayList<Trec>();

		QueryRunner queryRunner = new QueryRunner();
		DbUtils.loadDriver(env.getRequiredProperty("jdbc.driverClassName"));

		try {

			if(!brm_request_info.getTid().equalsIgnoreCase("all")) {
				
			

			
				trecList = queryRunner.query(dataSource.getConnection(), env.getRequiredProperty("select.app.tbl.single.input.qur"), appObj, 
						brm_request_info.getTid(),
						brm_request_info.getLoan_no(),
						brm_request_info.getLoan_suffix(),
						brm_request_info.getCov_type(),
						brm_request_info.getAcc_no(),
						brm_request_info.getUser());
				
			}
			else
			{
				
				if(brm_request_info.getTransType().equalsIgnoreCase("NBSALL"))
				{
					String sql = env.getRequiredProperty("select.app.tbl.input.qur.NBSALL").replaceAll("#R",env.getRequiredProperty("select.transaction.nbs.types.NBSALL") );
					
					
					trecList = queryRunner.query(dataSource.getConnection(), sql, appObj, 
							brm_request_info.getUser());
				}
				
				else
				{
					trecList = queryRunner.query(dataSource.getConnection(), env.getRequiredProperty("select.app.tbl.input.qur"), 
							appObj, brm_request_info.getUser(),"%"+brm_request_info.getTransType()+"%");
				}
				
				

			}
			
		

		} catch (Exception e) {

		}

		return trecList;
	}


}
