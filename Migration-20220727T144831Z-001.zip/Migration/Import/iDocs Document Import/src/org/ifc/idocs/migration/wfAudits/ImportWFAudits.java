package org.ifc.idocs.migration.wfAudits;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.ifc.idocs.migration.helper.IDocsEmailConstants;
import org.ifc.idocs.migration.helper.UpdateDB;
import org.ifc.idocs.migration.helper.Utilities;
import org.ifc.idocs.migration.importUtility.ImportUtility;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
/**
 * ImportWFAudits - Uploading workflow audits for every documents successfully uploaded. 
 * @author HAnuganti
 * 
 * #############################################################################################
 * Author		            DateofChange	 Version	  ModificationHistory
 * ###########################################################################################
 * Hemachandra Anuganti 
 * ###########################################################################################
 * 
 */
public class ImportWFAudits extends ImportUtility{

	protected static String dctmObjID,workflow_id,workflow_name,document_name,document_id,act_id,activity_name,assigned_to,performed_by,action,activity_audit_trail,queryRegion,queryLegacyID;
	protected static String insertAuditReportQry,qryTimeStampAuditTrail,insertAuditDetailsQry,insertAuditActivityQry,dctmObjectID,qryWflowIDandCnt,qryActIDandCnt,qryAuditTrailEntry;
	protected static Timestamp timestamp;
	protected static String activity_id,queryWFIDcnt,queryActIDcnt;
	protected static boolean txStartedHere = false;
//	protected static ResultSet extrInfo,getMigrationInfo,getWfID----CntInfo,getActID---CntInfo,getAuditTrailInfo,updateRollbackcolumn;
	protected static String wflowIDandCnt,strInsertIntoAuditReportTable,strInsertIntoAuditDetailsTable,strInsertIntoAuditTrailTable,strQryRollBack;
	protected static String times,dctmTimeStamp,oracleTimeStamp;
	protected static String timestampStr,timestampAuditTrail;	
	protected static String region="";
	protected static String legacyDocId="";
	protected static boolean boolAuditReport,boolAuditDetails,boolAuditTrail;
	protected static ArrayList wfIDList = new ArrayList();
	private static void updateRegionTBL() throws SQLException {
		// TODO Auto-generated method stub
		
		 try {
			 dfSession.abortTrans();
			 boolAuditReport=false;
			 boolAuditDetails=false;
			 boolAuditTrail=false;
			dfSession.beginTrans();
			String regRollBack=region;
		     String legacyDocIdRollBack=legacyDocId;
		     String extIdRollBack=extractionID;
		     strQryRollBack=idocsProperties.getProperty("MSG_DB_ROLLBACK_UPDATE");
		     strQryRollBack=strQryRollBack.replaceFirst("<region>",regRollBack);
		     strQryRollBack=strQryRollBack.replaceFirst("'<legacyID>'", "'" + legacyDocIdRollBack + "'");
		     strQryRollBack=strQryRollBack.replaceFirst("'<extraction_utility_code>'", "'" + extIdRollBack + "'");
//		     UpdateDB.updateDatabase(strQryRollBack.toString()); 
		     Utilities.addToWFArrayList(strQryRollBack.toString());
		    
		     
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException while updateRegionTBL");
			importDocLogger.log(Level.WARNING,"DfException while updateRegionTBL", e);
			e.printStackTrace();
		}	
		  
	}

	private static boolean insertAuditReportTable(IDfSession dfSession, String strInsertIntoAuditReportTable) throws DfException {
		// TODO Auto-generated method stub
		//importDocLogger.info("insertAuditReportTable(String strInsertIntoAuditReportTable) method ::"+ImportWFAudits.class);
		//importDocLogger.info("Building the query for Inserting into Audit Report Table");
		IDfCollection insertAuditReportInfo = null;
		boolean boolAuditReport=false;
		strInsertIntoAuditReportTable=strInsertIntoAuditReportTable.replaceFirst("'<dctmObjectID>'", "'" + dctmObjID + "'");
		//importDocLogger.info("Building the query Documentum ID>>"+dctmObjID);
		strInsertIntoAuditReportTable = strInsertIntoAuditReportTable.replaceFirst("'<workflow_id>'", "'" + workflow_id + "'");
		//importDocLogger.info("Building the query Workflow ID>>"+workflow_id);
		strInsertIntoAuditReportTable = strInsertIntoAuditReportTable.replaceFirst("'<workflow_name>'", "'" + workflow_name + "'");
		//importDocLogger.info("Building the query Workflow Name>>"+workflow_name);
			if(document_name != null && document_name!=""){
				document_name = document_name.replaceAll("'", "''");
			}else{
				document_name = "";
			}
			
		strInsertIntoAuditReportTable = strInsertIntoAuditReportTable.replaceFirst("'<document_name>'", "'" + document_name + "'");
		//importDocLogger.info("Building the query Documentum Name>>"+document_name);
		strInsertIntoAuditReportTable = strInsertIntoAuditReportTable.replaceFirst("'<documentid>'", "'" + document_id + "'");
		//importDocLogger.info("Building the query Legacy Doc ID>>"+document_id);
		//importDocLogger.info("Building the Query>>"+strInsertIntoAuditReportTable);		
		//System.out.println("Building the Query>>"+strInsertIntoAuditReportTable);
		//importDocLogger.info("Executing the Query>>");
		if(!dfSession.isTransactionActive()){
			dfSession.beginTrans();
		}
		System.out.println(strInsertIntoAuditReportTable);
		insertAuditReportInfo = Utilities.executeQuery(dfSession, strInsertIntoAuditReportTable, IDfQuery.DF_EXEC_QUERY);
		//importDocLogger.info("Query Executed Successfull");		
		boolAuditReport=true;	
			if(insertAuditReportInfo.next()){
				//importDocLogger.info("Closing the Collection insertAuditReportInfo");	
				insertAuditReportInfo.close();
				//importDocLogger.info("Closed the Collection insertAuditReportInfo");	
			}//end of IF for closing the collection			
         return boolAuditReport;
	}//End of insertAuditReportTable method
	
	private static boolean insertAuditDetailsTable(String strInsertIntoAuditDetailsTable) throws DfException {
		
		// TODO Auto-generated method stub
		//importDocLogger.info("insertAuditDetailsTable(String strInsertIntoAuditDetailsTable) method ::"+ImportWFAudits.class);
		//importDocLogger.info("Building the query for Inserting into Audit Details");
		IDfCollection insertAuditDetailsInfo = null;
		boolAuditDetails=false;
		strInsertIntoAuditDetailsTable = strInsertIntoAuditDetailsTable.replaceFirst("'<workflow_id>'", "'" + workflow_id + "'");
		//importDocLogger.info("Building the query Workflow ID>>"+workflow_id);
		strInsertIntoAuditDetailsTable = strInsertIntoAuditDetailsTable.replaceFirst("'<activity_id>'", "'" + act_id + "'");
		//importDocLogger.info("Building the query Activity ID>>"+act_id);
			if(activity_name != null && activity_name!=""){
				activity_name = activity_name.replaceAll("'", "''");
			}else{
				activity_name = "";
			}
			
		strInsertIntoAuditDetailsTable = strInsertIntoAuditDetailsTable.replaceFirst("'<workflowactivityname>'", "'" + activity_name+ "'");
		//importDocLogger.info("Building the query Activity Name>>"+activity_name);
		strInsertIntoAuditDetailsTable = strInsertIntoAuditDetailsTable.replaceFirst("'<timestamp>'", "DATE('" + timestampStr + "','dd-mon-yyyy hh:mi:ss')");
		//importDocLogger.info("Building the query Timestamp>>"+timestampStr);
			
			if(assigned_to != null && assigned_to!=""){
				assigned_to = assigned_to.replaceAll("'", "''");
			}else{
				assigned_to = "";
			}
			
		strInsertIntoAuditDetailsTable = strInsertIntoAuditDetailsTable.replaceFirst("'<activityassignedto>'", "'" + assigned_to + "'");
		//importDocLogger.info("Building the query Assigned To>>"+assigned_to);
			
			if(performed_by != null && performed_by!=""){
				performed_by = performed_by.replaceAll("'", "''");
			}else{
				performed_by = "";
			}
			
		strInsertIntoAuditDetailsTable = strInsertIntoAuditDetailsTable.replaceFirst("'<actionperformedby>'", "'" + performed_by + "'");
		//importDocLogger.info("Building the query Performed By>>"+performed_by);
			if(action != null && action!=""){
				action = action.replaceAll("'", "''");
			}else{
				action = "";
			}
			
		strInsertIntoAuditDetailsTable = strInsertIntoAuditDetailsTable.replaceFirst("'<actionperformed>'", "'" + action + "'");
		//importDocLogger.info("Building the query Action>>"+action);
		importDocLogger.info("Building the Query>>"+strInsertIntoAuditDetailsTable);	
			
		//importDocLogger.info("Executing the Query>>");	
		insertAuditDetailsInfo = Utilities.executeQuery(dfSession, strInsertIntoAuditDetailsTable, IDfQuery.DF_EXEC_QUERY);
		//importDocLogger.info("Query Executed Successfull");	
		boolAuditDetails=true;	
			//if(insertAuditDetailsInfo != null && insertAuditDetailsInfo.next()){
		if(insertAuditDetailsInfo.next()){
			//importDocLogger.info("Closing the Collection insertAuditDetailsInfo");	
				insertAuditDetailsInfo.close();
				//importDocLogger.info("Closed the Collection insertAuditDetailsInfo");	
			}//End of IF for closing collection
		return boolAuditDetails;
}//end of insertAuditDetailsTable method
	
	
	private static boolean insertAuditTrailTable(String strInsertIntoAuditTrailTable) throws DfException {
		// TODO Auto-generated method stub
		//importDocLogger.info("insertAuditTrailTable(String strInsertIntoAuditTrailTable) method ::"+ImportWFAudits.class);
		//System.out.println("test1");
		IDfCollection insertAuditActivityInfo = null;
		boolean boolAuditTrail=false;
		try{
		if(activity_audit_trail != "" && activity_audit_trail != null
				&& act_id != "" && act_id != null
				&& workflow_id != "" && workflow_id != null
				&& timestampStr != "" && timestampStr != null){	
			
		strInsertIntoAuditTrailTable=strInsertIntoAuditTrailTable.replaceFirst("<activity_id>",act_id);
		//importDocLogger.info("Building the query Activity ID>>"+act_id);
		//System.out.println("1::"+strInsertIntoAuditTrailTable);
		//System.out.println("activity_audit_trail"+activity_audit_trail);
		
			if(activity_audit_trail != null && activity_audit_trail!=""){
				activity_audit_trail = activity_audit_trail.replaceAll("'", "''");
			}else{
				activity_audit_trail = "";
			}
		strInsertIntoAuditTrailTable=strInsertIntoAuditTrailTable.replaceFirst("<activity_audit_trail>",activity_audit_trail);
		//importDocLogger.info("Building the query Activity Audit Trail>>"+activity_audit_trail);
		//System.out.println("2::"+strInsertIntoAuditTrailTable);
		strInsertIntoAuditTrailTable=strInsertIntoAuditTrailTable.replaceFirst("<workflow_id>",workflow_id);
		//importDocLogger.info("Building the query WorkFlow ID>>"+workflow_id);
		//System.out.println("3::"+strInsertIntoAuditTrailTable);
		strInsertIntoAuditTrailTable=strInsertIntoAuditTrailTable.replaceFirst("'<timestamp>'", "DATE('" + timestampStr + "','dd-mon-yyyy hh:mi:ss')");
		//importDocLogger.info("Building the query Timestamp>>"+timestampStr);
		//System.out.println("4::"+strInsertIntoAuditTrailTable);
		importDocLogger.info("Executing the Query>>"+strInsertIntoAuditTrailTable);
		insertAuditActivityInfo = Utilities.executeQuery(dfSession, strInsertIntoAuditTrailTable, IDfQuery.DF_EXEC_QUERY);
		//System.out.println("5::"+strInsertIntoAuditTrailTable);
		//importDocLogger.info("Query Executed Successfull");	
		boolAuditTrail=true;
		if( insertAuditActivityInfo != null && insertAuditActivityInfo.next()){
			//System.out.println("insertAuditActivityInfo:: not null");
			//importDocLogger.info("Closing the Collection insertAuditActivityInfo");	
			insertAuditActivityInfo.close();
			//importDocLogger.info("Closed the Collection insertAuditActivityInfo");	
		}//End of IF for closing collection	
		
		}//End of IF
		}catch(Exception e){
			importDocLogger.warning("Exception while inserting into insertAuditTrailTable::"+strInsertIntoAuditTrailTable);
			importDocLogger.log(Level.WARNING,"Exception while inserting into insertAuditTrailTable", e);
			e.printStackTrace();
			//System.out.println("inside catch::");
		}//End of Catch
		return boolAuditTrail;
	  }//End of insertAuditTrailTable method

	private static void importWorkflowAuditTrailsDoc(IDfSession dfSession,
			String ifcDocOBJID, String domDOCID) throws Exception, IOException, DfException {
		// TODO Auto-generated method stub
		
			try{
			legacyDocId = domDOCID;	
			dctmObjectID = ifcDocOBJID;
			qryWflowIDandCnt = idocsProperties.getProperty("MSG_DB_WFID_SELECT");
			qryWflowIDandCnt=qryWflowIDandCnt.replaceFirst("'<legacyID>'", "'" + legacyDocId + "'");
			if(!dfSession.isTransactionActive()){
					dfSession.beginTrans();
					txStartedHere = true;
				}
			Connection wfBatchConnCnt = UpdateDB.getBatchConnection();
			ResultSet getWfIDReportCntInfo=UpdateDB.selectFrmWfReportDatabse(qryWflowIDandCnt.toString(),wfBatchConnCnt);
			//importDocLogger.info("Got the workflow ID values in a ResultSet" + qryWflowIDandCnt);
			while (getWfIDReportCntInfo.next()){
				if (!dfSession.isTransactionActive()){
					dfSession.beginTrans();
					txStartedHere = true;
				} //end of If 'Setting Flag for Transactions'
				//importDocLogger.info("Inside While to get Column Values of Audit Report Table");
				workflow_id = getWfIDReportCntInfo.getString("workflow_id");
				//importDocLogger.info("Work Flow ID>>"+workflow_id);
				workflow_name = getWfIDReportCntInfo.getString("workflow_nme");
				//importDocLogger.info("Work Flow Name>>"+workflow_name);
				document_name = getWfIDReportCntInfo.getString("document_nme");
				//importDocLogger.info("Document Name>>"+document_name);
				document_id = getWfIDReportCntInfo.getString("document_id");
				//importDocLogger.info("Document ID>>"+document_id);
				dctmObjID=dctmObjectID;			
				//importDocLogger.info("dctmObjID Document ID>>"+dctmObjID);					
				//Inserting into Documentum Tab1e				
				//Insert DCTM.T1 With Workflow Details					
				strInsertIntoAuditReportTable= idocsProperties.getProperty("MSG_DB_AUDITREPORT_INSERT");
				//importDocLogger.info("Inserting Values to Audit Report Table>>"+strInsertIntoAuditReportTable);	 
				boolAuditReport=insertAuditReportTable(dfSession,strInsertIntoAuditReportTable);
				//System.out.println("boolAuditReport" +boolAuditReport);
				//importDocLogger.info("Insertion Done in Audit Report Table");
				//System.out.println("Insertion Done in Auditreport");					
				qryActIDandCnt = idocsProperties.getProperty("MSG_DB_ACTID_SELECT");					
				qryActIDandCnt=qryActIDandCnt.replaceFirst("'<workflow_id>'", "'" + workflow_id + "'");					
				//System.out.println(""+qryActIDandCnt);
				//importDocLogger.info("Getting Activity ID"+qryActIDandCnt.toString());
				
				Connection wfBatchConnRpt = UpdateDB.getBatchConnection();
				ResultSet getActIDWfCntInfo=UpdateDB.selectFrmWfReportDatabse(qryActIDandCnt.toString(),wfBatchConnRpt);					
				//importDocLogger.info("Got the required Activity IDs in a resultset");
				while (getActIDWfCntInfo.next()){
					act_id = getActIDWfCntInfo.getString("activity_id");	
					activity_name = getActIDWfCntInfo.getString("activity_nme");
					//System.out.println(""+act_id);
					//System.out.println(""+activity_name);
					timestampStr=getActIDWfCntInfo.getString("time_stamp");
					assigned_to = getActIDWfCntInfo.getString("assigned_to");
					performed_by = getActIDWfCntInfo.getString("performed_by");
					action = getActIDWfCntInfo.getString("action");

					//importDocLogger.info("Inserting into Audit Details Table");
					//Inserting into Documentum Tab2
					strInsertIntoAuditDetailsTable= idocsProperties.getProperty("MSG_DB_AUDITDETAILS_INSERT");
					//importDocLogger.info("Inserting into Audit Details Table Query>>"+strInsertIntoAuditDetailsTable);
					boolAuditDetails=insertAuditDetailsTable(strInsertIntoAuditDetailsTable);
					//System.out.println("boolAuditReport" +boolAuditDetails);
					//importDocLogger.info("Insertion Done in Audit Details Table");
					//System.out.println("Insertion Done in AuditDetails");
					//importDocLogger.info("Selecting Values from Audit Trail Table");
					qryAuditTrailEntry = idocsProperties.getProperty("MSG_DB_AUDITTRAIL_SELECT");						
					qryAuditTrailEntry=qryAuditTrailEntry.replaceFirst("'<activity_id>'","'" + act_id + "'");
					//importDocLogger.info("Building the query Activity ID>>"+act_id);
					qryAuditTrailEntry=qryAuditTrailEntry.replaceFirst("'<workflow_id>'","'" + workflow_id + "'");
					//importDocLogger.info("Building the query Workflow ID>>"+workflow_id);
					qryAuditTrailEntry=qryAuditTrailEntry.replaceFirst("'<timestamp>'", "'"+ timestampStr + "'");
					//importDocLogger.info("Building the query Timestamp>>"+timestampStr);
					//System.out.println("Audit trail qry "+qryAuditTrailEntry);
					//importDocLogger.info("Building the Query>>"+qryAuditTrailEntry.toString());
					//importDocLogger.info("Getting Audit Trail Values"+qryActIDandCnt.toString());
					Connection wfBatchConnTrail = UpdateDB.getBatchConnection();
					ResultSet getWfAuditTrailsInfo=UpdateDB.selectFrmWfReportDatabse(qryAuditTrailEntry.toString(),wfBatchConnTrail);
					//importDocLogger.info("Got Audit Trail Values");
					while (getWfAuditTrailsInfo.next()){
						//importDocLogger.info("Parsing the values from Resultset");
						
						activity_audit_trail = getWfAuditTrailsInfo.getString("activity_audit_trail");
						activity_audit_trail = activity_audit_trail.replaceAll("[^a-zA-Z 0-9]+",""); 
						strInsertIntoAuditTrailTable= idocsProperties.getProperty("MSG_DB_AUDITACTIVITY_INSERT");
						//importDocLogger.info("Inserting values to Audit Trail Table>>"+strInsertIntoAuditTrailTable.toString());
						boolAuditTrail=insertAuditTrailTable(strInsertIntoAuditTrailTable);
						//System.out.println("bool Audit Trail"+boolAuditTrail);
						//importDocLogger.info("Insertion done successfully on Audit Trail Table");
						}//end of While for Audit Trail Table resultset	
						if(getWfAuditTrailsInfo != null){
							//System.out.println("Resultset Closing for getAuditTrailInfo");
							//importDocLogger.info("Resultset Closing for getAuditTrailInfo");
//							getAuditTrailInfo = null;
							getWfAuditTrailsInfo.close();
							//System.out.println("Closed the resultset getAuditTrailInfo");
							//importDocLogger.info("Closed the resultset getAuditTrailInfo");
						}	
						
						//Close The connection for getWfAuditTrailsInfo
						try {
							if (wfBatchConnTrail!=null){
								wfBatchConnTrail.close();
								wfBatchConnTrail =null;
							}
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							importDocLogger.warning("Failed in closing the statement and connection::" + e.getMessage());
							importDocLogger.log(Level.WARNING,"SQLException Finally block::", e);
							e.printStackTrace();
						}
						
					}//end of While for Audit Detail Table resultset
					
					if(getActIDWfCntInfo != null){
						//System.out.println("Resultset Closing for getActIDandCntInfo");
						//importDocLogger.info("Resultset Closing for getActIDandCntInfo");
//						getActIDandCntInfo = null;
						getActIDWfCntInfo.close();
						//System.out.println("Closed the resultset getActIDandCntInfo");
						//importDocLogger.info("Closed the resultset getActIDandCntInfo");
					}	
					
					//Close The connection for getActIDWfCntInfo
					try {
						if (wfBatchConnRpt!=null){
							wfBatchConnRpt.close();
							wfBatchConnRpt =null;
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						importDocLogger.warning("Failed in closing the statement and connection::" + e.getMessage());
						importDocLogger.log(Level.WARNING,"SQLException Finally block::", e);
						e.printStackTrace();
					}
					
			 }//end of While for WorkflowID resultset	
				if(getWfIDReportCntInfo != null){
					//System.out.println("Resultset Closing for getWfIDandCntInfo");
					//importDocLogger.info("Resultset Closing for getWfIDandCntInfo");
//					getWfIDandCntInfo = null;
					getWfIDReportCntInfo.close();
					//System.out.println("Closed the resultset getWfIDandCntInfo");
					//importDocLogger.info("Closed the resultset getWfIDandCntInfo");
				}	
				
				//Close The connection for getWfIDReportCntInfo
				try {
					if (wfBatchConnCnt!=null){
						wfBatchConnCnt.close();
						wfBatchConnCnt =null;
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					importDocLogger.warning("Failed in closing the statement and connection::" + e.getMessage());
					importDocLogger.log(Level.WARNING,"SQLException Finally block::", e);
					e.printStackTrace();
				}
				
					if (txStartedHere&&boolAuditReport&&boolAuditDetails&&boolAuditTrail) {
						//importDocLogger.info("Inside IF for Committing Transactions>>"+txStartedHere);
						
						boolAuditReport=false;
						boolAuditDetails=false;
						boolAuditTrail=false;
					    dfSession.commitTrans();
					    //System.out.println("inside commit tx alive>>>" +dfSession.isTransactionActive());
					    dfSession.beginTrans();	
					    //System.out.println("inside commit tx alive>>>" +dfSession.isTransactionActive());
					    //System.out.println("inside tx "+txStartedHere);
					    //importDocLogger.info("Transactions Committed");
					 }/*else{
						 updateRegionTBL();
					}*/
			}catch (Exception e){
				// TODO Auto-generated catch block
				importDocLogger.warning("DfException::"+e.getMessage());
				e.printStackTrace();
				
				
				String skippedReason = "Issue During Migrating Workflow Audits to the document["+legacyDocId+"]";
				skippedReason = skippedReason.replaceAll("'", "''");
				skippedReason = skippedReason+"')";

				//Add the documents to skip table
				Utilities.addToSkippedReason("IMP_WF_AUDIT_TRAIL","","",legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_49"),skippedReason);
				
				//importDocLogger.info("Aborting Transactions>>"+txStartedHere);
				//Update region table with rollback required condition true
				//System.out.println("sad");
				//updateRegionTBL();
		     }//end of catch
			finally{
				//importDocLogger.info("Inside Finally for aborting Transactions>>"+txStartedHere);
				//System.out.println("inside finally tx alive" +dfSession.isTransactionActive());
				//System.out.println("inside finally tx value"+txStartedHere);
	     }
	}

	private static String getDocUniqueIDS(String legacyDocumentID, IDfSession dfSession) {
		// TODO Auto-generated method stub
		String legacyUniqueIDs = "";
		String ifcDocsUNIDs = "";
//		String ifcdocIDs = "";
		String legacyUNIDs = "";
		try {
			String strQuery = idocsProperties.getProperty("MSG_DB_GET_UNIQUE_IDS");
			strQuery = strQuery.replaceAll("<orig_doc_id>", legacyDocumentID);
			legacyUniqueIDs = getDocDetails(Utilities.executeQuery(dfSession, strQuery, DfQuery.EXECREAD_QUERY));
			if(legacyUniqueIDs != null && ""!=legacyUniqueIDs){
				//Check in Migration database for the workflow audits
				String[] idsList = legacyUniqueIDs.split("#");
//				String[] rObjectID = idsList[0].split(",");
//				System.out.println("rObjectID::"+rObjectID);
				String legacyObjectID = idsList[1].toString();
				legacyObjectID = legacyObjectID.replaceAll(",", "','");
				String chkQryStr = idocsProperties.getProperty("MSG_DB_GET_DOCUMENT_ID");
				chkQryStr = chkQryStr.replaceAll("<DOCUMENT_ID>", legacyObjectID);
				Connection wfBatchConn = UpdateDB.getBatchConnection();
				ResultSet  rsDocIDs = UpdateDB.selectFrmWfReportDatabse(chkQryStr,wfBatchConn);
				if(rsDocIDs != null){
					while(rsDocIDs.next()){
						if(legacyUNIDs==""){
							legacyUNIDs = rsDocIDs.getString("DOCUMENT_ID");
						}else{
							legacyUNIDs += ","+rsDocIDs.getString("r_object_id");
						}
//						legacyUniqueIDs = ifcdocIDs+"#"+legacyUNIDs;
					}
					rsDocIDs.close();
					//Close The connection
					try {
						if (wfBatchConn!=null){
							wfBatchConn.close();
							wfBatchConn =null;
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						importDocLogger.warning("Failed in closing the statement and connection::" + e.getMessage());
						importDocLogger.log(Level.WARNING,"SQLException Finally block::", e);
						e.printStackTrace();
					}
					
					
					legacyUNIDs = legacyUNIDs.replaceAll(",", "','");
					strQuery = idocsProperties.getProperty("MSG_DB_GET_UNIQUE_IDS_QRY");
					strQuery = strQuery.replaceAll("<orig_doc_unique_id>", legacyUNIDs);
					ifcDocsUNIDs = getDocDetails(Utilities.executeQuery(dfSession, strQuery, DfQuery.EXECREAD_QUERY));
				}
			}else{
				legacyUniqueIDs = "";
			}
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException while getting Unique Ids to the document::"+legacyDocumentID);
			importDocLogger.log(Level.WARNING,"DfException while getting Unique Ids to the document::", e);
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("SQLException while getting Unique Ids to the document::"+legacyDocumentID);
			importDocLogger.log(Level.WARNING,"SQLException while getting Unique Ids to the document::", e);
			e.printStackTrace();
		}
		return ifcDocsUNIDs;
	}

	private static String getDocDetails(IDfCollection collection) {
		// TODO Auto-generated method stub
		String legacyUniqueIDs = "";
		String ifcdocIDs = "";
		String legacyUNIDs = "";
		try {
			while(collection.next()){
//				ifcdocIDs = collection.getString("r_object_id");
//				legacyUNIDs = collection.getString("orig_doc_unique_id");
				if(ifcdocIDs==""){
					ifcdocIDs = collection.getString("r_object_id");
				}else{
					ifcdocIDs += ","+collection.getString("r_object_id");
				}
				if(legacyUNIDs==""){
					legacyUNIDs = collection.getString("orig_doc_unique_id");
				}else{
					legacyUNIDs += ","+collection.getString("orig_doc_unique_id");
				}
			}
			if(ifcdocIDs != null && "" != ifcdocIDs && legacyUNIDs != null && "" != legacyUNIDs){
				legacyUniqueIDs = ifcdocIDs +"#"+legacyUNIDs;
			}
			collection.close();
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException while getting Document Details from collection");
			importDocLogger.log(Level.WARNING,"DfException while getting Document Details from collection", e);
			e.printStackTrace();
		}//End of while collection
		return legacyUniqueIDs;
	}
	
	public static void uploadWFAudits() {
		// TODO Auto-generated method stub
		String[] regionList = idocsProperties.getProperty("MSG_REGION_NAME").split(",");
		int sendToCount = regionList.length;
		try {
			//Populate Arraylist with all the legacy IDS
			importDocLogger.info("Populatig Woflow Audits Legacy IDS please wait...!!!!");
			populateWFAuditsArrayList();
		for (int i=0;i<sendToCount;i++){
			importDocLogger.info("Processing the region::"+regionList[i]);
			String getLegacyIDs = idocsProperties.getProperty("MSG_DB_GETREGION_INFO_QRY");
			getLegacyIDs = getLegacyIDs.replaceFirst("<region>", regionList[i]);
			importDocLogger.info("Get IDS Query::"+getLegacyIDs);
			//Get the legacy ids from Region table for the documents successfully uploaded
			ResultSet getLegacyIDS = UpdateDB.selectFrmDatabse(getLegacyIDs);
			
				while(getLegacyIDS.next()){
					String wfAuditLegacyID = getLegacyIDS.getString("legacy_document_id");
					importDocLogger.info("Processing workflow audits for the Legacy ID::["+wfAuditLegacyID+"]");
					
					//Check if there is any Workflow Audits are there for this legacy id
					if(wfIDList.contains(wfAuditLegacyID)){
						
						//Get Current Versions RObjectID and upload all workflow audits for the same
						//Upload all workflow audits to current version of the uploaed document
						String curVerDocRObjID = getCurrVerRObjectID(dfSession,wfAuditLegacyID);
						if(null != curVerDocRObjID && !"".equals(curVerDocRObjID)){
							importWorkflowAuditTrailsDoc(dfSession,curVerDocRObjID,wfAuditLegacyID);
						}else{
							importDocLogger.info("Document is not found in IFCDOcs for the Legacy Document ID(Possible reason is incorrent cleanup)::["+wfAuditLegacyID+"]");
						}
					}else{
						importDocLogger.info("Workflow Audits does not exist for the Legacy ID::["+wfAuditLegacyID+"]");
					}
					
					//Get the Doc Unique IDS from IFCDocs for the uploaded document
					/*String ifcDocIDSQueue = getDocUniqueIDS(wfAuditLegacyID,dfSession);
					if(ifcDocIDSQueue != null && ""!=ifcDocIDSQueue){
						String[] idsList = ifcDocIDSQueue.split("#");
						String[] rObjectID = idsList[0].split(",");
						String[] legacyObjectID = idsList[1].split(",");
						if(rObjectID.length == legacyObjectID.length){
							for(int k=0;k<rObjectID.length;k++){
								importDocLogger.info("R_OBJECT_ID of the document::"+rObjectID[k]);
								importDocLogger.info("LEGACY UNIQUE ID of the document::"+legacyObjectID[k]);

								//Import the Workflow audits for the legacy document
								importWorkflowAuditTrailsDoc(dfSession,rObjectID[k],legacyObjectID[k]);
							}
						}
					}else{
						importDocLogger.info("Workflow audits does not exist for the document");
					}*/
					
				}if(getLegacyIDS != null){
					getLegacyIDS.close();
				}
		}//End of For loop for regions
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("SQLException while Starting workflow audits to the document");
			importDocLogger.log(Level.WARNING,"SQLException while Starting workflow audits to the document", e);
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("IOException while Starting workflow audits to the document");
			importDocLogger.log(Level.WARNING,"IOException while Starting workflow audits to the document", e);
			e.printStackTrace();
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException while Starting workflow audits to the document");
			importDocLogger.log(Level.WARNING,"DfException while Starting workflow audits to the document", e);
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("Exception while Starting workflow audits to the document");
			importDocLogger.log(Level.WARNING,"Exception while Starting workflow audits to the document", e);
			e.printStackTrace();
		}
			
		
		
		//Algorithm
		//1.Get the database connection with migration databases  -- Done
		//2.Select migrated(successfully imported) documents for every region
		//3.Process workflow audits for the migrated documents one by one
		//4.Abort the transactions if there is any failure in migration and mark the document as a rollback required.
	}

	private static String getCurrVerRObjectID(IDfSession dfSession,
			String wfAuditLegacyID) {
		// TODO Auto-generated method stub
		String currVrRObjectId = "";
		String getCurVerQryStr = idocsProperties.getProperty("MSG_GET_CURRENT_VERSION_IDS");
		getCurVerQryStr = getCurVerQryStr.replaceAll("<orig_doc_id>", wfAuditLegacyID);
		try {
			IDfCollection ObjIDColl = Utilities.executeQuery(dfSession, getCurVerQryStr, DfQuery.EXECREAD_QUERY);
			while(ObjIDColl.next()){
				currVrRObjectId = ObjIDColl.getString("r_object_id");
			}
			ObjIDColl.close();
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException while processing the collection");
			e.printStackTrace();
		}
		
		return currVrRObjectId;
	}

	private static ArrayList populateWFAuditsArrayList() {
		// TODO Auto-generated method stub
		String getIDSQryStr = idocsProperties.getProperty("MSG_DB_GET_ALL_DOCUMENT_IDS");
		Connection wfBatchConn = UpdateDB.getBatchConnection();
		ResultSet  rsDocIDs = UpdateDB.selectFrmWfReportDatabse(getIDSQryStr,wfBatchConn);
		try {
			while(rsDocIDs.next()){
				wfIDList.add(rsDocIDs.getString("DOCUMENT_ID"));
			}if(rsDocIDs != null){
				rsDocIDs.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("SQLException while populating WorkFlow Audits to Arraylist");
			e.printStackTrace();
		}
		return wfIDList;
	}
	
  }


		//Algorithm
		
		//1. For the Extraction Utility ID QUERY Region table.
		
		//2. Fetch list of all documents
		
		//3. For each document id
		
		//   Fetch list of WF ids from table 1
		 
		//    populate T1 
		
		//    For each  wf id fetch all activities (wf+act+timestamp ) table 2
		
		//      1. get all activity details and update dctm.T2
		
		//      2. for each (wf+act+timestamp) get list of audit trail entries from table 3
		
		//           populate the audit trail entries in dctm.t3
  
  
  
  
  
  
  
  
	