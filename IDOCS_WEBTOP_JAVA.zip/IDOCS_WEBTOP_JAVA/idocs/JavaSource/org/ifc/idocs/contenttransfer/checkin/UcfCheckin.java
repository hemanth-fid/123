/**
* This component checks in the document and gives the user to start workflow
* after the document is checked in .
* 
* ##############################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* ##############################################################################
* CVattathara			09/25/2010		1.0				created
* ##############################################################################
*/
package org.ifc.idocs.contenttransfer.checkin;

import java.util.Date;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.crrpsr.LinkToGHG;
import org.ifc.idocs.queryservices.DocTypeTableStructure;
import org.ifc.idocs.queryservices.IDocsQRYVO;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;
import org.ifc.idocs.workflow.startworkflow.StartWorkflow;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfTime;
import com.documentum.fc.common.IDfTime;
import com.documentum.operations.IDfFile;
import com.documentum.operations.impl.DfFile;
import com.documentum.web.common.AcsService;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.Checkbox;
import com.documentum.web.form.control.DateInput;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.Panel;
import com.documentum.web.form.control.Radio;
import com.documentum.web.form.control.Text;
import com.documentum.web.form.control.databound.DataDropDownList;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.form.control.databound.TableResultSet;
import com.documentum.web.formext.docbase.ObjectCacheUtil;
import com.documentum.webcomponent.common.WebComponentErrorService;
import com.documentum.webcomponent.library.contenttransfer.ContentTransferComponent;
import com.documentum.webcomponent.library.contenttransfer.ContentTransferServiceContainer;

public class UcfCheckin extends com.documentum.webcomponent.library.contenttransfer.checkin.UcfCheckin
{

	public String expectedDocumentName = null;
	public String docSubTypeName=null;
	public String docSubTypeCode=null;
	public DfTime docmntdate=null;
	public boolean isCreatedFromBizTemplate=false;
	public boolean flag=false;
	public boolean countryDoc=false;
	public boolean readOnly=false;
	String strFolderCategory = IDocsConstants.MSG_EMPTY_STRING;
	public static String STR_SUB_TYPE="DocSubType"; 
	
	public String getExpectedDocumentName() {
		return expectedDocumentName;
	}

	public void setExpectedDocumentName(String expectedDocumentName) {
		this.expectedDocumentName = expectedDocumentName;
	}
	public String getFolderTitle() {
		return folderTitle;
	}
	
	public void setFolderTitle(String strFolderTitle) {
		folderTitle = strFolderTitle;
	}
	public String getdocSubTypeName() {
		return docSubTypeName;
	}

	public void setdocSubTypeName(String docSubTypeName) {
		this.docSubTypeName = docSubTypeName;
	}
	public String getdocSubTypeCode() {
		return docSubTypeCode;
	}

	public void setdocSubTypeCode(String docSubTypeCode) {
		this.docSubTypeCode = docSubTypeCode;
	}
	public DfTime getdocmntdate() {
		return docmntdate;
	}

	public void setdocmntdate(DfTime docmntdate){
		this.docmntdate = docmntdate;
}
	
	public UcfCheckin(){
        doc = null;
        idocsUtil = new IdocsUtil();
    }

	 public void getBizTemplateStatus(String docSubType,String strObjectType) throws DfException{
		DfLogger.info(this," getBizTemplateStatus ::docSubtype: " + docSubType,null,null);
		if (docSubType == null || !(docSubType.trim().length() >0)) {
			setupTypeList();
			flag = true;
		}else{
			Label label = (Label)getControl(STR_SUB_TYPE, Label.class);
			label.setLabel(docSubType);
		}
		DfLogger.info(this,"Attributes :flag: " + flag,null,null);
		countryDoc=strObjectType.equals(IDocsConstants.MSG_IDOCS_COUNTRY_DOC);
		String docState=doc.getString(IDocsConstants.MSG_DOC_STATE);
		isCreatedFromBizTemplate=doc.getBoolean(IdocsConstants.MSG_IS_CREATED_FROM_BIZ_TEMPLATE);
		if(docState.equals("Released")){
			readOnly=true;
		}else{
			DfLogger.info(this,"Attributes if(docState.equals(\"Released\")) : else Part",null,null);
		}
		DfLogger.info(this, "Attributes getBusinessTemplateStatus :countryDoc : "+countryDoc,null,null);
		DfLogger.info(this, "Attributes getBusinessTemplateStatus :isCreatedFromBizTemplate : "+isCreatedFromBizTemplate,null,null);
		DfLogger.info(this, "Attributes getBusinessTemplateStatus :readOnly : "+readOnly,null,null);
	}
	 
	 	/**
		 * Method to populate the sub folder name during import and for documents that doesn't
		 * have doc sub type code.
		 * @param typeList
		 * @param args
		 * @throws DfException
		 */
		public void onSelectDoc(DataDropDownList typeList,ArgumentList args) throws DfException {
			String subFolder = IDocsConstants.MSG_EMPTY_STRING;
			String folderTitle=IDocsConstants.MSG_EMPTY_STRING;
			String [] typeResults =null;
			String columnNames[] = {"subfolder_title","doc_type_name"};
			/** getting values from Query Services */
			DocTypeTableStructure docTypeTableStructure = new DocTypeTableStructure(IDocsQRYVO.getTemplateInfoTableData(getDfSession()));
			typeResults=docTypeTableStructure.getTableResultSetColumnWithWhereClausesWithDistinctAsArray(columnNames, "folder_category", strFolderCategory, "is_active","Yes","doc_type_code",typeList.getValue(),"subfolder_title");
			
			if(typeResults.length >= 2){
				subFolder = typeResults[0];
				folderTitle = typeResults[1];
			}
			if(subFolder != null && subFolder.trim().length() >0){
				//don't care 
			}else{
				String subFolderQry = IdocsUtil.getMessage("QUERY_FOLDER_TITLE");
				subFolderQry = subFolderQry.replaceFirst(IdocsConstants.MSG_C_DQ_C, IdocsConstants.MSG_QUOTES+typeList.getValue()+IdocsConstants.MSG_QUOTES);
				subFolderQry = subFolderQry.replaceFirst(IdocsConstants.MSG_C_DQ_C, IdocsConstants.MSG_QUOTES+strFolderCategory+IdocsConstants.MSG_QUOTES);
				IDfCollection dfCollection = IdocsUtil.executeQuery(getDfSession(), subFolderQry,IDfQuery.DF_READ_QUERY);
				if (dfCollection.next()) {
					subFolder = dfCollection.getString("subfolder_title");
					folderTitle = dfCollection.getString("doc_type_name");
					dfCollection.close();
				}
				if(dfCollection != null) dfCollection.close();
				DfLogger.debug(this,"folderTitle Value"+folderTitle, null, null);
			}
			updateSubfolder(subFolder);
		}
	    
		/**
		 * Updating the corresponding folder title to UI and object
		 * 
		 * @param subFolder - folder_title selected
		 * @throws DfException
		 */
		private void updateSubfolder(String subFolder) throws DfException {
			Label label = (Label)getControl("subfolder", Label.class);
	    	label.setLabel(subFolder);
		}

		/**
		 * This prepares the drop down list with allowed document sub type names.
		 * @throws DfException
		 */
		public void setupTypeList() throws DfException {
			TableResultSet typeResultSet = null;
			DataDropDownList typeList = (DataDropDownList)getControl("docTypeList", DataDropDownList.class);
			typeList.clearOptions();
			DocTypeTableStructure docTypeTableStructure = new DocTypeTableStructure(IDocsQRYVO.getTemplateInfoTableData(getDfSession()));
			String columnNames[] = {"doc_type_code","doc_type_name"};
			typeResultSet=docTypeTableStructure.getTableResultSetColumnWithWhereClausesWithDistinct(columnNames, "folder_category", strFolderCategory, "is_active","Yes", "doc_type_code");
			if(typeResultSet !=null){
				//DfLogger.debug(this, "No need to Query again Values are existed", null, null);
			}else{
				DfLogger.debug(this," :: setupTypeList...!!!",null,null);
				typeResultSet=new TableResultSet(new String[] {"doc_type_code", "doc_type_name"});
				String typeListQry = IdocsUtil.getMessage("QUERY_SELECT_TYPE");
				typeListQry = typeListQry.replaceFirst("''", "'" + strFolderCategory + "'");
				DfLogger.debug(this," :: setupTypeList : typeListQry : "+typeListQry,null,null);
				IDfCollection collection =IdocsUtil.executeQuery(getDfSession(), typeListQry,IDfQuery.DF_READ_QUERY);
				while(collection.next()) {
					String typeName = collection.getString("doc_type_code");
					String typeLabel = collection.getString("doc_type_name");
					typeResultSet.add(new String[] {typeName, typeLabel});
				}
				if(collection !=null)collection.close();
			}
			typeList.getDataProvider().setScrollableResultSet(typeResultSet);
			typeList.getDataProvider().sort("doc_type_name",Datagrid.SORTDIR_FORWARD,Datagrid.SORTMODE_TEXT);
		}
	/**
	 * Reads the selected object id from the context parameters and store it for future use.
	 */
    public void onInit(ArgumentList args){
        try{
        	String objectType="";
        	String docSubType="";
            DfLogger.info(this, (new StringBuilder(" :: onInit : ")).append(getDfSession().getLoginUserName()).toString(), null, null);
            super.onInit(args);
            m_objectId = args.get(m_objectId_attr);
            setCheckinObjectId(m_objectId);
            doc = (IDfDocument)ObjectCacheUtil.getObject(getDfSession(),m_objectId);
            objectType=doc.getTypeName();
            docSubType=doc.getString("doc_subtype_nme");
            String folderId=doc.getString("i_folder_id");
            if(objectType.equals(IdocsConstants.PROJ_DOC_TYPE))
            	    strFolderCategory =IDocDocbaseAttributeTagUtility.getSingleAttributeValue(getDfSession(), folderId,"folder_category",IdocsConstants.PROJ_FOLDER_TYPE);
            else if(objectType.equals(IdocsConstants.INSTITUTION_DOC_TYPE)){
            	    strFolderCategory =IDocDocbaseAttributeTagUtility.getSingleAttributeValue(getDfSession(), folderId,"folder_category",IdocsConstants.INSTITUTION_FOLDER_TYPE);
            }else if(objectType.equals(IdocsConstants.COUNTRY_DOC_TYPE))
            		strFolderCategory =IDocDocbaseAttributeTagUtility.getSingleAttributeValue(getDfSession(), folderId,"folder_category",IdocsConstants.COUNTRY_FOLDER_TYPE);
            getBizTemplateStatus(docSubType,objectType);
        }catch(DfException e){
            DfLogger.error(this, (new StringBuilder(" :: onInit Exception >> ")).append(e.getMessage()).toString(), null, e);
        }
        updateControls();
    }

    /**
     * This method enables synchronous BOCS mode by default
     */
    protected void initStandardOptionsControls()
    {
        super.initStandardOptionsControls();
        try {
			if(AcsService.getInstance().canOverrideDefaultBocsWriteMode())
			{
			    com.documentum.webcomponent.library.contenttransfer.ContentTransferServiceContainer.IContainerInformant containerInformant = ((ContentTransferServiceContainer)getContainer()).getContainerInformant();
			    if(containerInformant.isDisplayingFirstComponent())
			    {
			        getBocsWriteOptionPanelControl(false).setVisible(true);
			            getBocsSyncWriteRadioControl(true).setValue(true);
			            DfLogger.info(this, " :: initStandardOptionsControls :: Enabled BOCS synchronous mode", null, null);
			        if(containerInformant.getNumberOfComponents() == 1)
			        {
			            getBocsWriteOptionTopPanelControl(true).setVisible(false);
			            getBocsWriteOptionBottomPanelControl(true).setVisible(false);
			        }
			    }
			}
			 
		getBocsSyncWriteRadioControl(true).setValue(true);
	    DfLogger.info(this, " :: initStandardOptionsControls :: Enabled BOCS synchronous mode", null, null);
		} catch (Exception e) {
			DfLogger.error(this, " :: initStandardOptionsControls :: " + e.getMessage(), null, null);
		}
    }

    /**
     * This renders the checkin UI with custom attributes.
     */
    public void onRender(){
        try{
        	DfLogger.info(this, (new StringBuilder(" :: onRender : ")).append(getDfSession().getLoginUserName()).toString(), null, null);
            super.onRender();
            DateInput docDate = (DateInput)getControl("doc_date", DateInput.class);
            IDfTime documentDate = doc.getTime("document_date");
            DfLogger.info(this, (new StringBuilder(" :: onRender : Date : ")).append(documentDate).toString(), null, null);
            if(documentDate.getDate() == null){
                docDate.setValue(new Date());
            }else{
                docDate.setValue(documentDate.getDate());
            }
        }catch(DfException e){
            DfLogger.error(this, (new StringBuilder(" :: onRender Exception >> ")).append(e.getMessage()).toString(), null, e);
        }
    }

    /**
     * This method saves the changes on the rendered attribute to the object.
     */
    public boolean onCommitChanges(){
        boolean commitFlag = false;
        try{
            
            String isWorkflowDocQry = IdocsUtil.getMessage("QRY_START_WORKFLOW_PRECONDITION");
            isWorkflowDocQry = isWorkflowDocQry.replaceFirst(IdocsConstants.MSG_C_DQ_C,IdocsConstants.MSG_QUOTES+m_objectId+IdocsConstants.MSG_QUOTES);
            DfLogger.info(this, "onCommitChanges : isWorkflowDocQry : " +  isWorkflowDocQry, null, null);
            String templateCode= null;
            IDfCollection collection = IdocsUtil.executeQuery(getDfSession(), isWorkflowDocQry, IDfQuery.DF_READ_QUERY);
			while(collection.next()){
				templateCode = collection.getString(IDocsConstants.MSG_TEMPLATE_CODE);
				DfLogger.info(this, "onCommitChanges : templateCode : " +  templateCode, null, null);
			}
			if(collection!=null)collection.close();
			if(templateCode != null && templateCode.trim().length() > 0 ){
				Label messageLabel = (Label)getControl("correcttype",Label.class);
				String docPath =null;
				if(getFilebrowseControl(false) != null && getCheckinFromFileCheckboxControl(false).getValue()){
					docPath  = getFilebrowseControl(false).getValue();
				}
				DfLogger.info(this, "onCommitChanges : docPath : " +  docPath, null, null);
				if (docPath != null && docPath.trim().length() > 0) {
					IDfFile idfFile = new DfFile(docPath); 
					if (idfFile != null){
						DfLogger.info(this, "onCommitChanges : is idfFile : " + idfFile.getName(), null, null);
						DfLogger.info(this, "onCommitChanges : file extension : " + idfFile.getExtension(), null, null);
						DfLogger.info(this, "Current document extension : " + idfFile.getExtension(),null, null);
						String docExtension=doc.getFormat().getDOSExtension();
						String fileExtension=idfFile.getExtension();
						if (fileExtension != null && fileExtension.trim().length() > 0
							&& docExtension!= null && docExtension.trim().length() > 0
							&& fileExtension.equals(docExtension)==false) {
							DfLogger.info(this, "onCommitChanges : idfFile is not valid extension: " , null, null);
							messageLabel.setVisible(true);
							messageLabel.setLabel( "Error with document format. Please select a file with '."+docExtension+"' extension");
							return false;
						} else {
							DfLogger.info(this, "onCommitChanges : idfFile is valid extension: " , null, null);
						}
					}
					else {
						DfLogger.info(this, "onCommitChanges : idfFile is null : " , null, null);
						messageLabel.setVisible(true);
						return false;
					}

				}
				}
           
            DateInput docDate = (DateInput)getControl("doc_date", DateInput.class);
            DfLogger.info(this, (new StringBuilder(" :: onCommitChanges : documentDate : ")).append(docDate.getValue()).toString(), null, null);
            if(docDate != null){
            	setdocmntdate(new DfTime(docDate.getValue(), "mm/dd/yyyy hh:mi:ss"));
                DfLogger.info(this, (new StringBuilder(" :: onCommitChanges : documentDate after set: ")).append(doc.getTime("document_date")).toString(), null, null);
            }
           
            try{
            	Radio majorversion = (Radio)getControl("majorversion", Radio.class);
            	if(majorversion != null && majorversion.getValue()==true){
            		Label majorversionNumber = (Label)getControl("majorversionnum", Label.class);
            		majorVersionLabel = IdocsUtil.getMajorVersionLabel(majorversionNumber.getLabel());
            	}
            }catch (Exception e) {
            	e.printStackTrace();
			}
            
 
            commitFlag = super.onCommitChanges();   
            
            /*
             * CODE CHANGES START for IOM Documents
             */
            
            DfLogger.info(this, "onCommitChanges : CODE CHANGES START for IOM Documents ", null, null);
            Text text = (Text)getControl(STR_TXT_DOCNAME,Text.class);
            String exisitingDocName = text.getValue();
            
            // Validating $ in document name
            if (IdocsUtil.isValidIOMObjectName(exisitingDocName) == false) {
    			DfLogger.debug(this, "exisitingDocName: contains $ symbol", null, null);
    			Object params[] = new Object[1];
   			 	params[0] = IDocsConstants.MSG_EMPTY_STRING;
   			 	WebComponentErrorService.getService().setNonFatalError(this, "MSG_DOLLAR_CHAR_VALIDATION", params, null);
   			 	return false;
    		}
            
            if(exisitingDocName != null && exisitingDocName.trim().length() > 0){
            	
            	StringBuffer docNewName = new StringBuffer(doc.getString(IDocsConstants.PROJECT_ID));
            	docNewName.append("_");
            	
            	if(exisitingDocName.startsWith(docNewName.toString())){
            		expectedDocumentName  = exisitingDocName;
            	}else{
            		docNewName.append(exisitingDocName);
            		DfLogger.info(this, (new StringBuilder(" :: onCommitChanges : New Document Name  : ").append(docNewName)).toString(), null, null);
            		expectedDocumentName = docNewName.toString();
            	}
            	
            	DfLogger.info(this, (new StringBuilder(" :: onCommitChanges : CODE CHANGES END for IOM Documents ")).toString(), null, null);
            }
            
            /*
             * CODE CHANGES END for IOM Documents
             */
            
            DfLogger.info(this, "onCommitChanges : Document Name changes : END", null, null);
            
        }catch(DfException e){
            DfLogger.error(this, (new StringBuilder(" :: onCommitChanges Exception >> ")).append(e.getMessage()).toString(), null, e);
        }catch(Exception e){
            DfLogger.error(this, (new StringBuilder(" :: onCommitChanges Exception >> ")).append(e.getMessage()).toString(), null, e);
        }
        return commitFlag;
    }

  	/**
     * This method initializes the start workflow check box as per the business rule.
     */
    public void updateControls(){
    	DfLogger.debug(this, (new StringBuilder(" :: updateControls : isWfDocument : ")).append(isWfDocument).toString(), null, null);
    	isWfDocument = isWorkflowRequired(m_objectId);
    	Label partnerTierprojectTierLabel = (Label) getControl("partnerTierLabel", Label.class);
    	Label projectTierLabel = (Label) getControl("projectTierLabel", Label.class);
    	Label ghgCheckLabel = (Label) getControl("ghgCheckLabel", Label.class);
    	String strTemplateTitle  = IdocsUtil.getTemplateTitle(getDfSession(),m_objectId);
    	try {
			/*
			 * Document Name changes text field is enabled only for IOM Documents 
			 * START
			 */
			DfLogger.info(this, (new StringBuilder(" :: updateControls changes START : ")).toString(), null, null);
	            
            Panel docNamePanel = (Panel)getControl("objectNamePanel", Panel.class);
            DfLogger.debug(this, "onInit() :: CODE CHANGES START for IOM Documents", null, null);
        	String strDocumentState = doc.getString(IDocsConstants.MSG_DOC_STATE);
        	if((IdocsUtil.getMessage("MSG_INTERNAL_OFFICE_MEMORANDUM")).equals(strTemplateTitle) 
        			&& (strDocumentState!=null && strDocumentState.equalsIgnoreCase(IdocsConstants.DOC_STATE_RELEASED)==false)) {
        		Text text = (Text)getControl(STR_TXT_DOCNAME,Text.class);
        		text.setValue(doc.getObjectName());
        		docNamePanel.setVisible(true);
        		DfLogger.debug(this, "onInit() :: Document Name field is set to Visible", null, null);
        	}else{
        		docNamePanel.setVisible(false);
        		DfLogger.debug(this, "onInit() :: hide Document Name field", null, null);
        	}
        	
        	DfLogger.info(this, (new StringBuilder(" :: updateControls changes END : ")).toString(), null, null);
        	/*
        	 * END
        	 */
        	
        	
        	/*
        	 * Advisory Services changes - START
        	 * JIRA : ASOP-2162
        	 */
        	DfLogger.debug(this, "onInit() :: Template Title :"+strTemplateTitle, null, null);
        	
        	boolean isAdvisoryTemplate = IdocsUtil.isAdvisoryTemplate(strTemplateTitle);
        	
        	if(isAdvisoryTemplate){
        		DfLogger.debug(this, "onInit() :: Is Advisory Template ::"+isAdvisoryTemplate, null, null);
        		Panel wfCheckboxPanel = (Panel)getControl("wfCheckboxPanel", Panel.class);
        		Checkbox wf_start = (Checkbox)getControl(m_workflowattribute, Checkbox.class);
				
        		wf_start.setValue(false);
				wf_start.setEnabled(false);
        		wfCheckboxPanel.setVisible(false);
        		DfLogger.debug(this, "onInit() :: Workflow Check box is unchecked and hidden", null, null);
        	}
        	
        	
        	/*
        	 * Advisory Services changes - END
        	 */
	        	
			if (isWfDocument) {
				String strPartnerTierTemplateNames = IdocsUtil.getMessage("PARTNER_TIER_TEMPLATES");
				String strProjectTierTemplateNames = IdocsUtil.getMessage("PROJECT_TIER_TEMPLATES");
				// To check for partner tier templates
				if (strTemplateTitle != null && strTemplateTitle.trim().length() > 0 
						&& IdocsUtil.checkIfTokenPresent(strPartnerTierTemplateNames, strTemplateTitle, IdocsConstants.MSG_COMMA) == true ) {
					String result = IdocsUtil.checkIfRightsIssueCSO(getDfSession(), m_objectId, strTemplateTitle);
					 if (result !=null && result.trim().length()> 0 
							 && (result.equalsIgnoreCase(IDocsConstants.MSG_NON_CSO) == true
									 || result.equalsIgnoreCase(IDocsConstants.MSG_OTHER) == true)){
						 // For Rights Issue NON CSO and Other templates.
						String partnerTier = IdocsUtil.getPartnerTier(m_objectId, getDfSession());
						DfLogger.info(this, " :: updateControls: partnerTier: " + partnerTier, null, null);
						if (IdocsUtil.isValidPartnerTier(partnerTier)) {
							enableStartWFControl(projectTierLabel,partnerTierprojectTierLabel, ghgCheckLabel, strTemplateTitle);
						} else {
							DfLogger.info(this, " :: updateControls: Enable Partner tier Label", null, null);
							partnerTierprojectTierLabel.setVisible(true);
							projectTierLabel.setVisible(false);
							ghgCheckLabel.setVisible(false);
							Checkbox wf_start = (Checkbox)getControl(m_workflowattribute, Checkbox.class);
							wf_start.setEnabled(false);
							wf_start.setValue(false);
						}
					} else { // If template is Rights Issue CSO
						enableStartWFControl(projectTierLabel,partnerTierprojectTierLabel,ghgCheckLabel, strTemplateTitle);
					}
				}else if (strTemplateTitle != null && strTemplateTitle.trim().length() > 0 &&
					 IdocsUtil.checkIfTokenPresent(strProjectTierTemplateNames, strTemplateTitle, IdocsConstants.MSG_COMMA) == true){
					 String result = IdocsUtil.checkIfRightsIssueCSO(getDfSession(), m_objectId, strTemplateTitle);
					 if (result !=null && result.trim().length()> 0 
							 && (result.equalsIgnoreCase(IDocsConstants.MSG_CSO) == true
									 || result.equalsIgnoreCase(IDocsConstants.MSG_OTHER) == true)){
						 // For templates Rights Issue CSO and other templates.
						 String projectTier = IdocsUtil.getProjectTier(m_objectId, getDfSession());
						 DfLogger.debug(this, " :: canStartIDocsWorkFlow: Project Tier: " + projectTier, null, null);
						 if (IdocsUtil.isValidProjectTier(projectTier)) {
							DfLogger.info(this, " :: updateControls: Disable Partner tier Label", null, null);
							enableStartWFControl(projectTierLabel,partnerTierprojectTierLabel, ghgCheckLabel, strTemplateTitle);									
						 }else{
						 	DfLogger.info(this, " :: updateControls: Enable Project tier Label", null, null);
							partnerTierprojectTierLabel.setVisible(false);
							projectTierLabel.setVisible(true);
							ghgCheckLabel.setVisible(false);
							Checkbox wf_start = (Checkbox)getControl(m_workflowattribute, Checkbox.class);
							wf_start.setEnabled(false);
							wf_start.setValue(false);
						 } 
					 }else {
						 DfLogger.debug(this, " :: canStartIDocsWorkFlow: Template is Rights Issue NON CSO", null, null);
						 enableStartWFControl(projectTierLabel,partnerTierprojectTierLabel,ghgCheckLabel, strTemplateTitle);
					 }
				}else{
					enableStartWFControl(projectTierLabel,partnerTierprojectTierLabel, ghgCheckLabel, strTemplateTitle);
				}
			} else{
				DfLogger.info(this, " :: updateControls: Workflow is not required since isWfDocument: " + isWfDocument, null, null);
				partnerTierprojectTierLabel.setVisible(false);
				projectTierLabel.setVisible(false);
				ghgCheckLabel.setVisible(false);
				Checkbox wf_start = (Checkbox)getControl(m_workflowattribute, Checkbox.class);
				wf_start.setEnabled(false);
				wf_start.setValue(false);
			}
		} catch (DfException e) {
			DfLogger.error(this, " :: onCommitChanges Exception >> " + e.getMessage(), null, e);
			partnerTierprojectTierLabel.setVisible(false);
			projectTierLabel.setVisible(false);
			ghgCheckLabel.setVisible(false);
			Checkbox wf_start = (Checkbox)getControl(m_workflowattribute, Checkbox.class);
			wf_start.setEnabled(false);
			wf_start.setValue(false);
		}
    	
        DfLogger.info(this, (new StringBuilder(" :: updateControls : isWfDocument : ")).append(isWfDocument).toString(), null, null);
    }

    private void enableStartWFControl(Label projectTierLabel, Label partnerTierLabel, Label ghgCheckLabel, String templateName) {
    	partnerTierLabel.setVisible(false);
    	projectTierLabel.setVisible(false);
    	ghgCheckLabel.setVisible(false);
    	StartWorkflow start_workflow = new StartWorkflow();
        boolean canWorkflowStart = start_workflow.canStartIDocsWorkFlow(m_objectId,false,false);
        boolean isAlreadyInWorkflow = checkIfAlreadyInWorkFlow(m_objectId);
        
        Checkbox wf_start = (Checkbox)getControl(m_workflowattribute, Checkbox.class);
        DfLogger.info(this, " :: enableStartWFControl: canWorkflowStart" + canWorkflowStart, null, null);
        if(canWorkflowStart){ // && isWfDocument Removed this to enable the startWorkflowCheckBox in checkin..
        	DfLogger.info(this, " :: enableStartWFControl: Checkbox is enabled", null, null);
            wf_start.setEnabled(true);
        } else{
        	
        	DfLogger.info(this, " :: enableStartWFControl: Checkbox is disabled", null, null);
            wf_start.setEnabled(false);
            // chkfor ghg emission and display label accordingly
            
            try {
				IDfSysObject sysObj = (IDfSysObject)ObjectCacheUtil.getObject(getDfSession(), getObjectId());
				String templateCode =  sysObj.getString(IDocsConstants.MSG_TEMPLATE_CODE);
				String currentProjectId = sysObj.getString(IDocsConstants.PROJECT_ID);
				boolean validated = LinkToGHG.isGHGCheckValidForDocument(currentProjectId, templateCode, getDfSession(), templateName);
				if (validated == false) {
					ghgCheckLabel.setVisible(true);
					DfLogger.info(this, " :: enableStartWFControl: Enable ghg check label", null, null);
				}
				if(isAlreadyInWorkflow){
					wf_start.setValue(true);
					DfLogger.info(this, " :: enableStartWFControl: Checkbox Read Only But Checked", null, null);
				}else{
					DfLogger.info(this, " :: enableStartWFControl: Checkbox is Read Only ", null, null);
					wf_start.setValue(false);
				}
			} catch (DfException e) {
				e.printStackTrace();
			}
        }
	}

	/**
     * This method will check if the document is already in workflow or not.
     * @param objectId - Object Id of the document.
     * @return
     */
    private boolean checkIfAlreadyInWorkFlow( String objectId) {
    	 try {
			String wfStatus = IDocsConstants.MSG_EMPTY_STRING;
			String docQuery = IdocsUtil.getMessage("QRY_WFSTATUS_TMPLTCODE");
			docQuery = docQuery.replaceFirst("''","'" + objectId + "'");
			DfLogger.info(this, " :: checkIfAlreadyInWorkFlow: docQuery: " + docQuery, null, null);
			IDfQuery query = new DfQuery(docQuery);
			IDfCollection docCollection = query.execute(getDfSession(), IDfQuery.DF_READ_QUERY);
			if(docCollection.next()){
			 	wfStatus = docCollection.getString(IDocsConstants.MSG_WORKFLOW_STATUS);
			 	DfLogger.info(this, " :: checkIfAlreadyInWorkFlow: wfStatus: " + wfStatus, null, null);
			 	docCollection.close();
			}
			if(docCollection != null) docCollection.close();
			if(wfStatus!= null && wfStatus.trim().length() > 0){
				 DfLogger.info(this, " :: checkIfAlreadyInWorkFlow: Document is in WorkFlow: " + wfStatus, null, null);
				 return true ;
			}else{
				 DfLogger.info(this, " :: checkIfAlreadyInWorkFlow: Document is not in WorkFlow: " + wfStatus, null, null);
				 return false;
			}
		} catch (DfException e) {
			e.printStackTrace();
			 DfLogger.info(this, " :: checkIfAlreadyInWorkFlow: Exception : " + e.getMessage(), null, null);
		}
		return false;
	}

    /**
     * Reads the check box value.
     * @return boolean value true of false 
     */
	public boolean getCheckBoxValue(){
        Checkbox wf_start = (Checkbox)getControl(m_workflowattribute, Checkbox.class);
        if(wf_start != null){
            return wf_start.getValue();
        }else{
            return false;
        }
    }

	/**
	 * THis method is to check if this document can be routed through any IDOCS workflow.
	 * @param objectID
	 * @return
	 */
    public boolean isWorkflowRequired(String objectID){
        boolean isWfDoc = false;
        try{
            DfLogger.info(this, " :: isWorkflowRequired : isWorkflowRequired", null, null);
            IDfQuery query = new DfQuery();
            query.setDQL(IdocsUtil.getMessage("QRY_ISWORKFLOW_REQUIRED").replaceFirst("''", (new StringBuilder("'")).append(objectID).append("'").toString()));
            IDfCollection collection = query.execute(getDfSession(), 0);
            if(collection.next()){
                isWfDoc = collection.getBoolean(IDocsConstants.MSG_IS_WORKFLOW_REQUIRED);
            }
            if(collection!=null)collection.close();
            DfLogger.info(this, " :: isWorkflowRequired : isWorkflowRequired : "+isWfDoc, null, null);
        }catch(DfException e){
            DfLogger.error(this, (new StringBuilder(" :: isWorkflowRequired Exception >> ")).append(e.getMessage()).toString(), null, e);
        }
        return isWfDoc;
    }

	/**
	 * 
	 * @return
	 */
    public String getCheckinObjectId() {
		return m_objectId;
	}

	public void setCheckinObjectId(String mObjectId) {
		m_objectId = mObjectId;
	}
	
	 
	/**
	 * Customized to set synchronous write for Template documents which undergo workflow and Asynchronous 
	 * write for other documents
	 * @see com.documentum.webcomponent.library.contenttransfer.checkin.UcfCheckin#getMode()
	 */
	public ContentTransferComponent.IBocsWriteModeConfigurator.BocsWriteMode getMode()
	{
		String templateTitle = IdocsUtil.getTemplateTitle(getDfSession(), m_objectId);
	    ContentTransferComponent.IBocsWriteModeConfigurator.BocsWriteMode bocsWriteMode = ContentTransferComponent.IBocsWriteModeConfigurator.BocsWriteMode.NOT_APPLICABLE;
	    boolean syncFlag = isWorkflowRequired(getCheckinObjectId());
	    String specialBocsNonWfDocuments = IdocsUtil.getMessage("MSG_SPECIAL_BOCS_NON_WF_TEMPLATES");
	    if(syncFlag == false 
	    		&& templateTitle !=null && templateTitle.trim().length() > 0 
	    		&& specialBocsNonWfDocuments != null 
	    		&& specialBocsNonWfDocuments.trim().length() > 0
	    		&& IdocsUtil.checkIfTokenPresent(specialBocsNonWfDocuments, templateTitle, ",")){
	    	DfLogger.info(this, " :: IBocsWriteModeConfigurator.BocsWriteMode :: This is a Special BOCS Template. Do not use BOCS.", null, null);
	    	syncFlag = true;
	    }else{
	    	DfLogger.info(this, " :: IBocsWriteModeConfigurator.BocsWriteMode :: This is not Special BOCS Template. Continue..", null, null);
	    }
	
	    if(syncFlag)
	    {
	    	bocsWriteMode = ContentTransferComponent.IBocsWriteModeConfigurator.BocsWriteMode.SYNC;
	    }
	    else
	    {
	    	bocsWriteMode = ContentTransferComponent.IBocsWriteModeConfigurator.BocsWriteMode.ASYNC;
	    }
	    return bocsWriteMode;
	}
    
	public String getMajorVersionLabel(){
		return majorVersionLabel;
	}
	
	public void onChangeCheckinFromFile(Checkbox checkbox, ArgumentList arg)
    {
		onSelectFile(checkbox, arg);
    }

	public void onSelectFile(Control c, ArgumentList arg)
    {
		super.onSelectFile(c, arg);
		Label messageLabel = (Label)getControl("correcttype",Label.class);
        messageLabel.setVisible(false);
        DfLogger.info(this, " :: messageLabel : Disabled : ", null, null);
    }
	
    IDfDocument doc;
    IdocsUtil idocsUtil;
	private String folderTitle="";
    private String m_objectId = IDocsConstants.MSG_EMPTY_STRING;
    private String majorVersionLabel = null;
    public boolean isWfDocument = false;
    private static final long serialVersionUID = 1L;
	private String m_objectId_attr = "objectId";
    private String m_workflowattribute = "attr_wf_start";
    public static final String STR_TXT_DOCNAME="txtDocumentName"; 
    
}
