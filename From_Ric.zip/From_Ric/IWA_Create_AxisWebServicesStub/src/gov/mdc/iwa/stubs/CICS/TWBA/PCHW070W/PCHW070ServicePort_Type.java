/**
 * PCHW070ServicePort_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W;

public interface PCHW070ServicePort_Type extends java.rmi.Remote {
    public gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070Response_Type PCHW070(gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070Request_Type body) throws java.rmi.RemoteException;
}
