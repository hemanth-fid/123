/**
* This class is for custom behaviour class validates user access,
* and also updates the attribute fields while clicking next button on UI.
* 
* NewDocument custom behaviour class sets security classification for the document and moves the document appropriate folder.
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Gangadhar Reddy.V		02/10/2011		1.2				created
* #######################################################################################################
*/


package org.ifc.idocs.create;

import java.util.Map;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.Button;
import com.documentum.web.form.control.Text;
import com.documentum.web.formext.action.ActionService;
import com.documentum.web.formext.action.CallbackDoneListener;


public class NewDocument extends com.documentum.webcomponent.library.create.NewDocument
{
    private static final long serialVersionUID = 1L;
    private String templateName=""; 

    

	public NewDocument(){
    	super();
    }

    public void showTemplateList(Button button, ArgumentList arg){
		ActionService.execute("showtemplatelist", arg, getContext(), this, new CallbackDoneListener(this, "onReturnFromShowTemplate"));		
	}
	
    
	public void onReturnFromShowTemplate(String strAction, boolean bSuccess, Map map)
	{
		String selectedTemplateName = (String)map.get("templatename");
		if(selectedTemplateName != null && selectedTemplateName.trim().length() > 0){
			Text txtTemplate = (Text)getControl("templateName");
			if(txtTemplate != null )txtTemplate.setValue(selectedTemplateName);
		}
		DfLogger.debug(this, "selectedTemplateName :"+ selectedTemplateName,null,null);
	}
	
	public void setTemplateName(String templateName){
		Text txtTemplate = (Text)getControl("templateName");
		if(txtTemplate != null){
			if(templateName != null && templateName.length() >0)
			txtTemplate.setValue(templateName);
		}
	}
	
	public String getTemplateName() {
		return templateName;
	}
	
    public void onInit(ArgumentList args){
		try {
			
			DfLogger.debug(this, " :: onInit : "+getDfSession().getLoginUserName(), null, null);
			boolean callerComponentstatus=false;
			String callerComponent=args.get("callerComponent");
			if(callerComponent != null && callerComponent.length() > 0){
				if(callerComponent.equalsIgnoreCase("createnewdoc")){
					callerComponentstatus=true;
				}else callerComponentstatus=false;
			}
			
	    	super.onInit(args);
	    	if(callerComponentstatus){
	    		String folderObjectId= args.get("objectId");
				String argstemplateName= args.get("templateName");
				if(folderObjectId != null && folderObjectId.length() > 0){
					args.replace("objectId",folderObjectId);
					templateName=argstemplateName;
			 }
	    	}else{
	    		
	    	}
		} catch (DfException e) {
			DfLogger.error(this, " :: onInit Exception >> "+e.getMessage(), null, e);
		}
    }

    public void onRender(){
		try {
			DfLogger.info(this, " :: onRender : "+getDfSession().getLoginUserName(), null, null);
	        super.onRender();
	        if(getTemplateName() != null && getTemplateName().length() >0){
	        		Text txtTemplate = (Text)getControl("templateName");
	        		if(txtTemplate != null){
	        			if(getTemplateName() != null && getTemplateName().length() >0)
	        			txtTemplate.setValue(getTemplateName());
	        		}
	        }
		} catch (DfException e) {
			DfLogger.error(this, " :: onRender Exception >> "+e.getMessage(), null, e);
		}
    }

    /**
     * This method creates the document on clicking finish on the new document container.
     */
    public boolean onCommitChanges(){
    	boolean documentCreated = false;	
        try{
            documentCreated = super.onCommitChanges();
            String objectId = getNewObjectId();
            IDfSession dfsess = getDfSession();
			DfLogger.info(this, " :: onCommitChanges : "+dfsess.getLoginUserName(), null, null);
        	DfLogger.info(this, " :: onCommitChanges() : NewObjectId : "+objectId,null,null);
            documentCreated=true;
        }catch(DfException e){
			DfLogger.error(this, " :: onCommitChanges Exception >> "+e.getMessage(), null, e);
            return false;
        }
        return documentCreated;
    }
}
