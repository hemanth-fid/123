/**
* This class is check the condition of the Workflow.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.workflow.abort;

import java.io.IOException;
import java.util.Properties;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfWorkflow;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.Label;
import com.documentum.webcomponent.library.messages.MessageService;

public class AbortWorkflow extends com.documentum.webcomponent.library.workflow.abort.AbortWorkflow{
	private static final long serialVersionUID = 1L;
	private static Properties idocsProperties = new Properties();
	private static final String QRY_VARIABLE_WORKFLOWID = "<workflowid>";
	private static final String QRY_VARIABLE_OBJECTID = "<objectid>";
	private boolean canCommit = true;
	private boolean isASWorkflow = false;
	String projectId = IDocsConstants.MSG_EMPTY_STRING;
	
	public void onInit(ArgumentList arg) {
		super.onInit(arg);
		try {
			String wfName = getString("MSG_OBJECT");
			idocsProperties.load(IdocsUtil.class.getResourceAsStream(IdocsConstants.IDOCS_PROPERTY_FILE));
			String folderId = IDocsConstants.MSG_EMPTY_STRING;
			String folderType = IDocsConstants.MSG_EMPTY_STRING;
			String projStatusCode = IDocsConstants.MSG_EMPTY_STRING;
			String folderTypeQry = idocsProperties.getProperty("WF_ATTACHED_DOC_FOLDER_TYPE");
			folderTypeQry = folderTypeQry.replace(QRY_VARIABLE_WORKFLOWID, m_strWorkflowId);
			DfLogger.info(this,": onCommitChanges:: folderTypeQry : " + folderTypeQry, null, null);
			IDfCollection folderTypeColl = IdocsUtil.executeQuery(getDfSession(), folderTypeQry, IDfQuery.DF_READ_QUERY);
			if (folderTypeColl.next() ){
				folderId = folderTypeColl.getString(IdocsConstants.R_OBJECT_ID);
				folderType = folderTypeColl.getString(IdocsConstants.R_OBJECT_TYPE);
				folderTypeColl.close();
			}
			if(folderTypeColl != null)folderTypeColl.close();
			if (folderType != null && folderType.trim().length() > 0 && folderType.equalsIgnoreCase(IdocsConstants.PROJ_FOLDER_TYPE)) {
				String projectStatusCodeQry = idocsProperties.getProperty("PROJECT_STATUS_CODE"); 
				projectStatusCodeQry = projectStatusCodeQry.replace(QRY_VARIABLE_OBJECTID, folderId);
				IDfCollection projStatusCodeColl = IdocsUtil.executeQuery(getDfSession(), projectStatusCodeQry, IDfQuery.DF_READ_QUERY);
				if (projStatusCodeColl.next() ){
					projStatusCode = projStatusCodeColl.getString(IdocsConstants.PROJECT_STATUS_CODE);
					projectId = projStatusCodeColl.getString(IdocsConstants.PROJ_ID);
					projStatusCodeColl.close();
				}
				if(projStatusCodeColl != null)projStatusCodeColl.close();
				
				/*
				 * AS Changes - START
				 */
				if(wfName != null && wfName.startsWith("AS")){
					DfLogger.info(this,": AS abort worklow", null, null);
					isASWorkflow = true;
					canCommit = true;
				}else{					
					if (projStatusCode != null && projStatusCode.trim().length() > 0 && projStatusCode.equalsIgnoreCase("X")==false) {
						DfLogger.info(this,": Cannot abort worklow as Project Status Code is not X : " + projStatusCode, null, null);
						MessageService.addMessage(this, "MSG_CANNOT_ABORT", new Object[] {wfName});
						canCommit = false;
						Label cannotAbort = (Label)getControl("cannotabort",Label.class);
						cannotAbort.setVisible(true);

					}
				}
				
			}
		} catch (IOException e) {
			DfLogger.error(this, " :: onInit: " + e.getMessage(), null, e);
		} catch (DfException e) {
			DfLogger.error(this, " :: onInit: " + e.getMessage(), null, e);
		}

	}
	
	
	public boolean canCommitChanges() {
		DfLogger.debug(this, " :: canCommitChanges :canCommit="+canCommit, null, null);
		if (super.canCommitChanges() == true) {
			DfLogger.debug(this, " :: super.canCommitChanges() == true: ", null, null);
			return canCommit;
		} else {
			return super.canCommitChanges();
		}
	}
	public boolean onCommitChanges() {
		if(canCommit==false){
			/** Donot perform any action just Come out. */
			return true;
		}
		IDfSession admSession = null;
		IDfSessionManager admSMgr = null;
		if(getIsValid()) {
			try {
				admSMgr = IdocsUtil.getAdminSessionManager(getDfSession());
				DfQuery query = new DfQuery();
				StringBuilder deleteWfGroupsQry = new StringBuilder(idocsProperties.getProperty("WF_GROUPS_DELETE_QRY"));
				deleteWfGroupsQry.append(m_strWorkflowId).append("_%'");
				query.setDQL(deleteWfGroupsQry.toString());
				DfLogger.info(this,": Delete Groups Query : " + deleteWfGroupsQry.toString(), null, null);
				admSession = admSMgr.getSession(getDfSession().getDocbaseName());
				IDfCollection collection = query.execute(admSession, IDfQuery.DF_READ_QUERY);
				if (collection.next()) {
					collection.close();
				}
				if (collection != null) {
					collection.close();
				}
				if(isASWorkflow){
					IDfCollection subWfIdColl = null;
					String subWfId = null;
					boolean isActiveWf = false;
					
					String subWfIdQRY = idocsProperties.getProperty("AS_SUB_WF_ID_QRY");
					subWfIdQRY = subWfIdQRY.replaceAll("%workflow_id%", m_strWorkflowId);
					subWfIdColl = IdocsUtil.executeQuery(admSession, subWfIdQRY, IDfQuery.DF_READ_QUERY);
					
					if(null != subWfIdColl){
						try{
							while(subWfIdColl.next()){
								subWfId = subWfIdColl.getString("r_workflow_id");
								IDfWorkflow workflowObj = (IDfWorkflow)admSession.getObject(new DfId(subWfId));
								isActiveWf = IdocsUtil.isActiveWorkflow(workflowObj);
								if(isActiveWf){
									workflowObj.abort();
									DfLogger.info(this, "Workflow is aborted and destroyed...", null, null);
								}
							}
						}
						finally{
							if(subWfIdColl != null){
								subWfIdColl.close();
							}
						}
					}
					IdocsUtil.executeASSevlet(admSession, projectId, idocsProperties, m_strWorkflowId);
				}
				
								
			} catch(DfException e) {
				DfLogger.error(this, (new StringBuilder(" :: onCommitChanges Exception >> ")).append(e.getMessage()).toString(), null, e);
			} finally {
				if (admSMgr != null && admSession != null) {
					admSMgr.release(admSession);
					DfLogger.info(this, "Admin Session Released", null, null);
				}
				else {
					DfLogger.info(this, "Unable to release Admin Session", null, null);
				}
			}
			return super.onCommitChanges();
		} else {
        	return false;
        }	 
    }
}
