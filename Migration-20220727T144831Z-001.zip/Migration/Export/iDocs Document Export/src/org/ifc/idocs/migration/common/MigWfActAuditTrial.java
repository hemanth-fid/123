package org.ifc.idocs.migration.common;


/**
 * @author VVellakkattumana
 * @category MigWfActAuditTrial is a java template class for easy implementation of workflow audit trials
 * 
 */
public class MigWfActAuditTrial {
	
	private String activityId;
	private String activityAuditTrial;
	private String workflowId;
	private String timeStamp;	
	
	public String getWorkflowId() {
		return workflowId;
	}
	
	public void setWorkflowId(String workflowId) {
		this.workflowId = workflowId;
	}
	
	public String getTimeStamp() {
		return timeStamp;
	}
	
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	
	public String getActivityId() {
		return activityId;
	}
	
	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}
	
	public String getActivityAuditTrial() {
		return activityAuditTrial;
	}
	
	public void setActivityAuditTrial(String activityAuditTrial) {
		this.activityAuditTrial = activityAuditTrial;
	}
	
}
