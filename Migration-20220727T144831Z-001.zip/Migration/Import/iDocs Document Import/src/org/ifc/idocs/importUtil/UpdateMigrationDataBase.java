package org.ifc.idocs.importUtil;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.common.DfException;

public class UpdateMigrationDataBase extends ImportUtility implements FilenameFilter
{
	protected static String sourceRoot = "";
	protected static String stagingFolderPath="";
	protected String ext1,ext2,ext3; 
	protected static String dateFormat="MM/dd/yyyy HH:mm:ss a z";
	public UpdateMigrationDataBase(String ext) 
	{
		this.ext1 = "_metadata"+"." + ext;
		this.ext2 = "_discussion"+"." + ext;
		this.ext3 = "_workflow"+"." + ext;
	}

	protected static void readStagingFolder() throws IOException, ParserConfigurationException, SAXException 
	{
		try
		{
			stagingFolderPath=idocsProperties.getProperty("STAGING_FOLDER_PATH");
//			System.out.println("Execution Started...");
			dominoDocLogger.info("Execution Started...");
			getNonXmlDocCount();
		}
		catch(DfException e)
		{
			dominoDocLogger.warning("Error while updating Database for : "+stagingFolderPath);
			dominoDocLogger.warning(e.getMessage());
//			e.printStackTrace();
		}
	}

	private static void getNonXmlDocCount() throws ParserConfigurationException, SAXException, IOException, DfException
	{
		sourceRoot = stagingFolderPath;
		File rootFolder = new File(sourceRoot);
		if(rootFolder.isDirectory())
		{
			File[] categoryFiles=rootFolder.listFiles();
			for(int i=0;i<categoryFiles.length;i++)
			{
				if(categoryFiles[i].isDirectory())
				{
					File[] idFiles=categoryFiles[i].listFiles();
					for(int j=0;j<idFiles.length;j++)
					{
						int nonXmlCount=0;
						if(idFiles[j].isDirectory())
						{
							FilenameFilter onlyFiles=new UpdateMigrationDataBase("xml");
							String nonMetadatFiles[] = idFiles[j].list(onlyFiles);
							for(int k=0;k<nonMetadatFiles.length;k++)
							{
//								System.out.println("getNonXmlDocCount() : File : "+nonMetadatFiles[k]);
//								dominoDocLogger.info("getNonXmlDocCount() : File : "+nonMetadatFiles[k]);
								nonXmlCount++;
							}
						}
//						System.out.println("getNonXmlDocCount() : Non-XML DOC COUNT : "+nonXmlCount+" for Category : "+categoryFiles[i].getName()+" for Id : "+idFiles[j].getName());
						dominoDocLogger.info("getNonXmlDocCount() : Non-XML DOC COUNT : "+nonXmlCount+" for Category : "+categoryFiles[i].getName()+" for Id : "+idFiles[j].getName());
						updateMigrationTable(categoryFiles[i].getName(),idFiles[j].getName(),nonXmlCount);
					}
				}
			}
		}
	}

	private static void updateMigrationTable(String category,String id,int nonXmlCount) throws DfException 
	{
		SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
		Date newDate = new Date();
		String exportedDate = formatter.format(newDate);
		IDfQuery dfquery = new DfQuery();
		if(exists(id))
		{
//			System.out.println("updateMigrationTable() : Updating values for : "+id);
			dominoDocLogger.info("updateMigrationTable() : Updating values for : "+id);
			StringBuilder updateQry=null;
			updateQry=new StringBuilder(idocsProperties.getProperty("MSG_UPD_MIG1")).append(nonXmlCount).append("'").append(idocsProperties.getProperty("MSG_UPD_MIG2")).append(exportedDate).append(idocsProperties.getProperty("MSG_UPD_MIG3")).append(id).append("'");
//			System.out.println("updateMigrationTable() : updateQry : "+updateQry.toString());
			dfquery.setDQL(updateQry.toString());
			dfquery.execute(dfSession, IDfQuery.DF_EXEC_QUERY);
		}
		else
		{
//			System.out.println("updateMigrationTable() : Inserting values for : "+id);
			dominoDocLogger.info("updateMigrationTable() : Inserting values for : "+id);
			dfquery = new DfQuery();
			StringBuilder insertQuery = null;
			insertQuery=new StringBuilder(idocsProperties.getProperty("MSG_EXPORT_MIGRATION_UPDATE")).append(id).append("','").append(category).append("',").append(nonXmlCount).append(",").append(idocsProperties.getProperty("MSG_EXPORT_MIGRATION_UPDATE_REM1")).append(exportedDate).append(idocsProperties.getProperty("MSG_EXPORT_MIGRATION_UPDATE_REM2")).append(idocsProperties.getProperty("MSG_EXPORT_MIGRATION_UPDATE_REM3")); 
//			System.out.println("updateMigrationTable() : insertQuery : "+insertQuery.toString());
			dfquery.setDQL(insertQuery.toString());
			dfquery.execute(dfSession, IDfQuery.DF_EXEC_QUERY );
		}
	}

	private static boolean exists(String id) throws DfException 
	{
		IDfQuery dfquery = new DfQuery();
		StringBuilder exstQuery=null;
		exstQuery=new StringBuilder(idocsProperties.getProperty("DF_EXEC_QUERY")).append(id).append("'");
		dfquery = new DfQuery();
		dfquery.setDQL(exstQuery.toString());
		IDfCollection exstCollection = dfquery.execute(dfSession, IDfQuery.DF_EXEC_QUERY);
		if(exstCollection.next())
		{
			if(exstCollection.getString("idocs_id").equalsIgnoreCase(id))
			{
				if(exstCollection!=null)
				exstCollection.close();
//				System.out.println("exists() : ID : "+id+" Exists...So update");
				return true;
			}
			else
			{
				if(exstCollection!=null)
				exstCollection.close();
//				System.out.println("exists() : ID : "+id+" Does not Exist...So insert");
				return false;
			}
		}
		
		else
		{
			if(exstCollection!=null)
			exstCollection.close();
			return false;
		}
		
	}
	
	public boolean accept(File dir, String name) 
	{
		if(!(name.endsWith(ext1)||name.endsWith(ext2)||name.endsWith(ext3)))
		{
			return true;
		}
		else
		{
			return false;
	    }
	}
}

