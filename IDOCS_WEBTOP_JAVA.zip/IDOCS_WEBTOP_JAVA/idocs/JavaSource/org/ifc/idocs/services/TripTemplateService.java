/**
* 
* This class is to dispplay the attributes in Document properties.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Dinesh R Mahalingam   03/15/2011	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.services;


import java.util.HashMap;
import java.util.Iterator;
import java.util.StringTokenizer;

import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.form.control.databound.ScrollableResultSet;
import com.documentum.web.form.control.databound.TableResultSet;

public class TripTemplateService {
	
	private  String strDatagridLabel = null;
	private  String strSelectTripDetailsTable;
	private  String submissionNum;
	private  String source_name;
	private  String usdamnt;
	private  String sourceAndamount;
	IDfCollection selectTripDetails;
	private  HashMap<String,String> tripIntegrationHP = new HashMap<String,String>();
	IdocsUtil idocsUtil = new IdocsUtil();
	String[] amntandSource;
	
	/**
	 * purpose : To Get the Trip template Details 
	 * @param dfSession
	 * @param strProjectID
	 * @param template_code
	 * @param datagrid
	 * @param templateName
	 * @return
	 * @throws DfException
	 */
	public Datagrid getTripGridDetails(IDfSession dfSession,String strProjectID,int template_code,Datagrid datagrid, String templateName) throws DfException
	{
		String projectID=strProjectID;
		DfLogger.info(this, " :: getTripGridDetails : templateName :" + templateName,null,null);
		String strTripTemplateNames = IdocsUtil.getMessage("TRIP_TEMPLATES");
		DfLogger.info(this, " :: getTripGridDetails : strTripTemplateNames :" + strTripTemplateNames,null,null);
		if (IdocsUtil.checkIfTokenPresent(strTripTemplateNames, templateName, IdocsConstants.MSG_COMMA)){
			ScrollableResultSet rs = buildTableResultSet(dfSession,template_code,projectID);
			if(null != rs && rs.getResultsCount()>0){
				datagrid.getDataProvider().setScrollableResultSet(rs);
				datagrid.getDataProvider().initBind();
				DfLogger.info(this,":: Result set for getTripGridDetails",null,null);
				}else{
					DfLogger.info(this,":: Result set for getTripGridDetails is Empty",null,null);
					datagrid = null;
					}
			}
		return datagrid;		
	}
	
	/**
	 * purpose : To Build TableResultSet 
	 * @param dfSession
	 * @param template_code
	 * @param projectID
	 * @return
	 * @throws DfException
	 */
	
	private ScrollableResultSet buildTableResultSet(IDfSession dfSession,int template_code, String projectID) throws DfException {
		String[] columnHeaders=new String[]{"submission_nbr","source_name","usdamnt"};
		TableResultSet ts = new TableResultSet(columnHeaders);
		DfLogger.info(this,":: Inside Build Result Set",null,null);
		boolean isSubmissionAvailable = calliDeskTable(projectID,dfSession);
		DfLogger.info(this,":: Inside Build Result Set: isSubmissionAvailable"+isSubmissionAvailable,null,null);
		if(isSubmissionAvailable){
			Iterator<String> it = tripIntegrationHP.keySet().iterator(); 
			while(it.hasNext()) { 
				DfLogger.info(this,":: Inside Iteration",null,null);
				submissionNum = it.next().toString();				
				String amountandSource = tripIntegrationHP.get(submissionNum).toString();
				DfLogger.info(this,":: Amountand Source"+amountandSource,null,null);		
				StringTokenizer strTokenizer=new StringTokenizer(amountandSource,"$#@#");
				int i=0;
				while(strTokenizer.hasMoreTokens()){				
					String strQuery=strTokenizer.nextToken();
					
					if(i++==0){
						source_name=strQuery;
						DfLogger.info(this,":: Source Name after Split"+source_name,null,null);
					}else{
						usdamnt=strQuery;
						DfLogger.info(this,":: USD Name after Split"+usdamnt,null,null);
					}
				}  
				if(submissionNum!=null &&source_name!=null && usdamnt!= null){
				String[] tableRow=new String[4]; 
				tableRow[0]=submissionNum;
				DfLogger.info(this,":: Table Row 1"+tableRow[1],null,null);
				tableRow[1]=source_name;
				DfLogger.info(this,":: Table Row 2"+tableRow[2],null,null);
				tableRow[2]=usdamnt;
				DfLogger.info(this,":: Table Row 3"+tableRow[3],null,null);
				tableRow[3]=Integer.toString(template_code);
				DfLogger.info(this,":: Table Row 0"+tableRow[0],null,null);				
				ts.add(tableRow);
			}else{
				DfLogger.info(this,"::Values of submission no "+submissionNum,null,null);
				DfLogger.info(this,"::Values of source name "+source_name,null,null);
				DfLogger.info(this,"::Values of submission no "+usdamnt,null,null);
				}			
		  }	
		}else{
			String[] tableRow=new String[4]; 
			DfLogger.info(this, "Trip template dummy values start", null, null);
			tableRow[0]="1";//submissionNum;
			DfLogger.info(this,":: Table Row 1"+tableRow[1],null,null);
			tableRow[1]="2";//source_name;
			DfLogger.info(this,":: Table Row 2"+tableRow[2],null,null);
			tableRow[2]="3";//usdamnt;
			DfLogger.info(this,":: Table Row 3"+tableRow[3],null,null);
			tableRow[3]="4";//Integer.toString(template_code);
			DfLogger.info(this,":: Table Row 0"+tableRow[0],null,null);				
			ts.add(tableRow);
			DfLogger.info(this, "Trip template dummy values end", null, null);
		}
		return ts;
	}
	
	/**
	 * purpose :to Call the Idesk Tables
	 * @param projectID
	 * @param dfSession
	 * @return
	 * @throws DfException
	 */
	private boolean calliDeskTable(String projectID, IDfSession dfSession) throws DfException {
		
		boolean boolTrip=false;
		strSelectTripDetailsTable= IdocsUtil.getMessage("QRY_DB_TRIPDETAILS_SELECT");	
		DfLogger.info(this,"Inside calliDeskTable:: DB Query"+strSelectTripDetailsTable,null,null);
		strSelectTripDetailsTable=strSelectTripDetailsTable.replaceFirst("'<project_id>'","'"+projectID+"'");
		DfLogger.info(this,"Inside calliDeskTable:: After replacement QRY"+strSelectTripDetailsTable,null,null);
		selectTripDetails = IdocsUtil.executeQuery(dfSession, strSelectTripDetailsTable, IDfQuery.DF_READ_QUERY);
		DfLogger.info(this,":: select TripDetails value "+selectTripDetails,null,null);
		
			while(selectTripDetails != null && selectTripDetails.next()){		
				DfLogger.info(this,":: Collection has value",null,null);
				submissionNum=selectTripDetails.getString("submission_nbr");
				submissionNum=submissionNum.trim();
				DfLogger.info(this,":: submissionNum value before HM"+submissionNum,null,null);
				usdamnt=selectTripDetails.getString("amount");
				usdamnt=usdamnt.trim();
				DfLogger.info(this,":: USDAMNT before HM"+usdamnt,null,null);
				source_name=selectTripDetails.getString("source");
				source_name=source_name.trim();
				DfLogger.info(this,":: Source Name value before HM"+source_name,null,null);
				if(source_name==null || source_name.equals("")){
					source_name="No source";
					DfLogger.info(this,":: source_name value is changed"+source_name,null,null);
				}
				if(usdamnt==null || usdamnt.equals("0")){
					usdamnt="No amount";
					DfLogger.info(this,":: usdamnt value is changed"+usdamnt,null,null);
				}
				sourceAndamount=source_name+"$#@#"+usdamnt;
				sourceAndamount=sourceAndamount.trim();
				DfLogger.info(this,":: sourceAndamount value"+sourceAndamount,null,null);
				DfLogger.info(this,":: submissionNum value before HM insertion"+submissionNum,null,null);
				DfLogger.info(this,":: sourceAndamount value before HM insertion"+sourceAndamount,null,null);
				tripIntegrationHP.put(submissionNum,sourceAndamount);
				DfLogger.info(this,":: Values added in Hash Map",null,null);
				boolTrip=true;
			}
			if(selectTripDetails != null ) 
				selectTripDetails.close();
			
			return boolTrip;
	}
	
	/**
	 * 
	 * @param location
	 * @return
	 */

	public String getDatagridLabel()
	{
		
		return strDatagridLabel;
	}
	public void setDatagridLabel(String strDatagridLabel)
	{
		this.strDatagridLabel = strDatagridLabel;			
	}
	

	
}
