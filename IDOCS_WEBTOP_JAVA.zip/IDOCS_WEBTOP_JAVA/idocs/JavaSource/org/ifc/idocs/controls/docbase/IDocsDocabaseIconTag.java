package org.ifc.idocs.controls.docbase;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Map;

import javax.servlet.jsp.JspWriter;

import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.web.common.AccessibilityService;
import com.documentum.web.common.BrandingService;
import com.documentum.web.common.ImageService;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.Control;
import com.documentum.web.form.ControlTag;
import com.documentum.web.form.Form;
import com.documentum.web.form.control.databound.CellTemplateTag;
import com.documentum.web.form.control.databound.DataProvider;
import com.documentum.web.form.control.databound.DatagridRowTag;
import com.documentum.web.form.control.databound.IDataboundControlTag;
import com.documentum.web.formext.control.docbase.DocbaseIcon;
import com.documentum.web.formext.control.docbase.DocbaseIconTag;
import com.documentum.web.formext.docbase.TypeUtil;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import com.documentum.web.util.SafeHTMLString;

public class IDocsDocabaseIconTag extends DocbaseIconTag {

	private static final String IDOCS_EMAIL_DOC_ASPECT = "idocs_email_doc_aspect";
	private static final String IDOCS_SCANNING_DOC_ASPECT = "idocs_scanning_doc_aspect";
	private static final String MSG_GET_ASPECT_NAME = "select r_aspect_name from idocs_document where r_object_id='";
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public IDocsDocabaseIconTag(){
		m_ObjectId = null;
		m_strSize = null;
		m_strType = null;
		m_strTypeDatafield = null;
		m_strFormat = null;
		m_strFormatDatafield = null;
		m_strLinkcntDatafield = null;
		m_strIsvirtualdocDatafield = null;
		m_strAssembledfromDatafield = null;
		m_strIsfrozenassemblyDatafield = null;
		m_strIsReplicaDatafield = null;
		m_strIsReferenceDatafield = null;
		m_strFolderIdDatafield = null;
		m_strDatafield = null;

	}

	    public void release()
	    {
	        super.release();
	        m_strSize = null;
	        m_strType = null;
	        m_strFormat = null;
	        m_strTypeDatafield = null;
	        m_strFormatDatafield = null;
	        m_strLinkcntDatafield = null;
	        m_strIsvirtualdocDatafield = null;
	        m_strAssembledfromDatafield = null;
	        m_strIsfrozenassemblyDatafield = null;
	    }
	    
	    public void setDatafield(String strDatafield)
	    {
	        m_strDatafield = strDatafield;
	    }
	    
	    protected String getDatafield()
	    {
	        if(m_strDatafield != null && m_strDatafield.equals("CURRENT"))
	        {
	            CellTemplateTag template = (CellTemplateTag)findAncestorWithClass(this, com.documentum.web.form.control.databound.CellTemplateTag.class);
	            if(template != null)
	                m_strDatafield = template.getCurrentField();
	        }
	        return m_strDatafield;
	    }
	    
	    public void setObjectId(String objectId)
	    {
	    	m_ObjectId=objectId;
	    	   
	    }
	    public void setType(String strType)
	    {
	        m_strType = strType;
	       
	    }

	    public void setFormat(String strFormat)
	    {
	        m_strFormat = strFormat;
	     
	    }

	    public void setTypedatafield(String strTypeDatafield)
	    {
	        m_strTypeDatafield = strTypeDatafield;
	    }

	    public void setFormatdatafield(String strFormatDatafield)
	    {
	        m_strFormatDatafield = strFormatDatafield;
	    }

	    public void setLinkcntdatafield(String strLinkcntDatafield)
	    {
	        m_strLinkcntDatafield = strLinkcntDatafield;
	    }

	    public void setIsvirtualdocdatafield(String strIsvirtualdocDatafield)
	    {
	        m_strIsvirtualdocDatafield = strIsvirtualdocDatafield;
	    }

	    public void setAssembledfromdatafield(String strAssembledfromdatafield)
	    {
	        m_strAssembledfromDatafield = strAssembledfromdatafield;
	    }

	    public void setIsfrozenassemblydatafield(String strIsfrozenassemblyDatafield)
	    {
	        m_strIsfrozenassemblyDatafield = strIsfrozenassemblyDatafield;
	    }

	    public void setIsreplicadatafield(String strIsReplica)
	    {
	        m_strIsReplicaDatafield = strIsReplica;
	    }

	    public void setIsreferencedatafield(String strIsReference)
	    {
	        m_strIsReferenceDatafield = strIsReference;
	    }

	    public void setFolderiddatafield(String strFolderId)
	    {
	        m_strFolderIdDatafield = strFolderId;
	    }
	    public void setSize(String strSize)
	    {
	        m_strSize = strSize;
	    }

	    protected Class getControlClass()
	    {
	        return com.documentum.web.formext.control.docbase.DocbaseIcon.class;
	    }

	    protected boolean isDatafieldHandlerClass(Class cl)
	    {
	        return cl.equals(org.ifc.idocs.controls.docbase.IDocsDocabaseIconTag.class);
	    }

	    protected void renderEnd(JspWriter out) throws IOException
	    {
	        DocbaseIcon icon = (DocbaseIcon)getControl();
	        
	        String strAltText = "";
	        if(!icon.isVisible())
	            return;
	        StringBuffer buf = new StringBuffer(150);
	        int iSize = 0;
	        try
	        {
	            iSize = Integer.parseInt(icon.getSize());
	        }
	        catch(Exception e) { }
	        if(iSize != 16 && iSize != 32)
	            iSize = 16;
	        String strImage;
	        strImage = getIconImageUrl(getForm(), icon.getFormat(), icon.getType(), iSize,getEventArgValue(this));
	        String strSize = Integer.toString(iSize);
	        String strOverlayImageUrl = null;
	        if(iSize == 16)
	            if(icon.isReplica())
	            {
	                String strFormat = icon.getFormat();
	                String strIconName = null;
	                String strObjType;
	                if(strFormat != null && strFormat.length() > 0 || (strObjType = icon.getType()) != null && strObjType.length() > 0 && (!strObjType.equalsIgnoreCase("dm_folder") && !TypeUtil.isSubtypeOf(strObjType, "dm_folder")))
	                    strIconName = "file-replica.gif";
	                else
	                    strIconName = "folder-replica.gif";
	                strOverlayImageUrl = BrandingService.getThemeResolver().getResourcePath((new StringBuilder()).append("icons/overlay/").append(strIconName).toString(), getForm().getPageContext(), false);
	            } else
	            if(icon.isReference())
	                strOverlayImageUrl = BrandingService.getThemeResolver().getResourcePath("icons/overlay/shortcut.gif", getForm().getPageContext(), false);
	            else
	            if(icon.getFolderIdLinkCount() > 1)
	                strOverlayImageUrl = BrandingService.getThemeResolver().getResourcePath("icons/overlay/link.gif", getForm().getPageContext(), false);
	        if(strImage != null && icon.getFormat()!= null)
	        {
	            buf.append("<img");
	            buf.append(" width='").append(strSize).append("' height='").append(strSize).append("'");
	            buf.append(renderNameAndId(getControl()));
	            String strClass = icon.getCssClass();
	            if(strClass != null)
	                buf.append(" class='").append(strClass);
	            else
	                buf.append(" class='").append("defaultDocbaseIconStyle");
	            buf.append("'");
	            String strStyle = icon.getCssStyle();
	            if(strStyle != null)
	                buf.append(" style='").append(strStyle).append('\'');
	            buf.append(" src='").append(strImage).append("' border='0'");
	            strAltText = ImageService.getAltText(strImage, getForm().getPageContext(), getForm().getNlsClass());
	            buf.append(" alt='").append(SafeHTMLString.escapeAttribute(strAltText)).append('\'');
	            buf.append(" title='").append(SafeHTMLString.escapeAttribute(strAltText)).append('\'');
	            buf.append(" />");
	            if(strOverlayImageUrl != null)
	            {
	                buf.append("<img");
	                buf.append(" class='").append("docbaseIconOverlay");
	                buf.append("' src='").append(strOverlayImageUrl).append("'");
	                buf.append(" alt=''");
	                buf.append(" />");
	            }
	            out.print(buf.toString());
	        } 
	        if(AccessibilityService.isAllAccessibilitiesEnabled())
	        {
	            DatagridRowTag parent = (DatagridRowTag)findAncestorWithClass(this, com.documentum.web.form.control.databound.DatagridRowTag.class);
	            if(parent != null)
	                parent.appendCustomRowInformation(strAltText);
	        }
	    }
    protected String getEventArgValue(ControlTag parent)
	    {
	       String strValue=null;
	        
	        if(m_strDatafield != null)
	            strValue = resolveDatafield(getDatafield());
	
	        return strValue;
	    }
	    
	    protected String resolveDatafield(String strDatafield)
	    {
	        String strResult = null;
	        DataProvider dataProvider = null;
	        javax.servlet.jsp.tagext.Tag parent = findAncestorWithClass(this, com.documentum.web.form.control.databound.IDataboundControlTag.class);
	        if(parent != null)
	        {
	            dataProvider = ((IDataboundControlTag)parent).getDataProvider();
	            if(dataProvider.hasDataField(strDatafield))
	                strResult = dataProvider.getDataField(strDatafield);
	        }
	        return strResult;
	    }
	    
	    public static String getIconImageUrl(Form form, String strFormat, String strType, int iSize,String objectId)
	    {
	        
	    	String strImage;
	        IDfSessionManager sessionManager;
	        IDfSession dfSession;
	        strImage = null;
	        if(strFormat != null){
	        sessionManager = SessionManagerHttpBinding.getSessionManager();
	        dfSession = null;
	        try
	        {
	            dfSession = sessionManager.getSession(SessionManagerHttpBinding.getCurrentDocbase());
	             if(strFormat != null && strFormat.length() != 0){
	            	 boolean isEmailDoc = false;
	            	 boolean isScannedDoc = false;
	            	 String strQuery = new StringBuilder(MSG_GET_ASPECT_NAME).append(objectId).append(IdocsConstants.MSG_QUOTES).toString();
	            	 IDfCollection collection = IdocsUtil.executeQuery(dfSession, strQuery, IDfQuery.DF_READ_QUERY);
	            	 while(collection.next()){
	            		 String aspectName = collection.getString(IdocsConstants.R_ASPECT_NAME);
	            		 if(isScannedDoc == false && aspectName != null && aspectName.trim().length() > 0 
	            				 && aspectName.equalsIgnoreCase(IDOCS_SCANNING_DOC_ASPECT) == true){
	            			isScannedDoc = true; 
	            		 }
	            		 if(isEmailDoc == false && aspectName != null && aspectName.trim().length() > 0 
	            				 && aspectName.equalsIgnoreCase(IDOCS_EMAIL_DOC_ASPECT) == true){
	            			 isEmailDoc = true; 
	            		 }
	            	 }
	            	 if(collection !=null)collection.close();
	            	 if(isScannedDoc && isEmailDoc){
  					   strImage = resolveFormatIconImage(form, "tiff", iSize);
	  				}else if(isEmailDoc){
	  						strImage = resolveFormatIconImage(form, "msg", iSize);
	  				}else if(isScannedDoc){
	  						strImage = resolveFormatIconImage(form, "tiff", iSize);
	  				}else return strImage;
	             }
	            	 
	        }catch(DfException dfe){
	        	throw new WrapperRuntimeException("Failed to get icon image", dfe);
	        }finally{
	        	if(dfSession != null){
	        		sessionManager.release(dfSession);
	        	}
	        }
	        }
	        return strImage;
	    }
	    
	    private static String resolveFormatIconImage(Form form, String strIcon, int iSize)
	    {
	    	
	        String strUrl = null;
	        if(iSize == 32)
	            strUrl = BrandingService.getThemeResolver().getResourcePath((new StringBuilder()).append("icons/format/f_").append(strIcon).append("_32.gif").toString(), form.getPageContext(), false);
	        else
	            strUrl = BrandingService.getThemeResolver().getResourcePath((new StringBuilder()).append("icons/format/f_").append(strIcon).append("_16.gif").toString(), form.getPageContext(), false);
	        return strUrl;
	    }

	  

	    protected void setControlProperties(Control control)
	    {
	        DocbaseIcon icon;
	        String strResult;
	        super.setControlProperties(control);
	        icon = (DocbaseIcon)control;
	        if(m_strSize != null)
	            icon.setSize(m_strSize);
	        if(m_strFormatDatafield != null && isDatafieldHandlerClass(org.ifc.idocs.controls.docbase.IDocsDocabaseIconTag.class))
	        {
	            strResult = resolveDatafield(m_strFormatDatafield);
	            icon.setFormat(strResult);
	        } else
	        if(m_strFormat != null)
	            icon.setFormat(m_strFormat);
	       
	        return;
	    }

	    
	    private String m_strSize;
	    private String m_strDatafield;
	    private String m_strType;
	    private String m_strTypeDatafield;
	    private String m_strFormat;
	    private String m_strFormatDatafield;
	    private String m_strLinkcntDatafield;
	    private String m_strIsvirtualdocDatafield;
	    private String m_strAssembledfromDatafield;
	    private String m_strIsfrozenassemblyDatafield;
	    private String m_strIsReplicaDatafield;
	    private String m_strIsReferenceDatafield;
	    private String m_strFolderIdDatafield;
	    private static Map g_shouldShowTypeIconMap = new Hashtable();
	    private static final String TYPE_ICON_PATH = "icons/type/";
	    private static final String FORMAT_ICON_PATH = "icons/format/";
	    private static final String OVERLAY_ICON_PATH = "icons/overlay/";
	    private static final String ICON_UNKNOWN_16 = "t_unknown_16.gif";
	    private static final String ICON_UNKNOWN_32 = "t_unknown_32.gif";
	    private static final String ICON_FOLDER_REPLICA_16 = "folder-replica.gif";
	    private static final String ICON_FILE_REPLICA_16 = "file-replica.gif";
	    private static final String ICON_REFERENCE_16 = "shortcut.gif";
	    private static final String ICON_LINK_16 = "link.gif";
	    private static final String ALWAYS_SHOW_TYPE_ICON = "always-show-type-icon";
	    private static final String DOCBASE_ICON = "application.docbaseicon";
	    private String m_ObjectId;

	//========================================================================
}

