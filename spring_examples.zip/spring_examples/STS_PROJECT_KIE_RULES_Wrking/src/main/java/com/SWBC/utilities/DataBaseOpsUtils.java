package com.SWBC.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;

import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;


public class DataBaseOpsUtils {
	
	public static final String __VERSION__ = "1.0.0";

	public static final String LOG_HEADER = "com.swbc.doca.utils.DataBaseOpsUtils("
			+ __VERSION__ + ")";

	private static final String GET_DB_ENDPOINT_PARAMETERS_QUERY = "SELECT property_name, property_value FROM dmc_xcp_app_config WHERE r_object_id = (SELECT r_object_id FROM dmc_xcp_app_config WHERE namespace = ''{0}'' and config_label = ''{1}'') order by i_position";

	public static Connection createSqlConnection(IDfSession session,
			String namespace, String dbEndpoint) throws DfException,
			ClassNotFoundException, SQLException {

		DfLogger.debug(LOG_HEADER, "Create Sql Connection for application : '"
				+ namespace + "' and endpoint : '" + dbEndpoint + "'", null,
				null);

		String dbEndpointParamsQry = MessageFormat.format(
				GET_DB_ENDPOINT_PARAMETERS_QUERY, namespace, dbEndpoint);

		System.out.println("DB Endpoint Parameters Query : ["
				+ dbEndpointParamsQry + "]");

		IDfCollection coll = DCTMOpsUtils.executeQuery(session,
				dbEndpointParamsQry);

		String dbUserName = null;
		String dbPassword = null;
		String dbDriver = null;
		String dbURL = null;

		while (coll.next()) {

			// DB User
			if (coll.getString("property_name").equals("USERNAME_CONFIG_PARAM")) {

				dbUserName = coll.getString("property_value");
				System.out.println("DB Username = " + dbUserName);
			}

			// DB Driver
			if (coll.getString("property_name").equals("DRIVER_CONFIG_PARAM")) {

				dbDriver = coll.getString("property_value");
				System.out.println("DB Driver = " + dbDriver);
			}

			// DB URL
			if (coll.getString("property_name").equals("DB_URL_CONFIG_PARAM")) {

				dbURL = coll.getString("property_value");
				System.out.println("DB URL = " + dbURL);
			}

			// DB Password (xCP Encrypted)
			if (coll.getString("property_name").equals("PASSWORD_CONFIG_PARAM")) {

				dbPassword = coll.getString("property_value");
				System.out.println("Encrypted : DB Password = " + dbPassword);

				// Decrypt password using SINGLETON version of dfClient object
				// xCP Uses SINGLETON version of client and decryptText() with
				// the shown default seed value
				dbPassword = DfClient.getLocalClient().decryptText(dbPassword,
						"bpm_default_seed_value");
				System.out.println("Decrypted : DB Password = " + dbPassword);
			}
		}

		Connection dbConn = createDBConnection(dbURL, dbUserName, dbPassword,
				dbDriver);

		return dbConn;

	}

	public static Connection createDBConnection(String dbURL,
			String dbUserName, String dbPassword, String dbDriver)
			throws ClassNotFoundException, SQLException {

		DfLogger.debug(LOG_HEADER, "Inside createDBConnection()...", null, null);
		Connection conn = null;

		try {
			Class.forName(dbDriver);
			conn = DriverManager.getConnection(dbURL, dbUserName, dbPassword);

			System.out
					.println("Database Connection established, connected to DB URL '"
							+ dbURL + "' for User '" + dbUserName + "'");
			DfLogger.debug(LOG_HEADER,
					"Database Connection established, connected to DB URL '"
							+ dbURL + "' for User '" + dbUserName + "'", null,
					null);

		} catch (ClassNotFoundException cnfe) {
			DfLogger.error(LOG_HEADER, cnfe.getMessage(), null, cnfe);
			throw cnfe;
		} catch (SQLException sqe) {
			DfLogger.error(LOG_HEADER, sqe.getMessage(), null, sqe);
			throw sqe;
		}

		DfLogger.debug(LOG_HEADER, "Database Connection Created for ["
				+ dbDriver + "] : " + conn.toString(), null, null);
		return conn;
	}

	public static void closeDBConnection(Connection conn) throws SQLException {
		try {
			if (conn != null)
				conn.close();

			System.out.println("Database Connection Closed...");
			DfLogger.info(LOG_HEADER, "Database Connection Closed...", null,
					null);

		} catch (SQLException sqe) {
			throw sqe;
		}
	}

	public static void executeUpdateQryInDB(Connection dbConn,
			String updateQry, boolean testMode) throws SQLException {

		DfLogger.info(LOG_HEADER, "Inside executeUpdateQryInDB()...", null,
				null);

		Statement stmt = null;
		try {
			if (!testMode) {
				stmt = dbConn.createStatement();
				stmt.executeUpdate(updateQry);
			}
		} catch (SQLException sqe) {
			throw new SQLException("SQLException in executeUpdateQryInDB() : "
					+ sqe.getMessage());
		} finally {
			if (null != stmt)
				stmt.close();
		}
	}

	public static void executeInsertQryInDB(Connection dbConn,
			String insertQry, boolean testMode) throws SQLException {

		DfLogger.info(LOG_HEADER, "Inside executeInsertQryInDB()...", null,
				null);

		Statement stmt = null;
		try {
			if (!testMode) {
				stmt = dbConn.createStatement();
				stmt.executeUpdate(insertQry);
			}
		} catch (SQLException sqe) {
			throw new SQLException("SQLException in executeInsertQryInDB() : "
					+ sqe.getMessage());
		} finally {
			if (null != stmt)
				stmt.close();
		}
	}

	public static ResultSet executeSelectQryInDB(Connection dbConn,
			Statement stmt, String selectQry) throws SQLException {

		DfLogger.info(LOG_HEADER, "Inside executeSelectQryInDB()...", null,
				null);

		ResultSet result = null;
		try {
			// stmt = dbConn.createStatement();
			result = stmt.executeQuery(selectQry);
		} catch (SQLException sqe) {
			throw new SQLException("SQLException in executeSelectQryInDB() : "
					+ sqe.getMessage());
		}
		return result;
	}

	public static void executeDeleteQryInDB(Connection dbConn,
			String deleteQry, boolean testMode) throws SQLException {

		DfLogger.info(LOG_HEADER, "Inside executeDeleteQryInDB()...", null,
				null);

		Statement stmt = null;

		try {
			if (!testMode) {
				stmt = dbConn.createStatement();
				stmt.executeUpdate(deleteQry);
			}
		} catch (SQLException sqe) {
			throw new SQLException("SQLException in executeDeleteQryInDB() : "
					+ sqe.getMessage());
		} finally {
			if (null != stmt)
				stmt.close();
		}
	}

}
