/**
* This is the custom browser tree control class which extends Webtop's browser tree control
* This customization is to hide the 'Add Repository' link which appears in the OOTB browser tree
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* CVattathara			10/14/2010		1.0					created
* #######################################################################################################
*/
package org.ifc.idocs.controls.browsertree;

import java.util.Iterator;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.TreeNode;
import com.documentum.webtop.control.WebTopBrowserTree;
public class IDocsWebTopBrowserTree extends WebTopBrowserTree
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void onInit(ArgumentList args){
		super.onInit(args);
		Iterator it = getAllNodes();
		if (null != it){
			Object m_Node = null;
			while (it.hasNext()){
				m_Node = it.next();
			}
			if (null != m_Node){
				((TreeNode) m_Node).setVisible(false);
			}
		}
	}
}
