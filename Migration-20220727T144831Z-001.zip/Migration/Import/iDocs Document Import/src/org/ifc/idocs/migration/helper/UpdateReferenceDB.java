package org.ifc.idocs.migration.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.ifc.idocs.migration.importUtility.ImportUtility;

/**
 * UpdateReferenceDB - All the Migration database related connetions and common methods were implemented. 
 * @author HAnuganti
 * 
 * #############################################################################################
 * Author		            DateofChange	 Version	  ModificationHistory
 * ###########################################################################################
 * Hemachandra Anuganti 
 * ###########################################################################################
 * 
 */
public class UpdateReferenceDB extends ImportUtility{

	private static Connection conn;
	private static ResultSet rsTAAS;
	private static ResultSet rsPRODUCT;
	private static ResultSet rsFAV;
	private static PreparedStatement pstmtTAAS;
	private static PreparedStatement pstmtPRODUCT;
	private static PreparedStatement pstmtFAV;
	
	public static Connection getConnection() {
		// TODO Auto-generated method stub
		try {
			
			Class.forName(config.getString("dbReferenceUtilityConnections.driverName"));
			conn = DriverManager.getConnection(config.getString("dbReferenceUtilityConnections.connectionName"),
					config.getString("dbReferenceUtilityConnections.userName"),
					config.getString("dbReferenceUtilityConnections.passwrd"));
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("ClassNotFoundException::" + e.getMessage());
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("SQLException::" + e.getMessage());
			e.printStackTrace();
		}
		return conn;

	}
	
	public static ResultSet selectRecords(String stringQuery, String callerRef) {
		// TODO Auto-generated catch block
		 ResultSet rsCommon = null;		
		try {
			
			if(idocsProperties.getProperty("MSG_PRODUCT_IDENTITY").equals(callerRef)){
				pstmtPRODUCT = conn.prepareStatement(stringQuery.toString());
				rsPRODUCT = pstmtPRODUCT.executeQuery();
				rsCommon = rsPRODUCT;
				
			}else if(idocsProperties.getProperty("MSG_TAAS_IDENTITY").equals(callerRef)){
				pstmtTAAS = conn.prepareStatement(stringQuery.toString());
				rsTAAS = pstmtTAAS.executeQuery();
				rsCommon = rsTAAS;
			}else if(idocsProperties.getProperty("MSG_FAVOURITES_IDENTITY").equals(callerRef)){
				pstmtFAV = conn.prepareStatement(stringQuery.toString());
				rsFAV = pstmtFAV.executeQuery();
				rsCommon = rsFAV;
			}


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("SQLException::" + e.getMessage());
			e.printStackTrace();
		}finally{
			if (pstmtPRODUCT !=null ){
				pstmtPRODUCT = null;
			}
			if (pstmtTAAS !=null ){
				pstmtTAAS = null;
			}
			if (pstmtFAV !=null ){
				pstmtFAV = null;
			}
			
		}
		
		return rsCommon;
	}
	
	public static void updateRecords(String stringQuery,String callerRef) {
		// TODO Auto-generated catch block
		try {
			
			if(idocsProperties.getProperty("MSG_PRODUCT_IDENTITY").equals(callerRef)){
				pstmtPRODUCT = conn.prepareStatement(stringQuery.toString());
				pstmtPRODUCT.executeQuery();
				
				
			}else if(idocsProperties.getProperty("MSG_TAAS_IDENTITY").equals(callerRef)){
				pstmtTAAS = conn.prepareStatement(stringQuery.toString());
				pstmtTAAS.executeQuery();
				
			}else if(idocsProperties.getProperty("MSG_FAVOURITES_IDENTITY").equals(callerRef)){
				pstmtFAV = conn.prepareStatement(stringQuery.toString());
				pstmtFAV.executeQuery();
				
			}
			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("SQLException::" + e.getMessage());
			e.printStackTrace();
		}finally{
			if (pstmtPRODUCT !=null ){
				pstmtPRODUCT = null;
			}
			if (pstmtTAAS !=null ){
				pstmtTAAS = null;
			}
			if (pstmtFAV !=null ){
				pstmtFAV = null;
			}
			
		}
	}
	
	
}
