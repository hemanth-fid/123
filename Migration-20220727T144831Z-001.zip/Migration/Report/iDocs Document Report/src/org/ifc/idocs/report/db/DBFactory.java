package org.ifc.idocs.report.db;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import org.ifc.idocs.report.common.AppConfig;

public class DBFactory {

	protected static AppConfig config = AppConfig.getInstance();
	protected static final String propertiesFile = "/Report.properties";
	protected static Properties idocsProperties = new Properties();
	protected static InputStream inputStream = DBFactory.class.getResourceAsStream(propertiesFile);
	protected static String dvr=config.getString("connection.driver");
	protected static String cname=config.getString("connection.connectionName");
	protected static String uname=config.getString("connection.u_name");
	protected static String pwd=config.getString("connection.password");
	protected static String driverName = dvr;
	protected static String connectionName =cname;
	protected static String dbUserName = uname;
	protected static String dbPassword =pwd;
	protected static ResultSet rs1;

	public static Connection conn;
	public static ResultSet rs;

	public static Connection getConnection() {
		try {
			idocsProperties.load(inputStream);
			if (conn == null){
				Class.forName(driverName);
				conn = DriverManager.getConnection(connectionName,dbUserName,dbPassword);	
			}
		} catch (NullPointerException e) {
			print("NullPointerException - Oracle database connection credentials are wrong. Please check configuration xml file.", true);
		} catch (ClassNotFoundException e) {
			print("ClassNotFoundException - Oracle database connection credentials are wrong. Please check configuration xml file.", true);
		} catch (SQLException e) {
			print("SQLException - Oracle database connection credentials are wrong. Please check configuration xml file.", true);
		} catch (IOException e) {
			print("IOException - Unable to load properties file.", true);
		}
		return conn;
	}

	public void com() throws IOException {//adding explicit commit statement to prevent database locks
		try {
			idocsProperties.load(inputStream);
			getConnection();
			String cmt = idocsProperties.getProperty("AutoCommit");
			PreparedStatement stmt = conn.prepareStatement(cmt);
			stmt.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void print(String message, boolean isExit){
		System.out.println(message);
		if(isExit){
			System.exit(0);
		}		
	}

}
