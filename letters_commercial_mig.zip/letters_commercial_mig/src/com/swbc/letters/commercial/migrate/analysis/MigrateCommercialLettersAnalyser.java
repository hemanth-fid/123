package com.swbc.letters.commercial.migrate.analysis;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.swbc.letters.commercial.migrate.constants.MigrateCommercialConstants;
import com.swbc.letters.commercial.migrate.dbutils.DataBaseConnUtils;
import com.swbc.letters.commercial.migrate.dctmutils.DctmSessionUtil;
import com.swbc.letters.commercial.migrate.utils.CommonUtils;
import com.swbc.letters.commercial.migrate.utils.PropertyReader;

public class MigrateCommercialLettersAnalyser {

	private static Logger log = Logger.getLogger(MigrateCommercialLettersAnalyser.class);
	private static PropertyReader propFile=null;
	private static int commentSuccessCntr;
	private static int commentFailedCntr;
	private static StringBuffer commentSucessRprt=null;
	private static StringBuffer commentfailedRprt=null;
	public String contentFilesDirectory;

	public static final String APP_CONFIG_PROPERTIES_PATH="migrate_commercial_config.properties";



	private static IDfSession m_session = null;
	private static IDfSessionManager m_sessionMgr = null;
	protected static String m_docbase = null;
	protected static String m_userName = null;
	protected static String m_password = null;
	protected static  Connection dbConn=null;



	public static void main(String[] args) throws Exception {

		propFile=new PropertyReader(APP_CONFIG_PROPERTIES_PATH);

		MigrateCommercialLettersAnalyser mig=new MigrateCommercialLettersAnalyser();


		try{

			//dctm session
			m_sessionMgr=DctmSessionUtil.createNewIDfSessionManager(propFile.getProperty(MigrateCommercialConstants.DCTM_USER_NAME).toString(),
					propFile.getProperty(MigrateCommercialConstants.DCTM_PASSWORD).toString(), 
					propFile.getProperty(MigrateCommercialConstants.DCTM_REPO_NAME).toString(),
					propFile.getProperty(MigrateCommercialConstants.DCTM_HOST_NAME).toString(),
					Integer.parseInt(propFile.getProperty(MigrateCommercialConstants.DCTM_PORT_NUMBER).toString()));

			if(m_sessionMgr!=null){

				m_session=m_sessionMgr.getSession(propFile.getProperty(MigrateCommercialConstants.DCTM_REPO_NAME).toString());

			}
 
			//db session
			dbConn = DataBaseConnUtils.createDBConnection
					(propFile.getProperty(MigrateCommercialConstants.DB_URL), 
							propFile.getProperty(MigrateCommercialConstants.DB_USER_NAME), 
							propFile.getProperty(MigrateCommercialConstants.DB_PASSWORD), 
							propFile.getProperty(MigrateCommercialConstants.DB_DRIVER_NAME));

			
			mig.processAnaylze();

		}catch(IOException e){
			log.error("Error : "+ExceptionUtils.getFullStackTrace(e.fillInStackTrace()));
		}catch(DfException e){
			log.error("Error : "+ExceptionUtils.getFullStackTrace(e.fillInStackTrace()));
		}catch(SQLException e){
			log.error("Error : "+ExceptionUtils.getFullStackTrace(e.fillInStackTrace()));
		}catch(ClassNotFoundException e){
			log.error("Error : "+ExceptionUtils.getFullStackTrace(e.fillInStackTrace()));
		}catch(Exception e){
			log.error("Error : "+ExceptionUtils.getFullStackTrace(e.fillInStackTrace()));

		}finally{

			try{
				DataBaseConnUtils.closeDBConnection(dbConn);
			}catch(SQLException e){
				log.error("Error Closing Connection : "+ExceptionUtils.getFullStackTrace(e.fillInStackTrace()));
			}

			try {
				DctmSessionUtil.releaseSession(m_sessionMgr, m_session);
			} catch (DfException e) {
				log.error("Error releasing Connection : "+ExceptionUtils.getFullStackTrace(e.fillInStackTrace()));
			}


		}

	}


	public void processAnaylze(){

		commentSuccessCntr=0;
		commentFailedCntr=0;
		commentSucessRprt=new StringBuffer();
		commentfailedRprt=new StringBuffer();
		contentFilesDirectory=propFile.getProperty(MigrateCommercialConstants.FILES_DIRECTORY).toString();


		try{

			log.info("Start Processing");

			if(CommonUtils.isDirectoryExists(contentFilesDirectory)){
				
				//Map<String,List<String>> filePathMap=CommonUtils.getfilesFromTable(contentFilesDirectory,dbConn);
				Map<String,List<String>> filePathMap=CommonUtils.getfilesFromDirectory(contentFilesDirectory,dbConn);
				CommonUtils.updatMetaAddlColumns(dbConn);
				updateTablewithFilePath(filePathMap);
				
			}else{
				
				log.debug(contentFilesDirectory+" doesn't exist");
			}




			StringBuffer jobReport=new StringBuffer();

			jobReport.append(MigrateCommercialConstants.NEWLINE);

			jobReport.append("Total No. of Records Processed ").append(": ").append(commentSuccessCntr+commentFailedCntr).append(MigrateCommercialConstants.NEWLINE);
			jobReport.append("------------------------------------------------------").append(MigrateCommercialConstants.NEWLINE);
			jobReport.append("Success ").append(": ").append(commentSuccessCntr).append(MigrateCommercialConstants.NEWLINE);
			jobReport.append(commentSucessRprt.toString()).append(MigrateCommercialConstants.NEWLINE);


			jobReport.append("Failed ").append(": ").append(commentFailedCntr).append(MigrateCommercialConstants.NEWLINE);
			jobReport.append(commentfailedRprt.toString());
			jobReport.append("------------------------------------------------------").append(MigrateCommercialConstants.NEWLINE);
			log.info(MigrateCommercialConstants.NEWLINE+jobReport.toString());

			log.info("End Processing");

		}catch(IOException e){
			log.error("Error : "+ExceptionUtils.getFullStackTrace(e.fillInStackTrace()));
		}catch(DfException e){
			log.error("Error : "+ExceptionUtils.getFullStackTrace(e.fillInStackTrace()));
		}catch(SQLException e){
			log.error("Error : "+ExceptionUtils.getFullStackTrace(e.fillInStackTrace()));
		}catch(ClassNotFoundException e){
			log.error("Error : "+ExceptionUtils.getFullStackTrace(e.fillInStackTrace()));
		}catch(Exception e){
			log.error("Error : "+ExceptionUtils.getFullStackTrace(e.fillInStackTrace()));

		}

	}

	public void updateTablewithFilePath(Map<String,List<String>> filePathMap) throws SQLException, IOException{
		
		ResultSet rs=null;
		
		rs=DataBaseConnUtils.executeSelectQryInDB(dbConn, MigrateCommercialConstants.QRY_SELECT_ALL_MIG_TABLE);
		
		if(rs!=null){
			
			while(rs.next()){
				
				String account_no=StringUtils.trim(rs.getString("Old_Comm_Acct"));
				String loan_no=StringUtils.trim(rs.getString("Comm_Ln"));
				String cov_type=StringUtils.trim(rs.getString("Comm_Cov_Type"));
				
				
				//String account_no=StringUtils.trim(Integer.toString(rs.getInt("Old_Comm_Acct")));
				//String loan_no=StringUtils.trim(String.valueOf(rs.getFloat("IH_LOAN_NO")));
				
				
				
				//String fileName="15650004006776";
				String fileName=CommonUtils.buildFileName(FilenameUtils.getBaseName(contentFilesDirectory),account_no,loan_no,cov_type);
				//log.debug(fileName);
				String updateQry="";
				String filePath="";
				
				if(filePathMap!=null && !filePathMap.isEmpty()){

					
					if(filePathMap.containsKey(fileName)){

						filePath=filePathMap.get(fileName).get(0);
						
						updateQry=MessageFormat.format(MigrateCommercialConstants.QRY_UPDATE_ALL_MIG_TABLE,
								"","true",account_no,loan_no);
						//DataBaseConnUtils.executeUpdateQryInDB(dbConn, updateQry,false);

					}else{

						updateQry=MessageFormat.format(MigrateCommercialConstants.QRY_UPDATE_ALL_MIG_TABLE,
								"","false",account_no,loan_no);

					}

					DataBaseConnUtils.executeUpdateQryInDB(dbConn, updateQry,false);
				}
						
			}
		}
		
		
	}
	
	
}
