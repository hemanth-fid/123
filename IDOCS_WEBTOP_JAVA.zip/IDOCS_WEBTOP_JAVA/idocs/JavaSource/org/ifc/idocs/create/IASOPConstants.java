package org.ifc.idocs.create;

public interface IASOPConstants {

	public static final String STR_CREATE_PERMISSION="/create/permission"; 
	public static final String STR_CREATE_MESSAGE="/create/message";
	public static final String STR_CREATE_NOTPOSSIBLE="No";
	public static final String STR_CREATE_NOT_POSSIBLE_ERROR_MESSAGE=" :: Document create permission Denied";
	public static final String STR_SM_UPI_NUMBER="SM_USERDN";
	public static final String STR_SM_USER_NAME="SM_USER";
	public static final String STR_ITEM_VALUE="item_value";
	public static final String STR_STATUS="status";
	public static final String STR_NAME="name";
	public static final String STR_FALSE="false";
	public static final String STR_TRUE="true";
	public static final String STR_ADVISORY_VALUE="advisory";
}



