package gov.dcra.filenet.connection;

import gov.dcra.filenet.constants.Constants;

//import java.io.InputStream;
import java.util.Iterator;
import java.util.Properties;

import javax.security.auth.Subject;

import org.apache.log4j.Logger;

import com.filenet.api.collection.ObjectStoreSet;
//import com.filenet.api.constants.*;
import com.filenet.api.core.Connection;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.util.UserContext;

public class DCRAFileNetConnection {
	
	@SuppressWarnings("unused")
	private final static Logger log=Logger.getLogger(DCRAFileNetConnection.class);
	private  final String credentialPropsFile = Constants.CREDENTAILS_PROPS;
	private  Properties credentialsProps = new Properties();
	
	private Connection getConnection() throws Exception {
		
		
		credentialsProps.load(DCRAFileNetConnection.class.getResourceAsStream(credentialPropsFile));
		
		String uri = credentialsProps.getProperty(Constants.MSG_URL);
		String username = credentialsProps.getProperty(Constants.MSG_USERNAME);
		String password = credentialsProps.getProperty(Constants.MSG_PWD);
		@SuppressWarnings("unused")
		String stanza = credentialsProps.getProperty(Constants.MSG_STANZA);
		Connection conn = Factory.Connection.getConnection(uri);
		Subject subject = UserContext.createSubject(conn, username, password, null);
		UserContext uc = UserContext.get();
		uc.pushSubject(subject);
		return conn;
	}
	
	public Domain getDomain() throws Exception {
		
		String domainName = credentialsProps.getProperty(Constants.MSG_DOMAIN);
		Domain domain = Factory.Domain.fetchInstance(getConnection(), domainName, null);
		return domain;
		
	}
	
	public void getObjectStore(Domain domain) throws Exception {
		
		ObjectStoreSet osSet = domain.get_ObjectStores();
		ObjectStore store;
		Iterator<?> osIter = osSet.iterator();
		while (osIter.hasNext()) 
		{
			store = (ObjectStore)osIter.next();
			System.out.println(store.get_Name());
		}
		
	}

	
}
