package org.ifc.idocs.workflow;

import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.Button;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.TextArea;
import com.documentum.web.formext.component.Component;

public class IDocsDocumentWorkflowDetails extends Component {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String m_objectId;
	public void onInit(ArgumentList args) {
		try {
			String outputString="";
			DfLogger.info(this, "ViewDRL :: onInit : Login Username"+getDfSession().getLoginUserName(), null, null);
			m_objectId = args.get("objectId");
			IDfCollection workflowIdCollection = getDocumentWfIds(m_objectId,getDfSession());
			String documentName = null;
			String workflowName = null;
			while(workflowIdCollection.next()){
				String workflowId = null;
				workflowId = workflowIdCollection.getString("r_workflow_id");
				workflowName = workflowIdCollection.getString("workflowname");
				documentName = workflowIdCollection.getString("documentname");
				if(workflowId != null && workflowId.trim().length() > 0
						&&workflowName != null && workflowName.trim().length() > 0){
					outputString +="Workflow Name \t: "+workflowName+"\n";
					outputString +="Workflow Id \t\t: "+workflowId+"\n";
					String strQueryWorkflowDetails = "select a.r_object_id as workitem_id,a.r_runtime_state as workitem_runitme_state,a.r_act_seqno as activitysequenceno ," +
							"a.r_performer_name as performer, b.object_name as activity_name,a.r_creation_date as workitem_creation_date,q.dequeued_date as cleared_date " +
							"from dmi_workitem a, dm_activity b, dmi_queue_item q  where a.r_runtime_state not in ('2','4') and a.r_workflow_id ='"+workflowId+"' and a.r_act_def_id=b.r_object_id " +
							"and q.r_object_id=a.r_queue_item_id";
					IDfCollection workflowDetailsCollection = IdocsUtil.executeQuery(getDfSession(), strQueryWorkflowDetails, REQUEST_LIFETIME);
					while(workflowDetailsCollection.next()){
						String activityName = workflowDetailsCollection.getString("activity_name");
						String workItemId = workflowDetailsCollection.getString("workitem_id");
						String activitySequenceNo = workflowDetailsCollection.getString("activitysequenceno");
						String performerName = workflowDetailsCollection.getString("performer"); 
						outputString +="Activity Name \t: "+activityName+"\n";
						outputString +="WorkItem Id \t: "+workItemId+"\n";
						outputString +="Activity Sequence No \t: "+activitySequenceNo+"\n";
						if(performerName!=null && performerName.trim().length() > 0 
								&& (performerName.startsWith("idocs_") || performerName.startsWith("as_"))){
							outputString +="Performer Group Name \t: "+performerName+"\n";
						}else{
							outputString +="Performer Name \t: "+performerName+"\n";
						}
					}
					if(workflowDetailsCollection!=null)workflowDetailsCollection.close();
				}
			}
			if(m_objectId!=null){
				outputString = "Document Id \t: "+m_objectId+"\n" + outputString;
			}
			if(documentName!=null){
				outputString = 	"Document Name \t: "+documentName+"\n" + outputString;				
			}
			
			if(workflowName==null){
				outputString = 	outputString + "Document is not part of any workflow \n" ;
			}
			if(workflowIdCollection != null)workflowIdCollection.close();
			if(outputString != null && outputString.trim().length() > 0) {
                TextArea workflowDetails = (TextArea)getControl("workflowid", TextArea.class);
                workflowDetails.setValue((new StringBuilder(String.valueOf(outputString))).toString());
                workflowDetails.setEditable(false);
    		}else {
    			Label errorMessageLabel= (Label)getControl("notpartofworkflow", Label.class);
    			errorMessageLabel.setLabel("This document is not part of any workflow");
            }            	            				
		} catch (DfException e) {
			DfLogger.error(this, "ViewDRL :: onInit Exception >> "+e.getMessage(), null, e);
		}
		super.onInit(args);
	}

	private static IDfCollection getDocumentWfIds(String mObjectId, IDfSession iDfSession) throws DfException {
		String strQueryGetTheWorkflowId="SELECT DISTINCT r_workflow_id,wf.object_name as workflowname,doc.object_name as documentname FROM dm_workflow wf,dmi_package pkg,idocs_document(all) " +
				"doc WHERE ANY pkg.r_component_chron_id=doc.i_chronicle_id and wf.r_object_id=pkg.r_workflow_id and r_runtime_state=1 and " +
				"doc.r_object_id='"+mObjectId+"'";
		IDfCollection workflowIdCollection = IdocsUtil.executeQuery(iDfSession, strQueryGetTheWorkflowId, REQUEST_LIFETIME);
		return workflowIdCollection;
	}
	
	public boolean canCancelChanges() {
		return false;
	}
	

	/**
	 * Allows user to go back to objectlist when closing the DRL window.
	 * @param control
	 * @param args
	 */
	public void onClose(Button control, ArgumentList args){
		setComponentReturn();
	}
}
