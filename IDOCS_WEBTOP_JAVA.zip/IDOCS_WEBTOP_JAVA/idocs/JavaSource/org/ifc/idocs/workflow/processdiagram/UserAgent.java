/**
* This class is cehcks the Browser for open the application
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.workflow.processdiagram;

import java.io.Serializable;
import javax.servlet.http.HttpServletRequest;

public final class UserAgent implements Serializable {
  private HttpServletRequest request = null;
  private String useragent = null;
  private boolean netEnabled = false;
  private boolean ie = false;
  private boolean ie6 = false;
  private boolean ie7 = false;
  private boolean netscape = false;
  private boolean firefox = false;
  
  private boolean opera = false;
  private boolean safari = false;

  public UserAgent(HttpServletRequest paramHttpServletRequest)
  {
    setRequest(paramHttpServletRequest);
  }

  public UserAgent()
  {
  }

  private void setRequest(HttpServletRequest paramHttpServletRequest)
  {
    this.request = paramHttpServletRequest;
    this.useragent = this.request.getHeader("User-Agent");
    if (this.useragent.toLowerCase().indexOf("msie") != -1)
    {
      this.ie = true;
      if (this.useragent.toLowerCase().indexOf("msie 7.") > -1)
        this.ie7 = true;
      if (this.useragent.toLowerCase().indexOf("msie 6.") > -1)
        this.ie6 = true;
    }
    if (this.useragent.toLowerCase().indexOf("opera") >= 0)
      this.opera = true;
    if (this.useragent.toLowerCase().indexOf("safari") >= 0)
      this.safari = true;
    if (this.useragent.toLowerCase().indexOf("netscape") != -1)
      this.netscape = true;
    if (this.useragent.toLowerCase().indexOf("firefox") != -1)
      this.firefox = true;
    if (this.useragent.toLowerCase().indexOf(".net clr") != -1)
      this.netEnabled = true;
  }

  public String getUseragent(HttpServletRequest paramHttpServletRequest)
  {
    setRequest(paramHttpServletRequest);
    return this.useragent;
  }

  public boolean isNetEnabled(HttpServletRequest paramHttpServletRequest)
  {
    setRequest(paramHttpServletRequest);
    return this.netEnabled;
  }

  public boolean isIE(HttpServletRequest paramHttpServletRequest)
  {
    setRequest(paramHttpServletRequest);
    return this.ie;
  }

  public boolean isIE6(HttpServletRequest paramHttpServletRequest)
  {
    setRequest(paramHttpServletRequest);
    return this.ie6;
  }

  public boolean isIE7(HttpServletRequest paramHttpServletRequest)
  {
    setRequest(paramHttpServletRequest);
    return this.ie7;
  }

  public boolean isNetscape(HttpServletRequest paramHttpServletRequest)
  {
    setRequest(paramHttpServletRequest);
    return this.netscape;
  }

  public boolean isFirefox(HttpServletRequest paramHttpServletRequest)
  {
    setRequest(paramHttpServletRequest);
    return this.firefox;
  }

  public boolean isSafari(HttpServletRequest paramHttpServletRequest)
  {
    setRequest(paramHttpServletRequest);
    return this.safari;
  }

  public boolean isOpera(HttpServletRequest paramHttpServletRequest)
  {
    setRequest(paramHttpServletRequest);
    return this.opera;
  }
}