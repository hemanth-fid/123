package org.ifc.idocs.migration.extract;
import java.io.File;
import java.io.IOException;
import java.util.Vector;
import java.util.logging.Level;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import lotus.domino.Database;
import lotus.domino.DbDirectory;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.View;
import lotus.domino.ViewEntry;
import lotus.domino.ViewEntryCollection;

import org.ifc.idocs.migration.ExtractDocuments;
import org.ifc.idocs.migration.common.CommonUtils;
import org.w3c.dom.Element;

/**
 * @author SPankajamsadanan
 *
 */
public class DiscussionMetadata {
	
	/**
	 * getDiscussionDocs method 
	 * @param db
	 * @param document
	 * @param dbDirectory
	 * @param displayPath
	 * @param utilityId
	 * @param region
	 * @return void
	 */
	private static java.util.logging.Logger exportDocLogger = LogHelper.getLogger(ExtractDocuments.class);
	@SuppressWarnings("unchecked")
	public static void getDiscussionDocs(Vector db, Object document, DbDirectory dbDirectory, String displayPath, String utilityId, String region){

		Database sourceDb = null;
		View threadView =  null;
		String sourceName = (String) document;
		String version = null,docId = null;
		ViewEntryCollection discussionCollection = null;
		View threadTopicsView = null;
		ViewEntryCollection threadTopicsCollection = null;
		ViewEntry topic = null;
		Document mainDoc = null;
		DocumentCollection docCollection = null;
		Document doc = null, nxtDoc = null;
		Boolean  flag = true;
		try {
			sourceDb = dbDirectory.openDatabase(sourceName);
		} catch (NotesException e1) {
			flag = false;
			exportDocLogger.warning("***Skipping as unable to open the database "+ sourceName);
		}
		if (flag){
		try {
//			sourceDb = dbDirectory.openDatabase(sourceName);
			threadView = sourceDb.getView("vaThreads");
			discussionCollection = threadView.getAllEntries();
			Integer discussionCount = discussionCollection.getCount();
			exportDocLogger.warning("Count of discussion documents in ~ " + sourceDb.getTitle()+ " ~ is ~ " + discussionCount);
			threadTopicsView = sourceDb.getView("vaThreadsTopicsOnly");
			threadTopicsCollection = threadTopicsView.getAllEntries();
			Integer topicCount = threadTopicsCollection.getCount();
			exportDocLogger.warning("Count of Discussion Docs = " + topicCount + ". Processing...");
			if (topicCount != null && topicCount != 0){
				topic = threadTopicsCollection.getFirstEntry();
				while(topic != null){
					mainDoc = topic.getDocument();
					if (mainDoc != null){
						docId = mainDoc.getItemValueString("DocID");
						version = mainDoc.getItemValueString("DomDocVersion");
						//exportDocLogger.info("Inside view entry = " + docId);
						StringBuffer searchFormulaStringBuffer = new StringBuffer("Form='faMainTopic'|Form='faResponse'|Form='faResponseToResponse'");
						searchFormulaStringBuffer.append(" & DocID='" + docId + "'");
						searchFormulaStringBuffer.append(" & DomDocVersion='" + version + "'");
						String searchFormula = searchFormulaStringBuffer.toString();           
						//exportDocLogger.info("Search Formula = " + searchFormula);
						docCollection = sourceDb.search(searchFormula);//searching document database with above query
						Integer docCount = docCollection.getCount();
						Integer docCounter = 0;
	//					exportDocLogger.warning(docCount + "main docs found in~"+sourceDb+"~"+docId+"~"+version);
						doc = docCollection.getFirstDocument();//getting first matching document
						while(doc != null){
							//exportDocLogger.info(docId + " is a parent document & has " + docCount + " child documents");
							if(docCount == 1){
								//exportDocLogger.info("single document");
								try {
									DiscussionMetadata.extractMainXml(doc, displayPath, utilityId, region);
								} catch (Exception e) {
									e.printStackTrace();
									exportDocLogger.log(Level.WARNING,"DiscussionMetadata.java-Exception", e);
								}
							} else {//if multiple childrens are present
								docCounter++;
								//exportDocLogger.info("Documents counter = " + docCounter);
								DiscussionMetadata.extractMultipleXml(doc, docCollection, displayPath, utilityId, region);
							}
							nxtDoc = docCollection.getNextDocument(doc);
							doc.recycle();
							doc = nxtDoc;
						}
					}
					topic = threadTopicsCollection.getNextEntry(topic);
				}//While
				if(docCollection != null){
				docCollection.recycle();
				}
				if(mainDoc != null){
				mainDoc.recycle();
				}
			}
			threadTopicsCollection.recycle();
			threadTopicsView.recycle();
			discussionCollection.recycle();
			threadView.recycle();
			sourceDb.recycle();
		}//end of else loop
		catch (NotesException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"DiscussionMetadata-NotesException", e);
		}
		}
	}

	/**
	 * extractMultipleXml method extracts multiple child documents
	 * @param mainDoc
	 * @param docCollection
	 * @param displayPath
	 * @param utilityId
	 * @param region
	 * @return void
	 */
	@SuppressWarnings("unchecked")
	public static void extractMultipleXml(Document mainDoc, DocumentCollection docCollection, String displayPath, String utilityId,String region){
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			
			String docId = mainDoc.getItemValueString("DocId");
			String mainDocVersion = mainDoc.getItemValueString("DomDocVersion");
			mainDocVersion = mainDocVersion.replace("Draft:  ", "");
			String sharedFileName = docId +"_"+mainDocVersion+ "_discussion.xml";
			
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			org.w3c.dom.Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("DiscussionDocument");
			rootElement.setAttribute("DocID", docId);
			doc.appendChild(rootElement);
	
//			Integer count = docCollection.getCount();
//			exportDocLogger.info("count of childs = " + count);
			Document eachChild = docCollection.getFirstDocument();
			
			while(eachChild != null){
				String mid = eachChild.getUniversalID();
				String mbody = eachChild.getItemValueString("Body");
				String mcic = eachChild.getItemValueString("CICtopic");
				String mpar = eachChild.getItemValueString("QS_ParentUNID");	//this contains the value of $REF
				String mfrom = eachChild.getItemValueString("From");
				String msub = eachChild.getItemValueString("Subject");
	
				Element child  =  doc.createElement("Message");
				rootElement.appendChild(child);
				child.setAttribute("id", mid);
				
				Element body = doc.createElement("Body");
				body.appendChild(doc.createCDATASection(mbody));
				child.appendChild(body);
	
				Element cic = doc.createElement("CIC");
				cic.appendChild(doc.createTextNode(mcic));
				child.appendChild(cic);
	
				Element ver = doc.createElement("DomDocVersion");
				ver.appendChild(doc.createTextNode(mainDocVersion));
				child.appendChild(ver);
				
				Element from = doc.createElement("From");
				String upId = CommonUtils.extractUPI(mfrom);	// commenting as UPI id id not required
				from.appendChild(doc.createTextNode(upId));	// getting notes name format
				child.appendChild(from);
	
				Element sub = doc.createElement("Subject");
				sub.appendChild(doc.createCDATASection(msub));
				child.appendChild(sub);
	
				Element parent = doc.createElement("Parent");	// this is the $REF field value,which identifies the parentdoc
				parent.appendChild(doc.createTextNode(mpar));
				child.appendChild(parent);
	
				Element dat = doc.createElement("CreatedDate");
				Vector createdVector = NotesSession.getInstance().evaluate("@Created", eachChild);
				String created = (createdVector.elementAt(0)).toString();
				dat.appendChild(doc.createTextNode(created));
				child.appendChild(dat);
				
				eachChild = docCollection.getNextDocument(eachChild);	//traversing to next document
			}
			
			String  folderPath = null;
			folderPath  =  DBConnection.getDiscussionData(utilityId, docId, region, displayPath);
			
		
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			if (folderPath == null){
//				exportDocLogger.warning("Skipping response document ~ " + docId + " ~ as matching entry is not found in ~ " + region + " _idocs_doc_mig_status table");
			}
			else{
				//exportDocLogger.info("MULTIPLE XML PATH FOUND : " + folderPath);
				new File(folderPath).mkdirs();
				StreamResult result =  new StreamResult(new File(folderPath + sharedFileName));
				transformer.transform(source, result); 
				//exportDocLogger.warning(docId + " ~ extracted successfully to ~ " + folderPath);
			}
		} catch (NotesException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"NotesException", e);
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"ParserConfigurationException", e);
		} catch (TransformerException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"TransformerException", e);
		} catch (IOException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"IOException", e);
		} 

	}	//	end of multiple documents
	
	/**
	 * extractMainXml method
	 * @param eachChild
	 * @param displayPath
	 * @param utilityId
	 * @param region
	 * @return void
	 */
	@SuppressWarnings("unchecked")
	public static void extractMainXml(Document eachChild, String displayPath, String utilityId,String region){
		try{
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();

			String docId = eachChild.getItemValueString("DocId");
			String mainDocVersion = eachChild.getItemValueString("DomDocVersion");
			mainDocVersion = mainDocVersion.replace("Draft:  ", "");
			String sharedFileName = docId + "_" + mainDocVersion + "_discussion.xml";
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			org.w3c.dom.Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("DiscussionDocument");
			rootElement.setAttribute("DocID", docId);
			doc.appendChild(rootElement);
	
			String mid = eachChild.getItemValueString("MainID");
			String mbody = eachChild.getItemValueString("Body");
			String mcic = eachChild.getItemValueString("CICtopic");
			String mpar = eachChild.getItemValueString("QS_ParentUNID");	//this contains the value of $REF
			String mfrom = eachChild.getItemValueString("From");
			String upId = CommonUtils.extractUPI(mfrom);	//commenting as UPI id id not required
			rootElement.appendChild(doc.createTextNode(upId));	//getting notes name format
			String msub = eachChild.getItemValueString("Subject");
			
			Element child = doc.createElement("Message");
			rootElement.appendChild(child);
			child.setAttribute("id", mid);
	
			Element body = doc.createElement("Body");
			body.appendChild(doc.createCDATASection(mbody));
			child.appendChild(body);
	
			Element cic = doc.createElement("CIC");
			cic.appendChild(doc.createTextNode(mcic));
			child.appendChild(cic);
	
			Element ver = doc.createElement("DomDocVersion");
			ver.appendChild(doc.createTextNode(mainDocVersion));
			child.appendChild(ver);
	
			Element from = doc.createElement("From");
			from.appendChild(doc.createTextNode(upId));
			child.appendChild(from);
	
			Element sub = doc.createElement("Subject");
			sub.appendChild(doc.createCDATASection(msub));
			child.appendChild(sub);
	
			Element parent = doc.createElement("Parent");	//this is the $REF field value,which identifies the parentdoc
			parent.appendChild(doc.createTextNode(mpar));
			child.appendChild(parent);
			
			Element dat = doc.createElement("CreatedDate");
			Vector createdVector = NotesSession.getInstance().evaluate("@Created", eachChild);
			String created = (createdVector.elementAt(0)).toString();
			created = created.replace("ZE5B","");
			dat.appendChild(doc.createTextNode(created));
			child.appendChild(dat);
			
			String folderPath = null;
			folderPath  = DBConnection.getDiscussionData(utilityId, docId, region,displayPath);
	
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
	
			//exportDocLogger.info("Parent xml final location = " + folderPath);
			if (folderPath == null){
//				exportDocLogger.warning("Skipping parent document ~ " + docId + " as matching entry is not found in ~ " + region + "_idocs_doc_mig_status table"); 
			}else{
				//exportDocLogger.info("SINGLE XML FOUND : " + folderPath);
				new File(folderPath).mkdirs();
				StreamResult result =  new StreamResult(new File(folderPath + sharedFileName));
				transformer.transform(source, result); 
//				exportDocLogger.warning(docId + " ~ parent extracted successfully to ~ " + folderPath);
			}
		}catch (Exception e){
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"Exception", e);
			
		}
	}
}
