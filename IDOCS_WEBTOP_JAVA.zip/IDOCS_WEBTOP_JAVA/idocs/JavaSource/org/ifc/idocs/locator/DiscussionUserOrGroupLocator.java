/**
* This class is for displaying to get list of all users for the specific project and list of to, cc, bcc fields
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Parag Doshi		    11/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.locator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.control.Button;
import com.documentum.web.form.control.Hidden;
import com.documentum.web.form.control.ListBox;
import com.documentum.web.form.control.Option;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.preset.ObjectSelector;
import com.documentum.web.preset.Selector;
import com.documentum.webcomponent.library.locator.LocatorQuery;
import com.documentum.webcomponent.library.locator.QueryFilterSets;


public class DiscussionUserOrGroupLocator extends com.documentum.webcomponent.library.locator.UserOrGroupLocator{
	private static final long serialVersionUID = 1L;
	private boolean m_fIsPrivateGroupVisible;
    private boolean m_fIsWorkQueueGroupVisible;
    private boolean m_bShowUnlistedUsers;
    private String BTN_REMOVE_TO = "removebtn_to";
    private String BTN_REMOVE_CC = "removebtn_cc";
    private String BTN_REMOVE_BCC = "removebtn_bcc";
    private String BTN_ADD_TO = "addbtn_to";
    private String BTN_ADD_CC = "addbtn_cc";
    private String BTN_ADD_BCC = "addbtn_bcc";
    public String strProjectIdArg = "";
    public String strTypeArg = "";
    public String strDocID = "";
    public static String PROJECT_ID = "projectId";

    public DiscussionUserOrGroupLocator(){
        m_fIsPrivateGroupVisible = false;
        m_fIsWorkQueueGroupVisible = false;
        m_bShowUnlistedUsers = false;
    }

    public void onInit(ArgumentList args){
    	//get value of project id as it is used in locator query which is called in super.oninit
        strProjectIdArg = args.get(PROJECT_ID);
        strTypeArg = args.get("type");
        strDocID = args.get("documentID");
        super.onInit(args);
        setInitialDocbaseType("dm_user");
    }

    public void onRender()
    {
    	super.onRender();
    	
    	ListBox add_lb = (ListBox)getControl( "toList", ListBox.class );
    	if(null== add_lb.getOptions() || add_lb.getOptions().size()==0){
    		Option blankOption = new Option();
    		String label = "Name"; 
    		blankOption.setValue("");
    		blankOption.setLabel(label);
    		blankOption.setAccessible(false);
    		blankOption.setCssStyle("background-color: #e4e6ea; font-weight: bold;font-color: #333;text-decoration: underline; " );
    		blankOption.setVisible(false);
        	add_lb.addOption(blankOption);
    	}
    	
    	ListBox add_lb_cc = (ListBox)getControl( "ccList", ListBox.class );
    	if(null== add_lb_cc.getOptions() || add_lb_cc.getOptions().size()==0){
    		Option blankOption = new Option();
    		blankOption.setValue("");
    		blankOption.setLabel("Name");
    		blankOption.setCssStyle("background-color: #e4e6ea;font-weight: bold; font-color: #333;text-decoration: underline; " );
    		blankOption.setVisible(false);
    		add_lb_cc.addOption(blankOption);
    	}
    	
    	ListBox add_lb_bcc = (ListBox)getControl( "bccList", ListBox.class );
    	if(null== add_lb_bcc.getOptions() || add_lb_bcc.getOptions().size()==0){
    		Option blankOption = new Option();
    		blankOption.setValue("");
    		blankOption.setLabel("Name");
    		blankOption.setCssStyle("background-color: #e4e6ea;font-weight: bold; font-color: #333;text-decoration: underline;" );
    		blankOption.setVisible(false);
    		add_lb_bcc.addOption(blankOption);
    	}
    }

    protected LocatorQuery createQuery(){
    	//Modified for custom user group
    	DiscussionUserOrGroupLocatorQuery query = new DiscussionUserOrGroupLocatorQuery();
        query.setPrivateGroupVisible(m_fIsPrivateGroupVisible);
        query.setWorkQueueGroupVisible(m_fIsWorkQueueGroupVisible);
        query.setShowUnlistedUsers(m_bShowUnlistedUsers);
        query.setProjectId(strProjectIdArg);
        query.setType(strTypeArg);
        query.setDocID(strDocID);
        return query;
    }

    protected Selector getPresetSelector(){
        ObjectSelector selector = new ObjectSelector(getConfigBasePath(), getPresetItemId(), getContext());
        selector.setDocbaseType("dm_group");
        selector.setSelectAttr("group_name");
        return selector;
    }

    protected boolean getIsPrivateGroupVisible(){
        return m_fIsPrivateGroupVisible;
    }

    protected boolean getIsWorkQueueGroupVisible(){
        return m_fIsWorkQueueGroupVisible;
    }

    protected boolean getShowUnlistedUsers(){
        return m_bShowUnlistedUsers;
    }

    protected void processConfig(){
        super.processConfig();
        IConfigElement config = lookupElement("privategroupvisible");
        if(config != null){
            String strVal = config.getValue();
            if(strVal.equalsIgnoreCase("true")){
                m_fIsPrivateGroupVisible = true;
            }else{
                m_fIsPrivateGroupVisible = false;
            }
        }
        config = lookupElement("workqueuegroupvisible");
        if(config != null)
        {
            String strVal = config.getValue();
            if(strVal.equalsIgnoreCase("true"))
            {
                m_fIsWorkQueueGroupVisible = true;
            } else
            {
                m_fIsWorkQueueGroupVisible = false;
            }
        }
        config = lookupElement("includeunlisted");
        if(config != null)
        {
            String strVal = config.getValue();
            if(strVal.equalsIgnoreCase("true"))
            {
                m_bShowUnlistedUsers = true;
            } else
            {
                m_bShowUnlistedUsers = false;
            }
        }
    }

    public void initControls()
    {
        setPreviousContainerNavigated(null);
        super.initControls();
    }

    protected void processViewConfig()
    {
        String version = null;
        try
        {
            IDfSession session = getDfSession();
            String serverVersion = session.getServerVersion();
            String baseVersion = serverVersion.substring(0, 3);
            float nServerVersion = 0.0F;
            try
            {
                nServerVersion = Float.parseFloat(baseVersion);
            }
            catch(NumberFormatException exp)
            {
                throw new WrapperRuntimeException(exp.getLocalizedMessage());
            }
            if((double)nServerVersion >= 5D)
            {
                version = "5.0";
            } else
            {
                version = "4.x";
            }
        }
        catch(DfException exp)
        {
            throw new WrapperRuntimeException(exp);
        }
        IConfigElement config = lookupElement("views");
        if(config != null)
        {
            Iterator iterViews = config.getChildElements("view");
            do
            {
                if(!iterViews.hasNext())
                {
                    break;
                }
                IConfigElement viewCfg = (IConfigElement)iterViews.next();
                QueryFilterSets viewdef = new QueryFilterSets(viewCfg);
                String strAttribute = viewCfg.getAttributeValue("applyto");
                if(strAttribute != null && strAttribute.equals(version))
                {
                    m_hashViewDefs.put("root", viewdef);
                    m_hashViewDefs.put("container", viewdef);
                    m_hashViewDefs.put("flatlist", viewdef);
                }
            } while(true);
        }
    }

    protected String getPresetItemId()
    {
        return "group_filter";
    }

    /*
     * @Override - Custom Code
     * @see com.documentum.webcomponent.library.locator.ObjectLocator#onClickAdd(com.documentum.web.form.control.Button, com.documentum.web.common.ArgumentList)
     */
    public void onClickAdd(Button arg0, ArgumentList arg1) 
    {
        try {
//	    	System.out.println("custom_UserOrGroupLocator :: onClickAdd :: Inside Onclick");
	    	String btnName = arg0.getName();
	    	Hidden ctrlHidden = (Hidden)getControl("addobjectids", Hidden.class);
	        String strIds = ctrlHidden.getValue();
//	        System.out.println("custom_UserOrGroupLocator :: onClickAdd :: Hidden Control : "+strIds);
	        ListBox add_lb = null;
	        String userGrpId = "", userGrpName="";
	        boolean exist = false;

	      //set appropriate listbox based on button name
	        if(null!=btnName && !"".equals(btnName))
    		{
        		if(btnName.equals(BTN_ADD_TO)){
        			add_lb = (ListBox)getControl( "toList", ListBox.class );
        		}
        		else if(btnName.equals(BTN_ADD_CC)){
        			add_lb = (ListBox)getControl( "ccList", ListBox.class );
        		}
        		else if(btnName.equals(BTN_ADD_BCC)){
        			add_lb = (ListBox)getControl( "bccList", ListBox.class );
        		}
        		add_lb.setMutable(true);
        		
    		}
	        if(strIds != null && strIds.length() > 0)
	        {
	        	//create tokenizer with all selected objects
	        	StringTokenizer tokenizer = new StringTokenizer(strIds, ";");
	        	while(tokenizer.hasMoreTokens())
	        	{
	        		userGrpId = tokenizer.nextToken();
        			//check if user/group exist in the listbox
	        		exist=existCheck(userGrpId,add_lb);
	            	if(!exist){
	            		//get user/group name for the user/group id(r_object_id)
	            		DfLogger.info(this, ":: onClickAdd:: user/group id: " + userGrpId, null, null);
	            		String query = null;
	            		if(userGrpId.startsWith(IDocsConstants.MSG_USER_OBJ_TYPE)){
	            			query ="select user_name from dm_user where r_object_id='"+userGrpId+"'";
	            			userGrpName=getUserGrpName("user_name", query);
	            		}else{
	            			query ="select group_name from dm_group where r_object_id='"+userGrpId+"'";
	            			userGrpName=getUserGrpName("group_name", query);
	            		}
	            		Option option = new Option();
		        		option.setValue(userGrpId);
		        		option.setLabel(userGrpName);
		        		option.setIsRemovable(true);
		            	//add option for the listbox
		            	add_lb.addOption(option);
		            	add_lb.setForceSelection(true);
	            	}
	        	}
	        	
	        	List lstOptions = add_lb.getOptions();
	        	if(null!=lstOptions && lstOptions.size()>1)
	        	{
		        	Option firstOption = (Option)lstOptions.get(0);
		        	firstOption.setVisible(true);
	        	}
    			//set the values of ListBox in map of the component
        		if(btnName.equals(BTN_ADD_TO)){
        			setReturnValue("toList",add_lb);
        		}
        		else if(btnName.equals(BTN_ADD_CC)){
        			setReturnValue("ccList",add_lb);
        		}
        		else if(btnName.equals(BTN_ADD_BCC)){
        			setReturnValue("bccList",add_lb);
        		}
	        }
        } catch (DfException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    /*
     * @Override - Custom Code
     * @see com.documentum.webcomponent.library.locator.ObjectLocator#onClickRemove(com.documentum.web.form.control.Button, com.documentum.web.common.ArgumentList)
     */
    public void onClickRemove(Button arg0, ArgumentList arg1) 
    {
        try {
	    	String btnName = arg0.getName();
	    	Hidden ctrlHidden = (Hidden)getControl("removeList", Hidden.class);
	        String strIds = ctrlHidden.getValue();
	        String user_id = "", userGrpname="";
	        ListBox lb_source = null;
	        List lst_source = null;

	        //set appropriate listbox based on button name
	        if(null!=btnName && !"".equals(btnName))
    		{
	        	if(btnName.equals(BTN_REMOVE_TO))
	        	{
	        		lb_source = (ListBox)getControl( "toList", ListBox.class );
	        	}
	        	else if(btnName.equals(BTN_REMOVE_CC))
    			{
	        		lb_source = (ListBox)getControl( "ccList", ListBox.class );
    			}
	        	else if(btnName.equals(BTN_REMOVE_BCC))
	        	{
	        		lb_source = (ListBox)getControl( "bccList", ListBox.class );
	        	}
	        	lb_source.setMutable(true);
	        	lst_source = lb_source.getOptions();
    		}

	        //for selected options
	        if(strIds != null && strIds.length() > 0)
	        {
	        	//create tokenizer for selected objects
	        	StringTokenizer tokenizer = new StringTokenizer(strIds, ";");
	        	List<String> lst_removeObjIds = new ArrayList<String> (); // Adding the selected objectIds to a list

	        	//generating list for selected options
	        	while(tokenizer.hasMoreTokens())
	        	{
	        		user_id = tokenizer.nextToken();	        		
	        		lst_removeObjIds.add(user_id);
	        	}        		
        		int count = 0;

        		//searching for selective option if exist in selected list box
        		Option option_lst = null;
        		String strObjectId = "";

        		while(count<lst_source.size()) //iterating through list of options
        		{
    				option_lst = (Option)lst_source.get(count);
    				strObjectId = option_lst.getValue();		        				        				

					//compare the objectIds in the lst_source and the lst_removeObjIds and if option exist, then remove it
    				if(lst_removeObjIds.contains(strObjectId))
    				{
    					String query = null;
	            		if(strObjectId.startsWith(IDocsConstants.MSG_USER_OBJ_TYPE)){
	            			query ="select user_name from dm_user where r_object_id='"+strObjectId+"'";
	            			userGrpname=getUserGrpName("user_name", query);
	            		}else{
	            			query ="select group_name from dm_group where r_object_id='"+strObjectId+"'";
	            			userGrpname=getUserGrpName("group_name", query);
	            		}
	            		//user_name=getUserName(str_ObjectId);
						DfLogger.debug(this,"custom_UserOrGroupLocator :: onClickRemove :: UserName : "+userGrpname+" Removed",null,null);
				        lst_source.remove(count);

				        //reducing count to match with lst_source.size() as after removing option it will be -1
				        count--;
					}
					count++;
        		}
        		
        		List lstOptions = lb_source.getOptions();
	        	if(null!=lstOptions && lstOptions.size()==1)
	        	{
		        	Option firstOption = (Option)lstOptions.get(0);
		        	firstOption.setVisible(false);
	        	}
        		
        		if(btnName.equals(BTN_ADD_TO)){
        			setReturnValue("toList",lb_source);
        		}
        		else if(btnName.equals(BTN_ADD_CC)){
        			setReturnValue("ccList",lb_source);
        		}
        		else if(btnName.equals(BTN_ADD_BCC)){
        			setReturnValue("bccList",lb_source);
        		}
	        }

        } catch (DfException e) {
        	DfLogger.error(this," :: onClickRemove :: DfException  " + e.getMessage(),null,null);
		}
    }

    /*
     * GetUser/Group Name returns userName for user_id
     */
	private String getUserGrpName(String attrName, String queryUserGrpName) throws DfException {
        
		String userName = null;
		IDfCollection coll=IdocsUtil.executeQuery(getDfSession(),queryUserGrpName,IDfQuery.DF_READ_QUERY);
		try {
			while(coll.next()){
				userName=coll.getString(attrName);
			}
		} catch (Exception e) {
			DfLogger.error(this," :: getUserGrpName: :: DfException  " + e.getMessage(),null,null);
		}finally{
			if(coll != null ){
				coll.close();
			}
		}	
		return userName;
	}

	/*
	 * checks the user_id in listbox, if exists will return true
	 */
	private boolean existCheck(String user_id, ListBox lb) throws DfException {

		boolean exist=false;
		int count = 0 ;
		List existing_users = lb.getOptions();
		Option option_lst = null;
		String str_ObjectId = "";

		//check for existing users in listbox
		while(count<existing_users.size())
		{
			option_lst = (Option)existing_users.get(count);
			str_ObjectId = option_lst.getValue();

			//compare the objectIds in the lst_source and the lst_removeObjIds and if option exist, then remove it
			if(str_ObjectId.equals(user_id))
			{
				exist=true;
				break;
			}
			else
			{
				exist=false;
			}
			count++;
		}
		return exist;
	}
}
