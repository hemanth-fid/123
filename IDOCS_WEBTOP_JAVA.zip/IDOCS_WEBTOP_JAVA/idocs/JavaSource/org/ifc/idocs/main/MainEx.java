
/**
* This class is diaplays the folder related attribues.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* DShivnani			    10/25/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.main;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.queryservices.IDocsQRYVO;
import org.ifc.idocs.titlebar.TitleBar;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.SessionState;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IPreferenceStore;
import com.documentum.web.formext.config.PreferenceService;
import com.documentum.webtop.app.AppSessionContext;



public class MainEx extends com.documentum.webtop.webcomponent.main.MainEx {
	
	private static final String ARGUMENT_OBJECT_ID = "objectId";
	private static final String EMPTY_STRING = "";
	private static final String R_OBJECT_ID = "r_object_id";
	private static final String SINGLE_QUOTED = "'";
	private static final String DOUBLE_QUOTES = "''";
	private static final String MSG_BLANK_SPACE = " ";
	private static final String ARG_PROJECT_ID = "projectId";
	private static final String QRY_PRJ_FOLDER = "QRY_PRJ_FOLDER";
	private static final String ARG_PARTNER_ID = "partnerId";
	private static final String QRY_PARTNER_FOLDER = "QRY_PARTNER_FOLDER";
	private static final String QRY_COUNTRY_FOLDER = "QRY_COUNTRY_FOLDER";
	private static final String ARG_COUNTRY_CODE = "country_code";
	private static final String SELECT_R_OBJECT_ID_FROM = "select r_object_id from ";
	private static final long serialVersionUID = 1L;
	public static final String URL_PREV_VALUE="URL_String_Value";
	public static final String URL_PREV_COUNT_VALUE="URL_Iteration_Count";
	
	public MainEx() {
		if((IDocsQRYVO.templateMapObject.size() == 0 || IDocsQRYVO.tableDataValues.size() == 0)  || IDocsQRYVO.canUpdatetheQueryServices()){
			IDocsQRYVO.IntiateQRYServices(getDfSession());
		}
	}

	/**
	 * 
	 */
	public void onInit(ArgumentList args) {
		
		try {
			String strFolderId = getFolderId(args);
			if(strFolderId != null && strFolderId.trim().length() >0) {
				args.replace(ARGUMENT_OBJECT_ID, strFolderId);			
			}
			
			javax.servlet.http.HttpSession httpSession = getPageContext().getSession();
			setSourceName(args.get(RESOURCE_ENTITY_ID),httpSession);
			setResourceKey(args.get(RESOURCE_KEY),httpSession);
			setInstitutionNumber(args.get(INSTITUTION_NBR),httpSession);
		} catch(Exception e) {
			DfLogger.error(this, " :: onInit Exception >> "+e.getMessage(), null, e);
		}
		super.onInit(args);
		if(isStreamlineViewVisible()) {
			args.replace("preferredVersion", "5.3");
			setComponentJump(getComponentId(), args, new Context(getContext()));
		}
	}
	

	/**
	 * 
	 * @param args
	 * @return
	 */
	private String getFolderId(ArgumentList args) {
		String strFolderId = EMPTY_STRING;
		String strFolderquery = EMPTY_STRING;
		boolean entryArgStatus=false;
		try {
			
			javax.servlet.http.HttpSession httpSession = getPageContext().getSession();
			setStrType(args.get(ARG_TYPE),httpSession);
			String strType = getstrType(httpSession); 
			String strId=getstrId(httpSession);
			if(strType != null && strType != MSG_BLANK_SPACE) {
				if(strType.equals(STR_PROJECT_TYPE)){
					entryArgStatus=true;
					setstrId(args.get(ARG_PROJECT_ID),httpSession);
					strId=getstrId(httpSession);
					if(strId != null && strId.trim().length() > 0) {
						strFolderquery=IdocsUtil.getMessage(QRY_PRJ_FOLDER);
						strFolderquery = strFolderquery.replaceFirst(DOUBLE_QUOTES, SINGLE_QUOTED+strId.trim()+SINGLE_QUOTED);
					}
				} else if(strType.equals(STR_PARTNER_TYPE)){
					entryArgStatus=true;
					setstrId(args.get(ARG_PARTNER_ID),httpSession);
					strId=getstrId(httpSession);
					if(strId != null && strId.trim().length() > 0) {
						strFolderquery=IdocsUtil.getMessage(QRY_PARTNER_FOLDER);
						strFolderquery = strFolderquery.replaceFirst(DOUBLE_QUOTES, SINGLE_QUOTED+strId.trim()+SINGLE_QUOTED);
					}
				} else if(strType.equals(STR_COUNTRY_TYPE)){
					entryArgStatus=true;
					setstrId(args.get(ARG_COUNTRY_CODE),httpSession);
					strId=getstrId(httpSession);
					if(strId != null && strId.trim().length() > 0 ) {
						strFolderquery=IdocsUtil.getMessage(QRY_COUNTRY_FOLDER);
						strFolderquery = strFolderquery.replaceFirst(DOUBLE_QUOTES, SINGLE_QUOTED+strId.trim()+SINGLE_QUOTED);
					}
				} else {
					strFolderquery =EMPTY_STRING;
				}
				String directNavigationQuery = (String)SessionState.getAttribute(IDocsConstants.DIRECT_NAVIGATION_IDESK);
				if(strFolderquery!= null && strFolderquery.trim().length() >0){
					strFolderquery = SELECT_R_OBJECT_ID_FROM+strFolderquery;
					if(directNavigationQuery != null && directNavigationQuery.trim().length() > 0
							&& directNavigationQuery.equals(strFolderquery) ==true){
					}else {
						IDfCollection collection = IdocsUtil.executeQuery(getDfSession(), strFolderquery, IDfQuery.DF_READ_QUERY);
						while(collection.next()){
							strFolderId = collection.getString(R_OBJECT_ID);
							SessionState.setAttribute(IDocsConstants.DIRECT_NAVIGATION_IDESK, strFolderquery);
						}
						if(collection !=null )collection.close();
					}
				}
			}else entryArgStatus=false;
			if(entryArgStatus){
					AppSessionContext.setEntryPointInView("cabinets");
			}else{
				String pageUrl=getPageURL();
				HttpServletRequest request = (HttpServletRequest) this.getPageContext().getRequest();
				pageUrl=request.getRequestURL().toString();
				if(pageUrl.contains(TitleBar.STR_TASK_STARTINGARGS1) ||pageUrl.contains(TitleBar.STR_TASK_STARTINGARGS2)){
					AppSessionContext.setEntryPointInView(TitleBar.CONTROL_INBOX);
				}
			}
			DfLogger.info(this, " :: Login User : " + getDfSession().getLoginUserName()+"  strFolderId ::"+strFolderId, null, null);
		} catch(Exception e){
			DfLogger.error(this,": getFolderId Exception >> "+e.getMessage(),null,e);
		}
		return strFolderId;
	}
	private void setStrType(String strTypeValue, HttpSession httpSession) {
		httpSession.setAttribute(ARG_TYPE,strTypeValue);
	}

	public static void setSourceName(String source,HttpSession httpSession) {
		httpSession.setAttribute(RESOURCE_ENTITY_ID,source);
	}
	
	public static String getSourceName(HttpSession httpSession){
		String resourceEntityId = (String)httpSession.getAttribute(RESOURCE_ENTITY_ID);
		if(resourceEntityId !=null && resourceEntityId.trim().length() >0){
			return resourceEntityId.trim();
		}else{
			return IDocsConstants.MSG_EMPTY_STRING;
		}
	}
	
	public static void setResourceKey(String rsKey,HttpSession httpSession) {
		httpSession.setAttribute(RESOURCE_KEY,rsKey);
	}
	
	public static String getResourcekey(HttpSession httpSession){
		String resourceKey = (String)httpSession.getAttribute(RESOURCE_KEY);
		if(resourceKey !=null && resourceKey.trim().length() >0){
			return resourceKey.trim();
		}else{
			return IDocsConstants.MSG_EMPTY_STRING;
		}
	}
	
	public static void setInstitutionNumber(String institutionNumber,HttpSession httpSession) {
		httpSession.setAttribute(INSTITUTION_NBR,institutionNumber);
	}
	
	public static String getInstitutionNumber(String institutionNumber,HttpSession httpSession) {
		String strArgInstitutionNumber = (String)httpSession.getAttribute(INSTITUTION_NBR);
		if(strArgInstitutionNumber !=null && strArgInstitutionNumber.trim().length() >0){
			return strArgInstitutionNumber.trim();
		}else{
			return IDocsConstants.MSG_EMPTY_STRING;
		}
	}
	
	public static String getstrType(HttpSession httpSession){
		String strArgType = (String)httpSession.getAttribute(ARG_TYPE);
		if(strArgType !=null && strArgType.trim().length() >0){
			return strArgType.trim();
		}else{
			return IDocsConstants.MSG_EMPTY_STRING;
		}
	}
	
	public static String getstrId(HttpSession httpSession){
		String strIdArg= (String)httpSession.getAttribute(ARG_STR_ID);
		if(strIdArg !=null && strIdArg.trim().length() >0){
			return strIdArg.trim();
		}else{
			return IDocsConstants.MSG_EMPTY_STRING;
		}
	}
	
	public static void setstrId(String strIdValue,HttpSession httpSession){
		httpSession.setAttribute(ARG_STR_ID,strIdValue);
		
	}
	
	public static final String STR_PROJECT_TYPE = "PROJECT";
	public static final String STR_PARTNER_TYPE = "PARTNER";
	public static final String STR_COUNTRY_TYPE = "COUNTRY";
	public static final String RESOURCE_ENTITY_ID = "resource_entity_id";
	public static final String INSTITUTION_NBR = "institution_nbr";
	public static final String RESOURCE_KEY = "resource_key";
	public static final String ARG_TYPE="type";
	public static final String ARG_STR_ID="argStrId";

}
