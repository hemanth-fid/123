package org.ifc.idocs.forms.adaptors;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.jxpath.JXPathContext;
import org.w3c.dom.Document;

import com.documentum.fc.common.DfLogger;
import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.xforms.engine.XFormsProcessorException;
import com.documentum.xforms.engine.adaptor.validator.IDocumentValidator;

public class SPIFormValidator implements IDocumentValidator {

	public boolean validate(Document document) throws XFormsProcessorException {
		boolean retvalue = true;
		String exception = "";
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date now = new Date();
		DfLogger.info(this,"SPIFormValidator:: Inside SPIFormValidator",null,null); 
		JXPathContext validateContext = JXPathContext.newContext(document);

		String validationFilter = validateContext.getPointer(
				"/iDOCs_SPI_Form/validation_filter").getValue().toString();
		DfLogger.info(this,"SPIFormValidator:: Validation Filter is "+ validationFilter,null,null);
		if (validationFilter.equals("form1")) {
			String strBoardDate = validateContext
					.getPointer(
							"/iDOCs_SPI_Form/ProjectedBoardDateGrp/projected_board_date")
					.getValue().toString();
			Date boardDate = new Date();

			if (strBoardDate.length() > 0) {
				try {
					boardDate = dateFormat.parse(strBoardDate);
					System.out
							.println("SPIFormValidator:: Projected Board Date from XPath is "
									+ boardDate);
				} catch (java.text.ParseException e) {
					DfLogger.error(this,": <<Exception>> : "+e.getMessage(),null,e);
				}

				if (!boardDate.after(now)) {
					retvalue = false;
					exception = exception
							.concat("\nProjected Board Date should be future date.");
				}
			}
		}

		else if (validationFilter.equals("form2")) {
			String clientClearance = validateContext.getPointer(
					"/iDOCs_SPI_Form/TL1ClearGrp/factual_accuracy_clearance")
					.getValue().toString();
			String strDateOfClearance = validateContext.getPointer(
					"/iDOCs_SPI_Form/TL1ClearGrp/date_of_clearance").getValue()
					.toString();
			Date clearanceDate = new Date();
			String strBoardDate = validateContext
					.getPointer(
							"/iDOCs_SPI_Form/ProjectedBoardDateGrp/projected_board_date")
					.getValue().toString();
			Date boardDate = new Date();

			if (strBoardDate.length() > 0) {
				try {
					boardDate = dateFormat.parse(strBoardDate);
					System.out
							.println("SPIFormValidator:: Projected Board Date from XPath is "
									+ boardDate);
				} catch (java.text.ParseException e) {
					DfLogger.error(this,": <<Exception>> : "+e.getMessage(),null,e);
				}

				if (!boardDate.after(now)) {
					retvalue = false;
					exception = exception
							.concat("\nProjected Board Date should be future date.");

				}
			}

			if (clientClearance.equals("no")) {
				retvalue = false;
				exception = exception
						.concat("\nClient Clearance is required to complete the activity.");
			} else if (clientClearance.equals("yes")
					&& strDateOfClearance.length() > 0) {

				try {
					clearanceDate = dateFormat.parse(strDateOfClearance);
					System.out
							.println("SPIFormValidator:: Client Clearance Date from XPath is "
									+ clearanceDate);
				} catch (java.text.ParseException e) {
					DfLogger.error(this,": <<Exception>> : "+e.getMessage(),null,e);
				}

				if (clearanceDate.after(now)) {
					retvalue = false;
					exception = exception
							.concat("\nThe Clearance Date has to be today or past.");

				}

			} else if (clientClearance.equals("yes")
					&& strDateOfClearance.length() <= 0) {
				retvalue = false;
				exception = exception
						.concat("\nClearance date cannot be empty.");
			}

		} else if (validationFilter.equals("form3")) {
			String limitedDisclosure = validateContext.getPointer(
					"/iDOCs_SPI_Form/LimitedDisclosureGrp/limited_disclosure")
					.getValue().toString();
			String rationale = validateContext
					.getPointer(
							"/iDOCs_SPI_Form/LimitedDisclosureGrp/ltd_disclosure_rationale")
					.getValue().toString();

			if (limitedDisclosure.equals("yes") && rationale.length() <= 0)

			{
				retvalue = false;
				exception = exception.concat("\nRationale cannot be empty.");
			}

		}

		if (retvalue == false) {
			XFormsProcessorException e = new XFormsProcessorException(exception);
			throw e;
		}
		return retvalue;
	}

	public void destroy() throws AdaptorException {
	}

	public void init(IAdaptorConfiguration arg0) throws AdaptorException {
	}
}