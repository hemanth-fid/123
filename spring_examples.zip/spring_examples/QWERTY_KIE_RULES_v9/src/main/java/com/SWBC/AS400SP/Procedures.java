package com.SWBC.AS400SP;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class Procedures 
{
	
	public static void getAS400AutoLoanStatus(Connection as400_conn, String accountNumber, String loanNumber, String loanSuffix, String AS400LibPath, ArrayList<String> libraryList) 
	{
		CallableStatement stmt = null;
		CallableStatement setPathStmt = null;
		
	
		
		try 
		{
			setPathStmt = as400_conn.prepareCall(AS400LibPath);
			setPathStmt.executeUpdate();
			setLibraryList(libraryList,as400_conn,true);
			

			stmt = as400_conn.prepareCall("call SQS920(?,?,?,?,?)",
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			
			//Input
			stmt.setString(1, accountNumber);
			stmt.setString(2, loanNumber);
			stmt.setString(3, loanSuffix);
			
			//Output
			stmt.setString(4, new String());
			stmt.setString(5, new String());

			stmt.registerOutParameter(1, Types.CHAR);
			stmt.registerOutParameter(2, Types.CHAR);
			stmt.registerOutParameter(3, Types.CHAR);
			stmt.registerOutParameter(4, Types.CHAR);
			stmt.registerOutParameter(5, Types.CHAR);

			// Execute Store PROC
			stmt.executeUpdate();

			System.out.println("Auto Loan Status Done");
			System.out.println("Insurance Status Parameter[1] Loan Status:"+ stmt.getString(4));
			System.out.println("Insurance Status Parameter[2] Error Message:"+ stmt.getString(5));

			setLibraryList(libraryList,as400_conn,false);
		} 
		catch (Exception e) 
		{
			System.out.println("Error getAS400AutoLoanStatus: "
					+ e.toString());

		}
	}
	
    public static void setLibraryList(ArrayList<String> libraries, Connection connection, Boolean addEntries) 
    {
        String cmd = new String();
        CallableStatement stmt = null;
        cmd = addEntries ? "ADDLIBLE" : "RMVLIBLE";
        //Collections.reverse(libraries);
        for(String lib : libraries) 
        {
               try 
               {
                     //logger.log(Level.FINE, cmd + " " + lib + "' to library list");
                     stmt = connection.prepareCall("CALL QSYS2.QCMDEXC('" + cmd + " " + lib.trim() + "')");
                     stmt.executeUpdate();
               } 
               catch (Exception e) 
               {
            	   System.out.println("Error setLibraryList For Loop Block: "
       					+ e.toString());
               } 
               finally {
                     try {
                            stmt.close();
                     } 
                     catch (SQLException e) 
                     {
                    	 System.out.println("Error setLibraryList Finally Block: "
                					+ e.toString());
                     }
               }
        }                          
 }
    
    public static Map<String, String> getAS400MortgageLoanStatus(Connection as400_conn, String accountNumber, String loanNumber, String loanSuffix, 
String covType, String AS400LibPath, ArrayList<String> libraryList) 
	{
		CallableStatement stmt = null;
		CallableStatement setPathStmt = null;
		
		Map<String, String> statusMap = new HashMap<String, String>();
		
		System.out.println("Inside getAS400MortgageLoanStatus()");
		
		try 
		{
			setPathStmt = as400_conn.prepareCall(AS400LibPath);
			setPathStmt.executeUpdate();
			
			//Setting the library list
			setLibraryList(libraryList,as400_conn,true);
			

			stmt = as400_conn.prepareCall("call SQS916(?,?,?,?,?,?)",
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			
			//Input
			stmt.setString(1, accountNumber);
			stmt.setString(2, loanNumber);
			stmt.setString(3, loanSuffix);
			stmt.setString(4, covType);
			
			//Output
			stmt.setString(5, new String());
			stmt.setString(6, new String());

			stmt.registerOutParameter(1, Types.CHAR);
			stmt.registerOutParameter(2, Types.CHAR);
			stmt.registerOutParameter(3, Types.CHAR);
			stmt.registerOutParameter(4, Types.CHAR);
			stmt.registerOutParameter(5, Types.CHAR);
			stmt.registerOutParameter(6, Types.CHAR);

			// Execute Store PROC
			stmt.executeUpdate();

			System.out.println("Mortgage Loan Status Done");
			System.out.println("Insurance Status Parameter[1] Loan Status:"+ stmt.getString(5));
			System.out.println("Insurance Status Parameter[2] Error Message:"+ stmt.getString(6));
			
			statusMap.put("Loan_Ins_Status", stmt.getString(5));
			statusMap.put("Error_Msg",stmt.getString(6));
			
			

			//Remove Library List
			setLibraryList(libraryList,as400_conn,false);
			
		
		} 
		catch (Exception e) 
		{
			System.out.println("Error getAS400MortgageLoanStatus: "
					+ e.toString());

		}
		return statusMap;
	}
    
    
    public static void getPayeeInformation(Connection as400_conn, String accountNumber, String payeeID, String AS400LibPath, ArrayList<String> libraryList) 
  	{
  		CallableStatement stmt = null;
  		CallableStatement setPathStmt = null;
  		
  		System.out.println("Inside getPayeeAddressInfo()");
  		
  		try 
  		{
  			setPathStmt = as400_conn.prepareCall(AS400LibPath);
  			setPathStmt.executeUpdate();
  			
  			//Setting the library list
  			setLibraryList(libraryList,as400_conn,true);
  			

  			//Account Number and Payee ID [FMS0101 - Client Payee Table Account and Payee Info]
  			stmt = as400_conn.prepareCall("call SQS180(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
  					ResultSet.TYPE_SCROLL_INSENSITIVE,
  					ResultSet.CONCUR_READ_ONLY);
  			
  			//Input
  			stmt.setString(1, accountNumber);
  			stmt.setString(2, payeeID);
  			
  		    //Output
  			stmt.setString(3, new String());
  			stmt.setString(4, new String());
  			stmt.setString(5, new String());
  			stmt.setString(6, new String());
  			stmt.setString(7, new String());
  			stmt.setString(8, new String());
  			stmt.setString(9, new String());
  			stmt.setString(10, new String());
  			stmt.setString(11, new String());
  			stmt.setString(12, new String());
  			stmt.setString(13, new String());
  			stmt.setString(14, new String());
  			

  			stmt.registerOutParameter(1, Types.CHAR);
  			stmt.registerOutParameter(2, Types.CHAR);
  			stmt.registerOutParameter(3, Types.CHAR);
  			stmt.registerOutParameter(4, Types.CHAR);
  			stmt.registerOutParameter(5, Types.CHAR);
  			stmt.registerOutParameter(6, Types.CHAR);
  			stmt.registerOutParameter(7, Types.CHAR);
  			stmt.registerOutParameter(8, Types.CHAR);
  			stmt.registerOutParameter(9, Types.CHAR);
  			stmt.registerOutParameter(10, Types.CHAR);
  			stmt.registerOutParameter(11, Types.CHAR);
  			stmt.registerOutParameter(12, Types.CHAR);
  			stmt.registerOutParameter(13, Types.CHAR);
  			stmt.registerOutParameter(14, Types.CHAR);

  			// Execute Store PROC
  			stmt.executeUpdate();

  			// Iterate through the rows in the result set and output the columns
  			// from AS400 for each row.
  			
  			System.out.println("getPayeeAddressInfo() Parameters");
  			System.out.println("AP_PAYEE Parameter[2]:"+ stmt.getString(2));
  			System.out.println("AP_TYPE Parameter[3]:"+ stmt.getString(3));
  			System.out.println("AP_NAME Parameter[4]:"+ stmt.getString(4));
  			System.out.println("AP_ADDR_1 Parameter[5]:"+ stmt.getString(5));
  			System.out.println("AP_ADDR_2 Parameter[6]:"+ stmt.getString(6));
  			System.out.println("AP_CITY Parameter[7]:"+ stmt.getString(7));
  			System.out.println("AP_STATE Parameter[8]:"+ stmt.getString(8));
  			System.out.println("AP_ZIP Parameter[9]:"+ stmt.getString(9));
  			System.out.println("AP_ZIP_4 Parameter[10]:"+ stmt.getString(10));
  			System.out.println("AP_PHONE Parameter[11]:"+ stmt.getString(11));
  			System.out.println("AP_FAX Parameter[12]:"+ stmt.getString(12));
  			System.out.println("AP_MP_FLAG Parameter[13]:"+ stmt.getString(13));
  			System.out.println("AP_MSG Parameter[14]:"+ stmt.getString(14));
  			
  			//Remove Library List
  			setLibraryList(libraryList,as400_conn,false);
  		} 
  		catch (Exception e) 
  		{
  			System.out.println("Error getPayeeAddressInfo: "
  					+ e.toString());

  		}
  	}
    
    public static String getPayeeList(Connection as400_conn, String accountNumber, String agentFlag, String state, String covType, String PolicyNo,
    		String AS400LibPath, ArrayList<String> libraryList) 
  	{
  		CallableStatement stmt = null;
  		CallableStatement setPathStmt = null;
  		String payeeID = "";
  		
  		System.out.println("Inside getPayeeInfo()");
  		
  		try 
  		{
  			setPathStmt = as400_conn.prepareCall(AS400LibPath);
  			setPathStmt.executeUpdate();
  			
  			//Setting the library list
  			setLibraryList(libraryList,as400_conn,true);
  			

  			stmt = as400_conn.prepareCall("call SQS181(?,?,?,?,?)",
  					ResultSet.TYPE_SCROLL_INSENSITIVE,
  					ResultSet.CONCUR_READ_ONLY);
 
  			//Input Master Payee - 4365, Client Payee 6758 
  			stmt.setString(1, accountNumber);
  			stmt.setString(2, agentFlag); //Agent Type [A and C]
  			stmt.setString(3, state); // State 
  			stmt.setString(4, covType); // coverage type 
  			stmt.setString(5, PolicyNo); // Policy 
 
  			// Execute Store PROC
  			ResultSet rs = stmt.executeQuery();
  			
  		// Iterate through the rows in the result set and output the columns from AS400 for each row.
	
  			while(rs.next())
  			{
  				System.out.println("######### Parameters START ##########");
  				System.out.println("Payee ID:"+ rs.getString(1)); //Master Payee ID//Client ID //6
  				payeeID = rs.getString(1);
  				System.out.println("Payee NAME:"+rs.getString(2)); // 50 char
  				System.out.println("Payee ADDR1:"+rs.getString(3));//30
  				System.out.println("Payee ADDR2:"+rs.getString(4));//30
  				System.out.println("Payee CITY:"+rs.getString(5));//25
  				System.out.println("Payee STATE:"+rs.getString(6));//2
  				System.out.println("Payee ZIP:"+rs.getString(7)); //numeric 
  				System.out.println("######### Parameters END ##########");
  				
  			}

  			//Remove Library List
  			setLibraryList(libraryList,as400_conn,false);
  		} 
  		catch (Exception e) 
  		{
  			e.getStackTrace();
  			System.out.println("Error getPayeeInfo: "
  					+ e.toString());
  		}
  		
  		return payeeID;
  	}

    
    public static void getMortgageCoverageTypes(Connection as400_conn, String accountNumber, String LoanNo, String LoanSuffix, String covType,
    		String AS400LibPath, ArrayList<String> libraryList) 
  	{
  		CallableStatement stmt = null;
  		CallableStatement setPathStmt = null;
  		
  		System.out.println("Inside getMortgageCoverageTypes()");
  		
  		try 
  		{
  			setPathStmt = as400_conn.prepareCall(AS400LibPath);
  			setPathStmt.executeUpdate();
  			
  			//Setting the library list
  			setLibraryList(libraryList,as400_conn,true);
  			

  			stmt = as400_conn.prepareCall("call SQS001(?,?,?,?,?,?,?)",
  					ResultSet.TYPE_SCROLL_INSENSITIVE,
  					ResultSet.CONCUR_READ_ONLY);
  			
  			//Input
  			stmt.setString(1, accountNumber);
  			stmt.setString(2, LoanNo);
  			stmt.setString(3, LoanSuffix);
  			stmt.setString(4, covType);
  			
  			//Output
  			stmt.setString(5, new String());
  			stmt.setString(6, new String());
  			stmt.setString(7, new String());

 
  			stmt.registerOutParameter(1, Types.CHAR);
  			stmt.registerOutParameter(2, Types.CHAR);
  			stmt.registerOutParameter(3, Types.CHAR);
  			stmt.registerOutParameter(4, Types.CHAR);
  			stmt.registerOutParameter(5, Types.CHAR);
  			stmt.registerOutParameter(6, Types.CHAR);
  			stmt.registerOutParameter(7, Types.CHAR);
  			
  			// Execute Store PROC
  			stmt.executeUpdate();

  			// Iterate through the rows in the result set and output the columns
  			// from AS400 for each row.
  			
  			System.out.println("getMortgageCoverageTypes() Parameters");
  			System.out.println("CA_COVERAGES Parameter[5]:"+ stmt.getString(5));
  			System.out.println("CA_RC Parameter[6]:"+ stmt.getString(6));
  			System.out.println("CA_MSG Parameter[7]:"+ stmt.getString(7));


  			//Remove Library List
  			setLibraryList(libraryList,as400_conn,false);
  		} 
  		catch (Exception e) 
  		{
  			System.out.println("Error getMortgageCoverageTypes(): "
  					+ e.toString());

  		}
  	}

}
