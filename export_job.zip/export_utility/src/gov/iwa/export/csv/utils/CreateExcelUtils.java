package gov.iwa.export.csv.utils;

import gov.iwa.fema.export.bean.FemaObjectBean;
import gov.iwa.fema.export.dctm.utils.DctmUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;




public class CreateExcelUtils {
	private static Logger logger = Logger.getLogger(DctmUtils.class);


	@SuppressWarnings("resource")
  public static void generateWorkbook(String path, List < FemaObjectBean > fobList) throws Exception {
    Workbook workBook = null;
    FileOutputStream fileOut = null;

    CellStyle cellStyle = null;
    CellStyle rowStyle = null;
    Font headerFont = null;
    try {
      workBook = new XSSFWorkbook();
      fileOut = new FileOutputStream(path + File.separator + "InconsistencyReport" + "_".concat(Long.toString(System.currentTimeMillis())) + ".xlsx");
      Sheet reportSheet = workBook.createSheet("Inconsistency Items");
      cellStyle = workBook.createCellStyle();
      cellStyle.setBorderBottom(CellStyle.BORDER_THIN);
      cellStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
      cellStyle.setBorderLeft(CellStyle.BORDER_THIN);
      cellStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
      cellStyle.setBorderRight(CellStyle.BORDER_THIN);
      cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
      cellStyle.setBorderTop(CellStyle.BORDER_THIN);
      cellStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
      rowStyle = workBook.createCellStyle();
      rowStyle.setBorderBottom(CellStyle.BORDER_THIN);
      rowStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
      rowStyle.setBorderLeft(CellStyle.BORDER_THIN);
      rowStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
      rowStyle.setBorderRight(CellStyle.BORDER_THIN);
      rowStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
      rowStyle.setBorderTop(CellStyle.BORDER_THIN);
      rowStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
      headerFont = workBook.createFont();
      headerFont.setFontHeightInPoints((short) 11);
      headerFont.setBoldweight(Font.BOLDWEIGHT_BOLD);

      rowStyle.setFont(headerFont);

      generateSheet(reportSheet, cellStyle, rowStyle, fobList);
      workBook.write(fileOut);
      fileOut.close();
    } catch(Exception e) {
      logger.error("Error while executing", e);
      e.printStackTrace();
      throw e;
    }
  }

  /**
* Method to generate sheet
*
* @param reportSheet
* @param style
* @param headerStyle
* @param jobInfoBean
* @throws Exception
*/
  private static void generateSheet(Sheet reportSheet, CellStyle style, CellStyle headerStyle, List < FemaObjectBean > fobList) throws Exception {
    Row row = null;
    Cell cell = null;
    int rowCount = 0;
    try {
      row = reportSheet.createRow(rowCount);
      cell = row.createCell(0);
      cell.setCellValue("Object Id");
      cell.setCellStyle(headerStyle);

      cell = row.createCell(1);
      cell.setCellValue("Invoice No");
      cell.setCellStyle(headerStyle);

      cell = row.createCell(2);
      cell.setCellValue("Vendor Name");
      cell.setCellStyle(headerStyle);

      cell = row.createCell(3);
      cell.setCellValue("Department");
      cell.setCellStyle(headerStyle);

      cell = row.createCell(4);
      cell.setCellValue("Po No");
      cell.setCellStyle(headerStyle);

      // Header
      rowCount++;

      for (FemaObjectBean fobBean: fobList) {

        row = reportSheet.createRow(rowCount);

        cell = row.createCell(0);
        cell.setCellValue(fobBean.getR_object_id());
        cell.setCellStyle(style);

        cell = row.createCell(1);
        cell.setCellValue(fobBean.getInvoice_no());
        cell.setCellStyle(style);

        cell = row.createCell(2);
        cell.setCellValue(fobBean.getVendor_name());
        cell.setCellStyle(style);

        cell = row.createCell(6);
        cell.setCellValue(fobBean.getDepartment());
        cell.setCellStyle(style);

        cell = row.createCell(8);
        cell.setCellValue(fobBean.getPo_no());
        cell.setCellStyle(style);

        rowCount++;

      }

    } catch(Exception e) {
      logger.error("Error while generating the report {}", e);
      throw e;
    }

  }
}