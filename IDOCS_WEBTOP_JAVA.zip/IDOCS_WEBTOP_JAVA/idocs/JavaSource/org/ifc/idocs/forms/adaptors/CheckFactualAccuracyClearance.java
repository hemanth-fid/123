package org.ifc.idocs.forms.adaptors;

import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.xforms.engine.adaptor.validator.IStringValidator;
import com.documentum.xforms.engine.adaptor.validator.ItemValidator;

public class CheckFactualAccuracyClearance extends ItemValidator implements IStringValidator  {
	public boolean validateString(String value)throws AdaptorException	{
		boolean retFlag = true;
		if (!value.equalsIgnoreCase("yes"))
			retFlag = false;
		return retFlag;
	}

	@Override
	public void destroy() throws AdaptorException {
		// TODO Auto-generated method stub

	}

	@Override
	public void init(IAdaptorConfiguration arg0) throws AdaptorException {
		// TODO Auto-generated method stub

	}



}