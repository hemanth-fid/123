/**
 * 
 */
package gov.dcra.filenet.ingest.inter;


/**
 * @author Administrator
 *
 */

public interface  IProjectDoxIngestProcessor {

	public void processIngest();

}
