package com.SWBC.configuration;

import java.beans.PropertyVetoException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;

import com.SWBC.model.Brm_rule_lookup_log;
import com.SWBC.utilities.BRMUtilities;
import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfTypedObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfLoginInfo;
//import com.documentum.com.DfClientX;
//import com.documentum.fc.client.DfClient;
//import com.documentum.fc.client.IDfClient;
//import com.documentum.fc.client.IDfSession;
//import com.documentum.fc.client.IDfSessionManager;
//import com.documentum.fc.common.DfException;
//import com.documentum.fc.common.DfLoginInfo;
//import com.documentum.fc.common.IDfLoginInfo;
import com.mchange.v2.c3p0.ComboPooledDataSource;

@Configuration
@ComponentScan(basePackages = "com.SWBC")
@PropertySource(value = { "classpath:application.properties" })
public class ApplicationConfig {

	@Autowired
	public Environment env;


	@Bean
	public DataSource dataSource_AS400() {
		ComboPooledDataSource dataSource_AS400 = new ComboPooledDataSource();
		try {
			dataSource_AS400.setDriverClass(env.getRequiredProperty("AS400_DRIVER_CLASS"));
		} catch (PropertyVetoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} // loads the jdbc driver
		dataSource_AS400.setJdbcUrl(env.getRequiredProperty("AS400_SERVER_URL_MTG"));
		dataSource_AS400.setUser(env.getRequiredProperty("AS400_USERID"));
		dataSource_AS400.setPassword(env.getRequiredProperty("AS400_PASSWORD"));

	
//		dataSource_AS400.setMinPoolSize(500);
//		dataSource_AS400.setMaxPoolSize(1000);
//		dataSource_AS400.setAcquireIncrement(5);

		return dataSource_AS400;

	}

	@Bean
	Connection AS400Conn() {
		Connection conn = null;

		
		try {
			Class.forName(env.getRequiredProperty("AS400_DRIVER_CLASS"));

			conn = DriverManager.getConnection(env.getRequiredProperty("AS400_SERVER_URL_MTG"),
					env.getRequiredProperty("AS400_USERID"), env.getRequiredProperty("AS400_PASSWORD"));

		} catch (ClassNotFoundException e) {

		} catch (SQLException e) {

		}

		return conn;

	}

	@Bean
	public DataSource dataSource() {
		// DriverManagerDataSource dataSource = new DriverManagerDataSource();
		ComboPooledDataSource dataSource = new ComboPooledDataSource();
		try {
			dataSource.setDriverClass(env.getRequiredProperty("jdbc.driverClassName"));
		} catch (PropertyVetoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // loads the jdbc driver
		dataSource.setJdbcUrl(env.getRequiredProperty("jdbc.url"));
		dataSource.setUser(env.getRequiredProperty("jdbc.username"));
		dataSource.setPassword(env.getRequiredProperty("jdbc.password"));
		System.out.println("INSIDE:" + env.getRequiredProperty("jdbc.username"));

//		dataSource.setMinPoolSize(500);
//		dataSource.setAcquireIncrement(5);
//		dataSource.setMaxPoolSize(1000);

		/*
		 * dataSource.setDriverClassName(env.getRequiredProperty("jdbc.driverClassName")
		 * ); dataSource.setUrl(env.getRequiredProperty("jdbc.url"));
		 * dataSource.setUsername(env.getRequiredProperty("jdbc.username"));
		 * dataSource.setPassword(env.getRequiredProperty("jdbc.password"));
		 */
		return dataSource;
	}

	@Bean
	public DataSource dataSource_iir() {

		ComboPooledDataSource dataSource_iir = new ComboPooledDataSource();
		try {
			dataSource_iir.setDriverClass(env.getRequiredProperty("jdbc.driverClassName"));
		} catch (PropertyVetoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // loads the jdbc driver
		dataSource_iir.setJdbcUrl(env.getRequiredProperty("jdbc.url_iir"));
		dataSource_iir.setUser(env.getRequiredProperty("jdbc.username_iir"));
		dataSource_iir.setPassword(env.getRequiredProperty("jdbc.password_iir"));

	
//		dataSource_iir.setMinPoolSize(500);
//		dataSource_iir.setMaxPoolSize(1000);
//		dataSource_iir.setAcquireIncrement(5);

		return dataSource_iir;
	}

	@Bean
	public DataSource dataSource_FMI006() {
		ComboPooledDataSource dataSource_FMI006 = new ComboPooledDataSource();
		try {
			dataSource_FMI006.setDriverClass(env.getRequiredProperty("jdbc.driverClassName"));
		} catch (PropertyVetoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dataSource_FMI006.setJdbcUrl(env.getRequiredProperty("jdbc.url_FMI006"));
		dataSource_FMI006.setUser(env.getRequiredProperty("jdbc.username_FMI006"));
		dataSource_FMI006.setPassword(env.getRequiredProperty("jdbc.password_FMI006"));

//		dataSource_FMI006.setMinPoolSize(500);
//		dataSource_FMI006.setAcquireIncrement(5);
//		dataSource_FMI006.setMaxPoolSize(1000);

		return dataSource_FMI006;
	}
	


	@Bean
	public JdbcTemplate jdbcTemplate(DataSource dataSource) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate.setResultsMapCaseInsensitive(true);

		return jdbcTemplate;
	}

	@Bean
	public JdbcTemplate jdbcTemplate_iir(DataSource dataSource_iir) {
		JdbcTemplate jdbcTemplate_iir = new JdbcTemplate(dataSource_iir);
		jdbcTemplate_iir.setResultsMapCaseInsensitive(true);
		return jdbcTemplate_iir;
	}

	@Bean
	public JdbcTemplate jdbcTemplate_FMI006(DataSource dataSource_FMI006) {
		JdbcTemplate jdbcTemplate_FMI006 = new JdbcTemplate(dataSource_FMI006);
		jdbcTemplate_FMI006.setResultsMapCaseInsensitive(true);
		return jdbcTemplate_FMI006;
	}

	@Bean
	public JdbcTemplate jdbcTemplate_AS400(DataSource dataSource_AS400) {
		JdbcTemplate jdbcTemplate_AS400 = new JdbcTemplate(dataSource_AS400);
		jdbcTemplate_AS400.setResultsMapCaseInsensitive(true);
		return jdbcTemplate_AS400;
	}

	@Bean
	public ArrayList<String> mortlibraryList() {

		ArrayList<String> myList = new ArrayList<String>(
				Arrays.asList(env.getRequiredProperty("AS400_MORT_LIB_LIST").split(",")));

		return myList;

	}
	
	@Bean
	public ArrayList<String> getLoanLineTrecAttr() {

		ArrayList<String> myList = new ArrayList<String>(
				Arrays.asList(env.getRequiredProperty("loan_line_attr").split(",")));

		return myList;

	}
	
	@Bean
	public ArrayList<String> getAllTransTypes()
	{
		ArrayList<String> myList = new ArrayList<String>(
				Arrays.asList(env.getRequiredProperty("select.transaction.types").split(",")));

		return myList;
	}


	@Bean
	public KieContainer kieContainer() {
		return KieServices.Factory.get().getKieClasspathContainer();
	}
	

    private IDfClientX configureConnectionBroker(String hostName, int portNumber)
            throws DfException {
      System.out.println("Inside configureConnectionBroker()...");

      System.out.println("Host Name : '" + hostName + "'");
      System.out.println("Port Name : '" + portNumber + "'");

      IDfClientX clientx = new DfClientX();
      IDfClient client;
      try {
            client = clientx.getLocalClient();
            IDfTypedObject config = client.getClientConfig();
            config.setString("primary_host", hostName);
            config.setInt("primary_port", portNumber);

      } catch (DfException dfe) {
            throw new DfException(
                        "DfException in configureConnectionBroker() :: "
                                    + dfe.getLocalizedMessage());
      }

      return clientx;
}

private IDfSessionManager createSessionMgr(String username,
            String password, String docbasename, IDfClientX clientx)
            throws DfException {

      System.out.println("Inside createSessionMgr()...");

      IDfSessionManager sMgr = null;
      try {
            IDfClient client = clientx.getLocalClient();
            sMgr = client.newSessionManager();
            IDfLoginInfo login = new DfLoginInfo();
            login.setUser(username);
            login.setPassword(password);
            login.setDomain(null);

            sMgr.setIdentity(docbasename, login);

      } catch (DfException dfe) {
            throw new DfException("DfException in createSessionMgr() :: "
                        + dfe.getLocalizedMessage());
      }

      return sMgr;
}


public IDfSession getDCTMSession() throws Exception {

  IDfSessionManager sessionManager = null;
  IDfSession session = null;
  
  sessionManager = createSessionMgr(env.getRequiredProperty("dctm.user"), env.getRequiredProperty("dctm.password"), env.getRequiredProperty("dctm.repo"),
              configureConnectionBroker(env.getRequiredProperty("dctm.host"), Integer.parseInt(env.getRequiredProperty("dctm.port"))));
  try {
        session = sessionManager.getSession("swbc_bpm");

        System.out.println("Session created for Docabase '" + "swbc_bpm"
                    + "'");
  } catch (Exception ex) {
        throw new Exception(
                    "Exception in DCTMSession(username, password, ) :: "
                                + ex.getLocalizedMessage());
  }
  return session;
}

  

	


}