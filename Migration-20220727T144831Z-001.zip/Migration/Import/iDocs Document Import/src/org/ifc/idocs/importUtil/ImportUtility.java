package org.ifc.idocs.importUtil;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;
import java.util.Vector;
import java.util.logging.Logger;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfLoginInfo;

public class ImportUtility {
	protected static final String propertiesFile = "/ImportDominoDoc.properties";
	protected  static Properties idocsProperties = new Properties();
	protected static IDfSessionManager sessionMgr = null;
	protected static IDfSession dfSession = null;
	private static String idocsId="";
	private static String idocsFolderCategory="";
	private static String stagingFolderPath="";
	protected static String sourceRoot = "";
	protected static String sourceFilePath = "";
	protected static String prevVerFolderPath = "";
	protected static String newVerFolderPath = "";
	protected static String category = "";
	protected static String categoryCode = "";
	protected static String projMainCategory = "";
	protected static String XMLPath="";
	protected static String docBaseObjectType ="";
	protected static IDfId newId = null;
	@SuppressWarnings("unchecked")
	protected  static HashMap attributeValueList[];
	@SuppressWarnings("unchecked")
	protected
	static HashMap mataData = new HashMap();
	@SuppressWarnings("unchecked")
	protected
	static HashMap attrData = new HashMap();
	protected static int documentCount = 0;
	@SuppressWarnings("unchecked")
	protected static Vector failedXMLList = new Vector();
	@SuppressWarnings("unchecked")
	protected static Vector importedXMLList = new Vector();
	protected static int failedDocumentCount = 0;
	protected static String strDocbase = "";
	protected static String strUserName = "";
	protected static String strPassword = "";
	protected static Logger dominoDocLogger = LogHelper.getLogger(ImportUtility.class);
	private static boolean sessionAvailable = false;
	
	public static void main(String[] args) throws IOException, DfException, ParserConfigurationException, SAXException, ParseException
	{
		int choice=0;
		//Loading the Properties File
		InputStream inputStream = ImportUtility.class.getResourceAsStream(propertiesFile);
		idocsProperties.load(inputStream);

		System.out.println("");
		System.out.println("*******************************************************************");
		System.out.println("*              iDocs - Documents Import Utilities                 *");
		System.out.println("*******************************************************************");
		System.out.println("");
		System.out.println("\t 1. Update Migration Database with extracted data. ");
		System.out.println("\t 2. Create Folders in iDocs Repository.");
		System.out.println("\t 3. Execute Import Utility ");
		System.out.println("\t 4. Execute Roll Back ");
		System.out.println("\t 5. Exit ");
		System.out.println("");
		System.out.println("*******************************************************************");
		System.out.print("Enter your Choice : ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String menuChoice = br.readLine();
		System.out.println("");
		if(!menuChoice.isEmpty()){
			try{
				choice = Integer.parseInt(menuChoice);
			}catch(NumberFormatException nfe){
				choice=0;
			}
		}
		if(((choice != 5)&&(choice != 0)) && (!sessionAvailable))
			initializeSession();
		switch(choice)
		{
			case 1 :System.out.println("Updating Migration Database with extracted data...");				
					UpdateMigrationDataBase.readStagingFolder();
					break;
			case 2 : System.out.println("Creating Folders in iDocs Repository...");
					CreateFolders.startExecution();
					break;
			case 3 : System.out.println("Executing Import Utility...");
					importUtility();
					break;
			case 4 : System.out.println("Executing Roll Back Fucntionality...");
					Rollback.startExecution();
					break;
			case 5 : System.out.println("Exit - Execution Ended.");
					System.exit(0);
					dfSession.disconnect();
			default: System.out.println("Invalid Entry Please provide your selection again...");
		}

		if(choice != 5)
		{			
			main(args);
		}
	}
	private static void initializeSession() throws DfException{
		//setting variables
		strDocbase=idocsProperties.getProperty("MSG_DOCBASE_NAME");
		strUserName=idocsProperties.getProperty("MSG_USER_NAME");
		strPassword=idocsProperties.getProperty("MSG_PASSWD");
		stagingFolderPath=idocsProperties.getProperty("STAGING_FOLDER_PATH");
		idocsId=idocsProperties.getProperty("MSG_IDOCS_ID");
		idocsFolderCategory=idocsProperties.getProperty("MSG_IDOCS_FOLDER_CATEGORY");

		// Getting the Session from Session Manager
		sessionMgr = getSessionMgr(strUserName, strPassword, strDocbase);
		dfSession = sessionMgr.getSession(strDocbase);
		sessionAvailable = true;		
	}
	
	@SuppressWarnings("unchecked")
	protected static void importUtility()
	{
		Date startDate;
		Date endDate;
//		System.out.println("ImportDominoDoc Execution Started.");
		startDate = new Date();

//		System.out.println("ImportDominoDoc :: main() : Start Time : "+startDate);
		dominoDocLogger.info("ImportDominoDoc Execution Started.");
		dominoDocLogger.info("ImportDominoDoc :: main() : Start Time : "+startDate);
		dominoDocLogger.info("ImportDominoDoc :: main() : Staging Folder Path : "+stagingFolderPath);
//		System.out.println("ImportDominoDoc :: main() : Staging Folder Path : "+stagingFolderPath);

		//read staging folders
		readStagingFolder();

		dominoDocLogger.info("\n");
		dominoDocLogger.info("******************************** Execution Summery ********************************");
		Enumeration vEnum = importedXMLList.elements();
		dominoDocLogger.info("ImportDominoDoc :: main() : Number of Imported Documents : "+importedXMLList.size());
//		System.out.println("ImportDominoDoc :: main() : Number of Imported Documents : "+importedXMLList.size());
		dominoDocLogger.info("ImportDominoDoc :: main() : List of Imported Document Names");
//		System.out.println("ImportDominoDoc :: main() : List of Imported Document Names");
		while(vEnum.hasMoreElements()){
			String newFile = vEnum.nextElement().toString();
			dominoDocLogger.info("ImportDominoDoc :: Imported File : "+newFile);
//			System.out.println("ImportDominoDoc :: Imported File : "+newFile);
		}

		dominoDocLogger.info("ImportDominoDoc :: main() : Number of Document Failed : "+failedDocumentCount);
//		System.out.println("ImportDominoDoc :: main() : Number of Document Failed : "+failedDocumentCount);
		dominoDocLogger.info("ImportDominoDoc :: main() : List of Failed documents");
//		System.out.println("ImportDominoDoc :: main() : List of Failed documents");
		vEnum = failedXMLList.elements();
		while(vEnum.hasMoreElements()){
			dominoDocLogger.info(vEnum.nextElement().toString());
//			System.out.println(vEnum.nextElement());
		}

		endDate = new Date();
		long timeDiff = (endDate.getTime() - startDate.getTime())/1000;
		int sec = (int) (timeDiff%60);
		timeDiff /=60;
		int min = (int) (timeDiff%60);
		timeDiff /=60;
		int hr = (int) (timeDiff%3600);		
		dominoDocLogger.info("ImportDominoDoc :: main() : End Time :  "+endDate);
		dominoDocLogger.info("ImportDominoDoc :: main() : Duration : "+hr+":"+min+":"+sec);
		dominoDocLogger.info("ImportDominoDoc Execution Finished.");
//		System.out.println("ImportDominoDoc Execution Successful.");
		failedDocumentCount = 0;
	}

	private static void readStagingFolder() {
		//read staging folder 
		try {
			IDfCollection collection=null;
			String query = idocsProperties.getProperty("QRY_IDOCS_IMPORT_UTILITY");
			IDfQuery queryObj=new DfQuery();
			queryObj.setDQL(query);
			collection = queryObj.execute(dfSession, IDfQuery.DF_EXEC_QUERY);
			int idocsIdCount = 0;
			while(collection.next()){
				idocsIdCount++;
				categoryCode = collection.getString(idocsId);
				category = collection.getString(idocsFolderCategory);
				dominoDocLogger.info("ImportDominoDoc :: readStagingFolder() : Folder Category : "+category);
				dominoDocLogger.info("ImportDominoDoc :: readStagingFolder() : Folder Category Id : "+categoryCode);
//				System.out.println("ImportDominoDoc :: readStagingFolder() : Folder Category Id : "+categoryCode);
				getMatadataXML();
				//Update the Migration report table.
		        IDfCollection countcollection;
		        StringBuilder updateQuery = null;
		        int count=0;
		        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a z");
		        updateQuery =  new StringBuilder(idocsProperties.getProperty("QRY_SELECT_MIGRATION_COUNT")).append(categoryCode).append("'");
		        queryObj=new DfQuery();
		        queryObj.setDQL(updateQuery.toString());
		        countcollection = queryObj.execute(dfSession, IDfQuery.DF_EXEC_QUERY);			
		        if(countcollection.next()){
		        	count = Integer.parseInt(countcollection.getString(idocsProperties.getProperty("MSG_EXTR_DOC_COUNT")));
		        	Date newDate = new Date();
		        	String importedDate = formatter.format(newDate);
//		     		System.out.println(">>>>>>>>>>>>>>>>>>> 3 Document Count  : "+documentCount);
		     		if(count == documentCount){
		        		updateQuery = new StringBuilder(idocsProperties.getProperty("QRY_UPDATE_MIGRATION_REPORT")).append(documentCount).append(idocsProperties.getProperty("QRY_UPDATE_MIGRATION_REPORT_DATE")).append("date('"+importedDate+"','mm/dd/yyyy hh:mi:ss am z')").append(idocsProperties.getProperty("QRY_UPDATE_MIGRATION_REPORT_REM")).append(categoryCode).append("'");
		        		queryObj.setDQL(updateQuery.toString());
		        		queryObj.execute(dfSession, IDfQuery.DF_EXEC_QUERY);
		        	}else{
		        		updateQuery = new StringBuilder(idocsProperties.getProperty("QRY_UPDATE_MIGRATION_REPORT")).append(documentCount).append(idocsProperties.getProperty("QRY_UPDATE_MIGRATION_REPORT_DATE")).append("date('"+importedDate+"','mm/dd/yyyy hh:mi:ss am z')").append(idocsProperties.getProperty("QRY_UPDATE_MIGRATION_REPORT_ELSE")).append(categoryCode).append("'");
		        		queryObj.setDQL(updateQuery.toString());
		        		queryObj.execute(dfSession, IDfQuery.DF_EXEC_QUERY);
		        	}
		        	if(countcollection!=null)
		        		countcollection.close();
		          }
		          failedDocumentCount+=count-documentCount;
		          documentCount=0;
			}
			if(collection!=null)
				collection.close();
			if(idocsIdCount == 0){
				dominoDocLogger.info("\n");
			//	System.out.println();
				dominoDocLogger.info("ImportDominoDoc :: readStagingFolder() : No Pending Documents to Import.");
			//	System.out.println("ImportDominoDoc :: readStagingFolder() : No Pending Documents to Import.");
			}

		} catch (DfException e) {
			dominoDocLogger.warning("DfException : "+e.getMessage());
//			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			dominoDocLogger.warning("ParserConfigurationException : "+e.getMessage());
//			e.printStackTrace();
		} catch (SAXException e) {
			dominoDocLogger.warning("SAXException : "+e.getMessage());
//			e.printStackTrace();
		} catch (IOException e) {
			dominoDocLogger.warning("IOException : "+e.getMessage());
//			e.printStackTrace();
		}
	}

	private static void getMatadataXML() throws ParserConfigurationException, SAXException, IOException, DfException 
	{
		sourceRoot = stagingFolderPath+"/"+category+"/"+categoryCode+ "/";
		File rootFolder = new File(sourceRoot);
		if(rootFolder.isDirectory())
		{
			File[] subFiles=rootFolder.listFiles();
			for(int l=0;l<subFiles.length;l++)
			{
				if(subFiles[l].getName().contains(idocsProperties.getProperty("MSG_METATADA_EXT")))
				{
					XMLPath=subFiles[l].toString();
//					dominoDocLogger.info("ImportDominoDoc :: getMatadataXML() : Meta data xml : "+XMLPath);
					//Update Migration report table for status value
					IDfQuery dfquery = new DfQuery();
					String query = idocsProperties.getProperty("QRY_UPDATE_MIGRATION_STATUS")+categoryCode+"'"; 
					dfquery.setDQL(query);
					dfquery.execute(dfSession, IDfQuery.DF_EXEC_QUERY );
					// read xml file
					ParseXMLData.ReadMatadataXML(XMLPath);
				}
			}
		}
	}

	private static IDfSessionManager getSessionMgr(String strUserName, String strPassword, String strDocbase) throws DfException
	{
		IDfClient client = DfClient.getLocalClient();
		IDfSessionManager sMgr = client.newSessionManager();
		IDfLoginInfo login = new DfLoginInfo();
		login.setUser( strUserName );
		login.setPassword( strPassword );
		login.setDomain( null );
		sMgr.setIdentity( strDocbase, login );
		return sMgr;
	}
}
