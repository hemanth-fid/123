package org.ifc.idocs.control.celllist;


import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import com.documentum.web.form.control.databound.CellList;
import com.documentum.web.form.control.databound.DataProvider;
import com.documentum.web.form.control.databound.FindEnclosingDataProvider;

public class IDocsCellList extends CellList{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private class FieldDescriptor implements Serializable
    {
 		
    /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

	public void setType(String strType)
    {
        type = strType;
        isNumber = strType.equals("int") || strType.equals("double");
    }

    public String name;
    public String type;
    public boolean isNumber;
    public IDocsCellList this$0;

    public FieldDescriptor(String strName, String strType)
    {
    	super();
    	this$0 = IDocsCellList.this;
        name = strName;
        type = strType;
        isNumber = strType.equals("int") || strType.equals("double");
    }
}


public IDocsCellList()
{
    m_fieldsToOutput = null;
    m_fields = null;
    m_labels = null;
    m_aliases = null;
    m_fieldList = new LinkedList();
    m_labelsMap = new HashMap(17, 1.0F);
    m_dataProvider = null;
    m_cloneFieldList = null;
    m_hasCustomAttr = null;
}

public String[] getFields()
{
    String fields[] = null;
    if(m_fields != null)
        fields = (String[])(String[])m_fields.clone();
    return fields;
}

public void setFields(String strFields)
{
    StringTokenizer tokenizer = new StringTokenizer(strFields, ", ");
    m_fields = new String[tokenizer.countTokens()];
    int iFieldCount = 0;
    while(tokenizer.hasMoreTokens()) 
        m_fields[iFieldCount++] = tokenizer.nextToken();
    buildFieldsList();
    if(m_labels != null)
        buildLabelsMap();
}

public void setFields(String fields[])
{
    if(fields == null || fields.length == 0)
        throw new IllegalArgumentException("IDocsCellList: fields argument must be valid!");
    m_fields = new String[fields.length];
    System.arraycopy(fields, 0, m_fields, 0, fields.length);
    buildFieldsList();
    if(m_labels != null)
        buildLabelsMap();
}

public void init()
{
    if(m_cloneFieldList != null)
    {
        m_fieldList = new LinkedList();
        for(int i = 0; i < m_cloneFieldList.size(); i++)
            m_fieldList.add(m_cloneFieldList.get(i));

    }
}

public String[] getLabels()
{
    String labels[] = null;
    if(m_labels != null)
        labels = (String[])(String[])m_labels.clone();
    return labels;
}

public void setLabels(String strLabels)
{
    StringTokenizer tokenizer = new StringTokenizer(strLabels, ", ");
    m_labels = new String[tokenizer.countTokens()];
    int iFieldCount = 0;
    while(tokenizer.hasMoreTokens()) 
        m_labels[iFieldCount++] = tokenizer.nextToken();
    if(m_fields != null)
        buildLabelsMap();
}

public void setLabels(String labels[])
{
    if(labels == null || labels.length == 0)
        throw new IllegalArgumentException("IDocsCellList: labels argument must be valid!");
    m_labels = new String[labels.length];
    System.arraycopy(labels, 0, m_labels, 0, labels.length);
    if(m_fields != null)
        buildLabelsMap();
}

public void setNlsids(String strNlsids)
{
    StringTokenizer tokenizer = new StringTokenizer(strNlsids, ", ");
    m_labels = new String[tokenizer.countTokens()];
    int iFieldCount = 0;
    while(tokenizer.hasMoreTokens()) 
        m_labels[iFieldCount++] = getForm().getString(tokenizer.nextToken());
    if(m_fields != null)
        buildLabelsMap();
}

public void setNlsids(String nlsids[])
{
    if(nlsids == null || nlsids.length == 0)
        throw new IllegalArgumentException("IDocsCellList: nlsids argument must be valid!");
    m_labels = new String[nlsids.length];
    for(int iLabelCount = 0; iLabelCount < nlsids.length; iLabelCount++)
        m_labels[iLabelCount] = getForm().getString(nlsids[iLabelCount]);

    if(m_fields != null)
        buildLabelsMap();
}

public void setAliases(String aliases[])
{
    if(aliases == null || aliases.length == 0)
    {
        throw new IllegalArgumentException("IDocsCellList: aliases argument must be valid!");
    } else
    {
        m_aliases = new String[aliases.length];
        System.arraycopy(aliases, 0, m_aliases, 0, aliases.length);
        return;
    }
}

public void setHasCustomAttributes(Boolean bHasCustomAttr)
{
    m_hasCustomAttr = bHasCustomAttr;
}

public Boolean hasCustomAttr()
{
    return m_hasCustomAttr;
}

void addCellTemplateOutput(String strField, String strOutput)
{
    getCellTemplateOutputMap().put(strField, strOutput);
}

public Map getCellTemplateOutputMap()
{
    if(m_fieldsToOutput == null)
        m_fieldsToOutput = new HashMap(17, 1.0F);
    return m_fieldsToOutput;
}

public String getNextFieldForName(String strName)
{
    String strField = null;
    int iListSize = m_fieldList.size();
    int iFieldCount = 0;
    do
    {
        if(iFieldCount >= iListSize)
            break;
        FieldDescriptor descriptor = (FieldDescriptor)m_fieldList.get(iFieldCount);
        if(descriptor.name.equals(strName))
        {
            strField = strName;
            m_fieldList.remove(iFieldCount);
            break;
        }
        iFieldCount++;
    } while(true);
    return strField;
}

public String getNextFieldForType(String strType)
{
    String strField = null;
    int iListSize = m_fieldList.size();
    int iFieldCount = 0;
    do
    {
        if(iFieldCount >= iListSize)
            break;
        FieldDescriptor descriptor = (FieldDescriptor)m_fieldList.get(iFieldCount);
        updateCustomAttrDataType(descriptor, iFieldCount);
        if(descriptor.type.equals(strType) || descriptor.isNumber && strType.equals("number"))
        {
            strField = descriptor.name;
            m_fieldList.remove(iFieldCount);
            break;
        }
        iFieldCount++;
    } while(true);
    return strField;
}

public String getNextField()
{
    String strField = null;
    if(m_fieldList.size() != 0)
    {
        FieldDescriptor descriptor = (FieldDescriptor)m_fieldList.get(0);
        updateCustomAttrDataType(descriptor, 0);
        strField = descriptor.name;
        m_fieldList.remove(0);
    }
    return strField;
}

public String lookupLabelForField(String strField)
{
    String strLabel = null;
    if(m_labelsMap != null)
        strLabel = (String)m_labelsMap.get(strField);
    return strLabel;
}

protected String[] getTypes()
{
    return TYPES;
}

private void buildFieldsList()
{
    FindEnclosingDataProvider visitor = new FindEnclosingDataProvider();
    visitContainer(visitor);
    m_dataProvider = visitor.getDataProvider();
    if(m_dataProvider == null)
        throw new IllegalStateException("IDocsCellList: No valid enclosing dataprovider found!");
    int iFieldsSize = m_fields.length;
    m_fieldList.clear();
    for(int iFieldCount = 0; iFieldCount < iFieldsSize; iFieldCount++)
    {
        String strField = m_fields[iFieldCount];
        if(strField == null)
            continue;
        int iType;
        if(m_aliases != null)
        {
            String strAlias = m_aliases[iFieldCount];
            if(strAlias != null)
                iType = m_dataProvider.getColumnType(strAlias);
            else
                iType = m_dataProvider.getColumnType(strField);
        } else
        {
            iType = m_dataProvider.getColumnType(strField);
        }
        FieldDescriptor descriptor = new FieldDescriptor(strField, getTypes()[iType]);
        m_fieldList.add(descriptor);
    }

    m_cloneFieldList = new LinkedList();
    for(int i = 0; i < m_fieldList.size(); i++)
        m_cloneFieldList.add(m_fieldList.get(i));

}

public void buildLabelsMap()
{
    for(int iFieldCount = 0; iFieldCount < m_fields.length && iFieldCount < m_labels.length; iFieldCount++)
        m_labelsMap.put(m_fields[iFieldCount], m_labels[iFieldCount]);

}

public void updateCustomAttrDataType(FieldDescriptor descriptor, int iFieldCount)
{
    if(descriptor.type.equals("undefined"))
    {
        int iType;
        if(m_aliases != null)
        {
            String strAlias = m_aliases[iFieldCount];
            if(strAlias != null)
                iType = m_dataProvider.getColumnType(strAlias);
            else
                iType = m_dataProvider.getColumnType(descriptor.name);
        } else
        {
            iType = m_dataProvider.getColumnType(descriptor.name);
        }
        descriptor.setType(getTypes()[iType]);
    }
}

public void clearCellTemplateOutputMap()
{
    m_fieldsToOutput = null;
}

private static final String TYPE_BOOLEAN = "boolean";
private static final String TYPE_INT = "int";
private static final String TYPE_STRING = "string";
private static final String TYPE_ID = "id";
private static final String TYPE_DATE = "date";
private static final String TYPE_DOUBLE = "double";
private static final String TYPE_NUMBER = "number";
private static final String DM_UNDEFINED = "undefined";
private static final String TYPES[] = {
    "boolean", "int", "string", "id", "date", "double", "undefined"
};
private Map m_fieldsToOutput;
private String m_fields[];
private String m_labels[];
private String m_aliases[];
private List m_fieldList;
private Map m_labelsMap;
private DataProvider m_dataProvider;
private List m_cloneFieldList;
private Boolean m_hasCustomAttr;

	
}
