/**
 * 
 */
package gov.iwa.fema.export.dctm.utils;

/**
 * @author hemanth.muppalanara
 *
 */
public class IUtilConstants {

	
	//job params
	public static final String JOB_PARAM_FILE_SHARE_LOCATION = "file_share_location";
	
	public static final String MSG_ERROR_FILE_DOES_NOT_EXIST_AFTER_EXPORT = "Error: File doesn't exist even after export operation returns true. File could not get exported properly.";
	
	public static final String SINGLE_SPACE = " ";
	public static final String DOT = ".";
	public static final String SINGLE_QUOTE = "'";
	public static final String HYPHEN = "-";
	public static final String NEWLINE = System.getProperty("line.separator");
	public static final String FILESEPARATOR = System.getProperty("file.separator");
	public static final String EMPTYSTRING = "";
	public static final String PIPE = "\\|";
	public static final String DOUBLE_SINGLE_QUOTE="''";
	
	public static final String DATEFORMAT="yyyy-MM-dd";
	
	
	
	
}
