/**
* Class to control the behavior of the user Inbox attributes. This class 
* populates the data provider for inbox list datagrid. Shows access 
* denied in case of tasks where current user is not having privileges on
* the attached document. 
* 
* #############################################################################
* Sl.No 	Author			DateofChange	Version		ModificationHistory
* #############################################################################
* 1.		Sleeba Kurian	26/11/2012		1.0			Created 
* #############################################################################
*/
package org.ifc.idocs.navigation.inbox;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfTypedObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfList;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfList;
import com.documentum.nls.NlsResourceClass;
import com.documentum.services.workflow.inbox.IInbox;
import com.documentum.services.workqueue.IUserQueue;
import com.documentum.web.common.LocaleService;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.control.databound.ICustomAttributeRecordSet;
import com.documentum.web.formext.role.RoleService;
import com.documentum.web.util.DfcUtils;
import com.documentum.webcomponent.library.workflow.EventNamesLookup;
import com.documentum.webcomponent.library.workflow.WorkflowUtil;
import com.documentum.webcomponent.navigation.inbox.InboxAttributeDataHandler;

public class IFCDocsInboxAttributeDataHandler extends InboxAttributeDataHandler {

	private static final String EMPTY_STRING = "";
	private static final String ALL = "(ALL)";
	private static final String QUOTES_BRACKET = "')";
	private static final String IN = " IN ('";
	private static final String ACCESS_DENIED = "Access Denied";
	private static final String COMMA_SPACE = ", ";
	private static final String DM_QUEUED = "dm_queued";
	private static final String DM_ROUTER_TASK = "dm_router_task";
	private static final String DM_NOTIFICATION = "dm_notification";
	private static final String DM_TASK = "dm_task";
	private static final String STR_COMMA_SINGLEQUOTE = ",'";
	private static final String STR_SINGLEQUOTES = "'";
	private static final String IFCDOCS_CUSTOMATTRIBUTES = "r_object_id,object_name,r_object_type,country_nme,country_code";
	private static final String R_COMPONENT_ID = "r_component_id";
	private static final String R_COMPONENT_CHRON_ID= "r_component_chron_id";
	private static final String R_PACKAGE_TYPE = "r_package_type";
	private static final String AND_ANY_R_COMPONENT_ID_AND_R_ACT_SEQNO = "' AND r_package_type IN ('idocs_project_doc','idocs_institution_doc','idocs_country_doc','idocs_document') AND ANY r_component_id != ' ' AND r_act_seqno=";
	private static final String SELECT_R_COMPONENT_ID_FROM_DMI_PACKAGE_WHERE_R_WORKFLOW_ID = "SELECT DISTINCT r_component_chron_id,r_package_type FROM dmi_package where r_workflow_id = '";
	private static final String R_OBJECT_TYPE = "r_object_type";
	private static final String R_OBJECT_ID = "r_object_id";
	private static final String I_CHRONICLE_ID = "i_chronicle_id";
	private static final String MSG_GENERIC_NOTIFICATION = "MSG_GENERIC_NOTIFICATION";
	private static final String MSG_GENERIC_TASK = "MSG_GENERIC_TASK";
	private static final String UNDERSCORE = "_";
	private static final String REGEX = "##";
	private static final String ENABLE_RETURN_TOP_1 = "' ENABLE(RETURN_TOP 1)";
	private static final String STRING_EQUALTO_QUOTES = " = '";
	private static final String WHERE = " where ";
	private static final String FROM = " from ";
	private static final String SELECT = "select ";
	private static final String IDOCS_COUNTRY_FOLDER = "idocs_country_folder";
	private static final String INSTITUTION_NBR = "institution_nbr";
	private static final String IDOCS_INSTITUTION_FOLDER = "idocs_institution_folder";
	private static final String INSTIT_SHORT_NME = "instit_short_nme";
	private static final String IDOCS_PROJECT_FOLDER = "idocs_project_folder";
	private static final String COUNTRY_CODE = "country_code";
	private static final String COUNTRY_NME = "country_nme";
	private static final String OBJECT_TYPE = "object_type";
	private static final String PROJECT_SHORT_NME = "project_short_nme";
	private static final String PROJECT_ID = "project_id";
	private static final String OBJECT_NAME = "object_name";

	public IFCDocsInboxAttributeDataHandler(){
		
	}

	public String[] getRequiredAttributes(){
		return (String[])REQUIRED_ATTRS.clone();
	}
	
	public void getData(IDfSession dfSession, ICustomAttributeRecordSet recordSet){
	    DfLogger.debug(this,"IFCDocsInboxAttributeDataHandler : getData() >>"+Calendar.getInstance().getTimeInMillis(),null,null);
    	String objectIds[] = recordSet.getAttributeValues(ATTR_OBJECT_ID);
	    int count = objectIds.length;
	    String customAttrArray[] = recordSet.getCustomAttributeNames();
	    List customAttrs = new ArrayList();
	    for(int i = 0; i < customAttrArray.length; i++)
	        customAttrs.add(customAttrArray[i]);
	    String attrArray[] = recordSet.getAttributeNames();
	    List attrs = new ArrayList();
	    for(int i = 0; i < attrArray.length; i++)
	    	attrs.add(attrArray[i]);
	        try{
	            for(int i = 0; i < count; i++){
	                int rowIndex = recordSet.getRow(R_OBJECT_ID, objectIds[i]);
	                if(rowIndex >= 0){
	                    String task_state = recordSet.getAttributeValue(rowIndex, ATTR_TASK_STATE);
	                    String event = recordSet.getAttributeValue(rowIndex, ATTR_EVENT);
	                    String content_type = recordSet.getAttributeValue(rowIndex, ATTR_CONTENT_TYPE);
	                    String item_type = recordSet.getAttributeValue(rowIndex, ATTR_ITEM_TYPE);
	                    String router_id = recordSet.getAttributeValue(rowIndex, ATTR_ROUTER_ID);
	                    String item_name = recordSet.getAttributeValue(rowIndex, ATTR_ITEM_NAME);
	                    String task_subject = attrs.contains(ATTR_ITEM_NAME) ? recordSet.getAttributeValue(rowIndex, ATTR_TASK_SUBJECT) : null;
	                    String task_name = recordSet.getAttributeValue(rowIndex, ATTR_TASK_NAME);
	                    String task_number = recordSet.getAttributeValue(rowIndex, ATTR_TASK_NUMBER);
	                    String dependency_type = recordSet.getAttributeValue(rowIndex, ATTR_DEPENDENCY_TYPE);
	                    if(customAttrs.contains(ATTR_TASKNAME)){
	                        String name = getTaskName(router_id, task_state, content_type, item_type, event, item_name, task_subject, task_name, dependency_type);
	                        recordSet.setCustomAttributeValue(rowIndex, ATTR_TASKNAME, name);
	                    }
	                    if(customAttrs.contains(ATTR_DOCNAMES)){
	                        int taskNum = -1;
	                        try{
	                            if(task_number != null && task_number.length() > 0)
	                                taskNum = Integer.parseInt(task_number);
	                        }catch(NumberFormatException e){
	                            taskNum = -1;
	                        }
	                        if(taskNum >= 0){
	                            String docNames = getDocumentNames(dfSession, router_id, taskNum);
	                            recordSet.setCustomAttributeValue(rowIndex, ATTR_DOCNAMES, docNames);	                           
	                        }
	                    }
	                    if(customAttrs.contains(ATTR_CONTENTTYPE)){
	                        String value = getContentType(router_id, task_state, content_type, item_type, dependency_type);
	                        recordSet.setCustomAttributeValue(rowIndex, ATTR_CONTENTTYPE, value);
	                    }
	                    if(customAttrs.contains(ATTR_ITEMTYPE)){
	                        String taskType = getTaskType(content_type, item_type, dependency_type);
	                        recordSet.setCustomAttributeValue(rowIndex, ATTR_ITEMTYPE, taskType);
	                    }
	                    String objectName=null;
	                    HashMap<String,String> objectNameMap = new HashMap<String,String>();  
	                    if(customAttrs.contains(OBJECT_NAME)){
	                        int taskNum = -1;
	                        try{
	                            if(task_number != null && task_number.length() > 0)
	                                taskNum = Integer.parseInt(task_number);
	                        }catch(NumberFormatException e){
	                            taskNum = -1;
	                        }
	                        if(taskNum >= 0){
	                        	objectNameMap = getDocumentNamesMap(dfSession, router_id, taskNum);	                           
	                        }
	                    }else{
	                    	objectName=null;
	                    }
	                    String projectId =ACCESS_DENIED;
                    	String packageObjectName =ACCESS_DENIED;
                    	String objectType = ACCESS_DENIED;
                    	String projectShortName = ACCESS_DENIED;
                    	String countryName = ACCESS_DENIED;
                    	String countryCode = ACCESS_DENIED;
	                    HashMap<String,String> ifcdocsTaskMap = parseDocumentNameStringForInbox(objectNameMap,objectName,dfSession);
	                    if(ifcdocsTaskMap !=null){
	                    	if(objectNameMap.containsKey(PROJECT_ID))projectId = objectNameMap.get(PROJECT_ID);
	                    	if(objectNameMap.containsKey(PROJECT_SHORT_NME))projectShortName = objectNameMap.get(PROJECT_SHORT_NME);
	                    	if(objectNameMap.containsKey(OBJECT_NAME))packageObjectName = objectNameMap.get(OBJECT_NAME);
	    					if(objectNameMap.containsKey(R_OBJECT_TYPE))objectType = objectNameMap.get(R_OBJECT_TYPE);
	    					if(objectNameMap.containsKey(COUNTRY_NME))countryName = objectNameMap.get(COUNTRY_NME);
	    					if(objectNameMap.containsKey(COUNTRY_CODE))countryCode = objectNameMap.get(COUNTRY_CODE);		                    	
	                    }else{
	                    	DfLogger.debug(this,"IFCDocsInboxAttributeDataHandler : getData() : Task Details Not Found : WorkflowID="+router_id,null,null);
	                    }
	                    if(customAttrs.contains(PROJECT_ID)){
	                    	recordSet.setCustomAttributeValue(rowIndex, PROJECT_ID, projectId);
	                    }
	                    if(customAttrs.contains(PROJECT_SHORT_NME)){
	                    	recordSet.setCustomAttributeValue(rowIndex, PROJECT_SHORT_NME, projectShortName);
	                    }
	                    if(customAttrs.contains(OBJECT_NAME)){
	                    	recordSet.setCustomAttributeValue(rowIndex, OBJECT_NAME, packageObjectName);
	                    }
	                    if(customAttrs.contains(OBJECT_TYPE)){
	                    	recordSet.setCustomAttributeValue(rowIndex, OBJECT_TYPE, objectType);
	                    }
	                    if(customAttrs.contains(COUNTRY_NME)){
	                    	recordSet.setCustomAttributeValue(rowIndex, COUNTRY_NME, countryName);
	                    }
	                    if(customAttrs.contains(COUNTRY_CODE)){
	                    	recordSet.setCustomAttributeValue(rowIndex, COUNTRY_CODE, countryCode);
	                    }
	                }	                	              
	            }
	        }catch(DfException e){
	            throw new WrapperRuntimeException(e);
	        }
	        DfLogger.debug(this,"IFCDocsInboxAttributeDataHandler : getData() <<"+Calendar.getInstance().getTimeInMillis(),null,null);
	    }

	    private String getProjectShortName(String projectId, String objectType,String objectId, IDfSession session) {
	    	String projectShortName = null;
	    	String key = new StringBuilder(projectId).append(UNDERSCORE).append(objectType).toString();
	    	if(projectId !=null && projectId.trim().length() > 0 && projectShortNamemap!=null 
	    			&& projectShortNamemap.size() >0 && projectShortNamemap.containsKey(key)){
	    		projectShortName = projectShortNamemap.get(key);
	    	}
	    	if(projectShortName!=null && projectShortName.trim().length() > 0){
	    		return projectShortName;    			
    		}else{
		    	String queryAttribute = null;
		    	String queryTable = null;
		    	String whereClause = null;
		    	if(objectType != null && objectType.trim().length() > 0){
		    		if(IdocsConstants.PROJ_DOC_TYPE.equals(objectType)){
		    			queryAttribute = PROJECT_SHORT_NME;
		    			queryTable = IDOCS_PROJECT_FOLDER;//objectType;// "dm_dbo.IDOCS_PROJECT";
		    			whereClause = PROJECT_ID;
		    		}else if(IdocsConstants.INSTITUTION_DOC_TYPE.equals(objectType)){
		    			queryAttribute = INSTIT_SHORT_NME;
		    			queryTable = objectType;//IDOCS_INSTITUTION_FOLDER;// "dm_dbo.IDOCS_INSTITUTION";
		    			whereClause = I_CHRONICLE_ID ;// INSTITUTION_NBR;
		    		}else if(IdocsConstants.COUNTRY_DOC_TYPE.equals(objectType)){
		    			queryAttribute = COUNTRY_NME;
		    			queryTable = objectType;//IDOCS_COUNTRY_FOLDER;//"dm_dbo.IDOCS_COUNRY";
		    			whereClause = I_CHRONICLE_ID ;// COUNTRY_CODE;
		    		}
		    	}
		    	
		    	if(queryAttribute != null && queryTable !=null && whereClause != null
		    			&& queryAttribute.trim().length() > 0 && queryTable.trim().length() > 0 && whereClause.trim().length() > 0){
		    		String strQuery = SELECT+queryAttribute + FROM + queryTable + WHERE + whereClause + IN +objectId +QUOTES_BRACKET;
		    		try{
		    			IDfCollection taskDetailsCollection = IdocsUtil.executeQuery(session, strQuery, IDfQuery.DF_CACHE_QUERY);
		    			while( taskDetailsCollection!=null && taskDetailsCollection .next()){
		    				projectShortName = taskDetailsCollection.getString(queryAttribute);
		    			}
		    			if(taskDetailsCollection != null){
		    				taskDetailsCollection.close();
		    				taskDetailsCollection = null;
		    			}
		    		}catch (Exception e) {
		    			e.printStackTrace();
					}	    		
		    	}
		    	projectShortNamemap.put(key, projectShortName);
	    	}
	    	return projectShortName;
		}

		public HashMap<String, String> parseDocumentNameStringForInbox(HashMap<String, String> objectNameMap, String docNames,IDfSession session) {
			String objectName = null;
			String objectType = null;
			String objectId = null;
			String projectShortName= null;
			if(objectNameMap != null){
				if(objectNameMap.containsKey(OBJECT_NAME))objectName = objectNameMap.get(OBJECT_NAME);
				if(objectNameMap.containsKey(R_OBJECT_ID))objectId = objectNameMap.get(R_OBJECT_ID);
				if(objectNameMap.containsKey(R_OBJECT_TYPE))objectType = objectNameMap.get(R_OBJECT_TYPE);
				if(objectName !=null && objectName.trim().length()>0){
					String projectIdArray[]= objectName.split(UNDERSCORE);
					String projectId= null;
					if(projectIdArray !=null && projectIdArray.length>1){
						projectId =projectIdArray[0];
						objectNameMap.put(PROJECT_ID,projectId);
					}
					/** Calculate the project Short Name */
					if(objectNameMap.containsKey(PROJECT_SHORT_NME)){
						projectShortName = objectNameMap.get(PROJECT_SHORT_NME);
						if(projectShortName != null && projectShortName.trim().length()>0){
						}else{
							if(projectId != null && objectId !=null && objectType != null){
								projectShortName=getProjectShortName(projectId,objectType,objectId,session);
								objectNameMap.put(PROJECT_SHORT_NME,projectShortName);
							}
						}
					}
				}
			}
			return objectNameMap;
		}

		public boolean isApplicable(Map columnMap)
	    {
	        String strRequiredAttrs[] = getRequiredAttributes();
	        for(int j = 0; strRequiredAttrs != null && j < strRequiredAttrs.length; j++)
	            if(!columnMap.containsKey(strRequiredAttrs[j]))
	                return false;

	        return true;
	    }

	    /**
	     * @deprecated Method getTaskName is deprecated
	     */

	    protected String getTaskName(String routerId, String taskState, String contentType, String itemType, String event, String itemName, String taskSubject, 
	            String taskName)
	        throws DfException
	    {
	        int type = getTaskTypeIntValue(routerId, taskState, contentType, itemType);
	        return getTaskNameHelper(type, event, itemName, routerId, taskSubject, taskName);
	    }

	    protected String getTaskName(String routerId, String taskState, String contentType, String itemType, String event, String itemName, String taskSubject, 
	            String taskName, String dependencyType)
	        throws DfException
	    {
	        int type = getTaskTypeIntValue(contentType, itemType, dependencyType);
	        return getTaskNameHelper(type, event, itemName, routerId, taskSubject, taskName);
	    }

	    private String getTaskNameHelper(int taskType, String event, String itemName, String routerId, String taskSubject, String taskName)
	        throws DfException
	    {
	        String attrStr;
	        if(taskType == 1 || taskType == 2)
	        {
	            if(event != null && event.length() > 0)
	                attrStr = getEventName(event);
	            else
	            if(itemName != null && itemName.length() > 0)
	                attrStr = itemName;
	            else
	                attrStr = getNlsResourceClass().getString(MSG_GENERIC_NOTIFICATION, LocaleService.getLocale());
	        } else
	        {
	            IInbox inbox = getInboxService();
	            attrStr = inbox.getTaskName(taskType, routerId, taskSubject, taskName, itemName, event);
	            if(attrStr == null || attrStr.length() == 0)
	                attrStr = getNlsResourceClass().getString(MSG_GENERIC_TASK, LocaleService.getLocale());
	        }
	        return attrStr;
	    }

	    protected String getEventName(String event)
	        throws DfException
	    {
	        String retStr = event;
	        int len = retStr.length();
	        if(len > 0)
	        {
	            String tmpStr = EventNamesLookup.getString(retStr, LocaleService.getLocale());
	            if(tmpStr != null && tmpStr.length() > 0)
	                retStr = tmpStr;
	        }
	        return retStr;
	    }

	    
	protected HashMap<String, String> getDocumentNamesMap(IDfSession session,
			String routerId, int seqNo) throws DfException {
		IDfList docList = initDocumentInfo(session, routerId, seqNo);
		if (docList == null)
			return new HashMap<String, String>();
		int docCount = docList.getCount();
		HashMap<String, String> rv = new HashMap<String, String>();
		if (docCount > 0) {
			IDfTypedObject typedObj = (IDfTypedObject) docList.get(0);
			rv.put(R_OBJECT_ID, typedObj.getString(R_OBJECT_ID));
			rv.put(OBJECT_NAME, typedObj.getString(OBJECT_NAME));
			rv.put(R_OBJECT_TYPE, typedObj.getString(R_OBJECT_TYPE));
			rv.put(COUNTRY_NME, typedObj.getString(COUNTRY_NME));
			rv.put(COUNTRY_CODE, typedObj.getString(COUNTRY_CODE));
			rv.put(PROJECT_SHORT_NME, typedObj.getString(PROJECT_SHORT_NME));
		}
		for (int docIndex = 1; docIndex < docCount; docIndex++) {
			IDfTypedObject typedObj = (IDfTypedObject) docList.get(docIndex);
			rv.put("separator", new StringBuffer().append(COMMA_SPACE).append(
					typedObj.getString(OBJECT_NAME)).toString());
		}
		return rv;
	}
	    
	    protected String getDocumentNames(IDfSession session, String routerId, int seqNo)
	        throws DfException{
	    	IDfList docList = initDocumentInfo(session, routerId, seqNo);
	        if(docList == null)
	            return EMPTY_STRING;
	        int docCount = docList.getCount();
	        StringBuffer rv = new StringBuffer();
	        if(docCount > 0)
	        {
	            IDfTypedObject typedObj = (IDfTypedObject)docList.get(0);
	            rv.append(typedObj.getString(R_OBJECT_ID));
	            rv.append(REGEX);
	            rv.append(typedObj.getString(OBJECT_NAME));
	            rv.append(REGEX);
	            rv.append(typedObj.getString(R_OBJECT_TYPE));
	            rv.append(REGEX);
	            rv.append(typedObj.getString(COUNTRY_NME));
	            rv.append(REGEX);
	            rv.append(typedObj.getString(COUNTRY_CODE));
	            rv.append(REGEX);
	            rv.append(typedObj.getString(PROJECT_SHORT_NME));	            
	        }
	        for(int docIndex = 1; docIndex < docCount; docIndex++)
	        {
	            IDfTypedObject typedObj = (IDfTypedObject)docList.get(docIndex);
	            rv.append(COMMA_SPACE).append(typedObj.getString(OBJECT_NAME));
	        }
	        return rv.toString();
	    }

//	    protected IDfList initDocumentInfo(IDfSession session, String routerId, int seqNo)
//	        throws DfException
//	    {
//	    	return super.initDocumentInfo(session, routerId, seqNo);
//	    }
	    
		protected IDfList initDocumentInfo(IDfSession session, String routerId,
				int seqNo) throws DfException {
			Vector componentIdVector;
			String packageType = null;
			IDfQuery query;
			IDfCollection coll;
			StringBuffer queryBuf = new StringBuffer(256);
			queryBuf
					.append(SELECT_R_COMPONENT_ID_FROM_DMI_PACKAGE_WHERE_R_WORKFLOW_ID);
			queryBuf.append(routerId);
			queryBuf.append(AND_ANY_R_COMPONENT_ID_AND_R_ACT_SEQNO);
			queryBuf.append(Integer.toString(seqNo));
			componentIdVector = new Vector();
			query = DfcUtils.getClientX().getQuery();
			query.setDQL(queryBuf.toString());
			coll = null;
			coll = query.execute(session, 0);
			do {
				if (!coll.next())
					break;
				IDfId componentId = coll.getId(R_COMPONENT_CHRON_ID);
				packageType = coll.getString(R_PACKAGE_TYPE);
				if (componentId != null && !componentId.isNull())
					componentIdVector.addElement(componentId.toString());
			} while (true);
			WorkflowUtil.closeCollection(coll);
			coll = null;
			return queryDocumentInfo(componentIdVector, packageType,IFCDOCS_CUSTOMATTRIBUTES);
		}
	    
		private IDfList queryDocumentInfo(Vector componentIdVector, String packageType, String attrs) {
					return queryDocumentInfoHelper(componentIdVector, packageType, attrs, s_queryDocInfo);
		}
		
		protected static IDfList queryDocumentInfoHelper(List ids, String packageType, String attrs,
				String queryPattern) {
			HashMap hash = new HashMap();
			int docCount = ids.size();
			for (int index = 0; index < docCount; index++) {
				String docIdStr = (String) ids.get(index);
				IDfId docId = new DfId(docIdStr);
				String docbaseScope = null;
				try {
					docbaseScope = WorkflowUtil.getDocbaseScope(docId);
				} catch (DfException e) {
					continue;
				}
				String idsStr = (String) hash.get(docbaseScope);
				if (idsStr == null)
					idsStr = (new StringBuilder()).append(STR_SINGLEQUOTES).append(docIdStr)
							.append(STR_SINGLEQUOTES).toString();
				else
					idsStr = (new StringBuilder()).append(idsStr).append(STR_COMMA_SINGLEQUOTE)
							.append(docIdStr).append(STR_SINGLEQUOTES).toString();
				hash.put(docbaseScope, idsStr);
			}
	
			IDfList rv = new DfList();
			if (hash.isEmpty())
				return rv;
			Object docbaseArray[] = hash.keySet().toArray();
			int docbaseCount = docbaseArray.length;
			for (int index = 0; index < docbaseCount; index++) {
				String docbaseScope = (String) docbaseArray[index];
				String docIdStr = (String) hash.get(docbaseScope);
				String formatArgs[] = { attrs, docIdStr };
				String queryStr = null;
				if(packageType !=null && packageType.trim().length()>0 && packageType.equals(IdocsConstants.PROJ_DOC_TYPE)){
					String projattrs= attrs+",project_short_nme";
					String projectformatArgs[] = { projattrs, docIdStr };
					queryStr = MessageFormat.format(queryPatternProjectDoc, projectformatArgs);
				}else{
					String projattrs= attrs+",'' as project_short_nme";
					String projectformatArgs[] = { projattrs, docIdStr };
					queryStr = MessageFormat.format(s_queryDocInfo, projectformatArgs);
				}
				IDfCollection coll = null;
				try {
					coll = WorkflowUtil.runQuery(docbaseScope, queryStr, 0);
				} catch (DfException e) {
					coll = null;
				}
				if (coll == null)
					continue;
				try {
					while(coll.next()){
						rv.append(coll.getTypedObject());
					}						
				} catch (DfException e) {
				}
				WorkflowUtil.closeCollection(coll);
				coll = null;
			}
			return rv;
		}

	    /**
	     * @deprecated Method getContentType is deprecated
	     */

	    protected String getContentType(String routerId, String taskState, String contentType, String itemType)
	        throws DfException
	    {
	        int type = getTaskTypeIntValue(routerId, taskState, contentType, itemType);
	        return getContentTypeHelper(type, contentType, itemType);
	    }

	    protected String getContentType(String routerId, String taskState, String contentType, String itemType, String dependencyType)
	        throws DfException
	    {
	        int type = getTaskTypeIntValue(contentType, itemType, dependencyType);
	        return getContentTypeHelper(type, contentType, itemType);
	    }

	    private String getContentTypeHelper(int taskType, String contentType, String itemType)
	    {
	        String rv;
	        if(taskType == 4)
	            rv = DM_TASK;
	        else
	        if(taskType == 1)
	            rv = DM_NOTIFICATION;
	        else
	        if(taskType == 2)
	        {
	            if(contentType == null || contentType.length() == 0)
	                rv = itemType;
	            else
	                rv = contentType;
	        } else
	        if(taskType == 8)
	            rv = DM_ROUTER_TASK;
	        else
	            throw new WrapperRuntimeException((new StringBuilder()).append("Unknown inbox item type :").append(taskType).toString());
	        return rv;
	    }

	    /**
	     * @deprecated Method getTaskType is deprecated
	     */

	    protected String getTaskType(String routerId, String taskState, String contentType, String itemType)
	        throws DfException
	    {
	        int type = getTaskTypeIntValue(routerId, taskState, contentType, itemType);
	        return getTaskTypeHelper(type);
	    }

	    protected String getTaskType(String contentType, String itemType, String dependencyType)
	        throws DfException
	    {
	        int type = getTaskTypeIntValue(contentType, itemType, dependencyType);
	        return getTaskTypeHelper(type);
	    }

	    private String getTaskTypeHelper(int taskType)
	    {
	        String rv;
	        switch(taskType)
	        {
	        case 4: // '\004'
	            rv = DM_TASK;
	            break;

	        case 1: // '\001'
	            rv = DM_NOTIFICATION;
	            break;

	        case 2: // '\002'
	            rv = DM_QUEUED;
	            break;

	        case 8: // '\b'
	            rv = DM_ROUTER_TASK;
	            break;

	        case 3: // '\003'
	        case 5: // '\005'
	        case 6: // '\006'
	        case 7: // '\007'
	        default:
	            throw new WrapperRuntimeException((new StringBuilder()).append("Unknown inbox item type :").append(taskType).toString());
	        }
	        return rv;
	    }

	    /**
	     * @deprecated Method getTaskTypeIntValue is deprecated
	     */

	    protected int getTaskTypeIntValue(String routerId, String taskState, String contentType, String itemType)
	        throws DfException
	    {
	        IInbox inbox = getInboxService();
	        return inbox.getTaskType(routerId, taskState, contentType, itemType);
	    }

	    protected int getTaskTypeIntValue(String contentType, String itemType, String dependencyType)
	        throws DfException
	    {
	        IInbox inbox = getInboxService();
	        return inbox.getTaskType(contentType, itemType, dependencyType);
	    }

	    protected IInbox getInboxServiceHelper()
	    {
	        return super.getInboxServiceHelper();
	    }

	    protected IUserQueue getUserQueueServiceHelper()
	    {
	        return super.getUserQueueServiceHelper();
	    }

	    protected IInbox getInboxService()
	    {
	        if(isWorkQueueProcessor())
	            return getUserQueueServiceHelper();
	        else
	            return getInboxServiceHelper();
	    }

	    public boolean isWorkQueueProcessor()
	    {
	        return RoleService.isUserAssignedRole(null, "queue_processor", null, null);
	    }

	    protected NlsResourceClass getNlsResourceClass()
	    {
	    	return super.getNlsResourceClass();
	    }

	    private static final String ATTR_TASKNAME = "taskName";
	    private static final String ATTR_DOCNAMES = "docNames";
	    private static final String ATTR_CONTENTTYPE = "contentType";
	    private static final String ATTR_ITEMTYPE = "itemType";
	    private static final String ATTR_OBJECT_ID = "r_object_id";
	    private static final String ATTR_TASK_STATE = "task_state";
	    private static final String ATTR_EVENT = "event";
	    private static final String ATTR_CONTENT_TYPE = "content_type";
	    private static final String ATTR_ITEM_TYPE = "item_type";
	    private static final String ATTR_ROUTER_ID = "router_id";
	    private static final String ATTR_ITEM_NAME = "item_name";
	    private static final String ATTR_TASK_SUBJECT = "task_subject";
	    private static final String ATTR_TASK_NAME = "task_name";
	    private static final String ATTR_TASK_NUMBER = "task_number";
	    private static final String ATTR_DEPENDENCY_TYPE = "dependency_type";
	    private final String REQUIRED_ATTRS[] = { ATTR_OBJECT_ID, ATTR_TASKNAME, ATTR_CONTENTTYPE, ATTR_ITEMTYPE, ATTR_TASK_STATE, ATTR_EVENT, ATTR_CONTENT_TYPE, ATTR_ITEM_TYPE, ATTR_ROUTER_ID, ATTR_ITEM_NAME, 
	    	ATTR_TASK_NAME, ATTR_TASK_NUMBER };
	    private static String s_queryDocInfo = "SELECT {0} FROM idocs_document WHERE i_chronicle_id IN ({1})";
	    private static String queryPatternProjectDoc = "SELECT {0} FROM idocs_project_doc WHERE i_chronicle_id IN ({1})";
	    private HashMap<String,String> projectShortNamemap = new HashMap<String,String>();
}