/**
* EmailSender custom class is used to send email to selected users in to, cc, bcc fields of discussionuserorgrouplocator jsp .
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created
* #######################################################################################################
*/
package org.ifc.idocs.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfLogger;

public class EmailSender {
	private static final String TEXT_HTML = "text/html";
	private static final String BODY = "body";
	private static final String CONTENT_TYPE = "contentType";
	private static final String SUBJECT = "subject";
	private static final String BCC = "BCC";
	private static final String CC = "CC";
	private static final String TO = "TO";
	private static final String MAIL_SERVER_NAME = "MAIL_SERVER_NAME";
	private static final String MAIL_SMTP_HOST = "mail.smtp.host";
	private static final String MAIL_SERVER_TYPE = "MAIL_SERVER_TYPE";
	public static String MAIL_SERVER ;
	private InternetAddress[] toAddress;
	private InternetAddress[] ccAddress;
	private InternetAddress[] bccAddress;
		
	// This method is implemented for testing purpose
	/*public static void main(String args[])
	{
		HashMap map = new HashMap();
		ArrayList lst = new ArrayList();
		//lst.add("BGupta@ifc.org");
		//lst.add("CVattathara@ifc.org");
		
		
		map.put("TO",lst);
		map.put("CC",lst);
		
		HashMap mp1 = new HashMap();
		mp1.put("subject", "Test Comment");
		mp1.put("body", "This is a test mail");
		mp1.put("contentType", "text/html");
	}*/
	
	/* Method setEmailAddress.
	 * @param lst_address	 *
	 */
	public InternetAddress[] getAddressArray(ArrayList lst_address) {
		InternetAddress[] addressArray = null;
		if(lst_address!=null){
			int count=lst_address.size();
			addressArray=new InternetAddress[count];			
			for(int i=0;i<count;i++){
				try{				
					addressArray[i]=new InternetAddress(lst_address.get(i).toString());
					DfLogger.info(this," :: getAddressArray : addressArray : "+addressArray[i],null,null); 
				}catch(AddressException ade){				
					DfLogger.error(this, " :: getAddressArray Exception >> "+ade.getMessage(), null, ade);
				}
			}
			DfLogger.info(this," :: getAddressArray : addressArray : "+lst_address.toString(),null,null); 
		}
		return addressArray;
	}
	
	
	
	public  void sendMail(HashMap emailMap,String strSender, Map recipientMap, IDfSession dfSession){
		boolean successmsg= false;
	    String strEmailSubject=null;
		String strEmailMessage=null;
	    String strEmailbody=null;
		String strContentType = null;
		String strMailServerType = null;
		String strMailServerName = null;
		try{
			Properties idocsProperties = new Properties();
	    	Properties props = System.getProperties();
	    	//props.put("mail.smtp.host", "lmail.worldbank.org");
	    	
	    	// To get mail server type
	    	String mailServerType = IdocsUtil.getIdocsConfigInfoValue(dfSession, MAIL_SERVER_TYPE);
	    	if (mailServerType!=null && mailServerType.trim().length()> 0) {
		     	strMailServerType = mailServerType;		    	 	
	     	} else {
	     		strMailServerType = MAIL_SMTP_HOST;
	     	}
	    	
	    	// To get mail server name
	    	String mailServerNameQry = IdocsUtil.getIdocsConfigInfoValue(dfSession, MAIL_SERVER_NAME);
	    	if (mailServerNameQry!=null && mailServerNameQry.trim().length()> 0) {
	    		strMailServerName = mailServerNameQry;	    	 	
	     	} else {
	     		strMailServerName = "lmail.worldbank.org";
	     	}
	    	props.put(strMailServerType, strMailServerName);
	     		
			// Get a Session object	    	 	
			Session session = Session.getInstance(props, null);				
			session.setDebug(true);
			Message msg = new MimeMessage(session);
				
			//Set from address in email
			msg.setFrom(new InternetAddress(strSender));
			DfLogger.info(this," :: sendMail : Email From : " +(msg.getFrom()).toString(),null,null); 

			// Set email date
			msg.setSentDate(new Date());
				
			/** Setting email address to to recipients**/
			//ArrayList lst_toEmailIds = null;				
			if(null!=recipientMap){
				if(recipientMap.containsKey(TO)){
					ArrayList lst_toEmailIds = (ArrayList)recipientMap.get(TO);					
					toAddress = getAddressArray(lst_toEmailIds);
					DfLogger.info(this," :: sendMail : toAddress : "+toAddress.length,null,null); 
					msg.setRecipients(Message.RecipientType.TO, toAddress);
				}
					
				if(recipientMap.containsKey(CC)){
					ArrayList lst_ccEmailIds = (ArrayList)recipientMap.get(CC);					
					ccAddress = getAddressArray(lst_ccEmailIds);
					DfLogger.info(this," :: sendMail : ccAddress : "+ccAddress.length,null,null);
					msg.setRecipients(Message.RecipientType.CC, ccAddress);
				}
				
				if(recipientMap.containsKey(BCC)){
					ArrayList lst_bccEmailIds = (ArrayList)recipientMap.get(BCC);					
					bccAddress = getAddressArray(lst_bccEmailIds);
					DfLogger.info(this," :: sendMail : bccAddress : "+bccAddress.length,null,null);
					msg.setRecipients(Message.RecipientType.BCC, bccAddress);
				}
			}
			
			//Set subject in email
			strEmailSubject= (String)emailMap.get(SUBJECT);								
			msg.setSubject(strEmailSubject); 		
			DfLogger.info(this," :: sendMail : strEmailSubject : " +strEmailSubject,null,null); 
			//Set email body				
		    strEmailbody=(String)emailMap.get(BODY);
		    strContentType = (String)emailMap.get(CONTENT_TYPE);
		    DfLogger.info(this," :: sendMail : strEmailbody : " +strEmailbody,null,null);
		    msg.setContent(strEmailbody,TEXT_HTML);
		    //Send mail........
			Transport.send(msg);
			DfLogger.info(this," :: sendMail : \nMail end...",null,null);
	     }catch(Exception e){
	    	DfLogger.error(this," :: sendMail Exception >>  "+e.getMessage(),null,e);
	    	successmsg=false;
	    }
	}
}
