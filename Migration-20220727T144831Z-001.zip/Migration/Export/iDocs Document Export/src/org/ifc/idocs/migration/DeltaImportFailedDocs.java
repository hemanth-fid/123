package org.ifc.idocs.migration;

import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;

import org.ifc.idocs.migration.common.AppConfig;
import org.ifc.idocs.migration.common.DomdocRepository;
import org.ifc.idocs.migration.common.DomdocRepositoryDescriptor;
import org.ifc.idocs.migration.extract.DBConnection;
import org.ifc.idocs.migration.extract.Discussion;
import org.ifc.idocs.migration.extract.DomdocDocument;
import org.ifc.idocs.migration.extract.DomdocFolder;
import org.ifc.idocs.migration.extract.LogHelper;
import org.ifc.idocs.migration.extract.NotesSession;
import org.ifc.idocs.migration.extract.TempDb;
import org.ifc.idocs.migration.transform.IFCNAB;
import org.ifc.idocs.migration.transform.WBNAB;

public class DeltaImportFailedDocs extends ExtractCommon{

	protected static String utilityId = "";
	private DomdocRepository domdoc = null;
	private DomdocRepositoryDescriptor repo = null;
	private AppConfig config = AppConfig.getInstance();
	private Logger exportDocLogger = LogHelper.getLogger(DeltaExtraction.class);
	private Integer notesExcep = 0, wflow_cnt = 0, cout_cnt = 0;
	private String folderQuery = null,documentQuery1 = null, region = null,deltaRegion=null,deltaUtilityID=null,deltaCriteriaCode=null;
	String replica_code=null,foldermanPath = null;
	private String display_path = null, documentQuery = null, cntry = null,DeltaImportDocId=null,Folder_name=null,docid=null;
	java.sql.Date replica_date=null;
	private int exportCount = 0, failureCount = 0;
	private boolean utilityIdFlag = false, foldermanFlag = false;	
	String[] foldermans = null;
	private static Database parentDatabse = null;

	public DeltaImportFailedDocs(){
		//	checking if extraction folder is present
		File theDir = new File(config.getString("export.path"));
		if (!theDir.exists()){
			//exportDocLogger.info("Export path not found!!!. Please update config.xml with a valid extraction path");
			NotesSession.terminate();//terminate the extraction
		}
		else{//if extraction folder is present , then only proceed with extraction
			try{
				//TODO- take failed id from table

				String deltaUtilityIDQuery = config.getString("filters.DeltaFailedImportID");	//retrieving query string from extraction_criteria table			
				String [] deltaUtilityIds = deltaUtilityIDQuery .split(";");
				String server = config.getString("repository.server");
				for(int k = 0; k < deltaUtilityIds.length; k++){
					exportDocLogger.info("iDocs Data Extraction-DELTA run for Import failed documents");
					deltaUtilityID = deltaUtilityIds[k];
					exportDocLogger.warning("Extraction id from config file= " + deltaUtilityID);
					criteriaCount = 0;
					foldermanFlag = true;
					foldermanPath=config.getString("repository.foldermanPath");
					foldermans = foldermanPath .split(";");

					for(int fman = 0; fman < foldermans.length; fman++){
						repo = new DomdocRepositoryDescriptor("","",server,foldermans[fman]);
						domdoc = new DomdocRepository(repo);
						if(utilityIdFlag && foldermanFlag){ // Multiple log files will be created when a new extraction criteria code exists
							ExportUtilityMain.getNewUtilityId();
							LogHelper.loggerMap.put("loggerMap",null);
						}
						utilityId = WorkflowAuditTrial.workflowMap.get("utilityId");
						exportDocLogger.warning("Extraction Utility ID for Delta is : " + utilityId);
						exportDocLogger.warning("Folderman db= "+foldermans[fman]);
						String[] deltaextInfo=DBConnection.getDeltaCriteriaCode(deltaUtilityID);
						if(deltaextInfo != null){
							deltaCriteriaCode = deltaextInfo[0];
						}
//						while (rs1.next())
//						{
//							deltaCriteriaCode=rs1.getString("EXTRACTION_CRITERIA_CODE");
//							//exportDocLogger.info("deltaUtility Criteria code="+deltaUtilityID);
//						}
						ResultSet rs3=DBConnection.getDeltaRegion(deltaCriteriaCode);
						while(rs3.next())
						{
							deltaRegion=rs3.getString("REGION_NME");
							folderQuery = rs3.getString("FOLDER_QUERY_TXT");
						}
						String[] extInfo = DBConnection.getExtractionInfo(deltaCriteriaCode);	//getting extraction query-string from database
						//getting docid's of failed docs from region table
						//ABOVE TABLE ALSO GETS THE SAME VALUE...CHECK IF THAT CAN BE REMOVED
						if(extInfo != null){
							folderQuery=extInfo[0];
							documentQuery1 = extInfo[1];
							region = extInfo[2];
							cntry = extInfo[3];
							replica_code = extInfo[5];
						}
						
						if (cntry.length() > 3){ // extracts the country name (IND / BRA) from folder query value if query contains more inputs (COUNTRY_NAME_CODE='BRA' & project_id = '9999')
							cntry = cntry.substring(0, 3);
						}
						String path = config.getString("export.path");
						path = path + "\\" + utilityId + "\\"; 	
						display_path = config.getString("export.path");
						display_path = display_path + "\\" + utilityId;
						//exportDocLogger.info("Display path = " + display_path);
						if(foldermanFlag){
							DBConnection.updateStartSummary(utilityId, deltaCriteriaCode, display_path);	//updating extraction utility info
						}else{
							DBConnection.updateEndSummary(utilityId,criteriaCount);
						}
						foldermanFlag = false;
						String[]  splits = folderQuery.split(" & ");
						String countryName = splits[0], projectId = null;
						ArrayList<String>  projectsIds = new ArrayList<String>();
						if(splits.length > 1){
							String[]  splits1 = splits[1].split("'");
							projectId = splits1[0];
							int j = 0;
							for(int i=1; i<splits1.length; i++){
								//checking doc query
								if(splits1.length>2){
									if (documentQuery1!=null){ 
										exportDocLogger.warning("MULTIPLE PROJECTS EXTRACTION SHOULD NOT HAVE DOCUMENT_QUERY ENTRIES ");
										exportDocLogger.warning("PLEASE REMOVE DOCUMENT_QUERY_TEXT FROM TABLE & TRY AGAIN");
										break;
									}}
								if(!splits1[i].contains(",")){
									projectsIds.add(splits1[i]);
									j++;
								}
							}
							for(String pid : projectsIds){
								folderQuery = countryName + " & " + projectId + "'" + pid + "'";
								DeltaImportextraction(folderQuery, path);
							}
						}else{
							folderQuery = countryName;
							DeltaImportextraction(folderQuery, path);
						}
						DBConnection.updateEndSummary(utilityId,exportCount);
						DBConnection.updateExtractionUtilityStart(utilityId);	//updating discussion extraction start status
						Discussion.extractDocuments(region,cntry,display_path,utilityId);	// Extract documents
//						TODO Aspose fix in delta import failed
//						AsposeUtilities au = new AsposeUtilities();
//						au.updateCustomProperties(utilityId);
						domdoc.recycle();
						}
				}
				}catch (RuntimeException ioe){	//loop to finish multiple project id extraction
					exportDocLogger.warning("Please ensure valid inputs are provided in config.xml");
					ioe.printStackTrace();
					exportDocLogger.log(Level.WARNING, "RuntimeException ~", ioe);
				}
				catch(NotesException e){
					exportDocLogger.warning("NotesError ~ " + e.id + " ~ " + e.text);
					e.printStackTrace();
					exportDocLogger.log(Level.WARNING, "NotesException~", e);
				}
				catch (Exception e){
					exportDocLogger.warning("Initialization error");
					e.printStackTrace();
					exportDocLogger.log(Level.WARNING, "Exception ~", e);
				}
				finally {
					if(foldermans.length == 1){
						try {
							//					DBConnection.updateEndSummary(utilityId,exportCount);
							//					DBConnection.updateExtractionUtilityStart(utilityId);	//updating discussion extraction start status
							//					Discussion.extractDocuments(region,cntry,display_path,utilityId);	// Extract documents
							DBConnection.updateExtractionUtilityEnd(utilityId);	//	updating discussion extraction end status
							exportDocLogger.warning("Extraction Utility ID is : " + utilityId);
							System.out.println("COMPLETED");
						} catch (IOException e) {
							exportDocLogger.warning("Error while updating extraction end in export_utility_info table");
							e.printStackTrace();
							exportDocLogger.log(Level.WARNING, " ~IOException~Finally Section~", e);
						}//updating extraction summary to table
						catch (Exception e) {
							e.printStackTrace();
							exportDocLogger.log(Level.WARNING, "~Exception~Finally Section~", e);
						}}
					//exportDocLogger.info("Completed");
					TempDb.recycle();
					IFCNAB.recycle();
					WBNAB.recycle();
					NotesSession.terminate();
					exportDocLogger.warning("Completed");
				}
		}//end of main loop
	}// ExtractDocument
	private void DeltaImportextraction(String folderQuery, String path) throws Exception {
		Document tempDoc = null;
		//exportDocLogger.info("inside DeltaImportextraction");
		DocumentCollection folders = domdoc.getFoldermanDb().findFolders(folderQuery);
		exportDocLogger.warning("Country Documents = " + folders.getCount());
		Document nfolder = folders.getFirstDocument();
		DomdocFolder folder = null;
		exportCount = 0;
		failureCount = 0;
		//exportDocLogger.info("Export started for :"+deltaUtilityID);
		ResultSet rs4=DBConnection.getImportFailedDocs(deltaRegion, deltaUtilityID);
		StringBuffer sb = new StringBuffer();
		while (rs4.next()){
			DeltaImportDocId=rs4.getString("LEGACY_DOCUMENT_ID");
			exportDocLogger.warning("LEGACY_DOCUMENT_ID="+DeltaImportDocId);
			sb.append(DeltaImportDocId);
			sb.append(",");
			documentQuery1 = sb.toString();
		}
		if(sb.length()==0){
			exportDocLogger.warning("No FAILED DOCUMENTS FOUND IN REGION TABLE");
			System.exit(0);
		}
		//exportDocLogger.info(documentQuery1);
		//		splitting of multiple documents
		ArrayList<String>  docIds = new ArrayList<String>();
		if(documentQuery1 != null){
			String []ids=documentQuery1.split(",");
			//			if (ids.length>1){
			int d=0;
			for( int p=0;p<ids.length;p++){
				docIds.add(ids[p]);
				d++;
			}
			//			}
		}
		documentQuery = "!(IsWIPVer='1')";	//ensuring that document is not checked out
		while (nfolder != null) {				
			try {
				folder = new DomdocFolder(domdoc, nfolder);
				String docExportPath = path + folder.getMetadata().getFileroomId();
				//exportDocLogger.info("more than 1 docid");
				for(String dids : docIds ){
					documentQuery = "!(IsWIPVer='1')";	//ensuring that document is not checked out
					documentQuery1 = "DocID = '"+dids+"'";
					if (documentQuery1  != null){
						documentQuery=documentQuery+" & "+documentQuery1;
						DeltaImportdocumentExtraction(folder, nfolder, docExportPath);
					}
				}
			} 		
			catch (Exception e) {	
				exportDocLogger.warning("Folder processing error");
				e.printStackTrace();
				exportDocLogger.log(Level.WARNING, "DeltaImportextraction~Exception~", e);
			}
			tempDoc = folders.getNextDocument();
			nfolder.recycle();
			nfolder= tempDoc;
		} 
		if (folder != null ){
			folder.recycle();
		}
		failureCount = failureCount + notesExcep ;//adding failures
		saveListToDatabse();
		utilityIdFlag = true;
		if (folders != null){
			folders.recycle();
		}
	}	
	private void saveListToDatabse() {
		if(regionList.size() > 0){
			DBConnection.updateRegion(regionList,region,DBConnection.getBatchConnection());
			regionList.clear();						
		}
		if(migrationSkippedDocumentList.size() > 0){
			DBConnection.saveSkippedDocuments(migrationSkippedDocumentList,DBConnection.getBatchConnection());
			migrationSkippedDocumentList.clear();
		}	
		System.gc();
	}

	private void DeltaImportdocumentExtraction(DomdocFolder folder, Document nfolder, String docExportPath) throws NotesException, IOException, ParseException {

		Document newNdoc = null,ndoc=null;
		DocumentCollection documents=null;
		try{
			documents = folder.findDocuments(documentQuery, null);
			int doc_cnt = documents.getCount();
			exportDocLogger.warning("Documents inside folder ~ " + nfolder.getItemValueString("title") + " = " + doc_cnt);
			ndoc = documents.getFirstDocument();
			parentDatabse = null;
		}
		catch(NotesException ne){
			exportDocLogger.warning(" Invalid Replica ID Found - "+nfolder.getItemValueString("documentdbid"));
			exportDocLogger.log(Level.WARNING,"documentExtraction Exception-", ne);
			listSkipDatabase(nfolder.getItemValueString("documentdbid"),nfolder.getItemValueString("filecabinet"),
					nfolder.getItemValueString("fileroom"),"Invalid Replica ID Found" ,"ER_019") ;
		}
		while (ndoc != null) {
			try{
				if(parentDatabse == null){
					parentDatabse = ndoc.getParentDatabase();
				}
			}catch(NotesException ne){
				exportDocLogger.log(Level.WARNING, "NotesException : Unable to open Parent Database database", ne);
			}

			try { 
				newNdoc = documents.getNextDocument(ndoc);	// for recycling ndoc, assigning the next ndoc to a variable
				boolean skipDocument = false;
				Document latest;					
				docid = ndoc.getItemValueString("docid");

				Folder_name=(ndoc.getItemValueString("FileRoom")).toUpperCase();//case is not uniform in documents.So converting all to upper case
				if (Folder_name.equals("MISCELLANEOUS")){Folder_name="COUNTRY";}
				if ((ndoc.getItemValueString("FileRoom")).toLowerCase().equals("projects")) folderValueCode=ndoc.getItemValueString("Project_id");
				if ((ndoc.getItemValueString("FileRoom")).toLowerCase().equals("institutions")) folderValueCode=ndoc.getItemValueString("Institution_Nbr");
				if ((ndoc.getItemValueString("FileRoom")).toLowerCase().equals("miscellaneous")) folderValueCode=ndoc.getItemValueString("Country_Name_Code");

				if (ndoc.getItemValueString("isCurrentVer").equals("1")) {
					latest = ndoc;
				} else {
					latest = parentDatabse.getView("IFCLatestDraftByDocID").getDocumentByKey(docid);
					if (latest == null) {
						latest = parentDatabse.getView("IFCLatestByDocID").getDocumentByKey(docid);
					}
				}
				if (latest == null) {
					listSkipDocuments(ndoc, docid, "Could not find latest document by docid.", "ER_018");
					continue;
				}
				if (latest.getItemValueString("WIPUNID").length()>0) {	
					skipDocument = true;
					cout_cnt++;
					exportDocLogger.warning("Document " + docid + " is checked out, skipping...");
					listSkipDocuments(ndoc, docid, "Checked Out", "ER_002");
				} else if (latest.getItemValueString("WorkflowStatus").matches("[124]")) {
					skipDocument = true;
					wflow_cnt++;
					exportDocLogger.warning("Document " + docid + " is in workflow, skipping...");	
					listSkipDocuments(ndoc, docid, "In Workflow", "ER_003");
				}

				if (!skipDocument) {
					new File(docExportPath).mkdirs();
					DomdocDocument doc = new DomdocDocument(ndoc);	//process current document
					doc.export(docExportPath);

					//updating the extraction of each entry into region table.
					addToRegionList(utilityId, ndoc,region, "Y");
					exportDocLogger.warning("DocID = " + ndoc.getItemValueString("DocID") + " ~ Title = " + nfolder.getItemValueString("TITLE")
							+ " ~ Type = " + ndoc.getItemValueString("FolderType") + " ~ FileCabinet = " + ndoc.getItemValueString("FileCabinet")
							+ " ~ exported successfully" + " ~ exportCount = " + exportCount);
					doc.recycle();
				}
				if(regionList.size()>=2000 || migrationSkippedDocumentList.size()>=2000){
					saveListToDatabse();
				}
			} 

			catch (NotesException e){
				addToRegionList(utilityId, ndoc,region, "N");
				exportDocLogger.log(Level.WARNING, "documentExtraction NotesException", e);
				exportDocLogger.info(ndoc.getItemValueString("DocID") + " ~ has error ~ " + e.id + " ~ " + e.text);
				notesExcep++;
				listSkipDocuments(ndoc, ndoc.getItemValueString("DocID"), "Doc Error - NotesException", "ER_001");
			} 
			catch (Exception e) {
				failureCount++;
				addToRegionList(utilityId, ndoc,region, "N");
				exportDocLogger.info(("Error exporting document " + ndoc.getUniversalID() + " from database " + parentDatabse.getTitle()+nfolder.getItemValueString("TITLE")));
				exportDocLogger.log(Level.WARNING,"documentExtraction Exception", e);
				e.printStackTrace();
				listSkipDocuments(ndoc, ndoc.getItemValueString("DocID"), "Doc Error - Exception", "ER_001");
			}
			ndoc.recycle();
			ndoc = newNdoc;
		}
		if (documents != null ){
			documents.recycle();}
	}
}
