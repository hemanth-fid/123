

package gov.dcra.filenet.delete;

import java.io.File;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.stream.Collectors;


import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.util.Id;

import gov.dcra.filenet.connection.DCRAFileNetConnection;
import gov.dcra.filenet.constants.Constants;
import gov.dcra.filenet.util.DCRAFileNetUtil;



/**
 * @author Administrator
 *
 */
public class DocumentDeleteExecute {

	/**
	 * @param args
	 */

	private final static Logger log = Logger.getLogger(DocumentDeleteExecute.class);
	private static String inputFileLoc = null;
	private static int successCtr=0;
	private static int failedCtr=0;

	private final String appPropsFile = Constants.APPLICATION_PROPS;
	private Properties appProps = new Properties();
	private static List<String> failedDeleteLst=null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		StringBuffer statsBuf=new StringBuffer();
		DocumentDeleteExecute exec = null;
		try {

			StringBuilder sb = new StringBuilder();
			sb.append("0. Exit").append(Constants.NEWLINE);
			sb.append("1. Process Document Export").append(Constants.NEWLINE);

			sb.append("Please input the number to proceed");

			String sampleOperation = read(sb.toString());
			int op = 0;
			try {
				op = Integer.parseInt(sampleOperation);
				if (op == 0) {
					System.out.println("Thanks, bye....!");
					System.exit(0);
				} else if (op == 1) {
					inputFileLoc = read("Please input the input file path : ");

					while (!isFilenameValid(inputFileLoc)) {
						inputFileLoc = read("Please input a valid file path : ");
					}
				} else {
					System.out.println("Unsupported " + op);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			exec = new DocumentDeleteExecute();
			exec.processDelete();
			statsBuf.append("------------------------------------------------------------------").append("\n");
			
			statsBuf.append("Delete Success : "+successCtr).append("\n");
			statsBuf.append("Delete Failed : "+failedCtr).append("\n");
			if(failedCtr>0){
				statsBuf.append("\n");
				statsBuf.append("Failed Records : ").append("\n");
				
				for(String failedDocId : failedDeleteLst){
					
					statsBuf.append("docID : ").append(StringUtils.substringBefore(failedDocId, "~")).
					append(" | Error : ").append(StringUtils.substringAfter(failedDocId, "~")).append("\n");
				}
				
			}
			statsBuf.append("------------------------------------------------------------------").append("\n");
			
			log.info(statsBuf);

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	private void processDelete() {

		DCRAFileNetConnection conn = null;
		DCRAFileNetUtil exportUtil = null;
		Domain domain = null;
		ObjectStore os = null;
		StringTokenizer docIds = null;
		String docId = null;	
		failedDeleteLst=new ArrayList<String>();
		try {

			log.debug("Start Processing......");
			appProps.load(DocumentDeleteExecute.class.getResourceAsStream(appPropsFile));
			
			//String filename = appProps.getProperty(Constants.MSG_EXPORT_DIR).concat(Constants.FILESEPARATOR).concat(appProps.getProperty(Constants.MSG_EXPORT_FILENAME));
			conn = new DCRAFileNetConnection();
			exportUtil = new DCRAFileNetUtil();
			domain = conn.getDomain();
			os = exportUtil.getObjectStore(domain,appProps.getProperty(Constants.MSG_OBJECTSTORE_NAME));
			

		if(os!=null){
			
			List<String> docIdList=exportUtil.readInputFile(inputFileLoc,appProps.getProperty(Constants.MSG_COLUMN_NAME));
			
			//List<String> docIdList=exportUtil.getObjectIds(os);
			
			if(docIdList!=null && docIdList.size()>0){
				docIds = new StringTokenizer(docIdList.stream().collect(Collectors.joining(",")), ",");

				while (docIds.hasMoreElements()) {

					 docId = docIds.nextToken();
					

					log.debug("Processing ID : "+docId);
					
					
					//Document_Date
					
			
					Document doc = Factory.Document.fetchInstance(os, new Id(docId),null);
					
					doc.delete();
					doc.save(RefreshMode.REFRESH);
					successCtr++;
					
					log.debug("Deleted  DocID : " + docId);
				}
				
			}
				else{
				
				log.error("Cannot Process,error extracting docIds from file : "+inputFileLoc);
			}
		}else{
			
			log.error("Cannot Process,error fetching objectStore : "+appProps.getProperty(Constants.MSG_OBJECTSTORE_NAME));
		}

		
			log.debug("End Processing......");
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			failedCtr++;
			log.error("Doc Delete failed : " + docId + " Error " + e.getMessage());
			failedDeleteLst.add(docId+"~"+e.getMessage());
			e.printStackTrace();
		}
	}

	public static boolean isFilenameValid(String fileName) {

		File f = new File(fileName);
		return f.isFile();
	}

	public static String read(String prompt) {
		String value = null;
		byte[] bytes = new byte[100];

		try {
			System.out.println(prompt);
			int readed;
			readed = System.in.read(bytes);
			while (readed <= 0) {
				System.out.println(prompt);
				readed = System.in.read(bytes);
			}
			value = new String(bytes, 0, readed).trim();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return value;
	}

}
