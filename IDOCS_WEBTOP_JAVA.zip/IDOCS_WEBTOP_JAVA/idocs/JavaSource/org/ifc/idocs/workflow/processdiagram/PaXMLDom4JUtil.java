/**
* This class read the component XML to check the Inbox functionality.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.workflow.processdiagram;

import com.documentum.fc.common.DfLogger;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Iterator;
import java.util.Map;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Templates;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamSource;
import org.dom4j.DocumentException;
import org.dom4j.Node;
import org.dom4j.io.DOMReader;
import org.dom4j.io.DocumentResult; 
import org.dom4j.io.DocumentSource;
import org.dom4j.io.SAXReader;

public class PaXMLDom4JUtil
{
	private static Templates cachedXSLT = null;

	public static org.dom4j.Document readDocumentFromXml(File paramFile)
	throws Exception
	{
		FileInputStream localFileInputStream;
		try
		{
			localFileInputStream = new FileInputStream(paramFile);
			BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(localFileInputStream, "UTF-8"));
			SAXReader localSAXReader = new SAXReader();
			org.dom4j.Document localDocument = localSAXReader.read(localBufferedReader);
			return localDocument;
		}
		catch (Exception localException)
		{
			localException.printStackTrace();
			DfLogger.error(PaXMLDom4JUtil.class," :: readDocumentFromXml Exception >> "+localException.getMessage(), null, localException);
		}
		return null;
	}

	public static Node findNode(org.dom4j.Document paramDocument, String paramString)
	throws DocumentException
	{
		Node localNode = paramDocument.selectSingleNode(paramString);
		return localNode;
	}
	public static org.dom4j.Document transformDOM2DOM(org.dom4j.Document paramDocument, String paramString, Map paramMap)
	throws Exception
	{
		Transformer localTransformer;

		try
		{
			localTransformer = null;
			if (cachedXSLT == null)
			{
				Object localObject1 = new StreamSource(new File(paramString));
				Object localObject2 = TransformerFactory.newInstance();
				cachedXSLT = ((TransformerFactory)localObject2).newTemplates((Source)localObject1);
				localTransformer = cachedXSLT.newTransformer();
			}
			else
			{
				localTransformer = cachedXSLT.newTransformer();
			}
			if (paramMap != null)
			{
				Object localObject1 = paramMap.entrySet().iterator();
				while (((Iterator)localObject1).hasNext())
				{
					Object  localObject2 = (Map.Entry)((Iterator)localObject1).next();
					localTransformer.setParameter((String)((Map.Entry)localObject2).getKey(), ((Map.Entry)localObject2).getValue());
				}
			}
			Object localObject1 = new DocumentSource(paramDocument);
			Object localObject2 = new DocumentResult();
			localTransformer.transform((Source)localObject1, (Result)localObject2);
			org.dom4j.Document localDocument = ((DocumentResult)localObject2).getDocument();
			//printDOM4JXML(localDocument);
			return localDocument;
		}
		catch (Exception localException)
		{
			localException.printStackTrace();
			DfLogger.error(PaXMLDom4JUtil.class," :: transformDOM2DOM Exception >> "+ localException.getMessage(), null, localException);
		}
		return ((org.dom4j.Document)(org.dom4j.Document)null);
	}

	public static void writeUTF8ToFile(File paramFile, String paramString)
	{
		FileOutputStream localFileOutputStream;
		try
		{
			localFileOutputStream = new FileOutputStream(paramFile);
			BufferedWriter localBufferedWriter = new BufferedWriter(new OutputStreamWriter(localFileOutputStream, "UTF-8"));
			localBufferedWriter.write(paramString);
			localBufferedWriter.close();
		}
		catch (IOException localIOException)
		{
			DfLogger.error(PaXMLDom4JUtil.class," :: writeUTF8ToFile Exception >> "+ localIOException.getMessage(), null, localIOException);
		}
	}

	public static org.dom4j.Document convertW3cDocumentToDom4jDocument(org.w3c.dom.Document paramDocument)
	{
		DOMReader localDOMReader = new DOMReader();
		return localDOMReader.read(paramDocument);
	}

	public static void printDOM4JXML(org.dom4j.Document localDocument1){
		try{
//			System.out.println(localDocument1.asXML());
		}catch (Exception e){
			e.printStackTrace();
		}
	}
}