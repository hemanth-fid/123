
package org.ifc.idocs.migration.extract;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Level;

import lotus.domino.Document;
import lotus.domino.NotesException;
import oracle.jdbc.OraclePreparedStatement;

import org.ifc.idocs.migration.ExtractDocuments;
import org.ifc.idocs.migration.WorkflowAuditTrial;
import org.ifc.idocs.migration.common.AppConfig;
import org.ifc.idocs.migration.common.AsposeError;
import org.ifc.idocs.migration.common.CountryProjectDoc;
import org.ifc.idocs.migration.common.DocumentDetailReportModel;
import org.ifc.idocs.migration.common.DocumentReportModel;
import org.ifc.idocs.migration.common.MigWfActAuditTrial;
import org.ifc.idocs.migration.common.MigWfAuditDetails;
import org.ifc.idocs.migration.common.MigWfAuditReport;
import org.ifc.idocs.migration.common.MigrationSkippedDocuments;
import org.ifc.idocs.migration.common.RegionModel;
import org.ifc.idocs.migration.common.SecurityExceptionReportModel;

/**
 * @author SPankajamsadanan
 * DBConnection class deails with all database connections
 * 
 */
public class DBConnection {

	public static ResultSet rs, rs1;
	public static Connection conn;

	private static AppConfig config = AppConfig.getInstance();
	private static Properties idocsProperties = new Properties();
	private static final String propertiesFile = "/Export.properties";

	private static final String driverName = config.getString("connection.driver");
	private static final String connectionName = config.getString("connection.connectionName");
	private static final String dbUserName = config.getString("connection.u_name");
	private static final String dbPassword = config.getString("connection.password");

	private static InputStream inputStream = ExtractDocuments.class.getResourceAsStream(propertiesFile);
	private static java.util.logging.Logger exportDocLogger = LogHelper.getLogger(ExtractDocuments.class);
	
	private static Set<String> uniqueDocIdSet = new HashSet<String>();	
	
	/**
	 * getConnection method create connection only when its null
	 * @return void
	 */
	public static void getConnection() { 
		try {
			if (conn == null){
				Class.forName(driverName);
				conn = DriverManager.getConnection(connectionName,dbUserName,dbPassword);
				idocsProperties.load(inputStream);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"getConnection-ClassNotFoundException", e);
		} catch (SQLException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"getConnection-SQLException", e);
		}catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * getConnection method create connection only when its null
	 * @return void
	 */
	public static Connection getBatchConnection() { 
		 Connection batchConn = null;
		//private ResultSet batchRs;
		
		try {
			if (batchConn == null){
				Class.forName(driverName);
				batchConn = DriverManager.getConnection(connectionName,dbUserName,dbPassword);				
				idocsProperties.load(inputStream);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"getConnection-ClassNotFoundException", e);
		} catch (SQLException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"getConnection-SQLException", e);
		}catch (IOException e) {
			e.printStackTrace();
		}
		return batchConn;
		
	}
	/**
	 * commonDbMethod method adding explicit commit statement to prevent database locks 
	 * @throws IOException
	 * @return void
	 */
	public static void commonDbMethod() throws IOException {
		try {
			//idocsProperties.load(inputStream);
			getConnection();
			final String cmt = idocsProperties.getProperty("AutoCommit");
			PreparedStatement stmt = conn.prepareStatement(cmt);
			stmt.executeQuery();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"commonDbMethod-SQLException", e);
		}
	}

	/**
	 * getExtractionInfo method read query string from extraction_criteria table, execute the query and return the result set
	 * @param extractionId
	 * @return ResultSet
	 * @throws IOException
	 */
	public static String[] getExtractionInfo(final String extractionId) throws IOException {
		String[] extInfo = new String[6];
		try {
			//idocsProperties.load(inputStream);
			getConnection();
			String query = idocsProperties.getProperty("Get_Extraction_Info");
			query = query + "'" + extractionId + "'";
			PreparedStatement stmt = conn.prepareStatement(query);
//			System.out.println(query);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()){
				String folderQuery = rs.getString("FOLDER_QUERY_TXT");
				extInfo[0] = folderQuery; 	// getting folder query value from extraction_criteria table.
				extInfo[1] = rs.getString("DOCUMENT_QUERY_TXT");	// getting document query value from extraction_criteria table.
				extInfo[2]=rs.getString("REGION_NME"); 	// getting region value from extraction_criteria table.
				int start = folderQuery.indexOf("'");
				int end = folderQuery.lastIndexOf("'");
				extInfo[3] = folderQuery.substring(start + 1, end);
				extInfo[4] = "false";
				extInfo[5] = rs.getString("REPLICATION_CODE");
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			exportDocLogger.warning("Please enter a valid extraction criteria present in table " + e);
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"getExtractionInfo-SQLException", e);
		}
		return extInfo;
	}
	/**
	 * @param deltaExtractionId
	 * @return
	 * @throws IOException
	 */
	public static String[] getDeltaCriteriaCode(final String deltaUtilityID) throws IOException {
		String[] extInfo = new String[6];
		try {
			//idocsProperties.load(inputStream);
			getConnection();
			String query = idocsProperties.getProperty("Query_getExtractionCriteriaID");
			query = query+ deltaUtilityID + "'";
			exportDocLogger.info("getDeltaExtractionCriteria : "+query);
			PreparedStatement stmt = conn.prepareStatement(query);
			ResultSet rs1 = stmt.executeQuery();
			while (rs1.next())
			{
				extInfo[0]=rs1.getString("EXTRACTION_CRITERIA_CODE");
				exportDocLogger.warning("deltaUtility Criteria code="+deltaUtilityID);
			}
			rs1.close();
			stmt.close();
		} catch (SQLException e) {
			exportDocLogger.info("Error in getDeltaExtractionId");
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"getDeltaCriteriaCode-SQLException", e);
		}
		return extInfo;
	}
	public static ResultSet getDeltaRegion(final String deltaExtractionUtilityID) throws IOException {
		try {
			//idocsProperties.load(inputStream);
			getConnection();
			String query = idocsProperties.getProperty("Query_deltaRegion");
			query = query+ deltaExtractionUtilityID + "'";
			PreparedStatement stmt = conn.prepareStatement(query);
			rs = stmt.executeQuery();
		} catch (SQLException e) {
			exportDocLogger.info("Error in getDeltaRegion");
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"getDeltaRegion-SQLException", e);
		}
		return rs;
	}
	/**
	 * @param deltaRegion
	 * @param deltaExtractionCriteria
	 * @return
	 * @throws IOException
	 */
	public static ResultSet getImportFailedDocs(final String deltaRegion, final String deltaUtilityID) throws IOException {
		try {
			//idocsProperties.load(inputStream);
			getConnection();
			String query1 = idocsProperties.getProperty("Query_import_failure1");
			String query2 = idocsProperties.getProperty("Query_import_failure2");
			String query = query1+" "+deltaRegion+query2+deltaUtilityID+"'";
			PreparedStatement stmt = conn.prepareStatement(query);
			exportDocLogger.info("getImportFailedDocs-"+query);
			rs = stmt.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"getImportFailedDocs-SQLException", e);
		}
		return rs;
	}
	public static ResultSet getExtractFailedDocs(final String deltaRegion, final String deltaUtilityID) throws IOException {
		try {
			//idocsProperties.load(inputStream);
			getConnection();
			String query1 = idocsProperties.getProperty("Query_import_failure1");
			String query2 = idocsProperties.getProperty("Query_extract_failure");
			String query = query1+" "+deltaRegion+query2+deltaUtilityID+"'";
			PreparedStatement stmt = conn.prepareStatement(query);
			exportDocLogger.info("extracty query-"+query);
			rs = stmt.executeQuery();
		} catch (SQLException e) {
			exportDocLogger.info("Error in getExtractFailedDocs");
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"getExtractFailedDocs-SQLException", e);
		}
		return rs;
	}

	
	/**
	 * @param utilityId
	 * @param doc
	 * @param regionName
	 * @throws SQLException
	 * @throws IOException
	 */
	public static void DeltaupdateRegion(String utilityId, Document doc, String regionName) throws SQLException, IOException {
		//idocsProperties.load(inputStream);
		getConnection();
		try {

			String ID=doc.getItemValueString("DocID");
			String Folder_name=(doc.getItemValueString("FileRoom")).toUpperCase();//case is not uniform in documents.So converting all to upper case
			//As per Hema's request,updating misc with country-19/02/2011
			if (Folder_name.equals("MISCELLANEOUS")){Folder_name="COUNTRY";}
			String folder_num = null,sql_query;
			if ((doc.getItemValueString("FileRoom")).toLowerCase().equals("projects")) folder_num=doc.getItemValueString("Project_id");
			if ((doc.getItemValueString("FileRoom")).toLowerCase().equals("institutions")) folder_num=doc.getItemValueString("Institution_Nbr");
			if ((doc.getItemValueString("FileRoom")).toLowerCase().equals("miscellaneous")) folder_num=doc.getItemValueString("Country_Name_Code");
			//	sql_query="'"+utilityId+"'"+",'"+"ToBeUpdated"+"',"+"'"+folder_num+"',"+"'"+Folder_name+"','"+ID+"','"+"ToBeUpdated"+"','"+"N"+"','"+"N"+"'";
			sql_query="'"+utilityId+"'"+",'"+"ToBeUpdated"+"',"+"'"+folder_num+"',"+"'"+Folder_name+"','"+ID+"','"+"ToBeUpdated"+"','"+"P"+"','"+"P"+"','"+"Y"+"'";
//			sql_query="'"+utilityId+"'"+",'"+"ToBeUpdated"+"',"+"'"+folder_num+"',"+"'"+Folder_name+"','"+ID+"','"+"ToBeUpdated"+"','"+"N"+"','"+"N"+"','Y'";

			// Checking duplicates to prevent duplicate DOCID entries for a particular extraction_utility_code
			boolean uniqueDoc = DBConnection.checkDuplicates(ID,regionName,utilityId);
			if (uniqueDoc){
				String q1=idocsProperties.getProperty("Query_insert");
				String q2=idocsProperties.getProperty("Query_region");
				sql_query=q1+regionName+q2+sql_query+")";
				String delta_del_update=idocsProperties.getProperty("Delete_delta_table");
				delta_del_update=delta_del_update+ID+"','M')";
				exportDocLogger.info(sql_query);
				PreparedStatement stmt = conn.prepareStatement(sql_query);
				PreparedStatement stmt1 = conn.prepareStatement(delta_del_update);
				rs = stmt.executeQuery();
				rs1=stmt1.executeQuery();
				commonDbMethod();
				stmt.close();
				stmt1.close();
				rs.close();
				rs1.close();

			}
		} catch (NotesException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"DeltaupdateRegion-SQLException", e);
		}
	}
	
	
	/**
	 * checkDuplicateRecords method checks whether the set is having duplicate entries or not 
	 * @param docID
	 * @param regionName
	 * @param utilityId
	 * @return boolean
	 */
	public static boolean checkDuplicates(String docID, String regionName, String utilityId) throws IOException {
		String key = docID + "|" + regionName + "|" + utilityId;
		if(uniqueDocIdSet.contains(key)){
			exportDocLogger.info(" key = " + key + " false");
			return false;
		}else{
			uniqueDocIdSet.add(key);
			exportDocLogger.info(" key = " + key + " true");
			return true;
		}
	}
	
	/**
	 * updateStartSummary method update extraction summary START details into extraction_utility_info table
	 * @param utilityId
	 * @param extractionId
	 * @param displayPath
	 * @throws IOException
	 */
	public static void updateStartSummary(final String utilityId, final String extractionId, final String displayPath) throws IOException {
		PreparedStatement stmt = null;
		try {
			final String status = "Started";
			getConnection();
			//idocsProperties.load(inputStream);
			final String subquery = "'" + utilityId + "','" + extractionId + "','" + displayPath + "',sysdate,'" + status + "'";
			final String q1 = idocsProperties.getProperty("Query_s_sum");
			final String query = q1 + subquery + ")";
			 stmt = conn.prepareStatement(query);
			stmt.executeQuery();
			commonDbMethod();
			stmt.close();
		} catch (SQLException e) {
			final String message = e.getMessage();
			final String sqlState = e.getSQLState();
			int errorCode = e.getErrorCode();
			exportDocLogger.info("Error in updating summary ~ " + message + " ~ " + errorCode + " ~ " + sqlState);
			exportDocLogger.info("EXTRACTION CRITERIA ID ~ " + extractionId + " ~ NOT FOUND IN TABLE.");
			exportDocLogger.log(Level.WARNING,"updateStartSummary-SQLException", e);
		}finally{
			if (stmt != null) stmt = null;
		}
	}


	/**
	 * updateExtractionUtilityStart method calls updateExtractionUtility method for processing the request
	 * @param utilityId
	 * @throws IOException
	 */
	public static void updateExtractionUtilityStart(final String utilityId) throws IOException {
		//idocsProperties.load(inputStream);
		final String query = idocsProperties.getProperty("Query_disc");
		updateExtractionUtility(utilityId, query);
	}

	/**
	 * updateExtractionUtilityEnd method calls updateExtractionUtility method for processing the request
	 * @param utilityId
	 * @throws IOException
	 */
	public static void updateExtractionUtilityEnd(final String utilityId) throws IOException {
		//idocsProperties.load(inputStream);
		final String query = idocsProperties.getProperty("Query_disc_end");
		updateExtractionUtility(utilityId, query);
	}

	/**
	 * updateExtractionUtility method updates the extraction utility table 
	 * @param utilityId
	 * @param sql
	 * @throws IOException
	 */
	public static void updateExtractionUtility(final String utilityId, final String sql) throws IOException {
		try {
			getConnection();
			final String query = sql + utilityId + "'";
			exportDocLogger.info(query);
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.executeQuery();
			commonDbMethod();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"updateExtractionUtility-SQLException", e);
		}
	}

	/**
	 * getDiscussionData method selects discussion documents details from region table
	 * @param utilityId
	 * @param docid
	 * @param region
	 * @return ResultSet of discussions
	 * @throws NotesException
	 * @throws IOException
	 */
	public static String getDiscussionData(final String utilityId, final String docid, final String region, String displayPath) throws NotesException, IOException {
		Connection discConn = null;
		ResultSet discRs = null;
		PreparedStatement dstmt = null;
		String folderPath = null;
		try {
			discConn= DBConnection.getBatchConnection();
			//idocsProperties.load(inputStream);
			final String q1 = idocsProperties.getProperty("Query_disc_data1");
			final String q2 = idocsProperties.getProperty("Query_disc_data2");
			final String q3 = idocsProperties.getProperty("Query_disc_data3");
			final String query = q1 + region + q2 + docid + q3 + utilityId + "'";
//			exportDocLogger.warning("getDiscussionData = " + query);
			dstmt = discConn.prepareStatement(query);
			discRs = dstmt.executeQuery();
			while (discRs.next()){	
				String folderValueCode = discRs.getString("FOLDER_VALUE_CODE");
				String folderTypeCode = discRs.getString("FOLDER_TYPE_CODE");
				folderPath = displayPath + "\\" + folderTypeCode + "\\" + folderValueCode + "\\";
				//exportDocLogger.info(displayPath + "folder path parent doc = " + folderPath);
			}
			discRs.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"getDiscussionData-SQLException", e);
		}finally{
			try{
				if (dstmt !=null){
					dstmt.close();
					dstmt = null;
				}
			if (discConn !=null){
				discConn.close();
				discConn = null;
			}
			}catch(SQLException se){
				se.printStackTrace();
				exportDocLogger.log(Level.WARNING,"updateRegion-Exception DB Connection close error", se);
			}
		}
		
		return folderPath;
	}

	/**
	 * updateEndSummary method updates extraction summary END details into extraction_utility_info table
	 * @param utilityId
	 * @param criteriaCount
	 * @throws IOException
	 */
	public static void  updateEndSummary(final String utilityId, long criteriaCount) throws IOException{
		try {
			getConnection();
			//idocsProperties.load(inputStream);
			final String status = "Completed";
			final String q1 = idocsProperties.getProperty("Query_sumry_end1");
			final String q2 = idocsProperties.getProperty("Query_sumry_end2");
			final String q3 = idocsProperties.getProperty("Query_sumry_end3");
			final String query = q1 + status + q2 + criteriaCount + " " + q3 + utilityId + "'";
			PreparedStatement stmt = conn.prepareStatement(query);
			rs = stmt.executeQuery();
			commonDbMethod();
			stmt.close();
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"updateEndSummary-SQLException", e);
		}
	}

	public static void updateDiscEndSummary(String utilityId, String extractionId, String display_path) {
//		try {
			getConnection();
			//idocsProperties.load(inputStream);
//		} 
//		catch (IOException e) {
//			e.printStackTrace();
//			exportDocLogger.log(Level.WARNING,"updateDiscEndSummary-SQLException", e);
//		}
	}
	
	public static Integer  getDiscStartSummary(final String utilityId) throws IOException{
		Integer totalCount=0;
		try {
			getConnection();
			//idocsProperties.load(inputStream);
			final String q1 = idocsProperties.getProperty("Query_Disc_Start");

			final String query = q1 + utilityId +"'";
			exportDocLogger.info(query);
			PreparedStatement stmt = conn.prepareStatement(query);
			rs = stmt.executeQuery();
			while (rs.next()){
				totalCount=rs.getInt(1);
			}
			stmt.close();
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"getDiscStartSummary-SQLException", e);
		}
		return totalCount;
	}

	/**
	 * @param extractionId
	 * @return
	 * @throws IOException
	 */
	public static ResultSet getReplicaDate(final String replica_code) throws IOException {
		try {
			//idocsProperties.load(inputStream);
			getConnection();
			String query_part1 = idocsProperties.getProperty("Query_replica_date1");
			String complete_query = query_part1+replica_code+"'";
			PreparedStatement stmt = conn.prepareStatement(complete_query);
//			System.out.println(complete_query);
			rs = stmt.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"getReplicaDate-SQLException", e);
		}
		return rs;
	}

	public static void  updateDeltaDeletedDocs(final ArrayList<String> docIds) throws IOException{
		try {			
			PreparedStatement stmt = conn.prepareStatement(idocsProperties.getProperty("Delete_delta_table")); 
			((OraclePreparedStatement)stmt).setExecuteBatch (2);
			for(String docId : docIds){
				stmt.setString(1, docId); 
				stmt.setString(2, "R");
				stmt.executeUpdate();
			}
			((OraclePreparedStatement)stmt).sendBatch();
			exportDocLogger.info("Delete_delta_table saved");
			stmt.close();		
		} catch (SQLException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"updateDeltaDeletedDocs-SQLException", e);
		}
	}

	/**
	 * saveWorkflowAuditTrial method save workflows, audit activities and audit trials as a batch from a collection
	 * @param auditReportsList
	 * @param auditDetailsList
	 * @param auditTrialsList
	 * @param isBaseline 
	 * @return void
	 */
	public static void saveWorkflowAuditTrial(ArrayList<MigWfAuditReport> auditReportsList, ArrayList<MigWfAuditDetails> auditDetailsList, ArrayList<MigWfActAuditTrial> auditTrialsList, boolean isBaseline) {
		String database = WorkflowAuditTrial.workflowMap.get("database");
		PreparedStatement wfstmt = null;
		Connection wfconn = null;
		
		try {
			wfconn= DBConnection.getBatchConnection();

			//idocsProperties.load(inputStream);
			wfstmt = wfconn.prepareStatement(idocsProperties.getProperty("Insert_audit_report")); 
			((OraclePreparedStatement)wfstmt).setExecuteBatch (5);
			for(MigWfAuditReport mwr : auditReportsList){
				wfstmt.setString(1, mwr.getWorkflowId()); 
				wfstmt.setString(2, mwr.getWorkflowName()); 
				wfstmt.setString(3, mwr.getDocumentName()); 
				wfstmt.setString(4, mwr.getDocumentId()); 
				wfstmt.setString(5, database); 
				wfstmt.executeUpdate(); //JDBC queues this for later execution 
			}
			((OraclePreparedStatement)wfstmt).sendBatch(); // JDBC sends the queued request
			exportDocLogger.info("MIG_WF_AUDIT_REPORT saved");
			wfstmt.close();

			wfstmt = wfconn.prepareStatement(idocsProperties.getProperty("Insert_audit_details")); 
			((OraclePreparedStatement)wfstmt).setExecuteBatch (7);

			for(MigWfAuditDetails mwd : auditDetailsList){
				wfstmt.setString(1, mwd.getWorkflowId()); 
				wfstmt.setString(2, mwd.getActivityId()); 
				wfstmt.setString(3, mwd.getActivityName()); 
				wfstmt.setString(4, mwd.getTimeStamp()); 
				wfstmt.setString(5, mwd.getAssignedTo()); 
				wfstmt.setString(6, mwd.getPerformedBy()); 
				wfstmt.setString(7, mwd.getAction()); 
				wfstmt.executeUpdate(); 
			}
			((OraclePreparedStatement)wfstmt).sendBatch();
			exportDocLogger.info("MIG_WF_AUDIT_DETAILS saved");
			wfstmt.close();

			wfstmt = wfconn.prepareStatement(idocsProperties.getProperty("Insert_audit_trial")); 
			((OraclePreparedStatement)wfstmt).setExecuteBatch (4);

			for(MigWfActAuditTrial mat : auditTrialsList){
				wfstmt.setString(1, mat.getActivityId()); 
				wfstmt.setString(2, mat.getActivityAuditTrial()); 
				wfstmt.setString(3, mat.getWorkflowId()); 
				wfstmt.setString(4, mat.getTimeStamp()); 
				wfstmt.executeUpdate(); 
			}
			((OraclePreparedStatement)wfstmt).sendBatch();
			exportDocLogger.info("MIG_WF_ACT_AUDIT_TRAIL saved");
			wfstmt.close();

			wfconn.commit();
			wfstmt.close();

		} catch (SQLException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"saveWorkflowAuditTrial-SQLException", e);
		}finally{
			try{
				if (wfstmt !=null){
					wfstmt.close();
					wfstmt = null;
				}
			if (wfconn !=null){
				wfconn.close();
				wfconn = null;
			}
			}catch(SQLException se){
				se.printStackTrace();
				exportDocLogger.log(Level.WARNING,"updateRegion-Exception DB Connection close error", se);
			}
		}
	}

	/**
	 * deleteWorkflowAuditTrials method delete workflow audit trials from 3 tables
	 * @param database 
	 * @return void
	 */
	public static void deleteWorkflowAuditTrials(String database) {
		
		PreparedStatement stmt = null;
		try {
			getConnection();
			//idocsProperties.load(inputStream);

			String query = idocsProperties.getProperty("Delete_audit_details") + database + "')";
			stmt = conn.prepareStatement(query);
			stmt.executeQuery();
			exportDocLogger.info(query);
			stmt.close();

			query = idocsProperties.getProperty("Delete_audit_trial") + database + "')";
			stmt = conn.prepareStatement(query);
			stmt.executeQuery();
			exportDocLogger.info(query);
			stmt.close();
			
			query = idocsProperties.getProperty("Delete_audit_report") + database + "'";
			stmt = conn.prepareStatement(query);
			stmt.executeQuery();
			exportDocLogger.info(query);
			stmt.close();
			conn.commit();
			exportDocLogger.info("All records deleted");

		} catch (SQLException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"deleteWorkflowAuditTrials-SQLException", e);
		} 
	}

	/**
	 * printWorkflowAuditTrialCount method prints the total counts of workflows, audit activities & workflow audit trials
	 * @return void
	 */
	public static void printWorkflowAuditTrialCount() {
		try {
			String database = WorkflowAuditTrial.workflowMap.get("database");
			//idocsProperties.load(inputStream);
			getConnection();

			String query = idocsProperties.getProperty("Count_audit_report") + database + "'";
			PreparedStatement stmt = conn.prepareStatement(query);
			rs = stmt.executeQuery();
			rs.next();
			exportDocLogger.warning("Total number of records on MIG_WF_AUDIT_REPORT table : " + rs.getString("rowcount"));
			rs.close() ;

			query = idocsProperties.getProperty("Count_audit_details") + database + "')";
			stmt = conn.prepareStatement(query);
			rs = stmt.executeQuery();
			rs.next();
			exportDocLogger.warning("Total number of records on MIG_WF_AUDIT_DETAILS table : " + rs.getString("rowcount"));
			rs.close() ;

			query = idocsProperties.getProperty("Count_audit_trial") + database + "')";
			stmt = conn.prepareStatement(query);
			rs = stmt.executeQuery();
			rs.next();
			exportDocLogger.warning("Total number of records on MIG_WF_ACT_AUDIT_TRAIL table : " + rs.getString("rowcount"));

			rs.close() ;
			stmt.close();

		} catch (SQLException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"printWorkflowAuditTrialCount-SQLException", e);
		}
//		catch (IOException e) {
//			e.printStackTrace();
//			exportDocLogger.log(Level.WARNING,"printWorkflowAuditTrialCount-IOException", e);
//		}
	}

	public static String updateReportUtilityMap(String utilityId, String extractionQuery) {
		String reportUtilCode = null;
		try {
			getConnection();
			final String q1 = idocsProperties.getProperty("updateReportUtilityCode");
			final String q2 = idocsProperties.getProperty("updateReportUtilityCode1");
			final String query = q1+utilityId+"' "+q2+extractionQuery+"'";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.executeQuery();
			conn.commit();
			stmt.close();
			
			final String query1 = idocsProperties.getProperty("updt_rept_util_map1") + utilityId 
				+ idocsProperties.getProperty("updt_rept_util_map2") + extractionQuery + "'";
			
			PreparedStatement stmt1 = conn.prepareStatement(query1);
			ResultSet rs = stmt1.executeQuery();
//			TODO - report utility code fix...if no resut found quit extraction
			if(	rs.next()){
				reportUtilCode = rs.getString("REPORT_UTILITY_ID");
			}
			rs.close();
			stmt1.close();
		} catch (SQLException e) {
			exportDocLogger.warning("Please enter a valid extraction criteria present in table " + e);
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"updateReportUtilityMap-SQLException", e);
		}
		return reportUtilCode;
	}

	public static String getExtractiontUtilityId(String extractionQuery) {
		String utilCode = null;
		try {
			getConnection();			
			final String query1 = idocsProperties.getProperty("get_ext_id_from_utility_map") + extractionQuery + "'";
//			System.out.println(query1);
			PreparedStatement stmt1 = conn.prepareStatement(query1);
			ResultSet rs = stmt1.executeQuery();
			if(	rs.next()){
				utilCode = rs.getString("EXTRACTION_UTILITY_ID");
			}
			rs.close();
			stmt1.close();
		} catch (SQLException e) {
			exportDocLogger.warning("Please enter a valid extraction criteria present in table " + e);
			exportDocLogger.log(Level.WARNING,"updateReportUtilityMap-SQLException", e);
		}
		return utilCode;
	}
	
	
	public static String getExtractiontCriteriaCode(String extractionUtilityID) {
		String utilCode = null;
		try {
			getConnection();	
			
			final String query1 = idocsProperties.getProperty("get_ext_criteria_from_utility_map") + extractionUtilityID + "'";
//			System.out.println(query1);
			PreparedStatement stmt1 = conn.prepareStatement(query1);
			ResultSet rs = stmt1.executeQuery();
			if(	rs.next()){
				utilCode = rs.getString("EXTRACTION_CRITERIA_CODE");
			}
			rs.close();
			stmt1.close();
		} catch (SQLException e) {
			exportDocLogger.warning("Please enter a valid extraction criteria present in table " + e);
			exportDocLogger.log(Level.WARNING,"updateReportUtilityMap-SQLException", e);
		}
		return utilCode;
	}

	public static Set<String> getErrorDocuments(String extractionQuery) {
		Set<String> errorDocs = new HashSet<String>();
		try {
			getConnection();
			final String query2 = idocsProperties.getProperty("get_err_doc2"); // + extractionQuery + "'";
//			System.out.println(query2);
			PreparedStatement stmt1 = conn.prepareStatement(query2);
			ResultSet rs = stmt1.executeQuery();
			while(rs.next()){
				errorDocs.add(rs.getString("SOURCE_DOC_UNIQUE_ID") + "_" +  rs.getString("SOURCE_DOC_ID"));
			}
			rs.close();
			stmt1.close();
		} catch (SQLException e) {
			exportDocLogger.warning("Please enter a valid extraction criteria present in table " + e);
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"updateReportUtilityMap-SQLException", e);
		}
		return errorDocs;
	}

	public static Set<String> getToBeSkippedDocuments(String region, String extUtilId) {
		Set<String> skipDocs = new HashSet<String>();
		try {
			getConnection();
			final String query2 = idocsProperties.getProperty("get_skipped_docs1") + region + "" +
			idocsProperties.getProperty("get_skipped_docs2") + extUtilId + "'";
//			System.out.println(query2);
			PreparedStatement stmt1 = conn.prepareStatement(query2);
			ResultSet rs = stmt1.executeQuery();
			while(rs.next()){
				skipDocs.add(rs.getString("FOLDER_VALUE_CODE") + "_" +  rs.getString("LEGACY_DOCUMENT_ID"));
			}
			rs.close();
			stmt1.close();
		} catch (SQLException e) {
			exportDocLogger.warning("Please enter a valid extraction criteria present in table " + e);
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"updateReportUtilityMap-SQLException", e);
		}
		return skipDocs;
	}

	public static void saveSkippedDocuments(
			ArrayList<MigrationSkippedDocuments> migrationSkippedDocumentList,Connection batchConn) {
		PreparedStatement stmt = null;
		try{
			exportDocLogger.info("Prepairing to save on Migration Skipped Documents");
			 stmt = batchConn.prepareStatement(idocsProperties.getProperty("Insert_migration_skipped_documents")); 
			((OraclePreparedStatement)stmt).setExecuteBatch (11);			

			for(MigrationSkippedDocuments msd : migrationSkippedDocumentList){
				stmt.setString(1, msd.getUtilityCode()); 
				stmt.setString(2, msd.getDocumentId()); 
				stmt.setString(3, msd.getDocumentUniqueId()); 
				stmt.setString(4, msd.getVersion()); 
				stmt.setString(5, msd.getTitle()); 
				stmt.setString(6, msd.getFolderTypeCode()); 
				stmt.setString(7, msd.getFileCabinet()); 
				stmt.setString(8, msd.getDatabase()); 
				stmt.setString(9, msd.getSkipReason()); 
				stmt.setString(10, msd.getFolderValueCode()); 
				stmt.setString(11, msd.getErrorCode()); 
				stmt.executeUpdate(); 
			}
			((OraclePreparedStatement)stmt).sendBatch();
			exportDocLogger.info("Migration Skipped Documents saved");
			stmt.close();
			batchConn.commit();
		}
		catch (Exception e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"saveSkippedDocuments-IOException", e);
		}finally{
			try{
				if (stmt !=null){
					stmt.close();
					stmt = null;
				}
			if (batchConn !=null){
				batchConn.close();
				batchConn = null;
			}
			}catch(SQLException se){
				se.printStackTrace();
				exportDocLogger.log(Level.WARNING,"updateRegion-Exception DB Connection close error", se);
			}
		}

	}

	public static ResultSet getDeltaExtractionUtilityID(String extractionId) throws SQLException {

//		try {
			//idocsProperties.load(inputStream);

			getConnection();
			final String q1 = idocsProperties.getProperty("Query_Disc");
			final String query = q1+extractionId+"'";
			exportDocLogger.info(query);
			PreparedStatement stmt = conn.prepareStatement(query);
			rs = stmt.executeQuery();
//			commonDbMethod();
//			stmt.close();
//			rs.close();
//		} 
//		catch (IOException e) {
//			e.printStackTrace();
//			exportDocLogger.log(Level.WARNING,"getDeltaExtractionUtilityID-IOException", e);
//		}
		return rs;
	}

	public static void updateDiscEndSummary(String utilityId, int totalCount) throws SQLException {

		try {
			//idocsProperties.load(inputStream);

			getConnection();
			final String q1 = idocsProperties.getProperty("Query_Disc_End1");
			final String q2 = idocsProperties.getProperty("Query_Disc_End2");
			final String query = q1+totalCount+q2+utilityId+"'";
			exportDocLogger.info(query);
			PreparedStatement stmt = conn.prepareStatement(query);
			rs = stmt.executeQuery();
			commonDbMethod();
			stmt.close();
			rs.close();
		} 
		catch (IOException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"updateDiscEndSummary-IOException", e);
		}

	}

	/**
	 * databaseTableCheck - read database names from property file, checks whether they exists or not. 
	 * If not, throw error message
	 * @return void
	 */
	public static void databaseTableCheck() {
		String tableName = "";
		try {
			PreparedStatement stmt = null;
			//idocsProperties.load(inputStream);
			getConnection();
			String countQuery = idocsProperties.getProperty("record_count");
			String tables = idocsProperties.getProperty("table_names");
			String[] tableNames = tables.split(",");
			for(String table : tableNames){
				tableName = table;
				exportDocLogger.info("Checking " + table + " table...");
				stmt = conn.prepareStatement(countQuery + tableName);
				stmt.executeQuery();
			}
			stmt.close();
		} catch (Exception e) {
			print(tableName + " Table does not exists.", true);
			exportDocLogger.log(Level.WARNING,"databaseTableCheck-Exception", e);
		}
	}

	public static void print(String message, boolean isExit){
		exportDocLogger.warning(message);
		if(isExit){
			System.exit(0);
		}		
	}

	public static void updateRegion(ArrayList<RegionModel> regionList, String region, Connection batchConn) {
		
		PreparedStatement stmt=null;
		try{
			exportDocLogger.info("Prepairing to update region table");
			String q1=idocsProperties.getProperty("Query_insert");
			String q2=idocsProperties.getProperty("Query_region");
			String sqlQuery=q1+region+q2;
			 stmt = batchConn.prepareStatement(sqlQuery); 
			((OraclePreparedStatement)stmt).setExecuteBatch (9);			
			for(RegionModel rm : regionList){
//				exportDocLogger.warning("Project ID : " + rm.getFolderValueCode() +  " == Legacy Document Id : " + rm.getLegacyDocumentId());
				stmt.setString(1, rm.getExtractionUtilityCode()); 
				stmt.setString(2, rm.getImportUtilityCode()); 
				stmt.setString(3, rm.getFolderValueCode()); 
				stmt.setString(4, rm.getFolderTypeCode()); 
				stmt.setString(5, rm.getLegacyDocumentId()); 
				stmt.setString(6, rm.getDocumentumDocId()); 
				stmt.setString(7, rm.getRollbackReqdInd()); 
				stmt.setString(8, rm.getRollbackSuccessfulInd()); 
				stmt.setString(9, rm.getExtractionSuccessful()); 
				stmt.executeUpdate(); 
			}
//			System.out.println(sqlQuery);
			((OraclePreparedStatement)stmt).sendBatch();
			exportDocLogger.warning("Documents saved into region table");
			stmt.close();
			batchConn.commit();
			
		}
		catch (Exception e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"updateRegion-Exception", e);
		}finally{
			try{
				if (stmt !=null){
					stmt.close();
					stmt = null;
				}
				if (batchConn !=null){
					batchConn.close();
					batchConn = null;
				}
			}catch(SQLException se){
				se.printStackTrace();
				exportDocLogger.log(Level.WARNING,"updateRegion-Exception DB Connection close error", se);
			}
			
		}
	}

	public static void updateRegionTableExtractionSuccessfulField(String utilityId, String region, String isSuccessful) {
		try {
			getConnection();
			final String q1 = idocsProperties.getProperty("region_sql1");
			final String q2 = idocsProperties.getProperty("region_sql2");
			final String q3 = idocsProperties.getProperty("region_sql3");
			final String query = "update " + region + q1 + isSuccessful + q2 + utilityId + q3 + utilityId + "'";
//			System.out.println(query);
			Connection con = getBatchConnection();
			PreparedStatement stmt = con.prepareStatement(query);
			stmt.executeQuery();
			stmt.close();
			con.commit();
		} catch (SQLException e) {
			exportDocLogger.warning("Please enter a valid extraction criteria present in table " + e);
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"updateReportUtilityMap-SQLException", e);
		} 

	}
	
	/**
	 * @param documentReportList
	 * @param documentDetailReportList
	 * @param securityExceptionList
	 * @return void
	 */
	public static void saveReports(
			ArrayList<DocumentReportModel> documentReportList,
			ArrayList<DocumentDetailReportModel> documentDetailReportList,
			ArrayList<SecurityExceptionReportModel> securityExceptionList) {

		exportDocLogger.warning("111111>>>>>>>>>>>>> saveReports");
		
		Connection reportConn;
		Statement stmt = null;
		try {
			reportConn = DBConnection.getBatchConnection();		
			
			stmt = reportConn.createStatement();
			
			StringBuffer sb = new StringBuffer();
			for(DocumentReportModel dr : documentReportList){
				sb.append("update recon_doc_count_report set EXTRACT_DOC_CNT=");
				sb.append(dr.getExtractDocCnt());
				sb.append(", EXTRACT_DOC_SIZE_NBR="); 
				sb.append(dr.getExtractDocSizeNbr());
				sb.append(" where REPORT_UTILITY_CODE='");
				sb.append(dr.getReportUtilityCode());
				sb.append("' and FOLDER_VALUE_CODE='");
				sb.append(dr.getFolderValueCode());
				sb.append("' and FOLDER_TYPE_CODE='"); 
				sb.append(dr.getFolderTypeCode()); 
				sb.append("'");
				exportDocLogger.info(sb.toString());
				stmt.addBatch(sb.toString());
				sb.setLength(0);
			}
			stmt.executeBatch();
			exportDocLogger.warning("Document Report saved");
			stmt.close();

			sb = new StringBuffer();
			stmt = reportConn.createStatement();			
			for(DocumentDetailReportModel ddr : documentDetailReportList){
				sb.append("update recon_sub_fldr_doc_cnt_rep set LEVEL1_EXTRACT_DOC_CNT=");
				sb.append(ddr.getLevel1ExtractDocCnt());
				sb.append(", LEVEL1_EXTRACT_DOC_SIZE_NBR="); 
				sb.append(ddr.getLevel1ExtractDocSizeNbr());
				sb.append(" where REPORT_UTILITY_CODE='");
				sb.append(ddr.getReportUtilityCode());
				sb.append("' and FOLDER_VALUE_CODE='");
				sb.append(ddr.getFolderValueCode());
				sb.append("' and FOLDER_TYPE_CODE='"); 
				sb.append(ddr.getFolderTypeCode()); 
				sb.append("' and LEVEL1_FOLDER_NME='"); 
				sb.append(ddr.getLevel1FolderNme()); 
				sb.append("'");
				exportDocLogger.info(sb.toString());
				stmt.addBatch(sb.toString());
				sb.setLength(0);
			}
			stmt.executeBatch();
			exportDocLogger.warning("Document Detailed Report saved");
			stmt.close();

			sb = new StringBuffer();
			stmt = reportConn.createStatement();			
			for(SecurityExceptionReportModel ser : securityExceptionList){
				sb.append("update recon_security_report set EXTRACT_DOC_ID='");
				sb.append(ser.getExtractDocId());
				sb.append("', EXTRACT_DOC_UNIQUE_ID='"); 
				sb.append(ser.getExtractDocUniqueId());
				sb.append("', EXTRACT_DOC_NME='"); 
				sb.append(ser.getExtractDocName().replaceAll("'", "''"));
				sb.append("', EXTRACT_SECURITY_CLASS_CODE='"); 
				sb.append(ser.getExtractSecurityClassCode());
				sb.append("', EXTRACT_DOC_VER_NBR='"); 
				sb.append(ser.getExtractDocVerNbr());
				sb.append("' where REPORT_UTILITY_CODE='");
				sb.append(ser.getReportUtilityCode());
				sb.append("' and FOLDER_VALUE_CODE='");
				sb.append(ser.getFolderValueCode());
				sb.append("' and FOLDER_TYPE_CODE='"); 
				sb.append(ser.getFolderTypeCode()); 
				sb.append("' and SOURCE_DOC_UNIQUE_ID='"); 
				sb.append(ser.getExtractDocUniqueId()); 
				sb.append("'");
//				exportDocLogger.warning(sb.toString());
				stmt.addBatch(sb.toString());
				sb.setLength(0);
			}
			stmt.executeBatch();
			exportDocLogger.warning("Security Exception Report saved");
			stmt.close();
			reportConn.commit();
			reportConn.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
			print("SQLException occurred while saving in Report tables", true);
		}		
	}

	public static ArrayList<String> getSkippedDocsCount(String utilityId) {
		ArrayList<String> skipList = new ArrayList<String>();
		try {
			PreparedStatement stmt = conn.prepareStatement("select SKIP_REASON, count(DOCUMENT_UNIQUE_ID) FROM MIGRATION_SKIPPED_DOCUMENTS WHERE UTILITY_CODE='" + utilityId + "' group by SKIP_REASON");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()){
				skipList.add("Skip Reason : " + rs.getString(1) + " | Count of Documents : " + rs.getString(2));
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return skipList;
	}

	public static Set<String> alreadySkippedDocuments(String utilityId) {
		Set<String> skippedDocs = new HashSet<String>();
		try {
			getConnection();
			final String query2 = idocsProperties.getProperty("already_skipped") + utilityId + "'";
//			System.out.println(query2);
			PreparedStatement stmt1 = conn.prepareStatement(query2);
			ResultSet rs = stmt1.executeQuery();
			while(rs.next()){
				skippedDocs.add(rs.getString("DOCUMENT_UNIQUE_ID"));
			}
			rs.close();
			stmt1.close();
		} catch (SQLException e) {
			exportDocLogger.warning("Please enter a valid extraction criteria present in table " + e);
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"updateReportUtilityMap-SQLException", e);
		}
		return skippedDocs;
	}

	public static void updateExtractionSummary(String extractionQuery,
			String utilityId, String folderQuery, long totalProcessedDocCount,
			long uniqueDoc, long versionDoc, long currentRun, long lastRun,
			long totalDocsWithVer, long totalSkipped, String sizeInMB,
			String sizeInGB) {

		try {
			getConnection();
			String query = idocsProperties.getProperty("Delete_extraction_summary") + extractionQuery + "'";
			PreparedStatement stmt = conn.prepareStatement(query);
			stmt.executeQuery();
			System.out.println("Extraction Summary records related to " + utilityId + " are deleted");
			stmt.close();

			query = idocsProperties.getProperty("Insert_extraction_summary");
			stmt = conn.prepareStatement(query);
			stmt.setString(1, extractionQuery); 
			stmt.setString(2, utilityId);
			stmt.setString(3, folderQuery);
			stmt.setLong(4, totalProcessedDocCount);
			stmt.setLong(5, uniqueDoc);
			stmt.setLong(6, versionDoc);
			stmt.setLong(7, currentRun);
			stmt.setLong(8, lastRun);
			stmt.setLong(9, totalDocsWithVer);
			stmt.setLong(10, totalSkipped);
			stmt.setString(11, sizeInMB);
			stmt.setString(12, sizeInGB);			
			stmt.executeQuery();
			stmt.close();
			System.out.println("Extraction Summary Table Updated");
		} catch (SQLException e) {
			print("SQLException occurred while saving Extraction Summary", true);
		}

	}

	public static int getMigrationFailedCount(String utilityId, String region) {
		int FailedCount = 0;
		try{
		getConnection();
		
		String query = idocsProperties.getProperty("Query_count") +region +idocsProperties.getProperty("get_skipped_docs2")+
		utilityId+"'"+ "and EXTRACTION_SUCCESSFUL='N'";
		System.out.println(query);
		Connection con = getBatchConnection();
		PreparedStatement stmt = con.prepareStatement(query);
		rs = stmt.executeQuery();
		if(	rs.next()){
			FailedCount = rs.getInt(1);
		}
		rs.close();
		stmt.close();
		con.commit();
		}catch (SQLException e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"getMigrationFailedCount-SQLException", e);
		}
		
		return FailedCount;
	}

	public static void updateAsposeErrorTable(List<AsposeError> asposeErrorList) {
		PreparedStatement stmt = null;
		try{
			getConnection();
			exportDocLogger.warning("Prepairing to save on Aspose Error Documents");
			 stmt = conn.prepareStatement(idocsProperties.getProperty("Insert_aspose_error")); 
			((OraclePreparedStatement)stmt).setExecuteBatch (9);			
			int i = 0;
			for(AsposeError ae : asposeErrorList){
				stmt.setString(1, ae.getUtilityCode()); 
				stmt.setString(2, ae.getFolderTypeCode()); 
				stmt.setString(3, ae.getFolderValueCode());
				stmt.setString(4, ae.getDocumentId()); 
				stmt.setString(5, ae.getVersion()); 
				stmt.setString(6, ae.getTitle()); 
				stmt.setString(7, ae.getCountryCode()); 
				stmt.setString(8, ae.getAbsoluteFilePath()); 
				stmt.setString(9, ae.getExceptionMessage()); 				 
				stmt.executeUpdate(); 
				i++;
			}
			((OraclePreparedStatement)stmt).sendBatch();
			exportDocLogger.warning("Aspose Error Documents saved : " + i);
			stmt.close();
			conn.commit();
		}
		catch (Exception e) {
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"saveSkippedDocuments-IOException", e);
		}
	}

	public static ArrayList<String> getFolderValueCodes(String utilityId, String region) {
		ArrayList<String> folderValueCodes = new ArrayList<String>();
		try {
			String sql = "SELECT DISTINCT FOLDER_VALUE_CODE FROM " + region + "_IDOCS_DOC_MIG_STATUS WHERE EXTRACTION_UTILITY_CODE='" + utilityId + "'";
//			System.out.println(sql);
			PreparedStatement stmt = conn.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()){
				folderValueCodes.add(rs.getString(1));
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return folderValueCodes;	
	}

	public static Set<String> getAsposeErrorDocForCountry(String cntry) {
		Set<String> docIdWithVersion = new HashSet<String>();
		try {
			String sql = "select DOCUMENT_ID, VERSION from aspose_error_docs where COUNTRY_CODE='" + cntry + "'";
//			System.out.println(sql);
			PreparedStatement stmt = conn.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()){
				docIdWithVersion.add(rs.getString(1) + "_" + rs.getString(2));
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return docIdWithVersion;	
	}
	
	public static ArrayList<CountryProjectDoc> getDocList(String extractionId) {
		CountryProjectDoc doc = null;
		ArrayList<CountryProjectDoc> docList = new ArrayList<CountryProjectDoc>();
		try {
			getConnection();
			String query_part1 = idocsProperties.getProperty("getDocFromTable");
			String completeQuery = query_part1 + extractionId  + "'";
//			System.out.println(completeQuery);
			PreparedStatement stmt = conn.prepareStatement(completeQuery);
			rs = stmt.executeQuery();
			while(rs.next()){
				doc = new CountryProjectDoc();
				doc.setSourceDocId(rs.getString("DOCUMENT_ID"));
				doc.setCountryCode(rs.getString("COUNTRY_CODE"));
				doc.setFolderValueCode(rs.getString("FOLDER_VALUE_CODE"));
				doc.setFolderTypeCode(rs.getString("FOLDER_TYPE_CODE"));
				docList.add(doc);
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			print("Error in getting Document from table", true);
		}
		return docList;
	}

	public static long getTotalSkippedDocsCount(String utilityId) {
		String skipCnt = null;
		try {
			String qry = "select count(*) FROM MIGRATION_SKIPPED_DOCUMENTS WHERE UTILITY_CODE='" + utilityId + "'";
//			System.out.println(qry);
			PreparedStatement stmt = conn.prepareStatement(qry);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()){
				skipCnt = rs.getString(1);
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return Long.parseLong(skipCnt);
	}
	
}

