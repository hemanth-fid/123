package org.ifc.idocs.navigation.navigationcontainer;



import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.Breadcrumb;
import com.documentum.webcomponent.navigation.navigationcontainer.NavigationContainer;
import com.documentum.webtop.app.AppSessionContext;
import com.documentum.webtop.app.ApplicationNavigation;

public class IDocsNavigationContainer extends NavigationContainer {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3392692252472433985L;
	private static final String VDMLIST="vdmlist"; 
	private static final String CALLER_COMPONENT="callerComponent";
	private static final String STR_VDM_ROOT_OBJECT="vdmRootObject";
	private String callerComponentValue="";
	private String vdmRootValue="";
	
	public void onInit(ArgumentList args)
	{
		super.onInit(args);
		callerComponentValue=args.get(CALLER_COMPONENT);
		vdmRootValue=args.get(STR_VDM_ROOT_OBJECT);
		AppSessionContext appSessionContext = AppSessionContext.get(getPageContext());
		String strView = appSessionContext.getView();
		if (strView == null){
			strView = AppSessionContext.getDefaultView();
		}
		setComponentPage(strView);
	}
	
	/**
	 * To Navigate Using Breadcrumb 
	 */
	public void onClickBreadcrumb(Breadcrumb breadcrumb, ArgumentList args)
	{
		String strPath = stripDocbaseRoot(breadcrumb.getValue());
		ApplicationNavigation.navigateToFolderPath(this, strPath);
	}
	
	/**
	 * 
	 * @param control
	 * @param args
	 */
	private void navigateToFolder(Control control, ArgumentList args){
		Breadcrumb breadcrumb = (Breadcrumb)getControl(CONTROL_BREADCRUMB, Breadcrumb.class);
  		String strPath = stripDocbaseRoot(breadcrumb.getValue());
  		int lastIndex = strPath.lastIndexOf("/");
  		strPath = strPath.substring(0,lastIndex);
  		ApplicationNavigation.navigateToFolderPath(this, strPath);
	}
	/**
	 * 
	 */
	public void onClose(Control control, ArgumentList args)
	{
		if(control != null && control.getName().trim().length() >0){
           if(callerComponentValue != null && callerComponentValue.trim().length() >0){
        	  args.add("objectId",vdmRootValue);
        	  setComponentJump(VDMLIST,args,super.getContext());
          }else{
        	  navigateToFolder(control,args);
          }
        }else{
        	navigateToFolder(control,args);
         }
	  }
  }

