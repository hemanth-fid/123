/**
* This class 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.workflow.processdiagram;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfLogger;

import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.workflow.processdiagram.DashboardEnv;
import org.ifc.idocs.workflow.processdiagram.EncodingUtil;
import java.io.File;
import java.util.HashMap;
import org.dom4j.Document;
import org.dom4j.Node;

public class WFProcessDiagram extends SvgParams 
{
	static Document error = null;
	static Document empty = null;
	public  Process transformProcessDiagram(Process paramProcess,IDfSession dfSession) throws Exception {
		String str1 = (String)DashboardEnv.getKeyValue(IdocsConstants.STR_SVG_PROCESS_DIAGRAM_FILES_LOCATION);
		String str2 = (String)DashboardEnv.getKeyValue(IdocsConstants.STR_SVG_PROCESS_DIAGRAM_VIRTUAL_LOCATION);
		paramProcess.svgLocation = str2 + paramProcess.instanceId + "_" + paramProcess.Id + IdocsConstants.STR_SVG_EXTENSION;
		File localFile = new File(str1 + File.separator + paramProcess.instanceId + "_" + paramProcess.Id + IdocsConstants.STR_SVG_EXTENSION);
		
		try
		{
			DfLogger.info(this, " :: transformProcessDiagram : "+dfSession.getLoginUserName(), null, null);
			Document localDocument1 = paramProcess.appendExcutionDataXml(dfSession);
			Node localNode = localDocument1.selectSingleNode("process");
			paramProcess.svgWidth = String.valueOf(Double.parseDouble(localNode.valueOf("@width")) + 100.0D);
			paramProcess.svgHeight = String.valueOf(Double.parseDouble(localNode.valueOf("@height")) + 100.0D);
			paramProcess.name = localNode.valueOf("@name");
			
			HashMap localHashMap = new HashMap(2);
			localHashMap.put("_svgWidth", paramProcess.svgWidth);
			localHashMap.put("_svgHeight", paramProcess.svgHeight);
			localHashMap.put("_classicView", "SVG");  // Need to find out 
			localHashMap.put("_exImagesRoot", DashboardEnv.getKeyValue(IdocsConstants.STR_SVG_IMAGE_ICON_LOCATION));
			localHashMap.put("processId", paramProcess.Id);
			localHashMap.put("instanceId", paramProcess.instanceId);
			localHashMap.put("processName", EncodingUtil.urlEencodeString(paramProcess.name));
			localHashMap.put("_complete", ACTIVITY_COMPLETE);
			localHashMap.put("_failed", ACTIVITY_FAILED);
			localHashMap.put("_fault", ACTIVITY_FAULT);
			localHashMap.put("_subProcess", SUB_PROCESS);
			localHashMap.put("_running", ACTIVITY_RUNNING);
			localHashMap.put("_timer", ACTIVITY_TIMER);
			localHashMap.put("_alert_high", ALERT_HIGH);
			localHashMap.put("_alert_med", ALERT_MED);
			localHashMap.put("_alert_low", ALERT_LOW);
			localHashMap.put("endDateTime", END_DATE_TIME);
			localHashMap.put("startDateTime", START_DATE_TIME);
			localHashMap.put("invokeProcessInstance", PROCESS_INVOCATION);
			localHashMap.put("performerName", PERFORMER_NAME);

			String str3 = (String)DashboardEnv.getKeyValue(IdocsConstants.STR_XSL_TO_SVG);
			Document localDocument2 = PaXMLDom4JUtil.transformDOM2DOM(localDocument1, str3, localHashMap);
			paramProcess.svgContent = localDocument2.asXML();
			PaXMLDom4JUtil.writeUTF8ToFile(localFile, paramProcess.svgContent);
		}
		catch (Exception localException3)
		{
			DfLogger.error(this," :: transformProcessDiagram Exception >> "+localException3.getMessage(), null, localException3);
			try
			{
				paramProcess.svgError = getSvgErrorMessage(new File(str1 + File.separator + STR_SVG_ERROR_FILE));
				PaXMLDom4JUtil.writeUTF8ToFile(localFile, paramProcess.svgError);
				paramProcess.svgWidth = "700";
				paramProcess.svgHeight = "200";
				paramProcess.error = true;
			}
			catch (Exception localException4)
			{
				localException4.printStackTrace();
				DfLogger.error(this," :: transformProcessDiagram : Exception >> "+localException3.getMessage(), null, localException3);
			}
		}
		DfLogger.info(this," :: transformProcessDiagram : paramProcess : "+paramProcess, null,null);
		return paramProcess;
	}

	private static String getSvgErrorMessage(File paramFile)
	throws Exception
	{
		if (error == null)
			error = PaXMLDom4JUtil.readDocumentFromXml(paramFile);
		return error.asXML().replace("DIAGRAM_ERROR", DIAGRAM_ERROR_MSG);
	}
	private static String getSvgEmptyMessage(Process paramProcess)	throws Exception {
		paramProcess.svgWidth = "700";
		paramProcess.svgHeight = "400";
		String str = (String)DashboardEnv.getKeyValue(IdocsConstants.STR_SVG_PROCESS_DIAGRAM_FILES_LOCATION);
		if (error == null)
			empty = PaXMLDom4JUtil.readDocumentFromXml(new File(str + File.separator + STR_SVG_EMPTY_FILE));
		return empty.asXML().replace("DIAGRAM_EMPTY", DIAGRAM_EMPTY_MSG);
	}

	public static final String DIAGRAM_ERROR_MSG="The Process Diagram cannot be displayed. Please contact your system administrator.";
	public static final String DIAGRAM_EMPTY_MSG="Please select a process to view the diagram.";
	public static final String ACTIVITY_COMPLETE="Task Completed";
	public static final String ACTIVITY_FAILED="Task Failed";
	public static final String ACTIVITY_FAULT="Fault";
	public static final String SUB_PROCESS="Sub Process";
	public static final String ACTIVITY_RUNNING="Task Running";
	public static final String ACTIVITY_TIMER="Timer";
	public static final String ALERT_HIGH="High Severity Alert";
	public static final String ALERT_MED="Medium Severity Alert";
	public static final String ALERT_LOW="Low Severity Alert";
	public static final String END_DATE_TIME="End Date Time:";
	public static final String START_DATE_TIME="Start Date Time:";
	public static final String PROCESS_INVOCATION="Process Invocation";
	public static final String PERFORMER_NAME="Performer Name:";
	public static final String STR_SVG_ERROR_FILE ="svgError.svg";
	public static final String STR_SVG_EMPTY_FILE ="svgEmpty.svg";

}