package com.logicbig.example;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;

public class ScreenInfo {
    //private String id;
    //private String title;
    
    private Map<String, Object> otherInfo;

    /*public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }*/

    @JsonAnyGetter
    public Map<String, Object> getProperties(){
       return otherInfo;
    }

    @JsonAnySetter
    public void addOtherInfo(String propertyKey, Object value) {
        if (this.otherInfo == null) {
            this.otherInfo = new HashMap<>();
        }
        this.otherInfo.put(propertyKey, value);
    }

/*    @Override
    public String toString() {
        return "ScreenInfo{" +
                "id='" + id + '\'' +
                ", title='" + title + '\'' +
                ", otherInfo=" + otherInfo +
                '}';
    }*/
}