package com.SWBC.model;

import org.springframework.stereotype.Service;


@Service("brmRequest")
public class Brm_request_info {
	
	private String source;
	private String user;
	private String ruleVersion;
	private String tid;
	private String loan_no;
	private String loan_suffix;
	private String cov_type;
	private String acc_no;
	private String transType;
	private String enableLookup;
	private boolean pCHRerouteFlag;
	private String singleAPITrec;
	
	public String getSingleAPITrec() {
		return singleAPITrec;
	}
	public void setSingleAPITrec(String singleAPITrec) {
		this.singleAPITrec = singleAPITrec;
	}
	public boolean ispCHRerouteFlag() {
		return pCHRerouteFlag;
	}
	public void setpCHRerouteFlag(boolean pCHRerouteFlag) {
		this.pCHRerouteFlag = pCHRerouteFlag;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getRuleVersion() {
		return ruleVersion;
	}
	public void setRuleVersion(String ruleVersion) {
		this.ruleVersion = ruleVersion;
	}
	public String getTid() {
		return tid;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public String getLoan_no() {
		return loan_no;
	}
	public void setLoan_no(String loan_no) {
		this.loan_no = loan_no;
	}
	public String getLoan_suffix() {
		return loan_suffix;
	}
	public void setLoan_suffix(String loan_suffix) {
		this.loan_suffix = loan_suffix;
	}
	public String getCov_type() {
		return cov_type;
	}
	public void setCov_type(String cov_type) {
		this.cov_type = cov_type;
	}
	public String getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(String acc_no) {
		this.acc_no = acc_no;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public String getEnableLookup() {
		return enableLookup;
	}
	public void setEnableLookup(String enableLookup) {
		this.enableLookup = enableLookup;
	}

}
