/**
* This precondition class Enable or Disables the LinkToGHG menu item 
* based on resource entity ID
* ######################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* ######################################################################
*  Gangadhar Reddy.V    02/15/2011	     1.0          Created
* ######################################################################
*/
package org.ifc.idocs.crrpsr.actions;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.main.MainEx;
import org.ifc.idocs.utils.IdocsConstants;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.action.IActionPrecondition;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

public class LinkToGHGEmissionPreCondition implements IActionPrecondition{

	public String[] getRequiredParams() {
		return (new String[] { "objectId" });
	}

	/**
	 * This method enables/disables the GHG action based on the current context.
	 */
	public boolean queryExecute(String strAction, IConfigElement config,
			ArgumentList arg, Context context, Component component) {
		boolean bExecute = false;
		String strObjectType = arg.get("type");
		String sourceName = MainEx.getSourceName(component.getPageContext().getSession());
		if (strObjectType !=null && strObjectType.trim().length()>0 
				&& strObjectType.equalsIgnoreCase(IdocsConstants.PROJ_DOC_TYPE)== true 
				&& sourceName != null && sourceName.trim().length()>0 
				&& sourceName.equals(IDocsConstants.MSG_GHG_ENTITY_ID)){
				return true;
		}
		return bExecute;
	}
}
