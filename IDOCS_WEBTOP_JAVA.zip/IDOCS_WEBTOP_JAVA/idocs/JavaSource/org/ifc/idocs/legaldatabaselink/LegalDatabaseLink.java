/**
* This is custom behavior class for legal database link provides encrypted url, 
* which launches new windows with project database link.
* 
* ##############################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* ##############################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created
* ##############################################################################
*/
package org.ifc.idocs.legaldatabaselink;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.form.Form;
import com.documentum.web.formext.component.Component;

public class LegalDatabaseLink extends Component {

	private static final String QRY_VAR_ENC_PROJECT_ID = "<ENC_PROJECT_ID>";
	private static final String LEGAL_DB_URL = "LEGAL_DB_URL";
	private static final long serialVersionUID = 1L;
    private int projectId = 0;
	public  boolean isValidFolder=false;

    public LegalDatabaseLink()
	{
	}

    /**
     * 
     */
	public void onInit(ArgumentList args){
		try {
			DfLogger.info(this, " :: onInit : "+getDfSession().getLoginUserName(), null, null);
			super.onInit(args);
			projectId=0;
			isValidFolder=false;
			String folderId=args.get("objectId");
			String folderTypeFromArg=args.get("type");
			DfLogger.error(this, " ::Folder type :  "+folderTypeFromArg,null,null);
			if(folderId.equals("0000000000000000")== false){
				String folderTypeName = IDocDocbaseAttributeTagUtility.getSysObjectAttribute(getDfSession(), folderId, IDocsConstants.MSG_R_OBJECT_TYPE);
				String strProjectId= null;
				if(folderTypeName !=null && (folderTypeName.equals(IDocsConstants.MSG_IDOCS_PROJ_FOLDER)
						|| folderTypeName.equals(IDocsConstants.MSG_IDOCS_PROJECT_DOC))){
				strProjectId=IDocDocbaseAttributeTagUtility.getSingleAttributeValue(getDfSession(), folderId, IdocsConstants.PROJ_ID, folderTypeName);;
				}
				try {
					if(strProjectId!=null && strProjectId.trim().length() > 0){
						projectId = Integer.parseInt(strProjectId);
					}else{
						projectId = 0;
					}
				} catch (Exception e) {
					// Caught all exceptions.
				}
				if(projectId != 0 )isValidFolder = true;
			}else{
				
			}
		} catch (DfException e) {
			DfLogger.error(this," :: onInit Exception >> "+e.getMessage(),null,e);
		}
	}

	public void onRender(){
		try{
			DfLogger.info(this, " :: onRender : "+getDfSession().getLoginUserName(), null, null);
	        super.onRender();
	        String url = getNewWindowUrl();
	        String title = "_blank";
	        String params = lookupString("windowparams");
	        ArgumentList clientEventArgs = new ArgumentList();
	        if(projectId!=0){
		        String ENC_PROJECT_ID = Long.toString((long)((projectId*726)-52)*394);
		        url=IdocsUtil.getIdocsConfigInfoValue(getDfSession(),LEGAL_DB_URL);
		        DfLogger.info(this, " :: Legal Database url : " +url, null, null);
		        url=url.replaceFirst(QRY_VAR_ENC_PROJECT_ID, ENC_PROJECT_ID);
	        }
	        clientEventArgs.add("url", url);
	        clientEventArgs.add("title", title);
	        clientEventArgs.add("params", params);
	        setClientEvent("newWindow", clientEventArgs);
		}catch(DfException e){
			DfLogger.error(this," :: onRender Exception >> "+e.getMessage(),null,e);
		}
    }

    public void onReturn(Control control, ArgumentList args){
		DfLogger.info(this, " :: onReturn ", null, null);
        setComponentReturn();
    }

    protected String getNewWindowUrl(){
		DfLogger.info(this, " :: getNewWindowUrl :"+Form.makeUrl(getPageContext().getRequest(), "/"), null, null);
        return Form.makeUrl(getPageContext().getRequest(), "/");
    }
    
    public boolean isFolderValid(){
    	return isValidFolder;
    }
}
