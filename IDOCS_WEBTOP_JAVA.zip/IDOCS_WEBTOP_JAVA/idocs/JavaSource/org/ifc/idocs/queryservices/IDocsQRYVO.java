package org.ifc.idocs.queryservices;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfTime;
import com.documentum.fc.common.IDfTime;
import com.documentum.web.form.control.databound.TableResultSet;

public class IDocsQRYVO {
	
	public static String NON_OPERATIONAL="Non-Operational";
	public static String INSTITUTION ="Institution";  
	public static String MANAGEMENT_AND_ADMIN="Management & Admin";
	public static String COUNTRY_DOCUMENTS="Country Documents";
	public static String ADVISORY_SERVICES="Advisory Services";
	public static String INVESTMENT_OPERATION="Investment Operations";
	public static String NON_INVESTMENT_OPERATION="Non-Investment Projects";
	
	public static final int NON_OPERATIONAL_NUMBER=1;
	public static final int INSTITUTION_NUMBER =2;  
	public static final int MANAGEMENT_AND_ADMIN_NUMBER=3;
	public static final int COUNTRY_DOCUMENTS_NUMBER=4;
	public static final int ADVISORY_SERVICES_NUMBER=5;
	public static final int INVESTMENT_OPERATION_NUMBER=6;
	public static final int NON_INVESTMENT_OPERATION_NUMBER=7;
	
	private static String STR_FOLDER_CATEGORY="folder_category";
	private static String STR_TEMPLATE_TITLE_NAME="template_title";
	
	public static final int TOTAL_NOOF_FOLDER_CATEGORIES=7;
	
	public static HashMap<String,TableResultSet> templateMapObject=new HashMap<String,TableResultSet>();
	public static HashMap<String,TableResultSet> folderMapObject=new HashMap<String,TableResultSet>();
	public static ArrayList<String []> tableDataValues=new ArrayList<String []>();
	public static ArrayList<String []> templateNameTableDataValues=new ArrayList<String []>();
	private static IDfTime pastDate = null;
	private static final long timeInterval=43200000;//12 hours
	public static long customTimeInterval=0;
	public static int noOfTemplateRecords=0;
	public static int noOfsubfolderRecords=0;
	
	/**
	 * 
	 * @param dfSession
	 */
	public synchronized static void IntiateQRYServices(IDfSession dfSession){
			intiateTemplateQRYS(dfSession);
			intiateTemplateInfoTable(dfSession);
	}
	/**
	 * 
	 * @param folderCategory
	 * @param dfSession
	 * @return
	 */
	public static TableResultSet getFolderTypeResultSet(String folderCategory, IDfSession dfSession){
    	try{
	    	if(canUpdatetheQueryServices()){
	    		IntiateQRYServices(dfSession);
	    		return folderMapObject.get(folderCategory);    		
	    	}else{
	    		return folderMapObject.get(folderCategory);  
	    	}
    	}catch (Exception e) {
    		DfLogger.error(IDocsQRYVO.class," <<Exception>> : getFolderTypeResultSet :"+e.getMessage(), null, e);
		}
		return null;
    }
	
	public static  TableResultSet getTemplateNamesResultSet(String folderCategory, IDfSession dfSession){
		try{
	    	if(canUpdatetheQueryServices()){
	    		IntiateQRYServices(dfSession);
	    		return templateMapObject.get(folderCategory);    		
	    	}else{
	    		return templateMapObject.get(folderCategory);  
	    	}
    	}catch (Exception e) {
    		DfLogger.error(IDocsQRYVO.class," <<Exception>> : getTemplateNamesResultSet :"+e.getMessage(), null, e);
		}
		return null;
	}
	
	/**
	 * 
	 * @param dfSession
	 */
	public static void intiateTemplateInfoTable(IDfSession dfSession){
		DOCTYPE_INFO_QRY=IdocsUtil.getMessage("DOCTYPE_INFO_QRY");
		IDfCollection dfCollection= null;
		noOfsubfolderRecords=0;
		try {
			dfCollection=IdocsUtil.executeQuery(dfSession, DOCTYPE_INFO_QRY, IDfQuery.DF_READ_QUERY);
			while(dfCollection.next()){
				noOfsubfolderRecords++;
				String [] rowValues= new String[TEMPLATE_INFO_QRY_COLUMNS_NUMBER];
				rowValues[doc_type_code]=dfCollection.getString(ATTR_DOC_TYPE_CODE);
				rowValues[doc_type_name]=dfCollection.getString(ATTR_DOC_TYPE_NUMBER);
				rowValues[subfolder_title]=dfCollection.getString(ATTR_SUB_FOLDER_TITLE);
				rowValues[is_active]=dfCollection.getString(ATTR_IS_ACTIVE);
				rowValues[folder_category]=dfCollection.getString(ATTR_FOLDER_CATEGORY);
				rowValues[datetime_stamp]=dfCollection.getString(ATTR_DATE_TIME_STAMP);
				rowValues[user_id]=dfCollection.getString(ATTR_USER_ID);
				tableDataValues.add(rowValues);
			}
		} catch (DfException e) {
			DfLogger.error(IDocsQRYVO.class," <<Exception>> "+e.getMessage(), null, e);
		}finally{
			if(dfCollection !=null){
				try {
					dfCollection.close();
				} catch (DfException e) {
					DfLogger.error(IDocsQRYVO.class," <<Exception>> "+e.getMessage(), null, e);
				}
			}
		}
	}
	
	public static ArrayList<String []> getTemplateInfoTableData(IDfSession dfSession){
		if(canUpdatetheQueryServices()){
			IntiateQRYServices(dfSession);
			return tableDataValues;
    		}else{
    			return tableDataValues;
    			}
		}

	/**
	 * 
	 * @return
	 */
	public static void intiateTemplateQRYS(IDfSession dfSession){
		TEMPLATE_NAME_QUERY=IdocsUtil.getMessage("TEMPLATE_NAME_QUERY");
		noOfTemplateRecords=0;
		ArrayList<TableResultSet> typeResultSet=new ArrayList<TableResultSet>();
		for (int i = 0; i < TOTAL_NOOF_FOLDER_CATEGORIES; i++) {
			typeResultSet.add(new TableResultSet(new String[] {STR_TEMPLATE_TITLE_NAME})); 
		}
		IDfCollection dfCollection= null;
		try {
			dfCollection=IdocsUtil.executeQuery(dfSession, TEMPLATE_NAME_QUERY, IDfQuery.DF_READ_QUERY);
			
			while(dfCollection.next()){
				noOfTemplateRecords++;
				String [] rowValues= new String[TEMPLATE_DETAILS_ATTR_COUNT];
					rowValues[template_details_template_title]=dfCollection.getString(ATTR_TEMPLATE_TITLE);
					rowValues[template_details_folder_category]=dfCollection.getString(ATTR_FOLDER_CATEGORY);
					rowValues[template_details_template_code]=dfCollection.getString(ATTR_TEMPLATE_CODE);
					templateNameTableDataValues.add(rowValues);
				
				String attrValue = dfCollection.getString(STR_TEMPLATE_TITLE_NAME);
				switch(getFolderCategoryNumber(dfCollection.getString(STR_FOLDER_CATEGORY))){
				case NON_OPERATIONAL_NUMBER			:{
														typeResultSet.get(NON_OPERATIONAL_NUMBER-1).add(new String[] {attrValue});
													 } break;
				case INSTITUTION_NUMBER				:{
														typeResultSet.get(INSTITUTION_NUMBER-1).add(new String[] {attrValue});
				 						  			 } break;
				case MANAGEMENT_AND_ADMIN_NUMBER    :{
														typeResultSet.get(MANAGEMENT_AND_ADMIN_NUMBER-1).add(new String[] {attrValue});
													  } break;
				case COUNTRY_DOCUMENTS_NUMBER		:{
														typeResultSet.get(COUNTRY_DOCUMENTS_NUMBER-1).add(new String[] {attrValue});
													 }break;
				case ADVISORY_SERVICES_NUMBER		:{
														typeResultSet.get(ADVISORY_SERVICES_NUMBER-1).add(new String[] {attrValue});
				 									 }break;
				case INVESTMENT_OPERATION_NUMBER    :{
														typeResultSet.get(INVESTMENT_OPERATION_NUMBER-1).add(new String[] {attrValue});
													 }break;
				case NON_INVESTMENT_OPERATION_NUMBER:{
														typeResultSet.get(NON_INVESTMENT_OPERATION_NUMBER-1).add(new String[] {attrValue});
													  }break;
				default								:{
														DfLogger.info(IDocsQRYVO.class, "<<No such mactching found>>", null, null);	
												 	 }
			  }//switch End
			}//Collection end
		} catch (DfException e) {
			DfLogger.error(IDocsQRYVO.class," <<Exception>> "+e.getMessage(), null, e);
		}finally{
			if(dfCollection !=null){
				try {
					dfCollection.close();
				} catch (DfException e) {
					DfLogger.error(IDocsQRYVO.class," <<Exception>> "+e.getMessage(), null, e);
				}
			}
		}
		
		templateMapObject.put(NON_OPERATIONAL,typeResultSet.get(NON_OPERATIONAL_NUMBER-1));
		templateMapObject.put(INSTITUTION,typeResultSet.get(INSTITUTION_NUMBER-1));		
		templateMapObject.put(MANAGEMENT_AND_ADMIN,typeResultSet.get(MANAGEMENT_AND_ADMIN_NUMBER-1));		
		templateMapObject.put(COUNTRY_DOCUMENTS,typeResultSet.get(COUNTRY_DOCUMENTS_NUMBER-1));		
		templateMapObject.put(ADVISORY_SERVICES,typeResultSet.get(ADVISORY_SERVICES_NUMBER-1));		
		templateMapObject.put(INVESTMENT_OPERATION,typeResultSet.get(INVESTMENT_OPERATION_NUMBER-1));
		templateMapObject.put(NON_INVESTMENT_OPERATION,typeResultSet.get(NON_INVESTMENT_OPERATION_NUMBER-1));
		pastDate = new DfTime(new Date()); 
	}

	public static boolean canUpdatetheQueryServices(){
    	if(customTimeInterval != 0){
    		IDfTime futureDate = new DfTime(new Date());
    		if((futureDate.getDate().getTime() - pastDate.getDate().getTime()) > customTimeInterval){
		    	return true;
		    }else{
		    	return false;
		    }
    	}else if(pastDate != null){
	    	IDfTime futureDate = new DfTime(new Date());
	    	long timedifference=futureDate.getDate().getTime() - pastDate.getDate().getTime();
		    if(timedifference > timeInterval){
		    	return true;
		    }else{
		    	DfLogger.info(IDocsQRYVO.class, "TimeStamp check for Queries ::Queries will execute after :: "+(timeInterval-timedifference)/1000+"  Seconds", null, null);
		    	return false;
		    }
	    }else{
	    	return true;
	    }
    }

	public static int getFolderCategoryNumber(String folderCategory){
		  int faloderCategoryNumber=0;
		  if(folderCategory.equals(NON_OPERATIONAL)){
			  faloderCategoryNumber=NON_OPERATIONAL_NUMBER;
		  }else if(folderCategory.equals(INSTITUTION)){
			  faloderCategoryNumber= INSTITUTION_NUMBER;
		  }else if(folderCategory.equals(MANAGEMENT_AND_ADMIN)){
			  faloderCategoryNumber= MANAGEMENT_AND_ADMIN_NUMBER;
		  }else if(folderCategory.equals(COUNTRY_DOCUMENTS)){
			  faloderCategoryNumber=COUNTRY_DOCUMENTS_NUMBER;
		  }else if(folderCategory.equals(ADVISORY_SERVICES)){
			  faloderCategoryNumber= ADVISORY_SERVICES_NUMBER;
		  }else if(folderCategory.equals(INVESTMENT_OPERATION)){
			  faloderCategoryNumber= INVESTMENT_OPERATION_NUMBER;
		  }else if(folderCategory.equals(NON_INVESTMENT_OPERATION)){
			  faloderCategoryNumber= NON_INVESTMENT_OPERATION_NUMBER;
		  }
		  return faloderCategoryNumber;
	}
  
	
	private static String ATTR_DOC_TYPE_CODE="doc_type_code";
    private static String ATTR_DOC_TYPE_NUMBER="doc_type_name";
    private static String ATTR_SUB_FOLDER_TITLE="subfolder_title";
    private static String ATTR_IS_ACTIVE="is_active";
    private static String ATTR_FOLDER_CATEGORY="folder_category";
    private static String ATTR_DATE_TIME_STAMP="datetime_stamp";
    private static String ATTR_USER_ID="user_id";
    
    private static String ATTR_TEMPLATE_TITLE="template_title";
    private static String ATTR_TEMPLATE_CODE="template_code";
    
    
    
	
    private static int doc_type_code =0;
    private static int doc_type_name =1;
    private static int subfolder_title =2;
    private static int is_active =3;
    private static int folder_category =4;
    private static int datetime_stamp=5;
    private static int user_id=6;
	
    private static int TEMPLATE_DETAILS_ATTR_COUNT=3;
    
    
    private static int template_details_template_title =0;
    private static int template_details_folder_category=1;
    private static int template_details_template_code =2;
    
	private static String TEMPLATE_NAME_QUERY="";
	private static String DOCTYPE_INFO_QRY="";
	public  static final int TEMPLATE_INFO_QRY_COLUMNS_NUMBER=7;
	public String docTypeInfoTable_attributes[] = {"doc_type_code",
			"doc_type_name", "subfolder_title",
			"is_active", "folder_category", "datetime_stamp",
			"user_id"};
	
}
