package com.swbc.letters.commercial.migrate.utils;

import java.io.IOException;

import java.util.HashMap;
import java.util.UUID;

import javax.json.Json;
import javax.json.JsonObject;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.Logger;
import org.json.JSONWriter;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonWriter;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.AMQP.BasicProperties;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.swbc.letters.commercial.migrate.constants.MigrateCommercialConstants;
import com.swbc.letters.commercial.migrate.service.bus.appConfig.ServBusApplicationConfig;

/**
 * @author hemanth.muppalanara
 *
 */

public class ServiceBusUtil {
	
  private static Logger log = Logger.getLogger(ServiceBusUtil.class);
  
  private HashMap<String, Object> values;
  private static String userid;
  private static String password;
  private static String hostname;
  private static String hostport;
  private static String virtualhost;
  private static String exchangename;
  private static String contenttype;
  private static String commandtype;
  private static final String CONFIG_USER = "user_id";
  private static final String CONFIG_PASSWORD = "password";
  private static final String CONFIG_HOST_NAME = "host_name";
  private static final String CONFIG_HOST_PORT = "host_port";
  private static final String CONFIG_VIRTUAL_HOST = "virtual_host";
  private static final String CONFIG_EXCHANGE_NAME = "exchange_name";
  private static final String CONFIG_CONTENT_TYPE = "content_type";
  private static final String CONFIG_COMMAND_TYPE = "command_type";
  private static final String JSON_BIPP_OBJECT = "BIPP";
  private static final String JSON_BIPO_OBJECT = "BIPO";
  private static final String JSON_PDPO_OBJECT = "PDPO";
  private static final String JSON_UMPP_OBJECT = "UMPP";
  private static final String JSON_UMPO_OBJECT = "UMPO";
  private static final String JSON_NAI_OBJECT = "NAI";
  private static final String JSON_AFTER_OBJECT = "After";
  private static final String JSON_BEFORE_OBJECT = "Before";
  private static final String JSON_COMPANY = "Company";
  private static final String JSON_AGENCY = "Agency";
  private static final String JSON_POLICY_NUMBER = "PolicyNumber";
  private static final String JSON_INSURANCE_TYPE = "InsuranceType";
  private static final String JSON_EFFECTIVE_DATE = "EffectiveDate";
  private static final String JSON_EXPIRATION_DATE = "ExpirationDate";
  private static final String JSON_CANCEL_DATE = "CancelDate";
  private static final String JSON_REINSTATE_DATE = "ReinstateDate";
  private static final String JSON_COMPREHENSIVE_DEDUCTIBLE = "ComprehensiveDeductible";
  private static final String JSON_COLLISION_DEDUCTIBLE = "CollisionDeductible";
  private static final String JSON_LIENHOLDER_NAME = "LienHolderName";
  private static final String JSON_AGENT_NAME = "AgentName";
  private static final String JSON_AGENT_ADDRESS_1 = "AgentAddress1";
  private static final String JSON_AGENT_ADDRESS_2 = "AgentAddress2";
  private static final String JSON_AGENT_CITY = "Agent_City";
  private static final String JSON_AGENT_STATE = "AgentState";
  private static final String JSON_AGENT_ZIP = "AgentZip";
  private static final String JSON_AGENT_PHONE = "AgentPhone";
  private static final String JSON_AGENT_FAX = "AgentFax";
  private static final String JSON_IMPAIR_CODE = "ImpairCode";
  private static final String JSON_VALUE = "Value";
  private static final String JSON_ACTION = "Action";
  private static final String JSON_ACCOUNT = "Account";
  private static final String JSON_LOAN_NUMBER = "LoanNumber";
  private static final String JSON_LOAN_SUFFIX = "LoanSuffix";
  private static final String JSON_TRANSACTION_ID = "TransactionId";
  private static final String JSON_TRANSACTION_DATE = "TransactionDate";
  private static final String JSON_REFUND_Q_ANALYSIS = "RefundQAnalysis";
  private static final String JSON_VSI_POLICY_NUMBER = "VsiPolicyNumber";
  private static final String JSON_UPDATE_LIABILITY = "UpdateLiability";
  private static final String JSON_ADDITIONAL_COMMENTS = "AdditionalComments";
  private static final String JSON_IVR_NUMBER = "IvrNumber";
  private static final String JSON_IVR_DATE_TIME = "IvrDateAndTime";
  private static final String JSON_OPERATION_ID = "OperationId";
  private static final String JSON_REFUND_DATE = "RefundDate";
  private static final String JSON_ECHO = "Echo";
  private static final String ATTR_A_COMPANY = "a_company";
  private static final String ATTR_A_POLICY_NUMBER = "a_policy_no";
  private static final String ATTR_A_INSURANCE_TYPE = "a_insur_type";
  private static final String ATTR_A_EFFECTIVE_DATE = "a_begin_date";
  private static final String ATTR_A_EXPIRATION_DATE = "a_end_date";
  private static final String ATTR_A_CANCEL_DATE = "a_cancel_date";
  private static final String ATTR_A_REINSTATE_DATE = "a_rein_eff_date";
  private static final String ATTR_A_COMPREHENSIVE_DEDUCTIBLE = "a_comp_deduct";
  private static final String ATTR_A_COLLISION_DEDUCTIBLE = "a_coll_deduct";
  private static final String ATTR_A_LIENHOLDER_NAME = "a_lienholder_name";
  private static final String ATTR_A_AGENT_NAME = "a_agent_name";
  private static final String ATTR_A_AGENT_ADDRESS_1 = "a_agent_address_1";
  private static final String ATTR_A_AGENT_ADDRESS_2 = "a_agent_address_2";
  private static final String ATTR_A_AGENT_CITY = "a_agent_city";
  private static final String ATTR_A_AGENT_STATE = "a_agent_state";
  private static final String ATTR_A_AGENT_ZIP = "a_agent_zip";
  private static final String ATTR_A_AGENT_PHONE = "a_agent_phone";
  private static final String ATTR_A_AGENT_FAX = "a_agent_fax";
  private static final String ATTR_A_IMPAIR_CODE = "a_impairment_code";
  private static final String ATTR_A_BIPP_IMPAIR_CODE = "a_bipp_impairment";
  private static final String ATTR_A_BIPO_IMPAIR_CODE = "a_bipo_impairment";
  private static final String ATTR_A_PDPO_IMPAIR_CODE = "a_pdpo_impairment";
  private static final String ATTR_A_UMPP_IMPAIR_CODE = "a_umpp_impairment";
  private static final String ATTR_A_UMPO_IMPAIR_CODE = "a_umpo_impairment";
  private static final String ATTR_A_NAI_IMPAIR_CODE = "a_nai_impairment";
  private static final String ATTR_B_COMPANY = "b_company";
  private static final String ATTR_B_POLICY_NUMBER = "b_policy_no";
  private static final String ATTR_B_INSURANCE_TYPE = "b_insur_type";
  private static final String ATTR_B_EFFECTIVE_DATE = "b_begin_date";
  private static final String ATTR_B_EXPIRATION_DATE = "b_end_date";
  private static final String ATTR_B_CANCEL_DATE = "b_cancel_date";
  private static final String ATTR_B_REINSTATE_DATE = "b_rein_eff_date";
  private static final String ATTR_B_COMPREHENSIVE_DEDUCTIBLE = "b_comp_deduct";
  private static final String ATTR_B_COLLISION_DEDUCTIBLE = "b_coll_deduct";
  private static final String ATTR_B_LIENHOLDER_NAME = "b_lienholder_name";
  private static final String ATTR_B_AGENT_NAME = "b_agent_name";
  private static final String ATTR_B_AGENT_ADDRESS_1 = "b_agent_address_1";
  private static final String ATTR_B_AGENT_ADDRESS_2 = "b_agent_address_2";
  private static final String ATTR_B_AGENT_CITY = "b_agent_city";
  private static final String ATTR_B_AGENT_STATE = "b_agent_state";
  private static final String ATTR_B_AGENT_ZIP = "b_agent_zip";
  private static final String ATTR_B_AGENT_PHONE = "b_agent_phone";
  private static final String ATTR_B_AGENT_FAX = "b_agent_fax";
  private static final String ATTR_B_IMPAIR_CODE = "b_impairment_code";
  private static final String ATTR_B_BIPP_IMPAIR_CODE = "b_bipp_impairment";
  private static final String ATTR_B_BIPO_IMPAIR_CODE = "b_bipo_impairment";
  private static final String ATTR_B_PDPO_IMPAIR_CODE = "b_pdpo_impairment";
  private static final String ATTR_B_UMPP_IMPAIR_CODE = "b_umpp_impairment";
  private static final String ATTR_B_UMPO_IMPAIR_CODE = "b_umpo_impairment";
  private static final String ATTR_B_NAI_IMPAIR_CODE = "b_nai_impairment";
  private static final String ATTR_B_BODILY_INJURY_PER_PERSON = "b_bodily_injury_per_person";
  private static final String ATTR_B_BODILY_INJURY_PER_OCC = "b_bodily_injury_per_occ";
  private static final String ATTR_B_PROPERTY_DAMAGE_PER_OCC = "b_property_damage_per_occ";
  private static final String ATTR_B_UNINS_MOTOR_PER_OCC = "b_unins_motor_per_occ";
  private static final String ATTR_B_UNINS_MOTOR_PER_PERSON = "b_unins_motor_per_person";
  private static final String ATTR_B_ADD_INSURED = "b_add_insured";
  private static final String ATTR_A_BODILY_INJURY_PER_PERSON = "a_bodily_injury_per_person";
  private static final String ATTR_A_BODILY_INJURY_PER_OCC = "a_bodily_injury_per_occ";
  private static final String ATTR_A_PROPERTY_DAMAGE_PER_OCC = "a_property_damage_per_occ";
  private static final String ATTR_A_UNINS_MOTOR_PER_OCC = "a_unins_motor_per_occ";
  private static final String ATTR_A_UNINS_MOTOR_PER_PERSON = "a_unins_motor_per_person";
  private static final String ATTR_A_ADD_INSURED = "a_add_insured";
  private static final String ATTR_ACTION = "as400_action";
  private static final String ATTR_AGENCY_NUMBER = "agency_number";
  private static final String ATTR_ACCOUNT_NUMBER = "account_number";
  private static final String ATTR_LOAN_NUMBER = "loan_no";
  private static final String ATTR_LOAN_SUFFIX = "loan_suffix";
  private static final String ATTR_TRANSACTION_ID = "transaction_id";
  private static final String ATTR_TRANSACTION_DATE = "received_date";
  private static final String ATTR_REFUND_Q_ANALYSIS = "refund_q_analysis_flag";
  private static final String ATTR_POLICY_NUMBER = "fp_policy_no";
  private static final String ATTR_UPDATE_LIABILITY = "update_liability_insurance";
  private static final String ATTR_COMMENTS_1 = "loan_comments_1";
  private static final String ATTR_COMMENTS_2 = "loan_comments_2";
  private static final String ATTR_COMMENTS_3 = "loan_comments_3";
  private static final String ATTR_COMMENTS_4 = "loan_comments_4";
  private static final String ATTR_COMMENTS_5 = "loan_comments_5";
  private static final String ATTR_IVR_NUMBER = "call_tag";
  private static final String ATTR_IVR_DATE_TIME = "call_time";
  private static final String ATTR_OPERATION_ID = "operator_id";
  private static final String ATTR_REFUND_DATE = "refund_date";

  
  public static void printJson(String jsonStr){
	 
	  Gson gson = new GsonBuilder().setPrettyPrinting().create();
	    String prettyJsonString = gson.toJson(new JsonParser().parse(jsonStr));
	    
	    log.debug(prettyJsonString);
	  
  }
  
  public static ServBusApplicationConfig getQueueConfiguration(IDfSession mSession,PropertyReader propConfig) throws DfException
  {
	  
	ServBusApplicationConfig mqAppConfig=new ServBusApplicationConfig();
   // IDfSysObject queueconfig = (IDfSysObject)mSession.getObjectByQualification("itk_mq_config where object_name = 'RabbitMQ Config'");
    mqAppConfig.setUserid(propConfig.getProperty(MigrateCommercialConstants.SRV_BUS_USER_ID).toString());
    mqAppConfig.setPassword(propConfig.getProperty(MigrateCommercialConstants.SRV_BUS_PASSWORD).toString());
    mqAppConfig.setHostname(propConfig.getProperty(MigrateCommercialConstants.SRV_BUS_HOST_NAME).toString());
    mqAppConfig.setHostport(propConfig.getProperty(MigrateCommercialConstants.SRV_BUS_HOST_PORT).toString());
    mqAppConfig.setVirtualhost(propConfig.getProperty(MigrateCommercialConstants.SRV_BUS_VIRTUAL_HOST).toString());
    mqAppConfig.setContenttype(propConfig.getProperty(MigrateCommercialConstants.SRV_BUS_CONTENT_TYPE).toString());
    mqAppConfig.setExchangename(propConfig.getProperty(MigrateCommercialConstants.SRV_BUS_EXCHANGE_NAME).toString());
    mqAppConfig.setCommandtype(propConfig.getProperty(MigrateCommercialConstants.SRV_BUS_COMMAND_TYPE).toString());
    
    return mqAppConfig;
    
  }
  
  
  public static Channel openConnectionChannel(ServBusApplicationConfig mqAppConfig) throws IOException {

	   ConnectionFactory factory = new ConnectionFactory();
	    
	    factory.setUsername(mqAppConfig.getUserid());
	    factory.setPassword(mqAppConfig.getPassword());
	    factory.setVirtualHost(mqAppConfig.getVirtualhost());
	    factory.setHost(mqAppConfig.getHostname());
	    factory.setPort(Integer.parseInt(mqAppConfig.getHostport()));
	    Connection connection = factory.newConnection();
	    Channel channel = connection.createChannel();
	    
	    return channel;
	  
  }
  
  public static void publishMessage(Channel channel,ServBusApplicationConfig mqAppConfig,String returnMailRecord) throws IOException,Exception {

	  //String uuid=java.util.UUID.randomUUID().toString();
	  //log.debug("Serv Bus UUID : "+uuid);
	  
	  AMQP.BasicProperties basicproperties = new AMQP.BasicProperties.Builder()
	  .type(mqAppConfig.getCommandtype())
	  .messageId(java.util.UUID.randomUUID().toString())
	  .contentType(mqAppConfig.getContenttype()).build();

	  channel.basicPublish(mqAppConfig.getExchangename(), "", basicproperties, returnMailRecord.getBytes());
	  
/*	  try{
		  
		  String uuid=java.util.UUID.randomUUID().toString();
		  
	  BasicProperties basicproperties = new AMQP.BasicProperties.Builder()
      .type(mqAppConfig.getCommandtype())
      .messageId(uuid)
      .contentType(mqAppConfig.getContenttype()).build();

	  channel.basicPublish(mqAppConfig.getExchangename(), "", basicproperties, returnMailRecord.getBytes());
	  log.debug("uuid : "+uuid);
	  
	  }catch(Throwable t){                      
          
		  log.error("AS400Action...Exception caught while attempting to establish service buss comm channel: " + t.getMessage());
	  } */


}
  


  
  	public static String buildReturnMailRecord(IDfSysObject returnMailobject,PropertyReader propertiesConfiguration) throws DfException {
	  JsonObject model = 
			
					  Json.createObjectBuilder()
					  .add("TransactionId", returnMailobject.getString("transaction_id"))
						.add("Data",
								Json.createObjectBuilder()
										.add("BusinessType", returnMailobject.getString("business_type"))
										.add("Document", "")
										.add("TransactionDate", returnMailobject.getString("transaction_date"))
										.add("AgencyNumber", returnMailobject.getString("agency_number"))
										.add("AccountNumber", returnMailobject.getString("account_number"))
										.add("LoanNumber",returnMailobject.getString("loan_number"))
										.add("LoanSuffix", returnMailobject.getString("loan_suffix"))
										.add("ClientProperty", returnMailobject.getString("client_property"))
										.add("Building", returnMailobject.getString("building"))
										.add("Sub", returnMailobject.getString("sub"))
										.add("CoverageType", returnMailobject.getString("coverage_type"))
										.add("SequenceNumber", returnMailobject.getString("sequence_number"))
										.add("LetterCode", returnMailobject.getString("letter_code"))
										.add("DocCreationDate", returnMailobject.getString("doc_creation_date"))).build();
																  
																			  
	  return model.toString();
  }
  
  public static void closeChannel(Channel channel) throws IOException {
	  
	  
		if (channel!=null && channel.isOpen()) {

			log.debug("Closing MQ Channel");
			channel.close();
			channel.getConnection().close();

		}
	  
  }
  
}
