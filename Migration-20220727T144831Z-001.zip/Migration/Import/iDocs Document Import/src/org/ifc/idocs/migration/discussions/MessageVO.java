package org.ifc.idocs.migration.discussions;
/**
 * GetDiscussionDocs - Discussion documents would be uploaded. 
 * @author HAnuganti
 * 
 * #############################################################################################
 * Author		            DateofChange	 Version	  ModificationHistory
 * ###########################################################################################
 * Hemachandra Anuganti 
 * ###########################################################################################
 * 
 */
public class MessageVO {
	private  String messageId = "";
	private  String bodyValue = "";
	private  String cicValue = "";
	private  String domdocVersion = "";
	private  String from = "";
	private  String subject = "";
	private  String parent = "";
	private  String createdDate = "";
		
	
	public  String getCicValue() {
		return cicValue;
	}
	public  void setCicValue(String cicValue) {
		this.cicValue = cicValue;
	}
	public  String getDomdocVersion() {
		return domdocVersion;
	}
	public  void setDomdocVersion(String domdocVersion) {
		this.domdocVersion = domdocVersion;
	}
	public  String getFrom() {
		return from;
	}
	public  void setFrom(String from) {
		this.from = from;
	}
	public  String getSubject() {
		return subject;
	}
	public  void setSubject(String subject) {
		this.subject = subject;
	}
	public  String getParent() {
		return parent;
	}
	public  void setParent(String parent) {
		this.parent = parent;
	}
	public  String getCreatedDate() {
		return createdDate;
	}
	public  void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	
	public  void setMessageId(String messageId) {
		this.messageId = messageId;
	}
	public  String getMessageId() {
		return messageId;
	}
	public  void setBodyValue(String bodyValue) {
		this.bodyValue = bodyValue;
	}
	public  String getBodyValue() {
		return bodyValue;
	}	
}
