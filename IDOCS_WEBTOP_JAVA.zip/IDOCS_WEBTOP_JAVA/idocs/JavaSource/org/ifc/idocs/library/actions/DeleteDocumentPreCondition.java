package org.ifc.idocs.library.actions;


import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.action.IActionPrecondition;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

public class DeleteDocumentPreCondition implements IActionPrecondition  {

	IDfDocument newDoc = null;
	
	//private static Properties idocsProperties = new Properties();
	
	String strObjectId="";
	String strObjectType = "";
	String strObjectName ="";
	String strDocState ="";
	String strOwnerName ="";
	String m_lockOwner="";
	String isWorkflowRequired ="";
	String strTemplateTitle = "";
	String currentSecurityClassificationCode="";
	
	/**
	 * 
	 */
	public String[] getRequiredParams() {
		DfLogger.info(this,"::  getRequiredParameters : " , null, null);
		return (new String[] {"objectId"});
	}

	/**
	 * 
	 */
	public boolean queryExecute(String strAction, IConfigElement config,ArgumentList arg, Context context, Component component) {
		try{
			
			 strObjectId = arg.get("objectId");			
			 getRequiredAttributes(component,strObjectId);

			 String strObjectPermit = arg.get("permit");
			 DfLogger.info(this,":: CHANGE PERMIT Id:"+ strObjectId + " ::Type: " + strObjectType + " ::Permit:" + strObjectPermit , null, null);
			
			 DfLogger.info(this,"::  Document State : " + strDocState, null, null);
			/** If the document is country allow user to edit the permissions  */
			 if(strObjectType!=null && strObjectType.trim().length() > 0 
						&& strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_COUNTRY_DOC)){
					return true;
			 }
			/** If the document state is released nobody is allowed to modify the ACL */
			if( strDocState != null && strDocState.equalsIgnoreCase(IdocsConstants.DOC_STATE_RELEASED)== true ){
				return false;
			}
			/** For non 'Released' Documents owners are allowed to edit the ACl */
			if(strOwnerName!=null && strOwnerName.equalsIgnoreCase(component.getDfSession().getLoginUserName()) == true ){
				return true;
			}
			/** For non 'Released' documents only specific users are allowed to edit the ACL. */
			String projectRole = null;
			if(IDocsConstants.MSG_OFFICIAL_CODE.equals(currentSecurityClassificationCode)){
				projectRole = IdocsUtil.getMessage("PROJECT_DOCUMENT_DELETE_ROLE_O");
				projectRole = projectRole.replaceAll(",", "','");
			}else if(IDocsConstants.MSG_CONFIDENTIAL_CODE.equals(currentSecurityClassificationCode)){
				projectRole = IdocsUtil.getMessage("PROJECT_DOCUMENT_DELETE_ROLE_C");
				projectRole = projectRole.replaceAll(",", "','");
			}else if(IDocsConstants.MSG_STRICTLY_CONFIDENTIAL_CODE.equals(currentSecurityClassificationCode)){
				projectRole = IdocsUtil.getMessage("PROJECT_DOCUMENT_DELETE_ROLE_S");
				projectRole = projectRole.replaceAll(",", "','");
			}else{
				DfLogger.info(this, " :: Exception: Unknown Security Classigication Code : "+currentSecurityClassificationCode,null,null);
			}
			if(projectRole != null && projectRole.trim().length() > 0 ){
				return checkTeamMemberShip(component.getDfSession(), strObjectId, strObjectType,projectRole);				
			}else{
				if(strOwnerName!=null && strOwnerName.equalsIgnoreCase(component.getDfSession().getLoginUserName()) == true ){
					return true;
				}else{
					return false;
				}
			}
		}catch (Exception e) {
			DfLogger.info(this, " :: Exception:"+e.getMessage(),null,null);
		}
		return false;
	}

	/**
	 * 
	 * @param dfSession
	 * @param strObjectId
	 * @param strObjectType
	 * @param role
	 * @return
	 */
	private boolean checkTeamMemberShip(IDfSession dfSession,
			String strObjectId, String strObjectType,
			String role){
		boolean validated = false;
		String strInstitutionNumberOrProjectId = null;
		try{
			String strMemberRoleQry = null;
			if(strObjectType != null && strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_INSTITUTION_DOC)){
				strMemberRoleQry = IdocsUtil.getMessage("QRY_INSTITUTION_MEMBER");
				strInstitutionNumberOrProjectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(dfSession,
						strObjectId,IdocsConstants.MSG_INSTITUTION_NBR,strObjectType);
			}else if(strObjectType != null && strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_PROJECT_DOC)){
				strMemberRoleQry =IdocsUtil.getMessage("QRY_PROJ_MEMBER");
				strInstitutionNumberOrProjectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(dfSession,
						strObjectId,IdocsConstants.PROJ_ID,strObjectType);
			}
			strMemberRoleQry = strMemberRoleQry.replaceFirst("''", "'"+strInstitutionNumberOrProjectId+"'");
			strMemberRoleQry = strMemberRoleQry.replaceFirst("''", "'"+role+"'");
			strMemberRoleQry = strMemberRoleQry.replaceFirst("''", "'"+IdocsUtil.handleSingleQuote(dfSession.getLoginUserName())+"'");
			
			IDfQuery query = new DfQuery();
			query.setDQL(strMemberRoleQry);
			DfLogger.info(this, " :: validateUserAccess : Check User Role Query :"+strMemberRoleQry,null,null);
			IDfCollection coll=query.execute(dfSession,IDfQuery.DF_READ_QUERY);
			if(coll.next()){
				validated=true;
				coll.close();
			}
			if(coll != null )coll.close();
		}catch (Exception e) {
			DfLogger.info(this, " :: validateUserAccess : Exception :"+e.getMessage(),null,null);
		}
		return validated;
	}
	
	
	/**
	 * @param component
	 * @param strObjectId
	 * @throws DfException
	 */
	private void getRequiredAttributes(Component component, String strObjectId)
			throws DfException {
		IDfCollection dfCollectionMain = null;
		String mainQuery=IdocsUtil.getMessage("QRY_GET_DOC_DETAILS");
		mainQuery=mainQuery.replace(STR_REPLACE_OBJECT_ID, strObjectId);
		dfCollectionMain=IdocsUtil.executeQuery(component.getDfSession(), mainQuery, IDfQuery.DF_READ_QUERY);
		while(dfCollectionMain.next()){
			strObjectType=dfCollectionMain.getString( IDocsConstants.MSG_R_OBJECT_TYPE);
			strObjectName=dfCollectionMain.getString( IDocsConstants.MSG_OBJECT_NAME);
			strDocState=dfCollectionMain.getString( IDocsConstants.MSG_DOC_STATE);
			m_lockOwner=dfCollectionMain.getString(IdocsConstants.R_LOCK_OWNER);
		    strOwnerName = dfCollectionMain.getString(IDocsConstants.MSG_OWNER_NAME);
		    isWorkflowRequired=dfCollectionMain.getString(IDocsConstants.MSG_IS_WORKFLOW_REQUIRED);
		    currentSecurityClassificationCode = dfCollectionMain.getString(IDocsConstants.MSG_SEC_CLASSIFICATION_CODE);
		}
		if(dfCollectionMain != null)
			dfCollectionMain.close();
	}
	
	/**
	 * 
	 * @param dfSession
	 * @param projectRole
	 * @param projectId
	 * @return
	 */
	public boolean checkRoleMembership(IDfSession dfSession,String projectRole,String projectId) {
		IDfCollection coll=null;
	    boolean validated = false;
	    try {
			String rolePermissionQry = IdocsUtil.getMessage("QRY_PROJ_MEMBER");
			rolePermissionQry = rolePermissionQry.replaceFirst("''", "'"+projectId+"'");
			rolePermissionQry = rolePermissionQry.replaceFirst("''", "'"+projectRole+"'");
			rolePermissionQry = rolePermissionQry.replaceFirst("''", "'"+IdocsUtil.handleSingleQuote(dfSession.getLoginUserName())+"'");
			DfLogger.info(this, " :: validateUserAccess : projMemberQry : " + rolePermissionQry, null, null);

			IDfQuery query = new DfQuery();
			query.setDQL(rolePermissionQry);
			DfLogger.info(this, " :: validateUserAccess : Check User Role Query :"+rolePermissionQry,null,null);
			coll=query.execute(dfSession,IDfQuery.DF_READ_QUERY);
			if(coll.next()){				
				validated=true;
				coll.close();
			}
		} catch (DfException e) {
			DfLogger.error(this, " :: validateUserAccess : Exception : " + e.getMessage(), null, null);
		}
		DfLogger.error(this, " :: validateUserAccess : validated = " + validated, null, null);
		return validated;
	}

	private String STR_REPLACE_OBJECT_ID="<objectId>";
}
