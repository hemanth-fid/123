package com.SWBC.model;

import java.util.Date;
import java.util.List;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;


@Service("Trec")
public class Trec {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	private String transaction_type;
	private String policy_number;
	private Date policy_cancel_date;
	private String transaction_cov_type;
	

	//private String doc_delivery_date;
	private String loan_insurance_type;
	private String loan_policy_no;
	private Date policy_expiration_date;
	private Date transaction_document_date;
	private String escrowClient;
	private String escrowLine;
	private Date loan_doc_issue_date;
	private String loan_insurance_status;
	private Date loan_uninsured_date;
	private String PMERecord;
	private boolean exit_flag;
	private boolean loanCancelled; //CBR
	private boolean exceptionCase;
	private String FPLoan;//CBR
	private String ruleResults;
	private String transaction_id;
	private String ruleExecName;    // CBR
	// private String doc_reinstatement_date;
	private String mortgageeLoan;
	private String mortgageeTransaction;
	private String policy_cancel_reason;
	private Date reinstatement_date;
	private Date doc_cancel_date;
	private String exceptionMessage; //CBR
	private String policyDecision;
	private Date loanExpirationDate;
	private Date trec_loan_es_bill_date;
	private Date loanHistReiDate;
	private String history_doc_no; //CBR
	private Date history_tran_date; //CBR
	private String loanCompanyName;
	private String loanHistoryDualPolicy;
	private int policyNumberScore;
	private String TransactionInsurer;
	private Date loanEffectiveDate;
	private String reiFMRDateCheck;
	private Date transaction_effective_date;
	private Date transaction_expiration_date;
	private String swbc_chk;
	private int loan_es_check_no;
	private Date trec_loan_es_rcvd_date; //for ITC 8 Series ..PME Received Date
	private Date trec_loan_es_exp_date;
	private Date trec_loan_es_eff_date;
	private List<String> policyCancelReasonList;
	private List<String> transactionInsurerList;
	// Dual Policy Score
	private int dual_policy_score;
	private int PMEDayDiff;
	private int REIDayDiff;
	private long diffRcvdDate;
	private String ruleVersion;
	private Date pme_creation_date;
	//PME Current Term
	private String pme_current_term;
	private String inpParams;
	private String inpParamsLabel;
	private int transaction_pme_policy_score;
	private String transaction_pme_policy_no;
	
	private double transaction_em_cov_amt;
	private String transaction_em_flood_zone;
	private String loan_ag_spare_code_2;
	private String loan_ag_flood_zone;
	private double transaction_premium_amt;
	private double loan_pme_premium_amt;
	private String transaction_impairment_code;
	private String loan_impairment_code;
	
	private double loan_ag_coverage_amt;
	
	private Date loan_pme_effective_date;
	private Date loan_pme_expiration_date;
	private String loan_transaction_id;
	private String loanDisbursementFlag;
	private double transaction_premium_net_amt;
	
	
	private double transaction_edi_deductible_per;
	private double transaction_non_edi_deductible_per;
	private double transaction_deductible_amt;
	private double loan_escrow_premium_amt;
	
	private double loan_ag_deductible_amt;
	private double loan_ag_deductible_pct;
	
	private String transaction_naic_code;
	private String policy_type;
	private String loan_gap_line;

	private Date loan_gap_effective_date;
	private Date loan_gap_expiration_date;
	
	private int delete_counter;
	
	private String account_no;
	
	private String loanNo;
	private String transactionSuffix;
	
	private String loanVSIPolicyNumber;
	
	private String transaction_operator_id;
	
	private String es_void;
	
	
	private String loan_ag_spare_code3;
	
	
	
	
	public String getLoan_ag_spare_code3() {
		return loan_ag_spare_code3;
	}

	public void setLoan_ag_spare_code3(String loan_ag_spare_code3) {
		this.loan_ag_spare_code3 = loan_ag_spare_code3;
	}

	public String getEs_void() {
		return es_void;
	}

	public void setEs_void(String es_void) {
		this.es_void = es_void;
	}

	public String getTransaction_operator_id() {
		return transaction_operator_id;
	}

	public void setTransaction_operator_id(String transaction_operator_id) {
		this.transaction_operator_id = transaction_operator_id;
	}

	public String getLoanVSIPolicyNumber() {
		return loanVSIPolicyNumber;
	}

	public void setLoanVSIPolicyNumber(String loanVSIPolicyNumber) {
		this.loanVSIPolicyNumber = loanVSIPolicyNumber;
	}

	public String getAccount_no() {
		return account_no;
	}

	public void setAccount_no(String account_no) {
		this.account_no = account_no;
	}

	public String getLoanNo() {
		return loanNo;
	}

	public void setLoanNo(String loanNo) {
		this.loanNo = loanNo;
	}

	public String getTransactionSuffix() {
		return transactionSuffix;
	}

	public void setTransactionSuffix(String transactionSuffix) {
		this.transactionSuffix = transactionSuffix;
	}

	public String getPolicy_type() {
		return policy_type;
	}

	public int getDelete_counter() {
		return delete_counter;
	}

	public void setDelete_counter(int delete_counter) {
		this.delete_counter = delete_counter;
	}

	public void setPolicy_type(String policy_type) {
		this.policy_type = policy_type;
	}

	public String getTransaction_naic_code() {
		return transaction_naic_code;
	}

	public void setTransaction_naic_code(String transaction_naic_code) {
		this.transaction_naic_code = transaction_naic_code;
	}

	
	public Date getLoan_gap_effective_date() {
		return loan_gap_effective_date;
	}

	public void setLoan_gap_effective_date(Date loan_gap_effective_date) {
		this.loan_gap_effective_date = loan_gap_effective_date;
	}

	public Date getLoan_gap_expiration_date() {
		return loan_gap_expiration_date;
	}

	public void setLoan_gap_expiration_date(Date loan_gap_expiration_date) {
		this.loan_gap_expiration_date = loan_gap_expiration_date;
	}

	
	
		
	public String getLoan_gap_line() {
		return loan_gap_line;
	}

	public void setLoan_gap_line(String loan_gap_line) {
		this.loan_gap_line = loan_gap_line;
	}

	public String getTransaction_cov_type() {
		return transaction_cov_type;
	}

	public void setTransaction_cov_type(String transaction_cov_type) {
		this.transaction_cov_type = transaction_cov_type;
	}
	
	
	public String getLoan_ag_spare_code_2() {
		return loan_ag_spare_code_2;
	}

	public void setLoan_ag_spare_code_2(String loan_ag_spare_code_2) {
		this.loan_ag_spare_code_2 = loan_ag_spare_code_2;
	}

	public String getLoan_ag_flood_zone() {
		return loan_ag_flood_zone;
	}

	public void setLoan_ag_flood_zone(String loan_ag_flood_zone) {
		this.loan_ag_flood_zone = loan_ag_flood_zone;
	}

	public double getTransaction_em_cov_amt() {
		return transaction_em_cov_amt;
	}

	public void setTransaction_em_cov_amt(double transaction_em_cov_amt) {
		this.transaction_em_cov_amt = transaction_em_cov_amt;
	}

	public String getTransaction_em_flood_zone() {
		return transaction_em_flood_zone;
	}

	public void setTransaction_em_flood_zone(String transaction_em_flood_zone) {
		this.transaction_em_flood_zone = transaction_em_flood_zone;
	}

	public String getLoan_insurance_type() {
		return loan_insurance_type;
	}

	public void setLoan_insurance_type(String loan_insurance_type) {
		this.loan_insurance_type = loan_insurance_type;
	}

	public String getLoan_policy_no() {
		return loan_policy_no;
	}

	public void setLoan_policy_no(String loan_policy_no) {
		this.loan_policy_no = loan_policy_no;
	}

	public Date getLoan_doc_issue_date() {
		return loan_doc_issue_date;
	}

	public void setLoan_doc_issue_date(Date loan_doc_issue_date) {
		this.loan_doc_issue_date = loan_doc_issue_date;
	}

	public String getLoan_insurance_status() {
		return loan_insurance_status;
	}

	public void setLoan_insurance_status(String loan_insurance_status) {
		this.loan_insurance_status = loan_insurance_status;
	}

	public Date getLoan_uninsured_date() {
		return loan_uninsured_date;
	}

	public void setLoan_uninsured_date(Date loan_uninsured_date) {
		this.loan_uninsured_date = loan_uninsured_date;
	}

	public Date getTrec_loan_es_bill_date() {
		return trec_loan_es_bill_date;
	}

	public void setTrec_loan_es_bill_date(Date trec_loan_es_bill_date) {
		this.trec_loan_es_bill_date = trec_loan_es_bill_date;
	}

	public int getLoan_es_check_no() {
		return loan_es_check_no;
	}

	public void setLoan_es_check_no(int loan_es_check_no) {
		this.loan_es_check_no = loan_es_check_no;
	}

	public Date getTrec_loan_es_rcvd_date() {
		return trec_loan_es_rcvd_date;
	}

	public void setTrec_loan_es_rcvd_date(Date trec_loan_es_rcvd_date) {
		this.trec_loan_es_rcvd_date = trec_loan_es_rcvd_date;
	}

	public Date getTrec_loan_es_exp_date() {
		return trec_loan_es_exp_date;
	}

	public void setTrec_loan_es_exp_date(Date trec_loan_es_exp_date) {
		this.trec_loan_es_exp_date = trec_loan_es_exp_date;
	}

	public Date getTrec_loan_es_eff_date() {
		return trec_loan_es_eff_date;
	}

	public void setTrec_loan_es_eff_date(Date trec_loan_es_eff_date) {
		this.trec_loan_es_eff_date = trec_loan_es_eff_date;
	}


	
	
	
	public String getInpParams() {
		return inpParams;
	}

	public void setInpParams(String inpParams) {
		this.inpParams = inpParams;
	}

	public String getInpParamsLabel() {
		return inpParamsLabel;
	}

	public void setInpParamsLabel(String inpParamsLabel) {
		this.inpParamsLabel = inpParamsLabel;
	}

	public long getDiffRcvdDate() {
		return diffRcvdDate;
	}

	public void setDiffRcvdDate(long diffRcvdDate) {
		this.diffRcvdDate = diffRcvdDate;
	}

	public String getSwbc_chk() {
		return swbc_chk;
	}

	public void setSwbc_chk(String swbc_chk) {
		this.swbc_chk = swbc_chk;
	}

	

	public Date getLoanEffectiveDate() {
		return loanEffectiveDate;
	}

	public void setLoanEffectiveDate(Date loanEffectiveDate) {
		this.loanEffectiveDate = loanEffectiveDate;
	}

	

	public Date getTransaction_effective_date() {
		return transaction_effective_date;
	}

	public void setTransaction_effective_date(Date transaction_effective_date) {
		this.transaction_effective_date = transaction_effective_date;
	}

	public Date getTransaction_expiration_date() {
		return transaction_expiration_date;
	}

	public void setTransaction_expiration_date(Date transaction_expiration_date) {
		this.transaction_expiration_date = transaction_expiration_date;
	}

	public List<String> getPolicyCancelReasonList() {
		return policyCancelReasonList;
	}

	public void setPolicyCancelReasonList(List<String> policyCancelReasonList) {
		this.policyCancelReasonList = policyCancelReasonList;
	}

	public List<String> getTransactionInsurerList() {
		return transactionInsurerList;
	}

	public void setTransactionInsurerList(List<String> transactionInsurerList) {
		this.transactionInsurerList = transactionInsurerList;
	}

	public String getTransactionInsurer() {
		return TransactionInsurer;
	}

	public void setTransactionInsurer(String transactionInsurer) {
		TransactionInsurer = transactionInsurer;
	}

	

	

	public String getRuleVersion() {
		return ruleVersion;
	}

	public void setRuleVersion(String ruleVersion) {
		this.ruleVersion = ruleVersion;
	}

	public int getPolicyNumberScore() {
		return policyNumberScore;
	}

	public void setPolicyNumberScore(int policyNumberScore) {
		this.policyNumberScore = policyNumberScore;
	}

	public Date getTransaction_document_date() {
		return transaction_document_date;
	}

	public void setTransaction_document_date(Date transaction_document_date) {
		this.transaction_document_date = transaction_document_date;
	}

	public void setDoc_cancel_date(Date doc_cancel_date) {
		this.doc_cancel_date = doc_cancel_date;
	}

	public String getMortgageeLoan() {
		return mortgageeLoan;
	}

	public void setMortgageeLoan(String mortgageeLoan) {
		this.mortgageeLoan = mortgageeLoan;
	}

	public Date getLoanHistReiDate() {
		return loanHistReiDate;
	}

	public void setLoanHistReiDate(Date loanHistReiDate) {
		this.loanHistReiDate = loanHistReiDate;
	}



	public Date getLoanExpirationDate() {
		return loanExpirationDate;
	}

	public void setLoanExpirationDate(Date loanExpirationDate) {
		this.loanExpirationDate = loanExpirationDate;
	}

	public String getPolicyDecision() {
		return policyDecision;
	}

	public void setPolicyDecision(String policyDecision) {
		this.policyDecision = policyDecision;
	}

	public Date getPolicy_expiration_date() {
		return policy_expiration_date;
	}

	public void setPolicy_expiration_date(Date policy_expiration_date) {
		this.policy_expiration_date = policy_expiration_date;
	}

	public String getEscrowLine() {
		return escrowLine;
	}

	public void setEscrowLine(String escrowLine) {
		this.escrowLine = escrowLine;
	}



	public String getHistory_doc_no() {
		return history_doc_no;
	}

	public void setHistory_doc_no(String history_doc_no) {
		this.history_doc_no = history_doc_no;
	}

	public Date getHistory_tran_date() {
		return history_tran_date;
	}

	public void setHistory_tran_date(Date history_tran_date) {
		this.history_tran_date = history_tran_date;
	}

	public String getTransaction_type() {
		return transaction_type;
	}

	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}

	public String getPolicy_number() {
		return policy_number;
	}

	public void setPolicy_number(String policy_number) {
		this.policy_number = policy_number;
	}

	public Date getPolicy_cancel_date() {
		return policy_cancel_date;
	}

	public void setPolicy_cancel_date(Date policy_cancel_date) {
		this.policy_cancel_date = policy_cancel_date;
	}

	/*public String getDoc_delivery_date() {
		return doc_delivery_date;
	}

	public void setDoc_delivery_date(String doc_delivery_date) {
		this.doc_delivery_date = doc_delivery_date;
	}
*/


	public String getPolicy_cancel_reason() {
		return policy_cancel_reason;
	}

	public void setPolicy_cancel_reason(String policy_cancel_reason) {
		this.policy_cancel_reason = policy_cancel_reason;
	}

	public Date getReinstatement_date() {
		return reinstatement_date;
	}

	public void setReinstatement_date(Date reinstatement_date) {
		this.reinstatement_date = reinstatement_date;
	}

	public Date getDoc_cancel_date() {
		return doc_cancel_date;
	}

	public String getEscrowClient() {
		return escrowClient;
	}

	public void setEscrowClient(String escrowClient) {
		this.escrowClient = escrowClient;
	}

	public boolean isExit_flag() {
		return exit_flag;
	}

	public void setExit_flag(boolean exit_flag) {
		this.exit_flag = exit_flag;
	}

	public boolean isLoanCancelled() {
		return loanCancelled;
	}

	public void setLoanCancelled(boolean loanCancelled) {
		this.loanCancelled = loanCancelled;
	}

	public boolean isExceptionCase() {
		return exceptionCase;
	}

	public void setExceptionCase(boolean exceptionCase) {
		this.exceptionCase = exceptionCase;
	}

	public String getFPLoan() {
		return FPLoan;
	}

	public void setFPLoan(String fPLoan) {
		FPLoan = fPLoan;
	}

	public String getRuleResults() {
		return ruleResults;
	}

	public void setRuleResults(String ruleResults) {
		this.ruleResults = ruleResults;
	}

	public String getTransaction_id() {
		return transaction_id;
	}

	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}

	public String getRuleExecName() {
		return ruleExecName;
	}

	public void setRuleExecName(String ruleExecName) {
		this.ruleExecName = ruleExecName;
	}
	/*
	 * public String getDoc_reinstatement_date() { return
	 * doc_reinstatement_date; } public void setDoc_reinstatement_date(String
	 * doc_reinstatement_date) { this.doc_reinstatement_date =
	 * doc_reinstatement_date; }
	 */

	public String getMortgageeTransaction() {
		return mortgageeTransaction;
	}

	public void setMortgageeTransaction(String mortgageeTransaction) {
		this.mortgageeTransaction = mortgageeTransaction;
	}

	public String getExceptionMessage() {
		return exceptionMessage;
	}

	public void setExceptionMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}

	public String getLoanCompanyName() {
		return loanCompanyName;
	}

	public void setLoanCompanyName(String loanCompanyName) {
		this.loanCompanyName = loanCompanyName;
	}

	public JSONObject setJSONOutput(String trans_id, String transaction_type, String tran_policy_no,
			String tran_cancellation_date, String doc_issue_date, String tran_reinstatement_date,
			String tran_policy_cancel_reason, String tran_mortgagee_name, String pol_decision, String isFPLoan,
			String loan_pol_no, String loan_expiration_date, String loan_doc_issue_date, String getIs_insur_status,
			// String loan_policy_cancel_date,
			String loan_mortgagee_name, String escrowClient, String escrowLine, String ES_BILL_DATE,
			String Is_uninsured_date, String LoanCompanyName, String IS_INSUR_TYPE, String LoanHistReiDate,
			String DualHistoryLoanPolicy, int Tran_Loan_Score,String swbc_check,String es_check_no,String REIDayDiff, String PMEDateDiff,String es_eff_date, String es_exp_date,String REIFMRDateCheck,String loanEffectiveDate) {

		JSONObject record = new JSONObject();
		JSONObject transaction = new JSONObject();
		JSONObject loan = new JSONObject();

		transaction.put("Document ID", trans_id);
		transaction.put("Document Type", transaction_type);
		transaction.put("Transaction Policy Number", tran_policy_no);
		transaction.put("Transaction Cancel Date", tran_cancellation_date);
		transaction.put("Transaction Document Date", doc_issue_date);
		transaction.put("Transaction Reinstatement Date", tran_reinstatement_date);
		transaction.put("Transaction Policy Cancel Reason", tran_policy_cancel_reason);
		transaction.put("Transaction Mortgagee Name", tran_mortgagee_name);
		transaction.put("Transaction Policy Decision", pol_decision);

		loan.put("Loan Insurance Type", isFPLoan); //CBR
		loan.put("Loan Policy Number", loan_pol_no);
		loan.put("Loan Expiration Date", loan_expiration_date);
		loan.put("Loan Issue Date", loan_doc_issue_date);
		loan.put("Loan Insurance Status", getIs_insur_status);
		// loan.put("Loan Cancel Date", loan_policy_cancel_date);
		loan.put("Loan Mortgagee Name", loan_mortgagee_name);
		loan.put("Loan Escrow Client", escrowClient);
		loan.put("Loan Escrow Line", escrowLine);
		// loan.put("PME Record", pmeRecord);
		loan.put("ES_BILL_DATE", ES_BILL_DATE);
		loan.put("Loan Cancel Date", Is_uninsured_date);
		loan.put("Loan Company Name", LoanCompanyName);
		loan.put("IS_INSUR_TYPE", IS_INSUR_TYPE);
		loan.put("Loan History Reinstatement Date", LoanHistReiDate);
		loan.put("Loan History Dual Policy Number", DualHistoryLoanPolicy);
		loan.put("Transaction - Loan Policy Number Score", Tran_Loan_Score);
		loan.put("REI FMR Date Check", reiFMRDateCheck);
		loan.put("SWBC_CHECK", swbc_check);
		loan.put("ES_CHECK_NO", es_check_no);
		loan.put("PME Days Diff", PMEDateDiff);
		loan.put("REI Days Diff", REIDayDiff);
		loan.put("ES_EFF_DATE",es_eff_date);
		loan.put("ES_EXP_DATE",es_exp_date);
		loan.put("Loan Effective Date", loanEffectiveDate);
		

		record.put("Transaction Details", transaction);
		record.put("Loan Details", loan);

		/*
		 * obj.put("age", new Integer(100)); JSONArray list = new JSONArray();
		 * list.add("msg 1"); list.add("msg 2"); list.add("msg 3");
		 * 
		 * obj.put("messages", list);
		 */

		logger.debug(record.toJSONString());

		return record;
	}

	public String getPMERecord() {
		return PMERecord;
	}

	public void setPMERecord(String pMERecord) {
		PMERecord = pMERecord;
	}

	public String getLoanHistoryDualPolicy() {
		return loanHistoryDualPolicy;
	}

	public void setLoanHistoryDualPolicy(String loanHistoryDualPolicy) {
		this.loanHistoryDualPolicy = loanHistoryDualPolicy;
	}

	public int getPMEDayDiff() {
		return PMEDayDiff;
	}

	public void setPMEDayDiff(int pMEDayDiff) {
		PMEDayDiff = pMEDayDiff;
	}

	public int getREIDayDiff() {
		return REIDayDiff;
	}

	public void setREIDayDiff(int rEIDayDiff) {
		REIDayDiff = rEIDayDiff;
	}

	public String getReiFMRDateCheck() {
		return reiFMRDateCheck;
	}

	public void setReiFMRDateCheck(String reiFMRDateCheck) {
		this.reiFMRDateCheck = reiFMRDateCheck;
	}

	public int getDual_policy_score() {
		return dual_policy_score;
	}

	public void setDual_policy_score(int dual_policy_score) {
		this.dual_policy_score = dual_policy_score;
	}

	public Date getPme_creation_date() {
		return pme_creation_date;
	}

	public void setPme_creation_date(Date pme_creation_date) {
		this.pme_creation_date = pme_creation_date;
	}

	public String getPme_current_term() {
		return pme_current_term;
	}

	public void setPme_current_term(String pme_current_term) {
		this.pme_current_term = pme_current_term;
	}

	public int getTransaction_pme_policy_score() {
		return transaction_pme_policy_score;
	}

	public void setTransaction_pme_policy_score(int transaction_pme_policy_score) {
		this.transaction_pme_policy_score = transaction_pme_policy_score;
	}

	
	public double getTransaction_premium_amt() {
		return transaction_premium_amt;
	}

	public void setTransaction_premium_amt(double transaction_premium_amt) {
		this.transaction_premium_amt = transaction_premium_amt;
	}

	public String getTransaction_pme_policy_no() {
		return transaction_pme_policy_no;
	}

	public void setTransaction_pme_policy_no(String transaction_pme_policy_no) {
		this.transaction_pme_policy_no = transaction_pme_policy_no;
	}

	public String getTransaction_impairment_code() {
		return transaction_impairment_code;
	}

	public void setTransaction_impairment_code(String transaction_impairment_code) {
		this.transaction_impairment_code = transaction_impairment_code;
	}

	public String getLoan_impairment_code() {
		return loan_impairment_code;
	}

	public void setLoan_impairment_code(String loan_impairment_code) {
		this.loan_impairment_code = loan_impairment_code;
	}

	public double getLoan_pme_premium_amt() {
		return loan_pme_premium_amt;
	}

	public void setLoan_pme_premium_amt(double loan_pme_premium_amt) {
		this.loan_pme_premium_amt = loan_pme_premium_amt;
	}

	public double getLoan_ag_coverage_amt() {
		return loan_ag_coverage_amt;
	}

	public void setLoan_ag_coverage_amt(double loan_ag_coverage_amt) {
		this.loan_ag_coverage_amt = loan_ag_coverage_amt;
	}

	public Date getLoan_pme_effective_date() {
		return loan_pme_effective_date;
	}

	public void setLoan_pme_effective_date(Date loan_pme_effective_date) {
		this.loan_pme_effective_date = loan_pme_effective_date;
	}

	public Date getLoan_pme_expiration_date() {
		return loan_pme_expiration_date;
	}

	public void setLoan_pme_expiration_date(Date loan_pme_expiration_date) {
		this.loan_pme_expiration_date = loan_pme_expiration_date;
	}

	public String getLoan_transaction_id() {
		return loan_transaction_id;
	}

	public void setLoan_transaction_id(String loan_transaction_id) {
		this.loan_transaction_id = loan_transaction_id;
	}

	public String getLoanDisbursementFlag() {
		return loanDisbursementFlag;
	}

	public void setLoanDisbursementFlag(String loanDisbursementFlag) {
		this.loanDisbursementFlag = loanDisbursementFlag;
	}

	public double getTransaction_premium_net_amt() {
		return transaction_premium_net_amt;
	}

	public void setTransaction_premium_net_amt(double transaction_premium_net_amt) {
		this.transaction_premium_net_amt = transaction_premium_net_amt;
	}

	public double getTransaction_edi_deductible_per() {
		return transaction_edi_deductible_per;
	}

	public void setTransaction_edi_deductible_per(double transaction_edi_deductible_per) {
		this.transaction_edi_deductible_per = transaction_edi_deductible_per;
	}

	public double getTransaction_non_edi_deductible_per() {
		return transaction_non_edi_deductible_per;
	}

	public void setTransaction_non_edi_deductible_per(double transaction_non_edi_deductible_per) {
		this.transaction_non_edi_deductible_per = transaction_non_edi_deductible_per;
	}

	public double getTransaction_deductible_amt() {
		return transaction_deductible_amt;
	}

	public void setTransaction_deductible_amt(double transaction_deductible_amt) {
		this.transaction_deductible_amt = transaction_deductible_amt;
	}

	public double getLoan_escrow_premium_amt() {
		return loan_escrow_premium_amt;
	}

	public void setLoan_escrow_premium_amt(double loan_escrow_premium_amt) {
		this.loan_escrow_premium_amt = loan_escrow_premium_amt;
	}

	public double getLoan_ag_deductible_amt() {
		return loan_ag_deductible_amt;
	}

	public void setLoan_ag_deductible_amt(double loan_ag_deductible_amt) {
		this.loan_ag_deductible_amt = loan_ag_deductible_amt;
	}

	public double getLoan_ag_deductible_pct() {
		return loan_ag_deductible_pct;
	}

	public void setLoan_ag_deductible_pct(double loan_ag_deductible_pct) {
		this.loan_ag_deductible_pct = loan_ag_deductible_pct;
	}

}