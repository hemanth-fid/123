package org.ifc.idocs.report.export;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import lotus.domino.Database;
import lotus.domino.DateTime;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesError;
import lotus.domino.NotesException;

import org.ifc.idocs.report.ReportUtility;
import org.ifc.idocs.report.common.AppConfig;
import org.ifc.idocs.report.common.LogHelper;
import org.ifc.idocs.report.common.NotesSession;
import org.ifc.idocs.report.db.ExportDAOImpl;
import org.ifc.idocs.report.db.ReportDAOImpl;
import org.ifc.idocs.report.model.DocumentDetailReportModel;
import org.ifc.idocs.report.model.DocumentReportModel;
import org.ifc.idocs.report.model.DomdocRepository;
import org.ifc.idocs.report.model.DomdocRepositoryDescriptor;
import org.ifc.idocs.report.model.MigrationSkippedDocuments;
import org.ifc.idocs.report.model.SecurityExceptionReportModel;
import org.ifc.idocs.report.transform.IFCNAB;
import org.ifc.idocs.report.transform.TempDb;
import org.ifc.idocs.report.transform.WBNAB;

/**
 * @author SPankajamsadanan
 * @see ExportUtility - extracts all sort of documents from lotus notes database
 *
 */
public class ExportUtility extends ReportUtility{

	protected static String utilityId = "", replicaCode = null, server = null, deltaDiscDocId = null;
	private static DateTime cutOffDate = null;
	private static Database parentDatabse = null;

	public static Map<String,Double> level1DocSize = new HashMap<String,Double>();
	public static Map<String,Integer> level1Subfolder = new HashMap<String,Integer>();

	private DomdocRepository domdoc = null;
	private DomdocRepositoryDescriptor repo = null;
	private static AppConfig config = AppConfig.getInstance();
	private Logger exportDocLogger = LogHelper.getLogger(ExportUtility.class);

	private Double sizeMapValue = 0.0;
	private DecimalFormat df = new DecimalFormat("#.##");
	private Integer countMapValue = 0, totalDocCount = 0;
	private String folderQuery = null, folderQuery1 = null, documentQuery1 = null, folderTypeCode = null, folderValueCode = null, regionName = null, projectCategoryNameCode = null;
	private static String documentQuery = null, country = null;

	private static Calendar calendar = null;
	private long exportCount = 0, duplicateDocCounter = 0;
	private boolean utilityIdFlag = false;

	private static Set<String> docIdSet = new HashSet<String>(), skipDocUniqueIdSet = new HashSet<String>(), legacyDocId = new HashSet<String>();
	private ArrayList<DocumentReportModel> documentReportList = new ArrayList<DocumentReportModel>();
	private ArrayList<DocumentDetailReportModel> documentDetailReportList = new ArrayList<DocumentDetailReportModel>();
	private ArrayList<SecurityExceptionReportModel> securityExceptionList = new ArrayList<SecurityExceptionReportModel>();
	private ArrayList<MigrationSkippedDocuments> migrationSkippedDocumentList = new ArrayList<MigrationSkippedDocuments>();
	private boolean foldermanFlag = false, skipDocument = false, checkedOut = false, inWorkflow = false;	
	private String foldermanPath = null, docid = null, skipMsg = null, extractionQuery = null;
	private String[] foldermans = null;
	/**
	 * Constructor for ExtractDocuments
	 */
	public ExportUtility() {
		legacyDocId.clear();
		duplicateDocCounter = 0;
		calendar = Calendar.getInstance();
		long startTime = calendar.getTimeInMillis();

		try{			
			extractionQuery = config.getString("filters.extractioncriteriacode");	//retrieving query string from extraction_criteria table
			exportDocLogger.warning("EXTRACTION CRITERIA ID = " + extractionQuery );
			String[] extCriteria = extractionQuery.split(";");
			server = config.getString("repository.server");

			for(int k = 0; k < extCriteria.length; k++){
				String extractionId = extCriteria[k];
				exportDocLogger.warning("Extraction id = " + extractionId);
				foldermanFlag = true;
				foldermanPath = config.getString("repository.foldermanPath");
				foldermans = foldermanPath .split(";");

				for(int fman = 0; fman < foldermans.length; fman++){
					repo = new DomdocRepositoryDescriptor("","",server,foldermans[fman]);
					if(utilityIdFlag && foldermanFlag){ // Multiple log files will be created when a new extraction criteria code exists
						getNewUtilityId();
						LogHelper.loggerMap.put("loggerMap",null);
						exportDocLogger = LogHelper.getLogger(ExportUtility.class);
					}
					
					utilityId = utilityMap.get("utilityId");
					exportDocLogger.warning("Report Utility ID is : " + utilityId);
					
					if(foldermanFlag){
						if(ExportDAOImpl.utilityIdIsExists(extractionId) != null){
							exportDocLogger.warning("Extraction criteria '" + extractionId + "' already exists in the system. Please create a new Extraction Criteria and re-run the Report Utility again ! ");
							System.exit(0);
						}else{
							ExportDAOImpl.saveReportUtilityId(utilityId, extractionId);
						}
					}
					
					foldermanFlag= false;
					domdoc = new DomdocRepository(repo);

					ResultSet rs = ExportDAOImpl.getExtractionInfo(extractionId);	//getting extraction query-string from database
					try {
						boolean invalidResultSet = true;
						while (rs.next()){
							folderQuery = rs.getString("FOLDER_QUERY_TXT"); 	// getting folder query value from extraction_criteria table.
							documentQuery1 = rs.getString("DOCUMENT_QUERY_TXT");	// getting document query value from extraction_criteria table.
							int start = folderQuery.indexOf("'");
							int end = folderQuery.lastIndexOf("'");
							country = folderQuery.substring(start + 1, end);
							replicaCode = rs.getString("REPLICATION_CODE");
							invalidResultSet = false;
						}
						if(invalidResultSet){
							exportDocLogger.warning("Invalid Extraction Criteria. Please check config.xml file");
							System.exit(0);
						}
						rs.close();
					} catch (SQLException e) {
						exportDocLogger.warning("Error : " + e);
					}

					if (country.length() > 3){ // extracts the country name (IND / BRA) from folder query value if query contains more inputs (COUNTRY_NAME_CODE='BRA' & project_id = '9999')
						country = country.substring(0, 3);
					}

//					code to extract multiple projects from database
//					folderQuery = "COUNTRY_NAME_CODE='BRA' & Project_id='20933'";
//					folderQuery = "COUNTRY_NAME_CODE='IND' & Project_Status_Code='A'";	

					updateFolderQuery();
					saveRecords();
					
				}//end of if extraction check
			}
		}catch (RuntimeException ioe){	//loop to finish multiple project id extraction
			exportDocLogger.warning("Please ensure valid inputs are provided in config.xml");
			ioe.printStackTrace();
			System.exit(0);
		}
		catch(NotesException e){
			exportDocLogger.warning("NotesError ~ " + e.id + " ~ " + e.text);
			e.printStackTrace();
			System.exit(0);
		}
		catch (Exception e){
			exportDocLogger.warning("Initialization error");
			e.printStackTrace();
			System.exit(0);
		}
		finally {
			long totalSkipped = 0;
			String[] skipCount = null;
			ArrayList<String> skipList = ReportDAOImpl.getSkippedDocsCount(utilityId);
			exportDocLogger.warning("Report Utility - Extract Part Done.");
			exportDocLogger.warning("Extraction Criteria Code = " + extractionQuery);
			exportDocLogger.warning("Report Utility ID is : " + utilityId);
			exportDocLogger.warning("Total number of processed documents = " + totalDocCount);			
			exportDocLogger.warning("Total number of documents to be Extracted (including versions) = " + exportCount);			
			for(String skip : skipList){
				exportDocLogger.warning(skip);
				skipCount = skip.split("Documents : ");
				totalSkipped += Long.parseLong(skipCount[1]); 
			}			
			exportDocLogger.warning("Total number of skipped documents = " + totalSkipped );
			exportDocLogger.warning("Total number of Distinct documents = " + skipDocUniqueIdSet.size());
			exportDocLogger.warning("Total number of Duplicate documents Skipped = " + duplicateDocCounter );
			
			TempDb.recycle();
			IFCNAB.recycle();
			WBNAB.recycle();
			NotesSession.terminate();
			printProcessRunTime(startTime, "Total run time");
		}
	}// ExtractDocument


	private void printProcessRunTime(long startTime, String msg) {
		calendar = Calendar.getInstance();
		long endTime = calendar.getTimeInMillis();
		long totalSeconds = endTime - startTime;
		totalSeconds = totalSeconds / 1000;
		exportDocLogger.warning(msg + " (in seconds) : " + totalSeconds);
		exportDocLogger.warning(msg + " (in minutes) : " + totalSeconds / 60 + ":" + totalSeconds % 60);
	}


	/**
	 * @return void
	 */
	private void updateFolderQuery() {
		folderQuery = folderQuery.trim();
		String[]  splits = folderQuery.split(" & ");
		String countryName = splits[0], projectId = null;
		ArrayList<String>  projectsIds = new ArrayList<String>();
		try {
			if(splits.length > 1){
				String[]  splits1 = splits[1].split("'");
				projectId = splits1[0];
				int j = 0;
				for(int i = 1; i < splits1.length; i++){
					//checking doc query
					if(splits1.length > 2){
						if (documentQuery1 != null){ 
							exportDocLogger.warning("MULTIPLE PROJECTS EXTRACTION SHOULD NOT HAVE DOCUMENT_QUERY ENTRIES ");
							exportDocLogger.warning("PLEASE REMOVE DOCUMENT_QUERY_TEXT FROM TABLE & TRY AGAIN");
							break;
						}
					}
					//end of doc query check
					if(!splits1[i].contains(",")){
						projectsIds.add(splits1[i]);
						j++;
					}
				}
				for(String pid : projectsIds){
					folderQuery1 = countryName + " & " + projectId + "'" + pid + "'";
					extractionDocsAndProjects(folderQuery1);
				}//end of query split loop
			}else{
				folderQuery1 = countryName;				
				extractionDocsAndProjects(folderQuery1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	/**
	 * extractionDocsAndProjects method extracts all projects & documents from lotus notes database
	 * @param folderQuery
	 * @param path
	 * @throws Exception
	 * @return void
	 */
	private void extractionDocsAndProjects(String folderQuery) throws Exception {
		DocumentCollection folders = domdoc.getFoldermanDb().findFolders(folderQuery);
		exportDocLogger.warning("Documents Count = " + folders.getCount());

		Document nfolder = folders.getFirstDocument();
		DomdocFolder folder;

//		splitting of multiple documents
		ArrayList<String> docIds = new ArrayList<String>();
		if(documentQuery1 != null){
			String[] ids = documentQuery1.split("'");
			if (ids.length > 1){
				int d = 0;
				for(int p = 1; p < ids.length; p++){
					if(!ids[p].contains(",")){
						docIds.add(ids[p]);
						d++;
					}
				}
			}
		}else if(docIdSet.size() > 0){
			docIds.addAll(docIdSet);
		}

		documentQuery = "!(IsWIPVer='1')";	//ensuring that document is not checked out
//		documentQuery = "";
		while (nfolder != null) {	
			try{
				folderValueCode = getFileRoomId(nfolder);
				folderTypeCode = getFileRoom(nfolder.getItemValueString("FileRoom"));
				regionName = nfolder.getItemValueString("REGION_NAME");
				projectCategoryNameCode = nfolder.getItemValueString("PROJECT_CATEGORY_NAME_CODE");
				exportDocLogger.warning("Project Id : " +  folderValueCode);
				if(folderValueCode.length() > 0){
					folder = new DomdocFolder(domdoc, nfolder);
					if(folder.getFolderkey() != null){
						if(docIds.size() > 0){
							for(String dids : docIds ){
								documentQuery = "!(IsWIPVer='1')";	//ensuring that document is not checked out
//								documentQuery = "";
								documentQuery1 = "DocID = '" + dids + "'";
								if (documentQuery1 != null){
									documentQuery = documentQuery + " & " + documentQuery1;
									documentExtraction(folder, nfolder);
								}
							}
						}else{
							documentExtraction(folder, nfolder);
						}
					}
				}else{
					listSkipDocuments(nfolder, nfolder.getItemValueString("docid"), "Missing FILEROOM attribute", "ER_020");
				}
			}
			catch (NotesException ne) {	
				exportDocLogger.warning("NotesException-Invalid replica id###");
				ne.printStackTrace();
			}
			catch (Exception e) {	
				exportDocLogger.warning("Exception-Invalid replica error###");
				e.printStackTrace();
			}
			nfolder = folders.getNextDocument();
		} //end of while loop

		exportDocLogger.warning("Saving the records...");
		saveRecords();
		utilityIdFlag = true;
	}

	/**
	 * documentExtraction method deals with document extraction
	 * @param folder
	 * @param document
	 * @param docExportPath
	 * @throws NotesException
	 * @return void
	 */
	private void documentExtraction(DomdocFolder folder, Document document) throws NotesException {
		Document newNdoc = null, ndoc = null;

		//		fetches the documents from lotus notes database. cutOffDate = used for delta run. for base line cutOffDate is null
		DocumentCollection documents = folder.findDocuments(documentQuery, cutOffDate);
		boolean isQualifiedDoc = true;
		if(cutOffDate != null){
			if(documents.getCount() < 1){
				isQualifiedDoc = false;
			}
		}
		Document latest;	
		Double documentsSize = 0.0, docLevelSize = 0.0, docLvlSize = 0.0;
		Integer level1DocCount = 0,docCount = 0;
		ndoc = documents.getFirstDocument();
		parentDatabse = null;
		while (ndoc != null) {
			try{
				if(parentDatabse == null){
					parentDatabse = ndoc.getParentDatabase();
				}
			}catch(NotesException ne){
				exportDocLogger.log(Level.WARNING, "NotesException : Unable to open Parent Database database", ne);
			}

			try { 
				totalDocCount++;
				
				if(!skipDocUniqueIdSet.contains(ndoc.getUniversalID())){
					
					newNdoc = documents.getNextDocument(ndoc);	// for recycling ndoc, assigning the next ndoc to a variable
					docid = ndoc.getItemValueString("docid");
					skipDocument = false;
					if (ndoc.getItemValueString("isCurrentVer").equals("1")) {
						latest = ndoc;
					} else {
						latest = parentDatabse.getView("IFCLatestDraftByDocID").getDocumentByKey(docid);
						if (latest == null) {
							latest = parentDatabse.getView("IFCLatestByDocID").getDocumentByKey(docid);
						}
					}
					if (latest == null) {
						skipDocument = true;
						listSkipDocuments(ndoc, docid, "Could not find latest document by docid.", "ER_018");
					}
					if (!skipDocument) {
						try{
							checkedOut = latest.hasItem("WIPUNID");
							inWorkflow = latest.hasItem("WorkflowStatus");
							
							if(checkedOut && inWorkflow && latest.getItemValueString("WIPUNID").length() > 0 && latest.getItemValueString("WorkflowStatus").matches("[124]")){
								skipDocument = true;
								exportDocLogger.warning("Document " + docid + " is checked out and in workflow, skipping...");
								listSkipDocuments(ndoc, docid, "Checked Out & In Workflow", "ER_045");	
							}
							else if(checkedOut && latest.getItemValueString("WIPUNID").length() > 0){	
								skipDocument = true;
								exportDocLogger.warning("Document " + docid + " is checked out, skipping...");
								listSkipDocuments(ndoc, docid, "Checked Out", "ER_002");							
							}else if(inWorkflow && latest.getItemValueString("WorkflowStatus").matches("[124]")) {
								skipDocument = true;
								exportDocLogger.warning("Document " + docid + " is In workflow, skipping...");	
								listSkipDocuments(ndoc, docid, "In Workflow", "ER_003");
							}else if(ndoc.getItemValueString("fileroom").length() == 0) {
								skipDocument = true;
								exportDocLogger.warning("Document " + docid + " is Missing FILEROOM attribute, skipping...");	
								listSkipDocuments(ndoc, docid, "Missing FILEROOM attribute", "ER_020");
							}
						}catch(NullPointerException ne){
							skipDocument = true;
							exportDocLogger.warning("DocID = " + docid +" ~ " + skipMsg);
							listSkipDocuments(ndoc, docid, "WIPUNID / WorkflowStatus attribute not found", "ER_031");
						}
					}
					if (!skipDocument) {
						
						docCount++;
						exportCount++;
	
//						Adding document to Security Exception Report List
						addSecurityExceptionReportModelToList(ndoc);
	
						level1DocCount = level1Subfolder.get(ndoc.getItemValueString("Subfolder"));
						if(level1DocCount == null){
							level1DocCount = 0;
						}
						level1DocCount++;
						level1Subfolder.put(ndoc.getItemValueString("Subfolder"), level1DocCount);
						
						docLvlSize = (double)ndoc.getSize();
						docLevelSize = level1DocSize.get(ndoc.getItemValueString("Subfolder"));
						if(docLevelSize == null){
							docLevelSize = 0.0;
						}
						docLevelSize = docLevelSize + docLvlSize;
						level1DocSize.put(ndoc.getItemValueString("Subfolder"), docLevelSize);
						documentsSize += docLvlSize;						
						
					}
					skipDocUniqueIdSet.add(ndoc.getUniversalID());
				}else{
					duplicateDocCounter++;
					exportDocLogger.warning("Duplicate Document ~ Document id : " + docid + " ~ Unique Document Id : " + ndoc.getUniversalID() +" skipping...");	
				}
			} 
			catch (NotesException e){
				listSkipDocuments(ndoc, ndoc.getItemValueString("DocID"), "Doc Error - NotesException", "ER_001");
			} 
			catch (Exception e) {
				listSkipDocuments(ndoc, ndoc.getItemValueString("DocID"), "Doc Error - Exception", "ER_001");
				e.printStackTrace();
			}
			
			ndoc.recycle();
			ndoc = newNdoc;
		}

		if(folderValueCode.length() > 0 && isQualifiedDoc && docCount > 0 && !legacyDocId.contains(folderValueCode)){

//			Adding document to Document Report List
			DocumentReportModel dr = addDocumentReportModelToList(document, documentsSize, docCount);

//			Adding document to Document Detailed Report List
			addDocumentDetailReportModelToList(dr);
			legacyDocId.add(folderValueCode);
		}
		level1DocSize.clear();
		level1Subfolder.clear();

		if((documentDetailReportList.size() > 3000 || securityExceptionList.size() > 3000)){
			exportDocLogger.warning("Saving the records... List.size() > 3000");
			saveRecords();
		}
	}


	/**
	 * addDocumentDetailReportModelToList - Adding document to Document Detailed Report List
	 * @param dr
	 * @return void
	 */
	private void addDocumentDetailReportModelToList(DocumentReportModel dr) {
		String docsSize;
		for (String key : level1Subfolder.keySet()) {
			if(key.length() > 0){

				DocumentDetailReportModel ddr = new DocumentDetailReportModel();
				ddr.setReportUtilityCode(utilityId);
				ddr.setFolderTypeCode(folderTypeCode);
				ddr.setFolderValueCode(folderValueCode);
				ddr.setLevel1FolderNme(key);

				countMapValue = (level1Subfolder.get(key) != null) ? level1Subfolder.get(key) : 0;
				sizeMapValue = (level1DocSize.get(key) != null) ? level1DocSize.get(key) : 0;
				sizeMapValue = sizeMapValue / 1024; // To KB
				docsSize = df.format(sizeMapValue);

				boolean uniqueLevel = true;
				for(DocumentDetailReportModel ddrm : documentDetailReportList){
					if(ddrm.getLevel1FolderNme().equals(key) && ddrm.getFolderValueCode().equals(ddr.getFolderValueCode())){ 
						documentDetailReportList.remove(ddrm);
						ddr.setLevel1SourceDocCnt(countMapValue + ddrm.getLevel1SourceDocCnt());
						ddr.setLevel1SourceDocSizeNbr(Double.parseDouble(docsSize) + ddrm.getLevel1SourceDocSizeNbr());
						uniqueLevel = false;
						break;
					}
				}

				if(uniqueLevel){
					ddr.setLevel1SourceDocCnt(countMapValue);
					ddr.setLevel1SourceDocSizeNbr(Double.parseDouble(docsSize));
				}
				documentDetailReportList.add(ddr);
				exportDocLogger.info("Level 1 subfolder : " + key + " - count : " + countMapValue);
			}
		}
	}


	/**
	 * addDocumentReportModelToList - Adding document to Document Report List
	 * @param document
	 * @param documentsSize
	 * @param docCount
	 * @return DocumentReportModel
	 * @throws NotesException
	 */
	private DocumentReportModel addDocumentReportModelToList(Document document, Double documentsSize, Integer docCount) throws NotesException {
		documentsSize = documentsSize / 1024; // To KB
		String docsSize = df.format(documentsSize);

		boolean uniqueProject = true;
		DocumentReportModel dr = new DocumentReportModel();
		for(DocumentReportModel drm : documentReportList){
			if(drm.getFolderValueCode().equals(folderValueCode)){
				documentReportList.remove(drm);
				dr.setSourceDocCnt(docCount + drm.getSourceDocCnt());
				dr.setSourceDocSizeNbr(Double.parseDouble(docsSize) + drm.getSourceDocSizeNbr());
				uniqueProject = false;
				break;
			}
		}

		if(uniqueProject){
			dr.setSourceDocCnt(docCount);
			dr.setSourceDocSizeNbr(Double.parseDouble(docsSize));
		}			
		dr.setReportUtilityCode(utilityId);
		dr.setFolderTypeCode(folderTypeCode);
		dr.setFolderValueCode(folderValueCode);
		dr.setRegionName(regionName);
		dr.setProjectCategoryNameCode(projectCategoryNameCode);
		documentReportList.add(dr);

		exportDocLogger.warning("FOLDER_VALUE_CODE : " + dr.getFolderValueCode() + " | FOLDER_TYPE_CODE : " + dr.getFolderTypeCode() 
				+ " | DOCUMENT_COUNT : " + dr.getSourceDocCnt() + " | DOCUMENT_SIZE : " + dr.getSourceDocSizeNbr());
		return dr;
	}


	/**
	 * addSecurityExceptionReportModelToList - Adding document to Security Exception Report List
	 * @param ndoc
	 * @throws NotesException
	 */
	@SuppressWarnings("unchecked")
	private void addSecurityExceptionReportModelToList(Document ndoc) throws NotesException {
		SecurityExceptionReportModel serm = new SecurityExceptionReportModel();
		serm.setReportUtilityCode(utilityId);
		serm.setFolderValueCode(folderValueCode);
		serm.setFolderTypeCode(folderTypeCode);
		serm.setSourceSecurityClassCode(ndoc.getItemValueString("SecurityClassification_Code"));
		serm.setSourceDocVerNbr(ndoc.getItemValueInteger("version") + "." + ndoc.getItemValueInteger("Draft"));
		serm.setSourceDocId(ndoc.getItemValueString("DocID"));
		serm.setSourceDocName(ndoc.getItemValueString("TITLE"));
		serm.setSourceDocUniqueId(ndoc.getUniversalID());
		serm.setCountryCode(ndoc.getItemValueString("COUNTRY_NAME_CODE"));
		serm.setRegionName(ndoc.getItemValueString("REGION_NAME"));
		serm.setProjectCategoryNameCode(projectCategoryNameCode);
		
		Vector lstModDate = ndoc.getItemValueDateTimeArray("LastModDate");		
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a Z");
		java.util.Date parsedDate;
		java.sql.Timestamp timestamp = null;
		try {
			parsedDate = dateFormat.parse(lstModDate.elementAt(0).toString());
			timestamp = new java.sql.Timestamp(parsedDate.getTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		serm.setDocLastModDate(timestamp);
		
		securityExceptionList.add(serm);

		exportDocLogger.warning("FOLDER_VALUE_CODE : " + serm.getFolderValueCode() + " | Doc Id : " 
				+ ndoc.getItemValueString("DocID") + "Doc Unique Id : " + ndoc.getUniversalID() + " | Doc Title : " 
				+ serm.getSourceDocName() + " | Version : " + serm.getSourceDocVerNbr() + " | Export Count : " + exportCount);

	}

	/**
	 * listSkipDocuments - adding skipped documents with skip reason & error code to a list
	 * @param ndoc
	 * @param docid
	 * @param skipReason
	 * @param errorCode
	 * @return void
	 */
	private void listSkipDocuments(Document ndoc, String docid, String skipReason, String errorCode) throws NotesException  {		
		MigrationSkippedDocuments msd = new MigrationSkippedDocuments();
		msd.setDatabase(ndoc.getParentDatabase().getTitle());
		msd.setDocumentId(docid);
		msd.setDocumentUniqueId(ndoc.getUniversalID());
		msd.setFileCabinet(ndoc.getItemValueString("FileCabinet"));
		msd.setFolderTypeCode(folderTypeCode);
		msd.setSkipReason(skipReason);
		msd.setTitle(ndoc.getItemValueString("TITLE"));
		msd.setUtilityCode(utilityId);
		msd.setVersion(ndoc.getItemValueInteger("version") + "." + ndoc.getItemValueInteger("Draft"));
		msd.setErrorCode(errorCode);
		msd.setFolderValueCode(folderValueCode);
		migrationSkippedDocumentList.add(msd);
	}


	/**
	 * saveRecords - saving all records of each list. after that clears the lists
	 * @return void
	 */
	private void saveRecords() {
		ExportDAOImpl.saveReports(documentReportList, documentDetailReportList, securityExceptionList, migrationSkippedDocumentList);
		documentReportList.clear();
		securityExceptionList.clear();
		documentDetailReportList.clear();
		migrationSkippedDocumentList.clear();
		System.gc();		
	}

	/**
	 * getFileRoomId - returns the folder value code of a document 
	 * @param doc
	 * @return String
	 */
	public String getFileRoomId(Document doc){
		try {
			String fileRoom = doc.getItemValueString("FileRoom");
			if(fileRoom != null && fileRoom.length() > 0){
				if (fileRoom.equals("PROJECTS"))
					return doc.getItemValueString("Project_ID");
				else if (fileRoom.equals("INSTITUTIONS"))
					return doc.getItemValueString("Institution_nbr");
				else if (fileRoom.equals("MISCELLANEOUS"))
					return doc.getItemValueString("Country_name_code");
				else {
					throw new NotesException(NotesError.NOTES_ERR_ERROR, "Unexpected fileroom value");
				}
			}
		} catch (NotesException e) {
			e.printStackTrace();
		}
		return "";
	}

	/**
	 * getFileRoom - checks the file room, if it is MISCELLANEOUS then returns COUNTRY
	 * @param fileRoom
	 * @return String
	 */
	private String getFileRoom(String fileRoom) {
		return (fileRoom.equals("MISCELLANEOUS") ? "COUNTRY" : fileRoom);
	}
	
}
