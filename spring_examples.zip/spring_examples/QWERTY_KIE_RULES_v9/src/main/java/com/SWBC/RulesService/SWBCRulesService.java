package com.SWBC.RulesService;

import static com.SWBC.utilities.BRMConstants.DATE_FORMAT;
import static com.SWBC.utilities.BRMConstants.NULL_DATE_VALUE;

import java.io.IOException;
import java.lang.reflect.Field;
import java.sql.Connection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.drools.core.base.RuleNameEndsWithAgendaFilter;
import org.drools.core.base.RuleNameEqualsAgendaFilter;
import org.drools.core.base.RuleNameMatchesAgendaFilter;
import org.drools.core.base.RuleNameStartsWithAgendaFilter;
import org.drools.core.command.runtime.rule.FireAllRulesCommand;
import org.drools.core.definitions.rule.impl.RuleImpl;
import org.drools.core.event.AfterActivationFiredEvent;
import org.drools.core.rule.Pattern;
import org.json.JSONObject;
import org.kie.api.definition.rule.Rule;
import org.kie.api.event.rule.AfterMatchFiredEvent;
import org.kie.api.event.rule.DefaultAgendaEventListener;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.StatelessKieSession;
import org.kie.api.runtime.rule.FactHandle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.SWBC.DataService.TrecService;
import com.SWBC.model.Brm_app_info;
import com.SWBC.model.Brm_app_json_info;
//import com.SWBC.model.Brm_app_json_info;
import com.SWBC.model.Brm_loan_info;
import com.SWBC.model.Brm_processing_info;
import com.SWBC.model.Brm_request_info;
import com.SWBC.model.Brm_rule;
import com.SWBC.model.Brm_rule_lookup_log;
import com.SWBC.model.PreProc_Doca_Ucap;
import com.SWBC.model.Trec;
import com.SWBC.utilities.BRMUtilities;
import com.documentum.fc.client.IDfSession;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import ssa.ssautil.SsaSysWinMonitor;

@Service
@Component
@PropertySource(value = { "classpath:application.properties" })
public class SWBCRulesService extends DefaultAgendaEventListener {

	private KieContainer kieContainer;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SetAPIAttributeValues setAPIAttributeValues;
	@Autowired
	private SetAPPAttributeValues setAPPAttributeValues;
	@Autowired
	private SetDOCAAttributeValues setDOCAAttributeValues;
	@Autowired
	private TrecService trecService;
	@Autowired
	private Trec trec;
	@Autowired
	private Environment env;
	@Autowired
	private IDfSession getDfSession;
	@Autowired
	private PreProc_Doca_Ucap preProc_Doca_Ucap;
	
	@Autowired
	private ArrayList<String> mortlibraryList;
	@Autowired
	private Connection AS400Conn;

	@Autowired
	private ArrayList<String> getLoanLineTrecAttr;

	boolean isExitFlag = false;
	boolean isExceptionCase = false;
	boolean isCommentCase = false;

	@Autowired
	public SWBCRulesService(KieContainer kieContainer) {
		this.kieContainer = kieContainer;
	}

	public void getRulesOutput(Brm_request_info brm_request_info) {

		Map<String, KieSession> kieSessionMap = getSessionMap(brm_request_info.getRuleVersion());

		List<Brm_rule> myRuleList = null;

		List<Brm_processing_info> proc_info = null;
		
		String transactionType = brm_request_info.getTransType().trim();

		List<Brm_app_info> appinputRecords = null;

		KieSession kieSession = null;
		KieSession kieSession_comm = kieContainer.newKieSession("default_rulesSession");
		KieSession kieSession_PreProc = kieContainer.newKieSession("preprocrules_id");
		
		//Date tst = trecService.getLoanBoardDate("6900", "00000000000000000000000004000049753", "F", "01");
		
		List<Map<String, Object>> tst = trecService.getPymtDisbData("3042");
		
		

		//trec=setAPIAttributeValues.setBICDate(trec, trecService.getBICData(3493, "00000000000000000000000000090327011"));
		

		String appName = "API";
		int procRec = 0;
		int counter = 0;
		String status = "INCOMPLETE";
		Date startDate = new Date();
		
		try {
			
			
			if (brm_request_info.getSource().equals("api")) {
				
				
				
				if(brm_request_info.getSingleAPITrec().equalsIgnoreCase("true"))
				{
					appName="Single_Tran";
				}
			
				
				proc_info = trecService.getProcInfo(brm_request_info);

				logger.debug("############### Total Records Picked:" + proc_info.size() + " #######################");
				try {
					for (int i = 0; i < proc_info.size(); i++) {
						
						

						isExitFlag = false;
						isExceptionCase = false;
						isCommentCase = false;

						myRuleList = trecService.getLogginhRuleList(proc_info.get(i).getTransaction_type());

						logger.debug("############### Processing Record:" + i + " for Transaction Type:"
								+ proc_info.get(i).getTransaction_type().trim() + " #######################");
						trecService.insertProcTbl(proc_info.get(i));
						List<Brm_loan_info> loan_info = trecService.getLoanInfo(proc_info.get(i));
						trecService.insertLoanTblData(loan_info);

						if (loan_info.get(0).getLoan_no().equalsIgnoreCase("NO_LOAN")) {
							continue;

						} 
						else 
						{
							
						
						
						for (int k = 0; k < loan_info.size(); k++) {
							
							{

								trec = setAPIAttributeValues.checkTransType(proc_info.get(i).getTransaction_type().trim(),
										proc_info.get(i), loan_info.get(k), trecService, trec);
								
								

								kieSession = (KieSession) kieSessionMap.get(proc_info.get(i).getTransaction_type().trim());

								for (int j = 0; j < myRuleList.size(); j++) {

									Map<String, String> infer = new HashMap<String, String>();

									if (myRuleList.get(j).getRule_name().substring(0, 3).equalsIgnoreCase("CR_") || myRuleList.get(j).getRule_name().substring(0, 4).equalsIgnoreCase("BIC_")) {

										executeRules(infer, kieSession_comm, myRuleList.get(j), brm_request_info, trec);
									}

									else {

										executeRules(infer, kieSession, myRuleList.get(j), brm_request_info, trec);

									}

								}

							}
							
						}
							
						
						}
						
					counter++;
						
					}

					if (!(kieSession == null)) {
						kieSession.dispose();
					}

					else {
						logger.debug("############### No Records to Process for " + transactionType
								+ " #######################");
					}

				} catch (Exception ex) {
//					logger.debug(
//							"############### evaluateRuleDRL() Exception:" + ex.getMessage() + " #######################");
					
					ex.printStackTrace();

				}

			
			}

			// BRM App xCP operation
			else

			{

				List<Trec> trecList = setAPPAttributeValues.setApp(trec, brm_request_info);

				if (!trecList.isEmpty()) {

					if (brm_request_info.getTransType().equalsIgnoreCase("NBSALL")) {
						myRuleList = trecService.getLogginhRuleList("NBS");
					} else {
						myRuleList = trecService.getLogginhRuleList(brm_request_info.getTransType());
					}

					try {
						for (int i = 0; i < trecList.size(); i++) {

							isExitFlag = false;
							isExceptionCase = false;
							isCommentCase = false;

							kieSession = (KieSession) kieSessionMap
									.get(brm_request_info.getTransType().equalsIgnoreCase("NBSALL") ? "NBS"
											: brm_request_info.getTransType());

							for (int j = 0; j < myRuleList.size(); j++) {

								Map<String, String> infer = new HashMap<String, String>();

								if (myRuleList.get(j).getRule_name().substring(0, 3).equalsIgnoreCase("CR_") || myRuleList.get(j).getRule_name().substring(0, 4).equalsIgnoreCase("BIC_")) {

									executeRules(infer, kieSession_comm, myRuleList.get(j), brm_request_info,
											trecList.get(i));
								}

								else {

									executeRules(infer, kieSession, myRuleList.get(j), brm_request_info, trecList.get(i));
								}

							}

						}

						if (!(kieSession == null)) {
							kieSession.dispose();
						}

						else {
							logger.debug("############### No Records to Process for " + transactionType
									+ " #######################");
						}

					} catch (Exception ex) {
//						logger.debug("############### evaluateRuleDRL() Exception:" + ex.getMessage()
//								+ " #######################");
						ex.printStackTrace();

					}
				}

			}
			
			//Date endDate = new Date();
			
			
			
			if(proc_info.size() == counter)
			{
				status = "DONE";
			}
			
			
	
			
			
		} catch (Exception e) {
			
		}
		
		finally {
			
			Date endDate = new Date();
			JSONObject json = new JSONObject();
			json.put("Total Docs", proc_info.size());
			json.put("Processed", counter);
			json.put("Type", brm_request_info.getTransType());
			json.put("Run Mode", appName);
			
			
			trecService.insertSchedularLog(startDate, endDate, appName, json.toString(), status);
			
		}



	}

	public void executeRules(Map<String, String> infer, KieSession kieSession_comm, Brm_rule myRuleList,
			Brm_request_info brm_request_info, Trec trec) throws JsonProcessingException {

		// JSONObject json = new JSONObject();

		ObjectMapper json = new ObjectMapper();
		// json.enable(SerializationFeature.INDENT_OUTPUT);

		//Map<String, String> logMap = new TreeMap<String, String>();
		
		JSONObject logMap = new JSONObject();

		ObjectMapper paramMapJson = new ObjectMapper();
		// paramMapJson.enable(SerializationFeature.INDENT_OUTPUT);
		ObjectMapper paramMap = new ObjectMapper();
		// paramMap.enable(SerializationFeature.INDENT_OUTPUT);

		ExpressionParser parser = new SpelExpressionParser();

		Date dNow = new Date();
		SimpleDateFormat ft = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
		boolean islookup = Boolean.parseBoolean(brm_request_info.getEnableLookup());

		trec.setPolicyCancelReasonList(trecService.getPolicyCancelReason());
		trec.setTransactionInsurerList(trecService.getTransactionInsurer());

		infer = getParamList(kieSession_comm, myRuleList, trec, paramMap, paramMapJson, parser);
		RuleNameEqualsAgendaFilter rn_comm = new RuleNameEqualsAgendaFilter(myRuleList.getRule_name().trim());

	
		
		ObjectMapper mapper = new ObjectMapper();
		Object jsonParam = null;
		try {
			jsonParam = mapper.readValue(infer.get("paramList"), Object.class);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		logMap.put("Parameters", new JSONObject(infer.get("paramList")));
		//logMap.put("Parameters", jsonParam.toString());
		//logMap.put("Parameters", infer.get("paramList").toString().substring(1, infer.get("paramList").toString().length()-1));

		logMap.put("rule", infer.get("pattern"));
		logMap.put("ruleName", myRuleList.getRule_name().trim());
		
		
		

		FactHandle handle_comm = kieSession_comm.insert(trec);
		kieSession_comm.insert(trec);

		if (kieSession_comm.fireAllRules(rn_comm) != 0) {

			logMap.put("time stamp", ft.format(dNow));
			
			
			///CONTINUE is the RULE_OUTOCME TABLE
			

			if (myRuleList.getRule_outcome().equalsIgnoreCase("CONTINUE") && myRuleList.getRule_msg().contains("BIC")) {
				
				trecService.insertLogTbl(trec.getTransaction_id(), trec.getTransaction_type(), infer.get("paramList"),
						myRuleList.getRule_name(), myRuleList.getRule_outcome().toString(),
						myRuleList.getRule_msg().toString(), brm_request_info.getUser(), trec.getTransaction_cov_type(),
						trec.getAccount_no(), trec.getLoanNo(), trec.getTransactionSuffix(),
						trec.getPolicyNumberScore(), brm_request_info.getSource(), "main",
						logMap.toString());

			}

			else if (myRuleList.getRule_outcome().equalsIgnoreCase("EXCEPTION") && isCommentCase == false
					&& isExitFlag == false) {

				isExceptionCase = true;

				trecService.insertLogTbl(trec.getTransaction_id(), trec.getTransaction_type(), infer.get("paramList"),
						myRuleList.getRule_name(), myRuleList.getRule_outcome().toString(),
						myRuleList.getRule_msg().toString(), brm_request_info.getUser(), trec.getTransaction_cov_type(),
						trec.getAccount_no(), trec.getLoanNo(), trec.getTransactionSuffix(),
						trec.getPolicyNumberScore(), brm_request_info.getSource(), "main",
						logMap.toString());
						
						//json.writeValueAsString(logMap)

				// json.writeValueAsString(logMap)

			} else if (myRuleList.getRule_outcome().equalsIgnoreCase("COMMENT") && isExceptionCase == false
					&& isExitFlag == false) {

				isCommentCase = true;
				isExitFlag = true;

				trecService.insertLogTbl(trec.getTransaction_id(), trec.getTransaction_type(), infer.get("paramList"),
						myRuleList.getRule_name(), myRuleList.getRule_outcome().toString(),
						myRuleList.getRule_msg().toString(), brm_request_info.getUser(), trec.getTransaction_cov_type(),
						trec.getAccount_no(), trec.getLoanNo(), trec.getTransactionSuffix(),
						trec.getPolicyNumberScore(), brm_request_info.getSource(), "main",
						logMap.toString());

				return;

			} else if (myRuleList.getRule_outcome().equalsIgnoreCase("UPDATE") && isExceptionCase == false
					&& isCommentCase == false) {

				isExitFlag = true;

				trecService.insertLogTbl(trec.getTransaction_id(), trec.getTransaction_type(), infer.get("paramList"),
						myRuleList.getRule_name(), myRuleList.getRule_outcome().toString(),
						myRuleList.getRule_msg().toString(), brm_request_info.getUser(), trec.getTransaction_cov_type(),
						trec.getAccount_no(), trec.getLoanNo(), trec.getTransactionSuffix(),
						trec.getPolicyNumberScore(), brm_request_info.getSource(), "main",
						logMap.toString());

				return;

			}

		} else {

			if (islookup) {

				logMap.put("time stamp", ft.format(dNow));

				trecService.insertLogTbl(trec.getTransaction_id(), trec.getTransaction_type(), infer.get("paramList"),
						myRuleList.getRule_name(), "SKIPPED", myRuleList.getRule_msg().toString(), brm_request_info.getUser(),
						trec.getTransaction_cov_type(), trec.getAccount_no(), trec.getLoanNo(),
						trec.getTransactionSuffix(), trec.getPolicyNumberScore(), brm_request_info.getSource(), "main",
						logMap.toString());
			}

		}

		kieSession_comm.delete(handle_comm);

	}

	public Map<String, String> getParamList(KieSession kieSession3, Brm_rule brm_rule, Trec trec, ObjectMapper paramMap,
			ObjectMapper paramMapJson, ExpressionParser parser) {

		Map<String, String> tempMap = new TreeMap<String, String>();

		Map<String, String> paramSortedMap = new TreeMap<String, String>();

		if (brm_rule.getRule_outcome().equalsIgnoreCase("UPDATE")) {
			EvaluationContext eContext = new StandardEvaluationContext(trec);

			for (String string : getLoanLineTrecAttr) {

				Expression exp = parser.parseExpression(string);
				
				paramSortedMap.put(string.toString(), exp.getValue(eContext, String.class).toString());
				// paramMapJson.put(string, exp.getValue(eContext,
				// String.class));

			}
			try {
				tempMap.put("paramList", paramMap.writeValueAsString(paramSortedMap).toString());
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else {

			RuleImpl ri = (RuleImpl) kieSession3.getKieBase().getRule("rules", brm_rule.getRule_name());

			//System.err.println(brm_rule.getRule_name());
			

			Pattern rce = (Pattern) ri.getLhs().getChildren().get(0);

			tempMap.put("pattern", rce.getConstraints().toString());

			EvaluationContext eContext = new StandardEvaluationContext(trec);

			for (Field attr : new Trec().getClass().getDeclaredFields()) {

				try {

					if (rce.getConstraints().toString().contains(attr.getName())) {
						Expression exp = parser.parseExpression(attr.getName());
						
						paramSortedMap.put(attr.getName().toString(), exp.getValue(eContext, String.class).toString());
					

					}

				} catch (Exception e) {

					e.printStackTrace();
				}

			}

			try {
				tempMap.put("paramList", paramMap.writeValueAsString(paramSortedMap).toString());
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return tempMap;

	}

	public Map<String, KieSession> getSessionMap(String ruleVersion) {
		List<String> reqList = new ArrayList<String>();

		Map<String, KieSession> sessionMap = new HashMap();

		String[] tempArr = env.getRequiredProperty("select.transaction.types").split(",");

		for (int i = 0; i < tempArr.length; i++) {
			sessionMap.put(tempArr[i].trim(),
					kieContainer.newKieSession(BRMUtilities.getKIESessionName(ruleVersion, tempArr[i].trim())));
		}

		return sessionMap;
	}

	public void releaseKIE(Map sessionMap) {
		KieSession session = null;

		String[] tempArr = env.getRequiredProperty("select.transaction.types").split(",");

		for (int i = 0; i < tempArr.length; i++) {
			session = (KieSession) sessionMap.get(tempArr[i]);
			session.dispose();
		}

	}

	public Brm_app_json_info getJsonApp(String dbId) {

		Brm_app_json_info obj = new Brm_app_json_info();
		
		return obj = trecService.getJSONOutput(dbId);

	}
	
	public String getTestRule(Brm_request_info brm_request_info) {
		
//
//		Brm_app_json_info obj = new Brm_app_json_info();
//		
//		
//		Map<String, KieSession> kieSessionMap = getSessionMap(brm_request_info.getRuleVersion());
//
//		List<Brm_rule> myRuleList = null;
//
//		List<Brm_processing_info> proc_info = null;
//		String transactionType = brm_request_info.getTransType().trim();
//
//		List<Brm_app_info> appinputRecords = null;
//
//		KieSession kieSession = null;
//		KieSession kieSession_comm = kieContainer.newKieSession("default_rulesSession");
//		
//		
//		proc_info = trecService.getProcInfoSingleAPI(brm_request_info.getTid(), brm_request_info.getLoan_no(),
//				brm_request_info.getLoan_suffix(), brm_request_info.getAcc_no(),
//				brm_request_info.getCov_type());
//		
//		List<Brm_loan_info> loan_info = trecService.getLoanInfo(proc_info.get(0));
//		
//		myRuleList = trecService.getSingleRuleList(brm_request_info.getSingleAPITrec());
//		Map<String, String> infer = new HashMap<String, String>();
//		
//		
//		trec = setAPIAttributeValues.checkTransType(proc_info.get(0).getTransaction_type().trim(),
//				proc_info.get(0), loan_info, trecService, trec);
//
//		kieSession = (KieSession) kieSessionMap.get(proc_info.get(0).getTransaction_type().trim());
//		
//		
//	
//		ObjectMapper json = new ObjectMapper();
//		// json.enable(SerializationFeature.INDENT_OUTPUT);
//
//		//Map<String, String> logMap = new TreeMap<String, String>();
//		
//		JSONObject logMap = new JSONObject();
//
//		ObjectMapper paramMapJson = new ObjectMapper();
//		// paramMapJson.enable(SerializationFeature.INDENT_OUTPUT);
//		ObjectMapper paramMap = new ObjectMapper();
//		// paramMap.enable(SerializationFeature.INDENT_OUTPUT);
//
//		ExpressionParser parser = new SpelExpressionParser();
//
//		Date dNow = new Date();
//		SimpleDateFormat ft = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
//		boolean islookup = Boolean.parseBoolean(brm_request_info.getEnableLookup());
//
//		trec.setPolicyCancelReasonList(trecService.getPolicyCancelReason());
//		trec.setTransactionInsurerList(trecService.getTransactionInsurer());
//
//		if (myRuleList.get(0).getRule_name().substring(0, 3).equalsIgnoreCase("CR_"))
//		{
//			infer = getParamList(kieSession_comm, myRuleList.get(0), trec, paramMap, paramMapJson, parser);
//		}
//		else
//		{
//			infer = getParamList(kieSession, myRuleList.get(0), trec, paramMap, paramMapJson, parser);
//		}
//		
//		
//		
//	
//		logMap.put("Parameters", new JSONObject(infer.get("paramList")));
//		//logMap.put("Parameters", jsonParam.toString());
//		//logMap.put("Parameters", infer.get("paramList").toString().substring(1, infer.get("paramList").toString().length()-1));
//
//		logMap.put("rule", infer.get("pattern"));
//		logMap.put("ruleName", myRuleList.get(0).getRule_name().trim());
//		
//		
//		return logMap.toString();
//
		return "";
	}
	
	

	
	
	public Map<String, String> getLoanStatusAS400(Connection as400_conn, String accountNumber, String loanNumber,
			String loanSuffix, String covType, String AS400LibPath, ArrayList<String> libraryList) {

		return com.SWBC.AS400SP.Procedures.getAS400MortgageLoanStatus(as400_conn, accountNumber, loanNumber, loanSuffix,
				covType, AS400LibPath, libraryList);
	}
	
	
	
	
	public void runPreProc()
	{
		
		
		try {
			
			List<String> inObjID = trecService.getInputrObjID(env.getRequiredProperty("select.input.dql"), getDfSession);
			
			
			for (String rObjectID : inObjID) {
				
				executePreProc(rObjectID);
			}
			
			

			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}

	private void executePreProc(String rObjectID) {
		
		KieSession kieSession_PreProc = kieContainer.newKieSession("preprocrules_id");
		
		
	

		try {
			preProc_Doca_Ucap = setDOCAAttributeValues.setAttr(trecService.executeDCTMQuery(getDfSession, env.getRequiredProperty("select.doca.dctm"),rObjectID));
			
			preProc_Doca_Ucap = setDOCAAttributeValues.setRule3_4_PreProc_AgentCode_PolicyScore(trecService.getISAgentCode(preProc_Doca_Ucap.getAccount_number(), preProc_Doca_Ucap.getCov_type(), preProc_Doca_Ucap.getLoan_number(), preProc_Doca_Ucap.getTransaction_id(), preProc_Doca_Ucap.getLoan_suffix()),preProc_Doca_Ucap);
			preProc_Doca_Ucap = setDOCAAttributeValues.setMasterPayee(trecService.getMasterPayee(preProc_Doca_Ucap.getAccount_number()), preProc_Doca_Ucap);
			preProc_Doca_Ucap = setDOCAAttributeValues.setShortNameCarrier_Rule_3_2(trecService.getPayeePreProc3_2(preProc_Doca_Ucap.getCarrier_state(), preProc_Doca_Ucap.getCarrier_name(), preProc_Doca_Ucap.getAccount_number()), preProc_Doca_Ucap);
			preProc_Doca_Ucap = setDOCAAttributeValues.setShortNameAndPayeeInfo(trecService.getShortNameFMS057("CGFLOOD", 6900),preProc_Doca_Ucap);
			preProc_Doca_Ucap = setDOCAAttributeValues.setCarrierInfo(trecService.getACCTSubStr(Integer.parseInt(preProc_Doca_Ucap.getAccount_number())), trecService.getCarrierFMS053(),preProc_Doca_Ucap);
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		preProc_Doca_Ucap.setPp_flag("PP_INPROCESS");
		preProc_Doca_Ucap.setLogJoinID(new Date().getTime());
		
//		preProc_Doca_Ucap.setLoan_number("00022");
		preProc_Doca_Ucap.setInsurance_type("X");
//		preProc_Doca_Ucap.setCov_type("W");
		
		trecService.insertStagingTable(preProc_Doca_Ucap);
		
		


	
		
		
		
//		//Test 3.4
//		preProc_Doca_Ucap.setPayee_code("");
//		preProc_Doca_Ucap.setPolicy_number("57F475382");		
//		preProc_Doca_Ucap = setDOCAAttributeValues.setRule3_4_PreProc_AgentCode_PolicyScore(trecService.getISAgentCode("6900", "Q", "00000000000000000000000000001005386", "ZBGRJPVP", "0"),preProc_Doca_Ucap);
//		
//		
		
		
		//Test 3.3
//		preProc_Doca_Ucap.setPayee_code("");
//		preProc_Doca_Ucap = setDOCAAttributeValues.setMasterPayee(trecService.getMasterPayee("6758"), preProc_Doca_Ucap);
		
		
		
		//Test 3.2
//		preProc_Doca_Ucap.setPayee_code("");
//		preProc_Doca_Ucap.setCarrier_name("USAA");
//		preProc_Doca_Ucap = setDOCAAttributeValues.setShortNameCarrier_Rule_3_2(trecService.getPayeePreProc3_2("IL", "STFARM", "6900"), preProc_Doca_Ucap);		
//		preProc_Doca_Ucap.setCov_type("X");
		
		
		//Test 3.1
//		preProc_Doca_Ucap.setPayee_code("");
//		preProc_Doca_Ucap.setCov_type("W");
//		preProc_Doca_Ucap.setCarrier_name("USAA");
//		preProc_Doca_Ucap = setDOCAAttributeValues.setShortNameAndPayeeInfo(trecService.getShortNameFMS057("CGFLOOD", 6900),preProc_Doca_Ucap);
		
		
		
		
		//Test 2.6
//		preProc_Doca_Ucap.setTransaction_type("XLC");
//		try {
//			preProc_Doca_Ucap.setPolicy_cancel_date(new SimpleDateFormat("MM/dd/YYYY").parse("01/01/1900"));
//		} catch (ParseException e) {
//			
//			e.printStackTrace();
//		}
//		try {
//			preProc_Doca_Ucap.setPolicy_effective_date(new SimpleDateFormat("yyyyMMdd").parse( "20180520"));
//		} catch (ParseException e) {
//			
//			e.printStackTrace();
//		}
		
		
		//Test 2.5
//		preProc_Doca_Ucap.setInsurance_type("D");
//		try {
//			preProc_Doca_Ucap.setPolicy_expiration_date(new SimpleDateFormat("MM/dd/YYYY").parse("01/01/1900"));
//		} catch (ParseException e) {
//			
//			e.printStackTrace();
//		}
//		try {
//			preProc_Doca_Ucap.setPolicy_effective_date(new SimpleDateFormat("yyyyMMdd").parse( "20180520"));
//		} catch (ParseException e) {
//			
//			e.printStackTrace();
//		}
		
		
		
		
		//Test 2.1
//		preProc_Doca_Ucap.setPolicy_holder_name("$Jimmy$");
//		preProc_Doca_Ucap.setCo_policy_holder_name("$Neesham$");
//		preProc_Doca_Ucap.setProperty_address_1("$@Antonio");
//		preProc_Doca_Ucap.setProperty_address_2("!!Andres");
//		preProc_Doca_Ucap.setProperty_city("+SAN Antonio+");
//		preProc_Doca_Ucap.setProperty_state("T#");
	
		
		
		
		
		//Test 1.2.x
//		preProc_Doca_Ucap.setInsurance_type("X");
//		preProc_Doca_Ucap.setCov_type("F");
//		preProc_Doca_Ucap = setDOCAAttributeValues.setCarrierInfo(trecService.getACCTSubStr(6900), trecService.getCarrierFMS053(),preProc_Doca_Ucap);
		
		
		kieSession_PreProc.insert(preProc_Doca_Ucap);
		kieSession_PreProc.insert(trecService);
		kieSession_PreProc.fireAllRules();	
		
		

//		
//		//System.out.println("OUTPUT::"+preProc_Doca_Ucap.getPayee_code());
//		//System.out.println("OUTPUT::"+preProc_Doca_Ucap.getPolicy_cancel_date());
//		//System.out.println("OUTPUT::"+preProc_Doca_Ucap.getPolicy_expiration_date());
//		//System.out.println("OUTPUT::"+preProc_Doca_Ucap.getInsurance_type());
//		System.out.println("OUTPUT::"+preProc_Doca_Ucap.getPolicy_holder_name());
//		System.out.println("OUTPUT::"+preProc_Doca_Ucap.getCo_policy_holder_name());
//		System.out.println("OUTPUT::"+preProc_Doca_Ucap.getProperty_address_1());
//		System.out.println("OUTPUT::"+preProc_Doca_Ucap.getProperty_address_2());
//		System.out.println("OUTPUT::"+preProc_Doca_Ucap.getProperty_city());
//		System.out.println("OUTPUT::"+preProc_Doca_Ucap.getProperty_state());
//		System.out.println("Pre Proc Test End");
		
		
		preProc_Doca_Ucap.setPp_flag("PP_COMPLETED");
		trecService.insertStagingTable(preProc_Doca_Ucap);
		

		
		
		
		resetPreProcObj(preProc_Doca_Ucap);
		
	}

	private void resetPreProcObj(PreProc_Doca_Ucap preProc_Doca_Ucap) {
		
		preProc_Doca_Ucap.setDoc_scan_date(null);
		preProc_Doca_Ucap.setFollow_up_date(null);
		preProc_Doca_Ucap.setPolicy_expiration_date(null);
		preProc_Doca_Ucap.setPolicy_cancel_date(null);
		preProc_Doca_Ucap.setPremium_due_date(null);
		preProc_Doca_Ucap.setDoc_issue_date(null);
		preProc_Doca_Ucap.setDoc_notice_effective_date(null);
		preProc_Doca_Ucap.setDoc_delivery_date(null);
		preProc_Doca_Ucap.setDoc_notice_date(null);
		preProc_Doca_Ucap.setReinstatement_date(null);
		preProc_Doca_Ucap.setPolicy_effective_date(null);
		preProc_Doca_Ucap.setDoc_received_date(null);
		preProc_Doca_Ucap.setAs400_post_date(null);
		preProc_Doca_Ucap.setPercent_primary_coverage(0.0);
		preProc_Doca_Ucap.setPolicy_premium(0.0);
		preProc_Doca_Ucap.setPercent_deductible(0.0);
		preProc_Doca_Ucap.setCoverage_amount(0.0);
		preProc_Doca_Ucap.setAdditional_coverage_amount(0.0);
		preProc_Doca_Ucap.setAdditional_premium_amt(0.0);
		preProc_Doca_Ucap.setDeductible(0.0);
		preProc_Doca_Ucap.setBase_coverage_other_structs(0.0);
		preProc_Doca_Ucap.setPolicy_score(0);
		preProc_Doca_Ucap.setBatch_number(0);
		preProc_Doca_Ucap.setNumber_of_condos(0);
		preProc_Doca_Ucap.setBatch_seq_no(0);
		preProc_Doca_Ucap.setSHORTNAME(null);
		preProc_Doca_Ucap.setPAYEE(null);
		preProc_Doca_Ucap.setSHORTNAME_CARRIER(null);
		preProc_Doca_Ucap.setPAYEE_CARRIER(null);
		preProc_Doca_Ucap.setPp_flag(null);
		preProc_Doca_Ucap.setInsurance_type(null);
		preProc_Doca_Ucap.setFC_FORMAT(null);
		preProc_Doca_Ucap.setFC_ACCOUNT(null);
		preProc_Doca_Ucap.setFIRE(null);
		preProc_Doca_Ucap.setHOME(null);
		preProc_Doca_Ucap.setFLOOD(null);
		preProc_Doca_Ucap.setWIND(null);
		preProc_Doca_Ucap.setCONT(null);
		preProc_Doca_Ucap.setLIAB(null);
		preProc_Doca_Ucap.setEQUIP(null);
		preProc_Doca_Ucap.setQUAKE(null);
		preProc_Doca_Ucap.setGAP(null);
		preProc_Doca_Ucap.setOTHR(null);
		preProc_Doca_Ucap.setCO_ALIAS(null);
		preProc_Doca_Ucap.setCO_NAME(null);
		preProc_Doca_Ucap.setCO_TRAN_DATE(null);
		preProc_Doca_Ucap.setCO_OPERATOR_ID(null);
		preProc_Doca_Ucap.setCO_SPARE_01(null);
		preProc_Doca_Ucap.setCO_SPARE_02(null);
		preProc_Doca_Ucap.setCO_DATE_01(null);
		preProc_Doca_Ucap.setCO_DATE_02(null);
		preProc_Doca_Ucap.setCO_FILLER(null);
		preProc_Doca_Ucap.setIS_AGENT_CODE(null);
		preProc_Doca_Ucap.setMasterPayee(null);
		preProc_Doca_Ucap.setFlood_zone(null);
		preProc_Doca_Ucap.setHo_6_flag(null);
		preProc_Doca_Ucap.setGrandfater_zone(null);
		preProc_Doca_Ucap.setEarthquake_excluded(null);
		preProc_Doca_Ucap.setGrandfather_zone(null);
		preProc_Doca_Ucap.setReplace_cost_ind(null);
		preProc_Doca_Ucap.setBill_indicator(null);
		preProc_Doca_Ucap.setPercent_add_other_structure(null);
		preProc_Doca_Ucap.setWind_excluded(null);
		preProc_Doca_Ucap.setDocument_sub_type(null);
		preProc_Doca_Ucap.setFollow_up_reason(null);
		preProc_Doca_Ucap.setAgent_email(null);
		preProc_Doca_Ucap.setCov_type(null);
		preProc_Doca_Ucap.setIs_qc_candidate(null);
		preProc_Doca_Ucap.setDocument_type(null);
		preProc_Doca_Ucap.setLoan_type(null);
		preProc_Doca_Ucap.setCarrier_zip(null);
		preProc_Doca_Ucap.setTransaction_status(null);
		preProc_Doca_Ucap.setOrig_file_name(null);
		preProc_Doca_Ucap.setProperty_zip(null);
		preProc_Doca_Ucap.setLoan_number(null);
		preProc_Doca_Ucap.setAgency_number(null);
		preProc_Doca_Ucap.setEscrow_indicator(null);
		preProc_Doca_Ucap.setMailing_address(null);
		preProc_Doca_Ucap.setAccount_number(null);
		preProc_Doca_Ucap.setAccount_tax_id(null);
		preProc_Doca_Ucap.setProperty_address_1(null);
		preProc_Doca_Ucap.setProperty_address_2(null);
		preProc_Doca_Ucap.setMailing_state(null);
		preProc_Doca_Ucap.setPayee_code(null);
		preProc_Doca_Ucap.setClient_number(null);
		preProc_Doca_Ucap.setQc_response_code(null);
		preProc_Doca_Ucap.setScan_id(null);
		preProc_Doca_Ucap.setProperty_city(null);
		preProc_Doca_Ucap.setPolicy_number(null);
		preProc_Doca_Ucap.setMortgagee_zip(null);
		preProc_Doca_Ucap.setMortgagee_name(null);
		preProc_Doca_Ucap.setAgent_city(null);
		preProc_Doca_Ucap.setImpairment_code(null);
		preProc_Doca_Ucap.setAgent_name(null);
		preProc_Doca_Ucap.setMailing_city(null);
		preProc_Doca_Ucap.setPolicy_cancel_reason(null);
		preProc_Doca_Ucap.setMortgagee_city(null);
		preProc_Doca_Ucap.setAgent_zip(null);
		preProc_Doca_Ucap.setAccount_name(null);
		preProc_Doca_Ucap.setTransaction_id(null);
		preProc_Doca_Ucap.setTransaction_source(null);
		preProc_Doca_Ucap.setCo_policy_holder_name(null);
		preProc_Doca_Ucap.setProperty_state(null);
		preProc_Doca_Ucap.setCarrier_city(null);
		preProc_Doca_Ucap.setAgent_phone(null);
		preProc_Doca_Ucap.setCarrier_name(null);
		preProc_Doca_Ucap.setLoan_suffix(null);
		preProc_Doca_Ucap.setMortgagee_address(null);
		preProc_Doca_Ucap.setCarrier_state(null);
		preProc_Doca_Ucap.setAgent_address(null);
		preProc_Doca_Ucap.setInstitution_code(null);
		preProc_Doca_Ucap.setCarrier_address_1(null);
		preProc_Doca_Ucap.setAgent_state(null);
		preProc_Doca_Ucap.setPolicy_holder_name(null);
		preProc_Doca_Ucap.setTransaction_type(null);
		preProc_Doca_Ucap.setMailing_zip(null);
		preProc_Doca_Ucap.setMortgagee_state(null);
		preProc_Doca_Ucap.setCarrier_phone(null);
		
		preProc_Doca_Ucap.setLogJoinID(0);

		
		
	}


	
	
}