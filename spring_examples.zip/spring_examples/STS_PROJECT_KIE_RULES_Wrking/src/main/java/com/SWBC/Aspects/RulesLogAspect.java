package com.SWBC.Aspects;

import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class RulesLogAspect {

	
	
}
