/**
 * PCHW078Response_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W;

public class PCHW078Response_Type  implements java.io.Serializable {
    private gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078Out_Type PCHW078Out;

    public PCHW078Response_Type() {
    }

    public PCHW078Response_Type(
           gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078Out_Type PCHW078Out) {
           this.PCHW078Out = PCHW078Out;
    }


    /**
     * Gets the PCHW078Out value for this PCHW078Response_Type.
     * 
     * @return PCHW078Out
     */
    public gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078Out_Type getPCHW078Out() {
        return PCHW078Out;
    }


    /**
     * Sets the PCHW078Out value for this PCHW078Response_Type.
     * 
     * @param PCHW078Out
     */
    public void setPCHW078Out(gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078Out_Type PCHW078Out) {
        this.PCHW078Out = PCHW078Out;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PCHW078Response_Type)) return false;
        PCHW078Response_Type other = (PCHW078Response_Type) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.PCHW078Out==null && other.getPCHW078Out()==null) || 
             (this.PCHW078Out!=null &&
              this.PCHW078Out.equals(other.getPCHW078Out())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPCHW078Out() != null) {
            _hashCode += getPCHW078Out().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PCHW078Response_Type.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "PCHW078Response_Type"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PCHW078Out");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "PCHW078Out"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "PCHW078Out_Type"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
