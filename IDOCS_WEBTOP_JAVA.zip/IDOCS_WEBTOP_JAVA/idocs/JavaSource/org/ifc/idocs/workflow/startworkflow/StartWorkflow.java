/**
 * This custom component class provides query for the users in selective project.
 * This custom component class provides query validation to start workflow.
 * #######################################################################################################
 * Author		 	  DateofChange	 Version		ModificationHistory
 * #######################################################################################################
 * Parag Doshi				11/20/2010		1.0			created
 * #######################################################################################################
 */
package org.ifc.idocs.workflow.startworkflow;

import java.io.InputStream;
import java.net.URL;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.crrpsr.LinkToGHG;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;
import org.w3c.dom.Document;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.DfWorkflowBuilder;
import com.documentum.fc.client.IDfActivity;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfWorkflow;
import com.documentum.fc.client.IDfWorkflowBuilder;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfList;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfList;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.LocaleService;
import com.documentum.web.form.control.Button;
import com.documentum.web.form.control.Label;

public class StartWorkflow extends com.documentum.webcomponent.library.workflow.startworkflow.StartWorkflow
{
	private static final String MSG_INITIATED_WORKFLOW = "Workflow Initiated";
	private static final String IOM_WORKFLOW_INITIATION_ERROR_PREF = "Workflow for this document can only be initiated by ";
	private static final String QRY_VARIABLE_PROJECTID = "<projectid>";
	String strTemplateName =IDocsConstants.MSG_EMPTY_STRING;

	public void onInit(ArgumentList args) {
		MESSAGE = IDocsConstants.MSG_EMPTY_STRING;
		b_MESSAGE = IDocsConstants.MSG_EMPTY_STRING;
		try {
			DfLogger.info(this, " :: onInit : " + getDfSession().getLoginUserName(), null, null);
		} catch (DfException e) {
			DfLogger.error(this, " :: onInit Exception >> " + e.getMessage(), null, e);
		}
		String objectId = args.get(IDocsConstants.MSG_OBJECTID);

		if (canStartIDocsWorkFlow(objectId,true,true) == false) {
			DfLogger.info(this, " onInit:: precondition failed Return from component", null, null);
		}else {
			DfLogger.info(this, " onInit:: Started Workflow", null, null);
		}
	}

	/**
	 * This method is the entry point for a user to start workflow. Checks whether a user can start a workflow or not
	 * and displays the validation messages accordingly
	 * 
	 * @param objectId - r_object_id of the selected document
	 * @param isLockedCheckRequired - This is to decide whether we need 
	 * 			to check whether the check for locked document is required or not.
	 * 			Pass false when you call this from Checkin Component
	 * 			Pass true when you call from startWorkFlow Component
	 * @return
	 */
	public boolean canStartIDocsWorkFlow(String objectId, boolean isLockedCheckRequired,boolean initateWorkFlow){
		try {
			m_nlsResourceBundle = new NlsResourceBundle(m_WorkflowNlsProp);
			String docQuery = IdocsUtil.getMessage("QRY_WFSTATUS_TMPLTCODE");
			String templateCode = IDocsConstants.MSG_EMPTY_STRING;
			String wfStatus = IDocsConstants.MSG_EMPTY_STRING;
			boolean isASTemplates = false;

			docQuery = docQuery.replaceFirst("''","'" + objectId + "'");
			DfLogger.info(this, " :: canStartIDocsWorkFlow: docQuery: " + docQuery, null, null);
			IDfQuery query = new DfQuery(docQuery);
			IDfCollection docCollection = query.execute(getDfSession(), IDfQuery.DF_READ_QUERY);
			if(docCollection.next()){
				templateCode = docCollection.getString(IDocsConstants.MSG_TEMPLATE_CODE);
				wfStatus = docCollection.getString(IDocsConstants.MSG_WORKFLOW_STATUS);
				if(docCollection.getString(IDocsConstants.MSG_R_LOCK_OWNER).equals(IDocsConstants.MSG_EMPTY_STRING)){
					isDocCheckedOut = false;
				}else{
					isDocCheckedOut = true;
				}
				docCollection.close();
			}
			if(docCollection != null)docCollection.close();
			DfLogger.info(this, " :: canStartIDocsWorkFlow: templateCode: " + templateCode, null, null);
		
			/**
			 * Advisory Services Change
			 */
			
			String docCatCode = IDocsConstants.MSG_EMPTY_STRING;
			String docCatQry = IdocsUtil.getMessage("QRY_AS_DOC_CATEGORY");
			docCatQry = docCatQry.replaceFirst("''", "'" + objectId + "'");
			DfLogger.info(this, " :: canStartIDocsWorkFlow: docCatQry: " + docCatQry, null, null);
			IDfQuery asDocQuery = new DfQuery(docCatQry);
			IDfCollection docCatColl = asDocQuery.execute(getDfSession(), IDfQuery.DF_READ_QUERY);

			 try {
				 while (docCatColl.next()) {
					 docCatCode = docCatColl.getString(IDocsConstants.DOC_CATEGORY);
					 DfLogger.info(this, " :: Doc Category Code " + docCatCode, null, null);
				 }
			 } finally {
				 if (docCatColl != null) {
					 docCatColl.close();
				 }
			 }
			
			 if (templateCode != null && templateCode.trim().length() > 0) {

				 /*
				  * String[] asTemplates = {"88","90","91","92","93"};
				  * DfLogger.info(this,
				  * "onNextComponent ::  AS template count : " +
				  * asTemplates.length , null, null);
				  * 
				  * for(int i = 0; i< asTemplates.length; i++){
				  * if(asTemplates[i].equalsIgnoreCase(templateCode)){
				  * isASTemplates = true; } } DfLogger.info(this,
				  * " :: is AS Workflow code : " + isASTemplates, null, null);
				  */

			
				 // Below code is commented because of TAPP templates
				 
				 /*if (IDocsConstants.MSG_ADVISORY_SERVICES.equalsIgnoreCase(docCatCode)) {
				 isASTemplates = true;
					}*/
				
				 strTemplateName=IdocsUtil.getTemplateTitle(getDfSession(), objectId);
				if(strTemplateName != null && IdocsUtil.isAdvisoryTemplate(strTemplateName)){
					isASTemplates = true;
				}

				/**
				 * Advisory code end
				 */

				 DfLogger.info(this, " :: canStartIDocsWorkFlow: template code is not null", null, null);
				 if (isDocCheckedOut == true && isLockedCheckRequired == true) {
					 displayErrorMessage("MSG_WORKFLOW_CHECKOUT", true);
					 return false;
				 } else {

					 /**
					  * For Advisory Templates only
					  */
					 try {
						 if (isASTemplates) {
							 String tempCategory = IdocsUtil.getTemplateCategoryCode(strTemplateName);
							 DfLogger.debug(this," :: onNextComponent : template category code : " + tempCategory, null, null);
							 if (tempCategory != null && tempCategory.trim().length() > 0) {
								 boolean result = checkASWorkflowStatus(isASTemplates, tempCategory, objectId, initateWorkFlow);
								 if(!result){
									 return result;
								 }
							 } else {
								 DfLogger.info(this, " :: canStartIDocsWorkFlow: Not Advisory AS template: ", null, null);
							 }	
						 }
					 } catch (Exception e) {
						 DfLogger.error(this, " :: canStartIDocsWorkFlow IOException:: " + e.getMessage(), null, null);
					 }

					 /**
					  * End of Advisory Code
					  */
					 /**Fetch the value of isWorkflowRequired, isWorkflowRestartable from the table, IDOCS_TEMPLATE_INFO */
					 String tblQuery =IdocsUtil.getMessage("QRY_ISWF_REQ_RSTRT");
					 String isWfReqd = IDocsConstants.MSG_EMPTY_STRING;
					 String isWfRestartable = IDocsConstants.MSG_EMPTY_STRING;
					 tblQuery = tblQuery.replaceFirst("''","'" + templateCode + "'");
					 DfLogger.info(this, " :: canStartIDocsWorkFlow: tblQuery: " + tblQuery, null, null);
					 IDfCollection tblCollection = IdocsUtil.executeQuery(getDfSession(),tblQuery, IDfQuery.DF_READ_QUERY);
					 if(tblCollection.next()){
						 isWfReqd = tblCollection.getString(IDocsConstants.MSG_IS_WORKFLOW_REQUIRED);
						 isWfRestartable = tblCollection.getString(IDocsConstants.MSG_IS_WORKFLOW_RESTARTABLE);
						 tblCollection.close();
					 }
					 if(tblCollection != null)tblCollection.close();
					 String strTemplateTitle = IdocsUtil.getTemplateTitle(getDfSession(),objectId);

					 /** Check for Product templates having workflow_status: Declined and throw validation error to user */
					 if(IdocsUtil.isProductTemplate(strTemplateTitle)) {
						 if (wfStatus !=null && wfStatus.equalsIgnoreCase("declined")){
							 displayErrorMessage("WORKFLOW_STATUS_DECLINED",true);
							 return false; 
						 }
					 }
					 /** Check for Project Tier Before Starting workflows */
					 String strProjectTierTemplateNames = IdocsUtil.getMessage("PROJECT_TIER_TEMPLATES");
					 if (strTemplateTitle != null && strTemplateTitle.trim().length() > 0 &&
							 IdocsUtil.checkIfTokenPresent(strProjectTierTemplateNames, strTemplateTitle, IdocsConstants.MSG_COMMA)) {
						 String result = IdocsUtil.checkIfRightsIssueCSO(getDfSession(), objectId, strTemplateTitle);
						 if (result !=null && result.trim().length()> 0 
								 && (result.equalsIgnoreCase(IDocsConstants.MSG_CSO) == true
										 || result.equalsIgnoreCase(IDocsConstants.MSG_OTHER) == true)){
							 // For templates Rights Issue CSO and other templates.
							 String projectTier = IdocsUtil.getProjectTier(objectId, getDfSession());
							 DfLogger.debug(this, " :: canStartIDocsWorkFlow: Project Tier: " + projectTier, null, null);
							 if (IdocsUtil.isValidProjectTier(projectTier)== false) {
								 DfLogger.info(this, " :: canStartIDocsWorkFlow: Project Tier Not Found", null, null);
								 displayErrorMessage("PROJECT_TIER_NOT_FOUND",true);
								 return false;
							 } 
						 }else {
							 DfLogger.debug(this, " :: canStartIDocsWorkFlow: Template is Rights Issue NON CSO", null, null);
						 }
					 }
					 /** To check for partner tier templates */
					 String strPartnerTierTemplateNames = IdocsUtil.getMessage("PARTNER_TIER_TEMPLATES");
					 if (strTemplateTitle != null && strTemplateTitle.trim().length() > 0 &&
							 IdocsUtil.checkIfTokenPresent(strPartnerTierTemplateNames, strTemplateTitle, IdocsConstants.MSG_COMMA)) {
						 String result = IdocsUtil.checkIfRightsIssueCSO(getDfSession(), objectId, strTemplateTitle);
						 if (result !=null && result.trim().length()> 0 
								 && (result.equalsIgnoreCase(IDocsConstants.MSG_NON_CSO) == true
										 || result.equalsIgnoreCase(IDocsConstants.MSG_OTHER) == true)){
							 // For Rights Issue NON CSO and Other templates.
							 String partnerTier = IdocsUtil.getPartnerTier(objectId, getDfSession());
							 DfLogger.debug(this, " :: canStartIDocsWorkFlow: Partner Tier: " + partnerTier, null, null);
							 if (IdocsUtil.isValidPartnerTier(partnerTier) == false ) {
								 DfLogger.info(this, " :: canStartIDocsWorkFlow: Partner Tier Not Found", null, null);
								 displayErrorMessage("PARTNER_TIER_NOT_FOUND",true);
								 return false;
							 } 
						 } else {
							 DfLogger.debug(this, " :: canStartIDocsWorkFlow: Template is Rights Issue CSO", null, null);
						 }
					 }
					 if (isWfReqd !=null && isWfReqd.trim().length() > 0 && isWfReqd.equalsIgnoreCase("3") == true ){ 
						 if (wfStatus.equalsIgnoreCase("completed")){
							 if (isWfRestartable.equals("1")){
								 boolean businessRule = checkBusinessRule(getDfSession(), objectId);
								 if (businessRule){
									 if(initateWorkFlow){
										 initiateWF(getDfSession(), objectId);
									 }else{
										 // THis is checked from the checkin Container. Which has separate technique to start workflow

									 }
									 displayErrorMessage(MESSAGE,false);
									 return true;
								 }else{
									 // Display error message that user should be a member of specific roles to start workflow..
									 displayErrorMessage(b_MESSAGE,false);
									 return false;
								 }
							 }else{
								 // Display Error Message that workflow is completed and is not restartable.
								 displayErrorMessage("MSG_WORKFLOW_CANT_RESTART",true);
								 return false;
							 } 
						 }else {
							 /** No Operations required. This workflow should be triggered from 
							  * another work flow(Not from IDocs Webtop )*/
							 b_MESSAGE = "Invalid Operation. You cannot start a workflow for this document.";
							 displayErrorMessage(b_MESSAGE,false);
						 }
					 }else  if (isWfReqd !=null && isWfReqd.trim().length() > 0 && isWfReqd.equalsIgnoreCase("0") == false ){ 
						 // If isWorkflowRequired is True
						 DfLogger.info(this, " :: canStartIDocsWorkFlow: isWfReqd: " + isWfReqd, null, null);
						 DfLogger.info(this, " :: canStartIDocsWorkFlow: wfStatus: " + wfStatus, null, null);
						 if (wfStatus.equals(IDocsConstants.MSG_EMPTY_STRING) || (wfStatus==null)){
							 boolean businessRule = checkBusinessRule(getDfSession(), objectId);
							 if (businessRule){
								 if(initateWorkFlow){
									 initiateWF(getDfSession(), objectId);
								 }else{
									 // THis is checked from the checkin Container. Which has separate technique to start workflow

								 }
								 displayErrorMessage(MESSAGE,false);
								 return true;
							 }else{
								 // Display error message that user should be a member of specific roles to start workflow..
								 displayErrorMessage(b_MESSAGE,false);
							 }	            			
						 }else if (wfStatus.equalsIgnoreCase("completed")){
							 if (isWfRestartable.equals("1") == true ){
								 boolean businessRule = checkBusinessRule(getDfSession(), objectId);
								 if (businessRule){
									 if(initateWorkFlow){
										 initiateWF(getDfSession(), objectId);
									 }else{
										 // THis is checked from the checkin Container. Which has separate technique to start workflow
									 }
									 displayErrorMessage(MESSAGE,false);
									 return true;
								 }else{
									 // Display error message that user should be a member of specific roles to start workflow....
									 displayErrorMessage(b_MESSAGE,false);
									 return false;
								 }
							 }else{
								 // Display Error Message that workflow is completed and is not restartable.
								 displayErrorMessage("MSG_WORKFLOW_CANT_RESTART",true);
								 return false;
							 }	            		
						 }else{
							 // Display error message that document is already in workflow
							 displayErrorMessage("MSG_WORKFLOW_RUNNING",true); 
							 return false;
						 }
					 }else{
						 DfLogger.info(this, " :: canStartIDocsWorkFlow: isWfReqd: " + isWfReqd, null, null);
						 // Display Error Message that workflow is not required.
						 displayErrorMessage("MSG_WORKFLOW_NOT_REQUIRED",true);
						 return false;
					 }
				 }
			 } else {
				 DfLogger.info(this, " :: canStartIDocsWorkFlow: template code is null or empty", null, null);            	
				 // Display Error Message that workflow is not required.
				 displayErrorMessage("MSG_WORKFLOW_NOT_REQUIRED",true);
				 return false;
			 }
		} catch(DfException e) {
			DfLogger.error(this," :: canStartWorkFlow DfException >> " + e.getMessage(),null,e);
			displayErrorMessage("MSG_WORKFLOW_ERROR",true);
		} 
		return false;
	}

	/**
	 * This check is required before starting PDS First Disbursement Workflow.
	 * @param currentProjectId
	 * @param strTemplateName
	 * @return
	 */
	private boolean projectStageNbrValidation(String currentProjectId,
			String strTemplateName) {
		try{
			String templatePDSFirstDisbursement = IdocsUtil.getMessage("MSG_TEMPLATE_PDS_FIRST_DISBURSEMENT");
			String templatePDSCommitment = IdocsUtil.getMessage("MSG_TEMPLATE_PDS_COMMITMENT");
			if(strTemplateName.equals(templatePDSFirstDisbursement)){
				int stageNbr = fetchProjectStageNumber(currentProjectId);		
				if (stageNbr >= Integer.parseInt(IdocsUtil.getMessage("MSG_PROJECT_STAGE_NBR_DISBURSEMENT_VALUE"))) {
					return true;
				} 
				else {
					b_MESSAGE = m_nlsResourceBundle.getString("MSG_PROJECT_STAGE_NBR_DISBURSEMENT_INVALID", LocaleService.getLocale());
					return false;
				}
			}else if(strTemplateName.equals(templatePDSCommitment)){
				int stageNbr = fetchProjectStageNumber(currentProjectId);		
				if (stageNbr >= Integer.parseInt(IdocsUtil.getMessage("MSG_PROJECT_STAGE_NBR_COMMITMENT_VALUE"))) {
					return true;
				} 
				else {
					b_MESSAGE = m_nlsResourceBundle.getString("MSG_PROJECT_STAGE_NBR_COMMITMENT_INVALID", LocaleService.getLocale());
					return false;
				}
			} else {
				DfLogger.debug(this, " :: projectStageNbrValidation : Not PDS First Disbursement & PDS Commitment templates ",null,null);
				return true;
			}
		}catch (Exception e) {
			DfLogger.debug(this, " :: projectStageNbrValidation : Exception :"+e.getMessage(),null,null);
		}
		return true;
	}
	//@ TODO Check this code 
	
	/**
	 * To Check disbursement Amount validation
	 * @return 
	 * @param currentProjectId
	 * @param strTemplateName
	 * @param objectId
	 */
	private boolean disbursementAmntValidation(String currentProjectId,String strTemplateName,String objectId){
		try{
				String productNbr = IDocsConstants.MSG_EMPTY_STRING;
				String disbursementWfNbr = IDocsConstants.MSG_EMPTY_STRING;
				String commitmentWfNbr = IDocsConstants.MSG_EMPTY_STRING;
				String templatePDSFirstDisbursement = IdocsUtil.getMessage("MSG_TEMPLATE_PDS_FIRST_DISBURSEMENT");
				String templatePDSSubsequentDisbursement = IdocsUtil.getMessage("MSG_TEMPLATE_PDS_SUBSEQ_DISBURSEMENT");
				if(strTemplateName.equals(templatePDSFirstDisbursement)||strTemplateName.equals(templatePDSSubsequentDisbursement)){
					if (objectId != null && objectId.trim().length() > 0 && !objectId.equals(IDocsConstants.BLANK_OBJECT_ID)) {
						// 	Query to get product nbr,disbursement nbr and commitment nbr 
						String disbursementWfNbrQry=IdocsUtil.getMessage("QRY_GET_DISBURSEMENT_WF_DETAILS");
						//PRODUCT_NBR ='<product_nbr>' AND COMMITMENT_WORKFLOW_NBR = '<commitment_workflow_nbr>'
						disbursementWfNbrQry=disbursementWfNbrQry.replaceFirst("''", "'"+objectId+"'");
						IDfCollection disbursementWfNbrColl = IdocsUtil.executeQuery(getDfSession(), disbursementWfNbrQry, DfQuery.DF_READ_QUERY);
						while (disbursementWfNbrColl.next()) {
							productNbr = disbursementWfNbrColl.getString(IDocsConstants.MSG_PRODUCT_NBR);
							disbursementWfNbr = disbursementWfNbrColl.getString(IDocsConstants.MSG_DISBURSEMENT_WF_NBR);
							commitmentWfNbr = disbursementWfNbrColl.getString(IDocsConstants.MSG_COMMITMENT_WF_NBR);
						}
						if(disbursementWfNbrColl != null)disbursementWfNbrColl.close();
					}else{
						DfLogger.info(this,"Invalid Object Id...", null, null);
					}
					// To get undisbursed workflow amount in USD
					String undisbursedWorkflowUsdQry = IdocsUtil.getMessage("QRY_GET_UNDISBURSED_WORKFLOW_USD_AMT");
					undisbursedWorkflowUsdQry = undisbursedWorkflowUsdQry.replace(replaceProductNBRSting,IdocsConstants.MSG_QUOTES+productNbr+IdocsConstants.MSG_QUOTES); 
					undisbursedWorkflowUsdQry = undisbursedWorkflowUsdQry.replace(replaceCommitmentWorkflowNBRSting,IdocsConstants.MSG_QUOTES+commitmentWfNbr+IdocsConstants.MSG_QUOTES);
					double undisbursedAmnt = 0;
					try {
						IDfCollection undisbursedAmntColl = IdocsUtil.executeQuery(getDfSession(), undisbursedWorkflowUsdQry, DfQuery.DF_READ_QUERY);
						while (undisbursedAmntColl.next()) {
							undisbursedAmnt = undisbursedAmntColl.getDouble(IDocsConstants.UNDISBURSED_WORKFLOW_USD_AMT);
						}
						if(undisbursedAmntColl != null)undisbursedAmntColl.close();
						DfLogger.error(this, " :: Undisbursed amount in USD: "+undisbursedAmnt,null,null);
					}catch (DfException e) {
						DfLogger.error(this, " :: Undisbursed amount in USD "+e.getMessage(),null,null);
						errorStringforExceptions=e.getMessage();
						return false;
					}
					//To get disbursement amount in USD

					String disbursementUsdQry = IdocsUtil.getMessage("QRY_DISBURSEMENT_USD_AMT");
					disbursementUsdQry = disbursementUsdQry.replace(replaceProductNBRSting,IdocsConstants.MSG_QUOTES+productNbr+IdocsConstants.MSG_QUOTES);
					disbursementUsdQry = disbursementUsdQry.replace(replaceDisbursmentWorkflowNBRSting,IdocsConstants.MSG_QUOTES+disbursementWfNbr+IdocsConstants.MSG_QUOTES);
					disbursementUsdQry = disbursementUsdQry.replace(replaceCommitmentWorkflowNBRSting,IdocsConstants.MSG_QUOTES+commitmentWfNbr+IdocsConstants.MSG_QUOTES);
					DfLogger.info(this, "disbursementAmntValidation() :: disbursementUsdQry  ::"+disbursementUsdQry, null, null);
					
					double disbursementAmnt = 0;
					try {
						IDfCollection disbrsmntAmntColl = IdocsUtil.executeQuery(getDfSession(), disbursementUsdQry, DfQuery.DF_READ_QUERY);
						while (disbrsmntAmntColl.next()) {
							disbursementAmnt = disbrsmntAmntColl.getDouble(IDocsConstants.ATTR_DISBURSEMENT_USD_AMT);
						}
						if(disbrsmntAmntColl != null)disbrsmntAmntColl.close();
						DfLogger.error(this, " :: Disbursement amount in USD : "+disbursementAmnt,null,null);
					}catch (DfException e) {
						DfLogger.error(this, " :: Disbursement amount "+e.getMessage(),null,null);
						errorStringforExceptions=e.getMessage();
						return false;
					}
				if(undisbursedAmnt >= disbursementAmnt){
					DfLogger.info(this,"Valid disbursement amount", null, null);
					return true;
				}
				else if(undisbursedAmnt < disbursementAmnt){
					DfLogger.info(this,"Invalid disbursement amount, Cannot initiate workflow", null, null);
					b_MESSAGE = m_nlsResourceBundle.getString("MSG_DISBURSEMENT_AMNT_INVALID", LocaleService.getLocale());
					return false;
				}
			}
		}
		catch (Exception e) {
			DfLogger.debug(this, " :: disbursementAmntValidation : Exception :"+e.getMessage(),null,null);
			errorStringforExceptions=e.getMessage();
			return false;
			}
		
		return true;
	}

	/**
	 * @param currentProjectId
	 */
	private int fetchProjectStageNumber(String currentProjectId) {
		String projectStageNbrQry = IdocsUtil.getMessage("QRY_PROJECT_STAGE_NBR");
		projectStageNbrQry = projectStageNbrQry.replaceFirst(QRY_VARIABLE_PROJECTID, currentProjectId);
		int stageNbr = 0;
		try {
			IDfCollection stageNbrColl = IdocsUtil.executeQuery(getDfSession(), projectStageNbrQry, DfQuery.DF_READ_QUERY);
			while (stageNbrColl.next()) {
				stageNbr = Integer.parseInt(stageNbrColl.getString(IDocsConstants.MSG_STAGE_NBR));
			}
			if(stageNbrColl != null)stageNbrColl.close();
			
			
		} catch (DfException e) {
			DfLogger.error(this, " :: fetchProjectStageNumber "+e.getMessage(),null,null);
		}
		DfLogger.info(this, " :: fetchProjectStageNumber : stageNbr: "+ stageNbr, null,null);
		return stageNbr;
	}
	
	/**
	 * 
	 * @param isASTemplates
	 * @param templateCode
	 * @param objectId
	 * @return
	 * @throws Exception
	 */
	private boolean checkASWorkflowStatus(boolean isASTemplates,
			String tempCategory, String objectId, boolean initateWorkFlow) throws Exception {

		boolean flag = false;

		if (isASTemplates) {
			IDfDocument doc = null;
			String projectId = null;
			if (null != objectId && "" != objectId) {
				doc = (IDfDocument) getDfSession().getObject(new DfId(objectId));
				projectId = doc.getString(m_nlsResourceBundle.getString("MSG_PROJECT_ID", LocaleService.getLocale()));
				DfLogger.error(this," :: checkASWorkflowStatus :: project id for AS Wokflow:  " + projectId, null, null);
			}
		try {
			if (null != projectId && projectId.trim().length() > 0) {
				/*if(tempCategory.equals(IDocsConstants.MSG_AS_PDP_SUPERVISION_TEMPCODE) || tempCategory.equals(IDocsConstants.MSG_AS_PDP_IMPL_PLAN_TEMPCODE) ){
					flag = true;
					DfLogger.info(this," checkASWorkflowStatus :: PDP Documents Start Work flow enabled flag "+flag,null, null);
				}else{*/
					Document document = canCreateServletCall(projectId,getDfSession(), tempCategory);
					XPathFactory xPathFactory = XPathFactory.newInstance();
					XPath xPath = xPathFactory.newXPath();


					XPathExpression permExpression = xPath.compile("/update/permission");
					String createPermission = permExpression.evaluate(document);
					DfLogger.info(this, " :: checkASWorkflowStatus : create permission : " + createPermission, null, null);

					XPathExpression msgExpression = xPath.compile("/update/message");
					String message = msgExpression.evaluate(document);
					DfLogger.info(this, " :: checkASWorkflowStatus : message: " + message, null, null);
					// check document creation
					try {
						if (createPermission.equalsIgnoreCase("no")) {
							// Object params[] = new Object[1];
							// DfLogger.info(this,"Message is 111: ", null,
							// null);
							// params[0] =
							// DocbaseUtils.getValidationExceptionMsg(new
							// DfException(message));
							// DfLogger.info(this,"Message is 222: "+ params[0],
							// null, null);

							Label errorMessageLabel = (Label) getControl("message", Label.class);
							if (errorMessageLabel != null) {
								MESSAGE = "Error Message :" + message;
								DfLogger.debug(this," :: checkASWorkflowStatus : label set " + MESSAGE, null, null);
								errorMessageLabel.setLabel(MESSAGE);
							} else {
								DfLogger.debug(this," :: checkASWorkflowStatus : Control Not found " + MESSAGE, null, null);
							}

							flag = false;
						} else {
							DfLogger.info(this," checkASWorkflowStatus :: if createPermission is Yes. Providing option to start workflow ",null, null);
							flag = true;
						}

					} catch (Exception e) {
						DfLogger.error(this," :: checkASWorkflowStatus : Exception occured while reading servlet :: "+ e.getMessage(), null, null);
						flag = true;
					}

				/*}*/
			}else{
				DfLogger.debug(this," checkASWorkflowStatus :: projectId Value Null or Empty Value", null, null);
			}

		} catch (XPathExpressionException e) {
					e.printStackTrace();
				}
		}

		return flag;
	}



	/**
	 * This is a utility method to display WDK error messages from startWorkFlow component.
	 * This method gets the ErrorMessage for the current template and diplays that in the 
	 * iDocs application UI
	 * 
	 */
	private void displayErrorMessage(String errorMessageNls , boolean isNls){
		if(isNls){
			MESSAGE = m_nlsResourceBundle.getString(errorMessageNls, LocaleService.getLocale());
		}else{
			MESSAGE = errorMessageNls;
		}
		if(MESSAGE != null && MESSAGE.trim().length() >0){
			DfLogger.info(this,"NO Need to Update the Error Message",null,null);
		}else{
		   MESSAGE="Unexpected exception occured please contact Admin";
		}
		Label errorMessageLabel = (Label)getControl("message",Label.class);
		if(errorMessageLabel  != null ){
			DfLogger.debug(this, " :: displayErrorMessage : label set "+MESSAGE,null,null);
			errorMessageLabel.setLabel(MESSAGE);
		}else{
			DfLogger.debug(this, " :: displayErrorMessage : Control Not found "+MESSAGE,null,null);
		}
	}

	/**
	 * 
	 * @param project_id
	 * @param dfsess
	 * @param tempCategory
	 * @return
	 * @throws DfException
	 */
	private Document canCreateServletCall(String project_id, IDfSession dfsess,String tempCategory)throws DfException{

		//String project_id = parentFolder.getString(m_nlsResourceBundle.getString("MSG_PROJECT_ID", LocaleService.getLocale()));
		DfLogger.info(this," :: Project id::  " + project_id,null,null);

		//String validateQry = m_nlsResourceBundle.getString("AS_TEMP_VALID_QRY", LocaleService.getLocale());
		String validateQry = IdocsUtil.getMessage("AS_TEMP_VALID_QRY");
		IDfQuery qryObj = new DfQuery();
		qryObj.setDQL(validateQry);
		String basicUrl = "";
		Document doc = null;

		IDfCollection validateColl = qryObj.execute(dfsess, IDfQuery.DF_READ_QUERY);
		try{
			while(validateColl.next()){
				basicUrl = validateColl.getString("item_value");
				DfLogger.info(this," :: Basic url ::  " + basicUrl,null,null);
			}
		}
		finally{
			if(validateColl != null){
				validateColl.close();
			}
		}

		StringBuffer queryBuilder =  new StringBuffer(basicUrl);
		queryBuilder.append("task=caninitiate&temp_cat=").append(tempCategory).append("&project_id=").append(project_id);
		DfLogger.info(this," :: Full servlet URL  " + queryBuilder.toString(),null,null);
		try {
			URL urlObj = new URL(queryBuilder.toString());
			DocumentBuilderFactory buildFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = buildFactory.newDocumentBuilder();
			InputStream in  = urlObj.openStream();
			doc = docBuilder.parse(in);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return doc;
	}


	/** 
	 * Utility Method to check whether this user can start workflow for this document. 
	 * @param dfSession - IDfSession Object to the docbase
	 * @param objectId - r_object_id of the document.
	 * @return - true - If the user has the privilege to start the workflow
	 * 		   - fasle - If the user should not start a workflow with this document.
	 * @throws DfException - Exception incase of any errors
	 */
	private boolean checkBusinessRule(IDfSession dfSession, String objectId) throws DfException {
		boolean validated = false;
		IDfDocument doc = (IDfDocument) dfSession.getObject(new DfId(objectId));
		String objectName = doc.getObjectName();
		DfLogger.info(this, " checkBusinessRule : ObjectName : "+objectName+" objectType : "+doc.getTypeName(), null, null);
		if(doc.getTypeName().equals(IdocsConstants.PROJ_DOC_TYPE)){
			//String templateName = objectName.replace(doc.getString(m_nlsResourceBundle.getString("MSG_PROJECT_ID", LocaleService.getLocale()))+"_", IDocsConstants.MSG_EMPTY_STRING);
			String templateName = IdocsUtil.getTemplateTitle(getDfSession(),objectId);
			String templateCode = LinkToGHG.getTemplateCode(templateName, getDfSession());
			String currentProjectId = doc.getString(m_nlsResourceBundle.getString("MSG_PROJECT_ID", LocaleService.getLocale()));
			validated = LinkToGHG.isGHGCheckValidForDocument(currentProjectId, templateCode, getDfSession(), templateName);
			if(validated == false)	{
				b_MESSAGE = m_nlsResourceBundle.getString("GHG_EMISSION_ESTIMATION_NOT_AVAILABLE", LocaleService.getLocale());
				return false;
			}else {
				if(projectStageNbrValidation(currentProjectId, templateName) == false){
					DfLogger.info(this, " checkBusinessRule : templateName : "+templateName, null, null);
					//b_MESSAGE = m_nlsResourceBundle.getString("MSG_PROJECT_STAGE_NBR_INVALID", new Object[]{IdocsUtil.getMessage("MSG_PROJECT_STAGE_NBR_VALUE")}, LocaleService.getLocale());
					return false;
				}else{
					if(disbursementAmntValidation(currentProjectId, templateName,objectId) == false){
						return false;
					}
					else{
					
						DfLogger.info(this, " checkBusinessRule : templateName : "+templateName, null, null);
						validated = validateProjUserAccess(dfSession, templateName,currentProjectId,doc.getOwnerName());
					}
				}
			}
		}else{
			validated=true;
		}
		return validated;
	}

	/**
	 * 
	 * @param dfSession
	 * @param templateName
	 * @param projectId
	 * @return
	 */
	private boolean validateProjUserAccess(IDfSession dfSession,String templateName, String projectId,String ownerName) {
		DfLogger.debug(this, " :: validateUserAccess >> UserLoginName : "+templateName +" :: Project Id :"+projectId,null,null);
		boolean validated=false;
		DfQuery query = new DfQuery();
		try{
			
			/** SKIP IOM checks and allow only owner_name to start workflow */
			if(IdocsUtil.getMessage("MSG_INTERNAL_OFFICE_MEMORANDUM").equals(templateName)){
				if(ownerName.equalsIgnoreCase(getDfSession().getLoginUserName())== true ){
					return true ;
				}else{
					b_MESSAGE = new StringBuilder().append(IOM_WORKFLOW_INITIATION_ERROR_PREF).append(ownerName).toString();
					return false;
				}
			}
        			
			String role=IDocsConstants.MSG_EMPTY_STRING;
			String projMemberQry = IDocsConstants.MSG_EMPTY_STRING;
			String userName=dfSession.getLoginUserName();
			DfLogger.info(this, " :: validateUserAccess : UserLoginName : "+userName,null,null);
			IDfCollection coll = null;
			boolean isException = false;
			try{
				String strQry = IdocsUtil.getMessage("QRY_TEMPLATE_INFO_STARTWF");
				String templateQry = strQry.replaceFirst("''", "'"+templateName+"'");
				DfLogger.info(this, " :: validateUserAccess : templateQry : " + templateQry, null, null);
				query.setDQL(templateQry);
				coll=query.execute(dfSession,IDfQuery.DF_READ_QUERY);
			}catch (Exception e) {
				DfLogger.info(this, " :: validateUserAccess : Query Execution failed : Try Second Query", null, null);
				isException = true;
				String templateQry = IdocsUtil.getMessage("QRY_TEMPLATE_INFO");
				templateQry = templateQry.replaceFirst("''", "'"+templateName+"'");
				DfLogger.info(this, " :: validateUserAccess : templateQry : " + templateQry, null, null);
				// execute query
				query.setDQL(templateQry);
				coll=query.execute(dfSession,IDfQuery.DF_READ_QUERY);
			}
			/*String templateQry = idocsProperties.getProperty("QRY_TEMPLATE_INFO");
    		templateQry = templateQry.replaceFirst("''", "'"+templateName+"'");
    		DfLogger.info(this, " :: validateUserAccess : templateQry : " + templateQry, null, null);
    		// execute query
    		query.setDQL(templateQry);
    		IDfCollection coll=query.execute(dfSession,IDfQuery.DF_READ_QUERY);*/
			if(coll.next()){

				//b_MESSAGE=coll.getString(m_nlsResourceBundle.getString("MSG_WORKFLOW_ERROR_MESSAGE", LocaleService.getLocale()));
				if(isException){
					b_MESSAGE = "User Is Not Allowed To Start The Workflow";
				}else{
					b_MESSAGE=coll.getString(m_nlsResourceBundle.getString("MSG_ERROR_MESSAGE", LocaleService.getLocale()));
				}
				// b_MESSAGE = "User Is Not Allowed To Start The Workflow";
				role=coll.getString(m_nlsResourceBundle.getString("MSG_ROLE", LocaleService.getLocale()));
				coll.close();
			}
			
			/*
			 * Advisory Services Changes - START 
			 */
			if(IdocsUtil.isAdvisoryTemplate(templateName)){
				
				DfLogger.debug(this, " :: validateProjUserAccess : Advisory Template : "+templateName,null,null);
				
				/*String projectTeamQry =idocsProperties.getProperty("PROJECT_TEAM_MEMBERS_QRY");
				projectTeamQry = projectTeamQry.replaceAll("%projectid%", projectId);
				
				List<String> projectTeamList = IdocsUtil.dfCollectionToArrayList(IdocsUtil.executeQuery(dfSession, projectTeamQry, DfQuery.READ_QUERY), IdocsConstants.USER_NAME);
				
				if(projectTeamList.contains(dfSession.getLoginUserName())){
					return true;
				}else{
					return false;
				}*/
				
				boolean isAsProjectTeamMember = false;
				try{
					isAsProjectTeamMember = IdocsUtil.checkASProjectTeam(projectId, dfSession);
				}catch (Exception e) {
					DfLogger.debug(this, "Advisory Template : Exception in checkASProjectTeam : "+e.getMessage(),null,null);
				}
				return isAsProjectTeamMember;
			}
			/*
			 * Advisory Services Changes - END 
			 */
			
			
			
			if(role.equalsIgnoreCase("All")){
				validated=true;
			}else if(role.equalsIgnoreCase("None")){
				validated=false;
			}else if(role.startsWith(IDocsConstants.MSG_RESTART_ONLY)){
				String restrtRoleArray [] = role.split(":"); //RestartOnly:TransactionLeader,Portfolio Officer
				if(restrtRoleArray !=null && restrtRoleArray .length > 1){
					String restrtRoles = restrtRoleArray[1];
					if(IdocsUtil.checkProjectInstiTeamMemberShip(restrtRoles, projectId, dfSession)){
						DfLogger.debug(this, "This is a restart only request. Role validation Success", null, null);
						validated = true;
					}else{
						DfLogger.debug(this, "This is a restart only request. But role validation Failed", null, null);
						validated = false;
					}
				}else{
					DfLogger.debug(this, "This is a restart only request. But role is not present in Template Info table", null, null);
					validated=false;
				}				
			}else{
				boolean userPresentInLDAPGroup = IdocsUtil.isUserMemberofLDAPGroup(
						role, projectId, dfSession);
				if (userPresentInLDAPGroup == true) {
					return true;
				} else {
					DfLogger.debug(IdocsUtil.class,"User is not present in LDAP Group. COntinue with Direct User Membership",null, null);
				}
				role=role.replaceAll(",", "','");
				projMemberQry = IdocsUtil.getMessage("QRY_PROJ_MEMBER");
				projMemberQry = projMemberQry.replaceFirst("''", "'"+projectId+"'");
				projMemberQry = projMemberQry.replaceFirst("''", "'"+role+"'");
				projMemberQry = projMemberQry.replaceFirst("''", "'"+IdocsUtil.handleSingleQuote(userName)+"'");
				DfLogger.info(this, " :: validateUserAccess : projMemberQry : " + projMemberQry, null, null);


				// execute query
				query.setDQL(projMemberQry);
				//DfLogger.info(this, " :: validateUserAccess : Check User Role Query :"+projMemberQry,null,null);
				coll=query.execute(dfSession,IDfQuery.DF_READ_QUERY);
				if(coll.next()){
					// b_MESSAGE=m_nlsResourceBundle.getString("ERR_TMPL_VALIDATION", LocaleService.getLocale());
					validated=true;
					coll.close();
				}
			}
			if(coll != null)coll.close();
		}catch(DfException e){
			DfLogger.error(this, " :: validateProjUserAccess Exception >>> "+e.getMessage(),null,null);
		}
		return validated;
	}

	/**
	 * 
	 * @param control
	 * @param args
	 */
	public void onClose(Button control, ArgumentList args){
		setComponentReturn();
	}


	/**
	 * This method initiates the corresponding workflow for the selected document
	 * 
	 * @param dfSession - IDfSession Object to the docbase
	 * @param objectId - r_object_id of the document
	 * @throws DfException - Exception in case of any errors
	 */
	public void initiateWF(IDfSession dfSession, String objectId)
	throws DfException{

		String process_id = getProcessId(objectId);
		DfLogger.info(this," :: initiateWF : process_id : "+process_id,null,null);
		IDfWorkflowBuilder idfworkflowbuilder = new DfWorkflowBuilder(dfSession, new DfId(process_id));
		DfLogger.info(this," :: initiateWF : Workflow Builder : ",null,null);
		idfworkflowbuilder.initWorkflow();
		DfLogger.info(this," :: initiateWF : initWorkflow : ",null,null);
		idfworkflowbuilder.runWorkflow();
		DfLogger.info(this," :: initiateWF : runWorkflow : "+process_id,null,null);
		IDfWorkflow idfworkflow = idfworkflowbuilder.getWorkflow();
		DfLogger.info(this," :: initiateWF : workflow name : "+idfworkflow.getObjectName(),null,null);
		IDfList activity_name_list = idfworkflowbuilder.getStartActivityNames();
		IDfList activity_id_list = idfworkflowbuilder.getStartActivityIds();
		IDfId activity_id = (IDfId)activity_id_list.get(0);
		IDfActivity idfactivity = (IDfActivity)dfSession.getObject(activity_id);
		IDfId package_id = null;
		DfList dflist = new DfList();
		int i = 0;
		String port_name = IDocsConstants.MSG_EMPTY_STRING;
		String activity_name = activity_name_list.getString(0);
		for(i = 0; i < idfactivity.getPortCount(); i++){
			if(idfactivity.getPortType(i).equals("INPUT")){
				port_name = idfactivity.getPortName(i);
			}
		}

		for(i = 0; i < idfactivity.getPackageCount(); i++){
			if(idfactivity.getPortType(i).equals("INPUT")){
				if(idfactivity.getPackageType(i).equals(IdocsConstants.PROJ_DOC_TYPE) 
						|| idfactivity.getPackageType(i).equals(IdocsConstants.IDOCS_DOC_TYPE) 
						|| idfactivity.getPackageType(i).equals(IdocsConstants.INSTITUTION_DOC_TYPE) 
						||  idfactivity.getPackageType(i).equals(IdocsConstants.COUNTRY_DOC_TYPE)){
					dflist.append(new DfId(objectId));
					package_id = idfworkflow.addPackage(activity_name, port_name, idfactivity.getPackageName(i),
							idfactivity.getPackageType(i), null, false, dflist);
				}else{
					dflist.removeAll();
					package_id = idfworkflow.addPackage(activity_name, port_name, idfactivity.getPackageName(i), 
							idfactivity.getPackageType(i), null, false, dflist);
				}
			}
		}
		MESSAGE = m_nlsResourceBundle.getString("MSG_WORKFLOW_STARTED", LocaleService.getLocale());
		DfLogger.info(this, " :: initiateWF: Invoke updateStatus method", null, null);
		updateStatus(getDfSession(), objectId);
		DfLogger.info(this," :: initiateWF : WorkflowId : "+idfworkflow.getObjectId().getId()+
				" with Package Id : "+package_id.getId(),null,null);
	}

	/**
	 * This method gets the r_object_id of the workflow based on the template
	 * @param objectId
	 * @return
	 */
	public String getProcessId(String objectId){
		String process_id = IDocsConstants.MSG_EMPTY_STRING;
		try {
			String strGetTemplateTitleQuery = IdocsUtil.getMessage("QRY_GET_TEMPLATE_TITLE_N_PID");
			strGetTemplateTitleQuery = strGetTemplateTitleQuery.replaceFirst(IdocsConstants.MSG_C_DQ_C, IdocsConstants.MSG_QUOTES+objectId+IdocsConstants.MSG_QUOTES);
			IDfCollection collection = IdocsUtil.executeQuery(getDfSession(), strGetTemplateTitleQuery, IDfQuery.DF_READ_QUERY);
			String strTemplateTitle = null;
			String strprojectId= null;
			while(collection.next()){
				strTemplateTitle = collection.getString(IDocsConstants.MSG_TEMPLATE_TITLE);
				strprojectId = collection.getString(IdocsConstants.PROJ_ID);
			}
			if(collection != null )collection.close();
			String rightsIssueTemplateTitleName = IdocsUtil.getMessage("MSG_RIGHTS_ISSUE_TEMPLATE_TITLE");
			if(rightsIssueTemplateTitleName !=null && strTemplateTitle !=null && strprojectId!=null
					&& rightsIssueTemplateTitleName.trim().length()>0 && strTemplateTitle.trim().length()>0 && strprojectId.trim().length()>0
					&& rightsIssueTemplateTitleName.equalsIgnoreCase(strTemplateTitle)){
				DfLogger.info(this," :: getProcessId : Template is : "+rightsIssueTemplateTitleName,null,null);
				String strSouCode = getSouCodeFromProjectId(strprojectId);
				if(strSouCode!=null && strSouCode.trim().length() >0){
					String nonCSOSouCodes = IdocsUtil.getMessage("MSG_NON_CSO_VALUES");
					if(IdocsUtil.checkIfTokenPresent(nonCSOSouCodes,strSouCode,",")){
						/** Start NON CSO */
						String nonCSOProcessName = IdocsUtil.getMessage("MSG_RIGHTS_ISSUE_NON_CSO_PROCESS_NAME");
						process_id = getInstalledProcessId(nonCSOProcessName);
					}else{
						/** Start CSO */
						String CSOProcessName = IdocsUtil.getMessage("MSG_RIGHTS_ISSUE_CSO_PROCESS_NAME");
						process_id = getInstalledProcessId(CSOProcessName);
					}
				} else{
					DfLogger.error(this," :: getProcessId : SOU_CODE is NULL : Exception ",null,null);
				}
			}else{
				//idocsProperties.load(StartWorkflow.class.getResourceAsStream(IdocsConstants.IDOCS_PROPERTY_FILE));
				String wfProcessIdQryStr = IdocsUtil.getMessage("QRY_PROCESS_TEMPLATE_ID");
				wfProcessIdQryStr = wfProcessIdQryStr.replaceFirst("''", IdocsConstants.MSG_QUOTES+objectId+ IdocsConstants.MSG_QUOTES);
				DfLogger.info(this," :: getProcessId : QRY_PROCESS_TEMPLATE_ID : "+wfProcessIdQryStr,null,null);
				IDfQuery wfProcessIdQryObj = new DfQuery(wfProcessIdQryStr);
				IDfCollection wfProcessIdColl = wfProcessIdQryObj.execute(getDfSession(), IDfQuery.DF_READ_QUERY);
				if(wfProcessIdColl.next()){
					process_id = wfProcessIdColl.getString(IDocsConstants.MSG_R_OBJECT_ID);
					wfProcessIdColl.close();
				}
				if(wfProcessIdColl != null)wfProcessIdColl.close();
			}
		} catch (DfException e) {
			DfLogger.error(this," :: getProcessId Exception>> "+e.getMessage(),null,e);
		} 
		return process_id;
	}

	/**
	 * This method is to get the installed Process's objectId
	 * @param strProcessName - Name of the process
	 * @return
	 */
	private String getInstalledProcessId(String strProcessName) {
		try{
			String strGetProcessQuery = IdocsUtil.getMessage("QRY_INSTALLED_PROCESS_ID");
			strGetProcessQuery = strGetProcessQuery.replaceFirst(IdocsConstants.MSG_C_DQ_C, IdocsConstants.MSG_QUOTES+strProcessName+IdocsConstants.MSG_QUOTES);
			IDfCollection collection = IdocsUtil.executeQuery(getDfSession(), strGetProcessQuery , IDfQuery.DF_READ_QUERY);
			String strProcessId = null;
			while(collection.next()){
				strProcessId= collection.getString(IDocsConstants.MSG_R_OBJECT_ID);
			}
			if(collection != null)collection.close();
			return strProcessId;
		}catch (Exception e) {
			DfLogger.error(this," :: getInstalledProcessId : "+e.getMessage(),null,null);
		}
		return null;
	}


	/**
	 * This utility method is to get the sou code from the project
	 * @param strprojectId - Id of the project.
	 * @return
	 */
	private String getSouCodeFromProjectId(String strprojectId) {
		String strSouCode= null;
		try{
			String strGetSouCodeQuery = IdocsUtil.getMessage("QRY_GET_CSO_FROM_PROJECT");
			strGetSouCodeQuery = strGetSouCodeQuery.replaceFirst(IdocsConstants.MSG_C_DQ_C,  IdocsConstants.MSG_QUOTES+strprojectId+IdocsConstants.MSG_QUOTES);
			IDfCollection collection = IdocsUtil.executeQuery(getDfSession(), strGetSouCodeQuery, IDfQuery.DF_READ_QUERY);
			while(collection.next()){
				strSouCode = collection.getString(IDocsConstants.MSG_SOU_CODE);
			}
			if(collection != null)collection.close();
		}catch (Exception e) {
			DfLogger.error(this," :: getSouCode : Exception "+e.getMessage(),null,null);
		}
		DfLogger.debug(this," :: getSouCode : strSouCode= "+strSouCode,null,null);
		return strSouCode;
	}

	/**
	 * This method updates the workflow_status attribute of the document during workflow 
	 * initiation process
	 * @param dfSession - IDfSession Object to the docbase
	 * @param objectId - r_object_id of the document
	 */
	private void updateStatus(IDfSession dfSession, String objectId) {
		try {
			IDfDocument doc = (IDfDocument) dfSession.getObject(new DfId(objectId));
			doc.setString("workflow_status", "Started");
			doc.save();
			IdocsUtil.auditIDocsActivity(MSG_INITIATED_WORKFLOW,objectId,dfSession);    
		} catch (DfException e) {
			DfLogger.error(this," :: updateStatus Exception>> " + e.getMessage(),null,e);
		}

	}

	public String MESSAGE = IDocsConstants.MSG_EMPTY_STRING;
	public String b_MESSAGE = IDocsConstants.MSG_EMPTY_STRING;
	private boolean isDocCheckedOut = false;
	private static final long serialVersionUID = 1L;
	private static NlsResourceBundle m_nlsResourceBundle = null;
	private static String m_WorkflowNlsProp = "org.ifc.idocs.workflow.startworkflow.StartCustomWorkflowTaskNlsProp";
	private static String replaceProductNBRSting ="'<product_nbr>'";
	private static String replaceDisbursmentWorkflowNBRSting ="'<disbursment_workflow_nbr>'";
	private static String replaceCommitmentWorkflowNBRSting ="'<commitment_workflow_nbr>'";
	static {
		m_nlsResourceBundle = new NlsResourceBundle(m_WorkflowNlsProp);
	}
	private String errorStringforExceptions="";
}