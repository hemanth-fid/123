/**
* This class displays 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.workflow.taskmanager;


import java.util.Map;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.services.workflow.inbox.IWorkflowTask;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.webcomponent.common.WebComponentErrorService;

public class AcceptWorkflowTaskAction extends com.documentum.webcomponent.library.workflow.taskmanager.AcceptWorkflowTaskAction {
	private static final long serialVersionUID = 1L;
	private static final String R_COMPONENT_ID = "r_component_id";
    String strLockOwner=null;

    public AcceptWorkflowTaskAction() {
	}

    
	public boolean execute(String strAction, IConfigElement config, ArgumentList args, Context context, Component component, Map completionArgs)
    {
		try {
			DfLogger.info(this, " :: execute : "+component.getDfSession().getLoginUserName(), null, null);
			if(canPeformOnThisTask(args, component)){
				DfLogger.debug(this, " :: onInit GO AND AQUIRE IT ", null, null);
				super.execute(strAction, config, args, context, component, completionArgs);
			}else{
				displayErrorMessages(component);
				DfLogger.debug(this, " :: onInit Exception displayErrorMessages : Component Returning ", null, null);
				component.setComponentReturn();
				return false;
			}
		} catch(Exception e) {
			DfLogger.error(this, " :: onInit Exception >> "+e.getMessage(), null, e);
		}
        return true;
    }
	
	/**
	 * to display error messages
	 * @param component
	 */
	
	private void displayErrorMessages(Component component) {
		DfException ex = new DfException();
		ex.setMessage("The task is locked by " + strLockOwner + "."+ " Please try after sometime.");
		WebComponentErrorService.getService().setNonFatalError(component,"MSG_ERROR", ex);
	}
	
	public boolean canPeformOnThisTask(ArgumentList args,Component component){
	 try {
			String strQueueItemId = args.get("objectId");
			IWorkflowTask wtask = getWorkflowTask(component, strQueueItemId);
			/** updated by sudhakar on 28/08/2012 to get only form Id*/
			if (wtask.getType() == 4) {
				DfLogger.info(this, "Queue Item ID : :" + strQueueItemId,null,null);
				String formId = "";
				String r_package_name="";
				IDfCollection dfCollection = null;//
				String quryFormId=IdocsUtil.getMessage("QRY_WRK_GET_FORM_ID");
				quryFormId=quryFormId.replace(WORKITEM_ID, IdocsConstants.MSG_QUOTES+wtask.getItemId()+IdocsConstants.MSG_QUOTES);
				dfCollection=IdocsUtil.executeQuery(component.getDfSession(), quryFormId, IDfQuery.DF_READ_QUERY);
				DfLogger.info(this, "work item Id ::"+wtask.getItemId(), null,null);
				while (dfCollection.next()) {
					r_package_name= dfCollection.getString(IDocsConstants.STR_R_PACKAGE_NME);
					if(!r_package_name.startsWith(R_PACKAGE_NAME_VALUE_FOR_WRK_DOCS)){
						formId = dfCollection.getString(R_COMPONENT_ID);
						DfLogger.info(this, "r_package_name : : : ::" +r_package_name,null,null);
						DfLogger.info(this, "Form ID : : : ::" + formId,null,null);
						}
					}
				if(dfCollection != null)dfCollection.close();
				String lockOwnerQuery=IdocsUtil.getMessage("QRY_WRK_FROM_LOCK_OWNER");
				lockOwnerQuery=lockOwnerQuery.replace(STR_REPLEACE_OBJECT_ID,IdocsConstants.MSG_QUOTES+formId+IdocsConstants.MSG_QUOTES);
				DfLogger.info(this ,"Form Lock Owner Query"+lockOwnerQuery,null,null);
				dfCollection=IdocsUtil.executeQuery(component.getDfSession(), lockOwnerQuery, IDfQuery.DF_READ_QUERY);
				while(dfCollection.next()){
					strLockOwner= dfCollection.getString(IdocsConstants.R_LOCK_OWNER);
				}
				if(dfCollection != null) dfCollection.close();
				/** updated by sudhakar on 28/08/2012 to get only form Id*/
				DfLogger.info(this, "Lock owner : : :: : :" + strLockOwner,null,null);
				String strCurrentUser = component.getDfSession().getLoginUserName();
				DfLogger.info(this, "Current User Name  : : :: : :"+ strCurrentUser,null,null);
				DfLogger.info(this, " : form Id Value  :: " + formId,null,null);
				if (strLockOwner!=null && strLockOwner.trim().length() > 0 &&
						strCurrentUser.equalsIgnoreCase(strLockOwner) == false) {
					DfLogger.info(this, " : displayErrorMessages IN TASK MANAGER ::" + formId,null,null);
					return false;
				} else {
					return true;
				}
			}
		} catch (DfException e) {
			throw new WrapperRuntimeException(e);
		}
		return false;
	}
	String R_PACKAGE_NAME_VALUE_FOR_WRK_DOCS="Project";
	private static final String WORKITEM_ID="'<workItemId>'";
	private static final String STR_REPLEACE_OBJECT_ID="'<objectId>'";
	
}