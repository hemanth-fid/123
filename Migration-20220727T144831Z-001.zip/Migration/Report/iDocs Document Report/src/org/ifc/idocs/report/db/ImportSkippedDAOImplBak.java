package org.ifc.idocs.report.db;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Logger;

import org.ifc.idocs.report.common.LogHelper;

public class ImportSkippedDAOImplBak extends DBFactory{
	
	private static Calendar calender = null;
	private Logger exportDocLogger = LogHelper.getLogger(ImportSkippedDAOImpl.class);
	private int start = 0, end = 1000, max = 0, docDiff = 0;
	private Set<String> missingSet = new HashSet<String>();
	private long st = 0, et = 0;
	
//	public static void main(String args[]) throws SQLException, IOException{
//		ImportSkippedDAOImpl iSkipped = new ImportSkippedDAOImpl();
//		iSkipped.importSkipped("28OCT11");
//	}
	
	public void importSkipped(String prefix) throws IOException, NumberFormatException, SQLException{
		try{
			calender = Calendar.getInstance();
			st = calender.getTimeInMillis(); 
			idocsProperties.load(inputStream);
			getConnection();
			getDocumentReport(prefix + "_PRJ", "PROJECTS");		
			start = 0; end = 1000;
			getDocumentReport(prefix + "_PTR", "INSTITUTIONS");
			
			conn.close();
			conn = null;
			
			calender = Calendar.getInstance();
			et = calender.getTimeInMillis();
			exportDocLogger.warning("Total Time in Minutes : " + (et - st)/60000);
			System.gc();
		}catch(IOException ioe){
			ioe.printStackTrace();
		}catch(NumberFormatException nfe){
			nfe.printStackTrace();
		}catch(SQLException sqle){
			sqle.printStackTrace();
		}
	}

	public void getDocumentReport(String prefix, String folderTypeCode) throws SQLException{
		String maxQry = "SELECT MAX(TO_NUMBER(FOLDER_VALUE_CODE)) FROM RECON_SECURITY_REPORT WHERE (FOLDER_TYPE_CODE != 'COUNTRY') AND FOLDER_TYPE_CODE='" + folderTypeCode + "' AND REPORT_UTILITY_CODE LIKE '" + prefix + "%'";
		max = Integer.parseInt(getMaxLimit(maxQry));
		exportDocLogger.warning("Max Limit : " + max);
//		max = 1000;

		executeQuery(prefix, folderTypeCode);
		if(missingSet.size() > 0){
			updateImportSkipped(prefix, missingSet);
		}
		missingSet.clear();
	}

	private void executeQuery(String prefix, String folderTypeCode) throws SQLException {
		while(max >= end){
			String query1 = "SELECT DISTINCT SOURCE_DOC_UNIQUE_ID FROM RECON_SECURITY_REPORT WHERE FOLDER_VALUE_CODE IN " +
				"(SELECT DISTINCT FOLDER_VALUE_CODE FROM RECON_SECURITY_REPORT WHERE (FOLDER_TYPE_CODE != 'COUNTRY') " +
				"AND TO_NUMBER(FOLDER_VALUE_CODE) > " + start + " AND TO_NUMBER(FOLDER_VALUE_CODE) < " + end + " AND FOLDER_TYPE_CODE='" + folderTypeCode + "' " +
				"AND REPORT_UTILITY_CODE LIKE '" + prefix + "%') AND REPORT_UTILITY_CODE LIKE '" + prefix + "%' AND FOLDER_TYPE_CODE='" + folderTypeCode + "'";
			
			String query2 = "SELECT DISTINCT DOC_UNID FROM IMPORT_COMPLETED_DOCS WHERE FOLDER_VALUE_CODE IN " +
				"(SELECT DISTINCT FOLDER_VALUE_CODE FROM IMPORT_COMPLETED_DOCS WHERE TO_NUMBER(FOLDER_VALUE_CODE) > " + start + 
				" AND TO_NUMBER(FOLDER_VALUE_CODE) < " + end + " AND FOLDER_TYPE_CODE='" + folderTypeCode + "' AND REPORT_UTILITY_CODE LIKE '" + prefix + "%') " +
				"AND REPORT_UTILITY_CODE LIKE '" + prefix + "%' AND FOLDER_TYPE_CODE='" + folderTypeCode + "'";
					
			Set<String> sourceSet = new HashSet<String>(fireQuery(query1));
			Set<String> destSet = new HashSet<String>(fireQuery(query2));
			sourceSet.removeAll(destSet);
			exportDocLogger.warning("From " + start + " To " + end + " : "+ sourceSet.size());
			start = end;
			end = end + 1000;
			docDiff = docDiff + sourceSet.size();
			missingSet.addAll(sourceSet);
			System.gc();
		}		
	}

	private void updateImportSkipped(String setCode, Set<String> missingSet) throws SQLException {
		Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		conn.setAutoCommit(false);
		for(String docUnid : missingSet){
			stmt.addBatch("INSERT INTO IMPORT_SKIPPED_DOCS VALUES ('" + setCode + "', '" + docUnid + "')");
		}
		int[] updateCounts = stmt.executeBatch();
		exportDocLogger.warning("Document Report saved : " +  updateCounts.length);
		stmt.close();
		conn.commit();
		System.gc();

	}

	private Set<String> fireQuery(String qry) throws SQLException {
		Set<String> returnVal = new HashSet<String>();
//		exportDocLogger.warning(qry);
		PreparedStatement stmt = conn.prepareStatement(qry);
		rs = stmt.executeQuery();
		while (rs.next()){
			returnVal.add(rs.getString(1));			
		}
		rs.close();
		stmt.close();
		conn.commit();
		conn.close();
		conn = null;
		getConnection();
		return returnVal;
	}

	private String getMaxLimit(String qry) throws SQLException{
		String returnVal = null;
//		exportDocLogger.warning(qry);
		PreparedStatement stmt = conn.prepareStatement(qry);
		rs = stmt.executeQuery();
		while (rs.next()){
			returnVal = rs.getString(1);			
		}
		rs.close();
		stmt.close();
		return returnVal;
	}
}
