/*package org.ifc.idocs.library.actions;

import java.util.Properties;

import javax.servlet.jsp.PageContext;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.utils.IdocsConstants;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Form;
import com.documentum.web.formext.action.IActionPrecondition;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
public class ChangePermissionPreCondition implements IActionPrecondition  {

	IDfDocument newDoc = null;
	private static Properties idocsProperties = new Properties();
	public String[] getRequiredParams() {
		DfLogger.info(this,"::  getRequiredParameters : " , null, null);
		return null;		
	} 
	

	public boolean queryExecute(String strAction, IConfigElement config, ArgumentList arg, Context context, Component component) {
		
		boolean preconditionValue=false;
		try{
			idocsProperties.load(ChangePermissionPreCondition.class.getResourceAsStream(IdocsConstants.IDOCS_PROPERTY_FILE));			
			
			Form form = (Form) component.getPageContext().getAttribute(Form.FORM, PageContext.REQUEST_SCOPE);
			ArgumentList args = form.getInitArgs();		
			String strObjectId = args.get("objectId");			
			String strObjectType = IDocDocbaseAttributeTagUtility.getSysObjectAttribute(component.getDfSession(),
					strObjectId,IdocsConstants.R_OBJECT_TYPE);			
			String strObjectPermit = arg.get("permit");		
			
			DfLogger.info(this,":: CHANGE PERMIT Id:"+ strObjectId + " ::Type: " + strObjectType + " ::Permit:" + strObjectPermit , null, null);
			String strDocState = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(component.getDfSession(),
					strObjectId,IDocsConstants.MSG_DOC_STATE,strObjectType);
			DfLogger.info(this,"::  Document State : " + strDocState, null, null);
			*//** If the document is country allow user to edit the permissions  *//*
			if(strObjectType!=null && strObjectType.trim().length() > 0 
					&& strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_COUNTRY_DOC)){
				return true;
			}
			
			*//** If the document state is released nobody is allowed to modify the ACL *//*
			if( strDocState != null && strDocState.equalsIgnoreCase(IdocsConstants.DOC_STATE_RELEASED)== true ){
				return false;
			}
			DfLogger.info(this, " :: DocState loop is done: ",null,null);
			String strOwnerName = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(component.getDfSession(),
					strObjectId,IDocsConstants.MSG_OWNER_NAME,strObjectType);
			*//** For non 'Released' Documents owners are allowed to edit the ACl *//*
			if(strOwnerName!=null && strOwnerName.equalsIgnoreCase(component.getDfSession().getLoginUserName()) == true ){
				return true;
			}
			
			*//** For non 'Released' documents only specific users are allowed to edit the ACL. *//*
			String currentSecurityClassificationCode = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(component.getDfSession(),
					strObjectId,IDocsConstants.MSG_SEC_CLASSIFICATION_CODE,strObjectType);
			DfLogger.info(this, " :: currentSecurityClassificationCode: "+ currentSecurityClassificationCode,null,null);
			
			preconditionValue=PermissionPreConditionUtility.callPermissionPreCondition(component.getDfSession(),strObjectId,strObjectType,strDocState,strOwnerName,currentSecurityClassificationCode,idocsProperties);
			
		}catch (Exception e) {
			DfLogger.info(this, " :: Exception:"+e.getMessage(),null,null);
		}
	      return preconditionValue;
	   }		
	}
			
			if(IDocsConstants.MSG_OFFICIAL_CODE.equals(currentSecurityClassificationCode)){
				projectRole = idocsProperties.getProperty("PROJECT_CHANGE_PERMIT_ROLE_O");
				projectRole=projectRole.replaceAll(",", "','");
				DfLogger.info(this, " :: projectRole value: "+ projectRole,null,null);
			}else if(IDocsConstants.MSG_CONFIDENTIAL_CODE.equals(currentSecurityClassificationCode)){
				projectRole = idocsProperties.getProperty("PROJECT_CHANGE_PERMIT_ROLE_C");
				projectRole.replaceAll(",", "','");
			}else if(IDocsConstants.MSG_STRICTLY_CONFIDENTIAL_CODE.equals(currentSecurityClassificationCode)){
				projectRole = idocsProperties.getProperty("PROJECT_CHANGE_PERMIT_ROLE_S");
				projectRole.replaceAll(",", "','");
			}else{
				DfLogger.info(this, " :: Exception: Unknown Security Classigication Code : "+currentSecurityClassificationCode,null,null);
			}
			DfLogger.info(this, " :: projectRole value: "+ projectRole,null,null);
			if(projectRole != null && projectRole.trim().length() > 0 ){
				return checkMemberShip(component.getDfSession(), strObjectId, strObjectType,projectRole);				
			}else{
				return true;
			}
		}catch (Exception e) {
			DfLogger.info(this, " :: Exception:"+e.getMessage(),null,null);
		}
		return false;
	}

	private boolean checkMemberShip(IDfSession dfSession,
			String strObjectId, String strObjectType,
			String role){
		boolean validated = false;
		String strInstitutionNumberOrProjectId = null;
		try{
			String strMemberRoleQry = null;
			if(strObjectType != null && strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_INSTITUTION_DOC)){
				strMemberRoleQry = idocsProperties.getProperty("QRY_INSTITUTION_MEMBER");
				strInstitutionNumberOrProjectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(dfSession,
						strObjectId,IdocsConstants.MSG_INSTITUTION_NBR,strObjectType);
			}else if(strObjectType != null && strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_PROJECT_DOC)){
				strMemberRoleQry = idocsProperties.getProperty("QRY_PROJ_MEMBER");
				strInstitutionNumberOrProjectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(dfSession,
						strObjectId,IdocsConstants.PROJ_ID,strObjectType);
			}
			strMemberRoleQry = strMemberRoleQry.replaceFirst("''", "'"+strInstitutionNumberOrProjectId+"'");
			strMemberRoleQry = strMemberRoleQry.replaceFirst("''", "'"+role+"'");
			strMemberRoleQry = strMemberRoleQry.replaceFirst("''", "'"+dfSession.getLoginUserName()+"'");
			
			// execute query
			IDfQuery query = new DfQuery();
			query.setDQL(strMemberRoleQry);
			DfLogger.info(this, " :: validateUserAccess : Check User Role Query :"+strMemberRoleQry,null,null);
			IDfCollection coll=query.execute(dfSession,IDfQuery.DF_READ_QUERY);
			if(coll.next()){
				validated=true;
				coll.close();
			}
		}catch (Exception e) {
			DfLogger.info(this, " :: validateUserAccess : Exception :"+e.getMessage(),null,null);
		}
		return validated;
	}

	public boolean checkRoleMembership(IDfSession dfSession,String projectRole,String projectId) {
		IDfCollection coll=null;
	    boolean validated = false;
	    try {
			String rolePermissionQry = idocsProperties.getProperty("QRY_PROJ_MEMBER");
			rolePermissionQry = rolePermissionQry.replaceFirst("''", "'"+projectId+"'");
			rolePermissionQry = rolePermissionQry.replaceFirst("''", "'"+projectRole+"'");
			rolePermissionQry = rolePermissionQry.replaceFirst("''", "'"+dfSession.getLoginUserName()+"'");
			DfLogger.info(this, " :: validateUserAccess : projMemberQry : " + rolePermissionQry, null, null);

			// execute query
			IDfQuery query = new DfQuery();
			query.setDQL(rolePermissionQry);
			DfLogger.info(this, " :: validateUserAccess : Check User Role Query :"+rolePermissionQry,null,null);
			coll=query.execute(dfSession,IDfQuery.DF_READ_QUERY);
			if(coll.next()){				
				validated=true;
				coll.close();
			}
		} catch (DfException e) {
			DfLogger.error(this, " :: validateUserAccess : Exception : " + e.getMessage(), null, null);
		}
		DfLogger.error(this, " :: validateUserAccess : validated = " + validated, null, null);
		return validated;
	}
	
	

	
*/