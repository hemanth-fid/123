/**
* This class is to navigate the documetn to the folder.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Parag Doshi		    10/17/2010	     1.0          Created

* #######################################################################################################
*//*
package org.ifc.idocs.navigate;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.component.Component;

public class NavigateToFolder extends Component {
	private static final long serialVersionUID = 899939303857886345L;
	public static String STR_PROJ_INSTITUTIONS_QRY = null;
	public void onInit(ArgumentList args) {
		super.onInit(args);
		String institutionsNbr = args.get("institutionsNbr");
		DfLogger.debug(this,"institutionsNbr is :: "+institutionsNbr,null,null);
		String parentFldId = getParentId(institutionsNbr);
		DfLogger.debug(this,"folder id is :: "+parentFldId,null,null);
		// redirect to folder tree for parentFldId
		args.add("folderId",parentFldId);
		setComponentJump("main", args, getContext());
	}

	private String getParentId(String institutionsNbr) {
		IDfSession session = getDfSession();
		String fldId = null;
		DfLogger.info(this, "institutionsNbr is::" + institutionsNbr, null, null);
		try {
			IDfSysObject syso = (IDfSysObject) session
					.getObjectByQualification("idocs_institution_folder where object_name like '" + institutionsNbr + "%'");
			if (syso != null) {
				fldId = syso.getString("i_folder_id");
				DfLogger.info(this,"folder id is ::" + fldId, null, null);
			} else {
				DfLogger.info(this,"unable to find the document with the institutions with Nbr::" + institutionsNbr, null, null);
			}
		} catch (DfException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return fldId;
	}

	public void onRender() {
		super.onRender();
	}

}
*/