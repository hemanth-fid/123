package org.ifc.idocs.forms.adaptors;
import com.documentum.fc.common.DfLogger;
import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.IAdaptorParameter;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.xforms.engine.adaptor.datasource.ISetValueAdaptor;
public class SetDecisionChoice implements ISetValueAdaptor {

public Object execute(IAdaptorParameter[] parameters)
   throws AdaptorException {
	  String ChoiceValue = "";
	  try
	  {
	  	DfLogger.info(this,"SetDecisionChoice:: execute :: ",null,null); 
	   	DfLogger.info(this,"Parameter Values : "+parameters.length,null,null); 
		  
	   	for (int i=0;i<parameters.length;i++)
	   	{
	   		DfLogger.info(this,"Inside for: "+parameters[i].getValue(),null,null);
	   		if (null!=parameters[i].getValue()&& !"".equals(parameters[i].getValue()))
	   			ChoiceValue=parameters[i].getValue();
	   	}
	   	  	  
		  DfLogger.info(this,"Choice Value : "+ChoiceValue,null,null);
		  return ChoiceValue;
	  }
	  catch(Exception exception)
	  {
		  throw new AdaptorException(exception);
	  }
}

 public void destroy() throws AdaptorException {
 }

 public void init(IAdaptorConfiguration iAdaptorConfiguration) throws AdaptorException {
	 DfLogger.info(this,"SetDecisionChoice.init()",null,null);

 }
}