package org.ifc.idocs.environment.actions;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.clipboard.IClipboardPasteHandler;
import com.documentum.web.formext.component.Component;

// Referenced classes of package com.documentum.webcomponent.environment.actions:
//            MoveAction, HereActionHelper

public class MoveHereAction extends org.ifc.idocs.environment.actions.IDocsMoveAction
{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MoveHereAction()
    {
		DfLogger.info(this, " :: MoveHereAction : Constructor",null,null);
    }

    public String[] getRequiredParams()
    {
    	DfLogger.info(this, " :: getRequiredParams",null,null);
        return HereActionHelper.getRequiredParams();
    }

    IClipboardPasteHandler getClipboardPasteHandler(ArgumentList args, Component component)
    {
    	DfLogger.info(this, " :: getClipboardPasteHandler : args.get(objectId): "+args.get("objectId"),null,null);
        return HereActionHelper.getClipboardPasteHandler(args, component);
    }
}


