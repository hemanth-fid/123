/**
 * PCHW070In_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W;

public class PCHW070In_Type  implements java.io.Serializable {
    private gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070InHdr_Type PCHW070InHdr;

    private java.lang.String VENDORNO;

    private java.lang.String INDEPT1;

    public PCHW070In_Type() {
    }

    public PCHW070In_Type(
           gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070InHdr_Type PCHW070InHdr,
           java.lang.String VENDORNO,
           java.lang.String INDEPT1) {
           this.PCHW070InHdr = PCHW070InHdr;
           this.VENDORNO = VENDORNO;
           this.INDEPT1 = INDEPT1;
    }


    /**
     * Gets the PCHW070InHdr value for this PCHW070In_Type.
     * 
     * @return PCHW070InHdr
     */
    public gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070InHdr_Type getPCHW070InHdr() {
        return PCHW070InHdr;
    }


    /**
     * Sets the PCHW070InHdr value for this PCHW070In_Type.
     * 
     * @param PCHW070InHdr
     */
    public void setPCHW070InHdr(gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070InHdr_Type PCHW070InHdr) {
        this.PCHW070InHdr = PCHW070InHdr;
    }


    /**
     * Gets the VENDORNO value for this PCHW070In_Type.
     * 
     * @return VENDORNO
     */
    public java.lang.String getVENDORNO() {
        return VENDORNO;
    }


    /**
     * Sets the VENDORNO value for this PCHW070In_Type.
     * 
     * @param VENDORNO
     */
    public void setVENDORNO(java.lang.String VENDORNO) {
        this.VENDORNO = VENDORNO;
    }


    /**
     * Gets the INDEPT1 value for this PCHW070In_Type.
     * 
     * @return INDEPT1
     */
    public java.lang.String getINDEPT1() {
        return INDEPT1;
    }


    /**
     * Sets the INDEPT1 value for this PCHW070In_Type.
     * 
     * @param INDEPT1
     */
    public void setINDEPT1(java.lang.String INDEPT1) {
        this.INDEPT1 = INDEPT1;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PCHW070In_Type)) return false;
        PCHW070In_Type other = (PCHW070In_Type) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.PCHW070InHdr==null && other.getPCHW070InHdr()==null) || 
             (this.PCHW070InHdr!=null &&
              this.PCHW070InHdr.equals(other.getPCHW070InHdr()))) &&
            ((this.VENDORNO==null && other.getVENDORNO()==null) || 
             (this.VENDORNO!=null &&
              this.VENDORNO.equals(other.getVENDORNO()))) &&
            ((this.INDEPT1==null && other.getINDEPT1()==null) || 
             (this.INDEPT1!=null &&
              this.INDEPT1.equals(other.getINDEPT1())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPCHW070InHdr() != null) {
            _hashCode += getPCHW070InHdr().hashCode();
        }
        if (getVENDORNO() != null) {
            _hashCode += getVENDORNO().hashCode();
        }
        if (getINDEPT1() != null) {
            _hashCode += getINDEPT1().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PCHW070In_Type.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "PCHW070In_Type"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PCHW070InHdr");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "PCHW070InHdr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "PCHW070InHdr_Type"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("VENDORNO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "VENDORNO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("INDEPT1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "INDEPT1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
