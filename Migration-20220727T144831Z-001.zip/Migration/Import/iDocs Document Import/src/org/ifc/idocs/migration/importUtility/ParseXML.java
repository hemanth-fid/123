package org.ifc.idocs.migration.importUtility;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.logging.Level;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.ifc.idocs.migration.helper.UpdateDB;
import org.ifc.idocs.migration.helper.Utilities;
import org.ifc.idocs.migration.updateReferences.UpdateTAASDB;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfUser;
import com.documentum.fc.common.DfException;

/**
 * ParseXML - Parsing XML for every document and calling other functions to update the values and import the documents. 
 * @author HAnuganti
 * 
 * #############################################################################################
 * Author		            DateofChange	 Version	  ModificationHistory
 * ###########################################################################################
 * Hemachandra Anuganti 
 * ###########################################################################################
 * 
 */
public class ParseXML extends ImportUtility {

	/**
	 * get xml from the resultset
	 * @param getMigrationInf
	 * @param location
	 * @param extractionId
	 * @param impUniqId
	 */
	
	private static HashMap documentAuditHM = new HashMap();
	public static void getXML(String legacyDocId, String folderType, String folderCode,String location, String extractionId, String impUniqId)
	{
		// get xml path
		//importDocLogger.info("Executing generateXMLPath(location,folderType,folderCode,legacyDocId, extractionId)"+ParseXML.class);
		xmlPath = generateXMLPath(location,folderType,folderCode,legacyDocId,extractionId);
		IDfCollection selectDocumentAuditInfo = null;
		IDfCollection insertDocumentAuditInfo = null;
		File xmlFilePath = new File(xmlPath);
		if(xmlFilePath.exists()){
			
			//Check for Total Number of documents Uploaded and recycle the docbase session
/*			if(totalDocsCount == Integer.parseInt(idocsProperties.getProperty("MSG_RECYCLE_SESSION_DOC_CNT"))){
				importDocLogger.warning("Recycling and Getting Docbase Session again......!");
				//Recycle the Docbas Session
				try {
					if(dfSession.isConnected()){
						dfSession.disconnect();
//						sessionMgr.release(dfSession);
					}
					
					//Re Initialize the Docbase Session
					ImportUtility.initializeSession();
					importDocLogger.warning("New Docbase Session Established Successfully......!");
				} catch (DfException e) {
					// TODO Auto-generated catch block
					importDocLogger.warning("DfException During Recreating the Docbase Session");
					importDocLogger.log(Level.WARNING,"DfException During Recreating the Docbase Session::", e);
					e.printStackTrace();
				}
			}*/

			//parse xml and import
			if(parseCurrentXML(xmlPath,folderType)){
				//final update of the region info table
//				documentCount++;
				//Updating DB for document audit trail entries
				//importDocLogger.info("*****************************************************************************************************");	
				Iterator it = documentAuditHM.keySet().iterator();
				while(it.hasNext()) { 
				String legacyIdwithVersion = it.next().toString(); 
				String versionLabel;
				String legacyIdFinal;
				String[] versionLength=legacyIdwithVersion.split("  ");
				legacyIdFinal=versionLength[0];
				versionLabel=versionLength[1];	
				String queryString = documentAuditHM.get(legacyIdwithVersion).toString();
		 		StringTokenizer strTokenizerdctmInQuery=new StringTokenizer(queryString,"$$$$");
				String qrySelectDocumentAuditTable = idocsProperties.getProperty("MSG_DOC_DOCUMENT_AUDIT_SELECT");
				qrySelectDocumentAuditTable=qrySelectDocumentAuditTable.replaceAll("'<legacy_doc_id>'","'" + legacyIdFinal + "'");
				qrySelectDocumentAuditTable=qrySelectDocumentAuditTable.replaceAll("'<versionLabel>'","'" + versionLabel + "'");
				String strFailedQuery = "";
				try {
					selectDocumentAuditInfo = Utilities.executeQuery(dfSession, qrySelectDocumentAuditTable, IDfQuery.DF_EXEC_QUERY);
					while (selectDocumentAuditInfo.next())
					{
						String dctmObjID = selectDocumentAuditInfo.getString("r_object_id");
						while(strTokenizerdctmInQuery.hasMoreTokens())
						{
						String strQuery=strTokenizerdctmInQuery.nextToken();
						strQuery=strQuery.replaceAll("<dctmObjectID>",dctmObjID);
						strFailedQuery = "";
						strFailedQuery = strQuery;
						insertDocumentAuditInfo = Utilities.executeQuery(dfSession, strQuery, IDfQuery.DF_EXEC_QUERY);
						}
					}
					//importDocLogger.info("*****************************************************************************************************");
					if(insertDocumentAuditInfo !=null && selectDocumentAuditInfo!=null)
						{
						insertDocumentAuditInfo.close();
						selectDocumentAuditInfo.close();
//						insertDocumentAuditInfo = null;
//						selectDocumentAuditInfo = null;
						//importDocLogger.info("Closed the collections insertDocumentAuditInfo & insertDocumentAuditInfo");
						} 
				} catch (DfException e) {
					// TODO Auto-generated catch block
					importDocLogger.warning("Audit Query::"+strFailedQuery);
					importDocLogger.warning("Failed Query String::"+queryString);
					importDocLogger.warning("Failed XML path::"+xmlPath);
					importDocLogger.warning("Documentum doc ID::"+e.getMessage());
					importDocLogger.log(Level.WARNING,"DfException during audit uploads for the document::"+xmlFilePath, e);
					e.printStackTrace();
				}
				}
				//importDocLogger.info("Clearing the Hashmap");
				documentAuditHM.clear();
				uploadedDocCnt++;
				importDocLogger.warning("Successfully Uploaded documents count::"+uploadedDocCnt);
			}else{
				//importDocLogger.info("parseCurrentXML(xmlPath,folderType method returned FALSE");
				if(queryString5 != ""){
					Utilities.addToArrayList(queryString5.toString());
//2222					UpdateDB.updateDatabase(queryString5.toString());
				}				
				//importDocLogger.info("Udating the rollback attribute to false::"+queryString5);
			}
		}else{
			
			importDocLogger.warning("Meta data XML does not existing for the XML path::"+xmlPath);
//			failedXMLList.addElement(xmlPath);
			
			//Update Region table with Rollback required flag if source document not found in the system.
			if(queryString5 != ""){
				Utilities.addToArrayList(queryString5.toString());
			}
			if(skipped_fldValue_code == null){
				skipped_fldValue_code = "";
			}else if(skipped_fldType_code == null){
				skipped_fldType_code = "";
			}
			//Make Entry in Migration Skipped documents table as folder is not found
			String skippedDocQry = idocsProperties.getProperty("MIG_SKIPPED_DOCS_QUERY")
									.replaceAll("<UTILITY_CODE>", impUniqId)
										.replaceAll("<FOLDER_TYPE_CODE>", skipped_fldType_code)
											.replaceAll("<FOLDER_VALUE_CODE>", skipped_fldValue_code)
												.replaceAll("<DOCUMENT_ID>", legacyDocId)
													.replaceAll("<ERROR_CODE>", idocsProperties.getProperty("MIG_ERROR_CODE_28"));
			skippedDocQry = skippedDocQry+"Source document Metadata XML :: "+xmlPath+" :: could not be located')";											
			importDocLogger.warning("Source document Metadata XML :: "+xmlPath+" :: could not be located");											
			Utilities.addToArrayList(skippedDocQry.toString());
		}
	}
	/**
	 * parse the XMl from the XML path
	 * @param flag
	 * @param xmlPath
	 * @param folderType
	 */
	private static boolean parseCurrentXML(String xmlPath, String folderType) {

		boolean flag = false;
		DocumentBuilderFactory docBuilderFactory;
        DocumentBuilder docBuilder;
        String legacyIDvalue="";
        Document doc;
		try {
			//get XML document
			docBuilderFactory = DocumentBuilderFactory.newInstance();
			docBuilder = docBuilderFactory.newDocumentBuilder();
			doc = docBuilder.parse (new File(xmlPath));

			//get list of nodes for version
			NodeList listOfVersions = doc.getElementsByTagName(idocsProperties.getProperty("MSG_DomdocDocument"));
			NodeList sortlistOfVersions = doc.getElementsByTagName(idocsProperties.getProperty("MSG_DomdocDocument"));

			NodeList legacyIDlist = doc.getElementsByTagName(idocsProperties.getProperty("MSG_DocumentBundle"));
			Node legacyNode=legacyIDlist.item(0);
			if(legacyNode.getNodeType()==Node.ELEMENT_NODE)	{
				Element legacyIDelt=(Element)legacyNode;
				legacyIDvalue=legacyIDelt.getAttribute("docid");				
			}
	        int totalVersions = listOfVersions.getLength();
	        attributeValueList = new HashMap[totalVersions];
	        
	     // Code  Version value from the DomDocDocument tag and populate array
			String[] arrDocVersion = new String[totalVersions];
			for(int ver=0; ver<totalVersions; ver++){
				Node versionNode1 = sortlistOfVersions.item(ver);
				if(versionNode1.getNodeType() == Node.ELEMENT_NODE){
					Element versionElement1 = (Element)versionNode1;
					String legacyDocVer=versionElement1.getAttribute("version");
					arrDocVersion[ver] = legacyDocVer;
				}
			}
			// Call sort version method to sort version as per document management system 0.1 0.2 0.10
			ArrayList listSortedVersion  =sortVersion(arrDocVersion);
			
			
	        for(int s=0; s<totalVersions; s++){
	        	Node versionNode = listOfVersions.item(s);
	        	if(versionNode.getNodeType() == Node.ELEMENT_NODE){
	        		HashMap hm = new HashMap();
	                Element versionElement = (Element)versionNode;
	                String legacyIDvalue1=versionElement.getAttribute("version");
	             // Get index value of the version tag to keep in right sequence 
					int intVersionIndex = listSortedVersion.indexOf(legacyIDvalue1);
	                //update attribute value list hashmap from xmlParse function
	                attributeValueList[intVersionIndex] = xmlParse(versionElement, hm, legacyIDvalue);
	            }
	        }
	        	//importDocLogger.info("Executing UpdateValues.updateAttrHM(0,folderType) method");

	        	//UpdateValueClass
	        	if(!attrData.isEmpty()){
//	        		importDocLogger.warning("attrData hashmap is not empty::");
	        		attrData.clear();
	        	}
	        	if(UpdateValues.updateAttrHM(0)){
		        	//Import The Files.
		        	if(ImportDocument.importFile(totalVersions)){
		        		flag = true;
		            }else{
		            	importDocLogger.warning("Utility Faied to Upload the document in importFile");
		            	flag = false;
		            }
	        	}else{
	        		importDocLogger.warning("Utility Faied to Update the Folder attributes in updateAttrHM");
	        		flag = false;
	        	}

		}catch(IndexOutOfBoundsException ioe){
			// TODO Auto-generated catch block
//	    	System.out.println("qryFinalInsertDocumentAuditTable::"+qryFinalInsertDocumentAuditTable);
			importDocLogger.warning("IOException ::"+ioe.getMessage());
			importDocLogger.log(Level.WARNING,"IOException during parsing the xml::"+xmlPath, ioe);
			ioe.printStackTrace();
			raiseXMLParsingException(ioe);
			flag = false;
		} catch (ParserConfigurationException pce) {
			// TODO Auto-generated catch block
			importDocLogger.warning("ParserConfigurationException ::"+pce.getMessage());
			importDocLogger.log(Level.WARNING,"ParserConfigurationException during parsing the xml::"+xmlPath, pce);
			pce.printStackTrace();
			raiseXMLParsingException(pce);
			flag = false;
		} catch (SAXException saxe) {
			// TODO Auto-generated catch block
			importDocLogger.warning("SAXException ::"+saxe.getMessage());
			importDocLogger.log(Level.WARNING,"SAXException during parsing the xml::"+xmlPath, saxe);
			saxe.printStackTrace();
			raiseXMLParsingException(saxe);
			flag = false;
		} catch (DOMException dome) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DOMException ::"+dome.getMessage());
			importDocLogger.log(Level.WARNING,"DOMException during parsing the xml::"+xmlPath, dome);
			dome.printStackTrace();
			raiseXMLParsingException(dome);
			flag = false;
		}catch (IOException ie) {
			// TODO Auto-generated catch block
			importDocLogger.warning("IOException ::"+ie.getMessage());
			importDocLogger.log(Level.WARNING,"IOException during parsing the xml::"+xmlPath, ie);
			ie.printStackTrace();
			raiseXMLParsingException(ie);
			flag = false;
		} catch (DfException dfe) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException ::"+dfe.getMessage());
			importDocLogger.log(Level.WARNING,"DfException during parsing the xml::"+xmlPath, dfe);
			dfe.printStackTrace();
			raiseXMLParsingException(dfe);
			flag = false;
		}
		return flag;
	}


	/**
	 * Sort the version value as per document management system
	 */
	
	private static ArrayList sortVersion(String strVersion[]){
		String strDocVer = "";
	
		ArrayList finalSortList = new ArrayList();
		HashMap mapMajorMinor = new HashMap();
		String strMajorVer ="";
		List listMinor = new ArrayList();
		int strVerLength = 0;
		if(strVersion.length>0 && strVersion != null){
			Arrays.sort(strVersion);
			String tmpMajorValue= (strVersion[0].split("\\."))[0];
			strVerLength = strVersion.length;
			for(int index=0; index < strVerLength ; index++) {
				strDocVer= strVersion[index];
				String[] splitVersion = strDocVer.split("\\.");
				strMajorVer = splitVersion[0];
				String strMinorVer = splitVersion[1];
				if(strMajorVer.equals(tmpMajorValue)){
					listMinor.add(Integer.valueOf(strMinorVer));
				}else {
					Collections.sort(listMinor);
					mapMajorMinor.put(tmpMajorValue, listMinor);
					tmpMajorValue= strMajorVer;
					listMinor = new ArrayList();
					listMinor.add(Integer.valueOf(strMinorVer));
				}
			}
			Collections.sort(listMinor);
			mapMajorMinor.put(tmpMajorValue, listMinor);
		
			//------------------------------------
		
			Set setver = mapMajorMinor.keySet();
			Iterator t = setver.iterator();
			Integer[] key = new Integer[setver.size()];
			int j=0;
			while(t.hasNext()){
				key[j++] = Integer.valueOf((String)t.next());
			}
			Arrays.sort(key);
			int keyLength = key.length;
			for(int count=0;count<keyLength;count++){
			String s = key[count].toString();
		
			ArrayList listMinorVer = (ArrayList)mapMajorMinor.get(s);
			//Collections.sort(listMinorVer);
			Iterator t1 = listMinorVer.iterator();
		
			while(t1.hasNext()){
				String strSort = s+"."+t1.next();
				finalSortList.add(strSort);
			}
			}
			}else {
	
		}
		return finalSortList;
	}

	/*private static ArrayList sortVersion(String strVersion[]){
		String strDocVer = "";

		ArrayList finalSortList = new ArrayList();
		HashMap mapMajorMinor = new HashMap();
		String strMajorVer ="";
		List listMinor = new ArrayList();

		if(strVersion.length>0 && strVersion != null){
			Arrays.sort(strVersion);
			String tmpMajorValue= (strVersion[0].split("\\."))[0];

			for(int index=0; index < strVersion.length ; index++)    
			{
				strDocVer= strVersion[index];
				String[] splitVersion = strDocVer.split("\\.");
				strMajorVer = splitVersion[0];
				String strMinorVer = splitVersion[1];
				if(strMajorVer.equals(tmpMajorValue)){
					listMinor.add(Integer.valueOf(strMinorVer));
				}else {
					Collections.sort(listMinor);
					mapMajorMinor.put(tmpMajorValue, listMinor);
					tmpMajorValue= strMajorVer;
					listMinor = new ArrayList();
					listMinor.add(Integer.valueOf(strMinorVer));
				}
			}
			Collections.sort(listMinor);
			mapMajorMinor.put(tmpMajorValue, listMinor);
			Set setver = mapMajorMinor.keySet();
			Iterator t = setver.iterator();
			while(t.hasNext()){
				String key = (String)t.next();
				ArrayList listMinorVer = (ArrayList)mapMajorMinor.get(key);
				Collections.sort(listMinorVer);
				Iterator t1 = listMinorVer.iterator();

				while(t1.hasNext()){
					String strSort = key+"."+t1.next();
					finalSortList.add(strSort);
				}
			}
		}else {
			importDocLogger.log(Level.WARNING,"ParseXML.java sortVersion method .. No version Available ");
		}
		return finalSortList;
	}*/
	
	/**
	 * parsing the XML and populating Hashmap
	 */
	private static HashMap xmlParse(Element elem, HashMap hm, String legacyIDvalue) throws IndexOutOfBoundsException,DfException,DOMException{
		
		//importDocLogger.info("inside xmlParse(Element elem, HashMap hm)"+ParseXML.class);
		String CSV = "";
		String legacyUNID = elem.getAttribute(idocsProperties.getProperty("MSG_DOCUNID"));
		String verLabel=elem.getAttribute(idocsProperties.getProperty("MSG_VERSION"));
		String legacyParentID=legacyIDvalue+"  "+verLabel;			
		String qryFinalInsertDocumentAuditTable =  "";
		StringBuffer sbFinalString = new StringBuffer("");
		hm.put(idocsProperties.getProperty("MSG_VERSION"), elem.getAttribute(idocsProperties.getProperty("MSG_VERSION")));
		hm.put("legacyUNID", legacyUNID);
		NodeList list = elem.getChildNodes();
//		try{
		for(int i=0;i<list.getLength();i++){
         	Node firstPersonNode = list.item(i);
             if(firstPersonNode.getNodeType() == Node.ELEMENT_NODE){
                 Element firstPersonElement = (Element)firstPersonNode;
                 NodeList textFNList = firstPersonElement.getChildNodes();
                 int length = textFNList.getLength();
                 switch(length){
	                 case 1 : 	String key = firstPersonElement.getNodeName();
	                 			textFNList = firstPersonElement.getElementsByTagName(idocsProperties.getProperty("MSG_VALUE_TAG"));
	                 			String value = textFNList.item(0).getChildNodes().item(0).getNodeValue().trim();
			         			if (value.contains("/")){
			         				value = value.replace("/", "\\");
			         			}if(key.equals(idocsProperties.getProperty("MSG_AUTHORORSENDER"))){
			         				hm.put(idocsProperties.getProperty("MSG_SENDER"), value);
			         			}if(key.equals(idocsProperties.getProperty("MSG_CREATOR"))){
			         				String FiledByKey = "FiledBy";
			         				value = value.replaceAll("'", "''");
			         				IDfUser userName = (IDfUser) dfSession.getObjectByQualification("dm_user where (user_os_name like'%"+value+"' or user_name='"+value+"')");
			         				if(userName == null){
				         				hm.put(FiledByKey, value);
			        					value = dfSession.getLoginUserName().toString();
			         				}else{
				        				value = userName.getUserName();
				         				hm.put(FiledByKey, value);
			         				}
			        			}
			         			
			        	 		hm.put(key, value);
			        	 		break;
	                 case 0 : 	hm.put(firstPersonElement.getNodeName(),"");
	                	 		continue;
	                 default :  key = firstPersonElement.getNodeName();
				      			NodeList activityList = firstPersonElement.getElementsByTagName(idocsProperties.getProperty("MSG_VALUE_TAG"));
				      			int count = activityList.getLength();
				      			for(int j=0;j<count;j++){
				     				NodeList newList = textFNList.item(j).getChildNodes();
				     				int newLength = newList.getLength();
				     				switch(newLength){
					     				case 1: if(textFNList.item(j).getChildNodes().item(0) != null){
					     							CSV = CSV + textFNList.item(j).getChildNodes().item(0).getNodeValue().trim() + "#" ;
							     				}
					     						break;
					     				case 0:  break;
					     				default : HashMap newHM = new HashMap();
					     						  for(int x=0;x<newLength;x++){
						     						  if(newList.item(x).getChildNodes().item(0) != null){
								     						key = newList.item(x).getNodeName().toString();
								     						value = newList.item(x).getChildNodes().item(0).getNodeValue().trim();
								     						if (value.contains("/") && key!="Date"){
										         				value = value.replace("/", "\\");
										         			}
									     					newHM.put(key, value);
									     			  }
					     						  }
					     						 String actor = "";
							         			   if(newHM.get(idocsProperties.getProperty("MSG_ACTOR"))!=null){
								         			   actor = newHM.get(idocsProperties.getProperty("MSG_ACTOR")).toString();
							         			   }else{
							         				   actor="";
							         			   }if (actor.contains("'")){
					     							  actor = actor.replaceAll("'", "''");
								         		   }
									               String action = "";
							         			   if(newHM.get(idocsProperties.getProperty("MSG_ACTION"))!=null){
							         				   action = newHM.get(idocsProperties.getProperty("MSG_ACTION")).toString();
							         			    }else{
							         				   action="";
							         			    }
							         			  
									            	action = action.replaceAll("'", "''");
									            	action = action.replaceAll("\\$", " Dollars ");
//									            	action = action.replaceAll("[^a-zA-Z 0-9]+",""); 
									            	String timeStamp =   (String) newHM.get("Date");
									            	String qryInsertDocumentAuditTable=idocsProperties.getProperty("MSG_DOC_AUDIT_QUERY");
									            	qryInsertDocumentAuditTable = qryInsertDocumentAuditTable.replaceFirst("'<timestamp>'", "DATE('" + timeStamp + "','mon/dd/yyyy hh:mi:ss AM z')");
									            	if(action.length()<128){
									            		
									            		qryInsertDocumentAuditTable = qryInsertDocumentAuditTable.replaceFirst("'<action>'", "'" + action + "'");
									            	}else{
									            		action = action.substring(0, 128);
									            		qryInsertDocumentAuditTable = qryInsertDocumentAuditTable.replaceFirst("'<action>'", "'" + action + "'");
									            	}
									            	actor = actor.replaceAll("'", "''");
									            	actor = actor.replaceAll("\\$", " Dollars ");
//									            	System.out.println("Issue::"+qryInsertDocumentAuditTable.replaceFirst("<actor>",actor));
									            	qryInsertDocumentAuditTable = qryInsertDocumentAuditTable.replaceFirst("'<actor>'", "'" + actor+ "'");
									            	sbFinalString.append(qryInsertDocumentAuditTable+"$$$$");
//									            	qryFinalInsertDocumentAuditTable=qryFinalInsertDocumentAuditTable+qryInsertDocumentAuditTable+"$$$$";
//									            	System.out.println("qryInsertDocumentAuditTable::"+qryInsertDocumentAuditTable);
//									            	System.out.println("qryFinalInsertDocumentAuditTable::"+qryFinalInsertDocumentAuditTable);
				     				}
			 	            	}
				      			documentAuditHM.put(legacyParentID,sbFinalString.toString());

				      			//Iterating HM for testing
				     			if (CSV.contains("/")){
			         				value = CSV.replace("/", "\\");
			         			}
				     			hm.put(key, CSV);
				     			CSV="";
				}
             }
         }
	/*}catch(IndexOutOfBoundsException ioe){
		// TODO Auto-generated catch block
//    	System.out.println("qryFinalInsertDocumentAuditTable::"+qryFinalInsertDocumentAuditTable);
		importDocLogger.warning("IOException ::"+ioe.getMessage());
		importDocLogger.log(Level.WARNING,"IOException during parsing the xml::"+xmlPath, ioe);
		ioe.printStackTrace();
		raiseXMLParsingException();
	} catch (DfException e) {
		// TODO Auto-generated catch block
		importDocLogger.warning("IOException ::"+e.getMessage());
		importDocLogger.log(Level.WARNING,"IOException during parsing the xml::"+xmlPath, e);
		e.printStackTrace();
		raiseXMLParsingException();
	}catch (DOMException e) {
		// TODO Auto-generated catch block
		importDocLogger.warning("DOMException ::"+e.getMessage());
		importDocLogger.log(Level.WARNING,"DOMException during parsing the xml::"+xmlPath, e);
		e.printStackTrace();
		raiseXMLParsingException();
	}*/
		return hm;
	}
	private static void raiseXMLParsingException(Exception e) {
		// TODO Auto-generated method stub
		String skippedReason = "Unable to parse the XML::["+xmlPath+"]";
		skippedReason = skippedReason.replaceAll("'", "''");
		skippedReason = skippedReason+"')";
		
		Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_53"),skippedReason);
		e.printStackTrace();
	}
	/**
	 * Generate XML path to be parsed
	 * @param location
	 * @param folderType
	 * @param legacy_id
	 * @param extractionId 
	 */
	private static String generateXMLPath(String location,String folderType,String folderCode,String legacy_id, String extractionId) {
		//importDocLogger.info("inside generateXMLPath(String location,String folderType,String folderCode,String legacy_id)"+ParseXML.class);
		if("COUNTRY".equals(folderType)){
			folderType = idocsProperties.getProperty("MSG_PATH_CTRY");
		}
		sourceRoot = config.getString("path.extractionPath")+"\\"+extractionId+"\\"+folderType+"\\"+folderCode+"\\";
		StringBuffer xmlPath = new StringBuffer();
		xmlPath.append(sourceRoot).append(legacy_id);
		xmlPath.append(idocsProperties.getProperty("MSG_METADATA_XML_EXTN"));
//		System.out.println(xmlPath.toString());
		return xmlPath.toString();
	}
}
