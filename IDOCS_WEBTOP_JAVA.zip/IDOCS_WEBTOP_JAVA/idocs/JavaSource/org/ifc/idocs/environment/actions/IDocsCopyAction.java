package org.ifc.idocs.environment.actions;

import java.util.Map;

import org.ifc.idocs.utils.IDocsClipboardPasteHandler;

import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.clipboard.IClipboard;
import com.documentum.web.formext.clipboard.IClipboardPasteHandler;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.webcomponent.environment.actions.CopyAction;

public class IDocsCopyAction extends CopyAction {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public boolean execute(String strAction, IConfigElement config,
			ArgumentList args, Context context, Component component,
			Map completionArgs) {
		boolean bExecutionSucceded = false;
		String[] cliboarItems = null;
		String nlsprop = config.getChildValue("nlsbundle");
		NlsResourceBundle nlsResBndl = new NlsResourceBundle(nlsprop);

		IClipboard clipboard = component.getClipboard();
		IClipboardPasteHandler clipPasteHandler = component
				.getClipboardPasteHandler();

		if (clipPasteHandler != null) {
			if (clipboard.hasItems() == true) {
				cliboarItems = clipboard.getItemIds();
				IDocsClipboardPasteHandler idocsClipPasteHandler = new IDocsClipboardPasteHandler(
						component, clipPasteHandler.getDestinationId());
				for (int i = 0; i < cliboarItems.length; i++) {
					idocsClipPasteHandler.onPasteAsCopy(cliboarItems[i]);
				}
				bExecutionSucceded = true;
			}
		}else {
			throw new IllegalArgumentException("Invalid Component");
		}
		return bExecutionSucceded;
	}
}
