/**
 * PCHW078ServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W;

public class PCHW078ServiceLocator extends org.apache.axis.client.Service implements gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078Service {

    public PCHW078ServiceLocator() {
    }


    public PCHW078ServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public PCHW078ServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for PCHW078ServicePort
    private java.lang.String PCHW078ServicePort_address = "http://ibmtst.metro-dade.com:4004/CICS/TWBA/CSIWKI2X/PCHW078W";

    public java.lang.String getPCHW078ServicePortAddress() {
        return PCHW078ServicePort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String PCHW078ServicePortWSDDServiceName = "PCHW078ServicePort";

    public java.lang.String getPCHW078ServicePortWSDDServiceName() {
        return PCHW078ServicePortWSDDServiceName;
    }

    public void setPCHW078ServicePortWSDDServiceName(java.lang.String name) {
        PCHW078ServicePortWSDDServiceName = name;
    }

    public gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078ServicePort_Type getPCHW078ServicePort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(PCHW078ServicePort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getPCHW078ServicePort(endpoint);
    }

    public gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078ServicePort_Type getPCHW078ServicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078ServiceBindingStub _stub = new gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078ServiceBindingStub(portAddress, this);
            _stub.setPortName(getPCHW078ServicePortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setPCHW078ServicePortEndpointAddress(java.lang.String address) {
        PCHW078ServicePort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078ServicePort_Type.class.isAssignableFrom(serviceEndpointInterface)) {
                gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078ServiceBindingStub _stub = new gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078ServiceBindingStub(new java.net.URL(PCHW078ServicePort_address), this);
                _stub.setPortName(getPCHW078ServicePortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("PCHW078ServicePort".equals(inputPortName)) {
            return getPCHW078ServicePort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "PCHW078Service");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW078W", "PCHW078ServicePort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("PCHW078ServicePort".equals(portName)) {
            setPCHW078ServicePortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
