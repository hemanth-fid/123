package org.ifc.idocs.forms.adaptors;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.IAdaptorParameter;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import com.documentum.xforms.engine.adaptor.datasource.ISetValueAdaptor;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfLogger;

import java.io.InputStream;
import java.util.Properties;

/**
* CheckIPSEventDate - Adaptor to check IPS Event date in Project Event table.
* @author DShivnani
* 
* #####################################################################
* Author		DateofChange 		Version 	ModificationHisotry
* #####################################################################
* 
* #####################################################################
*/

public class CheckIPSEventDate implements ISetValueAdaptor {

	public Object execute(IAdaptorParameter[] parameters) throws AdaptorException {
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		String propertiesFile = "/idocsProps.properties";
		Properties idocsProperties = new Properties();
	    InputStream inputStream = CheckIPSEventDate.class.getResourceAsStream(propertiesFile);
	    String strQuery = null;
	    IDfSession session = null;
	    try
		{
	        idocsProperties.load(inputStream);
	        strQuery = idocsProperties.getProperty("IPS_EVENT_QRY");
			strQuery = strQuery.replaceFirst("''", "'"+parameters[0].getValue()+"'");
			strQuery = strQuery.replaceFirst("''", "'"+parameters[1].getValue()+"'");
			DfLogger.info(this,"CheckIPSEventDate: Query"+strQuery,null,null);
			IDfQuery strDQL = new DfQuery();
			IDfCollection dfCollection = null;
			
			DfLogger.info(this,"CheckIPSEventDate:: CheckIPSEventDate",null,null);
			strDQL.setDQL(strQuery);
			session = SessionManagerHttpBinding.getSessionManager().getSession(SessionManagerHttpBinding.getCurrentDocbase());
			dfCollection = strDQL.execute(session,IDfQuery.DF_EXEC_QUERY);
			if (dfCollection.next()) {
				date =  dateFormat.parse(dfCollection.getString("actual_date"));
				DfLogger.info(this,"CheckIPSEventDate ::Date"+date,null,null);
				dfCollection.close();	
				return date;
			}
		}
		catch(Exception e)
		{
		     DfLogger.error(this,": <<Exception>> : "+e.getMessage(),null,e);
		}
		finally
		{
			SessionManagerHttpBinding.getSessionManager().release(session);
		}
		return date;
	}
		
	public void destroy() throws AdaptorException {
		}
	
	public void init(IAdaptorConfiguration arg0) throws AdaptorException {
		DfLogger.info(this,"Init: CheckIPSEventDate:: CheckIPSEventDate",null,null);
	}	
}