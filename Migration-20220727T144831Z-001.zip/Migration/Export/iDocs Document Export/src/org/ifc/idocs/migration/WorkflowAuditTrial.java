package org.ifc.idocs.migration;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.ifc.idocs.migration.common.AppConfig;
import org.ifc.idocs.migration.common.DomdocRepository;
import org.ifc.idocs.migration.common.DomdocRepositoryDescriptor;
import org.ifc.idocs.migration.extract.LogHelper;
import org.ifc.idocs.migration.extract.Metadata;
import org.ifc.idocs.migration.extract.NotesSession;
import org.ifc.idocs.migration.transform.IFCNAB;
import org.ifc.idocs.migration.transform.WBNAB;

/**
 * @author VVellakkattumana
 * @see WorkflowAuditTrial - extracts workflow audit trials from lotus notes database
 * 
 */
public class WorkflowAuditTrial {

	public static Map<String,String> workflowMap = new HashMap<String,String>();
	protected static String utilityId = workflowMap.get("utilityId");
	public static Metadata metaData = new Metadata();
	private static AppConfig config = AppConfig.getInstance();

	
	public WorkflowAuditTrial() {
		String baselineView = config.getString("workflow.baselineView"); // getting baselineView from properties
		String activityView = config.getString("workflow.activityView"); // getting activityView from properties
		WorkflowAuditTrialBaseLine(baselineView, activityView, true);		
	}

	public static void WorkflowAuditTrialDelta() {
		String deltaView = config.getString("workflow.deltaView"); // getting deltaView from properties
		String activityView = config.getString("workflow.activityView"); // getting activityView from properties
		WorkflowAuditTrialBaseLine(deltaView, activityView, false);		
	}

	/**
	 * Constructor for WorkflowAuditTrial
	 * @param isBaseline 
	 */
	@SuppressWarnings("unchecked")
	
	public static void WorkflowAuditTrialBaseLine(String workflowView, String activityView, boolean isBaseline) {
		String dbName;
		String[] dbs = null ;

		Logger exportDocLogger = LogHelper.getLogger(WorkflowAuditTrial.class);

		try {
			String server = config.getString("workflow.server"); // getting server from properties
			Object databases = config.getProperty("workflow.database"); // getting database(s) from properties
			if (databases != null) {
				if (databases instanceof Collection) { // if multiple database exists
					int size = ((Collection) databases).size();
					dbs = new String[size];

					for (int i = 0; i < size; i++) {
						dbName = config.getString(new StringBuilder("workflow.database(").append(i).append(")").toString());
						//exportDocLogger.info("Available Databases = " + dbName);
						dbs[i] = dbName;
					}
				}else if (databases instanceof String){ // if only one database
					dbName = databases.toString();
					//exportDocLogger.info("Available Databases = " + dbName);
					dbs = new String[1];
					dbs[0] = dbName;
				}
			}

//			Checks whether a database available or not
			if(dbs != null && dbs.length > 0){
				for(int k=0; k < dbs.length; k++){ // itrating databases one by one
					String database = dbs[k];
					exportDocLogger.warning("Database name = " + database);
					workflowMap.put("database",database);
					
					DomdocRepositoryDescriptor repo = new DomdocRepositoryDescriptor("","",server,database);
					DomdocRepository domdoc = new DomdocRepository(repo);
					utilityId = workflowMap.get("utilityId");
					exportDocLogger.warning("Extraction Utility ID is ~ " + utilityId);
					domdoc.getFoldermanDb().getAuditTrials(utilityId, workflowView, activityView, isBaseline); // extracting workflow audit trials here by  utilityId
					domdoc.recycle();
				}
				exportDocLogger.warning("Workflow audit Trial done successfully");
			}else{
				exportDocLogger.warning("Unable to connect to Database / No Database available");
			}
		} 
		catch (Exception e) {
			exportDocLogger.warning("WorkflowAuditTrial exception");
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"Exception-", e);
		}
		finally {
			IFCNAB.recycle();
			WBNAB.recycle();
			NotesSession.terminate();
		}
	}
}
