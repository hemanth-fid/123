This folder contains all the classes needed to generate the stub classes to create web services for Documentum

Run this command #1 to generate the classes:
java -Djava.ext.dirs=C:\Projects\AxisWebServiceStubGenerator\lib org.apache.axis.wsdl.WSDL2Java -o C:\Projects\AxisWebServiceStubGenerator\src -p com.metro_dade.ibmtst.CICS.TWBA.PCHW070W <C:\Temp\Axis\PCHW070.wsdl>


Sample command line #2
java -Djava.ext.dirs=C:\Projects\IWA_Create_AxisWebServicesStub\lib org.apache.axis.wsdl.WSDL2Java -o C:\Projects\IWA_Create_AxisWebServicesStub\src -p com.metro_dade.ibmtst.CICS.TWBA.PCHW070W .\wsdl_files\PCHW070.wsdl


- Run command 1 or 2 to generate the classess with the new wsdl file

Latest command ran on 05/09/2014 for PCHW078
java -Djava.ext.dirs=C:\Projects\IWA_Create_AxisWebServicesStub\lib org.apache.axis.wsdl.WSDL2Java -o C:\Projects\IWA_Create_AxisWebServicesStub\src -p com.metro_dade.ibmtst.CICS.TWBA.PCHW078W .\wsdl_files\PCHW078.wsdl