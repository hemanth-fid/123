package org.ifc.idocs.report.common;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XMLReader {

	public static Map<String,String> securityReportMap = new HashMap<String,String>();
	
	public static Map<String, String> processXML() {
		try {
			final File file = new File("config.xml");
			final DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			final DocumentBuilder db = dbf.newDocumentBuilder();
			final Document doc = db.parse(file);
			doc.getDocumentElement().normalize();
			final NodeList projectTag = doc.getElementsByTagName("projects");
			String ProjectId = "";
			
			for (int i = 0; i < projectTag.getLength(); i++) {
				ProjectId = "";
				final Node projectNode = projectTag.item(i);
				final Element projectElement = (Element) projectNode;
				final NodeList projectList = projectElement.getElementsByTagName("project");
				for (int j = 0; j < projectList.getLength(); j++) {
					final Node idNode = projectList.item(j);
					final Element idElement = (Element) idNode;
					if (idElement.getNodeType() == Node.ELEMENT_NODE) {
						final NodeList idList = projectElement.getElementsByTagName("id");
						final Element idValueElement = (Element) idList.item(j);
						final NodeList idValue = idValueElement.getChildNodes();
						ProjectId = ((Node) idValue.item(0)).getNodeValue();
					}
					
					final NodeList documents = idElement.getElementsByTagName("documents");
					if(documents != null && documents.getLength() > 0){
						for (int k = 0; k < documents.getLength(); k++) {
							final Node documentNode = documents.item(k);
							final Element documentElement = (Element) documentNode;
							if (documentElement.getNodeType() == Node.ELEMENT_NODE) {
								final NodeList documentList = documentElement.getElementsByTagName("document");
								if(documentList.getLength() > 0){
									for (int m = 0; m < documentList.getLength(); m++) {
										final Element docElement = (Element) documentList.item(m);
										final NodeList docValue = docElement.getChildNodes();
										final String docId = ((Node) docValue.item(0)).getNodeValue();
										if(securityReportMap.get(ProjectId) != null){
											securityReportMap.put(ProjectId, "'" + docId + "'," + securityReportMap.get(ProjectId));
										}else{
											securityReportMap.put(ProjectId, "'" + docId + "'");
										}
									}
								}else{
									securityReportMap.put(ProjectId, "All");
								}
							}
						}
					}else{
						securityReportMap.put(ProjectId, "All");
					}
				}
			}
//			for (final String key : securityReportMap.keySet()) {
//				System.out.println(key + " : " + securityReportMap.get(key).toString());
//			}
		} catch (final Exception e) {
			e.printStackTrace();
		}
		return securityReportMap;
 	}
	
	public static void main(String args[]){
		processXML();
	}

}