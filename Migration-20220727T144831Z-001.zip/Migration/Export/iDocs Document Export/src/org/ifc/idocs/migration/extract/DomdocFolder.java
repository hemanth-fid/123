package org.ifc.idocs.migration.extract;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import lotus.domino.DateTime;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;

import org.ifc.idocs.migration.ExtractCommon;
import org.ifc.idocs.migration.ExtractDocuments;
import org.ifc.idocs.migration.common.DomdocRepository;

/**
 * @author SPankajamsadanan
 *
 */
public class DomdocFolder {

	private String folderkey;
	private Document doc;
	private Metadata metadata;
	private DomdocRepository domdoc;
	private static ExtractCommon eComm = null;
	private Logger exportDocLogger = LogHelper.getLogger(ExtractDocuments.class);
	private static Map<String,DomdocStorageDb> storageDbs = new HashMap<String,DomdocStorageDb>();
	
	/**
	 * getStorageDbByID method 
	 * @param id
	 * @return DomdocStorageDb 
	 * @throws NotesException
	 */
	private DomdocStorageDb getStorageDbByID(String id) throws NotesException {
		if (!storageDbs.containsKey(id)) {
			DomdocStorageDb sdb = new DomdocStorageDb(domdoc, id);
			storageDbs.put(id, sdb);
		}
		return storageDbs.get(id);		
	}
	
	/**
	 * @return DomdocStorageDb
	 * @throws NotesException
	 */
	public DomdocStorageDb getStorageDb() throws NotesException {
		return getStorageDbByID(this.doc.getItemValueString("documentdbid"));
	}
	
	/**
	 * DomdocFolder constructor
	 * @param domdoc
	 * @param doc
	 * @throws NotesException
	 */
	public DomdocFolder(DomdocRepository domdoc, Document doc){
		this.doc = doc;
		this.domdoc = domdoc;
		eComm = new ExtractCommon();
		try{
			String docid = doc.getItemValueString("docid");
			this.folderkey = doc.getItemValueString("folderkey");
			String fileroom = doc.getItemValueString("fileroom");
			if (fileroom.length() == 0) {
				exportDocLogger.log(Level.WARNING,"FILEROOM attribute missing");
				eComm.listSkipDocuments(doc, docid, "Missing FILEROOM attribute", "ER_020");
			} else {
				this.metadata = MetadataTemplateFactory.createFolderMetadataByFileroom(fileroom);
				this.metadata.populateFromNotesDocument(doc);
			}
		}
		catch(NotesException e){
			exportDocLogger.log(Level.WARNING,"NotesException DomdocFolder.java", e);
		}
	}
	
	/**
	 * export method
	 * @param path
	 * @param query
	 * @param cutoff
	 * @throws Exception
	 */
	public void export(String path, String query, DateTime cutoff) throws Exception {
		DomdocStorageDb sdb = getStorageDbByID(doc.getItemValueString("documentdbid"));
		String docquery;
		if (query == null) {
			docquery = "Folderkey='" + folderkey + "'";
		} else {
			docquery = "Folderkey='" + folderkey + "' & (" + query + ")";
		}
		sdb.export(path, docquery, cutoff);
	}
	
	/**
	 * @param path
	 * @return
	 * @throws NotesException
	 * @throws ParserConfigurationException
	 * @throws TransformerException
	 */
	public String exportMetadata(String path) throws NotesException, ParserConfigurationException, TransformerException {
		String exportPath = path + metadata.getFileroomId();
		new File(exportPath).mkdirs();
        DocumentBuilderFactory dbfac = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = dbfac.newDocumentBuilder();
        org.w3c.dom.Document xmldoc = docBuilder.newDocument();
        org.w3c.dom.Element root = xmldoc.createElement("DomdocFolder");
        xmldoc.appendChild(root);
        this.metadata.exportToXML(root);
        TransformerFactory tf = TransformerFactory.newInstance();
        tf.setAttribute("indent-number", new Integer(2));
		Transformer trans = tf.newTransformer();
        trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        trans.setOutputProperty(OutputKeys.INDENT, "yes");
        File xmlfile = new File(exportPath + "\\folder.xml");
        StreamResult result = new StreamResult(xmlfile);
        DOMSource source = new DOMSource(xmldoc);
        trans.transform(source, result);
        return exportPath;
	}
	
	/**
	 * @param query
	 * @param cutoff
	 * @return
	 * @throws NotesException
	 */
	public DocumentCollection findDocuments(String query, DateTime cutoff) throws NotesException {
		String docquery = "(" + query + ") & folderkey='" + this.folderkey + "'";
		DomdocStorageDb sdb = getStorageDbByID(this.doc.getItemValueString("documentdbid"));
//		System.out.println("DocumentQuery="+docquery+"~"+this.doc.getItemValueString("documentdbid"));
//		System.out.println(docquery);
		return sdb.findDocuments(docquery, cutoff);
	}
	/**Added for extracting documents during delta migration
	 * @param query
	 * @param cutoff
	 * @return
	 * @throws NotesException
	 */
	public DocumentCollection DeltaDocuments(String query, DateTime replica_date) throws NotesException {
		String docquery = "(" + query + ") & folderkey='" + this.folderkey + "'";
		DomdocStorageDb sdb = getStorageDbByID(this.doc.getItemValueString("documentdbid"));
		return sdb.findDocuments(docquery,replica_date);
	}
	
	
	/**
	 * @throws NotesException
	 */
	public void recycle() throws NotesException {
		this.doc.recycle();
	}
	
	/**
	 * @throws NotesException
	 */
	public static void recycleCache() throws NotesException {
		Iterator<String> it = storageDbs.keySet().iterator();
		while (it.hasNext()) {
			storageDbs.get(it.next()).recycle();
		}
	}
	
	/**
	 * @return
	 */
	public Metadata getMetadata() {
		return metadata;
	}

	/**
	 * @param metadata
	 */
	public void setMetadata(Metadata metadata) {
		this.metadata = metadata;
	}

	
	public String getFolderkey() {
		return folderkey;
	}

	public void setFolderkey(String folderkey) {
		this.folderkey = folderkey;
	}


	
}
