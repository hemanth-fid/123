package com.SWBC.DataService;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.drools.core.spi.KnowledgeHelper;
import org.kie.api.runtime.KieSession;

import com.SWBC.model.Brm_app_info;
import com.SWBC.model.Brm_app_json_info;
//import com.SWBC.model.Brm_app_json_info;
import com.SWBC.model.Brm_loan_info;
import com.SWBC.model.Brm_policy_info;
import com.SWBC.model.Brm_processing_info;
import com.SWBC.model.Brm_request_info;
import com.SWBC.model.Brm_rule;
import com.SWBC.model.Brm_rule_lookup_log;
import com.SWBC.model.PreProc_Doca_Ucap;
import com.SWBC.model.Trec;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfSession;


public interface TrecDao {

	public void insertLogTbl(String transaction_id, String transaction_type, String inputParameter, String ruleName,
			String ruleOutcome, String ruleMsg, String loginUserName, String cov_type, String loan_account_no,String loan_no,String loan_no_suffix, int policyTLMatchScore,String source,String rule_version,String jsonString);

	public List<Brm_processing_info> getProcInfo(Brm_request_info brm_request_info);
	
	public List<Brm_processing_info> getProcInfo(String loanno, String loanSuffix, String covType, String accno, String tid);
	
	//For Getting App Info
	public List<Brm_app_info> getAppInfo(String userID,String transType);
	
	
	
	public List<Brm_app_info> getAppSingleInfo(String tid,String t_loan_no, String l_suffix, String cov_type, String acc_no, String proc_user);

	/*public void insertProcTblData(List<Brm_processing_info> procTblData); */

	public void insertLoanTblData(List<Brm_loan_info> loanData);

	//public List<Brm_loan_info> getLoanInfo(List<Brm_processing_info> longLoanList);

	public String getEscrowClient(String procAccountNo);

	public List<Map<String, Object>> getPMERecord(Brm_processing_info procInfoObj);

	public List<String> get_FMM080_LoanHistory(Brm_processing_info procInfoObj);

	public void updateProcTbl(String tid, String loan_No, String loan_Suffix, String accnt_No, String cov_Type, String source);
	
	public List<String> getValidRuleList(String ruleSet);
	
	public List<Brm_loan_info> getLoanInfo(Brm_processing_info longLoanList);
	
	public void insertProcTbl(Brm_processing_info listProcTbl);

	public String get_FMI006_DualPolicy(Brm_processing_info procInfoObj);
	
	public boolean getRuleName(String transactionId, String ruleName);
	
	public void printMsgDRL(String msg);
	
	public String getLoanPropertyType(String loanNo, String loanSuffix, String accountNo);
	
	public List<String> getPolicyCancelReason();
	
	public List<String> getTransactionInsurer();
	
	public ArrayList<String> getFMR001VSIPolicyNummber(Brm_processing_info longLoanList);
	
	public List<Brm_policy_info> getFMRPolicyInfo(Brm_processing_info longLoanList, String policyNo);
	
	public void insertPolicyInfo(List<Brm_policy_info> policyInfo);
	
	public boolean reisntatetmentFMRCheck(Date reinstatementDate, List<Brm_policy_info> policyInfo);
	
	public Map<String, String> getDisbITCValues(String tid, String loan_No, String loan_Suffix, String accnt_No, String cov_Type);
	
	public String getITCSWBCCheck(String accNo);
	
	public String getCalculatedInsuraneStatus(String loan_is_waive_inititals,String loan_is_spare_code_1,
			Date loan_is_waive_date,String loan_is_audit_code,
			String loan_is_letter_code,String loan_is_impairment_code,
			String insuranceStatus, String insuranceType, Date expirationDate);
	
	public List<Brm_rule> getLogginhRuleList(String tType);
	
	public void insertPolicyHistory(String account_no, String loan_no,String loan_suffix,
			String cov_type,String loan_policy_no,String transaction_policy_no,
			Date transaction_effective_date,Date transaction_expiration_date,
			String transaction_insurer_name, String transaction_type, String transaction_id, Date transaction_document_date);
	
	public List<Brm_processing_info> getProcInfoSingleAPI(String tid, String loan_No, String loan_Suffix, String accnt_No, String cov_Type);
	
	public void insertFME001Info(String transaction_id, String transaction_type, String es_account_no,
			String es_loan_no, String es_loan_suffix, String es_coverage_type, String es_policy_no, 
			Date es_bill_date, Date es_eff_date,Date es_expiration_date,Date es_date_added,
			String  es_current_term, Double es_premium_amt, int es_no_pme_days, String es_void) ;
	
	public String isGapLineAvailable(Brm_processing_info procInfoObj);
	public Date getDatesFromLoanTable(Brm_processing_info procInfoObj, String fieldName);
	
	public Map<String, String> getLoanStatusAS400 (Connection as400_conn, String accountNumber, String loanNumber, String loanSuffix, String covType, String AS400LibPath, ArrayList<String> libraryList);
	
	public Brm_app_json_info getJSONOutput(String idCol);
	
	public List<Brm_rule> getSingleRuleList(String ruleName);
	
	public List<Map<String, Object>> getACCTSubStr(int accountNo);
	
	
	public List<Map<String, Object>> getCarrierFMS053();

	public IDfCollection executeDCTMQuery(IDfSession session, String query, String rObjID);
	
	public void saveEventAuditField(long event_id,String field_name, String value_before, String value_after);
	
	public List<Map<String, Object>> getShortNameFMS057(String format, int account_no); 
	
	public List<Map<String, Object>> getISAgentCode(String accno, String covType,String loanNo,String tranID,String suffix); 

	public List<Map<String, Object>> getPayeePreProc3_2(String carrierState, String carrierName, String accountNo);
	
	public String getMasterPayee(String accountNo);
	
	
	public String getPayeeIDFromAS4SP(String carrierName, String policyNo, String state, String covType, String accno);
	
	public void insertStagingTable(PreProc_Doca_Ucap preProc_Doca_Ucap); 
	
	public List<String> getInputrObjID(String dqlQyr,IDfSession session);
	
	public void insertBRM_EVENT_AUDIT_LOG(PreProc_Doca_Ucap preProc_Doca_Ucap, String ruleName);
	
	public List<Map<String, Object>> getBICData(int account_no,String loanNo,String covType);  
	
	public void insertSchedularLog(Date startTime, Date endTime, String appName, String metrics, String status);
	
	public String getWaiveCode(String accno,String loanno, String covType);
	
	public Date getLoanBoardDate(String accno,String loanno, String covType,String tranCode);
	
	public List<Map<String, Object>> getPymtDisbData(String accountNo);
	

}
