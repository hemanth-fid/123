package org.ifc.idocs.web.prompt;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;

public class WebPrompt extends com.documentum.web.formext.component.Prompt 
{

	/**
	 * This class to get the custom functionality of prompt message.
	 * created on 15/11/2011 
	 */
	private static final long serialVersionUID = 1L;
   /**
    * Purpose : is to delete the document if user by mistake closed the window.
    * @param control
    * @param argList
    */
	
	public void onCloseForm(Control control, ArgumentList argList) {
//		System.out.println("in Side the file changes prompt Message");
			 onNo(control, argList);
	}
}
