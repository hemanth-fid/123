package org.ifc.idocs.workflow;

import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfWorkflow;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import com.documentum.webcomponent.library.workflow.WorkflowService;

public class IDocsWorkflowService extends WorkflowService {
/**
 * 
 * @param objectId
 */
	 public static void abort(String objectId)
	    {
	        IDfSessionManager sessionManager;
	        IDfSession dfSession;
	        
	        sessionManager = SessionManagerHttpBinding.getSessionManager();
	        IDfSessionManager admSMgr = null;
	        IDfSession adminSession= null;
	        dfSession = null;
	        try
	        {
	        	dfSession = sessionManager.getSession(SessionManagerHttpBinding.getCurrentDocbase());
	        	admSMgr=IdocsUtil.getAdminSessionManager(dfSession);
	        	adminSession=admSMgr.getSession(dfSession.getDocbaseName());
	            IDfWorkflow workflow = (IDfWorkflow)adminSession.getObject(new DfId(objectId));
	        	workflow.fetch(null);
	        	workflow.setSessionManager(admSMgr);
	            workflow.abort();
	            DfLogger.debug(WorkflowService.class,"Aborting workflow Completed ",null,null);
	        }
	        catch(DfException dfe)
	        {
	        	DfLogger.error(WorkflowService.class,"Error encountred in aborting workflow "+dfe.getMessage(),null,null);
	            throw new WrapperRuntimeException(dfe);
	        }finally{
	        if(dfSession != null){
	        	sessionManager.release(dfSession);
	        	DfLogger.debug(WorkflowService.class,"relesing normal session ",null,null);
	        }
	        if(adminSession != null){
	        	admSMgr.release(adminSession);
	        	DfLogger.debug(WorkflowService.class,"relesing adminSession ",null,null);
	        }
	        
	        }
	    }
	 
	 /**
	  * 
	  * @param objectId
	  */
	 public static void delete(String objectId)
	    {
	        IDfSessionManager sessionManager;
	        IDfSession dfSession;
	        sessionManager = SessionManagerHttpBinding.getSessionManager();
	        IDfSessionManager admSMgr = null;
	        IDfSession adminSession= null;
	        dfSession = null;
	        try
	        {
	            dfSession = sessionManager.getSession(SessionManagerHttpBinding.getCurrentDocbase());
	            admSMgr=IdocsUtil.getAdminSessionManager(dfSession);
	            adminSession=admSMgr.getSession(dfSession.getDocbaseName());
	        	IDfWorkflow workflow = (IDfWorkflow)adminSession.getObject(new DfId(objectId));
	        	workflow.setSessionManager(admSMgr);
	            workflow.fetch(null);
	            workflow.destroy();
	        }
	        catch(DfException dfe)
	        {
	        	DfLogger.error(WorkflowService.class,"Error encountred in deleting workflow "+dfe.getMessage(),null,null);
	            throw new WrapperRuntimeException("Failed to delete", dfe);
	        }
	        finally{
	        	if(dfSession != null){
		        	sessionManager.release(dfSession);
		        	DfLogger.debug(WorkflowService.class,"relesing normal session ",null,null);
		        }
		        if(adminSession != null){
		        	admSMgr.release(adminSession);
		        	DfLogger.debug(WorkflowService.class,"relesing adminSession ",null,null);
		        }
	        }
	    }

}
