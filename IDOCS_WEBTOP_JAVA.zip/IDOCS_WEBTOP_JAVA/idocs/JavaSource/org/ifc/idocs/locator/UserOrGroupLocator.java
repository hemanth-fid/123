/**
* This custom behaviour class provides list of users related to project of the document 
* selected for providing permissions.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Parag Doshi 			11/10/2010		1.0				created
* #######################################################################################################
*/
package org.ifc.idocs.locator;

import java.io.IOException;
import java.util.Properties;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.utils.IdocsConstants;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.LocaleService;
import com.documentum.web.form.control.databound.DataDropDownList;
import com.documentum.web.form.control.databound.TableResultSet;

public class UserOrGroupLocator extends com.documentum.webcomponent.library.locator.UserOrGroupLocator
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private boolean m_fIsPrivateGroupVisible;
    private boolean m_fIsWorkQueueGroupVisible;
    private boolean m_bShowUnlistedUsers;
    public String documentObjectId="";
    public String strRoleType = "project_members";
    public static String PROJECT_ID = "projectId";
    public static String DROPDOWN_ROLEFILTERS="rolefilter";

	private static String UserOrGroupLocatorNlsProp = "org.ifc.idocs.locator.UserOrGroupLocatorNlsProp";
	private static NlsResourceBundle m_nlsResourceBundle = new NlsResourceBundle(UserOrGroupLocatorNlsProp);
	private static Properties idocsProperties = new Properties();
	private UserOrGroupLocatorQuery locatorQuery = new UserOrGroupLocatorQuery();
	private boolean isEditIOMPerformers = false;
	public UserOrGroupLocator()
    {
        m_fIsPrivateGroupVisible = false;
        m_fIsWorkQueueGroupVisible = false;
        m_bShowUnlistedUsers = false;
    }

    public void onInit(ArgumentList args) {
    	try {
    		setInitialDocbaseType(IDocsConstants.MSG_DM_USER);
    		String callerComponent = args.get("callerComponent");
    		if (null != callerComponent && callerComponent.trim().length() > 0 && callerComponent.equals("editiomperformers")) {
    			isEditIOMPerformers = true;
    			DfLogger.debug(this, " :: onInit(): isEditIOMPerformers: " + isEditIOMPerformers, null, null);
    			DataDropDownList roleList = (DataDropDownList)getControl(DROPDOWN_ROLEFILTERS, DataDropDownList.class);
    			roleList.setVisible(false);
    			roleList.setEnabled(false);
    		} else {
    			DfLogger.debug(this, " :: onInit(): isEditIOMPerformers: " + isEditIOMPerformers, null, null);
    			idocsProperties.load(UserOrGroupLocator.class.getResourceAsStream(IdocsConstants.IDOCS_PROPERTY_FILE));
    	        documentObjectId = args.get("documentId");
    	        DfLogger.info(this, "UserOrGroupLocator :: onInit :: documentObjectId : " +documentObjectId, null, null);
            	updateFilters();
    		}
    		super.onInit(args);
	        
		} catch (DfException e) {
			DfLogger.error(this, " :: onInit : " + e.getMessage(), null, null);
		} catch (IOException e) {
			DfLogger.error(this, " :: onInit : " + e.getMessage(), null, null);
		}
    }

	private void updateFilters() throws DfException {
		TableResultSet templateResultSet = new TableResultSet(new String[] {
				 "roleId","roleName"
       });
       DataDropDownList roleList = (DataDropDownList)getControl(DROPDOWN_ROLEFILTERS, DataDropDownList.class);

       DfQuery query = new DfQuery();
       String strObjectType =  IDocDocbaseAttributeTagUtility.getSysObjectAttribute(getDfSession(), documentObjectId, IdocsConstants.R_OBJECT_TYPE);
       if(strObjectType != null 
       		&& strObjectType.equals(IDocsConstants.MSG_IDOCS_PROJECT_DOC)){	
    	   String strProjectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(getDfSession(),  documentObjectId, "project_id", IDocsConstants.MSG_IDOCS_PROJECT_DOC);
	       query.setDQL((idocsProperties.getProperty("QRY_ROLE_LIST")).replaceFirst("''", "'"+strProjectId+"'"));
       }else if(strObjectType != null 
       			&& strObjectType.equals(IDocsConstants.MSG_IDOCS_INSTITUTION_DOC)){
    	   String strInstiRoleType = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(getDfSession(),  documentObjectId, "instit_role_type_code", IDocsConstants.MSG_IDOCS_INSTITUTION_DOC);
	   		DfLogger.info(this,"Value of Institution Role type "+strInstiRoleType,null,null);     		
	   		if(strInstiRoleType!=null && strInstiRoleType.trim().length() > 0 
	   				&& strInstiRoleType == IDocsConstants.MSG_INTITUTION_CLIENT_ROLE){
	   			String strInstitutionNumber = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(getDfSession(),  documentObjectId, "institution_nbr", IDocsConstants.MSG_IDOCS_INSTITUTION_DOC);
	   			DfLogger.info(this,"Value of Institution Number "+strInstitutionNumber,null,null);
	   			String frameClientProjects = idocsProperties.getProperty("QRY_CLIE_INSTI_PROJECTS").replaceFirst("''", strInstitutionNumber);
	   			query.setDQL(idocsProperties.getProperty("QRY_ROLE_LIST_MULTI").replaceFirst("''",frameClientProjects)+")");	
	   		}else{	        			
	   			query.setDQL("select i_all_users_names from dm_group where group_name='"+idocsProperties.getProperty("MSG_IFC_CORE_GROUP")+"'");	        					
	   		}
       }else{
    	   query.setDQL("select i_all_users_names from dm_group where group_name='"+idocsProperties.getProperty("MSG_IFC_CORE_GROUP")+"'");
       }
       DfLogger.info(this, "UserOrGroupLocator :: updateFilters : DQL : "+query.getDQL(), null, null);
       IDfCollection collection = query.execute(getDfSession(), 0);
       String roleName = "", roleLabel = "";

       templateResultSet.add(new String[] {
    		   m_nlsResourceBundle.getString("MSG_PROJECT_MEMBERS", LocaleService.getLocale()),
    		   m_nlsResourceBundle.getString("MSG_SHOW_PROJECT_MEMBERS", LocaleService.getLocale())
       });

       try{
	    	while(collection.next()){
	           roleName = collection.getString(m_nlsResourceBundle.getString("MSG_STAFF_FUNCTION_CODE", LocaleService.getLocale()));
	           roleLabel = collection.getString(m_nlsResourceBundle.getString("MSG_STAFF_FUNCTION_NME", LocaleService.getLocale()));
	           templateResultSet.add(new String[] {
	        		roleName, roleLabel
	           });
	//           DfLogger.info(this, "UserOrGroupLocator :: updateFilters : roleName : "+roleName+" : roleLabel : "+roleLabel,null,null);
	       }
	    if(collection != null )collection.close();
	    }catch (Exception e) {
	        DfLogger.error(this, "UserOrGroupLocator :: updateFilters : Query Error : "+e.getMessage(), null, null);
		}
       roleList.getDataProvider().setScrollableResultSet(templateResultSet);
	}

	public void onRender(){
    	super.onRender();
    }

    protected UserOrGroupLocatorQuery createQuery() {
    	//Modified for custom user group
        locatorQuery.setPrivateGroupVisible(m_fIsPrivateGroupVisible);
        locatorQuery.setWorkQueueGroupVisible(m_fIsWorkQueueGroupVisible);
        locatorQuery.setShowUnlistedUsers(m_bShowUnlistedUsers);
        locatorQuery.setIsIOMEditPerformers(isEditIOMPerformers);
    	if (isEditIOMPerformers == false) {
    		//locatorQuery.setProjectId(strProjectIdArg);
    		locatorQuery.setDocumentId(documentObjectId);
    		locatorQuery.setRoleType(strRoleType);
    	}
    	return locatorQuery;
    }

    public void onChangeAttributeFilter(DataDropDownList versions, ArgumentList arg) {
        DataDropDownList roleList = (DataDropDownList)getControl(DROPDOWN_ROLEFILTERS, DataDropDownList.class);
        DfLogger.info(this, "Role Value Selected :: "+roleList.getValue(), null, null);
        strRoleType=roleList.getValue();
        locatorQuery.setRoleType(strRoleType);
        updateQuery();
    }
}
