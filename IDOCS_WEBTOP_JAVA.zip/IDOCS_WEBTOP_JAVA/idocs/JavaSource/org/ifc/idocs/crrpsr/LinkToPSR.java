/**
* This custom component class is provided to link the document to PSR.  
* #######################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################
* Gangadhar Reddy.V		02/27/2011		1.0				Created

* #######################################################################
*/
package org.ifc.idocs.crrpsr;

import java.io.IOException;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.main.MainEx;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.Button;
import com.documentum.web.form.control.Label;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.drl.DRLComponent;

public class LinkToPSR extends Component {

	private String m_objectId;
	private String m_chronicleId;
	private String m_documentId;
	private static Properties idocsProperties = new Properties();
	private static final long serialVersionUID = 1L;
	private static final String ATTR_DOCUMENT_ID = "document_id";
	private static final String ATTR_RESOURCE_ENTITY_ID = "resource_entity_id";
	private static final String ATTR_INSTITUTION_NBR = "institution_nbr";
	private static final String ATTR_R_CREATION_DATE = "r_creation_date";
	private static final String LINKED_SUCCESSFULLY = "Document linked to PSR successfully";
	private static final String DO_NOT_LINK = "Not supposed to link this document";
	private static final String ALREADY_LINKED = "Document is already linked to PSR";
	public static String MESSAGE = IDocsConstants.MSG_EMPTY_STRING;
	private static final String QRY_VARIABLE_DOCUMENTURL = "<documentUrl>";
	private static final String QRY_VARIABLE_USER = "<userID>";
	private static final String QRY_VARIABLE_DOCUMENTID = "<documentID>";
	
	/**
	 *  Constructor
	 */
	public LinkToPSR() {
		m_objectId = IDocsConstants.MSG_EMPTY_STRING;
	}
 
	/**
	 * This is the method at which component initialises
	 * 
	 * args - Dictionary of form arguments
	 */
	public void onInit(ArgumentList args) {
		IDfSession dfSession = null;
		boolean txStartedHere = false;
		try {
			idocsProperties.load(LinkToPSR.class.getResourceAsStream(IdocsConstants.IDOCS_PROPERTY_FILE));
			super.onInit(args);
			dfSession = getDfSession();
			String userName = dfSession.getLoginUserName();
			DfLogger.info(this, " :: onInit : " + userName, null, null);
			m_objectId = args.get("objectId");
			DfLogger.info(this, " :: onInit : ObjectID : " + m_objectId, null, null);
			IDfDocument psrDoc = (IDfDocument) dfSession.getObject(new DfId(m_objectId));
			String strDocName = psrDoc.getObjectName();
			DfLogger.info(this, " :: onInit : strDocName: " + strDocName, null, null);
			String partnerIdFromLink = MainEx.getstrId(getPageContext().getSession());
			DfLogger.info(this, " :: onInit : partnerIdFromLink: " + partnerIdFromLink, null, null);
			String resourceIdFromLink = MainEx.getSourceName(getPageContext().getSession());
			DfLogger.info(this, " :: onInit : resourceIdFromLink: " + resourceIdFromLink, null, null);
			String resourceKey = MainEx.getResourcekey(getPageContext().getSession());
			DfLogger.info(this, " :: onInit : resourceKey : " + resourceKey, null, null);
			String partnerIdOfSelDoc = psrDoc.getString(ATTR_INSTITUTION_NBR);
			DfLogger.info(this, " :: onInit : partnerIdOfSelDoc: " + partnerIdOfSelDoc, null, null);
			m_chronicleId = psrDoc.getChronicleId().toString();
			DfLogger.info(this, " :: onInit : m_chronicleId : " + m_chronicleId, null, null);
			
			if (partnerIdFromLink != null && partnerIdFromLink.trim().length() > 0
					&& partnerIdOfSelDoc != null && partnerIdOfSelDoc.trim().length() > 0) { // If Partner ID of selected document and Partner ID passed from URL are not empty
				
				if (partnerIdFromLink.equals(partnerIdOfSelDoc)) {
					String dtCreated = psrDoc.getString(ATTR_R_CREATION_DATE);
					
					if ( !dfSession.isTransactionActive() ) {
						dfSession.beginTrans();
					    txStartedHere = true;
					}
					
					// To get document_id from dm_dbo.IDOCS_UTILITY_DOC table
					String strQryDocId = idocsProperties.getProperty("MSG_GET_ID_FRM_UTILITY_DOC_TBL");
					strQryDocId = strQryDocId + m_chronicleId + "'";
					IDfCollection docIdCollection = executeQuery(strQryDocId);
					if (docIdCollection.next()) {
						m_documentId = docIdCollection.getString(ATTR_DOCUMENT_ID);
						docIdCollection.close();
			    	}
					if(docIdCollection != null )docIdCollection.close();
					if(m_documentId != null && m_documentId.trim().length() > 0) { // If document_id already exists in dm_dbo.IDOCS_UTILITY_DOC table
						String rsEntityId = getResourceEntityId(resourceIdFromLink,resourceKey);
						if(rsEntityId != null && rsEntityId.trim().length() > 0) { // If resource_entity_id for PSR already exists in dm_dbo.IDOCS_UTILITY_DOCATTACHMENT table
							MESSAGE = ALREADY_LINKED;
						} else {
							
							// Updating details of UTILITY.DOCUMENT Table (Update Query)
							updateUtilityDocTable(userName, dtCreated, psrDoc, dfSession, false); 
													
							// Updating details of UTILITY.DOCUMENT_ATTACHMENT table
							updateUtilityDocAttachmentTable(userName, dtCreated, dfSession);
							
							if (txStartedHere) {
								dfSession.commitTrans();
								DfLogger.info(this, " :: onInit :: Commited The Transaction", null, null);
							}
							MESSAGE = LINKED_SUCCESSFULLY;
						}
					} else { // If document_id doesn't exists in dm_dbo.IDOCS_UTILITY_DOC table
						String rsEntityId = getResourceEntityId(resourceIdFromLink,resourceKey);
						if(rsEntityId != null && rsEntityId.trim().length() > 0) { // If resource_entity_id for PSR already exists in dm_dbo.IDOCS_UTILITY_DOCATTACHMENT table
							// Updating details of UTILITY.DOCUMENT Table (Update Query)
							updateUtilityDocTable(userName, dtCreated, psrDoc, dfSession, false); 
							
							if (txStartedHere) {
								dfSession.commitTrans();
								DfLogger.info(this, " :: onInit :: Commited The Transaction", null, null);
							}
							MESSAGE = LINKED_SUCCESSFULLY;
						} else {
							
							// Updating details of UTILITY.DOCUMENT Table (Insert Query)
							updateUtilityDocTable(userName, dtCreated, psrDoc, dfSession, true); 
													
							// Updating details of UTILITY.DOCUMENT_ATTACHMENT table
							updateUtilityDocAttachmentTable(userName, dtCreated, dfSession);
							
							if (txStartedHere) {
								dfSession.commitTrans();
								DfLogger.info(this, " :: onInit :: Commited The Transaction", null, null);
							}
							MESSAGE = LINKED_SUCCESSFULLY;
						}
					}
				} else {
		    		MESSAGE = DO_NOT_LINK;
		    	}
			} else {
				MESSAGE = DO_NOT_LINK;
			}
			
			Label messageLabel = (Label)getControl("finalMessage",Label.class);
			messageLabel.setLabel(MESSAGE);
			messageLabel.setVisible(true);
			messageLabel.setEnabled(true);
			DfLogger.info(this, " :: onInit  label Set to " + MESSAGE, null, null);
			
		} catch (IOException e) {
			DfLogger.error(this, " :: onInit  IOException >> " + e.getMessage(), null, null);
		} catch (DfException e) {
			DfLogger.error(this, " :: onInit DfException >> " + e.getMessage(), null, null);
		} finally {
			try {
				if (txStartedHere && dfSession.isTransactionActive()) {
					dfSession.abortTrans();
					DfLogger.info(this, " :: onInit :: Aborted The Transaction ", null, null);
				}
			} catch (DfException dfe) {
				DfLogger.error(this, " :: onInit Exception during Transaction Abort>> " + dfe.getMessage(), null, null);
			}
		}
	}

	/**
	 * This method checks whether the resource_entity_id (302) value exists or not in the dm_dbo.IDOCS_UTILITY_DOCATTACHMENT
	 * table for the selected document
	 *  
	 * @param resourceIdFromLink - Resource Entity Id value passed from URL
	 * @return resourceEntityId - resource_entity_id value read from dm_dbo.IDOCS_UTILITY_DOCATTACHMENT table
	 */
	private String getResourceEntityId(String resourceIdFromLink,String resourceKey) {
		String resourceEntityId = null;
		try {
			// To get resource_entity_id from dm_dbo.IDOCS_UTILITY_DOCATTACHMENT table
			String strQryResEntityId = idocsProperties.getProperty("MSG_GET_RSEID_FRM_DOCATTACHMENT_TBL");
			strQryResEntityId = strQryResEntityId.replaceFirst("''", "'"+resourceIdFromLink+"'");
			strQryResEntityId = strQryResEntityId.replaceFirst("''", "'"+m_chronicleId+"'");
			strQryResEntityId = strQryResEntityId.replaceFirst("''", "'"+resourceKey+"'");
			IDfCollection rsEntityIdCollection = executeQuery(strQryResEntityId);
			if(rsEntityIdCollection.next()){
				resourceEntityId = rsEntityIdCollection.getString(ATTR_RESOURCE_ENTITY_ID);
				rsEntityIdCollection.close();
	    	}
			if(rsEntityIdCollection != null )rsEntityIdCollection.close();
		} catch (Exception e) {
			DfLogger.error(this, " :: getResourceEntityId :: " + e.getMessage(), null, null);
		}
		return resourceEntityId;
	}

	/**
	 * This method executes the DQL query and returns the result in a collection object
	 * 
	 * @param queryString - Query String that is to be executed
	 * @return collectionObj - Collection object containing execution results
	 * @throws DfException
	 */
	private IDfCollection executeQuery(String queryString) throws DfException{
		IDfCollection collectionObj = null;
		DfLogger.info(this, " :: executeQuery :: queryString: " + queryString , null, null);
		IDfQuery query = new DfQuery();
		query.setDQL(queryString);		
		collectionObj = query.execute(getDfSession(), DfQuery.EXECREAD_QUERY);
		return collectionObj;
	}

	/**
	 * This method performs INSERT query to update the dm_dbo.IDOCS_UTILITY_DOCATTACHMENT table
	 * 
	 * @param userName - User who creates the link
	 * @param dtCreated - Date when document was created
	 * @param dfSession - Session Instance
	 * @throws IOException
	 * @throws DfException
	 */
	private void updateUtilityDocAttachmentTable(String userName, String dtCreated, IDfSession dfSession) throws IOException, DfException{
		
		String strResourceEntityId = MainEx.getSourceName(getPageContext().getSession());
		int resourceEntityId = Integer.parseInt(strResourceEntityId);
		String resourceKey = MainEx.getResourcekey(getPageContext().getSession());
		
		DfLogger.info(this, " :: updateUtilityDocAttachmentTable :: RESOURCE_ENTITY_ID: " + resourceEntityId, null, null);
		DfLogger.info(this, " :: updateUtilityDocAttachmentTable :: RESOURCE_KEY: " + resourceKey, null, null);
		DfLogger.info(this, " :: updateUtilityDocAttachmentTable :: DOCUMENT_ID: " + m_chronicleId, null, null);
		DfLogger.info(this, " :: updateUtilityDocAttachmentTable :: DOCUMENT_VERSION_NBR: " + m_chronicleId, null, null);
		DfLogger.info(this, " :: updateUtilityDocAttachmentTable :: USER_ID: " + userName, null, null);
		DfLogger.info(this, " :: updateUtilityDocAttachmentTable :: DATETIME_STAMP: " + dtCreated, null, null);

		String strConst = "','";
	
		StringBuffer qryBuffer = new StringBuffer();
		qryBuffer = qryBuffer.append(idocsProperties.getProperty("MSG_UTILITY_DOC_ATTACHMENT_INSERT_QUERY"));
		
		qryBuffer.append(resourceEntityId);
		qryBuffer.append(",'" + resourceKey);
		qryBuffer.append(strConst);
		qryBuffer.append(m_chronicleId);
		qryBuffer.append(strConst);
		qryBuffer.append(m_chronicleId);
		qryBuffer.append("',date(today),'");
		qryBuffer.append(IdocsUtil.handleSingleQuote(userName)+"')");

		DfLogger.info(this, " :: updateUtilityDocAttachmentTable :: MSG_UTILITY_DOC_ATTACHMENT_INSERT_QUERY: " + qryBuffer.toString(), null, null);
		executeQuery(qryBuffer.toString());		
	}

	/**
	 * This method performs INSERT/UPDATE query update the dm_dbo.IDOCS_UTILITY_DOC table
	 * 
	 * @param userName - User who creates the link
	 * @param dtCreated - Date when document was created
	 * @param psrDoc - dm_document instance of selected document
	 * @param dfSession - Session Instance
	 * @param isInsert - boolean value that decides INSERT or UPDATE operation to be done
	 * @throws IOException
	 * @throws DfException
	 */
	private void updateUtilityDocTable(String userName, String dtCreated, IDfDocument psrDoc, IDfSession dfSession, boolean isInsert) throws IOException, DfException{
		
		String description = psrDoc.getString("description");
		String title = psrDoc.getObjectName();
		String fullDrl = IDocsConstants.MSG_EMPTY_STRING;
		
		HttpServletRequest request = (HttpServletRequest) this.getPageContext().getRequest();
		String drlString = DRLComponent.constructDRL(m_chronicleId, null, null, this);
		
		DfLogger.info(this, " :: updateUtilityDocTable :: drlString: " + drlString, null, null);
        if(drlString != null) {
        	
            fullDrl = Component.makeFullUrl(request, drlString);
           	fullDrl = fullDrl + "/versionLabel/CURRENT";
			DfLogger.info(this, " :: updateUtilityDocTable :: fullDrl: " + fullDrl, null, null);
	        String strConst = "','";
	    	StringBuffer qryBuffer = new StringBuffer();
	        if (isInsert) {
	        	DfLogger.info(this, " :: updateUtilityDocTable :: DOCUMENT_ID: " + m_chronicleId, null, null);
	    		DfLogger.info(this, " :: updateUtilityDocTable :: DOCUMENT_VERSION_NBR: " + m_chronicleId, null, null);
	    		DfLogger.info(this, " :: updateUtilityDocTable :: DOCUMENT_TITLE_NAME: " + title, null, null);
	    		DfLogger.info(this, " :: updateUtilityDocTable :: DOCUMENT_DESC: " + description, null, null);
	    		DfLogger.info(this, " :: updateUtilityDocTable :: DOCUMENT_URL_TEXT: " + fullDrl, null, null);
	    		DfLogger.info(this, " :: updateUtilityDocTable :: USER_ID: " + userName, null, null);
	    		DfLogger.info(this, " :: updateUtilityDocTable :: DATETIME_STAMP: " + dtCreated, null, null);

	    		
	    		qryBuffer = qryBuffer.append(idocsProperties.getProperty("MSG_UTILITY_DOC_INSERT_QUERY"));
	    		qryBuffer.append(m_chronicleId);
	    		qryBuffer.append(strConst);
	    		qryBuffer.append(m_chronicleId);
	    		qryBuffer.append(strConst);
	    		qryBuffer.append(IdocsUtil.handleSingleQuote(title));
	    		qryBuffer.append(strConst);
	    		qryBuffer.append(IdocsUtil.handleSingleQuote(description));
	    		qryBuffer.append(strConst);
	    		qryBuffer.append(fullDrl);
	    		qryBuffer.append("',date(today),'");
	    		qryBuffer.append(IdocsUtil.handleSingleQuote(userName)+"')");

	    		DfLogger.info(this, " :: updateUtilityDocTable :: MSG_UTILITY_DOC_INSERT_QUERY: " + qryBuffer.toString(), null, null);
	    		executeQuery(qryBuffer.toString());		
	    	} else {
	    		DfLogger.info(this, " :: updateUtilityDocTable :: DOCUMENT_URL_TEXT: " + fullDrl, null, null);
	    		DfLogger.info(this, " :: updateUtilityDocTable :: USER_ID: " + userName, null, null);
	    		String queryUpdateUtilityDoc = idocsProperties.getProperty("MSG_UTILITY_DOC_UPDATE_QUERY");
	    		/*queryUpdateUtilityDoc = queryUpdateUtilityDoc.replaceFirst("''", "'" + fullDrl + "'");
	    		queryUpdateUtilityDoc = queryUpdateUtilityDoc.replaceFirst("''", "'" + userName + "'");
	    		queryUpdateUtilityDoc = queryUpdateUtilityDoc.replaceFirst("''", "'" + m_chronicleId + "'");*/
	    		queryUpdateUtilityDoc = queryUpdateUtilityDoc.replace(QRY_VARIABLE_DOCUMENTURL, "'" + fullDrl + "'");
	    		queryUpdateUtilityDoc = queryUpdateUtilityDoc.replace(QRY_VARIABLE_USER, "'" + IdocsUtil.handleSingleQuote(userName) + "'");
	    		queryUpdateUtilityDoc = queryUpdateUtilityDoc.replace(QRY_VARIABLE_DOCUMENTID, "'" + m_chronicleId + "'");
	    		DfLogger.info(this, " :: updateUtilityDocTable :: MSG_UTILITY_DOC_UPDATE_QUERY: " + qryBuffer.toString(), null, null);
	    		executeQuery(queryUpdateUtilityDoc);		
	    	}
		}
        else {
        	DfLogger.info(this, "Unable To Construct DRL", null, null);
        }
	}

	/**
	 * This method is invoked when user clicks Close button on popup window
	 * 
	 * @param control - Button
	 * @param args - Arguments
	 */
	public void onClose(Button control, ArgumentList args) {
		setComponentReturn();
	}
}
