package org.ifc.idocs.migration.updateReferences;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.ifc.idocs.migration.helper.UpdateReferenceDB;
import org.ifc.idocs.migration.importUtility.ImportUtility;
import org.ifc.idocs.migration.updateReferences.UpdateTAASDB;

import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.common.DfException;
/**
 * UpdateProductDB - Updating iDesk Product databases. 
 * @author HAnuganti
 * 
 * #############################################################################################
 * Author		            DateofChange	 Version	  ModificationHistory
 * ###########################################################################################
 * Hemachandra Anuganti 
 * ###########################################################################################
 * 
 */
public class UpdateProductDB extends ImportUtility{

	public static void updateWorkFolwDRLs() {
		
		//importDocLogger.info("Inside updateWorkFolwDRLs():"+UpdateProductDB.class);
		//importDocLogger.info("Getting DB Connection from UpdateTAASDB");
		UpdateReferenceDB.getConnection();
		IDfDocument document;
		String dominoDocID = "";
		ResultSet rsPRODUCT = UpdateReferenceDB.selectRecords(idocsProperties.getProperty("MSG_PRODUCT_DOC_QUERY"), idocsProperties.getProperty("MSG_PRODUCT_IDENTITY"));
		try {
			while(rsPRODUCT.next()){
				try {
					String wfDRL = rsPRODUCT.getString(1);
					int drlInt=wfDRL.lastIndexOf('=');
					dominoDocID = wfDRL.substring(drlInt+1);
					document = (IDfDocument) dfSession.getObjectByQualification("idocs_document(all) where orig_doc_unique_id='"+dominoDocID+"'");
					if (document != null) {
						String idocsDocID = document.getString("r_object_id");
						String updatedrl = idocsProperties.getProperty("MSG_CRR_PSR_DRL");
						updatedrl = updatedrl.replaceFirst("<r_object_id>", idocsDocID);
						String updateProduct = idocsProperties.getProperty("MSG_UPDATE_PRODUCT_DB");
						updateProduct = updateProduct.replaceFirst("<updatedrl>", updatedrl);
						updateProduct = updateProduct.replaceFirst("<wfDRL>", wfDRL);
						UpdateReferenceDB.updateRecords(updateProduct, idocsProperties.getProperty("MSG_PRODUCT_IDENTITY"));
					}else{
						importDocLogger.warning("Documet Does not exist in IFCDocs Documentum for the Lagacy ID::["+dominoDocID+"]");
					}
				} catch (DfException e) {
					// TODO Auto-generated catch block
					importDocLogger.warning("DfException::"+e.getMessage());
					importDocLogger.warning("Issue while processing the Legacy ID for Product DB Update::["+dominoDocID+"]");
					e.printStackTrace();
				}
			}
			if(rsPRODUCT != null){
				rsPRODUCT.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("Issue while processing the Legacy ID for Product DB Update::["+dominoDocID+"]");
			importDocLogger.warning("SQLException::"+e.getMessage());
			e.printStackTrace();
		}
		
	}
	
}
