package com.SWBC.utilities;

import java.util.LinkedHashMap;
import java.util.Map;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;

public class DCTMOpsUtils {

	
	public static final String __VERSION__ = "1.0.0";
	
	
	public static final String LOG_HEADER = "com.swbc.doca.utils.DCTMOpsUtils("
			+ __VERSION__ + ")";

	// ------------------Configuration Object field names-------------
	public static final String CONFIG_OBJ_ATTR_PARAM = "parameter";
	public static final String CONFIG_OBJ_ATTR_PARAM_VALUE = "parameter_value";

	public static Map<String, String> getConfigObjectMap(IDfSession session,
			final String configObjName) throws DfException {

		DfLogger.debug(LOG_HEADER, "Getting Configuration Object Map : '"
				+ configObjName + "'", null, null);

		Map<String, String> mapConfigObj = new LinkedHashMap<String, String>();

		try {
			// getting the config object
			IDfSysObject configObject = (IDfSysObject) session
					.getObjectByQualification("dm_sysobject where object_name = '"
							+ configObjName + "'");
			if (configObject != null) {
				DfLogger.debug(LOG_HEADER,
						"--------------------- Config Object [" + configObjName
								+ "] ------------------------", null, null);
				System.out.println("--------------------- Config Object ["
						+ configObjName + "] ------------------------");

				for (int i = 0; i < configObject
						.getValueCount(CONFIG_OBJ_ATTR_PARAM); i++) {
					String strAttr = configObject.getRepeatingString(
							CONFIG_OBJ_ATTR_PARAM, i);
					String attrValue = configObject.getRepeatingString(
							CONFIG_OBJ_ATTR_PARAM_VALUE, i);
					mapConfigObj.put(configObject.getRepeatingString(
							CONFIG_OBJ_ATTR_PARAM, i), configObject
							.getRepeatingValue(CONFIG_OBJ_ATTR_PARAM_VALUE, i)
							.asString());
					DfLogger.debug(LOG_HEADER, "[Parameter Name : '" + strAttr
							+ "'] , [Parameter Value : '" + attrValue + "']",
							null, null);
					System.out.println("[Parameter Name : '" + strAttr
							+ "'] , [Parameter Value : '" + attrValue + "']");
				}
				DfLogger.debug(
						LOG_HEADER,
						"----------------------------------------------------------------------------",
						null, null);
				System.out
						.println("----------------------------------------------------------------------------");
			} else {
				throw new DfException("Config Object '" + configObjName
						+ "' not found.");
			}
		} catch (DfException dfe) {
			throw new DfException(
					"Error while populating the config object values map in getConfigObjectMap() : '"
							+ dfe.getMessage() + "'");
		}
		return mapConfigObj;
	}

	public static IDfCollection executeQuery(IDfSession session, String query)
			throws DfException {
		DfLogger.debug(LOG_HEADER, "Executing DCTM Query : [" + query + "]",
				null, null);

		IDfCollection outputColl = null;
		try {
			IDfClientX cx = new DfClientX();
			IDfQuery idfQry = cx.getQuery(); // Create query object
			idfQry.setDQL(query); // Pass the user's query

			// Execute the query
			outputColl = idfQry.execute(session, IDfQuery.READ_QUERY);
		} catch (DfException dfe) {
			throw new DfException(
					"Error while executing the query in executeQuery() : "
							+ dfe.getMessage());
		}
		return outputColl;
	}

	public static void cleanUpCollection(IDfCollection resourceCollection)
			throws DfException {
		try {
			if (resourceCollection != null) {
				resourceCollection.close();

				DfLogger.debug(LOG_HEADER, "Collection closed successfully.",
						null, null);
			}
		} catch (DfException dfe) {
			throw new DfException("Error while closing the collection : "
					+ dfe.getMessage());
		}
	}

}
