package gov.dcra.filenet.create;

import gov.dcra.filenet.connection.DCRAFileNetConnection;
import gov.dcra.filenet.constants.Constants;
import gov.dcra.filenet.util.DCRAFileNetUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;

import com.filenet.api.collection.ContentElementList;
import com.filenet.api.constants.AutoClassify;
import com.filenet.api.constants.AutoUniqueName;
import com.filenet.api.constants.CheckinType;
import com.filenet.api.constants.DefineSecurityParentage;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;


public class CreateDocumentWithFileContent {

	private final static Logger log = Logger.getLogger(DocumentCreateExecute.class);
	private final String appPropsFile = Constants.APPLICATION_PROPS;
	private Properties appProps = new Properties();
	
	public static void main(String[] args) {
		
		CreateDocumentWithFileContent createDoc=new CreateDocumentWithFileContent();
		createDoc.processCreate();
	}
	
	private void processCreate() {

		DCRAFileNetConnection conn = null;
		DCRAFileNetUtil exportUtil = null;
		Domain domain = null;
		ObjectStore os = null;
			
		
		try {

			log.debug("Start Processing......");
			appProps.load(CreateDocumentWithFileContent.class.getResourceAsStream(appPropsFile));
			
			conn = new DCRAFileNetConnection();
			exportUtil = new DCRAFileNetUtil();
			domain = conn.getDomain();
			os = exportUtil.getObjectStore(domain,appProps.getProperty(Constants.MSG_OBJECTSTORE_NAME));
			String folderPath=appProps.getProperty(Constants.TARGET_FOLDER_PATH);
			
			String file="C:\\Temp\\hello.txt";
					
			create(getFolder(os,folderPath),new FileInputStream(new File(file)),FilenameUtils.getBaseName(file));
			
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public Folder getFolder(ObjectStore os,String folderPath) throws Exception {

		Folder folder=null;
		folder=Factory.Folder.fetchInstance(os, folderPath, null); 
		return folder;

	}
	
	public void create(Object parent,InputStream fileStream,String fileName) throws Exception {
		Folder folder = (Folder) parent;
		Document document = createDocument(folder.getObjectStore(), fileStream, fileName);
		folder.file(document, AutoUniqueName.AUTO_UNIQUE, null,
				DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE).save(
				RefreshMode.NO_REFRESH);
	}

	private Document createDocument(ObjectStore objectStore,InputStream fileStream,String fileName) throws Exception  {
		Document document = Factory.Document.createInstance(objectStore, "Document");
		setProperties(document.getProperties());
		document.set_ContentElements( getContentElements(fileStream,fileName));
		document.checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION );
		document.save(RefreshMode.REFRESH);
		return document;
	}

	private void setProperties(com.filenet.api.property.Properties p) {
		p.putValue("DocumentTitle","Test_"+new Date().getTime());
		p.putValue("Name","Hello");
	}
	

	@SuppressWarnings("unchecked")
	private ContentElementList getContentElements(InputStream fileStream,String fileName)  throws Exception {
		ContentElementList contentElementList = Factory.ContentElement.createList();
		contentElementList.add( createStringContent(fileStream,fileName) );
		return contentElementList;
	}

	private ContentTransfer createStringContent(InputStream fileStream,String fileName)  throws Exception {
		ContentTransfer content = Factory.ContentTransfer.createInstance();
		content.set_RetrievalName(fileName);
		content.setCaptureSource(fileStream);
		content.set_ContentType("text/plain");
		return content;
	}
}