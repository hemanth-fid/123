/**
* This precondition class is to add the component with validation.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* DShivnani			   09/17/2010	     1.0          Created
* #######################################################################################################
*/
package org.ifc.idocs.library.actions;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.AccessibilityService;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.action.IActionPrecondition;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.docbase.VdmUtil;

public class AddComponentFSPrecondition
    implements IActionPrecondition {

    public AddComponentFSPrecondition(){
    }

    public String[] getRequiredParams(){
        return null;
    }

    public boolean queryExecute(String strAction, IConfigElement config, 
    		ArgumentList arg, Context context, Component component){
        boolean bExecute=false;
        try {
	        IDfSession dfSession = component.getDfSession();
	        String strObjectId = arg.get("objectId");
			DfLogger.info(this, " :: queryExecute : "+dfSession.getLoginUserName(), null, null);
			DfLogger.info(this," :: queryExecute() : component : "+component.getComponentId()+" strObjectId : "+strObjectId,null,null); 
	        String strLockOwner = arg.get("lockOwner");
			String strUserName = dfSession.getLoginUserName(); 
		        if(strUserName != null && strLockOwner != null && strLockOwner.length() > 0 && !strUserName.equals(strLockOwner)){
					DfLogger.info(this," :: queryExecute() : return from UserName validation",null,null); 
					return bExecute;
		        }		
	        }catch (DfException e) {
				DfLogger.error(this,": <<Exception>> : "+e.getMessage(),null,e);
			}
	
        String strCompoundArchitecture = arg.get("compoundArchitecture");
        DfLogger.info(this," :: queryExecute() : strCompoundArchitecture : "+strCompoundArchitecture,null,null);
        if(!VdmUtil.isEditable(strCompoundArchitecture)){
        	DfLogger.info(this," :: queryExecute() : return from VdmUtil validation",null,null); 
        	return bExecute;
        }
        boolean bAccessibilityOn = AccessibilityService.isAllAccessibilitiesEnabled();
        String strComponentId = component.getComponentId(bAccessibilityOn);
        DfLogger.info(this," :: strComponentId : "+strComponentId,null,null); 
        if(strComponentId.equals("vdmlist") || strComponentId.equals("vdmliststreamline") || strComponentId.equals("objectlist") )
        {
        	DfLogger.info(this," :: queryExecute() : set return true",null,null);
        	bExecute = true;
        }
        return true;
    }
}