package com.amex.ngdp.dataflow.batch;

import java.io.IOException;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.Sum;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.TypeDescriptors;

import com.amex.ngdp.dataflow.common.bigquery.Schema;
import com.amex.ngdp.dataflow.common.model.InputRecord;
import com.amex.ngdp.dataflow.common.options.BigQueryIngestOptions;
import com.amex.ngdp.dataflow.common.transform.ParseAndConvertToInputRecord;
import com.amex.ngdp.dataflow.common.utils.JsonSchemaReader;
import com.amex.ngdp.dataflow.common.utils.MathUtils;
import com.google.api.services.bigquery.model.TableRow;


public class BigQueryIngestPipeline {

  private static final String SCHEMA_FILE = "./schema.json";

  public static void main(String... args) throws IOException {
    BigQueryIngestOptions options =
        PipelineOptionsFactory.fromArgs(args).as(BigQueryIngestOptions.class);
    	executePipeline(options);
  }

  private static void executePipeline(BigQueryIngestOptions options) throws IOException {
    Pipeline p = Pipeline.create(options);

    Schema schema = new Schema(JsonSchemaReader.readSchemaFile(SCHEMA_FILE));
    String bqColUser = schema.getColumnName(0);
    String bqColAmount = schema.getColumnName(1);

   
    p.apply("ReadFromStorage", TextIO.read().from(options.getBucketUrl() + "/*"))

        
        .apply("ConvertToInputRecord", ParDo.of(new ParseAndConvertToInputRecord()))

       
        .apply(
            "CreateKVPairs",
            MapElements.into(
                    TypeDescriptors.kvs(TypeDescriptors.strings(), TypeDescriptors.doubles()))
                .via((InputRecord record) -> KV.of(record.getUser(), record.getAmount())))

      
        .apply("SumAmountsPerUser", Sum.doublesPerKey())

        // Write to BigQuery.
        .apply(
            "WriteToBigQuery",
            BigQueryIO.<KV<String, Double>>write()
                .to(options.getBqTableName())
                .withSchema(schema.getTableSchema())
                .withFormatFunction(
                    (KV<String, Double> record) ->
                        new TableRow()
                            .set(bqColUser, record.getKey())
                            .set(bqColAmount, MathUtils.roundToTwoDecimals(record.getValue())))
                .withCreateDisposition(BigQueryIO.Write.CreateDisposition.CREATE_IF_NEEDED)
                .withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_APPEND));
    p.run();
  }
}
