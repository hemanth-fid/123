package org.ifc.idocs.editiomperformers;




import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;
import  org.ifc.idocs.refreshproject.RefreshPerformerUtility;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfGroup;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.LocaleService;
import com.documentum.web.form.Form;
import com.documentum.web.form.IReturnListener;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.Link;
import com.documentum.web.form.control.Panel;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.docbase.ObjectCacheUtil;
import com.documentum.webcomponent.common.WebComponentErrorService;
import com.documentum.webcomponent.library.locator.ILocator;
import com.documentum.webcomponent.library.locator.LocatorItemResultSet;

public class EditIOMPerformers extends Component {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String m_strFormID = null;
	public String m_strDocumentID = null;
	public String m_strWorkflowID = null;
	public String m_calling_ctrl = null;
	public String strObjectId=null;
	public String MESSAGE = IDocsConstants.MSG_EMPTY_STRING;
	public int m_no_of_approvers1;
	public int m_no_of_approvers2;
	public int m_no_of_approvers3;
	
	private static final NlsResourceBundle m_nlsResourceBundle = new NlsResourceBundle("org.ifc.idocs.editiomperformers.EditIOMPerformersNlsProp");
	private static final String QRY_VARIABLE_CHRONICLEID = "<chronicleId>";
	private static final String QRY_VARIABLE_USERNAME = "<userName>";
	private static final String QRY_VARIABLE_WORKFLOWID = "<workflowId>";
	public  static final String[] LEVEL ={"","first","second","third"};
	public static final String[] LEVEL_SUFFIX ={"","f","s","t"};
	public static final String LBL_LEVEL = "lbl_level";
	public static final String _APPROVER_ = "_approver_";
	public static final String _PROXY_ = "_proxy_";
	public static final String APPROVE = "approve";
	public static final String APPROVEPROXIE = "approveproxie";
	public static final String PROXY = "proxy";
	private final String PANEL_SUCCESS = "success";
	private final String PANEL_FAILURE = "failure";
	private int m_no_of_levels = 3;
	private Panel successpanel;
	private Panel failurepanel;
	private int workitemLevel = 0;
	String workflowId = null;
	private int acquiredWorkitemLevel = 0;
	private HashMap mapOfActivitiesNPerformerGrp = new HashMap();
	private ArrayList acquiredApproversList = new ArrayList();
	/**
	 * 
	 * @return
	 */
	public String getCallingControl() {
		return m_calling_ctrl;
	}

	/**
	 * 
	 * @param ctrlname
	 * @return
	 */
	public String setCallingControl(String ctrlname) {
		return m_calling_ctrl = ctrlname;
	}

	/**
	 * 
	 * @param formobj 
	 * @param level
	 * @return
	 */
	public int getNoOfApprovers(int level) {
		if (level == 1) {
			return m_no_of_approvers1;
		}else if(level == 2) {
			return m_no_of_approvers2;
		}else if(level == 3) {
			return m_no_of_approvers3;
		}else{
			return 0;
		}
		
	}
	
	/**
	 * 
	 * @param formObject
	 * @param level
	 */
	public void setNoOfApprovers(IDfSysObject formObject,int level){
		if (level == 1) {
			try {
				String numberofApprovals = formObject.getString("first_approval_choice");
				m_no_of_approvers1 = Integer.parseInt(numberofApprovals);
			} catch (DfException e) {
				e.printStackTrace();
				m_no_of_approvers1 = 8;
			}			
		} else if (level == 2) {
			try {
				String numberofApprovals = formObject.getString("second_approval_choice");
				m_no_of_approvers2 = Integer.parseInt(numberofApprovals);
			} catch (DfException e) {
				e.printStackTrace();
				m_no_of_approvers2 = 4;
			}			
		} else {
			try {
				String numberofApprovals = formObject.getString("third_approval_choice");
				m_no_of_approvers3 = Integer.parseInt(numberofApprovals);
			} catch (DfException e) {
				e.printStackTrace();
				m_no_of_approvers3 = 2;
			}
		}


	}

	/**
	 * 
	 */
	public void onInit(ArgumentList args) {
		super.onInit(args);
		// Success Panel
        successpanel = (Panel)getControl(PANEL_SUCCESS,Panel.class);
        // Failure Panel
        failurepanel = (Panel)getControl(PANEL_FAILURE,Panel.class);
		strObjectId = args.get("objectId");
		DfLogger.debug(this," :: onInit :Document Id:" + strObjectId, null, null);
		
		try {
			if (canRefreshIOMPerformers(strObjectId) == true) {
				m_strFormID = fetchFormId(strObjectId);
				if (null != m_strFormID && m_strFormID.trim().length() > 0){
					successpanel.setVisible(true);
					failurepanel.setVisible(false);
					populateData(strObjectId);
				} else {
					DfLogger.debug(this," :: onInit: Unable to fetch form Id", null, null);
				}
			} else {
				DfLogger.debug(this," :: onInit: Cannot Refresh IOM Performers", null, null);
			}
		} catch (Exception e) {
			DfLogger.error(this, " :: onInit() : " + e.getMessage(), null, null);
		}
	}

	/**
	 * 
	 * @param objectId
	 * @return
	 */
	private String fetchFormId(String objectId) {
		String strFormId = null;
		IDfCollection formIdCollection = null;
		try {
			String docChronicleId = IDocDocbaseAttributeTagUtility.getSysObjectAttribute(getDfSession(), objectId, IDocsConstants.MSG_I_CHRONICLE_ID);
			String formIdQuery = IdocsUtil.getMessage("QRY_FETCH_FORM_ID");
			formIdQuery = formIdQuery.replace(QRY_VARIABLE_CHRONICLEID, docChronicleId);
			formIdCollection = IdocsUtil.executeQuery(getDfSession(), formIdQuery, IDfQuery.DF_READ_QUERY);
			while (formIdCollection.next()) {
				strFormId = formIdCollection.getString(IDocsConstants.STR_R_COMPONENT_ID);
				String strObjectType = IDocDocbaseAttributeTagUtility.getSysObjectAttribute(getDfSession(), strFormId, IDocsConstants.MSG_R_OBJECT_TYPE);
				if (null != strObjectType && strObjectType.trim().length() > 0 &&
						strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_IOM_FORM)) {
					break;
				}
			}
		} catch (DfException e) {
			DfLogger.error(this, " :: fetchFormId : " + e.getMessage(), null, null);
		} finally {
			try {
				if(null != formIdCollection) {
					formIdCollection.close();
				}
			} catch (DfException e) {
				DfLogger.error(this, " :: fetchFormId : " + e.getMessage(), null, null);
			}
		}
		DfLogger.debug(this, " :: fetchFormId: strFormId: " + strFormId, null, null);
		return strFormId;
	}

	/**
	 * 
	 * @param objectId
	 * @return
	 */
	private boolean canRefreshIOMPerformers(String objectId) {
		
		boolean canRefresh = false;
		String templateName = IdocsUtil.getTemplateTitle(getDfSession(), objectId);
		String strObjectType = IDocDocbaseAttributeTagUtility.getSysObjectAttribute(getDfSession(), objectId, IDocsConstants.MSG_R_OBJECT_TYPE);
		String workflowStatus = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(getDfSession(), objectId, IDocsConstants.MSG_WORKFLOW_STATUS, strObjectType);
		String ownerName = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(getDfSession(), objectId, IDocsConstants.MSG_OWNER_NAME, strObjectType);
		DfLogger.debug(this, " :: canRefreshIOMPerformers: objectId: " + objectId +
				", templateName: " + templateName + ", workflowstatus: " + workflowStatus + ", ownerName: " + ownerName, null, null);
		try { 
			if (null != templateName && templateName.trim().length() > 0 && 
					(templateName.equals(IdocsUtil.getMessage("MSG_INTERNAL_OFFICE_MEMORANDUM")) == true)) {
				if (workflowStatus != null && workflowStatus.trim().length() > 0) {
					if (workflowStatus.equalsIgnoreCase(IDocsConstants.MSG_COMPLETED) == false) {
						if (null != ownerName && ownerName.trim().length() > 0 && (ownerName.equalsIgnoreCase(getDfSession().getLoginUserName()) == true)) {
							if (workflowStatus.equals(IdocsUtil.getMessage("IOM_SETUP_INITIATE_APPROVAL")) == false) {
								canRefresh = true;
							} else {
								DfLogger.debug(this, " :: canRefreshIOMPerformers: Please finish the activity: " +
									IdocsUtil.getMessage("IOM_SETUP_INITIATE_APPROVAL") + " to perform refresh operation", null, null);
								displayErrorMessage("MSG_FINISH_SETUP_INITIATE_APPROVAL", IdocsUtil.getMessage("IOM_SETUP_INITIATE_APPROVAL"), true);
								canRefresh =  false;							
							}
						} else {
							boolean isAdminUser = IdocsUtil.isIFCDocsAdmin(getDfSession());
							if(isAdminUser){
								canRefresh = true;
							}else{
								DfLogger.debug(this, " :: canRefreshIOMPerformers: Only workflow initiator: " + ownerName + " can refresh performers", null, null);
								displayErrorMessage("MSG_WF_INITIATOR_ONLY_CAN_REFRESH",  null, true);
								canRefresh =  false;
							}
						}
					} else {
						DfLogger.debug(this, " :: canRefreshIOMPerformers: Workflow is completed on the document", null, null);
						displayErrorMessage("MSG_WF_COMPLETED",  ownerName, true);
						canRefresh =  false;
					}
				} else {
					DfLogger.debug(this, " :: canRefreshIOMPerformers: Document is not part of workflow", null, null);
					displayErrorMessage("MSG_DOCUMENT_NOT_IN_WORKFLOW",  ownerName, true);
					canRefresh =  false;
				}
				
			}
			 else {
				 DfLogger.debug(this, " :: canRefreshIOMPerformers: This operation can be done only on : " +
						 IdocsUtil.getMessage("MSG_INTERNAL_OFFICE_MEMORANDUM") + " template", null, null);
				 displayErrorMessage("MSG_NON_IOM_TEMPLATE", IdocsUtil.getMessage("MSG_INTERNAL_OFFICE_MEMORANDUM"), true);
				 canRefresh =  false;
			}
			
		} catch (DfException e) {
			DfLogger.error(this, " :: canRefreshIOMPerformers: exception : " + e.getMessage(), null, null);
		}
		DfLogger.debug(this, " :: canRefreshIOMPerformers: canRefresh: " + canRefresh, null, null);
		
		return canRefresh;
	}

	/**
	 * This is a utility method to display WDK error messages from startWorkFlow component.
	 * This method gets the ErrorMessage for the current template and diplays that in the 
	 * iDocs application UI
	 * 
	 */
	private void displayErrorMessage(String errorMessageNls , String value, boolean isNls){
		successpanel.setVisible(false);
		failurepanel.setVisible(true);
		if(isNls){
			MESSAGE = m_nlsResourceBundle.getString(errorMessageNls, new String[]{value}, LocaleService.getLocale());
			
		}else{
			MESSAGE = errorMessageNls;
		}

		Label errorMessageLabel = (Label)getControl("message",Label.class);
		if(null != errorMessageLabel ){
			DfLogger.debug(this, " :: displayErrorMessage : label set " + MESSAGE, null, null);
			errorMessageLabel.setLabel(MESSAGE);
		}else{
			DfLogger.debug(this, " :: displayErrorMessage : Control Not found " + MESSAGE, null, null);
		}
	}

	/**
	 * 
	 * @throws DfException
	 */
	private void populateData(String objectId) {
		IDfCollection workflowIdColl = null;
		IDfCollection activityRuntimeStateColl = null;
		try {
			// Logic to disable edit links for approvers and proxies if they have finished the workflow
			String docChronicleId = IDocDocbaseAttributeTagUtility.getSysObjectAttribute(getDfSession(), objectId, IDocsConstants.MSG_I_CHRONICLE_ID);
			workflowIdColl = IDocDocbaseAttributeTagUtility.fetchAnyAttrValFrmAnyType(IDocsConstants.MSG_KEYWORD_DISTINCT +
											IDocsConstants.MSG_SINGLE_SPACE + IDocsConstants.R_WORKFLOW_ID, IDocsConstants.MSG_DMI_PACKAGE,
											IDocsConstants.MSG_KEYWORD_ANY + IDocsConstants.MSG_SINGLE_SPACE + IDocsConstants.MSG_R_COMPONENT_CHRON_ID, docChronicleId, getDfSession());
			workflowId = IdocsUtil.getCommaSeparatedStrFromColl(workflowIdColl, IDocsConstants.R_WORKFLOW_ID);
			DfLogger.debug(this," :: populateData: workflowId: " + workflowId, null, null);
			String qryActivityRuntimeState = IdocsUtil.getMessage("QRY_ACTIVITY_RUNTIME_STATE");
			qryActivityRuntimeState = qryActivityRuntimeState.replace(QRY_VARIABLE_WORKFLOWID, workflowId);
			activityRuntimeStateColl = IdocsUtil.executeQuery(getDfSession(), qryActivityRuntimeState, IDfQuery.DF_READ_QUERY); 
			
			getActivitiesAndPerformerGrp(activityRuntimeStateColl);
			setAcquiredWorkitemLevel(workflowId);
			IDfSysObject formobj = (IDfSysObject) ObjectCacheUtil.getObject(getDfSession(),m_strFormID);
			
			for (int levelCount = 1; levelCount <= m_no_of_levels; levelCount++) {
				// Iterate through each Level
				setNoOfApprovers(formobj, levelCount);
				Label lblLevelCount = (Label) getControl("level_" + levelCount, Label.class);
				boolean enableDisableLevelLabel = false;
				for (int approverCount = 1; approverCount <= getNoOfApprovers(levelCount); approverCount++) {//Iterate through all approvers for each level
					Panel panelApproverProxy = (Panel) getControl("panelApproverProxy" + levelCount + approverCount, Panel.class);
					DfLogger.debug(this, " :: populateData: panelApproverProxy: " + panelApproverProxy.getName(), null, null);
					String approverValue = formobj.getString(LEVEL[levelCount] + APPROVE + approverCount);
					if (null != approverValue && approverValue.trim().length() > 0) {
						panelApproverProxy.setVisible(true);
						enableDisableLevelLabel = true;
						DfLogger.debug(this, ":: populateData: Approver: " + approverCount, null, null);
						Label lblApproverValue = (Label) getControl(LBL_LEVEL + levelCount + _APPROVER_ + approverCount, Label.class);
						lblApproverValue.setLabel(approverValue);
						DfLogger.debug(this, " :: populateData: Label: " + lblApproverValue.getName() + ", Value: " +
								formobj.getString(LEVEL[levelCount] + APPROVE + approverCount), null, null);
						Label lblProxyValue = (Label) getControl(LBL_LEVEL + levelCount + _PROXY_	+ approverCount, Label.class);
						lblProxyValue.setLabel(formobj.getAllRepeatingStrings(LEVEL[levelCount] + APPROVEPROXIE	+ approverCount +
								"1", IdocsConstants.MSG_COMMA));
						DfLogger.debug(this, " :: populateData: Proxy Label: " + lblProxyValue.getName() +
								", Value: " + formobj.getAllRepeatingStrings(LEVEL[levelCount] + APPROVEPROXIE	+ approverCount +
										"1", IdocsConstants.MSG_COMMA), null, null);
						DfLogger.debug(this, " ::populateData: Approver:" + LEVEL[levelCount] + APPROVE + approverCount, null, null);
						DfLogger.debug(this, " :: populateData: proxy:" + LEVEL[levelCount] + APPROVEPROXIE + approverCount + "1", null, null);
						
						// Disabling Edit link
						Link approverEditLinkLabel = (Link) getControl("link_level" + levelCount + _APPROVER_ + approverCount, Link.class);
						Link proxyEditLinkLable = (Link) getControl("proxylink_level"  + levelCount + _PROXY_ + approverCount, Link.class);
						if (workitemLevel == levelCount) {
							
							if (mapOfActivitiesNPerformerGrp.size() > 0) {
								if (mapOfActivitiesNPerformerGrp.containsKey(String.valueOf(approverCount))) {
									DfLogger.debug(this," ::populateData: " + LEVEL[levelCount] + APPROVE + approverCount +
											" didn't finish the activity: Hence enbaling edit link", null, null);
									
								} else {
									DfLogger.debug(this," ::populateData: " + LEVEL[levelCount] + APPROVE + approverCount +
									"  finished the activity: Hence disbaling edit link", null, null);
									approverEditLinkLabel.setVisible(false);
									proxyEditLinkLable.setVisible(false);
								}
							} else {
								//disable corresponding approval n proxy links
								approverEditLinkLabel.setVisible(false);
								proxyEditLinkLable.setVisible(false);
							}
						} else if(workitemLevel == 0 || acquiredWorkitemLevel >= levelCount){
							
							if (acquiredApproversList.size() > 0){
								if (acquiredApproversList.contains(String.valueOf(approverCount))) {
									approverEditLinkLabel.setVisible(false);
									proxyEditLinkLable.setVisible(false);
									acquiredApproversList.remove(String.valueOf(approverCount));
								}
							}
							
						}
					} else {
						panelApproverProxy.setVisible(false);
						/**  REmove if not needed*/
						//lblLevelCount.setVisible(false);
					}
				}
				if (enableDisableLevelLabel == true) {
					lblLevelCount.setLabel("Approval Level " + levelCount);
					lblLevelCount.setVisible(true);
					
				} else {
					lblLevelCount.setVisible(false);
				}
			}
		} catch (DfException e) {
			DfLogger.error(this, " :: populateData: exception : " + e.getMessage(), null, null);
		} finally {
			try {
				if(null != workflowIdColl) {
					workflowIdColl.close();
				}
				if (null != activityRuntimeStateColl) {
					activityRuntimeStateColl.close();
				}
			} catch (DfException e) {
				DfLogger.error(this, " :: populateData : " + e.getMessage(), null, null);
			}
		}
	}

	
	private void setAcquiredWorkitemLevel(String workflowId) {
		IDfCollection activityAcquiredStateColl = null;
		try {
			boolean isAcquiredWorkItemFound = false;
			// Disabling edit links for approvers who acquired the task
			String qryActivityAcquiredState = IdocsUtil.getMessage("QRY_ACTIVITY_ACQUIRED_STATE");
			qryActivityAcquiredState = qryActivityAcquiredState.replace(QRY_VARIABLE_WORKFLOWID, workflowId);
			activityAcquiredStateColl = IdocsUtil.executeQuery(getDfSession(), qryActivityAcquiredState, IDfQuery.DF_READ_QUERY); 
			while (activityAcquiredStateColl.next()) {
				String strActivityName = activityAcquiredStateColl.getString(IDocsConstants.MSG_OBJECT_NAME);
				String strTaskState = activityAcquiredStateColl.getString(IDocsConstants.MSG_TASK_STATE);
				if((strActivityName !=null && strActivityName.trim().length() > 0) && strActivityName.equals(IdocsUtil.getMessage("IOM_SETUP_INITIATE_APPROVAL")) == false){
					if (isAcquiredWorkItemFound == false && null != strTaskState && strTaskState.trim().length() > 0 ){
	
						if (null != strActivityName && strActivityName.trim().length() > 0 && strActivityName.startsWith("First")) {
							acquiredWorkitemLevel = 1;
							isAcquiredWorkItemFound = true;
						} else if (null !=  strActivityName && strActivityName.trim().length() > 0 && strActivityName.startsWith("Second")) {
							acquiredWorkitemLevel = 2;
							isAcquiredWorkItemFound = true;
						} else if (null != strActivityName && strActivityName.trim().length() > 0 && strActivityName.startsWith("Third")) {
							acquiredWorkitemLevel = 3;
							isAcquiredWorkItemFound = true;
						} else {
							DfLogger.debug(this," :: setAcquiredWorkitemLevel: Unable to find the workitem level", null, null);
						}
					}
					if (acquiredWorkitemLevel > 0) {
						String approvalNumber = strActivityName.substring(strActivityName.length()-1);
						DfLogger.debug(this," :: setAcquiredWorkitemLevel: ApprovalValue in Level " +
								acquiredWorkitemLevel + ": is "+ approvalNumber, null, null);
						acquiredApproversList.add(approvalNumber);
					}
				}else{
					DfLogger.debug(this," :: setAcquiredWorkitemLevel: Unable to find the Activity Name.", null, null);
				}
			} 
		} catch (DfException e) {
			DfLogger.error(this, " :: setAcquiredWorkitemLevel : " + e.getMessage(), null, null);
		} finally {
			try {
				if(null != activityAcquiredStateColl) {
					activityAcquiredStateColl.close();
				}
			} catch (DfException e) {
				DfLogger.error(this, " :: setAcquiredWorkitemLevel : " + e.getMessage(), null, null);
			}
		}

	}

	private HashMap getActivitiesAndPerformerGrp(IDfCollection activityRuntimeStateColl) {
				
		try {
			boolean isDormantWorkItemFound = false;
			
			while (activityRuntimeStateColl.next()) {
				String strActivityName = activityRuntimeStateColl.getString(IDocsConstants.MSG_OBJECT_NAME);
				String strPerformerGrp = activityRuntimeStateColl.getString(IDocsConstants.MSG_R_PERFORMER_NAME);
				
				if (isDormantWorkItemFound == false && null != strActivityName && strActivityName.trim().length() > 0) {
					if (strActivityName.startsWith("First")) {
						workitemLevel = 1;
						isDormantWorkItemFound = true;
					} else if (strActivityName.startsWith("Second")) {
						workitemLevel = 2;
						isDormantWorkItemFound = true;
					} else if (strActivityName.startsWith("Third")) {
						workitemLevel = 3;
						isDormantWorkItemFound = true;
					} else {
						DfLogger.debug(this," :: getActivitiesAndPerformerGrp: Unable to find the workitem level", null, null);
					}
				}
				if (workitemLevel > 0) {
					String approvalNumber = strActivityName.substring(strActivityName.length()-1);
					DfLogger.debug(this," :: getActivitiesAndPerformerGrp: ApprovalValue in Level " + workitemLevel + ": is "+ approvalNumber, null, null);
					mapOfActivitiesNPerformerGrp.put(approvalNumber, strPerformerGrp);
				}
			}
		} catch (DfException e) {
			DfLogger.error(this, " :: getActivitiesAndPerformerGrp : " + e.getMessage(), null, null);
		}
		return mapOfActivitiesNPerformerGrp;
	}

	/**
	 * 
	 */
	public boolean onCommitChanges() {
		if (null != m_strFormID && m_strFormID.trim().length() > 0){
			IDfGroup mainPerformerGroup = null;
			IDfGroup innerPerformerFormGroup = null;
			IDfSessionManager adminSessionManager = null;
			IDfSession adminSession =  null;
			boolean isFormSaveRequired = false; 
			try {
				adminSessionManager = IdocsUtil.getAdminSessionManager(getDfSession());
				adminSession =  adminSessionManager.getSession(getDfSession().getDocbaseName());
				IDfSysObject formobj = (IDfSysObject) ObjectCacheUtil.getObject(adminSession,m_strFormID);
				DfLogger.debug(this," :: onCommitChanges: workitemLevel: " + workitemLevel, null, null);
				for (int levelCount = 1; levelCount <= m_no_of_levels; levelCount++) {
					DfLogger.debug(this," :: onCommitChanges: levelCount: " + levelCount, null, null);
					
					if (levelCount >= workitemLevel) {
						isFormSaveRequired = true;
						/** ACTION */
						// Adding level 1,2 and3 approvers(who didn't finish the activity) to their corresponding
						//form attributes notifyflevel, notifyslevel and notifytlevel.
						StringBuffer eachLevelApproverNamesForGettingEmailId = new StringBuffer(IDocsConstants.MSG_EMPTY_STRING); 
						StringBuffer eachLevelIndividualProxies = new StringBuffer(IDocsConstants.MSG_EMPTY_STRING); 
						for (int approverCount = 1; approverCount <= getNoOfApprovers(levelCount); approverCount++){
							innerPerformerFormGroup = null;
							eachLevelIndividualProxies = new StringBuffer(IDocsConstants.MSG_EMPTY_STRING);
							if (workitemLevel == levelCount) {
								mainPerformerGroup =  getCurrentPerformerGroup(adminSession,approverCount);
								DfLogger.debug(this," :: onCommitChanges: Main Performer group : " + mainPerformerGroup.getGroupName(), null, null);
								for(int i=0;i<mainPerformerGroup.getAllUsersNamesCount();i++){
									DfLogger.debug(this,"Users in mainperformergroup : "+ mainPerformerGroup.getAllUsersNames(i),null,null);
								}
								if(mainPerformerGroup!=null){
									try {
										RefreshPerformerUtility.updateDocSecurity(strObjectId,mainPerformerGroup,adminSession);
									} catch (IOException e) {
											e.printStackTrace();
									}
								}
								innerPerformerFormGroup = getFormGroupFromPerformerGroup(mainPerformerGroup,adminSession);
								DfLogger.debug(this," :: onCommitChanges: Adding Approval " + LBL_LEVEL + levelCount +
									_APPROVER_ + approverCount + " users to its corresponding performer grp " + mainPerformerGroup, null, null);
								if (null != mainPerformerGroup){
									mainPerformerGroup.removeAllUsers();
									mainPerformerGroup.save();
								}															
							}else if(workitemLevel < levelCount){
								/** This to update the inner peformer form group */
								try {
									String futureLevelFormGroupName = getFutureFormGroupName(levelCount,approverCount);
									DfLogger.debug(this, " :: onCommitChanges: futureLevelFormGroupName: " + futureLevelFormGroupName, null, null);
									innerPerformerFormGroup  = adminSession.getGroup(futureLevelFormGroupName);									
								} catch (Exception e) {
									e.printStackTrace();
								}
							}							
							if (innerPerformerFormGroup != null) {
								innerPerformerFormGroup.removeAllUsers();
								innerPerformerFormGroup.save();
							}								
							Label lblApproverValue = (Label) getControl(LBL_LEVEL + levelCount + _APPROVER_ + approverCount, Label.class);
							String strApproverValue = lblApproverValue.getLabel();
							DfLogger.debug(this, " :: onCommitChanges: strApproverValue: " + strApproverValue, null, null);
							Label lblProxyValue = (Label) getControl(LBL_LEVEL + levelCount + _PROXY_ + approverCount, Label.class);
							String strProxyValue = lblProxyValue.getLabel();
							DfLogger.debug(this, " :: onCommitChanges: Proxy Value Selected : " + strProxyValue, null, null);
							
							/** Set Primary Performer */
							if (null != strApproverValue  && strApproverValue.trim().length() > 0) {
								/** Adding Primary to the Form Object */
								formobj.setString(LEVEL[levelCount] + APPROVE + approverCount, strApproverValue);	
								/** Adding Primary to the Form Group */
								if(innerPerformerFormGroup != null){
									innerPerformerFormGroup.addUser(strApproverValue);
									DfLogger.debug(this, " :: onCommitChanges: strApproverValue SET : " + strApproverValue, null, null);
								}
								eachLevelApproverNamesForGettingEmailId = eachLevelApproverNamesForGettingEmailId.append(IdocsUtil.handleSingleQuote(strApproverValue)).append(IdocsConstants.MSG_COMMA);
							}
							
							/** Set Proxies */
							DfLogger.debug(this, " :: onCommitChanges: strProxyValue: " + strProxyValue, null, null);
							// flush all proxy values of each approver before insertion
							formobj.removeAll(LEVEL[levelCount] + APPROVEPROXIE	+ approverCount + "1");
							if (null != strProxyValue && strProxyValue.trim().length() > 0) {
								String[] arrProxyValues = strProxyValue.split(IdocsConstants.MSG_COMMA);
								/** Adding Proxies into the Form Object */
								for (int proxyValCnt = 0; proxyValCnt < arrProxyValues.length; proxyValCnt++) {
									DfLogger.debug(this, " :: onCommitChanges: strProxyValue: " + arrProxyValues[proxyValCnt], null, null);
									formobj.setRepeatingString(LEVEL[levelCount] + APPROVEPROXIE	+ approverCount + "1", proxyValCnt, arrProxyValues[proxyValCnt]);
									if(innerPerformerFormGroup != null){
										innerPerformerFormGroup.addUser(arrProxyValues[proxyValCnt]);
										DfLogger.debug(this, " :: onCommitChanges: strProxyValue: "+proxyValCnt+" : " + arrProxyValues[proxyValCnt], null, null);
									}
								}
								eachLevelIndividualProxies = eachLevelIndividualProxies.append(IdocsUtil.handleSingleQuote(strProxyValue)).append(IdocsConstants.MSG_COMMA);								
							}
							
							if(innerPerformerFormGroup != null){
								innerPerformerFormGroup.save();								
								DfLogger.debug(this, " :: onCommitChanges: innerPerformerFormGroup Updated. :"+innerPerformerFormGroup.getGroupName(), null, null);
							}
							DfLogger.debug(this," :: onCommitChanges: Form Group Save Complete", null, null);	
					
							if (null != eachLevelIndividualProxies && eachLevelIndividualProxies.length() > 0) {
								eachLevelIndividualProxies = eachLevelIndividualProxies.deleteCharAt(eachLevelIndividualProxies.length()-1);
								eachLevelApproverNamesForGettingEmailId = eachLevelApproverNamesForGettingEmailId.append(eachLevelIndividualProxies).append(IdocsConstants.MSG_COMMA);
							}
							String eachLevelIndividualProxiesMailIds = getPerformerEmailId(getDfSession(),eachLevelIndividualProxies,levelCount); 
							DfLogger.debug(this," :: onCommitChanges: eachLevelIndividualProxiesMailIds: " + eachLevelIndividualProxiesMailIds, null, null);
							formobj.setString(LEVEL[levelCount] + "approveproxieaddr" + approverCount, IDocsConstants.MSG_EMPTY_STRING);
							if (null != eachLevelIndividualProxiesMailIds && eachLevelIndividualProxiesMailIds.trim().length() > 0) {
								formobj.setString(LEVEL[levelCount] + "approveproxieaddr" + approverCount, eachLevelIndividualProxiesMailIds);
							}
						}
					
						if (null != eachLevelApproverNamesForGettingEmailId && eachLevelApproverNamesForGettingEmailId.length() > 0) {
							eachLevelApproverNamesForGettingEmailId = eachLevelApproverNamesForGettingEmailId.deleteCharAt(eachLevelApproverNamesForGettingEmailId.length()-1);
						}
						String eachLevelApproverMailIds = getPerformerEmailId(getDfSession(),eachLevelApproverNamesForGettingEmailId,levelCount);
						DfLogger.debug(this," :: onCommitChanges: eachLevelApproverMailIds: " + eachLevelApproverMailIds, null, null);
						if (null != eachLevelApproverMailIds && eachLevelApproverMailIds.trim().length() > 0) {
							formobj.setString("notify" + LEVEL_SUFFIX[levelCount] + "level", eachLevelApproverMailIds);
						}
					
					}else{
						/** Already passed activities. No Update. */
					}
										
				}
				DfLogger.debug(this, " :: onCommitChanges : isFormSaveRequired ="+ isFormSaveRequired, null, null);
				if(isFormSaveRequired){
					formobj.save();					
				}
				DfLogger.debug(this, " :: onCommitChanges : COMPLETE", null, null);
		} catch (DfException e) {
			DfLogger.error(this, " :: onCommitChanges : " + e.getMessage(), null, null);
		} finally {
				if(adminSessionManager != null){
					adminSessionManager.release(adminSession);
				}					
		}
	} 
	return super.onCommitChanges();
	}

	private String getFutureFormGroupName(int levelCount, int approverCount) {
		return "idocs_"+workflowId+"_l"+levelCount+"_form_"+approverCount;
	}
	
	private String getPerformerEmailId(IDfSession dfSession,
			StringBuffer eachLevelApproverNamesForGettingEmailId,int levelCount) {
		String eachLevelApproverMailIds = null;
		try {
			if(eachLevelApproverNamesForGettingEmailId != null && eachLevelApproverNamesForGettingEmailId.length() > 0){
				IDfCollection eachLevelApproverMailIdsColl = null;
				DfLogger.debug(this," :: onCommitChanges: users at Approver Level: " + levelCount +" are: " + eachLevelApproverNamesForGettingEmailId.toString(), null, null);
				eachLevelApproverMailIdsColl = IDocDocbaseAttributeTagUtility.fetchAnyAttrValFrmAnyType(IDocsConstants.MSG_USER_ADDRESS,
						IDocsConstants.MSG_DM_USER,	IdocsConstants.USER_NAME, eachLevelApproverNamesForGettingEmailId.toString(), getDfSession());
				eachLevelApproverMailIds = IdocsUtil.getCommaSeparatedStrFromColl(eachLevelApproverMailIdsColl, IDocsConstants.MSG_USER_ADDRESS);
				if(eachLevelApproverMailIdsColl != null )eachLevelApproverMailIdsColl.close();
			}
		} catch (DfException e) {
			e.printStackTrace();
		}
		return eachLevelApproverMailIds;
	}

	private IDfGroup getFormGroupFromPerformerGroup(IDfGroup performerGroup,
			IDfSession adminSession) {
		IDfGroup formGroup = null;
		try {
			if(performerGroup != null){
				IDfCollection groupMembersColl = null;
				groupMembersColl = performerGroup.getGroupsNames();
				String strFormGroup = IDocsConstants.MSG_EMPTY_STRING;
				while (groupMembersColl.next()) {
					strFormGroup = groupMembersColl.getString(IDocsConstants.MSG_GROUPS_NAMES);
					DfLogger.debug(this," :: onCommitChanges: strFormGroup: " + strFormGroup, null, null);
					if (strFormGroup.contains("form")) {
					break;
					}
				}
				formGroup = adminSession.getGroup(strFormGroup);
			} 
		}catch (DfException e) {
				e.printStackTrace();
		}
		return formGroup;
	}

	private IDfGroup getCurrentPerformerGroup(IDfSession adminSession,
			int approverCount) {
		IDfGroup performerGroup = null;
		try {
			String performerGrp = null;
			DfLogger.debug(this," :: onCommitChanges: mapOfActivitiesNPerformerGrp.size(): " + mapOfActivitiesNPerformerGrp.size(), null, null);
			if (mapOfActivitiesNPerformerGrp.size() > 0 && mapOfActivitiesNPerformerGrp.containsKey(String.valueOf(approverCount))) {
				performerGrp = (String)mapOfActivitiesNPerformerGrp.get(String.valueOf(approverCount));								
			}
			if(performerGrp != null && performerGrp.trim().length() > 0)
				performerGroup = adminSession.getGroup(performerGrp);
		} catch (DfException e) {
			e.printStackTrace();
		}
		return performerGroup;
	}  
		
	/**
	 * 
	 * @param link
	 * @param args
	 */
	public void onEditApprover(Link link, ArgumentList args) {
		final String primaryApprover;
		final int endIndex;
		final String proxy;
		ArgumentList selectArgs = new ArgumentList();
		setCallingControl(args.get("argapprover"));
		String strProxyUsers = ((Label) getControl(args.get("argapprover"), Label.class)).getLabel();
		DfLogger.debug(this, " :: onEditApprover: strProxyUsers: " + strProxyUsers, null, null);
		if (null != strProxyUsers && strProxyUsers.trim().length() > 0) {
			strProxyUsers = IdocsUtil.handleSingleQuote(strProxyUsers);
			DfLogger.debug(this," :: onEditApprover: strProxyUsers after handling single quote in usernames: " + strProxyUsers, null, null);
			IDfCollection strSelectedObjectIdsColl = IDocDocbaseAttributeTagUtility.fetchAnyAttrValFrmAnyType(IDocsConstants.MSG_R_OBJECT_ID,
														IDocsConstants.MSG_DM_USER,	IdocsConstants.USER_NAME, strProxyUsers, getDfSession());
			String strSelectedObjectIds = IdocsUtil.getCommaSeparatedStrFromColl(strSelectedObjectIdsColl, IDocsConstants.MSG_R_OBJECT_ID);
			try {
				if (null != strSelectedObjectIdsColl) {
					strSelectedObjectIdsColl.close();
				}
			} catch(DfException dfe) {
				DfLogger.error(this, " :: onEditApprover : " + dfe.getMessage(), null, null);
			} 
			if (null != strSelectedObjectIds && strSelectedObjectIds.trim().length() > 0) {
				selectArgs.add("selectedobjectids", strSelectedObjectIds);
			} else {
				DfLogger.debug(this, " :: onEditApprover: Unable to fetch user's object ids for users:  " + strProxyUsers, null, null);
			}
		} else {
			DfLogger.debug(this, " :: onEditApprover: None of the users are available for Proxy Label:  " + args.get("argapprover"), null, null);
		}
		
		selectArgs.add("component", "userorgrouplocator");
		selectArgs.add("callerComponent","editiomperformers");
		final Link linkCopy = link;
		DfLogger.debug(this, " :: onEditApprover: linkCopy: " + linkCopy.getName(), null, null);
		primaryApprover = ((Label) getControl(args.get("primaryApprover"), Label.class)).getLabel();
		DfLogger.debug(this, " :: onEditApprover: primaryApprover: " + primaryApprover, null, null);
		endIndex = primaryApprover.length() + 1; // This "1" is for removing extra coma after user name  
		proxy = ((Label) getControl(args.get("proxy"), Label.class)).getLabel();
		if(link.getName().contains(PROXY)) {
			selectArgs.add("multiselect","true");
		}
		
		
		setComponentNested("userorgrouplocatorcontainer", selectArgs, getContext(), new IReturnListener() {
			public void onReturn(Form form, java.util.Map map) {
				// Handle return event from select permission set
				// component.
				if (null != map) {
					LocatorItemResultSet setLocatorSelections = (LocatorItemResultSet) map.get(ILocator.LOCATORSELECTIONS);
					if (linkCopy.getName().contains(PROXY) ==  true) {
						if (null != setLocatorSelections) {
							int proxyUsersCount = setLocatorSelections.getResultsCount();
							DfLogger.debug(this, " :: onEditApprover: proxyUsersCount: " + proxyUsersCount, null, null);
							StringBuffer strProxyUserName = new StringBuffer(IDocsConstants.MSG_EMPTY_STRING);

							for (int proxyUserNo = 0; proxyUserNo < proxyUsersCount; proxyUserNo++) {
								DfLogger.debug(this, " :: onEditApprover: ProxyUserName: " +
										(String) setLocatorSelections.getObjectAttributeValue(proxyUserNo, IdocsConstants.USER_NAME), null, null);
								strProxyUserName = strProxyUserName.append((String) setLocatorSelections.getObjectAttributeValue(
										proxyUserNo, IdocsConstants.USER_NAME)).append(IdocsConstants.MSG_COMMA);
							}
							if (strProxyUserName.indexOf(primaryApprover) != -1) {
								Object params[] = new Object[1];
		           			 	params[0] = primaryApprover;
		           			 	WebComponentErrorService.getService().setNonFatalError(form, "MSG_PRIMARY_AVAILABLE", params, null);
								DfLogger.debug(this, ":: onEditApprover: primaryApprover is found in proxy. SO deleting primary approver: " + primaryApprover, null, null);
								strProxyUserName = strProxyUserName.delete(strProxyUserName.indexOf(primaryApprover), strProxyUserName.indexOf(primaryApprover) + endIndex);
							}
							
							DfLogger.debug(this," :: onEditApprover: strProxyUserName length: " + strProxyUserName.length(), null, null);
							if (null != strProxyUserName && strProxyUserName.length() > 0) {
								char trailingComma = strProxyUserName.charAt(strProxyUserName.length()-1);
								if (IdocsConstants.MSG_COMMA.equals(Character.toString(trailingComma))) {
									strProxyUserName = strProxyUserName.deleteCharAt(strProxyUserName.length()-1);
								}
								
							}
							DfLogger.debug(this, " :: onEditApprover: strProxyUserName After removing coma: " + strProxyUserName.toString(), null, null);
							// get label control name
							String strCtrlName = getCallingControl();
							((Label) getControl(strCtrlName, Label.class)).setLabel(strProxyUserName.toString());
						}

					} else {
						if (null != setLocatorSelections && setLocatorSelections.first() == true) {
							String strUserName = (String) setLocatorSelections.getObject(IdocsConstants.USER_NAME);
							if (proxy.indexOf(strUserName) != -1) {
								Object params[] = new Object[1];
		           			 	params[0] = strUserName;
		           			 	WebComponentErrorService.getService().setNonFatalError(form, "MSG_PROXY_AVAILABLE", params, null);
								DfLogger.debug(this, ":: onEditApprover: primaryApprover is found in proxy. SO deleting primary approver: " + primaryApprover, null, null);
							} else {
								// get label control name
								String strCtrlName = getCallingControl();
								((Label) getControl(strCtrlName, Label.class)).setLabel(strUserName);
							}
							

						}
					}
				}
			}
		});
   }


	private String getSelectedObjectIds(String strProxyUsers) {
		IDfCollection usersObjectdIdscoll = null;
		StringBuffer strUsersObjectIds = new StringBuffer(IDocsConstants.MSG_EMPTY_STRING);
		try {
			String qrySafeUsersNames = IdocsUtil.makeQuerySafe(strProxyUsers, null);
			DfLogger.debug(this," :: getSelectedObjectIds: qrySafeUsersNames: " + qrySafeUsersNames, null, null);
			String qrySelectedUsersObjectIds = IdocsUtil.getMessage("QRY_FETCH_USERS_OBJECT_IDS");
			qrySelectedUsersObjectIds = qrySelectedUsersObjectIds.replace(QRY_VARIABLE_USERNAME,qrySafeUsersNames);
			usersObjectdIdscoll = IdocsUtil.executeQuery(getDfSession(), qrySelectedUsersObjectIds, IDfQuery.DF_READ_QUERY);

			while (usersObjectdIdscoll.next()) {
				strUsersObjectIds = strUsersObjectIds.append(usersObjectdIdscoll.getString(IDocsConstants.MSG_R_OBJECT_ID)).append(IdocsConstants.MSG_COMMA);
			}
			if (null != strUsersObjectIds && strUsersObjectIds.length() > 0) {
				strUsersObjectIds = strUsersObjectIds.deleteCharAt(strUsersObjectIds.length()-1);
			}

			DfLogger.debug(this," :: getSelectedObjectIds: strUsersObjectIds After removing coma: " + strUsersObjectIds.toString(), null, null);
		} catch (DfException e) {
			DfLogger.error(this, " :: getSelectedObjectIds: " + e.getMessage(), null, null);
		} finally {
			try {
				if(null != usersObjectdIdscoll) {
					usersObjectdIdscoll.close();
				}
			} catch (DfException e) {
				DfLogger.error(this, " :: getSelectedObjectIds : " + e.getMessage(), null, null);
			}
		}
		return strUsersObjectIds.toString();
	}
}
