package gov.mdc.iwa.monitors.utils;

import java.util.ArrayList;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Email {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	/*
	 * Send Email 
	 */
	public static void Send(MonitorConfig config, String emailMessage)
	{    
		ArrayList<String> recipients = config.getRecipients();
		Properties properties = System.getProperties();
		properties.setProperty("mail.smtp.host", config.getSmtp());
		Session session = Session.getDefaultInstance(properties);
		try{
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(config.getFrom()));

			for (int i = 0; i < recipients.size(); i++) {
				message.addRecipient(Message.RecipientType.TO,new InternetAddress(recipients.get(i)));
			}
			message.setSubject(config.getSubject());
			message.setText(emailMessage);
			Transport.send(message);
		}catch (MessagingException mex) {
			mex.printStackTrace();
		}
	}

	public static void SendToSupport(String message)
	{ 
		MonitorConfig config = new MonitorConfig();
		ArrayList<String> recipient = new ArrayList<String>();
		recipient.add("rarenas@miamidade.gov");
		config.setRecipients(recipient);
		config.setSmtp("smtp.miamidade.gov");
		config.setFrom("IWA_WS_Monitor@miamidade.gov");
		config.setSubject("IWA Web Service Monitor");
		Send( config , message );	    	
	}

}
