package com.swbc.letters.commercial.migrate.dctmutils;

import org.apache.log4j.Logger;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfTypedObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.fc.impl.util.RegistryPasswordUtils;




public class DctmSessionUtil {

	private final static Logger log = Logger.getLogger(DctmSessionUtil.class);

	public static IDfSessionManager createNewIDfSessionManager(String userName,String pwd,String docbase,String hostName, int portNumber) throws DfException,Exception {

		IDfClientX clientx = null;
		IDfClient client = null;
		IDfLoginInfo loginInfo = null;
		IDfSessionManager sessionManager=null;

		

			clientx = configureConnectionBroker(hostName,portNumber);
			client = clientx.getLocalClient();
			loginInfo = clientx.getLoginInfo();

			sessionManager = client.newSessionManager();
			loginInfo.setUser(userName);
			loginInfo.setPassword(RegistryPasswordUtils.decrypt(pwd));
			sessionManager.setIdentity(docbase,loginInfo);

		
		
		return sessionManager;
		
	}
	
	
	private static IDfClientX configureConnectionBroker(String hostName, int portNumber) throws DfException {

		IDfClientX clientx = new DfClientX();
		IDfClient client;

			client = clientx.getLocalClient();
			IDfTypedObject config = client.getClientConfig();
			config.setString("primary_host", hostName);
			config.setInt("primary_port", portNumber);


		return clientx;
	}
	
	public static void releaseSession(IDfSessionManager sessionManager, IDfSession session) throws DfException {

		
		if (session!=null && session.isConnected()) {

			log.debug("Releasing session for " + session.getLoginUserName());

			sessionManager.release(session);

		}

	}

}