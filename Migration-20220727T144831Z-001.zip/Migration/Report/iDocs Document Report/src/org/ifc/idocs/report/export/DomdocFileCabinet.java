package org.ifc.idocs.report.export;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import lotus.domino.Database;
import lotus.domino.DbDirectory;
import lotus.domino.Document;
import lotus.domino.NotesException;

import org.ifc.idocs.report.common.NotesSession;
import org.ifc.idocs.report.model.DomdocRepository;

/**
 * @author SPankajamsadanan
 *
 */
public class DomdocFileCabinet {

	private Database db;
	private DomdocRepository domdoc;
	private String name;
	private List<DomdocStorageDb> storageDbs;
		
	/**
	 * @param domdoc
	 * @param replicaId
	 */
	public DomdocFileCabinet(DomdocRepository domdoc, String replicaId){
		try{
			this.domdoc = domdoc;
			DbDirectory dbdir = NotesSession.getInstance().getDbDirectory(null);
			this.db = dbdir.openDatabaseByReplicaID(replicaId);
			this.name = this.db.getTitle();
		}catch(NotesException e){
			e.printStackTrace();
		}
	}
	
	/**
	 * @return DomdocStorageDb List
	 */
	public List<DomdocStorageDb> getStorageDbs(){
		try{
			if (this.storageDbs == null) {
				this.storageDbs = _getStorageDbs();
			}
		}catch(NotesException e){
			e.printStackTrace();
		}
		return this.storageDbs;
	}
	
	/**
	 * @return DomdocStorageDb List
	 * @throws NotesException
	 */
	@SuppressWarnings("unchecked")
	private List<DomdocStorageDb> _getStorageDbs() throws NotesException {
		Document fcProfile = this.db.getView("(InternalAdmin)").getDocumentByKey("GlobalProfile", true);
		Vector<String> storageDbIds = fcProfile.getItemValue("ListOfDocReplicas");
		List<DomdocStorageDb> list = new ArrayList<DomdocStorageDb>(1);
		int dbCount = storageDbIds.size();
		for (int i=0; i < dbCount; i++) {
			list.add(new DomdocStorageDb(domdoc, storageDbIds.elementAt(i)));
		}
		return list;
	}
	
	/**
	 * @throws NotesException
	 */
	public void recycle() throws NotesException {
		if (this.storageDbs != null) {
			Iterator<DomdocStorageDb> it = storageDbs.iterator();
			while (it.hasNext()) {
				DomdocStorageDb sdb = it.next();
				sdb.recycle();
			}
			while (it.hasNext()) {
				DomdocStorageDb sdb = it.next();
				storageDbs.remove(sdb);
			}
		}
		this.db.recycle();
	}
	
	/**
	 * @return
	 */
	public String getName() {
		return this.name;
	}

}
