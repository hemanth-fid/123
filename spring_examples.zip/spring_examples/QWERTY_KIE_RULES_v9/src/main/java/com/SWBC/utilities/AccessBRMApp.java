package com.SWBC.utilities;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class AccessBRMApp
{
  public static void main(String[] args)
  {
    try
    {
      URL url = new URL("http://p-appdamxms1-v:8383/BRM/api?"
      		+ "userName=dmadmin"
      		+ "&tranType=ALL"
      		+ "&enableLookup=false"
      		+ "&ruleSet=100"
      		+ "&singleAPITrec=false"
      		+ "&tid=HBBP1NJ4"
      		+ "&t_loan_no=00000000000000000000000000000829555"
      		+ "&source=api"
      		+ "&l_suffix=00"
      		+ "&t_cov_type=F"
      		+ "&t_acc_no=4540");
      URLConnection conn = url.openConnection();
      
      BufferedReader br = new BufferedReader(
        new InputStreamReader(conn.getInputStream()));
      
      System.out.println("Done");
    }
    catch (MalformedURLException e)
    {
      e.printStackTrace();
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
  }
}
