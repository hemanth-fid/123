/***************************************************************************
 * State Farm
 * Version Template: 2012
 *
 * File Name: InvokeExportController.java
 *
 * Version     ChgDate          Author           Comments
 * ________   __________       ________         ___________
 * 1.0        06/01/2013        t7p9          Initial Creation 
 *
 ***************************************************************************/

package sf.application.custcomm.ccs.main;
import static java.util.concurrent.TimeUnit.SECONDS;

import java.util.Map;
import java.util.concurrent.ScheduledExecutorService;

import sf.application.custcomm.ccs.constants.CleanUpConstants;
import sf.application.custcomm.ccs.core.PurgeDataCleanupService;
import sf.application.custcomm.ccs.exceptions.CleanUpServiceException;
import sf.application.custcomm.ccs.util.CleanUpHelper;
import sf.application.custcomm.ccs.util.FileOperationUtils;

import com.documentum.fc.common.DfLogger;

/**
 * <i> Invoke WorkFlowTimer Services </i> class provides the functionality to acquire and complete the timer activities  for the scheduled time.
 * 
 */

public final class InvokePurgeDataCleanupServices {

	/**
	 * private Constructor
	 */

	private InvokePurgeDataCleanupServices() {

	}

	/**
	 * It's a main method to invoke the  WorkFlowTimer Services.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		if(DfLogger.isTraceEnabled(InvokePurgeDataCleanupServices.class)) {
			DfLogger.trace(InvokePurgeDataCleanupServices.class, "Workflow Timer Services main() entry", null, null);
		}

		try {
			
			// cleanup existing log files
			
			performTask();
		} catch(CleanUpServiceException cleanUpServiceException) {
			
			DfLogger.error(InvokePurgeDataCleanupServices.class, cleanUpServiceException.getMessage(), null,
					cleanUpServiceException);
		}

		if(DfLogger.isTraceEnabled(InvokePurgeDataCleanupServices.class)) {
			DfLogger.trace(InvokePurgeDataCleanupServices.class, "Workflow Timer Services main() exit", null, null);
		}
	}

	/**
	 * It executes the functionality of  WorkFlow Timer Services by initiating the
	 * scheduler.
	 * 
	 * @throws CleanUpServiceException
	 *             Custom Workflow Service Exception
	 * 
	 */
	private static void performTask() throws CleanUpServiceException {

		if(DfLogger.isTraceEnabled(InvokePurgeDataCleanupServices.class)) {
			DfLogger.trace(InvokePurgeDataCleanupServices.class, "performTask() entry", null, null);
		}
		
		Map<String, String> params = CleanUpHelper.initializeParameters();
		FileOperationUtils.createFolderstructure(params);
		FileOperationUtils.moveFilesInProcessToReadyToProcess(params);
		startPurgeDataCleanupServices(params);
		if(DfLogger.isTraceEnabled(InvokePurgeDataCleanupServices.class)) {
			DfLogger.trace(InvokePurgeDataCleanupServices.class, "performTask() exit", null, null);
		}
	}

	/**
	 * It create's the scheduler object and invokes workflow timer services
	 * 
	 * @param params
	 */
	private static void startPurgeDataCleanupServices(Map<String, String> params) {

		if(DfLogger.isTraceEnabled(InvokePurgeDataCleanupServices.class)) {
			DfLogger.trace(InvokePurgeDataCleanupServices.class, "startPurgeDataCleanupServices() entry", null, null);
		}
		
		ScheduledExecutorService purgeDataCleanupServiceScheduler = CleanUpHelper.getScheduler(CleanUpConstants.NUMBER_ONE);
		
		purgeDataCleanupServiceScheduler.schedule(new PurgeDataCleanupService(params, purgeDataCleanupServiceScheduler),
				CleanUpConstants.NUMBER_ONE, SECONDS);
		
		
		
		if(DfLogger.isTraceEnabled(InvokePurgeDataCleanupServices.class)) {
			DfLogger.trace(InvokePurgeDataCleanupServices.class, "startPurgeDataCleanupServices() exit", null, null);
		}
	}

}
