
package org.ifc.idocs.forms.adaptors;

import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.xforms.engine.adaptor.validator.IStringValidator;
import com.documentum.xforms.engine.adaptor.validator.ItemValidator;

public class StringLengthValidator extends ItemValidator implements IStringValidator  {


	public boolean validateString(String stringField) throws AdaptorException {

		boolean returnFlag = true;
		if(stringField != null && stringField.length()>32 )
			returnFlag = false;
		return returnFlag;
	}

	public void destroy() throws AdaptorException {


	}

	public void init(IAdaptorConfiguration adaptor) throws AdaptorException {


	}


}