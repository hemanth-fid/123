package org.ifc.idocs.report.model;

import java.lang.String;

/**
 * @author SPankajamsadanan
 *
 */
public class DomdocRepositoryDescriptor {

	private String servername;
	private String username;
	private String userpassword;
	private String foldermanpath;

	/**
	 * Constructor for DomdocRepositoryDescriptor
	 */
	public DomdocRepositoryDescriptor() {
		super();
	}
	
	/**
	 * Constructor for DomdocRepositoryDescriptor
	 * @param username
	 * @param userpassword
	 * @param servername
	 * @param foldermanpath
	 */
	public DomdocRepositoryDescriptor(String username, String userpassword, String servername, String foldermanpath) {
		super();
		this.username = username;
		this.userpassword = userpassword;
		this.servername = servername;
		this.foldermanpath = foldermanpath;
	}

	public String getServername() {
		return servername;
	}
	
	public void setServername(String servername) {
		this.servername = servername;
	}
	
	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getUserpassword() {
		return userpassword;
	}
	
	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}
	
	public String getFoldermanpath() {
		return foldermanpath;
	}
	
	public void setFoldermanpath(String foldermanpath) {
		this.foldermanpath = foldermanpath;
	}
}
