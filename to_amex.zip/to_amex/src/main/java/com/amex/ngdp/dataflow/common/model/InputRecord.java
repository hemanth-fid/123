package com.amex.ngdp.dataflow.common.model;

import java.io.Serializable;

public class InputRecord implements Serializable {

    private String userId;
    private Double amount;

    public InputRecord(String userId, Double amount) {
        this.userId = userId;
        this.amount = amount;
    }

    public String getUser() {
        return userId;
    }

    public Double getAmount() {
        return amount;
    }

}
