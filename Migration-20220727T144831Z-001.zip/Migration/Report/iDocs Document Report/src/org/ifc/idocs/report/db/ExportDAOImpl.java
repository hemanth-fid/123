package org.ifc.idocs.report.db;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import oracle.jdbc.OraclePreparedStatement;

import org.ifc.idocs.report.model.CountryProjectDoc;
import org.ifc.idocs.report.model.DocumentDetailReportModel;
import org.ifc.idocs.report.model.DocumentReportModel;
import org.ifc.idocs.report.model.MigrationSkippedDocuments;
import org.ifc.idocs.report.model.SecurityExceptionReportModel;

public class ExportDAOImpl extends DBFactory{

	/**
	 * getExtractionInfo method read query string from extraction_criteria table, execute the query and return the result set
	 * @param extractionId
	 * @return ResultSet
	 * @throws IOException
	 */
	public static ResultSet getExtractionInfo(final String extractionId){
		try {
			getConnection();
			String query = idocsProperties.getProperty("Get_Extraction_Info");
			query = query + "'" + extractionId + "'";
			PreparedStatement stmt = conn.prepareStatement(query);
			rs = stmt.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
			print("SQLException - Please enter a valid extraction criteria present in table", true);
		}
		return rs;
	}

	/**
	 * @param documentReportList
	 * @param documentDetailReportList
	 * @param securityExceptionList
	 * @param migrationSkippedDocumentList
	 * @return void
	 */
	public static void saveReports(
			ArrayList<DocumentReportModel> documentReportList,
			ArrayList<DocumentDetailReportModel> documentDetailReportList,
			ArrayList<SecurityExceptionReportModel> securityExceptionList, 
			ArrayList<MigrationSkippedDocuments> migrationSkippedDocumentList) {

		PreparedStatement stmt = null;
		try {
			getConnection();
			stmt = conn.prepareStatement(idocsProperties.getProperty("Insert_recon_doc_count_report")); 
			((OraclePreparedStatement)stmt).setExecuteBatch (7);
			for(DocumentReportModel dr : documentReportList){
				stmt.setString(1, dr.getFolderTypeCode()); 
				stmt.setString(2, dr.getFolderValueCode()); 
				stmt.setString(3, dr.getReportUtilityCode()); 
				stmt.setInt(4, dr.getSourceDocCnt()); 
				stmt.setDouble(5, dr.getSourceDocSizeNbr()); 
				stmt.setString(6, dr.getRegionName()); 
				stmt.setString(7, dr.getProjectCategoryNameCode()); 
				stmt.executeUpdate(); //JDBC queues this for later execution 
			}
			
			((OraclePreparedStatement)stmt).sendBatch(); // JDBC sends the queued request
			System.out.println("Document Report saved");
			stmt.close();

			stmt = conn.prepareStatement(idocsProperties.getProperty("Insert_recon_sub_fldr_doc_cnt_rep")); 
			((OraclePreparedStatement)stmt).setExecuteBatch (6);
			for(DocumentDetailReportModel ddr : documentDetailReportList){
				stmt.setString(1, ddr.getFolderTypeCode()); 
				stmt.setString(2, ddr.getFolderValueCode()); 
				stmt.setString(3, ddr.getReportUtilityCode()); 
				stmt.setString(4, ddr.getLevel1FolderNme()); 
				stmt.setInt(5, ddr.getLevel1SourceDocCnt()); 
				stmt.setDouble(6, ddr.getLevel1SourceDocSizeNbr()); 
				stmt.executeUpdate(); 
			}
			((OraclePreparedStatement)stmt).sendBatch();
			System.out.println("Document Detailed Report saved.");
			stmt.close();

			stmt = conn.prepareStatement(idocsProperties.getProperty("Insert_recon_security_report")); 
			((OraclePreparedStatement)stmt).setExecuteBatch (12);

			for(SecurityExceptionReportModel se : securityExceptionList){
				stmt.setString(1, se.getFolderTypeCode()); 
				stmt.setString(2, se.getFolderValueCode()); 
				stmt.setString(3, se.getReportUtilityCode()); 
				stmt.setString(4, se.getSourceDocId()); 
				stmt.setString(5, se.getSourceDocName()); 
				stmt.setString(6, se.getSourceDocVerNbr()); 
				stmt.setString(7, se.getSourceSecurityClassCode()); 
				stmt.setString(8, se.getSourceDocUniqueId()); 
				stmt.setTimestamp(9, se.getDocLastModDate()); 
				stmt.setString(10, se.getCountryCode()); 
				stmt.setString(11, se.getRegionName()); 
				stmt.setString(12, se.getProjectCategoryNameCode()); 
				stmt.executeUpdate(); 
			}
			((OraclePreparedStatement)stmt).sendBatch();
			System.out.println("Security Exception Report saved");
			stmt.close();

			stmt = conn.prepareStatement(idocsProperties.getProperty("Insert_migration_skipped_documents")); 
			((OraclePreparedStatement)stmt).setExecuteBatch (11);			
			
			for(MigrationSkippedDocuments msd : migrationSkippedDocumentList){
				stmt.setString(1, msd.getUtilityCode()); 
				stmt.setString(2, msd.getDocumentId()); 
				stmt.setString(3, msd.getDocumentUniqueId()); 
				stmt.setString(4, msd.getVersion()); 
				stmt.setString(5, msd.getTitle()); 
				stmt.setString(6, msd.getFolderTypeCode()); 
				stmt.setString(7, msd.getFileCabinet()); 
				stmt.setString(8, msd.getDatabase()); 
				stmt.setString(9, msd.getSkipReason()); 
				stmt.setString(10, msd.getFolderValueCode()); 
				stmt.setString(11, msd.getErrorCode()); 
				stmt.executeUpdate(); 
			}
			((OraclePreparedStatement)stmt).sendBatch();
			System.out.println("Migration Skipped Documents saved");
			stmt.close();
			
			conn.commit();
			stmt.close();

		} catch (SQLException e) {
			e.printStackTrace();
			print("SQLException occurred while saving in Report tables", true);
		}		
	}

	/**
	 * @param utilityId
	 * @param extractionQuery
	 * @return void
	 */
	public static void saveReportUtilityId(String utilityId, String extractionQuery) {
		try {
			getConnection();
			PreparedStatement stmt = conn.prepareStatement(idocsProperties.getProperty("Insert_report_utility_map"));
			stmt.setString(1, utilityId); 
			stmt.setString(2, extractionQuery); 
			stmt.executeQuery();
			stmt.close();
			System.out.println("Report Utility Map Table Updated");
		} catch (SQLException e) {
			print("SQLException occurred while saving Report Utility Id", true);
		}
	}

	/**
	 * @param extractionId
	 * @return void
	 * @throws IOException
	 */
	public static ResultSet getReplicaDate(final String replicaCode){
		try {
			getConnection();
			String query_part1 = idocsProperties.getProperty("Query_replica_date1");
			String complete_query = query_part1 + replicaCode + "'";
			PreparedStatement stmt = conn.prepareStatement(complete_query);
			rs = stmt.executeQuery();
		} catch (SQLException e) {
			print("Error in getting Replica Date", true);
		}
		return rs;
	}

	/**
	 * databaseTableCheck - read database names from property file, checks whether they exists or not. 
	 * If not, throw error message
	 * @return void
	 */
	public static void databaseTableCheck() {
		String tableName = "";
		try {
			PreparedStatement stmt = null;
			getConnection();
			String countQuery = idocsProperties.getProperty("record_count");
			String tables = idocsProperties.getProperty("table_names");
			String[] tableNames = tables.split(",");
			for(String table : tableNames){
				tableName = table;
				System.out.println("Checking " + table + " table...");
				stmt = conn.prepareStatement(countQuery + tableName);
				stmt.executeQuery();
			}
			stmt.close();
		} catch (Exception e) {
			print(tableName + " Table does not exists.", true);
		}
	}

	public static String utilityIdIsExists(String extractionId) {
		String utilityId = null;
		try {
			getConnection();
			String query_part1 = idocsProperties.getProperty("Get_report_utility_id_from_map");
			String complete_query = query_part1 + extractionId + "'";
			PreparedStatement stmt = conn.prepareStatement(complete_query);
			rs = stmt.executeQuery();
			if(rs.next()){
				utilityId = rs.getString("REPORT_UTILITY_ID");
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			print("Error in getting Replica Date", true);
		}
		return utilityId;
	}

	public static ArrayList<CountryProjectDoc> getDocList(String extractionId, String tableName) {
		CountryProjectDoc doc = null;
		ArrayList<CountryProjectDoc> docList = new ArrayList<CountryProjectDoc>();
		try {
			getConnection();
			String query_part1 = idocsProperties.getProperty("getDocFromTable1");
			String query_part2 = idocsProperties.getProperty("getDocFromTable2");
			String query_part3 = idocsProperties.getProperty("getDocFromTable3");
			String completeQuery = query_part1 + tableName + " " + query_part2 + extractionId + query_part3;
//			System.out.println(completeQuery);
			PreparedStatement stmt = conn.prepareStatement(completeQuery);
			rs = stmt.executeQuery();
			while(rs.next()){
				doc = new CountryProjectDoc();
				doc.setSourceDocId(rs.getString("DOCUMENT_ID"));
				doc.setCountryCode(rs.getString("COUNTRY_CODE"));
				doc.setFolderValueCode(rs.getString("FOLDER_VALUE_CODE"));				
				docList.add(doc);
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			print("Error in getting Document from table", true);
		}
		return docList;
	}


}
