package org.ifc.idocs.control.dragdrop;

import org.ifc.idocs.utils.IdocsConstants;

import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.dragdrop.IDragDropDataProvider;
import com.documentum.web.form.Form;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.control.dragdrop.DragDropClipboard;
import com.documentum.web.formext.docbase.FolderUtil;
import com.documentum.webcomponent.common.WebComponentErrorService;

public class LinkToFolderTargetAction extends com.documentum.web.formext.control.dragdrop.LinkToFolderTargetAction
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	NlsResourceBundle m_nlsResourceBundle = new NlsResourceBundle("org.ifc.idocs.clipboard.ClipboardErrorsNlsProp");

	/**
	 * Method overwritten to change the link operation.
	 */
	public boolean execute(Form form, String position,
			IDragDropDataProvider sourceDataProvider[],
			IDragDropDataProvider targetDataProvider, String sourceItemData[],
			String targetItemData) {
		boolean bExecute = false;
        if(!(form instanceof Component)){
            throw new IllegalArgumentException("LinkToFolderTargetAction.execute() expects a Component as the first argument");
        }
    	IDfSession sess = ((Component) form).getDfSession();
        try {
			DfLogger.info(this, " :: execute : "+sess.getLoginUserName(), null, null);
		} catch (DfException e) {
    		DfLogger.error(this, " :: execute Exception >> "+e.getMessage(), null, e);
		}
       	Component component = (Component)form;
        com.documentum.web.dragdrop.IDragDropData targetData = getTargetDataFromProvider(targetDataProvider, targetItemData);
        String strTargetObjId = getObjectIdFromData(targetData);

        //Validation 1 : if target folder is subfolder level 2
        //Validation 2 : if target folder is of same category
        //Validation 3 : Document is not in workflow
        boolean validation1=false,validation2=false,validation3=false;
        String targetCategory="", sourceCategory="", workflowStatus="", targetName="";
        IDfFolder targetIdFolder = null;
        IDfFolder sourceIdFolder = null;
        IDfSysObject doc = null;

        //validation 1
        if(strTargetObjId!=null){
        	try{
        		IDfSysObject obj = (IDfSysObject)sess.getObject(new DfId(strTargetObjId));
        		String objType = obj.getTypeName();
        		targetName=obj.getObjectName();
        		DfLogger.info(this, " :: execute : targetObjectType : "+objType+" targetName : "+targetName, null, null);
        		if(objType.equals(IdocsConstants.SUB_FOLDER_TYPE)){
            		IDfFolder subFolder1 = (IDfFolder)sess.getObject(obj.getFolderId(0));
            		if(subFolder1.getTypeName().equals(IdocsConstants.SUB_FOLDER_TYPE)){
            			validation1=true;
            			targetIdFolder = (IDfFolder)sess.getObject(subFolder1.getFolderId(0));
            			targetCategory = targetIdFolder.getString("folder_category");
                		DfLogger.info(this, " :: execute : target Subfolder Level2 with : "+targetIdFolder.getObjectName()+" of category : "+targetCategory, null, null);
            		}else{
            			validation1=false;
                		DfLogger.info(this, " :: execute : Subfolder Level1 ", null, null);
            		}
        		}else if(FolderUtil.isCabinetType(strTargetObjId) || FolderUtil.isFolderType(strTargetObjId)){
        			validation1=false;
            		DfLogger.info(this, " :: execute : targetObjectType : "+objType, null, null);
        		}
        	}catch(DfException e){
        		DfLogger.error(this, " :: execute Exception >> "+e.getMessage(), null, e);
        	}
        }

        if(validation1){
	        for(int i = 0; i < sourceItemData.length && sourceItemData.length == sourceDataProvider.length; i++){
	        	validation2=false;
	        	validation3=false;
	        	bExecute = false;
	            com.documentum.web.dragdrop.IDragDropData sourceData = getSourceDataFromProvider(sourceDataProvider[i], sourceItemData[i]);
	            String strSrcObjId = getObjectIdFromData(sourceData);
	            String objectName = "";
	            DfLogger.info(this, " :: execute : strSrcObjId : "+strSrcObjId, null, null);

	            try{
    				if(strSrcObjId != null){
			            //validation 2
		        		doc = (IDfDocument)sess.getObject(new DfId(strSrcObjId));
		        		objectName = doc.getObjectName(); 
		        		String objType = doc.getTypeName();
		        		if(objType.equals(IdocsConstants.PROJ_DOC_TYPE) 
		        				|| objType.equals(IdocsConstants.INSTITUTION_DOC_TYPE) 
		        				|| objType.equals(IdocsConstants.COUNTRY_DOC_TYPE)){
		            		IDfFolder subFolder2 = (IDfFolder)sess.getObject(doc.getFolderId(0));
		            		IDfFolder subFolder1 = (IDfFolder)sess.getObject(subFolder2.getFolderId(0));
		           			sourceIdFolder = (IDfFolder)sess.getObject(subFolder1.getFolderId(0));
		            		sourceCategory = sourceIdFolder.getString("folder_category");
		            		DfLogger.info(this, " :: execute : source Subfolder Level2 with : "+sourceIdFolder.getObjectName()+" of category : "+sourceCategory, null, null);
		            		if(targetCategory.equals(sourceCategory) 
		            				&& !(FolderUtil.isCabinetType(strSrcObjId) 
		            						|| FolderUtil.isFolderType(strSrcObjId))){
		            			validation2=true;
								workflowStatus = doc.getString("workflow_status");
								if(workflowStatus==null || workflowStatus.equals("") || workflowStatus.equals("Completed")){
									validation3 = true;
									bExecute = true;
				                	DfLogger.info(this, " :: execute : workflowStatus : "+workflowStatus, null, null);
								}else{
									validation3 = false;
								}
		            		}else{
		            			validation2=false;
		                		DfLogger.info(this, " :: execute : FolderCategory does not match", null, null);
		            		}
		        		}
    				}else{
		    			bExecute = false;
						WebComponentErrorService.getService().setNonFatalError(m_nlsResourceBundle, "MSG_CLIPBOARD_LINK_FAIL", component, new Object[] {
								objectName
						}, null);
						DfLogger.info(this, " :: execute : User not allowed to copy/move/link/unlink this document", null, null);
		            }
				}catch (DfException e){
            		DfLogger.error(this, " :: execute Exception >> "+e.getMessage(), null, e);
				}

	            if(validation2 && validation3){
    	            com.documentum.web.formext.clipboard.IClipboardPasteHandler handler = component.getClipboardPasteHandler(strTargetObjId);
		            if(handler != null && bExecute){
		                DragDropClipboard dragDropClipboard = new DragDropClipboard();
		                dragDropClipboard.pasteAsLink(strSrcObjId, handler);
		            }else if(!bExecute){
		                WebComponentErrorService.getService().setNonFatalError(m_nlsResourceBundle, "MSG_CLIPBOARD_LINK_FAIL", component, new Object[] {
		                		objectName
		                }, null);
		                DfLogger.info(this, " :: execute : User not allowed to copy/move/link/unlink this document", null, null);
		            }else{
		                throw new IllegalArgumentException("Component must implement IClipboardPasteHandler!");
		            }
	        	}else{
	            	if(!validation3){
					    WebComponentErrorService.getService().setNonFatalError(m_nlsResourceBundle, "MSG_CLIPBOARD_LINK_FAIL_WF", component, new Object[] {
					    		objectName
					    }, null);
	            	}else{
					    WebComponentErrorService.getService().setNonFatalError(m_nlsResourceBundle, "MSG_CLIPBOARD_LINK_FAIL", component, new Object[] {
					    		objectName
					    }, null);
	            	}
				    DfLogger.info(this, " :: execute MSG_CLIPBOARD_LINK_FAIL : User not allowed to copy/move/link/unlink this document", null, null);
	            }
	        }
        }else{
			bExecute = false;
			WebComponentErrorService.getService().setNonFatalError(m_nlsResourceBundle, "MSG_CLIPBOARD_LINK_FAIL_TARGET", component, new Object[] {
					targetName
			}, null);
			DfLogger.info(this, " :: execute MSG_CLIPBOARD_LINK_FAIL_TARGET : User not allowed to copy/move/link/unlink this document", null, null);
        }
        return true;
    }
}
