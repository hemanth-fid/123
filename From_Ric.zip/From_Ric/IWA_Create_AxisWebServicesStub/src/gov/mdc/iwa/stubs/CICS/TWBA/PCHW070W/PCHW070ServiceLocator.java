/**
 * PCHW070ServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W;

public class PCHW070ServiceLocator extends org.apache.axis.client.Service implements gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070Service {

    public PCHW070ServiceLocator() {
    }


    public PCHW070ServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public PCHW070ServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for PCHW070ServicePort
    private java.lang.String PCHW070ServicePort_address = "http://ibmtst.metro-dade.com:4002/CICS/TWBA/CSIWKI2X/PCHW070W";

    public java.lang.String getPCHW070ServicePortAddress() {
        return PCHW070ServicePort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String PCHW070ServicePortWSDDServiceName = "PCHW070ServicePort";

    public java.lang.String getPCHW070ServicePortWSDDServiceName() {
        return PCHW070ServicePortWSDDServiceName;
    }

    public void setPCHW070ServicePortWSDDServiceName(java.lang.String name) {
        PCHW070ServicePortWSDDServiceName = name;
    }

    public gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070ServicePort_Type getPCHW070ServicePort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(PCHW070ServicePort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getPCHW070ServicePort(endpoint);
    }

    public gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070ServicePort_Type getPCHW070ServicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070ServiceBindingStub _stub = new gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070ServiceBindingStub(portAddress, this);
            _stub.setPortName(getPCHW070ServicePortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setPCHW070ServicePortEndpointAddress(java.lang.String address) {
        PCHW070ServicePort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070ServicePort_Type.class.isAssignableFrom(serviceEndpointInterface)) {
                gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070ServiceBindingStub _stub = new gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070ServiceBindingStub(new java.net.URL(PCHW070ServicePort_address), this);
                _stub.setPortName(getPCHW070ServicePortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("PCHW070ServicePort".equals(inputPortName)) {
            return getPCHW070ServicePort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "PCHW070Service");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "PCHW070ServicePort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("PCHW070ServicePort".equals(portName)) {
            setPCHW070ServicePortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
