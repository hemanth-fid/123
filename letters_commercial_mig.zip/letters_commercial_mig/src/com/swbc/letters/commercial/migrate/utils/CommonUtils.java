/**
 * 
 */
package com.swbc.letters.commercial.migrate.utils;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.filefilter.FileFilterUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.swbc.letters.commercial.migrate.constants.MigrateCommercialConstants;
import com.swbc.letters.commercial.migrate.dbutils.DataBaseConnUtils;

/**
 * @author hemanth.muppalanara
 *
 */
public class CommonUtils {

	
	private static Logger log = Logger.getLogger(CommonUtils.class);
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		if(isDirectoryExists("C:\\temp")){
			
			try {
				getfilesFromDirectory("C:\\temp",null);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

	
	public static void  updatMetaAddlColumns(Connection dbConn) throws SQLException,Exception{
		
		
		
		String selectQry="select source_file_path from [dbo].[commercial_letters_file_share_metadata] where source_account_no='0223'";
		
		ResultSet rs=DataBaseConnUtils.executeSelectQryInDB(dbConn, selectQry);
		
		while(rs.next()){


			String source_file_path=rs.getString("source_file_path");
			String[] splitStr=StringUtils.split(FilenameUtils.getBaseName(source_file_path), "_");

			StringBuffer fileName=new StringBuffer("");
			String fileExtractStatus="true";

			for (int i = 1; i < splitStr.length; i++) {

				if(splitStr[i].length()>6 && splitStr[i].length()<35){

					fileName.append(StringUtils.substring(splitStr[i], 0,6)).append("_");
					fileName.append(StringUtils.substring(splitStr[i], 7,StringUtils.length(splitStr[i]))).append("_");
					fileExtractStatus="false";

				}else{

					if(i==splitStr.length-1)
						fileName.append(splitStr[i]);
					else
						fileName.append(splitStr[i]).append("_");
				}

			}
			
			String[] fileNameStrArry=fileName.toString().split("_");
			
			if(fileNameStrArry!=null && fileNameStrArry.length>1){
				
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
				 String modfDate=sdf.format(FileUtils.getFile(source_file_path).lastModified());
				
				String updateQry=MessageFormat.format(MigrateCommercialConstants.QRY_UPDATE_ALL_META_TABLE,
					fileNameStrArry[2],fileNameStrArry[3],fileNameStrArry[5],StringUtils.substringBefore(fileNameStrArry[6],"~"),
					FilenameUtils.getBaseName(source_file_path),
					fileExtractStatus,StringUtils.substringAfter(fileNameStrArry[6],"~"),modfDate,fileNameStrArry[4],source_file_path);
				log.debug(updateQry);
				DataBaseConnUtils.executeUpdateQryInDB(dbConn, updateQry,false);
			}
			

		}
		
		if(rs!=null){
			
			rs.close();
		}
		
	}
	
	public static Map<String,List<String>>  getfilesFromDirectory(String srcFileDirPath,Connection dbConn) throws Exception{

		List<File> fileList=null;
		Map<String,List<String>> filePathMap = new  HashMap<String,List<String>>();
		
		
		File fileDir = new File(srcFileDirPath);

		System.out.println("Getting all files in " + fileDir.getCanonicalPath() + " including those in subdirectories");
		fileList = (List<File>) FileUtils.listFiles(fileDir, FileFilterUtils.suffixFileFilter("pdf"), TrueFileFilter.INSTANCE);
		
		
		for (File file : fileList) {

			List<String> filePathList=null;
			String[] splitStr=StringUtils.split(FilenameUtils.getBaseName(file.getCanonicalPath()), "_");
			
			
			
			
			if(filePathMap.containsKey(splitStr[1].concat("_").concat(splitStr[2]).concat("_").concat(splitStr[5])) && splitStr!=null){

				filePathList=filePathMap.get(splitStr[1].concat("_").concat(splitStr[2]).concat("_").concat(splitStr[5]));
				filePathList.add(file.getCanonicalPath());

			}else{

				filePathList=new ArrayList<String>();
				filePathList.add(file.getCanonicalPath());
				filePathMap.put(splitStr[1].concat("_").concat(splitStr[2]).concat("_").concat(splitStr[5]),filePathList);

			}

			//log.debug("file: " + file.getCanonicalPath());
		}
		
		populateMetaDataTable(filePathMap,dbConn);
		printMap(filePathMap,dbConn);
		
		
		return filePathMap;
	}
	
	
	public static Map<String,List<String>>  getfilesFromTable(String srcFileDirPath,Connection dbConn) throws Exception{

		
		Map<String,List<String>> filePathMap = new  HashMap<String,List<String>>();
		
		
		String selectQry="select source_account_no,source_loan_no,source_cov_type,source_file_path from [dbo].[commercial_letters_file_share_metadata]";
		
		ResultSet rs=DataBaseConnUtils.executeSelectQryInDB(dbConn, selectQry);
		
		while(rs.next()){
			
			String source_account_no="";
			String source_loan_no="";
			String source_cov_type="";
			String source_file_path="";
			
			List<String> filePathList=null;
		//	String[] splitStr=StringUtils.split(FilenameUtils.getBaseName(file.getCanonicalPath()), "_");
			if(filePathMap.containsKey(source_account_no.concat("_").concat(source_loan_no).concat("_").concat(source_cov_type))){

				filePathList=filePathMap.get(source_account_no.concat("_").concat(source_loan_no).concat("_").concat(source_cov_type));
				filePathList.add(source_file_path);

			}else{

				filePathList=new ArrayList<String>();
				filePathList.add(source_file_path);
				filePathMap.put(source_account_no.concat("_").concat(source_loan_no).concat("_").concat(source_cov_type),filePathList);

			}
			
		}
		
		
		if(rs!=null){
			
			rs.close();
		}
		
		return filePathMap;
	}
	
	
	public static <K, V> void printMap(Map<K,List<V>> map,Connection dbConn) throws IOException {

		for (Map.Entry<K,List<V>> entry : map.entrySet()) {

			
			log.debug("key : "+entry.getKey()+"\t"+entry.getValue()+"\n");
			

		}

	}
	
	
	
	public static void populateMetaDataTable(Map<String,List<String>> filePathMap,Connection dbConn) throws IOException, SQLException {
		
		
		for (Entry<String, List<String>> entry : filePathMap.entrySet()) {
			
			String[] splitStr=StringUtils.split(entry.getKey().toString(), "_");
			
			List<String> filePathList=entry.getValue();
			
			for (Iterator iterator = filePathList.iterator(); iterator.hasNext();) {
				
				
				String insertQry=MigrateCommercialConstants.QRY_INSERT_ALL_FILEPATH_TABLE;
				insertQry=MessageFormat.format(insertQry, splitStr[0].trim(),splitStr[1].trim(),splitStr[2].trim(),iterator.next().toString().trim());
				//log.debug(insertQry);
				DataBaseConnUtils.executeInsertQryInDB(dbConn, insertQry, false);
				
				
			}
			
			
			
		}
		
		
	}
	
	
/*	public static <K, V> void printMap(Map<K,List<V>> map) throws IOException {


		String filename = "C:\\Temp\\Letters_Commercial_Docs".concat("_Report_").concat(Long.toString(System.currentTimeMillis())).concat(".xls");

		File file = new File("");
		if (!file.exists()) {
			file.createNewFile();
		}

		BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(filename,true));

		bufferedWriter.write("AccntNo_LoanNo_CovType" +"\t"+"Matching_Files"+"\n");	  

		for (Map.Entry<K,List<V>> entry : map.entrySet()) {

			bufferedWriter.write(entry.getKey()+"\t"+entry.getValue()+"\n");

		}

		if (bufferedWriter != null) {
			bufferedWriter.flush();
			bufferedWriter.close();
		}
		
	}*/
	
	public static boolean isDirectoryExists(String directoryPath){

		boolean isExists=false;
		File srcFolder = null;

		if(StringUtils.isNotEmpty(directoryPath)){
			srcFolder = new File(directoryPath);

			if(srcFolder!=null){

				if(srcFolder.isDirectory()){
					isExists=true;
				}

			}
		}
		return isExists;
		
	}
	
	
	public static String buildFileName(String filesParentDir,String account_no,String loan_no,String cov_type){
		
		
		StringBuffer fileNamebuf=new StringBuffer();
		
		if(StringUtils.isNotBlank(loan_no) && StringUtils.length(loan_no)<35){

			loan_no=StringUtils.leftPad(loan_no, 35, "0");
		}
		
		fileNamebuf.append(account_no).append("_").append(loan_no).append("_").append(cov_type);
		
		return fileNamebuf.toString();
		
	}
	
	public static String trimStringtoLength(String message,int length) {

		if (message != null && message.length() > length) {
			message = message.substring(0, length);
			
		}
		return message;
	}
	
	public static String escapeSpecialChars(String strMsg) {

		strMsg=strMsg.replaceAll("'","''");
		return strMsg;
	}
	

	
}
