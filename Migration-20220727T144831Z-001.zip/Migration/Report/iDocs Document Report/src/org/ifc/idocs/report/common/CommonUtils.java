package org.ifc.idocs.report.common;

import java.io.InputStream;
import java.util.Properties;

public class CommonUtils {

	static AppConfig config = AppConfig.getInstance();
	
	public static void checkForConfigFile(Properties idocsProperties, InputStream inputStream, String inputType, boolean isExit){
		if(inputStream != null){
			try{
				idocsProperties.load(inputStream);
			}catch(Exception e){
				System.out.println("Exception occured " + e);
				System.exit(0);
			}
		}else{
			print("Cannot locate " + inputType + " Properties file. Please check the file name or the file location", isExit);
		}
	}
	
	public static void checkConfigAttributes(String attribute, String message, boolean isExit) {
		String element = config.getString(attribute);
		if(element == null || element.length() == 0){
			print("Please specify " + message + " in config.xml file", true);
		}
	}

	private static void print(String message, boolean isExit){
		System.out.println(message);
		if(isExit){
			System.exit(0);
		}		
	}
	
}
