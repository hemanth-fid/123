package com.swbc.letters.commercial.migrate.constants;


public interface MigrateCommercialConstants {

	public static final String DCTM_HOST_NAME="config.dctm.host.name";
	public static final String DCTM_PORT_NUMBER="config.dctm.port.number";

	public static final String DCTM_REPO_NAME="config.dctm.repository.name";
	public static final String DCTM_USER_NAME="config.dctm.admin.user.name";
	public static final String DCTM_PASSWORD="config.dctm.admin.password";
	
	
	public static final String DB_DRIVER_NAME="config.jdbc.driverClassName";
	public static final String DB_URL="config.db.url";
	public static final String DB_USER_NAME="config.db.username";
	public static final String DB_PASSWORD="config.db.password";
	
	
	
	//public static final String QRY_SELECT_ALL_MIG_TABLE="SELECT Old_Comm_Acct,IH_LOAN_NO,IH_COVERAGE_TYPE FROM  dbo.Commercial_Loan_Data  where [Old_Comm_Acct]='223' and IH_LOAN_NO='14730004008963'";
	public static final String QRY_SELECT_ALL_MIG_TABLE="SELECT Old_Comm_Acct,Comm_Ln,Comm_Cov_Type FROM  dbo.Commercial_Loan_Data";
	public static final String QRY_UPDATE_ALL_MIG_TABLE="update dbo.Commercial_Loan_Data set file_path=''{0}'',is_file_status=''{1}'' where [Old_Comm_Acct]=''{2}'' and IH_LOAN_NO=''{3}''";
	public static final String QRY_INSERT_ALL_FILEPATH_TABLE="INSERT INTO dbo.commercial_letters_file_share_metadata (source_account_no,source_loan_no,source_cov_type,source_file_path) values(''{0}'',''{1}'',''{2}'',''{3}'')";
	
	//DEV- Migrate queries
		public static final String QRY_SELECT_ALL_MIG_MASTER_TABLE="SELECT  * FROM [DM_swbc_bpm_docbase].[dbo].[commercial_migration_master_dev] where is_migrated='false' OR is_migrated='' and  source_account_no='0311'";
		public static final String QRY_UPDATE_IS_MIG_MASTER_TABLE_FAIL="UPDATE [DM_swbc_bpm_docbase].[dbo].[commercial_migration_master_dev] set is_migrated=''{0}'',error_message=''{1}'' where id=''{2}''";
		public static final String QRY_UPDATE_IS_MIG_MASTER_TABLE_SUCCESS="UPDATE [DM_swbc_bpm_docbase].[dbo].[commercial_migration_master_dev] set transaction_id=''{0}'',is_migrated=''{1}'' where id=''{2}''";
		
		public static final String QRY_SELECT_IS_COMMENT_MASTER_TABLE="SELECT  * FROM [DM_swbc_bpm_docbase].[dbo].[commercial_migration_master_dev] where is_migrated='true' and (is_commented='false' OR is_commented='')";
		public static final String QRY_UPDATE_IS_COMMENT_MASTER_TABLE_FAIL="UPDATE [DM_swbc_bpm_docbase].[dbo].[commercial_migration_master_dev] set is_commented=''{0}'',error_message=''{1}'' where transaction_id=''{2}''";
		public static final String QRY_UPDATE_IS_COMMENT_MASTER_TABLE_SUCCESS="UPDATE [DM_swbc_bpm_docbase].[dbo].[commercial_migration_master_dev] set is_commented=''{0}'',posting_json_message=''{1}'' where transaction_id=''{2}''";
		
	
	
	//PROD- Migrate queries
		//public static final String QRY_SELECT_ALL_MIG_MASTER_TABLE="SELECT  * FROM [DM_swbc_bpm_docbase].[dbo].[commercial_migration_master] where is_migrated='false' OR is_migrated=''";
		//public static final String QRY_UPDATE_IS_MIG_MASTER_TABLE_FAIL="UPDATE [DM_swbc_bpm_docbase].[dbo].[commercial_migration_master] set is_migrated=''{0}'',error_message=''{1}'' where id=''{2}''";
		//public static final String QRY_UPDATE_IS_MIG_MASTER_TABLE_SUCCESS="UPDATE [DM_swbc_bpm_docbase].[dbo].[commercial_migration_master] set transaction_id=''{0}'',is_migrated=''{1}'' where id=''{2}''";
		//public static final String QRY_UPDATE_IS_COMMENT_MASTER_TABLE="SELECT  * FROM [DM_swbc_bpm_docbase].[dbo].[commercial_migration_master]  where is_migrated='true'  and is_commented='false'";
	
		
		//public static final String QRY_SELECT_IS_COMMENT_MASTER_TABLE="SELECT  * FROM [DM_swbc_bpm_docbase].[dbo].[commercial_migration_master] where is_migrated='true' and (is_commented='false' OR is_commented='')";
		//public static final String QRY_UPDATE_IS_COMMENT_MASTER_TABLE_FAIL="UPDATE [DM_swbc_bpm_docbase].[dbo].[commercial_migration_master] set is_commented=''{0}'',error_message=''{1}'' where transaction_id=''{2}''";
		//public static final String QRY_UPDATE_IS_COMMENT_MASTER_TABLE_SUCCESS="UPDATE [DM_swbc_bpm_docbase].[dbo].[commercial_migration_master] set is_commented=''{0}'',posting_json_message=''{1}'' where transaction_id=''{2}''";
		
	public static final String QRY_UPDATE_ALL_META_TABLE="update dbo.commercial_letters_file_share_metadata set property_no=''{0}'',building_no=''{1}'',seq_no=''{2}'',letter_code=''{3}'',file_nme=''{4}'',file_status=''{5}'',letter_code_ext=''{6}'',file_modified_date=''{7}'',source_cov_type=''{8}'' where [source_file_path]=''{9}''";
	
	public static final String SUCCESS="Success";
	public static final String FAILURE="Failure";
	
	public static final String TRUE="true";
	public static final String FALSE="false";
	
	public static final String SRV_BUS_COMMAND_TYPE="config.serv.bus.mtg.command.type";
	public static final String SRV_BUS_EXCHANGE_NAME="config.serv.bus.mtg.exchange.name";
	public static final String SRV_BUS_USER_ID="config.serv.bus.mtg.user.id";
	public static final String SRV_BUS_PASSWORD="config.serv.bus.mtg.password";
	public static final String SRV_BUS_HOST_NAME="config.serv.bus.mtg.host.name";
	public static final String SRV_BUS_HOST_PORT="config.serv.bus.mtg.host.port";
	public static final String SRV_BUS_VIRTUAL_HOST="config.serv.bus.mtg.virtual.host";
	public static final String SRV_BUS_CONTENT_TYPE="config.serv.bus.mtg.content.type";
	
	public static final String FILES_DIRECTORY="config.migrate.commercial.letters.file.directory";
	
	public static final String NEWLINE = System.getProperty("line.separator");
	public static final String FILESEPARATOR = System.getProperty("file.separator");
	public static final String EMPTYSTRING = "";
	

}
