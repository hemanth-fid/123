package gov.mdc.iwa.monitors.utils;

public class Result {
	
	
	private String message ="";
	private boolean status  = true;
	private boolean connectionOk = true;
	
	public void setMessage(String message){
		this.message = message;
	}
	
	public void setStatus(boolean status){
		this.status = status;
	}
	
	public void setConnectionOk(boolean connectionOk){
		this.connectionOk = connectionOk;
	}

	public String getMessage(){
		return this.message;
	}
	
	public boolean getStatus(){
		return this.status;
	}

	public boolean getConnectionOk(){
		return this.connectionOk;
	}	
}
