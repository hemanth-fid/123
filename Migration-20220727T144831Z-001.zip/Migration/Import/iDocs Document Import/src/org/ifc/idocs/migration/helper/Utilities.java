package org.ifc.idocs.migration.helper;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.logging.Level;

import org.ifc.idocs.migration.importUtility.ImportDocument;
import org.ifc.idocs.migration.importUtility.ImportUtility;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.DfAttributeValueException;
import com.documentum.fc.client.DfDuplicateAspectException;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.aspect.IDfAspects;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfTime;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfList;
import com.documentum.fc.common.IDfTime;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * Utilities - All common functions that are used across the classes. 
 * @author HAnuganti
 * 
 * #############################################################################################
 * Author		            DateofChange	 Version	  ModificationHistory
 * ###########################################################################################
 * Hemachandra Anuganti 
 * ###########################################################################################
 * 
 */
public class Utilities extends ImportUtility{
	/**
	 * executeQuery() - Executes the query passed as an argument.
	 * 
	 * @param dfSession
	 * @param strQuery
	 * @param queryType
	 * @return
	 * @throws DfException
	 */
	public static IDfCollection executeQuery(IDfSession dfSession, String strQuery, int queryType) throws DfException{
		IDfCollection dfCollection = null;
		IDfQuery dfQuery = new DfQuery();
		dfQuery.setDQL(strQuery);
		dfCollection = dfQuery.execute(dfSession,queryType);
		return dfCollection;
	} // end of executeQuery()

	public static void addToArrayList(String updateQry) {
		// TODO Auto-generated method stub

		if(dbqryList.size() >=200){
			importDocLogger.warning("Updating Migration Region Databases........!!!!!");
			UpdateDB.executeBatch(dbqryList,UpdateDB.getBatchConnection());
			importDocLogger.warning("Migration Region Databases Updated Successfully.........!!!!!");
			dbqryList.clear();
		}
		dbqryList.add(updateQry);
	}
	
	public static void addToWFArrayList(String updateQry) {
		// TODO Auto-generated method stub

		if(dbqryWFList.size() >=200){
			UpdateDB.executeBatch(dbqryWFList,UpdateDB.getBatchConnection());
			dbqryWFList.clear();
		}
		dbqryWFList.add(updateQry);
	}
	
	
	public static void addToFldLevelHM(){
		//Populate Folder Level2 hashmap
		StringTokenizer fldTokens = new StringTokenizer(idocsProperties.getProperty("MSG_FETCH_ALL_MAP_KEYS"), ",");
		while(fldTokens.hasMoreTokens()){
			String tokenNme = fldTokens.nextToken();
			String hmKey = idocsProperties.getProperty(tokenNme);
			String hmValue = idocsProperties.getProperty(tokenNme+"_MAP");
			levelFldHM.put(hmKey, hmValue);
		}
	}
	
	public static void addToDocTitlesHM() {
		// TODO Auto-generated method stub
		//Populate Folder Level2 hashmap
		StringTokenizer docTitleTokens = new StringTokenizer(idocsProperties.getProperty("MSG_OBJ_TITLE_MAP_KEYS"), ",");
		while(docTitleTokens.hasMoreTokens()){
			String tokenNme = docTitleTokens.nextToken();
			String docTitleKey = idocsProperties.getProperty(tokenNme);
			String docTitleValue = idocsProperties.getProperty(tokenNme+"_MAP");
			docTitleMapHM.put(docTitleKey, docTitleValue);
		}
	}
	
	public static boolean setDocRepeatingAttributes(IDfSysObject sysObj,
			String attrName, String keyValue) {
		// TODO Auto-generated method stub
		String repValue = "";
		StringTokenizer stRepeatingTokens = new StringTokenizer(keyValue,",");
		try {
			int tokensCNT = 0;
			while(stRepeatingTokens.hasMoreTokens()){
				repValue = stRepeatingTokens.nextToken();
					if(repValue.length()>=48){
						repValue = repValue.substring(0, 47);
					}
					sysObj.setRepeatingString(attrName, tokensCNT++, repValue);
				
			}

				return true;
			}catch (DfException e) {
			// TODO Auto-generated catch block
			
			//Make Entry in Migration Skipped documents table as folder is not found
			importDocLogger.warning("Exception during settring repeating attribute value");
			importDocLogger.log(Level.WARNING,"Stting repeating attributes::attrName::"+attrName, e);
			
			String skippedReason = "Unable to update the attributes [Key="+attrName+" and Value ="+repValue+"] for the document::"+sourceFilePath+" with the metadata xml::"+xmlPath;
			skippedReason = skippedReason.replaceAll("'", "''");
			skippedReason = skippedReason+"')";
			
			Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_43"),skippedReason);
			
			e.printStackTrace();
			return false;
		}
	}

	public static boolean setDocRepeatingAuthors(IDfSysObject sysObj, String key,
			String value) {
		// TODO Auto-generated method stub
		String repValue ="";
		StringTokenizer stRepeatingTokens = new StringTokenizer(value,"#");
		try {
			int tokenIndex=0;
			while(stRepeatingTokens.hasMoreTokens()){
				repValue = stRepeatingTokens.nextToken();
				
				if(repValue.length()>Integer.parseInt(idocsProperties.getProperty("MSG_AUTHORS_LENGTH"))){
					importDocLogger.warning("Attribute is too big for the Authors attribute");
				}else{
					sysObj.setRepeatingString(key, tokenIndex++, repValue);
				}
			}
				//Set Authors to defalut authors attribute also
//				setDefaultAuthors(sysObj,value);
				
				return true;
			}catch (DfAttributeValueException ave) {
				ImportDocument.raiseUnableToUpdateAttributesException(key,repValue);
				ave.printStackTrace();
				return false;
			}catch (DfException e) {
				// TODO Auto-generated catch block
				ImportDocument.raiseUnableToUpdateAttributesException(key,repValue);
				e.printStackTrace();
				return false;
			}
	}
	
	private static void setDefaultAuthors(IDfSysObject sysObj, String value) {
		// TODO Auto-generated method stub
		String repAuthValue ="";
		StringTokenizer stRepeatingAuthors = new StringTokenizer(value,"#");
		int tokenAuthIndex=0;
		
		while(stRepeatingAuthors.hasMoreTokens()){
			repAuthValue = stRepeatingAuthors.nextToken();
			try{
				if(repAuthValue.length() <= 48){
					sysObj.setRepeatingString(idocsProperties.getProperty("MSG_DEFAULT_AUTHORS_KEY"), tokenAuthIndex++, repAuthValue);
				}else{
					repAuthValue = repAuthValue.substring(0, 48);
					sysObj.setRepeatingString(idocsProperties.getProperty("MSG_DEFAULT_AUTHORS_KEY"), tokenAuthIndex++, repAuthValue);
				}
			}catch (ArrayIndexOutOfBoundsException e) {
				// TODO: handle exception
				importDocLogger.warning("ArrayIndexOutOfBoundsException while processing Authors attribute::"+repAuthValue);
				importDocLogger.log(Level.WARNING,"Issue while processing the Authors attribute::"+repAuthValue, e);
				e.printStackTrace();
			} catch (DfException e) {
				// TODO Auto-generated catch block
				importDocLogger.warning("ArrayIndexOutOfBoundsException while processing Authors attribute::"+repAuthValue);
				importDocLogger.log(Level.WARNING,"Issue while processing the Authors attribute::"+repAuthValue, e);
				e.printStackTrace();
			}
		}
	}

	public static boolean attachDocAspects(IDfSession dfSession, IDfId dfId, HashMap hmAspects) {
		try {
			
			IDfDocument dfDocument = (IDfDocument) dfSession.getObject(dfId); 
			IDfList dfList = ((IDfAspects)dfDocument).getAspects();
			int dfListCount = dfList.getCount();
			boolean emailAspectAttached = false;
			boolean scanningAspectAttached = false;
			
			for (int i=0;i<dfListCount;i++){			
				if (dfList.get(i).equals(IDocsEmailConstants.EMAIL_ASPECT_NME)){
					emailAspectAttached = true;
				}else if (dfList.get(i).equals(IDocsEmailConstants.SCANNING_ASPECT_NME)){
					scanningAspectAttached = true;
				} else{
					importDocLogger.warning("");
				}		
				
			} // end of for loop
			
			// Attaching email document Aspect
			if (!emailAspectAttached){
				((IDfAspects)dfDocument).attachAspect(IDocsEmailConstants.EMAIL_ASPECT_NME, null);
				//Set Aspect Single valued Attributes
				dfDocument.setString(IDocsEmailConstants.EMAIL_ASPECT_DOC_TYPE_ATTR, (String) hmAspects.get(IDocsEmailConstants.DOC_TYPE_ATTR));
				dfDocument.setString(IDocsEmailConstants.EMAIL_ASPECT_MSG_ID_ATTR, (String) hmAspects.get(IDocsEmailConstants.MSG_ID_ATTR));
				dfDocument.setString(IDocsEmailConstants.EMAIL_ASPECT_SENT_FROM_ATTR, (String) hmAspects.get(IDocsEmailConstants.SENT_FROM_ATTR));
				
				if(hmAspects.get(IDocsEmailConstants.RECD_DT_ATTR).toString().contains(".") || hmAspects.get(IDocsEmailConstants.RECD_DT_ATTR).toString().contains("-")){
					raiseAspetException(dfId);
					return false;
				}else{
					dfDocument.setString(IDocsEmailConstants.EMAIL_ASPECT_RECD_DT_ATTR, convertToEasternTime((String)hmAspects.get(IDocsEmailConstants.RECD_DT_ATTR)));
				}
				
				String strEmailTo = (String) hmAspects.get(IDocsEmailConstants.SENT_FROM_ATTR);
				if (strEmailTo == null || "".equals(strEmailTo)){
	
				}else{
					strEmailTo = strEmailTo.replaceAll(";", ",");
					String[] emailSendToList = strEmailTo.split(",");
					int sendToCount = emailSendToList.length;
					for (int i=0;i<sendToCount;i++){
						dfDocument.setRepeatingString(IDocsEmailConstants.EMAIL_ASPECT_SENT_TO_ATTR, i,emailSendToList[i]);				
					}
				}
				
				//Set Aspect Repeating Attributes to "idocs_email_cc_list"
				String strEmailCC = (String) hmAspects.get(IDocsEmailConstants.CC_TO_ATTR);
				if (strEmailCC == null || "".equals(strEmailCC)){

				}else{
					strEmailCC = strEmailCC.replaceAll(";", ",");
					String[] emailSendCCList = strEmailCC.split(",");
					int sendCCCount = emailSendCCList.length;
					for (int i=0;i<sendCCCount;i++){
						dfDocument.setRepeatingString(IDocsEmailConstants.EMAIL_ASPECT_CC_TO_ATTR, i,emailSendCCList[i]);				
					}
				}
				
				//Saving the Aspect
				dfDocument.setString(idocsProperties.getProperty("MSG_DOC_IS_MIGRATED"), "T");
				dfDocument.save();
				
				importDocLogger.warning("Aspect Created Successfully::["+dfDocument.getObjectId()+"]");
			}else{
				importDocLogger.warning("Aspect already existing for the Document");
			}
			return true;
		}catch (DfDuplicateAspectException e) {
			// TODO: handle exception
			raiseDuplicateAspetException(dfId);
			importDocLogger.log(Level.WARNING,"Creating the aspect for the ID::dfId::"+dfId, e);
			e.printStackTrace();
			return false;
		}catch (DfException dfe) {
			// TODO Auto-generated catch block
			raiseAspetException(dfId);
			importDocLogger.log(Level.WARNING,"Creating the aspect for the ID::dfId::"+dfId, dfe);
			dfe.printStackTrace();
			return false;
		}
	}

	private static void raiseAspetException(IDfId dfId) {
		// TODO Auto-generated method stub
		String skippedReason = "Issue During attaching Aspect to the Document["+dfId+"]";
		skippedReason = skippedReason.replaceAll("'", "''");
		skippedReason = skippedReason+"')";
		Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_41"),skippedReason);
	}

	private static void raiseDuplicateAspetException(IDfId dfId) {
		// TODO Auto-generated method stub
		String skippedReason = "Duplicate aspect found for the document["+dfId+"]";
		skippedReason = skippedReason.replaceAll("'", "''");
		skippedReason = skippedReason+"')";
		Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_40"),skippedReason);
	}

	public static void addToSkippedReason(String impUniqId,
			String skipped_fldType_code, String skipped_fldValue_code,
			String legacyDocId, String errorCode, String skippedReason) {
		// TODO Auto-generated method stub
		
		String skippedDocQry = idocsProperties.getProperty("MIG_SKIPPED_DOCS_QUERY")
								.replaceAll("<UTILITY_CODE>", impUniqId)
									.replaceAll("<FOLDER_TYPE_CODE>", skipped_fldType_code)
										.replaceAll("<FOLDER_VALUE_CODE>", skipped_fldValue_code)
											.replaceAll("<DOCUMENT_ID>", legacyDocId)
												.replaceAll("<ERROR_CODE>", errorCode);
		
		skippedDocQry = skippedDocQry+skippedReason;
		
		//Adding Query to the queue
		addToArrayList(skippedDocQry.toString());
	}

	public static HashMap mapTemplateTitles() {
		// TODO Auto-generated method stub
		try {
			IDfCollection templateColl = executeQuery(dfSession, idocsProperties.getProperty("MSG_GET_TEMPLATE_DETAILS"), DfQuery.EXECREAD_QUERY);
			while(templateColl.next()){
				if(templateMappingHM.containsKey(templateColl.getString("template_title"))){
					
				}else{
					templateMappingHM.put(templateColl.getString("template_title"), templateColl.getString("template_code"));
				}
			}templateColl.close();
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException while updating template titles to the hashmap");
			e.printStackTrace();
		}
		return templateMappingHM;
	}
	
	public static String convertToEasternTime(String dateTime) {
		// TODO Auto-generated method stub
			try{
			if(dateTime !="" && dateTime !=null){
				dateTime = dateTime.trim();
				
					dateTime = dateTime.replaceAll("\\\\", "/");
					String[] nDate = dateTime.split(":");
					if(nDate.length ==2){
						if(nDate[1].contains(" ")){
							String timeStr = nDate[1].replaceAll(" ", ":00 ");
							dateTime = nDate[0]+":"+timeStr+" EST";
	//						System.out.println("333::dateTime:::"+dateTime);
	//						return convertDateToCSDate(nDate[0]+":"+timeStr);
							return dateTime;
						}else{
	//						System.out.println("22::Invalid date::"+dateTime);
							return dateTime;
						}
					}else{
						if(dateTime.contains("EDT")){
	//						dateTime = dateTime.replace("EDT","").trim();
	//						return convertDateToCSDate(dateTime);
							return dateTime;
	//						System.out.println("EDT Time::"+dateTime);
						}else if(dateTime.contains("EST")){
	//						dateTime = dateTime.replace("EDT","").trim();
	//						return convertDateToCSDate(dateTime);
							return dateTime;
	//						System.out.println("EST Time::"+dateTime);
						}else {
							if(dateTime.contains(" ")){
								if (dateTime.contains("AM") || dateTime.contains("PM")){
									//check for time zone
									//if time zone doesnt exists then add EST and send it
										//if time zone found
										//get the time zone
										//convert to EST and send it
									//else add EST time zone at the end and send it
									
									if(dateTime.contains("AM") && (dateTime.substring(0, dateTime.indexOf("AM")+2).length()!=dateTime.length())){
										String timez = dateTime.substring(dateTime.indexOf("AM")+3, dateTime.length());
	//									System.out.println("AM timez::"+timez);
										//if time zone found
										//get the time zone
										//convert to EST and send it
										convertDateToESTDate(dateTime,timez);
									}else if(dateTime.contains("PM") && (dateTime.substring(0, dateTime.indexOf("PM")+2).length()!=dateTime.length())){
										String timez = dateTime.substring(dateTime.indexOf("PM")+3, dateTime.length());
	//									System.out.println("PM timez::"+timez);
										//if time zone found
										//get the time zone
										//convert to EST and send it
										convertDateToESTDate(dateTime,timez);
									}else{
	//									System.out.println("Date Does not contain time zone::"+dateTime);
										if(dateTime.contains("AM")){
	//										System.out.println("Time contains AM::"+dateTime);
	//										System.out.println("Added EST to the time::"+dateTime+" EST");
											return dateTime+" EST";
										}else if(dateTime.contains("PM")){
	//										System.out.println("Time contains PM::"+dateTime);
	//										System.out.println("Added EST to the time::"+dateTime+" EST");
											return dateTime+" EST";
										}
									}
								}else{
									importDocLogger.warning("Date doesnt contain AM and PM and it is an invalid date::"+dateTime);
								}
	//							System.out.println(dateTime);
							}else{
								//Treat this date as EST and save as is
								dateTime = dateTime+" 12:00:00 PM EST";
//								importDocLogger.warning("Date Does not contain any time/zone so formatted to EST::"+dateTime);
								return dateTime;
	//							return convertDateToCSDate(dateTime);
							}
						}
					}
				
			}else{
				dateTime = "nulldate";
				importDocLogger.warning("dateTime::"+dateTime);
			}
		}catch(Exception e){
			importDocLogger.warning("dateTime::"+dateTime);
		}
		return dateTime;
	}
	
	private static String convertDateToESTDate(String newdateTime,String timez) {
		// TODO Auto-generated method stub

/*//		Date csDate = new Date(dateTime);
		String destFolrmatter = "MM/dd/yyyy hh:mm:ss a z";
		
		DateFormat formatter = new SimpleDateFormat(destFolrmatter);
		Date date;
		try {
			date = formatter.parse(newdateTime);
			newdateTime = formatter.format(date);
			formatter.setTimeZone(TimeZone.getTimeZone("EST"));
			newdateTime = formatter.format(date);
			System.out.println("Converted new Dte::"+newdateTime);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return newdateTime;*/
		
		newdateTime = convertTimezone(newdateTime);
		Date date = new Date(newdateTime);
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a z"); 
		String dStr = df.format(date); 
		String str = dStr.substring(0, dStr.length()-2);
		str = str + ":";
		dStr = str + dStr.substring(dStr.length()-2, dStr.length());
		
		System.out.println("Converted Time Zone:::::++++::"+dStr);
		
		String destFolrmatter = "MM/dd/yyyy hh:mm:ss a z";
		
		DateFormat formatter = new SimpleDateFormat(destFolrmatter);
		Date date1;
		try {
			date1 = formatter.parse(dStr);
			dStr = formatter.format(date1);
			formatter.setTimeZone(TimeZone.getTimeZone("EST"));
			dStr = formatter.format(date1);
//			System.out.println("Converted new Dte::"+newdateTime);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("Parse Exception During Date Processing dateTime::"+newdateTime);
		}
		return dStr; 
	}
	
	private static String convertTimezone(String timeStamp) {
		String zone = timeStamp.substring(22, timeStamp.length());
		if (zone.equals(" AST")) { zone = " -0400"; }
		else if (zone.equals(" BST")) { zone = " -1100"; }
		else if (zone.equals(" CDT")) { zone = " -0600"; }
		else if (zone.equals(" CEDT")){ zone = " +0100"; }
		else if (zone.equals(" CET")) { zone = " +0100"; }
		else if (zone.equals(" CST")) { zone = " -0600"; }
		else if (zone.equals(" EDT")) { zone = " -0500"; }
		else if (zone.equals(" EST")) { zone = " -0500"; }
		else if (zone.equals(" GDT")) { zone = " -0000"; }
		else if (zone.equals(" ")) { zone = " -0000"; }
		else if (zone.equals(" HST")) { zone = " -1000"; }
		else if (zone.equals(" MDT")) { zone = " -0700"; }
		else if (zone.equals(" MST")) { zone = " -0700"; }
		else if (zone.equals(" NDT")) { zone = " -0330"; }
		else if (zone.equals(" NST")) { zone = " -0330"; }
		else if (zone.equals(" PDT")) { zone = " -0800"; }
		else if (zone.equals(" PST")) { zone = " -0800"; }
		else if (zone.equals(" YDT")) { zone = " -0900"; }
		else if (zone.equals(" YST")) { zone = " -0900"; }
		else if (zone.equals(" YW1")) { zone = " -0100"; }
		else if (zone.equals(" YW2")) { zone = " -0200"; }
		else if (zone.equals(" Z-13")) { zone = " +1300"; }
		else if (zone.equals(" ZE10")) { zone = " +1000"; }
		else if (zone.equals(" ZE11")) { zone = " +1100"; }
		else if (zone.equals(" ZE12")) { zone = " +1200"; }
		else if (zone.equals(" ZE2")) { zone = " +0200"; }
		else if (zone.equals(" ZE3")) { zone = " +0300"; }
		else if (zone.equals(" ZE3B")) { zone = " +0330"; }
		else if (zone.equals(" ZE4")) { zone = " +0400"; }
		else if (zone.equals(" ZE4B")) { zone = " +0430"; }
		else if (zone.equals(" ZE5")) { zone = " +0500"; }
		else if (zone.equals(" ZE5B")) { zone = " +0530"; }
		else if (zone.equals(" ZE5C")) { zone = " +0545"; }
		else if (zone.equals(" ZE6")) { zone = " +0600"; }
		else if (zone.equals(" ZE6B")) { zone = " +0630"; }
		else if (zone.equals(" ZE7")) { zone = " +0700"; }
		else if (zone.equals(" ZE8")) { zone = " +0800"; }
		else if (zone.equals(" ZE9")) { zone = " +0900"; }
		else if (zone.equals(" ZE9B")) { zone = " +0930"; }
		else if (zone.equals(" ZW1")) { zone = " -0100"; }
		else if (zone.equals(" ZW12")) { zone = " -1200"; }
		else if (zone.equals(" ZW2")) { zone = " -0200"; }
		else if (zone.equals(" ZW3")) { zone = " -0300"; } 
		else { zone = " -0000"; }
		timeStamp = (String) timeStamp.subSequence(0, 22);
		timeStamp += zone;
		return timeStamp;
	}


	private static String convertDateToCSDate(
			String metadataDate) {
		// TODO Auto-generated method stub
		Date csDate = new Date(metadataDate);
		DateFormat utcFormat = new SimpleDateFormat();
		TimeZone utcTime = TimeZone.getTimeZone("UTC");
		utcFormat.setTimeZone(utcTime);
		String newDate = utcFormat.format(csDate);
		
		String[] nDate = newDate.split(":");
		if(nDate.length ==2){
			if(nDate[1].contains(" ")){
				String nd = nDate[1].replaceAll(" ", ":00 ");
				newDate = nDate[0]+":"+nd;
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
				newDate = sdf.format(new Date(newDate));
			}
		}
		return newDate;
	}
}