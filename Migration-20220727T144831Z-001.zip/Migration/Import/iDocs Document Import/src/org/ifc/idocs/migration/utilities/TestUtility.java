package org.ifc.idocs.migration.utilities;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;

public class TestUtility {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int versionCount = 9;
		String[] versionList = new String[versionCount];
		
		versionList[0] = "0.1";
		versionList[1] = "0.14";
		versionList[2] = "0.15";
		versionList[3] = "0.10";
		
		versionList[4] = "0.19";
		versionList[5] = "1.0";
		versionList[6] = "2.0";
		versionList[7] = "0.2";
		versionList[8] = "0.20";
		for (int i=0;i<versionCount;i++){
			System.out.println("versionList["+i+"] : "+versionList[i]);
		}
		
		ArrayList listSortedVersion  =sortVersion(versionList);
		for (int j=0;j<versionCount;j++){
			System.out.println("listSortedVersion["+j+"] : "+listSortedVersion.get(j));
		}
		
	}

	private static ArrayList sortVersion(String strVersion[]){
		String strDocVer = "";

		ArrayList finalSortList = new ArrayList();
		HashMap mapMajorMinor = new HashMap();
		String strMajorVer ="";
		List listMinor = new ArrayList();

		if(strVersion.length>0 && strVersion != null){
			Arrays.sort(strVersion);
			String tmpMajorValue= (strVersion[0].split("\\."))[0];
			System.out.println("tmpMajorValue : "+tmpMajorValue);
			for(int index=0; index < strVersion.length ; index++)    
			{
				strDocVer= strVersion[index];
				String[] splitVersion = strDocVer.split("\\.");
				strMajorVer = splitVersion[0];
				String strMinorVer = splitVersion[1];
				if(strMajorVer.equals(tmpMajorValue)){
					listMinor.add(Integer.valueOf(strMinorVer));
				}else {
					Collections.sort(listMinor);
					mapMajorMinor.put(tmpMajorValue, listMinor);
					tmpMajorValue= strMajorVer;
					listMinor = new ArrayList();
					listMinor.add(Integer.valueOf(strMinorVer));
				}
			}
			Collections.sort(listMinor);
			mapMajorMinor.put(tmpMajorValue, listMinor);
			Set setver = mapMajorMinor.keySet();
			Iterator t = setver.iterator();
			while(t.hasNext()){
				String key = (String)t.next();
				ArrayList listMinorVer = (ArrayList)mapMajorMinor.get(key);
				Collections.sort(listMinorVer);
				Iterator t1 = listMinorVer.iterator();

				while(t1.hasNext()){
					String strSort = key+"."+t1.next();
					finalSortList.add(strSort);
				}
			}
		}else {
			//importDocLogger.log(Level.WARNING,"ParseXML.java sortVersion method .. No version Available ");
			System.out.println("ParseXML.java sortVersion method .. No version Available");
		}
		return finalSortList;
	}
}
