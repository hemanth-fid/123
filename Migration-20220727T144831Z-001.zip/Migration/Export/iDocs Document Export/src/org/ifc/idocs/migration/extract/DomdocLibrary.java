package org.ifc.idocs.migration.extract;

import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import lotus.domino.Database;
import lotus.domino.DateTime;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.View;

import org.ifc.idocs.migration.common.DomdocRepository;

/**
 * @author SPankajamsadanan
 *
 */
public class DomdocLibrary {
	
	private Database db;
	private DomdocRepository domdoc;
	private String btReplicaId;

	private Map<String, DomdocFileCabinet> fileCabinetsByName;
	private Map<String, DomdocFileCabinet> fileCabinetsById;

	/**
	 * DomdocLibrary constructor
	 * @param domdoc
	 * @throws NotesException
	 */
	public DomdocLibrary(DomdocRepository domdoc) throws NotesException {
		this.domdoc = domdoc;
		this.fileCabinetsByName = new HashMap<String, DomdocFileCabinet>(500);
		this.fileCabinetsById = new HashMap<String, DomdocFileCabinet>(500);
		Document fmProfile = domdoc.getFoldermanDb().db.getView("(InternalAdmin)").getDocumentByKey("DominoDoc", true);
		this.db = NotesSession.getInstance().getDatabase(domdoc.getServerName(), fmProfile.getItemValueString("LibraryNotesURL"));
		fmProfile.recycle();
		if (!db.isOpen()) {
			db.open();
		}
		this.btReplicaId = domdoc.getFoldermanDb().db.getView("InternalAdmin").getDocumentByKey("BusinessTemplates").getItemValueString("binderdbid");
	}

	/**
	 * @throws NotesException
	 */
	public void recycle() throws NotesException {
		this.db.recycle();
	}

	/**
	 * getFileCabinetByName method
	 * @param name
	 * @return DomdocFileCabinet
	 * @throws NotesException
	 */
	public DomdocFileCabinet getFileCabinetByName(String name) throws NotesException {
		if (!this.fileCabinetsByName.containsKey(name)) {
			loadFileCabinetByName(name);
		}
		return this.fileCabinetsByName.get(name);
	}

	/**
	 * getFileCabinetById method
	 * @param id
	 * @return DomdocFileCabinet
	 * @throws NotesException
	 */
	public DomdocFileCabinet getFileCabinetById(String id) throws NotesException {
		if (!this.fileCabinetsById.containsKey(id)) {
			DomdocFileCabinet fc = new DomdocFileCabinet(this.domdoc, id);
			fileCabinetsById.put(id, fc);
			fileCabinetsByName.put(fc.getName(), fc);
		}
		return fileCabinetsById.get(id);
	}

	/**
	 * loadFileCabinetByName method
	 * @param name
	 * @return void
	 * @throws NotesException
	 */
	private void loadFileCabinetByName(String name) throws NotesException {
		Vector<String> v = new Vector<String>(2);
		v.addElement("1");
		v.addElement(name);
		Document doc = this.db.getView("(CabinetSearchView)").getDocumentByKey(v);
		if (doc != null) {
			String id = doc.getItemValueString("BinderDBReplicaID");
			DomdocFileCabinet fc = new DomdocFileCabinet(domdoc, id);
			fileCabinetsById.put(id, fc);
			fileCabinetsByName.put(name, fc);
			doc.recycle();
		}	
	}

	/**
	 * export method
	 * @param path
	 * @param query
	 * @param cutoff
	 * @return void
	 * @throws Exception
	 */
	public void export(String path, String query, DateTime cutoff) throws Exception {
		View v = this.db.getView("(CabinetSearchView)");
		Document doc = v.getFirstDocument();
		while (doc != null) {
			String id = doc.getItemValueString("BinderDBReplicaID");
			if (!id.equals(btReplicaId)) {
				DomdocFileCabinet fc = getFileCabinetById(id);
				fc.export(new StringBuilder(path).append(db.getTitle()).append("/").toString(), query, cutoff);
				fc.recycle();
			}
			doc = v.getNextDocument(doc);
		}
		v.recycle();
	}
}
