/**
* This class is for displaying product details while create document.
* This component will be invoked when user clicks on 'View Projects/Partners' action menu on a folder .
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.services;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Properties;

import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.form.control.databound.TableResultSet;

/**
 * @author CVattathara
 *
 */
public class ProductAppService {
	
	private static Properties idocsProperties = new Properties();
	
	private static final String WORKFLOW_NBR = "workflow_nbr";	
	private static final String PRODUCT_TYPE_NME = "product_type_nme";
	private static final String PRODUCT_SUB_TYPE_NME = "product_sub_type_nme";		
	private static final String CURRENCY_AMT = "crncy_amt";
	private static final String PRODUCT_NBR = "product_nbr"; //This field name is different for Commitment Transfer Memo
	private static final String CURRENCY_CODE = "currency_code"; //This field name is different for R-MAM 
		
	private static final String RMAM_CRNCY_CODE = "transfer_crncy_code";
	private static final String RMAM_CRNCY_AMT = "transfer_crncy_amt";	
	
	private static final String COMMITMENT_WORKFLOW_NBR = "commitment_workflow_nbr";
	private static final String COMMITMENT_CRNCY_AMT = "commitment_crncy_amt";
	private static final String COMMITMENT_USD_AMT = "commitment_usd_amt";	
	
	private static final String DISBURSEMENT_WORKFLOW_NBR = "disbursement_workflow_nbr";
	private static final String DISBURSEMENT_CRNCY_AMT = "disbursement_crncy_amt";
	private static final String DISBURSEMENT_USD_AMT  = "disbursement_usd_amt";	
	
	private static final String ADJUSTMENT_WORKFLOW_NBR = "adjustment_workflow_nbr";
	private static final String ADJUSTMENT_CRNCY_AMT = "adjustment_crncy_amt";
	private static final String ADJUSTMENT_USD_AMT  = "adjustment_usd_amt";
	
	private static final String TRANSFER_WORKFLOW_NBR = "transfer_workflow_nbr";
	private static final String TRANSFER_PRODUCT_NBR = "parent_product_nbr";
	private static final String TRANSFER_CRNCY_AMT = "transfer_crncy_amt";
	private static final String TRANSFER_USD_AMT  = "transfer_usd_amt";	
	
	private static final String HEADER_COMMITMENT  = "Commitment Details";
	private static final String HEADER_DISBURSEMENT  = "Disbursement Details";
	private static final String HEADER_ADJUSTMENT  = "Adjustment Details";
	private static final String HEADER_TRANSFER  = "Transfer Details";
	private static final String HEADER_RMAM  = "RMAM Details";
	
	
	
	private static String strDatagridLabel=null;
	private static String strValidationMsg = null;
	private static boolean pdtWfFlag=false;
	
	public Datagrid getProductWfDetails(IDfSession dfSession,String strProjectID,int prodcutWfTypeCode,Datagrid datagrid){
		IDfCollection collection = null;		
		TableResultSet resultSet = null;
		boolean pdtWfDataFlag = false;
		try{
			idocsProperties.load(ProductAppService.class.getResourceAsStream(IdocsConstants.IDOCS_PROPERTY_FILE));
			String productWflQry = null;
			String strWorkflowNbr = null;
			String strProductNbr = null;
			String strCurrencyCode = null;
			String strCurrencyAmntColumn = null;
			String strUSDAmntColumn = null;				
			String strMessage = null;
			DfLogger.info(this, " :: getProductWfDetails : prodcutWfTypeCode :"+ prodcutWfTypeCode,null,null);
			if(prodcutWfTypeCode>100 ){
				//For Commitment and subsequent commitments 
				if(prodcutWfTypeCode == 103 || prodcutWfTypeCode == 104){
					productWflQry = idocsProperties.getProperty("QRY_PDS_COMMIT_WFL_DETAILS");
					strWorkflowNbr = COMMITMENT_WORKFLOW_NBR;
					strProductNbr = PRODUCT_NBR;
					strCurrencyCode = CURRENCY_CODE;
					strCurrencyAmntColumn = COMMITMENT_CRNCY_AMT;
					strUSDAmntColumn = COMMITMENT_USD_AMT;
					setDatagridLabel(HEADER_COMMITMENT);
					
					strMessage = idocsProperties.getProperty("MSG_VALIDATION");
					strMessage = strMessage.replaceFirst("''", "a Commitment");
					DfLogger.info(this, " :: getProductWfDetails : strMessage :"+ strMessage,null,null);
					setValidationMsg(strMessage);
				}
				//For Disbursement and Subsequent Disbursement
				else if(prodcutWfTypeCode == 105 || prodcutWfTypeCode == 106){
					productWflQry = idocsProperties.getProperty("QRY_PDS_DISBURSE_WFL_DETAILS");
					strWorkflowNbr = DISBURSEMENT_WORKFLOW_NBR;
					strProductNbr = PRODUCT_NBR;
					strCurrencyCode = CURRENCY_CODE;
					strCurrencyAmntColumn = DISBURSEMENT_CRNCY_AMT;
					strUSDAmntColumn = DISBURSEMENT_USD_AMT;
					setDatagridLabel(HEADER_DISBURSEMENT);
					
					strMessage = idocsProperties.getProperty("MSG_VALIDATION");
					
					if(prodcutWfTypeCode == 105){
						strMessage = strMessage.replaceFirst("''", "a Disbursement");
					}else if(prodcutWfTypeCode == 106){
						strMessage = strMessage.replaceFirst("''", "a Subsequent Disbursement");
					}
					DfLogger.info(this, " :: getProductWfDetails : strMessage :"+ strMessage,null,null);
					setValidationMsg(strMessage);
				}
				//For Droppage and Cancellation
				else if (prodcutWfTypeCode == 107 || prodcutWfTypeCode == 108){
					productWflQry = idocsProperties.getProperty("QRY_DROPPAGE_CANCEL_WFL_DETAILS");
					strWorkflowNbr = ADJUSTMENT_WORKFLOW_NBR;
					strProductNbr = PRODUCT_NBR;
					strCurrencyCode = CURRENCY_CODE;
					strCurrencyAmntColumn = ADJUSTMENT_CRNCY_AMT;
					strUSDAmntColumn = ADJUSTMENT_USD_AMT;
					setDatagridLabel(HEADER_ADJUSTMENT);
					
					strMessage = idocsProperties.getProperty("MSG_VALIDATION");
					strMessage = strMessage.replaceFirst("''", "an Adjustment");
					DfLogger.info(this, " :: getProductWfDetails : strMessage :"+ strMessage,null,null);
					setValidationMsg(strMessage);
				}
				//For Commitment Transfer
				else if(prodcutWfTypeCode == 110){
					productWflQry = idocsProperties.getProperty("QRY_TRANSFER_WF_DETAILS");
					strWorkflowNbr = TRANSFER_WORKFLOW_NBR;
					strProductNbr = TRANSFER_PRODUCT_NBR;
					strCurrencyCode = CURRENCY_CODE;
					strCurrencyAmntColumn = TRANSFER_CRNCY_AMT;
					strUSDAmntColumn = TRANSFER_USD_AMT;
					setDatagridLabel(HEADER_TRANSFER);
					
					strMessage = idocsProperties.getProperty("MSG_VALIDATION");
					strMessage = strMessage.replaceFirst("''", "a Transfer");
					DfLogger.info(this, " :: getProductWfDetails : strMessage :"+ strMessage,null,null);
					setValidationMsg(strMessage);
				}
				//For R-MAM
				else if(prodcutWfTypeCode == 102){
					productWflQry = idocsProperties.getProperty("QRY_R_MAM_WF_DETAILS");
					strWorkflowNbr = WORKFLOW_NBR;
					strProductNbr = PRODUCT_NBR;
					strCurrencyAmntColumn = RMAM_CRNCY_AMT;
					strCurrencyCode = RMAM_CRNCY_CODE;
					setDatagridLabel(HEADER_RMAM);
					strMessage = idocsProperties.getProperty("MSG_VALIDATION");
					strMessage = strMessage.replaceFirst("''", "a Revised MAM");
					DfLogger.info(this, " :: getProductWfDetails : strMessage :"+ strMessage,null,null);
					setValidationMsg(strMessage);
				}
				
				//Populate Datagrid with workflow details
				if(productWflQry != null && productWflQry.trim().length() > 0){
					productWflQry=productWflQry.replaceFirst("''", strProjectID);
					productWflQry = productWflQry.replaceFirst("''", String.valueOf(prodcutWfTypeCode));
					DfLogger.info(this, " :: getProductWfDetails : productWflQry :"+ productWflQry,null,null);
					datagrid.getDataProvider().setDfSession(dfSession);
					// datagrid.getDataProvider().setQuery(productWflQry);
					// datagrid.getDataProvider().initBind();			            
					// setWfNbr(datagrid.getDataProvider().getDataField(strWorkflowNbr));
		            
			        DfQuery dfQuery = new DfQuery();
			        dfQuery.setDQL(productWflQry);
			        collection = dfQuery.execute(dfSession, IDfQuery.DF_READ_QUERY);
			      		
			        resultSet = new TableResultSet(new String[]{
		        			WORKFLOW_NBR,PRODUCT_NBR,PRODUCT_TYPE_NME,
		        			PRODUCT_SUB_TYPE_NME,CURRENCY_CODE,CURRENCY_AMT
		        			}) ;
			       
			       String strCurrencyAmnt = "";
			       String strCurrencyCodeVal = "";
			       DfLogger.info(this, " :: getProductWfDetails : Before While :",null,null);
			       while(collection.next()){
			    	   DfLogger.info(this, " :: getProductWfDetails : Entered While :",null,null);
			    	   pdtWfDataFlag = true;
			    	   setPdtWfFlag(pdtWfDataFlag);
			    	   DfLogger.info(this, " :: getProductWfDetails : In collection..strCurrencyAmntColumn : " +collection.getString(strCurrencyAmntColumn),null,null);
			    	   if(null!=collection.getString(strCurrencyCode)){
			    		   strCurrencyCodeVal = collection.getString(strCurrencyCode);
			    	   }
			        	
			    	   if(collection.getDouble(strCurrencyAmntColumn)!= 0.0){
			        		strCurrencyAmnt = BigDecimal.valueOf(collection.getDouble(strCurrencyAmntColumn)).toPlainString();
			        		DfLogger.info(this, " :: getProductWfDetails : strCurrencyAmnt: "+strCurrencyAmnt,null,null);
			    	   }
			        	
			    	   //if(collection.getDouble(strUSDAmntColumn)!= 0.0)
			    	   //	strUSDAmnt = String.valueOf(collection.getDouble(strUSDAmntColumn));
			    	   if(IdocsUtil.isDocumentPresentForWorkflow(collection.getString(strWorkflowNbr), strProjectID, dfSession) 
			    			   == false){
			    		   resultSet.add(new String[]{
				    			   collection.getString(strWorkflowNbr),
				    			   collection.getString(strProductNbr),
				    			   collection.getString(PRODUCT_TYPE_NME),
				    			   collection.getString(PRODUCT_SUB_TYPE_NME),
				    			   strCurrencyCodeVal,	//collection.getString(strCurrencyCode),
				    			   strCurrencyAmnt				        			
				        			});
				    	   }else{
				    		   DfLogger.info(this, " :: getProductWfDetails : Document Already Present For :"+strWorkflowNbr,null,null);
				    	   }					        	
			    	   DfLogger.info(this, " :: getProductWfDetails :PdtAppService>resultSet>..."+resultSet.getResultsCount(),null,null);				        	
			       	} 
			        
			       	if(null != resultSet && resultSet.getResultsCount()>0){
			        	DfLogger.info(this, " :: getProductWfDetails : resultSet.getResultsCount() :"+ resultSet.getResultsCount(),null,null);
			        	datagrid.getDataProvider().setScrollableResultSet(resultSet);
			        	datagrid.getDataProvider().initBind();
			        	DfLogger.info(this, " :: getProductWfDetails :PdtAppService>>..."+datagrid.getDataProvider().getResultsCount(),null,null);
			        }else{
			        	DfLogger.info(this, " :: getProductWfDetails : result set count is less than 0 :",null,null);
			        	datagrid = null;
			        }
			       	if(collection != null )collection.close();			       
				}
			}	
		}catch(IOException ioe){
			
		}catch(DfException dfe){
			dfe.printStackTrace();
		}				
		return datagrid;
	}
	
	public String getDatagridLabel(){
		return strDatagridLabel;
	}
	
	public void setDatagridLabel(String strDatagridLabel){
		this.strDatagridLabel = strDatagridLabel;			
	}
	
	public String getValidationMsg(){
		return strValidationMsg;
	}
	
	public void setValidationMsg(String strValidationMsg){
		this.strValidationMsg = strValidationMsg;			
	}
	
	public boolean isPdtWfPresent(){
		return pdtWfFlag;
	}
	
	public void setPdtWfFlag(boolean pdtWfFlag){
		this.pdtWfFlag = pdtWfFlag;			
	}	
}
