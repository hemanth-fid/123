/**
 * 
 * This behaviour class displays selective attributes while creation of the
 * document.
 * 
 * ###########################################################################
 * Author		 	  DateofChange	 Version		ModificationHistory
 * ###########################################################################
 * Dinesh Mahalingam		03/12/2011		1.2			created 

 * ###########################################################################
 */
package org.ifc.idocs.attributes;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.queryservices.DocTypeTableStructure;
import org.ifc.idocs.queryservices.IDocsQRYVO;
import org.ifc.idocs.services.ProductAppService;
import org.ifc.idocs.services.TripTemplateService;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.utils.IdocsUtil;
import org.w3c.dom.Document;


import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfACL;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfTime;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfTime;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.Checkbox;
import com.documentum.web.form.control.DateInput;
import com.documentum.web.form.control.Hidden;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.Panel;
import com.documentum.web.form.control.databound.DataDropDownList;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.form.control.databound.ScrollableResultSet;
import com.documentum.web.form.control.databound.TableResultSet;
import com.documentum.web.formext.control.docbase.DocbaseAttributeValue;
import com.documentum.web.formext.docbase.ObjectCacheUtil;
import com.documentum.web.formext.session.DocbaseUtils;
import com.documentum.webcomponent.common.WebComponentErrorService;

/**
 * Displays selective attributes while creation of the document
 * @author Dinesh
 *
 */
public class Attributes extends com.documentum.webcomponent.library.attributes.Attributes
{

	public String aspect_attributes[] = { "Scanning partition",
			"Scanning Inputsender Host", "Scanning Input Sender Ip",
			"Scanning Inputtype", "Email Partition", "Email CC",
			"Email Doc Type", "Email Message Id", "Email Received Date",
			"Email Sent From", "Email Sent To" };
	private static final long serialVersionUID = 1L;
	private String validationError=IDocsConstants.MSG_EMPTY_STRING;
	private static final String PDT_GRID_PANEL = "pdtgridpanel";
	private static final String SELECTED_WF_NBR_HIDDEN = "selectedWfNbr";
	private static final String PDT_WF_NBR="product_wf_nbr";
	private static final String PDT_GRID="productgrid";
	private static final String GRID_HEADER="gridHeader";
	public boolean isFolderTitleDropDownMandatory=true;;
	private String strWfNbr=null;
	String strObjectId = null;
	IDfDocument newDoc = null;
	boolean isProductTemplate = false;
	boolean isProductWfExists = false;
	int pdtWfTypeCode = 0;
	String objectType = null;
	String submissionNbr = null;
	String docInputName=null;
	IdocsUtil idocsUtils = new IdocsUtil();
	//static Properties idocsProperties = new Properties();
	Datagrid datagrid = null;
	String strFolderCategory = IDocsConstants.MSG_EMPTY_STRING;

	private boolean enableDataGrid = false;
	private boolean tripGrid=false;
	Datagrid templatedatagrid=null;
	private static final String TEMPLATE_DATAGRID="tripgrid";
	private static final String TRIP_HEADER="tripHeader";
	private static final String SELECTED_TRIP_NBR_HIDDEN = "selectedTripNo";	
	private static final String TRIP_GRID_PANEL = "tripgridpanel";	
	private static final String TRIP_SUBMISSION_NBR="trip_submission_nbr";
	private static final String NOSUBMISSION_HEADER="nosubmissionnumbermsg";

	//--------- Aspects code variables
	private static final String ASPECT_GRID="aspectsGrid";
	public boolean enableScannedAttributes=false;
	public boolean enableEmailedAttributes=false;
	public boolean ASPECT_EXISTED = false;
	private String strTemplateName = null;

	String isThisCameFromCreate = null;
	int template_code;	

	/**
	 * This method has been overwritten to initialise the controls
	 * @param args - Documentum Context Arguments
	 */

	public void onInit(ArgumentList args){
		try{
			IDfFolder parentFolder=null;
			
			javax.servlet.http.HttpSession httpSession = getPageContext().getSession();
			isThisCameFromCreate = (String)httpSession.getAttribute(IdocsConstants.MSG_IS_LOADED_FROM_CREATE);
			if(isThisCameFromCreate != null && isThisCameFromCreate.trim().length()>0 
					&& isThisCameFromCreate.equalsIgnoreCase(IdocsConstants.MSG_YES)){
				DfLogger.debug(this, ":: is from Create = "+enableDataGrid +":: ENABLE DATAGRID = ", null, null);
				enableDataGrid = true;
			}else{
				DfLogger.debug(this, ":: is from Create = "+enableDataGrid+":: DISABLE DATAGRID = ", null, null);
				enableDataGrid = false;
			}
			
			DfLogger.debug(this, " :: onInit : "+getDfSession().getLoginUserName(), null, null);
			
			super.onInit(args);
			
			strObjectId = args.get("objectId");				
			newDoc = (IDfDocument)ObjectCacheUtil.getObject(getDfSession(),strObjectId);
			objectType=newDoc.getString(IdocsConstants.R_OBJECT_TYPE);
			DfLogger.debug(this, " :: onInit : objectType: "+objectType, null, null);
			getBizTemplateStatus(newDoc.getString(IDocsConstants.MSG_DOC_SUBTYPE_CODE),newDoc.getString(IDocsConstants.MSG_R_OBJECT_TYPE));
			IDfId folderID = newDoc.getFolderId(0);
			String strFolderId =  folderID.toString();
			String strFolderType = IDocsConstants.MSG_EMPTY_STRING;
			DfLogger.debug(this, " :: onInit : strFolderId: "+strFolderId, null, null);
			IDfFolder docFolder = null;
			try{
				
				docFolder =(IDfFolder)ObjectCacheUtil.getObject(getDfSession(), strFolderId);
				strFolderType = docFolder.getTypeName();
				DfLogger.debug(this, " :: onInit : strFolderType: "+strFolderType, null, null);
				if(strFolderType.equals(org.ifc.idocs.utils.IdocsConstants.PROJ_FOLDER_TYPE) 
						|| strFolderType.equals(org.ifc.idocs.utils.IdocsConstants.INSTITUTION_FOLDER_TYPE) 
						|| strFolderType.equals(org.ifc.idocs.utils.IdocsConstants.COUNTRY_FOLDER_TYPE)) {
					parentFolder = docFolder;
				}else if (!strFolderType.equals(org.ifc.idocs.utils.IdocsConstants.IDOCS_FOLDER_TYPE)) {
					docFolder = (IDfFolder)getDfSession().getObject(docFolder.getFolderId(0));
					strFolderType = docFolder.getTypeName();
					if ((strFolderType.equals(org.ifc.idocs.utils.IdocsConstants.PROJ_FOLDER_TYPE)
							|| strFolderType.equals(org.ifc.idocs.utils.IdocsConstants.INSTITUTION_FOLDER_TYPE) 
							|| strFolderType.equals(org.ifc.idocs.utils.IdocsConstants.COUNTRY_FOLDER_TYPE))
							&& (!docFolder.getFolderId(0).getId().equals("0000000000000000"))) {
						parentFolder = docFolder;
					}else {
						if(!docFolder.getFolderId(0).getId().equals("0000000000000000"))
							parentFolder=(IDfFolder)getDfSession().getObject(docFolder.getFolderId(0));
					}
				}
				DfLogger.debug(this, " :: onInit : Parent Folder Id : " + parentFolder.getObjectId(),null,null);
				DfLogger.debug(this, " :: onInit : Object Name : " + parentFolder.getObjectName(),null,null);
				if (!strFolderType.equals(org.ifc.idocs.utils.IdocsConstants.IDOCS_FOLDER_TYPE)) {
					strFolderCategory = parentFolder.getString("folder_category");
				}
			}catch (Exception e) {
				DfLogger.debug(this, " :: onInit : Get strFolderCategory Exception : " + e.getMessage(),null,null);
			}

			DfLogger.debug(this, " :: onInit : strFolderCategory : " + strFolderCategory,null,null);
			if(enableDataGrid == true ){
				if((objectType != null && objectType.trim().length()>0) && objectType.equals(IdocsConstants.PROJ_DOC_TYPE)){
					String strDocName = newDoc.getObjectName();
					strTemplateName  = IdocsUtil.getTemplateTitle(getDfSession(),strObjectId);
					DfLogger.debug(this, " :: onInit : strDocName: "+strDocName, null, null);
					if(strTemplateName==null){
						if(strDocName.indexOf("_")!= -1){
							strTemplateName = strDocName.substring(strDocName.indexOf("_")+1);
							DfLogger.debug(this, " :: onInit : strTemplateName: "+strTemplateName, null, null);
						}
					}
					pdtWfTypeCode = idocsUtils.getProductTypeCode(getDfSession(),strTemplateName);
					template_code= idocsUtils.getTemplateCode(getDfSession(),strTemplateName);
					
					if(pdtWfTypeCode > Integer.parseInt(IdocsUtil.getMessage("MSG_FIRST_VALID_PROD_WF_CODE"))){
						isProductTemplate = true;			
						updateDataGrid(getDfSession(), newDoc.getString(IdocsConstants.PROJ_ID), pdtWfTypeCode);
						DfLogger.debug(this, "Product DataGrid Required.", null, null);
					}else{
						Panel pdtgridpanel = (Panel)getControl(PDT_GRID_PANEL,Panel.class);
						pdtgridpanel.setVisible(false);
						DfLogger.debug(this, "Product DataGrid NOT Required. Disable Product DataGrid ", null, null);
					}
					
					DfLogger.debug(this, " :: onInit : strTemplateName :" + strTemplateName,null,null);
					String strTripTemplateNames = IdocsUtil.getMessage("TRIP_TEMPLATES");
					DfLogger.debug(this, " :: onInit : strTripTemplateNames :" + strTripTemplateNames,null,null);

					if ( (IdocsUtil.checkIfTokenPresent(strTripTemplateNames, strTemplateName, ",")) && (enableDataGrid == true) ) {	
						DfLogger.debug(this, " :: onInit : Inside TRIP Template: template_code"+template_code, null, null);	
						DfLogger.debug(this, " :: onInit : strTemplateName :" + strTemplateName, null, null);
						tripGrid=updateTripDataGrid(getDfSession(), newDoc.getString(IdocsConstants.PROJ_ID),template_code, strTemplateName);
					} else {
						DfLogger.debug(this, "Hiding datagrid and submission no label for other templates", null, null);
						Panel tripgridpanel = (Panel)getControl(TRIP_GRID_PANEL,Panel.class);
						tripgridpanel.setVisible(false);
						Label nosubmissionlabel = (Label)getControl(NOSUBMISSION_HEADER, Label.class);
						nosubmissionlabel.setVisible(false);
					}			        
					DfLogger.debug(this, "Trip Grid boolean value"+tripGrid, null, null);
					DfLogger.debug(this, "Enable DataGrid boolean value"+enableDataGrid, null, null);	
				}else{

					DfLogger.debug(this, "This is not TRIP or Product document, hence hiding datagrids", null, null);
					Panel tripgridpanel = (Panel)getControl(TRIP_GRID_PANEL,Panel.class);
					tripgridpanel.setVisible(false);
					Label nosubmissionlabel = (Label)getControl(NOSUBMISSION_HEADER, Label.class);
					nosubmissionlabel.setVisible(false);
					DfLogger.debug(this, "Submission Number Label is hidden", null, null);
					Panel pdtgridpanel = (Panel)getControl(PDT_GRID_PANEL,Panel.class);
					pdtgridpanel.setVisible(false);
				}
			}else{

				Panel tripgridpanel = (Panel)getControl(TRIP_GRID_PANEL,Panel.class);
				tripgridpanel.setVisible(false);
				Label nosubmissionlabel = (Label)getControl(NOSUBMISSION_HEADER, Label.class);
				nosubmissionlabel.setVisible(false);
				DfLogger.debug(this, "Submission Number Label is hidden", null, null);
				Panel pdtgridpanel = (Panel)getControl(PDT_GRID_PANEL,Panel.class);
				pdtgridpanel.setVisible(false);
			}

			DateInput docDate = (DateInput)getControl("doc_date",DateInput.class);
			IDfTime idfTime = newDoc.getTime("document_date");
			DfLogger.debug(this, " :: documentDate : "+docDate.getValue(), null, null);
			if(docDate != null){
				String currentValue = idfTime.asString(IDfTime.DF_TIME_PATTERN8);
				if(currentValue!=null && currentValue.trim().length() >0 && currentValue.equalsIgnoreCase("nulldate") == false ){
					DfLogger.debug(this, " :: Document Date Set Already>> " + currentValue, null, null);
					docDate.setValue(new DfTime(currentValue).asString("month dd, yyyy"));
				}else{
					docDate.setValue(new DfTime(new SimpleDateFormat(
					"yyyy/MM/dd").format(new Date()), "mon dd, yyyy").asString("month dd, yyyy"));
					DfLogger.debug(this, " :: Document Date is NULL Set it to >> " + docDate.getValue() , null, null);        		
				}
				if (newDoc.isImmutable() == true || newDoc.hasPermission(IDfACL.DF_PERMIT_WRITE_STR, getDfSession().getLoginUserName()) == false ) {
					DfLogger.debug(this, " :: Since cannot save attributes for previous versions, date field is disbaled" , null, null);     
					docDate.setEnabled(false);
				}
			}
			setupTypeList();
			//===================================== Aspects Attribute Display Code Start  ==========================================	
			if(newDoc.getBoolean("is_emaildoc") || newDoc.getBoolean("is_scandoc")){
				ASPECT_EXISTED=true;
				if(newDoc.getBoolean("is_emaildoc") )
					enableScannedAttributes=true;
				if(newDoc.getBoolean("is_scandoc"))
					enableEmailedAttributes=true;

				Datagrid aspectsGrid=(Datagrid)getControl(ASPECT_GRID, Datagrid.class);
				aspectsGrid.getDataProvider().setDfSession(getDfSession());
				String queryString=getAspectQuery(newDoc);
				if(queryString!= null){
					ScrollableResultSet scrollableResultSet = buildTableResultSet(queryString,newDoc);
					aspectsGrid.getDataProvider().setScrollableResultSet(scrollableResultSet);
				}
			}
			//================================== Aspects Attribute Display Code End ==========================================
			/*
			 * CODE CHANGES START  : IOM Documents
			 */     	

			String strTemplateName  = IdocsUtil.getTemplateTitle(getDfSession(),strObjectId);

			if(isThisCameFromCreate != null && isThisCameFromCreate.trim().length()>0 
					&& isThisCameFromCreate.equalsIgnoreCase(IdocsConstants.MSG_YES)){
				/*
				 * Advisory Services Change to add Financial Year and Qtr for Supervision Documents
				 */
				if (strTemplateName != null && strTemplateName.equals(IDocsConstants.MSG_AS_SUPERVISION) || strTemplateName.equals(IDocsConstants.MSG_AS_PDP_SUPERVISION)) {
					Document documentObject = IdocsUtil.getFinancialData(newDoc.getString(IDocsConstants.PROJECT_ID), getDfSession(),IdocsUtil.getTemplateCategoryCode(strTemplateName));
					String financialYear = null;
					String quarter = null;
					try{
						XPathFactory xPathFactory = XPathFactory.newInstance();
						XPath xPath = xPathFactory.newXPath();
						XPathExpression fyExpression = xPath.compile("/as_supervision/spv_fy");
						financialYear = fyExpression.evaluate(documentObject);
						DfLogger.debug(IdocsUtil.class,": Financial Year : "+financialYear,null,null);
						XPathExpression qtrExpression = xPath.compile("/as_supervision/spv_qtr");
						quarter = qtrExpression.evaluate(documentObject);
						DfLogger.debug(IdocsUtil.class,": Financial Quater : "+quarter,null,null);
					}catch (XPathExpressionException e) {
						e.printStackTrace();
					}finally{
						if(financialYear==null){
							Integer integerObj = new Integer(Calendar.YEAR);
							financialYear = integerObj.toString();
							DfLogger.debug(this, " :: onInit : Financial Year Data from XML is NULL so new financialYear: " + financialYear,null,null);
						}
						if(quarter==null){
							quarter = "";
							DfLogger.debug(this, " :: onInit : quarter Data from XML is NULL so new quarter " + quarter,null,null);
						}
					}    				
					StringBuffer asDocumentName = new StringBuffer(newDoc.getString(IDocsConstants.PROJECT_ID)).append("_").append(strTemplateName).append("_FY").append(financialYear).append(quarter);
					DfLogger.debug(this, " :: onInit : Document Name for Supervision is  " + asDocumentName,null,null);
					newDoc.setObjectName(asDocumentName.toString());
				}

				/*
				 * Code changes for Document Name change Finish
				 */

				DfLogger.debug(this, ":: is from Create = "+enableDataGrid, null, null);				
			}else{

				/*DfLogger.debug(this, "onInit() :: CODE CHANGES START for IOM Documents", null, null);
	        	DocbaseAttributeValue docbaseAttrValue = (DocbaseAttributeValue)getControl("docname", DocbaseAttributeValue.class); 
	        	String strDocumentState = newDoc.getString(IDocsConstants.MSG_DOC_STATE);
	        	if((idocsProperties.getProperty("MSG_INTERNAL_OFFICE_MEMORANDUM")).equals(strTemplateName) 
	        			&& newDoc.getOwnerName().equalsIgnoreCase(getDfSession().getLoginUserName())== true 
	        			&& newDoc.isCheckedOut() == false
	        			&& strDocumentState!=null && strDocumentState.equalsIgnoreCase(IdocsConstants.DOC_STATE_DRAFT)) {
	        		docbaseAttrValue.setReadonly(false);
	        		docbaseAttrValue.setRequired(true);
	        		DfLogger.debug(this, "onInit() :: Document Name field is set to READ ONLY", null, null);
	        	}else{
	        		docbaseAttrValue.setReadonly(true);	        		
	        	}
	        	DfLogger.debug(this, "onInit() :: CODE CHANGES END for IOM Documents", null, null);*/

			}

			/**
			 * CODE CHANGES START  : IOM Documents
			 */ 
			String strDocumentState = newDoc.getString(IDocsConstants.MSG_DOC_STATE);
			DfLogger.debug(this, "onInit() :: Document state : "+strDocumentState, null, null);
			String template_code = newDoc.getString(IDocsConstants.MSG_TEMPLATE_CODE);   
			DfLogger.debug(this, "onInit() :: Template code : "+template_code, null, null);
			DfLogger.debug(this, "onInit() :: Logged in user : "+getDfSession().getLoginUserName(), null, null);
			DfLogger.debug(this, "onInit() :: Owner name : "+newDoc.getOwnerName(), null, null);
			DocbaseAttributeValue docbaseAttrValue = (DocbaseAttributeValue)getControl("docname", DocbaseAttributeValue.class);
			if(newDoc.getOwnerName().equalsIgnoreCase(getDfSession().getLoginUserName())== true 
					&&newDoc.isCheckedOut() == false){
				if(((IdocsUtil.getMessage("MSG_INTERNAL_OFFICE_MEMORANDUM")).equals(strTemplateName)==true
						&& strDocumentState.equalsIgnoreCase(IdocsConstants.DOC_STATE_DRAFT)==true)
						|| template_code.trim().length()==0){
					docbaseAttrValue.setReadonly(false);
					docbaseAttrValue.setRequired(true);
					DfLogger.debug(this, "onInit() :: Document Name field is editable", null, null);
				}
			}
			else{
				docbaseAttrValue.setReadonly(true);
				DfLogger.debug(this, "onInit() :: Document Name field is set to read only", null, null);
			}
			/**
			 * CODE CHANGES END  : IOM Documents
			 */        	        	
		}catch(DfException e){
			DfLogger.error(this, " :: onInit Exception >> "+e.getMessage(), null, e);
		} 
	}

	public void getBizTemplateStatus(String docSubType,String strObjectType) throws DfException{

		DfLogger.info(this," getBizTemplateStatus ::docSubtype: " + docSubType,null,null);
		if (docSubType == null || docSubType.trim().equals("")) {
			flag = true;
		}
		DfLogger.info(this,"Attributes :flag: " + flag,null,null);
		countryDoc=strObjectType.equals("idocs_country_doc");
		String docState=newDoc.getString(IDocsConstants.MSG_DOC_STATE);
		isCreatedFromBizTemplate=newDoc.getBoolean("iscreatedfrombiztemplate");
		if(docState.equals("Released")){
			readOnly=true;
			if((newDoc.getBoolean("is_emaildoc") || newDoc.getBoolean("is_scandoc"))){
				if(newDoc.getOwnerName().equals(getDfSession().getLoginUserName())==true){
						DfLogger.info(this," getBizTemplateStatus ::Released : Logged in user is the DOCUMENT OWNER",null,null);
						securityreadOnly=false;
				}else if(IDocsConstants.MSG_IDOCS_PROJECT_DOC.equals(objectType)){
					if (IDocDocbaseAttributeTagUtility.isUserMemberOfGroup(getDfSession(),strObjectId,IDocsConstants.MSG_PR_TL_GROUP,IDocsConstants.MSG_IDOCS_PROJECT_DOC) 
						|| IDocDocbaseAttributeTagUtility.isUserMemberOfGroup(getDfSession(),strObjectId,IDocsConstants.MSG_PR_PO_GROUP,IDocsConstants.MSG_IDOCS_PROJECT_DOC)){
						DfLogger.info(this," getBizTemplateStatus ::Released : PROJECT DOC, User is present in TL/PO GROUP",null,null);
						securityreadOnly=false;
					}
				}else if(IDocsConstants.MSG_IDOCS_INSTITUTION_DOC.equals(objectType)){	
					if(IDocDocbaseAttributeTagUtility.isUserMemberOfGroup(getDfSession(),strObjectId,IDocsConstants.MSG_INST_TL_GROUP,IDocsConstants.MSG_IDOCS_INSTITUTION_DOC) 
						|| IDocDocbaseAttributeTagUtility.isUserMemberOfGroup(getDfSession(),strObjectId,IDocsConstants.MSG_INST_PO_GROUP,IDocsConstants.MSG_IDOCS_INSTITUTION_DOC)){
						DfLogger.info(this," getBizTemplateStatus ::Released : INSTITUTION DOC, User is present in TL/PO GROUP",null,null);
						securityreadOnly=false;
					}
				}
				// Checking change permit for the logged in user
				if (newDoc.hasPermission(IDfACL.DF_XPERMIT_CHANGE_PERMIT_STR, newDoc.getObjectSession().getLoginUserName()) == false) {
						DfLogger.debug(this, newDoc.getObjectSession().getLoginUserName()+ " Don't have CHANGE PERMIT", null, null);
					DfLogger.debug(this," getBizTemplateStatus ::Released : Render security classification as ReadOnly", null,null);
					securityreadOnly=true;
				}
				else{
					DfLogger.debug(this, newDoc.getObjectSession().getLoginUserName()+ " has CHANGE PERMIT", null, null);
				}
			}else{
				DfLogger.info(this," getBizTemplateStatus ::Released : Not Emailed/Scanned document",null,null);
				securityreadOnly=true;
			}
		}
		else
		{
			DfLogger.info(this,"Attributes if(docState.equals(\"Released\")) : else Part",null,null);
		}
	/*	DfLogger.info(this, "Attributes getBusinessTemplateStatus :countryDoc : "+countryDoc,null,null);
		DfLogger.info(this, "Attributes getBusinessTemplateStatus :isCreatedFromBizTemplate : "+isCreatedFromBizTemplate,null,null);
		DfLogger.info(this, "Attributes getBusinessTemplateStatus :readOnly : "+readOnly,null,null);
		DfLogger.info(this, "Attributes getBusinessTemplateStatus :securityreadOnly : "+securityreadOnly,null,null);*/

	}
	/**
	 * 
	 * @param aspectCheck
	 * @param arg
	 */
	public void onClickShowAspectProperties(Checkbox aspectCheck, ArgumentList arg ) {
		DfLogger.info(this, " :: onClickShowAspectProperties >> Check Box Status :: "+aspectCheck.getValue(), null, null);
		if(aspectCheck.getValue() == true)  {
			hideAspectAttributeProperties=true;

		}else{
			hideAspectAttributeProperties=false;
		}
	}
	/**
	 * To get the Query for Aspects attributes.
	 * 
	 * @return queryString
	 */
	public String getAspectQuery(IDfDocument docObject)
	{
		String queryString=null;
		try {
			int aspectValueCount=newDoc.getValueCount("r_aspect_name");

			StringBuilder queryBuilder= new StringBuilder(); 
			queryBuilder.append("select r_object_id");
			boolean entryStatus=false;
			boolean firstOccurence=false;
			ArrayList<String> aspectNames= new ArrayList<String>();
			aspectNames.add(IdocsConstants.IDOCS_SCANNING_DOC_ASPECT);
			aspectNames.add(IdocsConstants.IDOCS_EMAIL_DOC_ASPECT);

			for (int iter = 0; iter < aspectValueCount; iter++) {
				String aspectName=newDoc.getRepeatingString("r_aspect_name",iter);
				if(entryStatus){
					if(aspectNames.contains(aspectName))
						queryBuilder.append(",");	
					firstOccurence=true;
				}
				if(aspectName.equalsIgnoreCase(IdocsConstants.IDOCS_SCANNING_DOC_ASPECT)){
					/*idocs_scanning_doc_aspect.
						==============================
					i_partition  ==>integer,	ifc_inputsender_host    ==>String,ifc_inputsender_ip	==> String,ifc_inputtype		==> string*/
					entryStatus=true;
					if(firstOccurence == false)
						queryBuilder.append(",");

					queryBuilder.append(aspectName+".i_partition ,");
					queryBuilder.append(aspectName+".ifc_inputsender_host,");
					queryBuilder.append(aspectName+".ifc_inputsender_ip,");
					queryBuilder.append(aspectName+".ifc_inputtype");
					enableScannedAttributes=true;
				}else if(aspectName.equalsIgnoreCase(IdocsConstants.IDOCS_EMAIL_DOC_ASPECT)){
					/*	i_partition====> integer ,idocs_email_cc_list==>String,idocs_email_doc_type==>String,idocs_email_message_id==>String,idocs_email_received_date====> time
					idocs_email_sent_from====>String,idocs_email_sent_to_list==>String,		*/
					entryStatus=true;

					if(firstOccurence == false)
						queryBuilder.append(",");
					queryBuilder.append(aspectName+".i_partition ,");
					queryBuilder.append(aspectName+".idocs_email_cc_list,");
					queryBuilder.append(aspectName+".idocs_email_doc_type,");
					queryBuilder.append(aspectName+".idocs_email_message_id,");
					queryBuilder.append(aspectName+".idocs_email_received_date,");
					queryBuilder.append(aspectName+".idocs_email_sent_from,");
					queryBuilder.append(aspectName+".idocs_email_sent_to_list");
					enableEmailedAttributes=true;
				}
			}
			queryBuilder.append("  from  "+newDoc.getString("r_object_type")+" where r_object_id='"+newDoc.getString("r_object_id")+"'");
			queryString=queryBuilder.toString();

		} catch (DfException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return queryString;
	}

	public ScrollableResultSet buildTableResultSet(String queryString,IDfDocument docObject)throws DfException{

		DfLogger.debug(this, " :: buildTableResultSet:: " + queryString, null,null);
		int aspectCount=newDoc.getValueCount(IdocsConstants.R_ASPECT_NAME);
		ArrayList<String> aspectNames= new ArrayList<String>();
		if(aspectCount !=0){
			for(int iter1 = 0; iter1 < aspectCount; iter1++) {
				aspectNames.add(newDoc.getRepeatingString(IdocsConstants.R_ASPECT_NAME,iter1));
			}
		}

		TableResultSet tableResultSet = new TableResultSet(aspect_attributes);
		IDfCollection resultSet = null;
		IDfQuery query = new DfQuery();
		query.setDQL(queryString);
		try {

			resultSet = query.execute(getDfSession(), IDfQuery.READ_QUERY);
			if (resultSet != null) {
				while (resultSet.next()) {
					// extract the 4 know attribute values from the query
					String[] tableRow = new String[11];

					//idocs_email_doc_aspect, idocs_scanning_doc_aspect
					if(aspectNames.contains(IdocsConstants.IDOCS_SCANNING_DOC_ASPECT)){
						tableRow[0] = resultSet.getInt("idocs_scanning_doc_aspect.i_partition")+"";
						tableRow[1] = resultSet.getString("idocs_scanning_doc_aspect.ifc_inputsender_host");
						tableRow[2] = resultSet.getString("idocs_scanning_doc_aspect.ifc_inputsender_ip");
						tableRow[3] = resultSet.getString("idocs_scanning_doc_aspect.ifc_inputtype");
					}

					if(aspectNames.contains(IdocsConstants.IDOCS_EMAIL_DOC_ASPECT)){
						tableRow[4] = resultSet.getInt("idocs_email_doc_aspect.i_partition")+"";
						int idocs_email_list_count=resultSet.getValueCount("idocs_email_doc_aspect.idocs_email_cc_list");
						String idocs_email_list="";
						if(idocs_email_list_count >= 1)
							for (int iter_email_cc_list = 0; iter_email_cc_list < idocs_email_list_count; iter_email_cc_list++) {
								if(iter_email_cc_list !=0)
									idocs_email_list=idocs_email_list+",\n"+resultSet.getRepeatingString("idocs_email_doc_aspect.idocs_email_cc_list", iter_email_cc_list);
								else
									idocs_email_list=idocs_email_list+resultSet.getRepeatingString("idocs_email_doc_aspect.idocs_email_cc_list", iter_email_cc_list);
							}
						tableRow[5] = idocs_email_list;//resultSet.getString("idocs_email_doc_aspect.idocs_email_cc_list");
						tableRow[6] = resultSet.getString("idocs_email_doc_aspect.idocs_email_doc_type");
						tableRow[7] = resultSet.getString("idocs_email_doc_aspect.idocs_email_message_id");

						if(resultSet.getTime("idocs_email_doc_aspect.idocs_email_received_date") != null){
							if(resultSet.getTime("idocs_email_doc_aspect.idocs_email_received_date").toString() != "nulldate")
								tableRow[8] = resultSet.getTime("idocs_email_doc_aspect.idocs_email_received_date").toString();
							else 
								tableRow[8] ="";
						} else
							tableRow[8] ="";

						int idocs_email_sent_from_count=resultSet.getValueCount("idocs_email_doc_aspect.idocs_email_sent_from");
						String idocs_email_sent_from_list="";
						if(idocs_email_list_count >= 1){
							for (int iter_email_from_list = 0; iter_email_from_list < idocs_email_sent_from_count; iter_email_from_list++) {
								if(iter_email_from_list !=0)
									idocs_email_sent_from_list=idocs_email_sent_from_list+",\n"+resultSet.getRepeatingString("idocs_email_doc_aspect.idocs_email_sent_from", iter_email_from_list);
								else
									idocs_email_sent_from_list=idocs_email_sent_from_list+resultSet.getRepeatingString("idocs_email_doc_aspect.idocs_email_sent_from", iter_email_from_list);
							}
						} else idocs_email_sent_from_list = resultSet.getString("idocs_email_doc_aspect.idocs_email_sent_from");	

						tableRow[9] = idocs_email_sent_from_list;

						int email_sent_to_list_count=resultSet.getValueCount("idocs_email_doc_aspect.idocs_email_sent_to_list");
						String idocs_email_sent_to_list="";
						if(email_sent_to_list_count >= 1){
							for (int iter_email_to_list = 0; iter_email_to_list < email_sent_to_list_count; iter_email_to_list++) {
								if(iter_email_to_list !=0)
									idocs_email_sent_to_list=idocs_email_sent_to_list+",\n"+resultSet.getRepeatingString("idocs_email_doc_aspect.idocs_email_sent_to_list", iter_email_to_list);
								else
									idocs_email_sent_to_list=idocs_email_sent_to_list+resultSet.getRepeatingString("idocs_email_doc_aspect.idocs_email_sent_to_list", iter_email_to_list);
							}
						} else idocs_email_sent_to_list = resultSet.getString("idocs_email_doc_aspect.idocs_email_sent_to_list");

						tableRow[10] =idocs_email_sent_to_list;
					}
					// finally, add the row to the table result set
					tableResultSet.add(tableRow);
				}
			}
		}finally {
			if (resultSet != null)
				resultSet.close();
		}
		return tableResultSet;
	}


	/**
	 * Method overwritten to save the changes to the object
	 */
	public boolean onCommitChanges() {
		boolean commitFlag = false;
		String strDocName = "";
		try{
			String docTemplateName=null;
			strDocName = newDoc.getObjectName();
			DfLogger.debug(this, " :: onCommitChanges : strDocName: "+strDocName, null, null);
			if(strDocName.indexOf("_")!= -1){
				docTemplateName = strDocName.substring(strDocName.indexOf("_")+1);
				DfLogger.debug(this, " :: onCommitChanges : docTemplateName: " + docTemplateName, null, null);
			}
			String strTripTemplateNames =IdocsUtil.getMessage("TRIP_TEMPLATES");
			DfLogger.debug(this, " :: onCommitChanges : strTripTemplateNames :" + strTripTemplateNames,null,null);
			DfLogger.debug(this, " :: onCommitChanges: Login Name: "+getDfSession().getLoginUserName(), null, null);

			if(strTemplateName != null && strTemplateName.trim().length() >0){
				//don't care
			}else{
				strTemplateName  = IdocsUtil.getTemplateTitle(getDfSession(),strObjectId);
			}

			DocbaseAttributeValue docbaseAttrValue = (DocbaseAttributeValue)getControl("docname", DocbaseAttributeValue.class);

			if(isThisCameFromCreate != null && isThisCameFromCreate.trim().length()>0 
					&& isThisCameFromCreate.equalsIgnoreCase(IdocsConstants.MSG_YES)) {
				// $ validation for IOM templates during creation
				if(strTemplateName != null && (IdocsUtil.getMessage("MSG_INTERNAL_OFFICE_MEMORANDUM")).equals(strTemplateName) && !(newDoc.isCheckedOut())) {
					if(docbaseAttrValue.getValue() != null){
						String exisitingDocName = docbaseAttrValue.getValue();
						if (IdocsUtil.isValidIOMObjectName(exisitingDocName) == false) {
							Object params[] = new Object[1];
							params[0] = IDocsConstants.MSG_EMPTY_STRING;
							WebComponentErrorService.getService().setNonFatalError(this, "MSG_DOLLAR_CHAR_VALIDATION", params, null);
							return false;
						}	
					}else{
						//DfLogger.debug(this, ":: Existing doc name will not reflect in permission and history component:", null, null);
					}
				}
				
				if (IdocsUtil.checkIfTokenPresent(strTripTemplateNames, strTemplateName, ",")){
					Hidden hdTemplateNbr = (Hidden)getControl(SELECTED_TRIP_NBR_HIDDEN,Hidden.class);
					submissionNbr = hdTemplateNbr.getValue();
					DfLogger.debug(this, " :: onCommitChanges: submissionNbr : " +submissionNbr, null, null);
					if(submissionNbr != null && submissionNbr.trim().length() > 0){
						DfLogger.debug(this, " :: Selected Submission number:  submissionNbr: " + submissionNbr, null, null);
					}else{
						validationError=IdocsUtil.getMessage("MSG_TRIP_SELECT_VALIDATION");							 
						Object params[] = new Object[1];             
						params[0] = DocbaseUtils.getValidationExceptionMsg(new DfException(validationError));			            	   	
						WebComponentErrorService.getService().setNonFatalError(this, "MSG_VALIDATION_ERROR", new DfException(validationError));
						return false;
					}
				}else{
					DfLogger.debug(this, " :: Commit from new Document: Not a TRIP Template Document : ", null, null);
				}

				if(IdocsUtil.ifProductIntegrationRequired(strTemplateName)){
					Hidden hdWfNbr = (Hidden)getControl(SELECTED_WF_NBR_HIDDEN,Hidden.class); 
					strWfNbr = hdWfNbr.getValue();
					if(isProductWfExists && (strWfNbr != null && strWfNbr.trim().length() > 0)){	
						DfLogger.debug(this, " :: Selected workflow number:  strWfNbr: " + strWfNbr, null, null);
					}else if(isProductWfExists && (null== strWfNbr || IDocsConstants.MSG_EMPTY_STRING.equals(strWfNbr))){
						validationError=IdocsUtil.getMessage("MSG_WF_SELECT_VALIDATION");							 
						Object params[] = new Object[1];             
						params[0] = DocbaseUtils.getValidationExceptionMsg(new DfException(validationError));			            	   	
						WebComponentErrorService.getService().setNonFatalError(this, "MSG_VALIDATION_ERROR", new DfException(validationError));
						return false;
					}else{
						DfLogger.debug(this, " :: isProductWfExists :="+isProductWfExists +" :: strWfNbr="+strWfNbr, null, null);
					}
				} else{
					DateInput docDate = (DateInput)getControl("doc_date",DateInput.class);
					DfLogger.debug(this, " :: onCommitChanges::Coming from create:: documentDate : "+docDate.getValue(), null, null);
					if(docDate!=null){
						DfLogger.debug(this, ":: onCommitChanges:: Coming from create:: document_date from object : "+newDoc.getTime("document_date"), null, null);
					}
				}
			}else{
				// $ validation for IOM templates during view properties screen
				if(strTemplateName != null && (IdocsUtil.getMessage("MSG_INTERNAL_OFFICE_MEMORANDUM")).equals(strTemplateName) && !(newDoc.isCheckedOut())) {
					DfLogger.debug(this, " :: onCommitChanges ::$ validation for IOM templates during view properties screen", null, null);
					if(docbaseAttrValue.getValue() != null){
						String exisitingDocName = docbaseAttrValue.getValue();
						if (IdocsUtil.isValidIOMObjectName(exisitingDocName) == false) {
							Object params[] = new Object[1];
							params[0] = IDocsConstants.MSG_EMPTY_STRING;
							WebComponentErrorService.getService().setNonFatalError(this, "MSG_DOLLAR_CHAR_VALIDATION", params, null);
							return false;
						}	
					}else{
						//DfLogger.debug(this, " :: Existing doc name will not reflect in permission and history component : ", null, null);
					}
				}
				DfLogger.debug(this, " :: Commit from Properties: Dont Set Document Date If document is checked out : ", null, null);
				if(newDoc.isCheckedOut()){
					DfLogger.debug(this, ":: document_date not set as Document is Checkedout: ", null, null);
				}else{
					DateInput docDate = (DateInput)getControl("doc_date",DateInput.class);
					DfLogger.debug(this, " :: onCommitChanges:: documentDate 2 from control: "+docDate.getValue(), null, null);
					if(docDate!=null){
						if (newDoc.isImmutable() == false  && newDoc.hasPermission(IDfACL.DF_PERMIT_WRITE_STR, getDfSession().getLoginUserName()) == true ){
							DfLogger.debug(this, ":: onCommitChanges:: current version doc", null, null);
							DfLogger.debug(this, ":: onCommitChanges:: document_date from object : "+newDoc.getTime("document_date"), null, null);
						} else {
							DfLogger.debug(this, ":: Cannot set date for previous version documents", null, null); 
						}
					}else{
						DfLogger.debug(this, "::document is not saved b'coz   docDate is null.", null, null);
					}
				}
			}
		}catch(DfException e){
			DfLogger.error(this, ":: DfException : "+e.getMessage(), null, e);
		}
		
		javax.servlet.http.HttpSession httpSession = getPageContext().getSession();
		httpSession.setAttribute(IdocsConstants.MSG_IS_LOADED_FROM_CREATE,IDocsConstants.MSG_EMPTY_STRING);
		try {
			DfLogger.debug(this, ":: onCommitChanges:: document_date from object END: "+newDoc.getTime("document_date"), null, null);
		} catch (DfException e) {
			DfLogger.error(this, ":: DfException : "+e.getMessage(), null, e);
		}
		commitFlag = super.onCommitChanges();
		try {
			IDfSysObject freshObject = (IDfSysObject)ObjectCacheUtil.getObject(getDfSession(), strObjectId);
			DocbaseAttributeValue docbaseAttrValue = (DocbaseAttributeValue)getControl("docname", DocbaseAttributeValue.class);
			DateInput docDate = (DateInput)getControl("doc_date",DateInput.class);
			if(freshObject.isCheckedOut() == false 
					&& freshObject.isImmutable() == false  
					&& freshObject.hasPermission(IDfACL.DF_PERMIT_WRITE_STR, getDfSession().getLoginUserName()) == true ){
				if(newDoc != null && newDoc.getTypeName().equals(IDocsConstants.MSG_IDOCS_PROJECT_DOC)
						&& submissionNbr != null && submissionNbr.trim().length() > 0){
					freshObject.setString(TRIP_SUBMISSION_NBR, submissionNbr);
				}
				if(newDoc != null && newDoc.getTypeName().equals(IDocsConstants.MSG_IDOCS_PROJECT_DOC)
						&& isProductWfExists && (strWfNbr != null && strWfNbr.trim().length() > 0)){	
					freshObject.setString(PDT_WF_NBR, strWfNbr);
				}
				if(strTemplateName != null && (IdocsUtil.getMessage("MSG_INTERNAL_OFFICE_MEMORANDUM")).equals(strTemplateName) && !(newDoc.isCheckedOut())) {
					String correctObjectName = formatIOMName(docbaseAttrValue.getValue(),freshObject.getString(IDocsConstants.PROJECT_ID));
					freshObject.setString(IDocsConstants.MSG_OBJECT_NAME,correctObjectName);
				}else{
					
					if(getDocumentName() != null){
						freshObject.setString("object_name", getDocumentName());
						DfLogger.debug(this, " :: onCommitChanges::Document Name : "+getDocumentName(), null, null);
					}else{
						
						freshObject.setString("object_name", strDocName);
						DfLogger.debug(this, " :: onCommitChanges::Document Name : "+strDocName, null, null);
					}
					
				}		
				DfLogger.debug(this, " :: onCommitChanges::Coming from create:: documentDate : "+docDate.getValue(), null, null);
				if(docDate!=null){
					freshObject.setTime("document_date", getDocumentDate(docDate));			
				}
				freshObject.save();
			}
		} catch (DfException e) {
			e.printStackTrace();
		}
		return commitFlag;
	}

	private String formatIOMName(String objectName,String projectId) throws DfException {
		String exisitingDocName = objectName;
		String correctObjectName = null;
		if(exisitingDocName != null){
			StringBuffer docNewName = new StringBuffer(projectId);
			docNewName.append("_");
			if(exisitingDocName.startsWith(docNewName.toString())){
				correctObjectName = exisitingDocName;
				DfLogger.info(this, (new StringBuilder(" :: onCommitChanges : New Document Name  : ").append(exisitingDocName)).toString(), null, null);
			}else{
				docNewName.append(exisitingDocName);
				correctObjectName = docNewName.toString();
				DfLogger.debug(this, "New document name : ."+docNewName.toString(), null, null);
				DfLogger.info(this, (new StringBuilder(" :: onCommitChanges : New Document Name  : ").append(docNewName)).toString(), null, null);
			}
		}else{
			correctObjectName = exisitingDocName;
		}
		return correctObjectName;
	}

	/**
	 * 
	 * @param docDate
	 * @return
	 */
	private IDfTime getDocumentDate(DateInput documentDate) {
		if(documentDate != null){
			IDfTime documentDateSet = new DfTime(documentDate.getValue());
			if(documentDateSet.compareTo(new DfTime()) == 1){
				DfLogger.debug(this, "getDocumentDate :: Set Date ="+new DfTime(), null, null);
				return new DfTime();
			}else{
				DfLogger.debug(this, "getDocumentDate :: Set Date ="+documentDateSet, null, null);
				return documentDateSet;
			}
		}else{
			DfLogger.debug(this, "getDocumentDate :: Set Date ="+new DfTime(), null, null);
			return new DfTime();
		}
	}

	public void onExit() {
		super.onExit();
		javax.servlet.http.HttpSession httpSession = getPageContext().getSession();
		httpSession.setAttribute(IdocsConstants.MSG_IS_LOADED_FROM_CREATE,IDocsConstants.MSG_EMPTY_STRING);
		DfLogger.debug(this, " ::  onExit() :: MSG_IS_LOADED_FROM_CREATE is Cleared. ", null, null);
	}

	/**
	 * Method overwritten to take the user back to the main page on cancelling the Attributes
	 * Component.
	 */
	public boolean onCancelChanges() {		 
		javax.servlet.http.HttpSession httpSession = getPageContext().getSession();
		httpSession.setAttribute(IdocsConstants.MSG_IS_LOADED_FROM_CREATE,IDocsConstants.MSG_EMPTY_STRING);
		DfLogger.debug(this, " :: onCancelChanges() :: Create Attribute is cleared is null: ", null, null);
		return super.onCancelChanges();
	}	

	/**
	 * This method populates the datagrid for product workflow tempaltes
	 * while creation of document.
	 * @param dfsession - IDfSession Instance
	 * @param strProjID - Project ID
	 * @param pdtWfTypeCode - workflow type code
	 */
	public void updateDataGrid(IDfSession dfsession,String strProjID, int pdtWfTypeCode){
		try {
			DfLogger.debug(this, " :: updateDataGrid : "+getDfSession().getLoginUserName(), null, null);
		} catch (DfException e) {
			DfLogger.debug(this, ":: Exception : "+e.getMessage(), null, e);
		}
		datagrid = (Datagrid)getControl(PDT_GRID, Datagrid.class);
		datagrid.getDataProvider().setDfSession(getDfSession());		   	
		ProductAppService pdtService = new ProductAppService();    	
		datagrid  = pdtService.getProductWfDetails(getDfSession(), strProjID, pdtWfTypeCode,datagrid);

		if(null !=datagrid &&  datagrid.getDataProvider().getResultsCount()>0){
			isProductWfExists = true;
			datagrid.setVisible(true);
			String strDatagridHeader = pdtService.getDatagridLabel();
			Label headerLabel = (Label)getControl(GRID_HEADER, Label.class);
			headerLabel.setLabel(strDatagridHeader);
		}else{
			Panel pdtgridpanel = (Panel)getControl(PDT_GRID_PANEL,Panel.class);
			pdtgridpanel.setVisible(false);
			datagrid.setVisible(false);
		}
	}	


	/**
	 * This method is to show the Trip Integration datagrid in the debug 
	 * Tab of the IDocs Document.
	 * @param dfSession - Docbase session of the current user
	 * @param strProjId - Id of the project where the document belongs to.
	 * @param subTypeCode - Workflow type code of the document
	 * @return 
	 * @exception DfException - Exception thrown incase of any issue.
	 */
	private boolean updateTripDataGrid(IDfSession dfsession,String strProjID, int subTypeCode, String strTemplateName) throws DfException
	{
		boolean updateSuccess=false;
		try {
			DfLogger.debug(this, " :: updateTRIPDataGrid : "+getDfSession().getLoginUserName(), null, null);
		} catch (DfException e) {
			DfLogger.debug(this, ":: Exception : "+e.getMessage(), null, e);
		}

		DfLogger.debug(this, ":: Inside templatedatagrid : ", null, null);
		templatedatagrid = (Datagrid)getControl(TEMPLATE_DATAGRID, Datagrid.class);
		templatedatagrid.getDataProvider().setDfSession(getDfSession());		   
		TripTemplateService tripService = new TripTemplateService();

		//Method to show the submission details in the TRIP datagrid
		DfLogger.debug(this, " :: updateTripDataGrid : strTemplateName :" + strTemplateName, null, null);
		templatedatagrid  = tripService.getTripGridDetails(getDfSession(),strProjID,subTypeCode,templatedatagrid, strTemplateName);
		DfLogger.debug(this, "templatedatagrid.value"+templatedatagrid, null, null);

		if(null !=templatedatagrid &&  templatedatagrid.getDataProvider().getResultsCount()>0)
		{
			templatedatagrid.setVisible(true);
			String strDatagridHeader = tripService.getDatagridLabel();
			Label headerLabel = (Label)getControl(TRIP_HEADER, Label.class);
			headerLabel.setLabel(strDatagridHeader);
			updateSuccess=true;
			Label nosubmissionlabel = (Label)getControl(NOSUBMISSION_HEADER, Label.class);
			nosubmissionlabel.setVisible(false);
			DfLogger.debug(this, "Submission Number Label is hidden", null, null);
		}

		//If the datagrid is null, hide it and show a message

		if(templatedatagrid ==null){    		
			DfLogger.debug(this, "Inside null condition", null, null);
			Label nosubmissionlabel = (Label)getControl(NOSUBMISSION_HEADER, Label.class);
			nosubmissionlabel.setVisible(true);
			DfLogger.debug(this, "Template datagrid is empty label set", null, null); 
			Panel tripgridpanel = (Panel)getControl(TRIP_GRID_PANEL,Panel.class);
			tripgridpanel.setVisible(false);		        	
		}
		return updateSuccess;
	}


	/**
	 * Method to populate the sub folder name during import and for documents that doesn't
	 * have doc sub type code.
	 * @param typeList
	 * @param args
	 * @throws DfException
	 */
	public void onSelectDoc(DataDropDownList typeList,ArgumentList args) throws DfException {
		String subFolder = IDocsConstants.MSG_EMPTY_STRING;
		String folderTitle=IDocsConstants.MSG_EMPTY_STRING;
		String [] typeResults =null;
		String columnNames[] = {"subfolder_title","doc_type_name"};
		/** getting values from Query Services */
		DocTypeTableStructure docTypeTableStructure = new DocTypeTableStructure(IDocsQRYVO.getTemplateInfoTableData(getDfSession()));
		typeResults=docTypeTableStructure.getTableResultSetColumnWithWhereClausesWithDistinctAsArray(columnNames, "folder_category", strFolderCategory, "is_active","Yes","doc_type_code",typeList.getValue(),"subfolder_title");
		
		if(typeResults.length >= 2){
			subFolder = typeResults[0];
			folderTitle = typeResults[1];
		}
		
		if(subFolder != null && subFolder.trim().length() >0){
			//don't care 
		}else{
			String subFolderQry = IdocsUtil.getMessage("QUERY_FOLDER_TITLE");
			subFolderQry = subFolderQry.replaceFirst("''", "'"+typeList.getValue()+"'");
			subFolderQry = subFolderQry.replaceFirst("''", "'"+strFolderCategory+"'");
			IDfCollection dfCollection = IdocsUtil.executeQuery(getDfSession(), subFolderQry, IDfQuery.DF_READ_QUERY);
			if (dfCollection.next()) {
				subFolder = dfCollection.getString("subfolder_title");
				folderTitle = dfCollection.getString("doc_type_name");
				dfCollection.close();
			}
			if(dfCollection != null) dfCollection.close();	
		}
		newDoc.setString("doc_subtype_nme", folderTitle);
		newDoc.setString("doc_subtype_code", typeList.getValue());
		updateSubfolder(subFolder);
	}

	/**
	 * Updating the corresponding folder title to UI and object
	 * 
	 * @param subFolder - folder_title selected
	 * @throws DfException
	 */
	private void updateSubfolder(String subFolder) throws DfException {
		Label label = (Label)getControl("subfolder", Label.class);
		label.setLabel(subFolder);
		newDoc.setString("folder_title", label.getLabel());
	}
	
	/**
	 * This prepares the drop down list with allowed document sub type names.
	 * @throws DfException
	 */
	public void setupTypeList() throws DfException {
		TableResultSet typeResultSet = null;
		DataDropDownList typeList = (DataDropDownList)getControl("docTypeList", DataDropDownList.class);
		typeList.clearOptions();
		DocTypeTableStructure docTypeTableStructure = new DocTypeTableStructure(IDocsQRYVO.getTemplateInfoTableData(getDfSession()));
		String columnNames[] = {"doc_type_code","doc_type_name"};
		typeResultSet=docTypeTableStructure.getTableResultSetColumnWithWhereClausesWithDistinct(columnNames, "folder_category", strFolderCategory, "is_active","Yes", "doc_type_code");
		if(typeResultSet !=null){
			//DfLogger.debug(this, "No need to Query again Values are existed", null, null);
		}else{
			DfLogger.debug(this," :: setupTypeList...!!!",null,null);
			typeResultSet=new TableResultSet(new String[] {"doc_type_code", "doc_type_name"});
			String typeListQry = IdocsUtil.getMessage("QUERY_SELECT_TYPE");
			typeListQry = typeListQry.replaceFirst("''", "'" + strFolderCategory + "'");
			DfLogger.debug(this," :: setupTypeList : typeListQry : "+typeListQry,null,null);
			IDfCollection collection =IdocsUtil.executeQuery(getDfSession(), typeListQry,IDfQuery.DF_READ_QUERY);
			while(collection.next()) {
				String typeName = collection.getString("doc_type_code");
				String typeLabel = collection.getString("doc_type_name");
				typeResultSet.add(new String[] {typeName, typeLabel});
			}
			if(collection !=null)collection.close();
		}
		typeList.getDataProvider().setScrollableResultSet(typeResultSet);
		typeList.getDataProvider().sort("doc_type_name",Datagrid.SORTDIR_FORWARD,Datagrid.SORTMODE_TEXT);
	}

	public int getPdtWfTypeCode() {
		return pdtWfTypeCode;
	}

	public void setPdtWfTypeCode(int pdtWfTypeCode) {
		this.pdtWfTypeCode = pdtWfTypeCode;
	}

	public String getSelectedSubmissionNbr() {
		Hidden hdTemplateNbr = (Hidden)getControl(SELECTED_TRIP_NBR_HIDDEN,Hidden.class);
		if(hdTemplateNbr!= null ){
			return hdTemplateNbr.getValue();			
		}else{
			return null;
		}
	}

	public String getSelectedWfNbr() {
		Hidden hdWfNbr = (Hidden)getControl(SELECTED_WF_NBR_HIDDEN,Hidden.class); 
		if(hdWfNbr!= null ){
			return hdWfNbr.getValue();			
		}else{
			return null;
		}
	}

	public String getDocumentName(){
		DocbaseAttributeValue docbaseAttrValue = (DocbaseAttributeValue)getControl("docname", DocbaseAttributeValue.class);
		if(docbaseAttrValue != null){
			try {
				if(docbaseAttrValue.getValue() != null){
					DfLogger.info(this, " :: getDocumentName : documentName: " + docbaseAttrValue.getValue(), null, null);
					return docbaseAttrValue.getValue();
				}else return null;
			} catch (Exception e) {
				DfLogger.error(this, " :: getDocumentName :: " + e.getMessage(), null, null);
				return null;
			}
		}else{
			return null;
		}
	}

	public  boolean hideAspectAttributeProperties=false;
	public  boolean flag = false;
	public  boolean isCreatedFromBizTemplate=false;
	public  boolean readOnly=false;
	public  boolean securityreadOnly=false;
	public  boolean countryDoc=false;
}
