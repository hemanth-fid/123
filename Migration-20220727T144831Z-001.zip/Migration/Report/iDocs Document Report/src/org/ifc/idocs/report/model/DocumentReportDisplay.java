package org.ifc.idocs.report.model;

public class DocumentReportDisplay {
	
	private String folderValueCode1;
	private String documentCount1;
	private String folderSize1;
	private String folderValueCode2;
	private String documentCount2;
	private String folderSize2;
	
	public String getFolderValueCode1() {
		return folderValueCode1;
	}
	public void setFolderValueCode1(String folderValueCode1) {
		this.folderValueCode1 = folderValueCode1;
	}
	public String getDocumentCount1() {
		return documentCount1;
	}
	public void setDocumentCount1(String documentCount1) {
		this.documentCount1 = documentCount1;
	}
	public String getFolderSize1() {
		return folderSize1;
	}
	public void setFolderSize1(String folderSize1) {
		this.folderSize1 = folderSize1;
	}
	public String getFolderValueCode2() {
		return folderValueCode2;
	}
	public void setFolderValueCode2(String folderValueCode2) {
		this.folderValueCode2 = folderValueCode2;
	}
	public String getDocumentCount2() {
		return documentCount2;
	}
	public void setDocumentCount2(String documentCount2) {
		this.documentCount2 = documentCount2;
	}
	public String getFolderSize2() {
		return folderSize2;
	}
	public void setFolderSize2(String folderSize2) {
		this.folderSize2 = folderSize2;
	}

}
