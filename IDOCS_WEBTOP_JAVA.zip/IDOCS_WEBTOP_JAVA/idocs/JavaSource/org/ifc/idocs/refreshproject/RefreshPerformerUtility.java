package org.ifc.idocs.refreshproject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Map.Entry;

import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfACL;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfGroup;
import com.documentum.fc.client.IDfPermit;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfWorkflow;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfList;


public class RefreshPerformerUtility {
	
	private static final String R_LOCK_OWNER = "r_lock_owner";
	private static final String REFRESH_QRY_GET_DOC_DETAILS = "REFRESH_QRY_GET_DOC_DETAILS";
	/**
	 * 
	 * @param performerGrpName
	 * @param projectId
	 * @param adminSession
	 * @param lstPerformers
	 * @return
	 * @throws Exception 
	 * @throws Exception
	 */
	protected static ArrayList<String> getSubWfPerformersFromIdesk(String performerGrpName, String projectId, IDfSession adminSession) throws Exception{
		String upiIds = null;
		List<String> accessorIdLst = new ArrayList<String>();
		StringBuffer upiBuffer = new StringBuffer(BLANK_STRING);
		ArrayList<String> lstPerformers = new ArrayList<String>();
		String staffFunctionCode = getRoleCode(performerGrpName).get(1);
		if(staffFunctionCode==null){
			staffFunctionCode = performerGrpName.substring(3,5);
		}

		staffFunctionCode = staffFunctionCode.toUpperCase();
		DfLogger.debug(RefreshPerformerUtility.class,"getSubWfPerformersFromIdesk : staffFunctionCode : "+staffFunctionCode,null,null);
		String getUserDetailToBeAdded = GET_PROJECT_TEAM_MEM_ID;
		if(getUserDetailToBeAdded==null){
			throw new Exception("Exception occured :: GET_NEW_PERFORMERS_SUBWF_QRY is not available in property file::");
		}
		getUserDetailToBeAdded = getUserDetailToBeAdded.replaceAll(QRY_VARIABLE_PROJECT_ID_MOD, projectId).replaceAll(QRY_VARIABLE_STAFF_FUNCTION_CODE, staffFunctionCode);
		DfLogger.debug(RefreshPerformerUtility.class,"getSubWfPerformersFromIdesk : QRY for getUserDetailToBeAdded : "+getUserDetailToBeAdded,null,null);
		IDfCollection staffFunCollection = IdocsUtil.executeQuery(adminSession,getUserDetailToBeAdded, IDfQuery.READ_QUERY);
		try{
			while(staffFunCollection.next()){
				accessorIdLst.add(staffFunCollection.getString(PROJECT_TEAM_MEMBER_ID));
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());						
		}finally{
			if(staffFunCollection != null){
				staffFunCollection.close();
			}
		}
		if(accessorIdLst.size()>0){
			Iterator<String> iter =  accessorIdLst.iterator();
			while(iter.hasNext()){
				upiBuffer.append(QRY_VARIABLE_SQ);
				upiBuffer.append(addZeros(iter.next()));
				upiBuffer.append(STRING_Q_COMMA);
			}
		}
		if(upiBuffer.length()>0){
			upiIds = upiBuffer.substring(0, (upiBuffer.length()-1)).toString();
		}
		 if(upiIds != null && upiIds.length()>0){
			 String userNmeQry = GET_USER_NAME_QRY;
			 userNmeQry = userNmeQry.replaceAll(QRY_VARIABLE_UPI_ID, upiIds);
			 DfLogger.debug(RefreshPerformerUtility.class,"userNmeQry : " + userNmeQry,null,null);
			 IDfCollection userNmeColl = IdocsUtil.executeQuery(adminSession,userNmeQry, IDfQuery.READ_QUERY);
			 try {
				 while (userNmeColl.next()) {
					 lstPerformers.add(userNmeColl.getString(USER_NAME));
				}
			} catch (Exception e) {
				throw new Exception(e.getMessage());						
			}finally{
				if(userNmeColl != null){
					userNmeColl.close();
				}
			}
		 }
		DfLogger.debug(RefreshPerformerUtility.class,"getSubWfPerformersFromIdesk : lstPerformers getCount : "+lstPerformers.size(),null,null);
		return lstPerformers;
	}
	
	/**
	 * Fetches Performer List from Idesk for a given Workflow/Acitivity Combination
	 * 
	 * @return
	 * @throws DfException
	 * @throws IOException
	 */
	protected static ArrayList<String> getPerformersFromIdesk(IDfSession dfSession,String strProcessName,
			String strActivityName,String strProjectID,String strWorkflowId) throws DfException {
		ArrayList<String> lst_Idesk_Group_Members = new ArrayList<String>();
		boolean isGpsTask = false;
		isGpsTask = checkIsGpsTask(strActivityName);
		String workEnv = IdocsUtil.getLdapSuffixParam(dfSession);
		String QRY_GET_IDESK_PERFORMERS_FR_WF = GET_IDESK_PERFORMERS_FR_WF;
		QRY_GET_IDESK_PERFORMERS_FR_WF = QRY_GET_IDESK_PERFORMERS_FR_WF.replace(QRY_VARIABLE_STR_PROCESS_NAME, strProcessName);
		QRY_GET_IDESK_PERFORMERS_FR_WF = QRY_GET_IDESK_PERFORMERS_FR_WF.replace(QRY_VARIABLE_STR_ACTIVITY_NAME, strActivityName);
		IDfCollection dfCollection =  IdocsUtil.executeQuery(dfSession,QRY_GET_IDESK_PERFORMERS_FR_WF, IDfQuery.DF_READ_QUERY);
		while (dfCollection.next()){
			String role = dfCollection.getString(ROLE);
			DfLogger.info(RefreshProject.class,": role : "+role,null,null);
			String roleType = dfCollection.getString(ROLE_TYPE);
			DfLogger.info(RefreshProject.class,": roleType : "+roleType,null,null);
			String wfPerformer;
			if (roleType.equals(USER_ROLE)){
				String innerDql = null;
				if(isGpsTask){
					innerDql = AS_PROJ_TEAM_QRY;
					innerDql = innerDql.replaceFirst(QRY_VARIABLE_DQ, QRY_VARIABLE_SQ+strProjectID+QRY_VARIABLE_SQ);
					innerDql = innerDql.replaceFirst(QRY_VARIABLE_DQ, QRY_VARIABLE_SQ+role+QRY_VARIABLE_MOD_Q);
				}
				else{
					innerDql = IDOCS_PROJ_TEAM_QRY;
					innerDql = innerDql.replaceFirst(QRY_VARIABLE_DQ, QRY_VARIABLE_SQ+strProjectID+QRY_VARIABLE_SQ);
					innerDql = innerDql.replaceFirst(QRY_VARIABLE_DQ, QRY_VARIABLE_SQ+role+QRY_VARIABLE_SQ);
				}
				
				DfLogger.info(RefreshProject.class,": <LATEST> innerDql : "+innerDql,null,null);
				IDfCollection innerColl = IdocsUtil.executeQuery(dfSession, innerDql, IDfQuery.DF_READ_QUERY);
				while (innerColl.next()){
					wfPerformer = innerColl.getString(USER_NAME);
					if(wfPerformer!=null && wfPerformer.trim().length() >0){
						lst_Idesk_Group_Members.add(wfPerformer.trim());
						DfLogger.info(RefreshProject.class,": "+wfPerformer+" added to group ::::"+wfPerformer.trim(),null,null);
					}else{
						DfLogger.info(RefreshProject.class,"assignActPerformer() :No performer present for the "+role+" ",null,null);
					}
				}
				if (innerColl!=null)innerColl.close();
				// Extracting the Ldap groups present in a role
				String LdapGrpInRoleQry=IDOCS_PROJ_TEAM_LDAP_CHK_QRY;
				LdapGrpInRoleQry = LdapGrpInRoleQry.replaceFirst(QRY_VARIABLE_DQ, QRY_VARIABLE_SQ+strProjectID+QRY_VARIABLE_SQ);
				LdapGrpInRoleQry = LdapGrpInRoleQry.replaceFirst(QRY_VARIABLE_DQ, QRY_VARIABLE_SQ+role+QRY_VARIABLE_SQ);
				IDfCollection LdapGrpInRoleColl = IdocsUtil.executeQuery(dfSession, LdapGrpInRoleQry, IDfQuery.DF_READ_QUERY);

				while(LdapGrpInRoleColl.next()){
					//Add ldap group members to the performer group
					//Fetching group members of the corresponding group from the table,  idocs_ldap_group_membership
					//Determining work environment
					DfLogger.info(RefreshProject.class,": <LATEST> LdapGrpInRoleQry : "+LdapGrpInRoleQry,null,null);
					String LdapGrpInRole = LdapGrpInRoleColl.getString(PROJ_TEAM_MEMBER_NAME);
					if(LdapGrpInRole.contains(HASH))
						LdapGrpInRole = LdapGrpInRole.replace(HASH,workEnv);
					DfLogger.info( RefreshProject.class,": Ldap Group in Role : " + LdapGrpInRole,null,null);
					String LdapInnerQry = IDOCS_LDAP_GROUP_QRY;
					LdapInnerQry = LdapInnerQry.replaceFirst(QRY_VARIABLE_DQ, QRY_VARIABLE_SQ+LdapGrpInRole+QRY_VARIABLE_SQ);
					DfLogger.info(RefreshProject.class,": <ldap> LdapInnerQry : "+LdapInnerQry,null,null);
					IDfCollection innerLdapColl = IdocsUtil.executeQuery(dfSession, LdapInnerQry, IDfQuery.DF_READ_QUERY);
					while (innerLdapColl.next()){
						wfPerformer = innerLdapColl.getString(USER_NAME);
						//Adding member to the group
						if(wfPerformer!=null && wfPerformer.trim().length() >0){
							lst_Idesk_Group_Members.add(wfPerformer.trim());
							DfLogger.info(RefreshProject.class,": "+wfPerformer+" added to group",null,null);
						}else{
							DfLogger.info(RefreshProject.class,"assignActPerformer() :No performer present for the "+LdapGrpInRole+" ",null,null);
						}
					}

					if (innerLdapColl!=null)innerLdapColl.close();
				}
				if (LdapGrpInRoleColl!=null)LdapGrpInRoleColl.close();
			} else if (roleType.equals(WORKFLOW_SUPERVISOR)) {
				//Adding Workflow Supervisor  to the group
				IDfWorkflow workflow= (IDfWorkflow)dfSession.getObject(new DfId(strWorkflowId));
				String SupervisorName= workflow.getSupervisorName();
				lst_Idesk_Group_Members.add(SupervisorName.trim());
				DfLogger.info(RefreshProject.class,":ADDing Workflow supervisor:: "+SupervisorName.trim(),null,null);
			}else{
				//Add ldap group members to the performer group
				//Fetching group members of the corresponding group from the table,  idocs_ldap_group_membership
				//Determining work environment
				if(role.contains(HASH))
					role = role.replace(HASH,workEnv);
				DfLogger.info( RefreshProject.class,": role : "+role,null,null);
				String innerDql = IDOCS_LDAP_GROUP_QRY;
				innerDql = innerDql.replaceFirst(QRY_VARIABLE_DQ, QRY_VARIABLE_SQ+role+QRY_VARIABLE_SQ);
				DfLogger.info(RefreshProject.class,": <ldap> innerDql : "+innerDql,null,null);
				IDfCollection innerColl = IdocsUtil.executeQuery(dfSession, innerDql, IDfQuery.DF_READ_QUERY);
				while (innerColl.next()){
					wfPerformer = innerColl.getString(USER_NAME);
					//Adding member to the group
					if(wfPerformer.length()>32){
						wfPerformer=wfPerformer.substring(0,32);
					}
					lst_Idesk_Group_Members.add(wfPerformer.trim());
					DfLogger.info(RefreshProject.class,": "+wfPerformer+" added to group",null,null);
				}
				if (innerColl!=null)innerColl.close();
				// Added members to the group
			}
		} // end of while()
		if (dfCollection!=null)dfCollection.close();
		return lst_Idesk_Group_Members;
	}
	
	/**
	 * addZeros() - This method is to append extra zeros to the UPI ID
	 * 
	 * @param projectTeamMemberId
	 * @return String
	 */
	protected static String addZeros(String projectTeamMemberId) {
		StringBuffer zeroCount = new StringBuffer(BLANK_STRING);
		for(int i=0; i< (9 - (projectTeamMemberId.length())); i++){
			zeroCount.append(STRING_ZERO);
		}
		zeroCount.append(projectTeamMemberId);
		return zeroCount.toString();
	}
	
	public static void printMap(HashMap<String , String> finalMessageMap) {
		 Iterator<Entry<String, String>> iterator = finalMessageMap.entrySet().iterator();
		 DfLogger.debug(RefreshPerformerUtility.class,"###############################################################",null,null);
  	 while (iterator.hasNext()) { 
  		 Map.Entry<String,String> entry = iterator.next();
	         DfLogger.debug(RefreshPerformerUtility.class,(String)entry.getKey() +" : " + (String)entry.getValue(),null,null);
  	 }		
	}
	
	public static void printMapArray(HashMap<String , ArrayList<String>> finalMessageMap) {
		 Iterator<Entry<String, ArrayList<String>>> iterator = finalMessageMap.entrySet().iterator();
		 DfLogger.debug(RefreshPerformerUtility.class,"###############################################################",null,null);
 	 while (iterator.hasNext()) { 
 		 Map.Entry<String, ArrayList<String>> entry = iterator.next();
	         DfLogger.debug(RefreshPerformerUtility.class,(String)entry.getKey() +" : " + entry.getValue(),null,null);
 	 }		
	}
	/**
	 * 
	 * @param performerGrpName
	 * @return
	 */
	private static List<String> getRoleCode(String performerGrpName) {
		StringTokenizer strTokenizer = new StringTokenizer(performerGrpName,STRING_MSG_HIPHEN);
		List<String> tokenList = new ArrayList<String>();
		while (strTokenizer.hasMoreTokens()) {
			String token = strTokenizer.nextToken();
			tokenList.add(token);
		}
		return tokenList;
	}
	
	/**
	 * 
	 * @param strActivityName
	 * @return
	 */
	private static boolean checkIsGpsTask(String strActivityName) {
		if(strActivityName.equalsIgnoreCase(GPS_TASK)){
			return true;
		}else{
			return false;
		}		
	}

	protected static ArrayList<String> getGroupMembersAsList(IDfSession dfSession,String performerGroupName) throws DfException {
		ArrayList<String> groupMembersList = new ArrayList<String>();
		String QRY_GET_ALL_MEMBERSOF_GROUP = GET_ALL_MEMBERSOF_GROUP.replace(QRY_VARIABLE_GROUP_NAME, performerGroupName);
		IDfCollection collection = IdocsUtil.executeQuery(dfSession, QRY_GET_ALL_MEMBERSOF_GROUP, IDfQuery.DF_READ_QUERY);
		while (collection.next()) {
			String userName = collection.getString("i_all_users_names");
			if(userName != null && userName.trim().length() > 0){
				groupMembersList.add(userName);
			}
		}
		if (collection != null) collection.close();
		return groupMembersList;
	}
	
	/**
	 * updateDocSecurity-Grants write permission on the document to the task performers of a workflow
	 * 
	 * @param document
	 * @param performerGroup
	 * @param dfSession
	 * @throws IOException 
	 */
	public static boolean updateDocSecurity(String documentObjectId,IDfGroup performerGroup,IDfSession adminSession) throws IOException {
		boolean canRefresh=true;
		try {
			DfLogger.info(RefreshProject.class,": Updating doc security",null, null);
			int memberCount = performerGroup.getAllUsersNamesCount();
			int memberGroupCount = performerGroup.getGroupsNamesCount();
			ArrayList<String> permissionReqdUsersList = new ArrayList<String>();
			String currentAclName=null;
			String docLockOwner=null;
			String strQry = IdocsUtil.getMessage(REFRESH_QRY_GET_DOC_DETAILS);
			strQry = strQry.replaceFirst(STR_REPLACE_OBJECT, (IdocsConstants.MSG_QUOTES + documentObjectId + IdocsConstants.MSG_QUOTES));
			IDfCollection docCollection = IdocsUtil.executeQuery(adminSession,strQry, IDfQuery.DF_READ_QUERY);
			while (docCollection.next()) {
				currentAclName= docCollection.getString(ACL_NAME);
				docLockOwner= docCollection.getString(R_LOCK_OWNER);
			}
			if(docCollection!=null){docCollection.close();}
			
			DfLogger.info(RefreshProject.class, ":updateDocSecurity():Document lock owner" + " : "+ docLockOwner, null, null);
			DfLogger.info(RefreshProject.class, ":updateDocSecurity():number of users" + " : "+ memberCount, null, null);
			DfLogger.info(RefreshProject.class, ":updateDocSecurity():number of " + " : "+ memberGroupCount, null, null);
			
			IDfACL computedAcl = null;
			IDfACL currentAcl = null;
			String objectIdAclName = new StringBuilder().append(MSG_IDOC_ACL_PREFIX).append(documentObjectId).append(MSG_IDOC_ACL_SUFFIX).toString();
			DfLogger.info(RefreshProject.class, ":updateDocSecurity(): current acl name : "+ currentAclName, null, null);
			currentAcl=(IDfACL) adminSession.getObjectByQualification("dm_acl where object_name='"+ currentAclName + "'");
			if (currentAcl != null) {
				DfLogger.info(RefreshProject.class, "Checking write permissions for users", null, null);
				for (int i = 0; i < memberCount; i++) {
					if((currentAcl.hasPermission(IDfACL.DF_PERMIT_WRITE_STR,performerGroup.getAllUsersNames(i)))==false){
						permissionReqdUsersList.add(performerGroup.getAllUsersNames(i).toString());
							DfLogger.info(RefreshProject.class, ":updateDocSecurity(): New acl to be created for user", null, null);
					}
				}
			}
		
			DfLogger.info(RefreshProject.class, " :updateDocSecurity() :ObjectId Acl is" + ": " + objectIdAclName, null, null);
			if(permissionReqdUsersList.size()>0){
				DfLogger.info(RefreshProject.class, ":updateDocSecurity(): Computing new acl " , null, null);
				if (currentAclName.equals(objectIdAclName) == true) {
					// Applied ACL is Object Id ACL. So Add new user permissions to this ACL
					computedAcl = currentAcl;
				} else if (docLockOwner == null || !(docLockOwner.trim().length() > 0)) {
					if (currentAclName.startsWith("dm_45") == true) {
						// Applied ACL starts with dm_45 so Rename it to object_id ACL and add the performers
						computedAcl = copyToNewACL(adminSession,objectIdAclName, currentAclName,MSG_DESTROY_ACL, documentObjectId);
					} else if (currentAclName.startsWith("idocs_proj_")|| currentAclName.startsWith("idocs_inst_")|| currentAclName.startsWith("idocs_cntry_") == true) {
						// Applied ACL is Project/Institution/Country ACL so create a objectId ACL and add permissions
						computedAcl = copyToNewACL(adminSession,objectIdAclName, currentAclName,MSG_DONOT_DESTROY_ACL, documentObjectId);
					} else {
						// Applied ACL is something else eg: previous versions objectId ACL. Create ObjectID ACL for this version and add performers
						computedAcl = copyToNewACL(adminSession,objectIdAclName, currentAclName,MSG_DONOT_DESTROY_ACL, documentObjectId);
					}
				}
				else{
					DfLogger.info(RefreshProject.class, ":updateDocSecurity(): Cannot update acl as document is checked out " , null, null);
					canRefresh=false;
				}
			}
			if (computedAcl != null) {
				DfLogger.info(RefreshProject.class, ":updateDocSecurity(): granting write permission to user " , null, null);
				for (int i = 0; i < permissionReqdUsersList.size(); i++) {
					computedAcl.grant(permissionReqdUsersList.get(i),IDfACL.DF_PERMIT_WRITE, null);
					DfLogger.info(RefreshProject.class, ":updateDocSecurity():ADD USER" + ": "+ permissionReqdUsersList.get(i)+" "+"to the ACL", null, null);
				}
				/** Save ACL */
				computedAcl.save();
				DfLogger.info(RefreshProject.class, ":updateDocSecurity() :computed acl "+ ": " + computedAcl.getObjectName(), null, null);
				/** Update the Document with new ACL and save the Document. */
				if (currentAclName.equals(objectIdAclName) == false){
					String strDql = "update idocs_document object set acl_name='"+objectIdAclName+"' where r_object_id='"+documentObjectId.toString()+"'";
					DfLogger.info(RefreshProject.class, ":updateDocSecurity() : Query for updating ACL : " + strDql, null, null);
					IDfCollection dfCollection = IdocsUtil.executeQuery(adminSession, strDql, IDfQuery.DF_EXEC_QUERY);
					if (dfCollection.next()){dfCollection.close();}
				}
			}
		} catch (DfException e) {
			e.printStackTrace();
		}
		return canRefresh;
	}
	
	/**
	 * copyToNewACL-copies the permission from the current acl to new acl(Object_ID acl)
	 * @param dfSession
	 * @param newName
	 * @param oldAclName
	 * @param destroyOldAcl
	 * @param document
	 * @return Object_ID ACL
	 * @throws DfException
	 * @throws IOException 
	 */
	protected static IDfACL copyToNewACL(IDfSession adminSession, String newName, String oldAclName, boolean destroyOldAcl, String documentObjectId) throws DfException, IOException {
		IDfACL oldAcl = (IDfACL) adminSession.getObjectByQualification("dm_acl where object_name='"+ oldAclName + "'");
		DfLogger.info(RefreshProject.class, ":copyToNewACL() : oldAcl is" + ": "+ oldAcl.getObjectName(), null, null);
		if (oldAcl == null) {
			return null;
		}
		IDfACL objectIdAcl = (IDfACL) adminSession.getObjectByQualification("dm_acl where object_name='"+ newName + "'");
		if (objectIdAcl == null) {
			objectIdAcl = (IDfACL) adminSession.newObject("dm_acl");
			/** Grant all permissions from the parent ACL */
			IDfList permitList = oldAcl.getPermissions();
			for (int i = 0; i < permitList.getCount(); i++) {
			IDfPermit dfPermit = (IDfPermit)permitList.get(i);
			if(dfPermit!=null)objectIdAcl.grantPermit(dfPermit);
			} 
			objectIdAcl.setObjectName(newName);
			objectIdAcl.setDomain(MSG_ACL_DOMAIN);
			objectIdAcl.setACLClass(3);
			objectIdAcl.save();
		} else {
			reInitialiseAcl(objectIdAcl);
			IDfACL secClassACL=secClassificationACL(adminSession,documentObjectId);
			
			/** Grant all permissions from the parent ACL */
			IDfList permitList = secClassACL.getPermissions();
			for (int i = 0; i < permitList.getCount(); i++) {
			IDfPermit dfPermit = (IDfPermit)permitList.get(i);
			if(dfPermit!=null)objectIdAcl.grantPermit(dfPermit);
			} 
		}
		DfLogger.info(RefreshProject.class, ":copyTonewAcl() : NewAcl is" + ": "+ objectIdAcl.getObjectName(), null, null);
		if (objectIdAcl != null && destroyOldAcl) {
			oldAcl.destroy();
			DfLogger.info(RefreshProject.class, ":copyTonewAcl() : old acl destroyed is" + ": "+ oldAcl.getObjectName(), null, null);
		}
		return objectIdAcl;
	}
	
	/**
	 *secClassificationACL-builds the Security classification ACL using the classification code and project_id/institution_nbr/country_code
	 * @param dfSession
	 * @param docObjID
	 * @return Security Classification acl
	 * @throws IOException 
	 */
	protected static IDfACL secClassificationACL(IDfSession adminSession,String docObjID) throws IOException{
		IDfACL secClassACL=null;
		try{
			String strQry = IdocsUtil.getMessage("REFRESH_PROJ_DOC_QRY");
			strQry = strQry.replaceFirst("''", "'" + docObjID + "'");
			DfLogger.info(RefreshProject.class,": updateWordDocWithWfLog : strQry : " + strQry,null, null);
			IDfCollection collection = IdocsUtil.executeQuery(adminSession,strQry, IDfQuery.DF_READ_QUERY);
			String secClassCode = null;
			String aclPrefix=null;
			String secClassTypeCode=null;
			if (collection.next()) {
				secClassCode = collection.getString(ATTR_SECURITY_CLASS_CODE);
				DfLogger.info(RefreshProject.class,": secClassificationACL() :  Security_classification code "+ " : "+ secClassCode, null, null);
				String docType=collection.getString(ATTR_OBJECT_TYPE);
				//If the document is an project document
				if(docType.equals(PROJ_OBJECT_TYPE)){
					String strProjectQry = IdocsUtil.getMessage("QRY_IDOCS_PROJECT_OBJECT_ID");
					strProjectQry = strProjectQry.replaceFirst("''", "'" + docObjID + "'");
					IDfCollection projcollection = IdocsUtil.executeQuery(adminSession,strProjectQry, IDfQuery.DF_READ_QUERY);
					while(projcollection.next()) {
						secClassTypeCode = projcollection.getString(ATTR_PROJECT_ID);
						DfLogger.info(RefreshProject.class,": secClassificationACL() :  Project ID "+ " : " + secClassTypeCode,null, null);
					}
					if(projcollection!=null){projcollection.close();}
					aclPrefix=PRJT_ACL_PREFIX;
					//If the document is an institution document
				}else if(docType.equals(INST_OBJECT_TYPE)){
					String strInstQry = IdocsUtil.getMessage("QRY_IDOCS_INSTITUTION_OBJECT_ID");
					strInstQry = strInstQry.replaceFirst("''", "'" + docObjID + "'");
					IDfCollection instcollection = IdocsUtil.executeQuery(adminSession,strInstQry, IDfQuery.DF_READ_QUERY);
					while (instcollection.next()) {
						secClassTypeCode = instcollection.getString(ATTR_INSTITUTION_NBR);
						DfLogger.info(RefreshProject.class,": secClassificationACL() :  INSTITUTION NBR "+ " : " +secClassTypeCode ,null, null);
					}
					if(instcollection!=null){instcollection.close();}
					aclPrefix=INST_ACL_PREFIX;
					//If the document is an country document
				}else{
					String strCountryQry = IdocsUtil.getMessage("QRY_IDOCS_COUNTRY_OBJECT_ID");
					strCountryQry = strCountryQry.replaceFirst("''", "'" + docObjID + "'");
					IDfCollection countrycollection = IdocsUtil.executeQuery(adminSession,strCountryQry, IDfQuery.DF_READ_QUERY);
					while (countrycollection.next()) {
						secClassTypeCode = countrycollection.getString(ATTR_COUNTRY_CODE);
						DfLogger.info(RefreshProject.class,": secClassificationACL() :  COUNTRY CODE "+ " : " +secClassTypeCode ,null, null);
					}
					if(countrycollection!=null){countrycollection.close();}
					aclPrefix=CNTRY_ACL_PREFIX;
				}
			}//end if for collection execution
			StringBuilder secClassAclName = new StringBuilder().append(aclPrefix+"_").append(secClassTypeCode+"_").append(secClassCode+"_").append("acl");
			secClassACL = (IDfACL) adminSession.getObjectByQualification("dm_acl where object_name='"+ secClassAclName+ "'");
			DfLogger.info(RefreshProject.class,": secClassificationACL() : secClassACL Object Name " + secClassACL.getObjectName(),null, null);
		} catch (DfException e) {
			e.printStackTrace();
			DfLogger.info(RefreshProject.class, " :: secClassificationACL() : Exception :: "
					+ e.getMessage(), null, null);
		}
		return secClassACL;
	}
	
	
	/**
	 * reInitialiseAcl-Revokes all the permissions from object_ID acl 
	 * @param securityAcl
	 * @return Object_ID acl
	 */
	protected static IDfACL reInitialiseAcl(IDfACL securityAcl) {
		try {
			DfLogger.info(RefreshProject.class, " :: reInitialiseAcl()", null, null);
			/** Revoke all permissions from the parent ACL */
			IDfList permitList = securityAcl.getPermissions();
			for (int i = 0; i < permitList.getCount(); i++) {
				IDfPermit dfPermit = (IDfPermit)permitList.get(i);
				if(dfPermit!=null){
					securityAcl.revokePermit(dfPermit);
					DfLogger.info(RefreshProject.class, ":reInitialiseAcl() : Revoke : "+ dfPermit.getAccessorName(), null, null);
				}
			} 
			securityAcl.save();
			DfLogger.info(RefreshProject.class, " :: reInitialiseAcl() : Done for "+ securityAcl.getObjectName(), null, null);
		} catch (DfException e) {
			e.printStackTrace();
			DfLogger.info(RefreshProject.class, " :: reInitialiseAcl() : Exception :: "+ e.getMessage(), null, null);
		}
		return securityAcl;
	}
	
	private static final String STR_REPLACE_OBJECT="'<objectId>'";
	protected static final String HASH = "#";
	protected static final String ROLE = "role";
	protected static final String USER_ROLE = "U";
	protected static final String STRING_ZERO = "0";
	protected static final String BLANK_STRING = "";
	protected static final String STRING_Q_COMMA = "',";
	protected static final String LDAP_GROUP_ROLE = "G"; //Value of role_type column for ldap groups
	protected static final String STRING_UNDERSCORE = "_";
	protected static final String ROLE_TYPE = "role_type";
	protected static final String USER_NAME = "user_name";
	protected static final String PROJECT_ID = "project_id";
	protected static final String R_OBJECT_ID = "r_object_id";
	protected static final String OBJECT_NAME = "object_name";
	protected static final String ATTR_PROJECT_ID = "project_id";
	protected static final String R_ACTIVITY_NAME = "activity_name";
	protected static final String ATTR_COUNTRY_CODE = "country_code";
	protected static final String ATTR_OBJECT_TYPE = "r_object_type";
	protected static final String STRING_MSG_HIPHEN = STRING_UNDERSCORE;
	protected static final String PROJ_TEAM_MEMBER_NAME = "accessor_nme";
	protected static final String IDOCS_PROJECT_DOC = "idocs_project_doc";
	protected static final String ATTR_SECURITY_CLASS_CODE = "sec_classification_code";
	private static final String ACL_NAME = "acl_name";
	
	protected static final String ROLE_EXCLUDED = "E";
	protected static final boolean MSG_DESTROY_ACL=true;
	protected static final String MSG_ACL_DOMAIN="dm_dbo";
	protected static final String GPS_TASK = "GPS Approval";
	protected static final String WORKFLOW_SUPERVISOR = "W";
	protected static final String MSG_IDOC_ACL_SUFFIX="_acl";
	protected static final String PRJT_ACL_PREFIX="idocs_proj";
	protected static final String INST_ACL_PREFIX="idocs_inst";
	protected static final boolean MSG_DONOT_DESTROY_ACL=false;
	protected static final String MSG_IDOC_ACL_PREFIX="idocs_";
	protected static final String CNTRY_ACL_PREFIX="idocs_cntry";
	protected static final String SUB_WORKFLOW = "Sub Workflow";
	protected static final String PROJ_OBJECT_TYPE="idocs_project_doc";
	protected static final String CNTRY_OBJECT_TYPE="idocs_country_doc";
	protected static final String ATTR_INSTITUTION_NBR="institution_nbr";
	protected static final String INST_OBJECT_TYPE="idocs_institution_doc";
	protected static final String PROJECT_TEAM_MEMBER_ID = "project_team_member_id";
	
	protected static final String STR_QUOTES = "'";
	protected static final String QRY_VARIABLE_DQ = "''";
	protected static final String QRY_VARIABLE_MOD_Q = "%'";
	protected static final String QRY_VARIABLE_SQ = STR_QUOTES;
	protected static final String QRY_VARIABLE_UPI_ID = "%upi_id%";
	protected static final String QRY_VARIABLE_OBJECT_ID = "<ObjectID>";
	protected static final String QRY_VARIABLE_GROUP_NAME = "<GroupName>";
	protected static final String QRY_VARIABLE_WORKFLOW_ID = "<WorkflowID>";
	protected static final String QRY_VARIABLE_PROJECT_ID_MOD = "%projectId%";
	protected static final String QRY_VARIABLE_STR_PROCESS_NAME = "<strProcessName>";
	protected static final String QRY_VARIABLE_STR_ACTIVITY_NAME = "<strActivityName>";
	protected static final String QRY_VARIABLE_STAFF_FUNCTION_CODE = "%staffFunctionCode%";
	
	protected static final String REFRESH_AS_PROJ_TEAM_QRY = "REFRESH_AS_PROJ_TEAM_QRY";
	protected static final String REFRESH_GET_WORKFLOW_ID = "REFRESH_GET_WORKFLOW_ID_NEW";
	protected static final String REFRESH_GET_USER_NAME_QRY = "REFRESH_GET_USER_NAME_QRY";
	protected static final String REFRESH_IS_REFRESH_REQUIRED = "REFRESH_IS_REFRESH_REQUIRED";
	protected static final String REFRESH_GET_ALL_MEMBERSOF_GROUP = "GET_ALL_MEMBERSOF_GROUP";
	protected static final String REFRESH_IDOCS_PROJ_TEAM_QRY = "REFRESH_IDOCS_PROJ_TEAM_QRY";
	protected static final String REFRESH_GET_WORKITEM_FR_WF = "REFRESH_GET_WORKITEM_FR_WF_NEW";
	protected static final String REFRESH_IDOCS_LDAP_GROUP_QRY = "REFRESH_IDOCS_LDAP_GROUP_QRY";
	protected static final String REFRESH_GET_PROJECT_TEAM_MEM_ID = "REFRESH_GET_PROJECT_TEAM_MEM_ID";
	protected static final String REFRESH_GET_IDESK_PERFORMERS_FR_WF = "REFRESH_GET_IDESK_PERFORMERS_FR_WF";
	protected static final String REFRESH_IDOCS_PROJ_TEAM_LDAP_CHK_QRY = "REFRESH_IDOCS_PROJ_TEAM_LDAP_CHK_QRY";
	
	protected static String GET_WORKFLOW_ID = IdocsUtil.getMessage(REFRESH_GET_WORKFLOW_ID);
	protected static String AS_PROJ_TEAM_QRY = IdocsUtil.getMessage(REFRESH_AS_PROJ_TEAM_QRY);
	protected static String GET_USER_NAME_QRY = IdocsUtil.getMessage(REFRESH_GET_USER_NAME_QRY);
	protected static String GET_WORKITEM_FR_WF = IdocsUtil.getMessage(REFRESH_GET_WORKITEM_FR_WF);
	protected static String IDOCS_PROJ_TEAM_QRY = IdocsUtil.getMessage(REFRESH_IDOCS_PROJ_TEAM_QRY);
	protected static String IS_REFRESH_REQUIRED = IdocsUtil.getMessage(REFRESH_IS_REFRESH_REQUIRED);
	protected static String GET_ALL_MEMBERSOF_GROUP = IdocsUtil.getMessage(REFRESH_GET_ALL_MEMBERSOF_GROUP);
	protected static String IDOCS_LDAP_GROUP_QRY = IdocsUtil.getMessage(REFRESH_IDOCS_LDAP_GROUP_QRY);
	protected static String GET_PROJECT_TEAM_MEM_ID = IdocsUtil.getMessage(REFRESH_GET_PROJECT_TEAM_MEM_ID);
	protected static String GET_IDESK_PERFORMERS_FR_WF = IdocsUtil.getMessage(REFRESH_GET_IDESK_PERFORMERS_FR_WF);
	protected static String IDOCS_PROJ_TEAM_LDAP_CHK_QRY = IdocsUtil.getMessage(REFRESH_IDOCS_PROJ_TEAM_LDAP_CHK_QRY);
	
}
