package com.SWBC.model;

import java.util.Date;

public class Brm_log_info {
	
	private String id;
	private String transaction_id;
	private String transaction_type;
	private String input_parameters;
	private String rule_name;
	private String rule_outcome;
	private String rule_outcome_msg;
	private String rule_processor_id;
	
	private String loan_account_no;
	private String loan_no;
	private String loan_no_suffix;
	
	private Date rec_created_on;
	private Date rec_modified_on;
	private String cov_type;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}
	public String getTransaction_type() {
		return transaction_type;
	}
	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}
	public String getInput_parameters() {
		return input_parameters;
	}
	public void setInput_parameters(String input_parameters) {
		this.input_parameters = input_parameters;
	}
	public String getRule_name() {
		return rule_name;
	}
	public void setRule_name(String rule_name) {
		this.rule_name = rule_name;
	}
	public String getRule_outcome() {
		return rule_outcome;
	}
	public void setRule_outcome(String rule_outcome) {
		this.rule_outcome = rule_outcome;
	}
	public String getRule_outcome_msg() {
		return rule_outcome_msg;
	}
	public void setRule_outcome_msg(String rule_outcome_msg) {
		this.rule_outcome_msg = rule_outcome_msg;
	}
	public String getRule_processor_id() {
		return rule_processor_id;
	}
	public void setRule_processor_id(String rule_processor_id) {
		this.rule_processor_id = rule_processor_id;
	}
	public Date getRec_created_on() {
		return rec_created_on;
	}
	public void setRec_created_on(Date rec_created_on) {
		this.rec_created_on = rec_created_on;
	}
	public Date getRec_modified_on() {
		return rec_modified_on;
	}
	public void setRec_modified_on(Date rec_modified_on) {
		this.rec_modified_on = rec_modified_on;
	}
	public String getCov_type() {
		return cov_type;
	}
	public void setCov_type(String cov_type) {
		this.cov_type = cov_type;
	}
	public String getLoan_account_no() {
		return loan_account_no;
	}
	public void setLoan_account_no(String loan_account_no) {
		this.loan_account_no = loan_account_no;
	}
	public String getLoan_no() {
		return loan_no;
	}
	public void setLoan_no(String loan_no) {
		this.loan_no = loan_no;
	}
	public String getLoan_no_suffix() {
		return loan_no_suffix;
	}
	public void setLoan_no_suffix(String loan_no_suffix) {
		this.loan_no_suffix = loan_no_suffix;
	}
	

}
