package com.SWBC.model;

import java.util.Date;

public class Brm_PreProc {
	
	private	String	EM_FILE_NUMBER;
	private	String	EM_SERVICE_BUREAU;
	private	String	EM_POLICY_NO;
	private	String	EM_POL_TYPE;
	private	String	EM_INSURER;
	private	String	EM_LOAN_NO;
	private	String	EM_MORTGAGE_COMPANY;
	private	String	EM_MORT_ADDR;
	private	String	EM_MORT_CITY;
	private	String	EM_MORT_STATE;
	private	String	EM_SERVICING_AGENT;
	private	String	EM_AGENT_NO;
	private	String	EM_AGENT_ADDR;
	private	String	EM_AGENT_CITY;
	private	String	EM_AGENT_STATE;
	private	String	EM_INSURED_NAME;
	private	String	EM_PROP_ADDR;
	private	String	EM_PROP_ADDR_1;
	private	String	EM_PROP_CITY;
	private	String	EM_PROP_STATE;
	private	String	EM_TRAN_CODE;
	private	String	EM_OPERATOR_ID;
	private	String	EM_TRANS_SETID;
	private	String	EM_TRANS_NO;
	private	String	EM_INS_BANK_ROUTING;
	private	String	EM_INS_BANK_ACCT;
	private	String	EM_INS_CRED_REF;
	private	String	EM_FILE_TRNS;
	private	String	EM_POL_TRAN_CODE;
	private	String	EM_POL_CXL_RSN;
	private	String	EM_POL_PAID_BY;
	private	String	EM_NAIC;
	private	String	EM_INSCO_OCN;
	private	String	EM_POLICY_FORM;
	private	String	EM_NBR_MTGS;
	private	String	EM_MAIL_ADDR;
	private	String	EM_MAIL_CITY;
	private	String	EM_MAIL_STATE;
	private	String	EM_CRDB_FLAG;
	private	String	EM_COV_TYPE;
	private	String	EM_INSUR_TYPE;
	private	String	EM_DOC_NO;
	private	String	EM_COMMENT;
	private	String	EM_820_SENT_INV;
	private	String	EM_820_SENT_CODE;
	private	String	EM_FLOOD_MAP_REF;
	private	String	EM_FLOOD_MAP_NO;
	private	String	EM_FLOOD_ZONE;
	private	String	EM_NFIP_COMMUNITY_NAME;
	private	String	EM_NFIP_COUNTY;
	private	String	EM_NFIP_MAP_NO;
	private	String	EM_NFIP_STATE;
	private	String	EM_NO_CONDOS;
	private	String	EM_PAYEE_CD;
	private	String	EM_TIF_NO;
	private	String	EM_INS_CO_ADDR1;
	private	String	EM_INS_CO_ADDR2;
	private	String	EM_INS_CO_CITY;
	private	String	EM_INS_CO_STATE;
	private	String	EM_NON_TRACKING_FLG;
	private	String	EM_REPLACE_COST_IND;
	private	String	EM_EXCL_EARTHQUAKE;
	private	String	EM_EXCL_WIND_HURRICANE;
	private	String	EM_IMPAIR_CD;
	private	String	EM_SPARE_FL_1;
	private	String	EM_SPARE_FL_2;
	private	String	EM_SPARE_FL_3;
	private	String	EM_SPARE_FL_4;
	private	String	EMFLAG5;
	private	String	EMFLAG6;
	private	String	EMFLAG7;
	private	String	EMFLAG8;
	private	String	EMFLAG9;
	private	String	EMFLAG10;
	private	String	EM_SPARE_CODE_1;
	private	String	EMCODE2;
	private	String	EMCODE3;
	private	String	EMCODE4;
	private	String	EMCODE5;
	private	String	EMCODE6;
	private	String	EMCODE7;
	private	String	EMCODE8;
	private	String	EMCODE9;
	private	String	EMCODE10;
	private	String	EMSPRFLD;
	private	String	EM_ADDTNS;
	private	String	EM_ADD02;
	private	String	EM_ADD03;
	private	String	EM_ADD04;
	private	String	EM_ADD05;
	private	String	EM_ADD06;
	private	String	EM_ADD07;
	private	String	EM_ADD08;
	private	String	EM_ADD09;
	private	String	EM_ADD10;
	private	String	EM_ADD30;
	private	String	EM_ADD31;
	private	String	EM_ADD32;
	private	String	EM_ADD33;
	private	String	EM_ADD34;
	private	String	EM_ADD35;
	private	String	EM_ADD36;
	private	String	EM_ADD37;
	private	String	EM_ADD90;
	private	String	EM_ADD91;
	private	String	EM_ADD97;
	private	String	EM_ADD98;
	private	String	EM_ADD99;
	private	String	EM_PROCESS_FLAG;
	private	String	EM_PROCESS_ERROR_STATUS;
	private	String	EM_REC_ID;
	private	String	EM_PARENT_ID;
	private	String	EM_LEVEL_CD;
	private	String	EM_CHILD_CD;
	private	Date	rec_created_on;
	private	Date	rec_modified_on;
	private	Date	doc_received_date;
	private	Date	policy_effective_date;
	private	Date	reinstatement_date;
	private	Date	doc_notice_date;
	private	Date	doc_delivery_date;
	private	Date	doc_notice_effective_date;
	private	Date	premium_due_date;
	private	Date	policy_cancel_date;
	private	Date	policy_expiration_date;
	private	Date	doc_issue_date;
	private	Date	as400_post_date;
	private	Date	follow_up_date;
	private	double	EM_TAXPAYER_ID;
	private	double	EM_MORTGAGE_NO;
	private	double	EM_FILE_PREM;
	private	double	EM_SPARE_DATE_1;
	private	double	EMDATE2;
	private	double	EMDATE3;
	private	double	EMDATE4;
	private	double	EMDATE5;
	private	double	EMDATE6;
	private	double	EMDATE7;
	private	double	EMDATE8;
	private	double	EMDATE9;
	private	double	EMDATE10;
	private	double	EMSPRAMT;
	private	double	EMSPRAM2;
	private	double	EMSPRAM3;
	private	double	EMSPRAM4;
	private	double	EMSPRAM5;
	private	double	EMSPRAM6;
	private	double	EMSPRAM7;
	private	double	EMSPRAM8;
	private	double	EMSPRAM9;
	private	double	EMSPRAM10;
	private	double	base_coverage_other_structs;
	private	double	deductible;
	private	double	coverage_amount;
	private	double	percent_deductible;
	private	double	policy_premium;
	private	double	percent_primary_coverage;
	private	double	additional_premium_amt;
	private	double	additional_coverage_amount;
	private	int	number_of_condos;
	private	int	batch_number;
	private	int	batch_seq_no;
	private	double	EM_ACCOUNT_NO;
	private	double	EM_MCB_DATE;
	private	double	EM_FILE_DATE;
	private	double	EM_AGENCY_NO;
	private	double	EM_ACCT_TAX_ID;
	private	double	EM_LOAN_SUFFIX;
	private	double	EM_MORT_ZIP;
	private	double	EM_AGENT_ZIP;
	private	double	EM_AGENT_PHONE;
	private	double	EM_PROP_ZIP;
	private	double	EM_PROP_ZIP_4;
	private	double	EM_EFFECTIVE_DATE;
	private	double	EM_EXPIRATION_DATE;
	private	double	EM_POL_PROCESS_DATE;
	private	double	EM_POL_CHANGE_DATE;
	private	double	EM_DEDUCTIBLE;
	private	double	EM_PCT_PRIMARY_COV;
	private	double	EM_COV_AMT;
	private	double	EM_BASE_COV_OS;
	private	double	EM_BASE_COV_OS_PCT;
	private	double	EM_TRAN_DATE;
	private	double	EM_INSCO_TAXID;
	private	double	EM_MTG_TAX_ID;
	private	double	EM_POL_PREM;
	private	double	EM_POL_CANCEL_DATE;
	private	double	EM_POL_EXTEND_DATE;
	private	double	EM_POL_REINST_DATE;
	private	double	EM_MAIL_ZIP;
	private	double	EM_MAIL_ZIP_4;
	private	double	EM_NET_AMT;
	private	double	EM_TRANS_TOT;
	private	double	EM_SEQ;
	private	double	EM_DOC_DATE;
	private	double	EM_820_SENT_DATE;
	private	double	EM_NFIP_COMMUNITY_NO;
	private	double	EM_INS_CO_ZIP;
	private	double	EM_BASE_COV_AA;
	private	double	EM_BASE_COV_AA_PCT;
	private	double	EM_PREM_DUE_DATE;
	private	double	EM_BATCH_NO;
	private	double	EM_COG_DOC;
	private	double	EM_COG_SEQ;
	private	double	EM_VAR_COVERAGE;
	private	double	EM_VAR_DEDUCTIBLE;
	private	double	EM_VAR_COV_PCT1;
	private	double	EM_VAR_DED_PCT1;
	private	double	EM_VAR_COVERAGE02;
	private	double	EM_VAR_DEDUCT02;
	private	double	EM_VAR_COV_PCT02;
	private	double	EM_VAR_DED_PCT02;
	private	double	EM_VAR_COVERAGE03;
	private	double	EM_VAR_DEDUCT03;
	private	double	EM_VAR_COV_PCT03;
	private	double	EM_VAR_DED_PCT03;
	private	double	EM_VAR_COVERAGE04;
	private	double	EM_VAR_DEDUCT04;
	private	double	EM_VAR_COV_PCT04;
	private	double	EM_VAR_DED_PCT04;
	private	double	EM_VAR_COVERAGE05;
	private	double	EM_VAR_DEDUCT05;
	private	double	EM_VAR_COV_PCT05;
	private	double	EM_VAR_DED_PCT05;
	private	double	EM_VAR_COVERAGE06;
	private	double	EM_VAR_DEDUCT06;
	private	double	EM_VAR_COV_PCT06;
	private	double	EM_VAR_DED_PCT06;
	private	double	EM_VAR_COVERAGE07;
	private	double	EM_VAR_DEDUCT07;
	private	double	EM_VAR_COV_PCT07;
	private	double	EM_VAR_DED_PCT07;
	private	double	EM_VAR_COVERAGE08;
	private	double	EM_VAR_DEDUCT08;
	private	double	EM_VAR_COV_PCT08;
	private	double	EM_VAR_DED_PCT08;
	private	double	EM_VAR_COVERAGE09;
	private	double	EM_VAR_DEDUCT09;
	private	double	EM_VAR_COV_PCT09;
	private	double	EM_VAR_DED_PCT09;
	private	double	EM_VAR_COVERAGE10;
	private	double	EM_VAR_DEDUCT10;
	private	double	EM_VAR_COV_PCT10;
	private	double	EM_VAR_DED_PCT10;
	private	double	EM_VAR_COVERAGE30;
	private	double	EM_VAR_DEDUCT30;
	private	double	EM_VAR_COV_PCT30;
	private	double	EM_VAR_DED_PCT30;
	private	double	EM_VAR_COVERAGE31;
	private	double	EM_VAR_DEDUCT31;
	private	double	EM_VAR_COV_PCT31;
	private	double	EM_VAR_DED_PCT31;
	private	double	EM_VAR_COVERAGE32;
	private	double	EM_VAR_DEDUCT32;
	private	double	EM_VAR_COV_PCT32;
	private	double	EM_VAR_DED_PCT32;
	private	double	EM_VAR_COVERAGE33;
	private	double	EM_VAR_DEDUCT33;
	private	double	EM_VAR_COV_PCT33;
	private	double	EM_VAR_DED_PCT33;
	private	double	EM_VAR_COVERAGE34;
	private	double	EM_VAR_DEDUCT34;
	private	double	EM_VAR_COV_PCT34;
	private	double	EM_VAR_DED_PCT34;
	private	double	EM_VAR_COVERAGE35;
	private	double	EM_VAR_DEDUCT35;
	private	double	EM_VAR_COV_PCT35;
	private	double	EM_VAR_DED_PCT35;
	private	double	EM_VAR_COVERAGE36;
	private	double	EM_VAR_DEDUCT36;
	private	double	EM_VAR_COV_PCT36;
	private	double	EM_VAR_DED_PCT36;
	private	double	EM_VAR_COVERAGE37;
	private	double	EM_VAR_DEDUCT37;
	private	double	EM_VAR_COV_PCT37;
	private	double	EM_VAR_DED_PCT37;
	private	double	EM_VAR_COVERAGE90;
	private	double	EM_VAR_DEDUCT90;
	private	double	EM_VAR_COV_PCT90;
	private	double	EM_VAR_DED_PCT90;
	private	double	EM_VAR_COVERAGE91;
	private	double	EM_VAR_DEDUCT91;
	private	double	EM_VAR_COV_PCT91;
	private	double	EM_VAR_DED_PCT91;
	private	double	EM_VAR_COVERAGE97;
	private	double	EM_VAR_DEDUCT97;
	private	double	EM_VAR_COV_PCT97;
	private	double	EM_VAR_DED_PCT97;
	private	double	EM_VAR_COVERAGE98;
	private	double	EM_VAR_DEDUCT98;
	private	double	EM_VAR_COV_PCT98;
	private	double	EM_VAR_DED_PCT98;
	private	double	EM_VAR_COVERAGE99;
	private	double	EM_VAR_DEDUCT99;
	private	double	EM_VAR_COV_PCT99;
	private	double	EM_VAR_DED_PCT99;
	private	double	EM_PROCESS_DATE;
	private	double	EM_PROCESS_TIME;
	private	double	FMM080_RRN_FIELD_DATA;
	private	String	cov_type;
	private	String	transaction_type;
	private	String	policy_holder_name;
	private	String	agent_state;
	private	String	carrier_address_1;
	private	String	agent_address;
	private	String	loan_suffix;
	private	String	carrier_name;
	private	String	agent_phone;
	private	String	property_state;
	private	String	co_policy_holder_name;
	private	String	transaction_source;
	private	String	transaction_id;
	private	String	agent_zip;
	private	String	agent_name;
	private	String	impairment_code;
	private	String	agent_city;
	private	String	policy_number;
	private	String	property_city;
	private	String	payee_code;
	private	String	property_address_2;
	private	String	property_address_1;
	private	String	account_tax_id;
	private	String	account_number;
	private	String	escrow_indicator;
	private	String	agency_number;
	private	String	loan_number;
	private	String	property_zip;
	private	String	transaction_status;
	private	String	carrier_phone;
	private	String	mortgagee_state;
	private	String	mailing_zip;
	private	String	institution_code;
	private	String	carrier_state;
	private	String	mortgagee_address;
	private	String	carrier_city;
	private	String	mortgagee_city;
	private	String	policy_cancel_reason;
	private	String	mailing_city;
	private	String	mortgagee_name;
	private	String	mortgagee_zip;
	private	String	client_number;
	private	String	mailing_state;
	private	String	mailing_address;
	private	String	carrier_zip;
	private	String	qc_response_code;
	private	String	scan_id;
	private	String	orig_file_name;
	private	String	account_name;
	private	String	document_type;
	private	String	loan_type;
	private	String	is_qc_candidate;
	private	String	agent_email;
	private	String	follow_up_reason;
	private	String	document_sub_type;
	private	String	SRC_Agency;
	
	public String getEM_FILE_NUMBER() {
		return EM_FILE_NUMBER;
	}
	public void setEM_FILE_NUMBER(String eM_FILE_NUMBER) {
		EM_FILE_NUMBER = eM_FILE_NUMBER;
	}
	public String getEM_SERVICE_BUREAU() {
		return EM_SERVICE_BUREAU;
	}
	public void setEM_SERVICE_BUREAU(String eM_SERVICE_BUREAU) {
		EM_SERVICE_BUREAU = eM_SERVICE_BUREAU;
	}
	public String getEM_POLICY_NO() {
		return EM_POLICY_NO;
	}
	public void setEM_POLICY_NO(String eM_POLICY_NO) {
		EM_POLICY_NO = eM_POLICY_NO;
	}
	public String getEM_POL_TYPE() {
		return EM_POL_TYPE;
	}
	public void setEM_POL_TYPE(String eM_POL_TYPE) {
		EM_POL_TYPE = eM_POL_TYPE;
	}
	public String getEM_INSURER() {
		return EM_INSURER;
	}
	public void setEM_INSURER(String eM_INSURER) {
		EM_INSURER = eM_INSURER;
	}
	public String getEM_LOAN_NO() {
		return EM_LOAN_NO;
	}
	public void setEM_LOAN_NO(String eM_LOAN_NO) {
		EM_LOAN_NO = eM_LOAN_NO;
	}
	public String getEM_MORTGAGE_COMPANY() {
		return EM_MORTGAGE_COMPANY;
	}
	public void setEM_MORTGAGE_COMPANY(String eM_MORTGAGE_COMPANY) {
		EM_MORTGAGE_COMPANY = eM_MORTGAGE_COMPANY;
	}
	public String getEM_MORT_ADDR() {
		return EM_MORT_ADDR;
	}
	public void setEM_MORT_ADDR(String eM_MORT_ADDR) {
		EM_MORT_ADDR = eM_MORT_ADDR;
	}
	public String getEM_MORT_CITY() {
		return EM_MORT_CITY;
	}
	public void setEM_MORT_CITY(String eM_MORT_CITY) {
		EM_MORT_CITY = eM_MORT_CITY;
	}
	public String getEM_MORT_STATE() {
		return EM_MORT_STATE;
	}
	public void setEM_MORT_STATE(String eM_MORT_STATE) {
		EM_MORT_STATE = eM_MORT_STATE;
	}
	public String getEM_SERVICING_AGENT() {
		return EM_SERVICING_AGENT;
	}
	public void setEM_SERVICING_AGENT(String eM_SERVICING_AGENT) {
		EM_SERVICING_AGENT = eM_SERVICING_AGENT;
	}
	public String getEM_AGENT_NO() {
		return EM_AGENT_NO;
	}
	public void setEM_AGENT_NO(String eM_AGENT_NO) {
		EM_AGENT_NO = eM_AGENT_NO;
	}
	public String getEM_AGENT_ADDR() {
		return EM_AGENT_ADDR;
	}
	public void setEM_AGENT_ADDR(String eM_AGENT_ADDR) {
		EM_AGENT_ADDR = eM_AGENT_ADDR;
	}
	public String getEM_AGENT_CITY() {
		return EM_AGENT_CITY;
	}
	public void setEM_AGENT_CITY(String eM_AGENT_CITY) {
		EM_AGENT_CITY = eM_AGENT_CITY;
	}
	public String getEM_AGENT_STATE() {
		return EM_AGENT_STATE;
	}
	public void setEM_AGENT_STATE(String eM_AGENT_STATE) {
		EM_AGENT_STATE = eM_AGENT_STATE;
	}
	public String getEM_INSURED_NAME() {
		return EM_INSURED_NAME;
	}
	public void setEM_INSURED_NAME(String eM_INSURED_NAME) {
		EM_INSURED_NAME = eM_INSURED_NAME;
	}
	public String getEM_PROP_ADDR() {
		return EM_PROP_ADDR;
	}
	public void setEM_PROP_ADDR(String eM_PROP_ADDR) {
		EM_PROP_ADDR = eM_PROP_ADDR;
	}
	public String getEM_PROP_ADDR_1() {
		return EM_PROP_ADDR_1;
	}
	public void setEM_PROP_ADDR_1(String eM_PROP_ADDR_1) {
		EM_PROP_ADDR_1 = eM_PROP_ADDR_1;
	}
	public String getEM_PROP_CITY() {
		return EM_PROP_CITY;
	}
	public void setEM_PROP_CITY(String eM_PROP_CITY) {
		EM_PROP_CITY = eM_PROP_CITY;
	}
	public String getEM_PROP_STATE() {
		return EM_PROP_STATE;
	}
	public void setEM_PROP_STATE(String eM_PROP_STATE) {
		EM_PROP_STATE = eM_PROP_STATE;
	}
	public String getEM_TRAN_CODE() {
		return EM_TRAN_CODE;
	}
	public void setEM_TRAN_CODE(String eM_TRAN_CODE) {
		EM_TRAN_CODE = eM_TRAN_CODE;
	}
	public String getEM_OPERATOR_ID() {
		return EM_OPERATOR_ID;
	}
	public void setEM_OPERATOR_ID(String eM_OPERATOR_ID) {
		EM_OPERATOR_ID = eM_OPERATOR_ID;
	}
	public String getEM_TRANS_SETID() {
		return EM_TRANS_SETID;
	}
	public void setEM_TRANS_SETID(String eM_TRANS_SETID) {
		EM_TRANS_SETID = eM_TRANS_SETID;
	}
	public String getEM_TRANS_NO() {
		return EM_TRANS_NO;
	}
	public void setEM_TRANS_NO(String eM_TRANS_NO) {
		EM_TRANS_NO = eM_TRANS_NO;
	}
	public String getEM_INS_BANK_ROUTING() {
		return EM_INS_BANK_ROUTING;
	}
	public void setEM_INS_BANK_ROUTING(String eM_INS_BANK_ROUTING) {
		EM_INS_BANK_ROUTING = eM_INS_BANK_ROUTING;
	}
	public String getEM_INS_BANK_ACCT() {
		return EM_INS_BANK_ACCT;
	}
	public void setEM_INS_BANK_ACCT(String eM_INS_BANK_ACCT) {
		EM_INS_BANK_ACCT = eM_INS_BANK_ACCT;
	}
	public String getEM_INS_CRED_REF() {
		return EM_INS_CRED_REF;
	}
	public void setEM_INS_CRED_REF(String eM_INS_CRED_REF) {
		EM_INS_CRED_REF = eM_INS_CRED_REF;
	}
	public String getEM_FILE_TRNS() {
		return EM_FILE_TRNS;
	}
	public void setEM_FILE_TRNS(String eM_FILE_TRNS) {
		EM_FILE_TRNS = eM_FILE_TRNS;
	}
	public String getEM_POL_TRAN_CODE() {
		return EM_POL_TRAN_CODE;
	}
	public void setEM_POL_TRAN_CODE(String eM_POL_TRAN_CODE) {
		EM_POL_TRAN_CODE = eM_POL_TRAN_CODE;
	}
	public String getEM_POL_CXL_RSN() {
		return EM_POL_CXL_RSN;
	}
	public void setEM_POL_CXL_RSN(String eM_POL_CXL_RSN) {
		EM_POL_CXL_RSN = eM_POL_CXL_RSN;
	}
	public String getEM_POL_PAID_BY() {
		return EM_POL_PAID_BY;
	}
	public void setEM_POL_PAID_BY(String eM_POL_PAID_BY) {
		EM_POL_PAID_BY = eM_POL_PAID_BY;
	}
	public String getEM_NAIC() {
		return EM_NAIC;
	}
	public void setEM_NAIC(String eM_NAIC) {
		EM_NAIC = eM_NAIC;
	}
	public String getEM_INSCO_OCN() {
		return EM_INSCO_OCN;
	}
	public void setEM_INSCO_OCN(String eM_INSCO_OCN) {
		EM_INSCO_OCN = eM_INSCO_OCN;
	}
	public String getEM_POLICY_FORM() {
		return EM_POLICY_FORM;
	}
	public void setEM_POLICY_FORM(String eM_POLICY_FORM) {
		EM_POLICY_FORM = eM_POLICY_FORM;
	}
	public String getEM_NBR_MTGS() {
		return EM_NBR_MTGS;
	}
	public void setEM_NBR_MTGS(String eM_NBR_MTGS) {
		EM_NBR_MTGS = eM_NBR_MTGS;
	}
	public String getEM_MAIL_ADDR() {
		return EM_MAIL_ADDR;
	}
	public void setEM_MAIL_ADDR(String eM_MAIL_ADDR) {
		EM_MAIL_ADDR = eM_MAIL_ADDR;
	}
	public String getEM_MAIL_CITY() {
		return EM_MAIL_CITY;
	}
	public void setEM_MAIL_CITY(String eM_MAIL_CITY) {
		EM_MAIL_CITY = eM_MAIL_CITY;
	}
	public String getEM_MAIL_STATE() {
		return EM_MAIL_STATE;
	}
	public void setEM_MAIL_STATE(String eM_MAIL_STATE) {
		EM_MAIL_STATE = eM_MAIL_STATE;
	}
	public String getEM_CRDB_FLAG() {
		return EM_CRDB_FLAG;
	}
	public void setEM_CRDB_FLAG(String eM_CRDB_FLAG) {
		EM_CRDB_FLAG = eM_CRDB_FLAG;
	}
	public String getEM_COV_TYPE() {
		return EM_COV_TYPE;
	}
	public void setEM_COV_TYPE(String eM_COV_TYPE) {
		EM_COV_TYPE = eM_COV_TYPE;
	}
	public String getEM_INSUR_TYPE() {
		return EM_INSUR_TYPE;
	}
	public void setEM_INSUR_TYPE(String eM_INSUR_TYPE) {
		EM_INSUR_TYPE = eM_INSUR_TYPE;
	}
	public String getEM_DOC_NO() {
		return EM_DOC_NO;
	}
	public void setEM_DOC_NO(String eM_DOC_NO) {
		EM_DOC_NO = eM_DOC_NO;
	}
	public String getEM_COMMENT() {
		return EM_COMMENT;
	}
	public void setEM_COMMENT(String eM_COMMENT) {
		EM_COMMENT = eM_COMMENT;
	}
	public String getEM_820_SENT_INV() {
		return EM_820_SENT_INV;
	}
	public void setEM_820_SENT_INV(String eM_820_SENT_INV) {
		EM_820_SENT_INV = eM_820_SENT_INV;
	}
	public String getEM_820_SENT_CODE() {
		return EM_820_SENT_CODE;
	}
	public void setEM_820_SENT_CODE(String eM_820_SENT_CODE) {
		EM_820_SENT_CODE = eM_820_SENT_CODE;
	}
	public String getEM_FLOOD_MAP_REF() {
		return EM_FLOOD_MAP_REF;
	}
	public void setEM_FLOOD_MAP_REF(String eM_FLOOD_MAP_REF) {
		EM_FLOOD_MAP_REF = eM_FLOOD_MAP_REF;
	}
	public String getEM_FLOOD_MAP_NO() {
		return EM_FLOOD_MAP_NO;
	}
	public void setEM_FLOOD_MAP_NO(String eM_FLOOD_MAP_NO) {
		EM_FLOOD_MAP_NO = eM_FLOOD_MAP_NO;
	}
	public String getEM_FLOOD_ZONE() {
		return EM_FLOOD_ZONE;
	}
	public void setEM_FLOOD_ZONE(String eM_FLOOD_ZONE) {
		EM_FLOOD_ZONE = eM_FLOOD_ZONE;
	}
	public String getEM_NFIP_COMMUNITY_NAME() {
		return EM_NFIP_COMMUNITY_NAME;
	}
	public void setEM_NFIP_COMMUNITY_NAME(String eM_NFIP_COMMUNITY_NAME) {
		EM_NFIP_COMMUNITY_NAME = eM_NFIP_COMMUNITY_NAME;
	}
	public String getEM_NFIP_COUNTY() {
		return EM_NFIP_COUNTY;
	}
	public void setEM_NFIP_COUNTY(String eM_NFIP_COUNTY) {
		EM_NFIP_COUNTY = eM_NFIP_COUNTY;
	}
	public String getEM_NFIP_MAP_NO() {
		return EM_NFIP_MAP_NO;
	}
	public void setEM_NFIP_MAP_NO(String eM_NFIP_MAP_NO) {
		EM_NFIP_MAP_NO = eM_NFIP_MAP_NO;
	}
	public String getEM_NFIP_STATE() {
		return EM_NFIP_STATE;
	}
	public void setEM_NFIP_STATE(String eM_NFIP_STATE) {
		EM_NFIP_STATE = eM_NFIP_STATE;
	}
	public String getEM_NO_CONDOS() {
		return EM_NO_CONDOS;
	}
	public void setEM_NO_CONDOS(String eM_NO_CONDOS) {
		EM_NO_CONDOS = eM_NO_CONDOS;
	}
	public String getEM_PAYEE_CD() {
		return EM_PAYEE_CD;
	}
	public void setEM_PAYEE_CD(String eM_PAYEE_CD) {
		EM_PAYEE_CD = eM_PAYEE_CD;
	}
	public String getEM_TIF_NO() {
		return EM_TIF_NO;
	}
	public void setEM_TIF_NO(String eM_TIF_NO) {
		EM_TIF_NO = eM_TIF_NO;
	}
	public String getEM_INS_CO_ADDR1() {
		return EM_INS_CO_ADDR1;
	}
	public void setEM_INS_CO_ADDR1(String eM_INS_CO_ADDR1) {
		EM_INS_CO_ADDR1 = eM_INS_CO_ADDR1;
	}
	public String getEM_INS_CO_ADDR2() {
		return EM_INS_CO_ADDR2;
	}
	public void setEM_INS_CO_ADDR2(String eM_INS_CO_ADDR2) {
		EM_INS_CO_ADDR2 = eM_INS_CO_ADDR2;
	}
	public String getEM_INS_CO_CITY() {
		return EM_INS_CO_CITY;
	}
	public void setEM_INS_CO_CITY(String eM_INS_CO_CITY) {
		EM_INS_CO_CITY = eM_INS_CO_CITY;
	}
	public String getEM_INS_CO_STATE() {
		return EM_INS_CO_STATE;
	}
	public void setEM_INS_CO_STATE(String eM_INS_CO_STATE) {
		EM_INS_CO_STATE = eM_INS_CO_STATE;
	}
	public String getEM_NON_TRACKING_FLG() {
		return EM_NON_TRACKING_FLG;
	}
	public void setEM_NON_TRACKING_FLG(String eM_NON_TRACKING_FLG) {
		EM_NON_TRACKING_FLG = eM_NON_TRACKING_FLG;
	}
	public String getEM_REPLACE_COST_IND() {
		return EM_REPLACE_COST_IND;
	}
	public void setEM_REPLACE_COST_IND(String eM_REPLACE_COST_IND) {
		EM_REPLACE_COST_IND = eM_REPLACE_COST_IND;
	}
	public String getEM_EXCL_EARTHQUAKE() {
		return EM_EXCL_EARTHQUAKE;
	}
	public void setEM_EXCL_EARTHQUAKE(String eM_EXCL_EARTHQUAKE) {
		EM_EXCL_EARTHQUAKE = eM_EXCL_EARTHQUAKE;
	}
	public String getEM_EXCL_WIND_HURRICANE() {
		return EM_EXCL_WIND_HURRICANE;
	}
	public void setEM_EXCL_WIND_HURRICANE(String eM_EXCL_WIND_HURRICANE) {
		EM_EXCL_WIND_HURRICANE = eM_EXCL_WIND_HURRICANE;
	}
	public String getEM_IMPAIR_CD() {
		return EM_IMPAIR_CD;
	}
	public void setEM_IMPAIR_CD(String eM_IMPAIR_CD) {
		EM_IMPAIR_CD = eM_IMPAIR_CD;
	}
	public String getEM_SPARE_FL_1() {
		return EM_SPARE_FL_1;
	}
	public void setEM_SPARE_FL_1(String eM_SPARE_FL_1) {
		EM_SPARE_FL_1 = eM_SPARE_FL_1;
	}
	public String getEM_SPARE_FL_2() {
		return EM_SPARE_FL_2;
	}
	public void setEM_SPARE_FL_2(String eM_SPARE_FL_2) {
		EM_SPARE_FL_2 = eM_SPARE_FL_2;
	}
	public String getEM_SPARE_FL_3() {
		return EM_SPARE_FL_3;
	}
	public void setEM_SPARE_FL_3(String eM_SPARE_FL_3) {
		EM_SPARE_FL_3 = eM_SPARE_FL_3;
	}
	public String getEM_SPARE_FL_4() {
		return EM_SPARE_FL_4;
	}
	public void setEM_SPARE_FL_4(String eM_SPARE_FL_4) {
		EM_SPARE_FL_4 = eM_SPARE_FL_4;
	}
	public String getEMFLAG5() {
		return EMFLAG5;
	}
	public void setEMFLAG5(String eMFLAG5) {
		EMFLAG5 = eMFLAG5;
	}
	public String getEMFLAG6() {
		return EMFLAG6;
	}
	public void setEMFLAG6(String eMFLAG6) {
		EMFLAG6 = eMFLAG6;
	}
	public String getEMFLAG7() {
		return EMFLAG7;
	}
	public void setEMFLAG7(String eMFLAG7) {
		EMFLAG7 = eMFLAG7;
	}
	public String getEMFLAG8() {
		return EMFLAG8;
	}
	public void setEMFLAG8(String eMFLAG8) {
		EMFLAG8 = eMFLAG8;
	}
	public String getEMFLAG9() {
		return EMFLAG9;
	}
	public void setEMFLAG9(String eMFLAG9) {
		EMFLAG9 = eMFLAG9;
	}
	public String getEMFLAG10() {
		return EMFLAG10;
	}
	public void setEMFLAG10(String eMFLAG10) {
		EMFLAG10 = eMFLAG10;
	}
	public String getEM_SPARE_CODE_1() {
		return EM_SPARE_CODE_1;
	}
	public void setEM_SPARE_CODE_1(String eM_SPARE_CODE_1) {
		EM_SPARE_CODE_1 = eM_SPARE_CODE_1;
	}
	public String getEMCODE2() {
		return EMCODE2;
	}
	public void setEMCODE2(String eMCODE2) {
		EMCODE2 = eMCODE2;
	}
	public String getEMCODE3() {
		return EMCODE3;
	}
	public void setEMCODE3(String eMCODE3) {
		EMCODE3 = eMCODE3;
	}
	public String getEMCODE4() {
		return EMCODE4;
	}
	public void setEMCODE4(String eMCODE4) {
		EMCODE4 = eMCODE4;
	}
	public String getEMCODE5() {
		return EMCODE5;
	}
	public void setEMCODE5(String eMCODE5) {
		EMCODE5 = eMCODE5;
	}
	public String getEMCODE6() {
		return EMCODE6;
	}
	public void setEMCODE6(String eMCODE6) {
		EMCODE6 = eMCODE6;
	}
	public String getEMCODE7() {
		return EMCODE7;
	}
	public void setEMCODE7(String eMCODE7) {
		EMCODE7 = eMCODE7;
	}
	public String getEMCODE8() {
		return EMCODE8;
	}
	public void setEMCODE8(String eMCODE8) {
		EMCODE8 = eMCODE8;
	}
	public String getEMCODE9() {
		return EMCODE9;
	}
	public void setEMCODE9(String eMCODE9) {
		EMCODE9 = eMCODE9;
	}
	public String getEMCODE10() {
		return EMCODE10;
	}
	public void setEMCODE10(String eMCODE10) {
		EMCODE10 = eMCODE10;
	}
	public String getEMSPRFLD() {
		return EMSPRFLD;
	}
	public void setEMSPRFLD(String eMSPRFLD) {
		EMSPRFLD = eMSPRFLD;
	}
	public String getEM_ADDTNS() {
		return EM_ADDTNS;
	}
	public void setEM_ADDTNS(String eM_ADDTNS) {
		EM_ADDTNS = eM_ADDTNS;
	}
	public String getEM_ADD02() {
		return EM_ADD02;
	}
	public void setEM_ADD02(String eM_ADD02) {
		EM_ADD02 = eM_ADD02;
	}
	public String getEM_ADD03() {
		return EM_ADD03;
	}
	public void setEM_ADD03(String eM_ADD03) {
		EM_ADD03 = eM_ADD03;
	}
	public String getEM_ADD04() {
		return EM_ADD04;
	}
	public void setEM_ADD04(String eM_ADD04) {
		EM_ADD04 = eM_ADD04;
	}
	public String getEM_ADD05() {
		return EM_ADD05;
	}
	public void setEM_ADD05(String eM_ADD05) {
		EM_ADD05 = eM_ADD05;
	}
	public String getEM_ADD06() {
		return EM_ADD06;
	}
	public void setEM_ADD06(String eM_ADD06) {
		EM_ADD06 = eM_ADD06;
	}
	public String getEM_ADD07() {
		return EM_ADD07;
	}
	public void setEM_ADD07(String eM_ADD07) {
		EM_ADD07 = eM_ADD07;
	}
	public String getEM_ADD08() {
		return EM_ADD08;
	}
	public void setEM_ADD08(String eM_ADD08) {
		EM_ADD08 = eM_ADD08;
	}
	public String getEM_ADD09() {
		return EM_ADD09;
	}
	public void setEM_ADD09(String eM_ADD09) {
		EM_ADD09 = eM_ADD09;
	}
	public String getEM_ADD10() {
		return EM_ADD10;
	}
	public void setEM_ADD10(String eM_ADD10) {
		EM_ADD10 = eM_ADD10;
	}
	public String getEM_ADD30() {
		return EM_ADD30;
	}
	public void setEM_ADD30(String eM_ADD30) {
		EM_ADD30 = eM_ADD30;
	}
	public String getEM_ADD31() {
		return EM_ADD31;
	}
	public void setEM_ADD31(String eM_ADD31) {
		EM_ADD31 = eM_ADD31;
	}
	public String getEM_ADD32() {
		return EM_ADD32;
	}
	public void setEM_ADD32(String eM_ADD32) {
		EM_ADD32 = eM_ADD32;
	}
	public String getEM_ADD33() {
		return EM_ADD33;
	}
	public void setEM_ADD33(String eM_ADD33) {
		EM_ADD33 = eM_ADD33;
	}
	public String getEM_ADD34() {
		return EM_ADD34;
	}
	public void setEM_ADD34(String eM_ADD34) {
		EM_ADD34 = eM_ADD34;
	}
	public String getEM_ADD35() {
		return EM_ADD35;
	}
	public void setEM_ADD35(String eM_ADD35) {
		EM_ADD35 = eM_ADD35;
	}
	public String getEM_ADD36() {
		return EM_ADD36;
	}
	public void setEM_ADD36(String eM_ADD36) {
		EM_ADD36 = eM_ADD36;
	}
	public String getEM_ADD37() {
		return EM_ADD37;
	}
	public void setEM_ADD37(String eM_ADD37) {
		EM_ADD37 = eM_ADD37;
	}
	public String getEM_ADD90() {
		return EM_ADD90;
	}
	public void setEM_ADD90(String eM_ADD90) {
		EM_ADD90 = eM_ADD90;
	}
	public String getEM_ADD91() {
		return EM_ADD91;
	}
	public void setEM_ADD91(String eM_ADD91) {
		EM_ADD91 = eM_ADD91;
	}
	public String getEM_ADD97() {
		return EM_ADD97;
	}
	public void setEM_ADD97(String eM_ADD97) {
		EM_ADD97 = eM_ADD97;
	}
	public String getEM_ADD98() {
		return EM_ADD98;
	}
	public void setEM_ADD98(String eM_ADD98) {
		EM_ADD98 = eM_ADD98;
	}
	public String getEM_ADD99() {
		return EM_ADD99;
	}
	public void setEM_ADD99(String eM_ADD99) {
		EM_ADD99 = eM_ADD99;
	}
	public String getEM_PROCESS_FLAG() {
		return EM_PROCESS_FLAG;
	}
	public void setEM_PROCESS_FLAG(String eM_PROCESS_FLAG) {
		EM_PROCESS_FLAG = eM_PROCESS_FLAG;
	}
	public String getEM_PROCESS_ERROR_STATUS() {
		return EM_PROCESS_ERROR_STATUS;
	}
	public void setEM_PROCESS_ERROR_STATUS(String eM_PROCESS_ERROR_STATUS) {
		EM_PROCESS_ERROR_STATUS = eM_PROCESS_ERROR_STATUS;
	}
	public String getEM_REC_ID() {
		return EM_REC_ID;
	}
	public void setEM_REC_ID(String eM_REC_ID) {
		EM_REC_ID = eM_REC_ID;
	}
	public String getEM_PARENT_ID() {
		return EM_PARENT_ID;
	}
	public void setEM_PARENT_ID(String eM_PARENT_ID) {
		EM_PARENT_ID = eM_PARENT_ID;
	}
	public String getEM_LEVEL_CD() {
		return EM_LEVEL_CD;
	}
	public void setEM_LEVEL_CD(String eM_LEVEL_CD) {
		EM_LEVEL_CD = eM_LEVEL_CD;
	}
	public String getEM_CHILD_CD() {
		return EM_CHILD_CD;
	}
	public void setEM_CHILD_CD(String eM_CHILD_CD) {
		EM_CHILD_CD = eM_CHILD_CD;
	}
	public Date getRec_created_on() {
		return rec_created_on;
	}
	public void setRec_created_on(Date rec_created_on) {
		this.rec_created_on = rec_created_on;
	}
	public Date getRec_modified_on() {
		return rec_modified_on;
	}
	public void setRec_modified_on(Date rec_modified_on) {
		this.rec_modified_on = rec_modified_on;
	}
	public Date getDoc_received_date() {
		return doc_received_date;
	}
	public void setDoc_received_date(Date doc_received_date) {
		this.doc_received_date = doc_received_date;
	}
	public Date getPolicy_effective_date() {
		return policy_effective_date;
	}
	public void setPolicy_effective_date(Date policy_effective_date) {
		this.policy_effective_date = policy_effective_date;
	}
	public Date getReinstatement_date() {
		return reinstatement_date;
	}
	public void setReinstatement_date(Date reinstatement_date) {
		this.reinstatement_date = reinstatement_date;
	}
	public Date getDoc_notice_date() {
		return doc_notice_date;
	}
	public void setDoc_notice_date(Date doc_notice_date) {
		this.doc_notice_date = doc_notice_date;
	}
	public Date getDoc_delivery_date() {
		return doc_delivery_date;
	}
	public void setDoc_delivery_date(Date doc_delivery_date) {
		this.doc_delivery_date = doc_delivery_date;
	}
	public Date getDoc_notice_effective_date() {
		return doc_notice_effective_date;
	}
	public void setDoc_notice_effective_date(Date doc_notice_effective_date) {
		this.doc_notice_effective_date = doc_notice_effective_date;
	}
	public Date getPremium_due_date() {
		return premium_due_date;
	}
	public void setPremium_due_date(Date premium_due_date) {
		this.premium_due_date = premium_due_date;
	}
	public Date getPolicy_cancel_date() {
		return policy_cancel_date;
	}
	public void setPolicy_cancel_date(Date policy_cancel_date) {
		this.policy_cancel_date = policy_cancel_date;
	}
	public Date getPolicy_expiration_date() {
		return policy_expiration_date;
	}
	public void setPolicy_expiration_date(Date policy_expiration_date) {
		this.policy_expiration_date = policy_expiration_date;
	}
	public Date getDoc_issue_date() {
		return doc_issue_date;
	}
	public void setDoc_issue_date(Date doc_issue_date) {
		this.doc_issue_date = doc_issue_date;
	}
	public Date getAs400_post_date() {
		return as400_post_date;
	}
	public void setAs400_post_date(Date as400_post_date) {
		this.as400_post_date = as400_post_date;
	}
	public Date getFollow_up_date() {
		return follow_up_date;
	}
	public void setFollow_up_date(Date follow_up_date) {
		this.follow_up_date = follow_up_date;
	}
	public double getEM_TAXPAYER_ID() {
		return EM_TAXPAYER_ID;
	}
	public void setEM_TAXPAYER_ID(double eM_TAXPAYER_ID) {
		EM_TAXPAYER_ID = eM_TAXPAYER_ID;
	}
	public double getEM_MORTGAGE_NO() {
		return EM_MORTGAGE_NO;
	}
	public void setEM_MORTGAGE_NO(double eM_MORTGAGE_NO) {
		EM_MORTGAGE_NO = eM_MORTGAGE_NO;
	}
	public double getEM_FILE_PREM() {
		return EM_FILE_PREM;
	}
	public void setEM_FILE_PREM(double eM_FILE_PREM) {
		EM_FILE_PREM = eM_FILE_PREM;
	}
	public double getEM_SPARE_DATE_1() {
		return EM_SPARE_DATE_1;
	}
	public void setEM_SPARE_DATE_1(double eM_SPARE_DATE_1) {
		EM_SPARE_DATE_1 = eM_SPARE_DATE_1;
	}
	public double getEMDATE2() {
		return EMDATE2;
	}
	public void setEMDATE2(double eMDATE2) {
		EMDATE2 = eMDATE2;
	}
	public double getEMDATE3() {
		return EMDATE3;
	}
	public void setEMDATE3(double eMDATE3) {
		EMDATE3 = eMDATE3;
	}
	public double getEMDATE4() {
		return EMDATE4;
	}
	public void setEMDATE4(double eMDATE4) {
		EMDATE4 = eMDATE4;
	}
	public double getEMDATE5() {
		return EMDATE5;
	}
	public void setEMDATE5(double eMDATE5) {
		EMDATE5 = eMDATE5;
	}
	public double getEMDATE6() {
		return EMDATE6;
	}
	public void setEMDATE6(double eMDATE6) {
		EMDATE6 = eMDATE6;
	}
	public double getEMDATE7() {
		return EMDATE7;
	}
	public void setEMDATE7(double eMDATE7) {
		EMDATE7 = eMDATE7;
	}
	public double getEMDATE8() {
		return EMDATE8;
	}
	public void setEMDATE8(double eMDATE8) {
		EMDATE8 = eMDATE8;
	}
	public double getEMDATE9() {
		return EMDATE9;
	}
	public void setEMDATE9(double eMDATE9) {
		EMDATE9 = eMDATE9;
	}
	public double getEMDATE10() {
		return EMDATE10;
	}
	public void setEMDATE10(double eMDATE10) {
		EMDATE10 = eMDATE10;
	}
	public double getEMSPRAMT() {
		return EMSPRAMT;
	}
	public void setEMSPRAMT(double eMSPRAMT) {
		EMSPRAMT = eMSPRAMT;
	}
	public double getEMSPRAM2() {
		return EMSPRAM2;
	}
	public void setEMSPRAM2(double eMSPRAM2) {
		EMSPRAM2 = eMSPRAM2;
	}
	public double getEMSPRAM3() {
		return EMSPRAM3;
	}
	public void setEMSPRAM3(double eMSPRAM3) {
		EMSPRAM3 = eMSPRAM3;
	}
	public double getEMSPRAM4() {
		return EMSPRAM4;
	}
	public void setEMSPRAM4(double eMSPRAM4) {
		EMSPRAM4 = eMSPRAM4;
	}
	public double getEMSPRAM5() {
		return EMSPRAM5;
	}
	public void setEMSPRAM5(double eMSPRAM5) {
		EMSPRAM5 = eMSPRAM5;
	}
	public double getEMSPRAM6() {
		return EMSPRAM6;
	}
	public void setEMSPRAM6(double eMSPRAM6) {
		EMSPRAM6 = eMSPRAM6;
	}
	public double getEMSPRAM7() {
		return EMSPRAM7;
	}
	public void setEMSPRAM7(double eMSPRAM7) {
		EMSPRAM7 = eMSPRAM7;
	}
	public double getEMSPRAM8() {
		return EMSPRAM8;
	}
	public void setEMSPRAM8(double eMSPRAM8) {
		EMSPRAM8 = eMSPRAM8;
	}
	public double getEMSPRAM9() {
		return EMSPRAM9;
	}
	public void setEMSPRAM9(double eMSPRAM9) {
		EMSPRAM9 = eMSPRAM9;
	}
	public double getEMSPRAM10() {
		return EMSPRAM10;
	}
	public void setEMSPRAM10(double eMSPRAM10) {
		EMSPRAM10 = eMSPRAM10;
	}
	public double getBase_coverage_other_structs() {
		return base_coverage_other_structs;
	}
	public void setBase_coverage_other_structs(double base_coverage_other_structs) {
		this.base_coverage_other_structs = base_coverage_other_structs;
	}
	public double getDeductible() {
		return deductible;
	}
	public void setDeductible(double deductible) {
		this.deductible = deductible;
	}
	public double getCoverage_amount() {
		return coverage_amount;
	}
	public void setCoverage_amount(double coverage_amount) {
		this.coverage_amount = coverage_amount;
	}
	public double getPercent_deductible() {
		return percent_deductible;
	}
	public void setPercent_deductible(double percent_deductible) {
		this.percent_deductible = percent_deductible;
	}
	public double getPolicy_premium() {
		return policy_premium;
	}
	public void setPolicy_premium(double policy_premium) {
		this.policy_premium = policy_premium;
	}
	public double getPercent_primary_coverage() {
		return percent_primary_coverage;
	}
	public void setPercent_primary_coverage(double percent_primary_coverage) {
		this.percent_primary_coverage = percent_primary_coverage;
	}
	public double getAdditional_premium_amt() {
		return additional_premium_amt;
	}
	public void setAdditional_premium_amt(double additional_premium_amt) {
		this.additional_premium_amt = additional_premium_amt;
	}
	public double getAdditional_coverage_amount() {
		return additional_coverage_amount;
	}
	public void setAdditional_coverage_amount(double additional_coverage_amount) {
		this.additional_coverage_amount = additional_coverage_amount;
	}
	public int getNumber_of_condos() {
		return number_of_condos;
	}
	public void setNumber_of_condos(int number_of_condos) {
		this.number_of_condos = number_of_condos;
	}
	public int getBatch_number() {
		return batch_number;
	}
	public void setBatch_number(int batch_number) {
		this.batch_number = batch_number;
	}
	public int getBatch_seq_no() {
		return batch_seq_no;
	}
	public void setBatch_seq_no(int batch_seq_no) {
		this.batch_seq_no = batch_seq_no;
	}
	public double getEM_ACCOUNT_NO() {
		return EM_ACCOUNT_NO;
	}
	public void setEM_ACCOUNT_NO(double eM_ACCOUNT_NO) {
		EM_ACCOUNT_NO = eM_ACCOUNT_NO;
	}
	public double getEM_MCB_DATE() {
		return EM_MCB_DATE;
	}
	public void setEM_MCB_DATE(double eM_MCB_DATE) {
		EM_MCB_DATE = eM_MCB_DATE;
	}
	public double getEM_FILE_DATE() {
		return EM_FILE_DATE;
	}
	public void setEM_FILE_DATE(double eM_FILE_DATE) {
		EM_FILE_DATE = eM_FILE_DATE;
	}
	public double getEM_AGENCY_NO() {
		return EM_AGENCY_NO;
	}
	public void setEM_AGENCY_NO(double eM_AGENCY_NO) {
		EM_AGENCY_NO = eM_AGENCY_NO;
	}
	public double getEM_ACCT_TAX_ID() {
		return EM_ACCT_TAX_ID;
	}
	public void setEM_ACCT_TAX_ID(double eM_ACCT_TAX_ID) {
		EM_ACCT_TAX_ID = eM_ACCT_TAX_ID;
	}
	public double getEM_LOAN_SUFFIX() {
		return EM_LOAN_SUFFIX;
	}
	public void setEM_LOAN_SUFFIX(double eM_LOAN_SUFFIX) {
		EM_LOAN_SUFFIX = eM_LOAN_SUFFIX;
	}
	public double getEM_MORT_ZIP() {
		return EM_MORT_ZIP;
	}
	public void setEM_MORT_ZIP(double eM_MORT_ZIP) {
		EM_MORT_ZIP = eM_MORT_ZIP;
	}
	public double getEM_AGENT_ZIP() {
		return EM_AGENT_ZIP;
	}
	public void setEM_AGENT_ZIP(double eM_AGENT_ZIP) {
		EM_AGENT_ZIP = eM_AGENT_ZIP;
	}
	public double getEM_AGENT_PHONE() {
		return EM_AGENT_PHONE;
	}
	public void setEM_AGENT_PHONE(double eM_AGENT_PHONE) {
		EM_AGENT_PHONE = eM_AGENT_PHONE;
	}
	public double getEM_PROP_ZIP() {
		return EM_PROP_ZIP;
	}
	public void setEM_PROP_ZIP(double eM_PROP_ZIP) {
		EM_PROP_ZIP = eM_PROP_ZIP;
	}
	public double getEM_PROP_ZIP_4() {
		return EM_PROP_ZIP_4;
	}
	public void setEM_PROP_ZIP_4(double eM_PROP_ZIP_4) {
		EM_PROP_ZIP_4 = eM_PROP_ZIP_4;
	}
	public double getEM_EFFECTIVE_DATE() {
		return EM_EFFECTIVE_DATE;
	}
	public void setEM_EFFECTIVE_DATE(double eM_EFFECTIVE_DATE) {
		EM_EFFECTIVE_DATE = eM_EFFECTIVE_DATE;
	}
	public double getEM_EXPIRATION_DATE() {
		return EM_EXPIRATION_DATE;
	}
	public void setEM_EXPIRATION_DATE(double eM_EXPIRATION_DATE) {
		EM_EXPIRATION_DATE = eM_EXPIRATION_DATE;
	}
	public double getEM_POL_PROCESS_DATE() {
		return EM_POL_PROCESS_DATE;
	}
	public void setEM_POL_PROCESS_DATE(double eM_POL_PROCESS_DATE) {
		EM_POL_PROCESS_DATE = eM_POL_PROCESS_DATE;
	}
	public double getEM_POL_CHANGE_DATE() {
		return EM_POL_CHANGE_DATE;
	}
	public void setEM_POL_CHANGE_DATE(double eM_POL_CHANGE_DATE) {
		EM_POL_CHANGE_DATE = eM_POL_CHANGE_DATE;
	}
	public double getEM_DEDUCTIBLE() {
		return EM_DEDUCTIBLE;
	}
	public void setEM_DEDUCTIBLE(double eM_DEDUCTIBLE) {
		EM_DEDUCTIBLE = eM_DEDUCTIBLE;
	}
	public double getEM_PCT_PRIMARY_COV() {
		return EM_PCT_PRIMARY_COV;
	}
	public void setEM_PCT_PRIMARY_COV(double eM_PCT_PRIMARY_COV) {
		EM_PCT_PRIMARY_COV = eM_PCT_PRIMARY_COV;
	}
	public double getEM_COV_AMT() {
		return EM_COV_AMT;
	}
	public void setEM_COV_AMT(double eM_COV_AMT) {
		EM_COV_AMT = eM_COV_AMT;
	}
	public double getEM_BASE_COV_OS() {
		return EM_BASE_COV_OS;
	}
	public void setEM_BASE_COV_OS(double eM_BASE_COV_OS) {
		EM_BASE_COV_OS = eM_BASE_COV_OS;
	}
	public double getEM_BASE_COV_OS_PCT() {
		return EM_BASE_COV_OS_PCT;
	}
	public void setEM_BASE_COV_OS_PCT(double eM_BASE_COV_OS_PCT) {
		EM_BASE_COV_OS_PCT = eM_BASE_COV_OS_PCT;
	}
	public double getEM_TRAN_DATE() {
		return EM_TRAN_DATE;
	}
	public void setEM_TRAN_DATE(double eM_TRAN_DATE) {
		EM_TRAN_DATE = eM_TRAN_DATE;
	}
	public double getEM_INSCO_TAXID() {
		return EM_INSCO_TAXID;
	}
	public void setEM_INSCO_TAXID(double eM_INSCO_TAXID) {
		EM_INSCO_TAXID = eM_INSCO_TAXID;
	}
	public double getEM_MTG_TAX_ID() {
		return EM_MTG_TAX_ID;
	}
	public void setEM_MTG_TAX_ID(double eM_MTG_TAX_ID) {
		EM_MTG_TAX_ID = eM_MTG_TAX_ID;
	}
	public double getEM_POL_PREM() {
		return EM_POL_PREM;
	}
	public void setEM_POL_PREM(double eM_POL_PREM) {
		EM_POL_PREM = eM_POL_PREM;
	}
	public double getEM_POL_CANCEL_DATE() {
		return EM_POL_CANCEL_DATE;
	}
	public void setEM_POL_CANCEL_DATE(double eM_POL_CANCEL_DATE) {
		EM_POL_CANCEL_DATE = eM_POL_CANCEL_DATE;
	}
	public double getEM_POL_EXTEND_DATE() {
		return EM_POL_EXTEND_DATE;
	}
	public void setEM_POL_EXTEND_DATE(double eM_POL_EXTEND_DATE) {
		EM_POL_EXTEND_DATE = eM_POL_EXTEND_DATE;
	}
	public double getEM_POL_REINST_DATE() {
		return EM_POL_REINST_DATE;
	}
	public void setEM_POL_REINST_DATE(double eM_POL_REINST_DATE) {
		EM_POL_REINST_DATE = eM_POL_REINST_DATE;
	}
	public double getEM_MAIL_ZIP() {
		return EM_MAIL_ZIP;
	}
	public void setEM_MAIL_ZIP(double eM_MAIL_ZIP) {
		EM_MAIL_ZIP = eM_MAIL_ZIP;
	}
	public double getEM_MAIL_ZIP_4() {
		return EM_MAIL_ZIP_4;
	}
	public void setEM_MAIL_ZIP_4(double eM_MAIL_ZIP_4) {
		EM_MAIL_ZIP_4 = eM_MAIL_ZIP_4;
	}
	public double getEM_NET_AMT() {
		return EM_NET_AMT;
	}
	public void setEM_NET_AMT(double eM_NET_AMT) {
		EM_NET_AMT = eM_NET_AMT;
	}
	public double getEM_TRANS_TOT() {
		return EM_TRANS_TOT;
	}
	public void setEM_TRANS_TOT(double eM_TRANS_TOT) {
		EM_TRANS_TOT = eM_TRANS_TOT;
	}
	public double getEM_SEQ() {
		return EM_SEQ;
	}
	public void setEM_SEQ(double eM_SEQ) {
		EM_SEQ = eM_SEQ;
	}
	public double getEM_DOC_DATE() {
		return EM_DOC_DATE;
	}
	public void setEM_DOC_DATE(double eM_DOC_DATE) {
		EM_DOC_DATE = eM_DOC_DATE;
	}
	public double getEM_820_SENT_DATE() {
		return EM_820_SENT_DATE;
	}
	public void setEM_820_SENT_DATE(double eM_820_SENT_DATE) {
		EM_820_SENT_DATE = eM_820_SENT_DATE;
	}
	public double getEM_NFIP_COMMUNITY_NO() {
		return EM_NFIP_COMMUNITY_NO;
	}
	public void setEM_NFIP_COMMUNITY_NO(double eM_NFIP_COMMUNITY_NO) {
		EM_NFIP_COMMUNITY_NO = eM_NFIP_COMMUNITY_NO;
	}
	public double getEM_INS_CO_ZIP() {
		return EM_INS_CO_ZIP;
	}
	public void setEM_INS_CO_ZIP(double eM_INS_CO_ZIP) {
		EM_INS_CO_ZIP = eM_INS_CO_ZIP;
	}
	public double getEM_BASE_COV_AA() {
		return EM_BASE_COV_AA;
	}
	public void setEM_BASE_COV_AA(double eM_BASE_COV_AA) {
		EM_BASE_COV_AA = eM_BASE_COV_AA;
	}
	public double getEM_BASE_COV_AA_PCT() {
		return EM_BASE_COV_AA_PCT;
	}
	public void setEM_BASE_COV_AA_PCT(double eM_BASE_COV_AA_PCT) {
		EM_BASE_COV_AA_PCT = eM_BASE_COV_AA_PCT;
	}
	public double getEM_PREM_DUE_DATE() {
		return EM_PREM_DUE_DATE;
	}
	public void setEM_PREM_DUE_DATE(double eM_PREM_DUE_DATE) {
		EM_PREM_DUE_DATE = eM_PREM_DUE_DATE;
	}
	public double getEM_BATCH_NO() {
		return EM_BATCH_NO;
	}
	public void setEM_BATCH_NO(double eM_BATCH_NO) {
		EM_BATCH_NO = eM_BATCH_NO;
	}
	public double getEM_COG_DOC() {
		return EM_COG_DOC;
	}
	public void setEM_COG_DOC(double eM_COG_DOC) {
		EM_COG_DOC = eM_COG_DOC;
	}
	public double getEM_COG_SEQ() {
		return EM_COG_SEQ;
	}
	public void setEM_COG_SEQ(double eM_COG_SEQ) {
		EM_COG_SEQ = eM_COG_SEQ;
	}
	public double getEM_VAR_COVERAGE() {
		return EM_VAR_COVERAGE;
	}
	public void setEM_VAR_COVERAGE(double eM_VAR_COVERAGE) {
		EM_VAR_COVERAGE = eM_VAR_COVERAGE;
	}
	public double getEM_VAR_DEDUCTIBLE() {
		return EM_VAR_DEDUCTIBLE;
	}
	public void setEM_VAR_DEDUCTIBLE(double eM_VAR_DEDUCTIBLE) {
		EM_VAR_DEDUCTIBLE = eM_VAR_DEDUCTIBLE;
	}
	public double getEM_VAR_COV_PCT1() {
		return EM_VAR_COV_PCT1;
	}
	public void setEM_VAR_COV_PCT1(double eM_VAR_COV_PCT1) {
		EM_VAR_COV_PCT1 = eM_VAR_COV_PCT1;
	}
	public double getEM_VAR_DED_PCT1() {
		return EM_VAR_DED_PCT1;
	}
	public void setEM_VAR_DED_PCT1(double eM_VAR_DED_PCT1) {
		EM_VAR_DED_PCT1 = eM_VAR_DED_PCT1;
	}
	public double getEM_VAR_COVERAGE02() {
		return EM_VAR_COVERAGE02;
	}
	public void setEM_VAR_COVERAGE02(double eM_VAR_COVERAGE02) {
		EM_VAR_COVERAGE02 = eM_VAR_COVERAGE02;
	}
	public double getEM_VAR_DEDUCT02() {
		return EM_VAR_DEDUCT02;
	}
	public void setEM_VAR_DEDUCT02(double eM_VAR_DEDUCT02) {
		EM_VAR_DEDUCT02 = eM_VAR_DEDUCT02;
	}
	public double getEM_VAR_COV_PCT02() {
		return EM_VAR_COV_PCT02;
	}
	public void setEM_VAR_COV_PCT02(double eM_VAR_COV_PCT02) {
		EM_VAR_COV_PCT02 = eM_VAR_COV_PCT02;
	}
	public double getEM_VAR_DED_PCT02() {
		return EM_VAR_DED_PCT02;
	}
	public void setEM_VAR_DED_PCT02(double eM_VAR_DED_PCT02) {
		EM_VAR_DED_PCT02 = eM_VAR_DED_PCT02;
	}
	public double getEM_VAR_COVERAGE03() {
		return EM_VAR_COVERAGE03;
	}
	public void setEM_VAR_COVERAGE03(double eM_VAR_COVERAGE03) {
		EM_VAR_COVERAGE03 = eM_VAR_COVERAGE03;
	}
	public double getEM_VAR_DEDUCT03() {
		return EM_VAR_DEDUCT03;
	}
	public void setEM_VAR_DEDUCT03(double eM_VAR_DEDUCT03) {
		EM_VAR_DEDUCT03 = eM_VAR_DEDUCT03;
	}
	public double getEM_VAR_COV_PCT03() {
		return EM_VAR_COV_PCT03;
	}
	public void setEM_VAR_COV_PCT03(double eM_VAR_COV_PCT03) {
		EM_VAR_COV_PCT03 = eM_VAR_COV_PCT03;
	}
	public double getEM_VAR_DED_PCT03() {
		return EM_VAR_DED_PCT03;
	}
	public void setEM_VAR_DED_PCT03(double eM_VAR_DED_PCT03) {
		EM_VAR_DED_PCT03 = eM_VAR_DED_PCT03;
	}
	public double getEM_VAR_COVERAGE04() {
		return EM_VAR_COVERAGE04;
	}
	public void setEM_VAR_COVERAGE04(double eM_VAR_COVERAGE04) {
		EM_VAR_COVERAGE04 = eM_VAR_COVERAGE04;
	}
	public double getEM_VAR_DEDUCT04() {
		return EM_VAR_DEDUCT04;
	}
	public void setEM_VAR_DEDUCT04(double eM_VAR_DEDUCT04) {
		EM_VAR_DEDUCT04 = eM_VAR_DEDUCT04;
	}
	public double getEM_VAR_COV_PCT04() {
		return EM_VAR_COV_PCT04;
	}
	public void setEM_VAR_COV_PCT04(double eM_VAR_COV_PCT04) {
		EM_VAR_COV_PCT04 = eM_VAR_COV_PCT04;
	}
	public double getEM_VAR_DED_PCT04() {
		return EM_VAR_DED_PCT04;
	}
	public void setEM_VAR_DED_PCT04(double eM_VAR_DED_PCT04) {
		EM_VAR_DED_PCT04 = eM_VAR_DED_PCT04;
	}
	public double getEM_VAR_COVERAGE05() {
		return EM_VAR_COVERAGE05;
	}
	public void setEM_VAR_COVERAGE05(double eM_VAR_COVERAGE05) {
		EM_VAR_COVERAGE05 = eM_VAR_COVERAGE05;
	}
	public double getEM_VAR_DEDUCT05() {
		return EM_VAR_DEDUCT05;
	}
	public void setEM_VAR_DEDUCT05(double eM_VAR_DEDUCT05) {
		EM_VAR_DEDUCT05 = eM_VAR_DEDUCT05;
	}
	public double getEM_VAR_COV_PCT05() {
		return EM_VAR_COV_PCT05;
	}
	public void setEM_VAR_COV_PCT05(double eM_VAR_COV_PCT05) {
		EM_VAR_COV_PCT05 = eM_VAR_COV_PCT05;
	}
	public double getEM_VAR_DED_PCT05() {
		return EM_VAR_DED_PCT05;
	}
	public void setEM_VAR_DED_PCT05(double eM_VAR_DED_PCT05) {
		EM_VAR_DED_PCT05 = eM_VAR_DED_PCT05;
	}
	public double getEM_VAR_COVERAGE06() {
		return EM_VAR_COVERAGE06;
	}
	public void setEM_VAR_COVERAGE06(double eM_VAR_COVERAGE06) {
		EM_VAR_COVERAGE06 = eM_VAR_COVERAGE06;
	}
	public double getEM_VAR_DEDUCT06() {
		return EM_VAR_DEDUCT06;
	}
	public void setEM_VAR_DEDUCT06(double eM_VAR_DEDUCT06) {
		EM_VAR_DEDUCT06 = eM_VAR_DEDUCT06;
	}
	public double getEM_VAR_COV_PCT06() {
		return EM_VAR_COV_PCT06;
	}
	public void setEM_VAR_COV_PCT06(double eM_VAR_COV_PCT06) {
		EM_VAR_COV_PCT06 = eM_VAR_COV_PCT06;
	}
	public double getEM_VAR_DED_PCT06() {
		return EM_VAR_DED_PCT06;
	}
	public void setEM_VAR_DED_PCT06(double eM_VAR_DED_PCT06) {
		EM_VAR_DED_PCT06 = eM_VAR_DED_PCT06;
	}
	public double getEM_VAR_COVERAGE07() {
		return EM_VAR_COVERAGE07;
	}
	public void setEM_VAR_COVERAGE07(double eM_VAR_COVERAGE07) {
		EM_VAR_COVERAGE07 = eM_VAR_COVERAGE07;
	}
	public double getEM_VAR_DEDUCT07() {
		return EM_VAR_DEDUCT07;
	}
	public void setEM_VAR_DEDUCT07(double eM_VAR_DEDUCT07) {
		EM_VAR_DEDUCT07 = eM_VAR_DEDUCT07;
	}
	public double getEM_VAR_COV_PCT07() {
		return EM_VAR_COV_PCT07;
	}
	public void setEM_VAR_COV_PCT07(double eM_VAR_COV_PCT07) {
		EM_VAR_COV_PCT07 = eM_VAR_COV_PCT07;
	}
	public double getEM_VAR_DED_PCT07() {
		return EM_VAR_DED_PCT07;
	}
	public void setEM_VAR_DED_PCT07(double eM_VAR_DED_PCT07) {
		EM_VAR_DED_PCT07 = eM_VAR_DED_PCT07;
	}
	public double getEM_VAR_COVERAGE08() {
		return EM_VAR_COVERAGE08;
	}
	public void setEM_VAR_COVERAGE08(double eM_VAR_COVERAGE08) {
		EM_VAR_COVERAGE08 = eM_VAR_COVERAGE08;
	}
	public double getEM_VAR_DEDUCT08() {
		return EM_VAR_DEDUCT08;
	}
	public void setEM_VAR_DEDUCT08(double eM_VAR_DEDUCT08) {
		EM_VAR_DEDUCT08 = eM_VAR_DEDUCT08;
	}
	public double getEM_VAR_COV_PCT08() {
		return EM_VAR_COV_PCT08;
	}
	public void setEM_VAR_COV_PCT08(double eM_VAR_COV_PCT08) {
		EM_VAR_COV_PCT08 = eM_VAR_COV_PCT08;
	}
	public double getEM_VAR_DED_PCT08() {
		return EM_VAR_DED_PCT08;
	}
	public void setEM_VAR_DED_PCT08(double eM_VAR_DED_PCT08) {
		EM_VAR_DED_PCT08 = eM_VAR_DED_PCT08;
	}
	public double getEM_VAR_COVERAGE09() {
		return EM_VAR_COVERAGE09;
	}
	public void setEM_VAR_COVERAGE09(double eM_VAR_COVERAGE09) {
		EM_VAR_COVERAGE09 = eM_VAR_COVERAGE09;
	}
	public double getEM_VAR_DEDUCT09() {
		return EM_VAR_DEDUCT09;
	}
	public void setEM_VAR_DEDUCT09(double eM_VAR_DEDUCT09) {
		EM_VAR_DEDUCT09 = eM_VAR_DEDUCT09;
	}
	public double getEM_VAR_COV_PCT09() {
		return EM_VAR_COV_PCT09;
	}
	public void setEM_VAR_COV_PCT09(double eM_VAR_COV_PCT09) {
		EM_VAR_COV_PCT09 = eM_VAR_COV_PCT09;
	}
	public double getEM_VAR_DED_PCT09() {
		return EM_VAR_DED_PCT09;
	}
	public void setEM_VAR_DED_PCT09(double eM_VAR_DED_PCT09) {
		EM_VAR_DED_PCT09 = eM_VAR_DED_PCT09;
	}
	public double getEM_VAR_COVERAGE10() {
		return EM_VAR_COVERAGE10;
	}
	public void setEM_VAR_COVERAGE10(double eM_VAR_COVERAGE10) {
		EM_VAR_COVERAGE10 = eM_VAR_COVERAGE10;
	}
	public double getEM_VAR_DEDUCT10() {
		return EM_VAR_DEDUCT10;
	}
	public void setEM_VAR_DEDUCT10(double eM_VAR_DEDUCT10) {
		EM_VAR_DEDUCT10 = eM_VAR_DEDUCT10;
	}
	public double getEM_VAR_COV_PCT10() {
		return EM_VAR_COV_PCT10;
	}
	public void setEM_VAR_COV_PCT10(double eM_VAR_COV_PCT10) {
		EM_VAR_COV_PCT10 = eM_VAR_COV_PCT10;
	}
	public double getEM_VAR_DED_PCT10() {
		return EM_VAR_DED_PCT10;
	}
	public void setEM_VAR_DED_PCT10(double eM_VAR_DED_PCT10) {
		EM_VAR_DED_PCT10 = eM_VAR_DED_PCT10;
	}
	public double getEM_VAR_COVERAGE30() {
		return EM_VAR_COVERAGE30;
	}
	public void setEM_VAR_COVERAGE30(double eM_VAR_COVERAGE30) {
		EM_VAR_COVERAGE30 = eM_VAR_COVERAGE30;
	}
	public double getEM_VAR_DEDUCT30() {
		return EM_VAR_DEDUCT30;
	}
	public void setEM_VAR_DEDUCT30(double eM_VAR_DEDUCT30) {
		EM_VAR_DEDUCT30 = eM_VAR_DEDUCT30;
	}
	public double getEM_VAR_COV_PCT30() {
		return EM_VAR_COV_PCT30;
	}
	public void setEM_VAR_COV_PCT30(double eM_VAR_COV_PCT30) {
		EM_VAR_COV_PCT30 = eM_VAR_COV_PCT30;
	}
	public double getEM_VAR_DED_PCT30() {
		return EM_VAR_DED_PCT30;
	}
	public void setEM_VAR_DED_PCT30(double eM_VAR_DED_PCT30) {
		EM_VAR_DED_PCT30 = eM_VAR_DED_PCT30;
	}
	public double getEM_VAR_COVERAGE31() {
		return EM_VAR_COVERAGE31;
	}
	public void setEM_VAR_COVERAGE31(double eM_VAR_COVERAGE31) {
		EM_VAR_COVERAGE31 = eM_VAR_COVERAGE31;
	}
	public double getEM_VAR_DEDUCT31() {
		return EM_VAR_DEDUCT31;
	}
	public void setEM_VAR_DEDUCT31(double eM_VAR_DEDUCT31) {
		EM_VAR_DEDUCT31 = eM_VAR_DEDUCT31;
	}
	public double getEM_VAR_COV_PCT31() {
		return EM_VAR_COV_PCT31;
	}
	public void setEM_VAR_COV_PCT31(double eM_VAR_COV_PCT31) {
		EM_VAR_COV_PCT31 = eM_VAR_COV_PCT31;
	}
	public double getEM_VAR_DED_PCT31() {
		return EM_VAR_DED_PCT31;
	}
	public void setEM_VAR_DED_PCT31(double eM_VAR_DED_PCT31) {
		EM_VAR_DED_PCT31 = eM_VAR_DED_PCT31;
	}
	public double getEM_VAR_COVERAGE32() {
		return EM_VAR_COVERAGE32;
	}
	public void setEM_VAR_COVERAGE32(double eM_VAR_COVERAGE32) {
		EM_VAR_COVERAGE32 = eM_VAR_COVERAGE32;
	}
	public double getEM_VAR_DEDUCT32() {
		return EM_VAR_DEDUCT32;
	}
	public void setEM_VAR_DEDUCT32(double eM_VAR_DEDUCT32) {
		EM_VAR_DEDUCT32 = eM_VAR_DEDUCT32;
	}
	public double getEM_VAR_COV_PCT32() {
		return EM_VAR_COV_PCT32;
	}
	public void setEM_VAR_COV_PCT32(double eM_VAR_COV_PCT32) {
		EM_VAR_COV_PCT32 = eM_VAR_COV_PCT32;
	}
	public double getEM_VAR_DED_PCT32() {
		return EM_VAR_DED_PCT32;
	}
	public void setEM_VAR_DED_PCT32(double eM_VAR_DED_PCT32) {
		EM_VAR_DED_PCT32 = eM_VAR_DED_PCT32;
	}
	public double getEM_VAR_COVERAGE33() {
		return EM_VAR_COVERAGE33;
	}
	public void setEM_VAR_COVERAGE33(double eM_VAR_COVERAGE33) {
		EM_VAR_COVERAGE33 = eM_VAR_COVERAGE33;
	}
	public double getEM_VAR_DEDUCT33() {
		return EM_VAR_DEDUCT33;
	}
	public void setEM_VAR_DEDUCT33(double eM_VAR_DEDUCT33) {
		EM_VAR_DEDUCT33 = eM_VAR_DEDUCT33;
	}
	public double getEM_VAR_COV_PCT33() {
		return EM_VAR_COV_PCT33;
	}
	public void setEM_VAR_COV_PCT33(double eM_VAR_COV_PCT33) {
		EM_VAR_COV_PCT33 = eM_VAR_COV_PCT33;
	}
	public double getEM_VAR_DED_PCT33() {
		return EM_VAR_DED_PCT33;
	}
	public void setEM_VAR_DED_PCT33(double eM_VAR_DED_PCT33) {
		EM_VAR_DED_PCT33 = eM_VAR_DED_PCT33;
	}
	public double getEM_VAR_COVERAGE34() {
		return EM_VAR_COVERAGE34;
	}
	public void setEM_VAR_COVERAGE34(double eM_VAR_COVERAGE34) {
		EM_VAR_COVERAGE34 = eM_VAR_COVERAGE34;
	}
	public double getEM_VAR_DEDUCT34() {
		return EM_VAR_DEDUCT34;
	}
	public void setEM_VAR_DEDUCT34(double eM_VAR_DEDUCT34) {
		EM_VAR_DEDUCT34 = eM_VAR_DEDUCT34;
	}
	public double getEM_VAR_COV_PCT34() {
		return EM_VAR_COV_PCT34;
	}
	public void setEM_VAR_COV_PCT34(double eM_VAR_COV_PCT34) {
		EM_VAR_COV_PCT34 = eM_VAR_COV_PCT34;
	}
	public double getEM_VAR_DED_PCT34() {
		return EM_VAR_DED_PCT34;
	}
	public void setEM_VAR_DED_PCT34(double eM_VAR_DED_PCT34) {
		EM_VAR_DED_PCT34 = eM_VAR_DED_PCT34;
	}
	public double getEM_VAR_COVERAGE35() {
		return EM_VAR_COVERAGE35;
	}
	public void setEM_VAR_COVERAGE35(double eM_VAR_COVERAGE35) {
		EM_VAR_COVERAGE35 = eM_VAR_COVERAGE35;
	}
	public double getEM_VAR_DEDUCT35() {
		return EM_VAR_DEDUCT35;
	}
	public void setEM_VAR_DEDUCT35(double eM_VAR_DEDUCT35) {
		EM_VAR_DEDUCT35 = eM_VAR_DEDUCT35;
	}
	public double getEM_VAR_COV_PCT35() {
		return EM_VAR_COV_PCT35;
	}
	public void setEM_VAR_COV_PCT35(double eM_VAR_COV_PCT35) {
		EM_VAR_COV_PCT35 = eM_VAR_COV_PCT35;
	}
	public double getEM_VAR_DED_PCT35() {
		return EM_VAR_DED_PCT35;
	}
	public void setEM_VAR_DED_PCT35(double eM_VAR_DED_PCT35) {
		EM_VAR_DED_PCT35 = eM_VAR_DED_PCT35;
	}
	public double getEM_VAR_COVERAGE36() {
		return EM_VAR_COVERAGE36;
	}
	public void setEM_VAR_COVERAGE36(double eM_VAR_COVERAGE36) {
		EM_VAR_COVERAGE36 = eM_VAR_COVERAGE36;
	}
	public double getEM_VAR_DEDUCT36() {
		return EM_VAR_DEDUCT36;
	}
	public void setEM_VAR_DEDUCT36(double eM_VAR_DEDUCT36) {
		EM_VAR_DEDUCT36 = eM_VAR_DEDUCT36;
	}
	public double getEM_VAR_COV_PCT36() {
		return EM_VAR_COV_PCT36;
	}
	public void setEM_VAR_COV_PCT36(double eM_VAR_COV_PCT36) {
		EM_VAR_COV_PCT36 = eM_VAR_COV_PCT36;
	}
	public double getEM_VAR_DED_PCT36() {
		return EM_VAR_DED_PCT36;
	}
	public void setEM_VAR_DED_PCT36(double eM_VAR_DED_PCT36) {
		EM_VAR_DED_PCT36 = eM_VAR_DED_PCT36;
	}
	public double getEM_VAR_COVERAGE37() {
		return EM_VAR_COVERAGE37;
	}
	public void setEM_VAR_COVERAGE37(double eM_VAR_COVERAGE37) {
		EM_VAR_COVERAGE37 = eM_VAR_COVERAGE37;
	}
	public double getEM_VAR_DEDUCT37() {
		return EM_VAR_DEDUCT37;
	}
	public void setEM_VAR_DEDUCT37(double eM_VAR_DEDUCT37) {
		EM_VAR_DEDUCT37 = eM_VAR_DEDUCT37;
	}
	public double getEM_VAR_COV_PCT37() {
		return EM_VAR_COV_PCT37;
	}
	public void setEM_VAR_COV_PCT37(double eM_VAR_COV_PCT37) {
		EM_VAR_COV_PCT37 = eM_VAR_COV_PCT37;
	}
	public double getEM_VAR_DED_PCT37() {
		return EM_VAR_DED_PCT37;
	}
	public void setEM_VAR_DED_PCT37(double eM_VAR_DED_PCT37) {
		EM_VAR_DED_PCT37 = eM_VAR_DED_PCT37;
	}
	public double getEM_VAR_COVERAGE90() {
		return EM_VAR_COVERAGE90;
	}
	public void setEM_VAR_COVERAGE90(double eM_VAR_COVERAGE90) {
		EM_VAR_COVERAGE90 = eM_VAR_COVERAGE90;
	}
	public double getEM_VAR_DEDUCT90() {
		return EM_VAR_DEDUCT90;
	}
	public void setEM_VAR_DEDUCT90(double eM_VAR_DEDUCT90) {
		EM_VAR_DEDUCT90 = eM_VAR_DEDUCT90;
	}
	public double getEM_VAR_COV_PCT90() {
		return EM_VAR_COV_PCT90;
	}
	public void setEM_VAR_COV_PCT90(double eM_VAR_COV_PCT90) {
		EM_VAR_COV_PCT90 = eM_VAR_COV_PCT90;
	}
	public double getEM_VAR_DED_PCT90() {
		return EM_VAR_DED_PCT90;
	}
	public void setEM_VAR_DED_PCT90(double eM_VAR_DED_PCT90) {
		EM_VAR_DED_PCT90 = eM_VAR_DED_PCT90;
	}
	public double getEM_VAR_COVERAGE91() {
		return EM_VAR_COVERAGE91;
	}
	public void setEM_VAR_COVERAGE91(double eM_VAR_COVERAGE91) {
		EM_VAR_COVERAGE91 = eM_VAR_COVERAGE91;
	}
	public double getEM_VAR_DEDUCT91() {
		return EM_VAR_DEDUCT91;
	}
	public void setEM_VAR_DEDUCT91(double eM_VAR_DEDUCT91) {
		EM_VAR_DEDUCT91 = eM_VAR_DEDUCT91;
	}
	public double getEM_VAR_COV_PCT91() {
		return EM_VAR_COV_PCT91;
	}
	public void setEM_VAR_COV_PCT91(double eM_VAR_COV_PCT91) {
		EM_VAR_COV_PCT91 = eM_VAR_COV_PCT91;
	}
	public double getEM_VAR_DED_PCT91() {
		return EM_VAR_DED_PCT91;
	}
	public void setEM_VAR_DED_PCT91(double eM_VAR_DED_PCT91) {
		EM_VAR_DED_PCT91 = eM_VAR_DED_PCT91;
	}
	public double getEM_VAR_COVERAGE97() {
		return EM_VAR_COVERAGE97;
	}
	public void setEM_VAR_COVERAGE97(double eM_VAR_COVERAGE97) {
		EM_VAR_COVERAGE97 = eM_VAR_COVERAGE97;
	}
	public double getEM_VAR_DEDUCT97() {
		return EM_VAR_DEDUCT97;
	}
	public void setEM_VAR_DEDUCT97(double eM_VAR_DEDUCT97) {
		EM_VAR_DEDUCT97 = eM_VAR_DEDUCT97;
	}
	public double getEM_VAR_COV_PCT97() {
		return EM_VAR_COV_PCT97;
	}
	public void setEM_VAR_COV_PCT97(double eM_VAR_COV_PCT97) {
		EM_VAR_COV_PCT97 = eM_VAR_COV_PCT97;
	}
	public double getEM_VAR_DED_PCT97() {
		return EM_VAR_DED_PCT97;
	}
	public void setEM_VAR_DED_PCT97(double eM_VAR_DED_PCT97) {
		EM_VAR_DED_PCT97 = eM_VAR_DED_PCT97;
	}
	public double getEM_VAR_COVERAGE98() {
		return EM_VAR_COVERAGE98;
	}
	public void setEM_VAR_COVERAGE98(double eM_VAR_COVERAGE98) {
		EM_VAR_COVERAGE98 = eM_VAR_COVERAGE98;
	}
	public double getEM_VAR_DEDUCT98() {
		return EM_VAR_DEDUCT98;
	}
	public void setEM_VAR_DEDUCT98(double eM_VAR_DEDUCT98) {
		EM_VAR_DEDUCT98 = eM_VAR_DEDUCT98;
	}
	public double getEM_VAR_COV_PCT98() {
		return EM_VAR_COV_PCT98;
	}
	public void setEM_VAR_COV_PCT98(double eM_VAR_COV_PCT98) {
		EM_VAR_COV_PCT98 = eM_VAR_COV_PCT98;
	}
	public double getEM_VAR_DED_PCT98() {
		return EM_VAR_DED_PCT98;
	}
	public void setEM_VAR_DED_PCT98(double eM_VAR_DED_PCT98) {
		EM_VAR_DED_PCT98 = eM_VAR_DED_PCT98;
	}
	public double getEM_VAR_COVERAGE99() {
		return EM_VAR_COVERAGE99;
	}
	public void setEM_VAR_COVERAGE99(double eM_VAR_COVERAGE99) {
		EM_VAR_COVERAGE99 = eM_VAR_COVERAGE99;
	}
	public double getEM_VAR_DEDUCT99() {
		return EM_VAR_DEDUCT99;
	}
	public void setEM_VAR_DEDUCT99(double eM_VAR_DEDUCT99) {
		EM_VAR_DEDUCT99 = eM_VAR_DEDUCT99;
	}
	public double getEM_VAR_COV_PCT99() {
		return EM_VAR_COV_PCT99;
	}
	public void setEM_VAR_COV_PCT99(double eM_VAR_COV_PCT99) {
		EM_VAR_COV_PCT99 = eM_VAR_COV_PCT99;
	}
	public double getEM_VAR_DED_PCT99() {
		return EM_VAR_DED_PCT99;
	}
	public void setEM_VAR_DED_PCT99(double eM_VAR_DED_PCT99) {
		EM_VAR_DED_PCT99 = eM_VAR_DED_PCT99;
	}
	public double getEM_PROCESS_DATE() {
		return EM_PROCESS_DATE;
	}
	public void setEM_PROCESS_DATE(double eM_PROCESS_DATE) {
		EM_PROCESS_DATE = eM_PROCESS_DATE;
	}
	public double getEM_PROCESS_TIME() {
		return EM_PROCESS_TIME;
	}
	public void setEM_PROCESS_TIME(double eM_PROCESS_TIME) {
		EM_PROCESS_TIME = eM_PROCESS_TIME;
	}
	public double getFMM080_RRN_FIELD_DATA() {
		return FMM080_RRN_FIELD_DATA;
	}
	public void setFMM080_RRN_FIELD_DATA(double fMM080_RRN_FIELD_DATA) {
		FMM080_RRN_FIELD_DATA = fMM080_RRN_FIELD_DATA;
	}
	public String getCov_type() {
		return cov_type;
	}
	public void setCov_type(String cov_type) {
		this.cov_type = cov_type;
	}
	public String getTransaction_type() {
		return transaction_type;
	}
	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}
	public String getPolicy_holder_name() {
		return policy_holder_name;
	}
	public void setPolicy_holder_name(String policy_holder_name) {
		this.policy_holder_name = policy_holder_name;
	}
	public String getAgent_state() {
		return agent_state;
	}
	public void setAgent_state(String agent_state) {
		this.agent_state = agent_state;
	}
	public String getCarrier_address_1() {
		return carrier_address_1;
	}
	public void setCarrier_address_1(String carrier_address_1) {
		this.carrier_address_1 = carrier_address_1;
	}
	public String getAgent_address() {
		return agent_address;
	}
	public void setAgent_address(String agent_address) {
		this.agent_address = agent_address;
	}
	public String getLoan_suffix() {
		return loan_suffix;
	}
	public void setLoan_suffix(String loan_suffix) {
		this.loan_suffix = loan_suffix;
	}
	public String getCarrier_name() {
		return carrier_name;
	}
	public void setCarrier_name(String carrier_name) {
		this.carrier_name = carrier_name;
	}
	public String getAgent_phone() {
		return agent_phone;
	}
	public void setAgent_phone(String agent_phone) {
		this.agent_phone = agent_phone;
	}
	public String getProperty_state() {
		return property_state;
	}
	public void setProperty_state(String property_state) {
		this.property_state = property_state;
	}
	public String getCo_policy_holder_name() {
		return co_policy_holder_name;
	}
	public void setCo_policy_holder_name(String co_policy_holder_name) {
		this.co_policy_holder_name = co_policy_holder_name;
	}
	public String getTransaction_source() {
		return transaction_source;
	}
	public void setTransaction_source(String transaction_source) {
		this.transaction_source = transaction_source;
	}
	public String getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}
	public String getAgent_zip() {
		return agent_zip;
	}
	public void setAgent_zip(String agent_zip) {
		this.agent_zip = agent_zip;
	}
	public String getAgent_name() {
		return agent_name;
	}
	public void setAgent_name(String agent_name) {
		this.agent_name = agent_name;
	}
	public String getImpairment_code() {
		return impairment_code;
	}
	public void setImpairment_code(String impairment_code) {
		this.impairment_code = impairment_code;
	}
	public String getAgent_city() {
		return agent_city;
	}
	public void setAgent_city(String agent_city) {
		this.agent_city = agent_city;
	}
	public String getPolicy_number() {
		return policy_number;
	}
	public void setPolicy_number(String policy_number) {
		this.policy_number = policy_number;
	}
	public String getProperty_city() {
		return property_city;
	}
	public void setProperty_city(String property_city) {
		this.property_city = property_city;
	}
	public String getPayee_code() {
		return payee_code;
	}
	public void setPayee_code(String payee_code) {
		this.payee_code = payee_code;
	}
	public String getProperty_address_2() {
		return property_address_2;
	}
	public void setProperty_address_2(String property_address_2) {
		this.property_address_2 = property_address_2;
	}
	public String getProperty_address_1() {
		return property_address_1;
	}
	public void setProperty_address_1(String property_address_1) {
		this.property_address_1 = property_address_1;
	}
	public String getAccount_tax_id() {
		return account_tax_id;
	}
	public void setAccount_tax_id(String account_tax_id) {
		this.account_tax_id = account_tax_id;
	}
	public String getAccount_number() {
		return account_number;
	}
	public void setAccount_number(String account_number) {
		this.account_number = account_number;
	}
	public String getEscrow_indicator() {
		return escrow_indicator;
	}
	public void setEscrow_indicator(String escrow_indicator) {
		this.escrow_indicator = escrow_indicator;
	}
	public String getAgency_number() {
		return agency_number;
	}
	public void setAgency_number(String agency_number) {
		this.agency_number = agency_number;
	}
	public String getLoan_number() {
		return loan_number;
	}
	public void setLoan_number(String loan_number) {
		this.loan_number = loan_number;
	}
	public String getProperty_zip() {
		return property_zip;
	}
	public void setProperty_zip(String property_zip) {
		this.property_zip = property_zip;
	}
	public String getTransaction_status() {
		return transaction_status;
	}
	public void setTransaction_status(String transaction_status) {
		this.transaction_status = transaction_status;
	}
	public String getCarrier_phone() {
		return carrier_phone;
	}
	public void setCarrier_phone(String carrier_phone) {
		this.carrier_phone = carrier_phone;
	}
	public String getMortgagee_state() {
		return mortgagee_state;
	}
	public void setMortgagee_state(String mortgagee_state) {
		this.mortgagee_state = mortgagee_state;
	}
	public String getMailing_zip() {
		return mailing_zip;
	}
	public void setMailing_zip(String mailing_zip) {
		this.mailing_zip = mailing_zip;
	}
	public String getInstitution_code() {
		return institution_code;
	}
	public void setInstitution_code(String institution_code) {
		this.institution_code = institution_code;
	}
	public String getCarrier_state() {
		return carrier_state;
	}
	public void setCarrier_state(String carrier_state) {
		this.carrier_state = carrier_state;
	}
	public String getMortgagee_address() {
		return mortgagee_address;
	}
	public void setMortgagee_address(String mortgagee_address) {
		this.mortgagee_address = mortgagee_address;
	}
	public String getCarrier_city() {
		return carrier_city;
	}
	public void setCarrier_city(String carrier_city) {
		this.carrier_city = carrier_city;
	}
	public String getMortgagee_city() {
		return mortgagee_city;
	}
	public void setMortgagee_city(String mortgagee_city) {
		this.mortgagee_city = mortgagee_city;
	}
	public String getPolicy_cancel_reason() {
		return policy_cancel_reason;
	}
	public void setPolicy_cancel_reason(String policy_cancel_reason) {
		this.policy_cancel_reason = policy_cancel_reason;
	}
	public String getMailing_city() {
		return mailing_city;
	}
	public void setMailing_city(String mailing_city) {
		this.mailing_city = mailing_city;
	}
	public String getMortgagee_name() {
		return mortgagee_name;
	}
	public void setMortgagee_name(String mortgagee_name) {
		this.mortgagee_name = mortgagee_name;
	}
	public String getMortgagee_zip() {
		return mortgagee_zip;
	}
	public void setMortgagee_zip(String mortgagee_zip) {
		this.mortgagee_zip = mortgagee_zip;
	}
	public String getClient_number() {
		return client_number;
	}
	public void setClient_number(String client_number) {
		this.client_number = client_number;
	}
	public String getMailing_state() {
		return mailing_state;
	}
	public void setMailing_state(String mailing_state) {
		this.mailing_state = mailing_state;
	}
	public String getMailing_address() {
		return mailing_address;
	}
	public void setMailing_address(String mailing_address) {
		this.mailing_address = mailing_address;
	}
	public String getCarrier_zip() {
		return carrier_zip;
	}
	public void setCarrier_zip(String carrier_zip) {
		this.carrier_zip = carrier_zip;
	}
	public String getQc_response_code() {
		return qc_response_code;
	}
	public void setQc_response_code(String qc_response_code) {
		this.qc_response_code = qc_response_code;
	}
	public String getScan_id() {
		return scan_id;
	}
	public void setScan_id(String scan_id) {
		this.scan_id = scan_id;
	}
	public String getOrig_file_name() {
		return orig_file_name;
	}
	public void setOrig_file_name(String orig_file_name) {
		this.orig_file_name = orig_file_name;
	}
	public String getAccount_name() {
		return account_name;
	}
	public void setAccount_name(String account_name) {
		this.account_name = account_name;
	}
	public String getDocument_type() {
		return document_type;
	}
	public void setDocument_type(String document_type) {
		this.document_type = document_type;
	}
	public String getLoan_type() {
		return loan_type;
	}
	public void setLoan_type(String loan_type) {
		this.loan_type = loan_type;
	}
	public String getIs_qc_candidate() {
		return is_qc_candidate;
	}
	public void setIs_qc_candidate(String is_qc_candidate) {
		this.is_qc_candidate = is_qc_candidate;
	}
	public String getAgent_email() {
		return agent_email;
	}
	public void setAgent_email(String agent_email) {
		this.agent_email = agent_email;
	}
	public String getFollow_up_reason() {
		return follow_up_reason;
	}
	public void setFollow_up_reason(String follow_up_reason) {
		this.follow_up_reason = follow_up_reason;
	}
	public String getDocument_sub_type() {
		return document_sub_type;
	}
	public void setDocument_sub_type(String document_sub_type) {
		this.document_sub_type = document_sub_type;
	}
	public String getSRC_Agency() {
		return SRC_Agency;
	}
	public void setSRC_Agency(String sRC_Agency) {
		SRC_Agency = sRC_Agency;
	}

	

}
