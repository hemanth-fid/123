package org.ifc.idocs.migration.helper;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.logging.Level;

import org.ifc.idocs.migration.importUtility.ImportUtility;

import com.aspose.words.BookmarkCollection;
import com.aspose.words.CompositeNode;
import com.aspose.words.CustomDocumentProperties;
import com.aspose.words.Document;
import com.aspose.words.DocumentProperty;
import com.aspose.words.Footnote;
import com.aspose.words.FootnoteType;
import com.aspose.words.FormField;
import com.aspose.words.FormFieldCollection;
import com.aspose.words.HeaderFooter;
import com.aspose.words.HeaderFooterCollection;
import com.aspose.words.HeaderFooterType;
import com.aspose.words.License;
import com.aspose.words.Node;
import com.aspose.words.NodeCollection;
import com.aspose.words.PropertyType;
import com.aspose.words.ProtectionType;
import com.aspose.words.SaveFormat;
import com.aspose.words.Section;
import com.aspose.words.SectionCollection;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfLoginInfo;



public class UpdateRefreshDataURL extends ImportUtility{

	
	public static void updateRefreshDataURLs() {
		// TODO Auto-generated method stub
		
		try {
			StringTokenizer sTokenizerCtryCodes = new StringTokenizer(config.getString("refreshData.refreshDataURLCtry"),",");
			while(sTokenizerCtryCodes.hasMoreTokens()){
				String refreshCryCode = sTokenizerCtryCodes.nextToken();
				String strQuery = idocsProperties.getProperty("MSG_GET_TEMPLATE_DOC_IDS");
				strQuery = strQuery.replaceFirst("<country_code>",refreshCryCode);
				updateRepositoryTemplates(dfSession, strQuery, idocsProperties.getProperty("MSG_REFRESH_DATA_INV_OPS_URL"), idocsProperties.getProperty("MSG_REFRESH_DATA_ADV_SERV_URL"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("Exception while updating refresh Data URL");
			importDocLogger.log(Level.WARNING,"Exception while updating refresh Data URL::"+ e);
			e.printStackTrace();
		}
	}
	
	/*private static void displayRepositoryTemplates(IDfSession dfSession, String strQuery) throws Exception{

		
		File licenseFile = new File("/Aspose.Words.lic");
		if (licenseFile.exists()){
			License license = new License();
			license.setLicense("/Aspose.Words.lic");	
			System.out.println("updateWordDocument :: licence exists...");
		}
		String strObjectId = "";
		String strObjectName= "";
		
		//String strQuery = "select * from idocs_project_doc where folder('/Templates/iDocs') and object_name = 'Environmental and Social Review Summary'";
		System.out.println("strQuery : "+strQuery);
		
		
		IDfCollection dfCollection = Utilities.executeQuery(dfSession, strQuery, IDfQuery.DF_READ_QUERY);
		int docCount = 0;
		CustomDocumentProperties customDocProp = null;
		while (dfCollection.next() && (docCount<10)){
			
			strObjectId = dfCollection.getString("r_object_id");
			System.out.println("strObjectId : "+strObjectId);			
			strObjectName = dfCollection.getString("object_name");
			System.out.println("strObjectName : "+strObjectName);
			System.out.println("Modified Date : "+dfCollection.getString("r_modify_date"));
			
			System.out.println(">>>>>>>>>>> Object Name ["+docCount+"]\t: "+strObjectName);
			
			IDfId dfid = new DfId(strObjectId);				
			IDfDocument dfDocument = (IDfDocument) dfSession.getObject(dfid);
			
			Document wordDoc = new Document(dfDocument.getContent());
			//wordDoc.unprotect();
			customDocProp = wordDoc.getCustomDocumentProperties();			
			System.out.println("Custom Document Properties Count \t:<<<<<<"+customDocProp.getCount()+">>>>>>>");
			if (customDocProp.contains("RefreshDataURL")){
				System.out.println("RefreshDataURL : "+customDocProp.get("RefreshDataURL"));
			}else{
				System.out.println("Custom Document Property, RefreshDataURL, does not exist!!!");
			}
			
			docCount++;
			System.out.println("#####################################################################");
		} // End of while loop..
		
		if (dfCollection!=null)
			dfCollection.close();
	}*/
	
private static ArrayList<String> fetchProjDocDetails(IDfSession dfSession,
			String strQuery) throws DfException{
		// TODO Auto-generated method stub
	IDfCollection dfCollection;
	ArrayList<String> objDetailsArray = new ArrayList<String>();
	
		dfCollection = Utilities.executeQuery(dfSession, strQuery, IDfQuery.DF_READ_QUERY);
		//HashMap<String, String> projCategoryMap = new HashMap<String, String>(); 
		String docRObjID = "";
		String docObjCateGory = "";
		while (dfCollection.next()){
			docRObjID = dfCollection.getString("r_object_id");
			docObjCateGory = dfCollection.getString("doc_category");
			objDetailsArray.add(docRObjID+"#"+docObjCateGory);
			//projCategoryMap.put(strProjectId, strProjectCategory);
		}
		if (dfCollection!=null)
			dfCollection.close();
	return objDetailsArray;
}

public static void updateRepositoryTemplates(IDfSession dfSession, String strQuery, String IFCDocsRefreshDataInvOpsURL, String IFCDocsRefreshDataAdvServURL) throws Exception{
		
		File licenseFile = new File("/Aspose.Words.lic");
		if (licenseFile.exists()){
			License license = new License();
			//license.setLicense(ASPOSE_LIBRARY_FOLDER+"//Aspose.Words.lic");	
			license.setLicense("/Aspose.Words_Tst.lic");
//			System.out.println("updateWordDocument :: licence exists...");
			importDocLogger.warning("updateWordDocument :: licence exists...");
		}
		String strObjectId = "";
		String documentCategory = "";
//		String strObjectName= "";
		CustomDocumentProperties customDocProp = null;
		ArrayList<String> docRObjectIDs = fetchProjDocDetails(dfSession,strQuery);
		for(int k=0;k<docRObjectIDs.size();k++){
			String[] objDetails = docRObjectIDs.get(k).split("#");
			strObjectId = objDetails[0];
			documentCategory = objDetails[1];
			importDocLogger.warning("Processing docObjectID::["+strObjectId+"]::Doc Category::["+documentCategory+"]::CNT::["+k+"]");
//			IDfCollection dfCollection = Utilities.executeQuery(dfSession, strQuery, IDfQuery.DF_READ_QUERY);
//			int docCount = 0;
		
//		while (dfCollection.next()){
//			docCount++;
//			strObjectId = dfCollection.getString("r_object_id");
//			documentCategory = dfCollection.getString("doc_category");
//			strObjectName = dfCollection.getString("object_name");
//			System.out.println(">>>>>>>>>>> Object Name ["+docCount+"]\t: "+strObjectName);
//			importDocLogger.warning("Processing docObjectID::["+strObjectId+"]::Doc Category::["+documentCategory+"]::CNT::["+docCount+"]");
//			System.out.println("strObjectId["+docCount+"] \t: "+strObjectId);
//			System.out.println("Modified Date \t: "+dfCollection.getString("r_modify_date"));

			try{
				IDfId dfid = new DfId(strObjectId);				
				IDfDocument dfDocument = (IDfDocument) dfSession.getObject(dfid);
				Document wordDoc = new Document(dfDocument.getContent());
				wordDoc.unprotect();
				customDocProp = wordDoc.getCustomDocumentProperties();
				String strRefreshDataURL = "";

				if (customDocProp.contains("RefreshDataURL")){
					strRefreshDataURL = customDocProp.get("RefreshDataURL").toString();
					
					// ********************** This code needs to be modified as part of migration
					if (documentCategory.equals("Investment Operations") && strRefreshDataURL.equals(IFCDocsRefreshDataInvOpsURL)){						
						importDocLogger.warning("Existing Refresh Data URL matching with the new URL to be updated");
					}else if (documentCategory.equals("Advisory Services") && strRefreshDataURL.equals(IFCDocsRefreshDataAdvServURL)){						
						importDocLogger.warning("Existing Refresh Data URL matching with the new URL to be updated");
					}else{
						customDocProp.remove("RefreshDataURL");
						if(documentCategory.equals("Investment Operations")){
							customDocProp.add("RefreshDataURL", IFCDocsRefreshDataInvOpsURL);
						}else{
							customDocProp.add("RefreshDataURL", IFCDocsRefreshDataAdvServURL);
						}
						ByteArrayOutputStream baoStream = new ByteArrayOutputStream();
						wordDoc.protect(2, "IFC CONFIDENTIAL");
						wordDoc.save(baoStream, SaveFormat.DOC);
						
						//Checkout the document and again save the same
						if (!dfDocument.isCheckedOut()){					
							dfDocument.checkout();
						}
						dfDocument.setContent(baoStream);
						dfDocument.setString(idocsProperties.getProperty("MSG_DOC_IS_MIGRATED"), "T");
						dfDocument.save();				
					}
				}else{
					importDocLogger.warning("Custom Document Property, RefreshDataURL, does not exist!!!");
//					System.out.println("Custom Document Property, RefreshDataURL, does not exist!!!");
				}
				
			}catch(DfException dfException){
				dfException.printStackTrace();
			}
		} // End of while loop..
		/*if (dfCollection!=null)
			dfCollection.close();*/
	} // End of updateRepositoryTemplates()
}
