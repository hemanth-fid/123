package org.ifc.idocs.forms.adaptors;

import com.documentum.fc.common.DfLogger;
import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.IAdaptorParameter;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.xforms.engine.adaptor.datasource.ISetValueAdaptor;

public class SetForm3ValidationRequired
    implements ISetValueAdaptor
{
    public Object execute(IAdaptorParameter parameters[])
        throws AdaptorException
    {
        DfLogger.info(this,"SetForm1ValidationRequired:: SetForm1ValidationRequired",null,null); 
        String validationRequired = "form3";
        return validationRequired;
    }

    public void destroy()
        throws AdaptorException
    {
    }

    public void init(IAdaptorConfiguration iadaptorconfiguration)
        throws AdaptorException
    {
    }
}
