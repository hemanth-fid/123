package org.ifc.idocs.crr;

import java.io.IOException;
import java.util.Properties;

import org.ifc.idocs.utils.IdocsConstants;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.Button;
import com.documentum.web.form.control.Label;
import com.documentum.web.formext.component.Component;

public class LinkToPSR extends Component {

	private String m_objectId;
	static Properties idocsProperties = new Properties();

	private static final long serialVersionUID = 1L;
	public static String drl = "";
	private static String m_message="";

	public LinkToPSR() {
		m_objectId = "";
	}

	public void onInit(ArgumentList args) {
		try {
			super.onInit(args);
			IDfSession dfsession = getDfSession();
			String userName = dfsession.getLoginUserName();
			DfLogger.info(this, " :: onInit : " + userName, null, null);
			m_objectId = args.get("objectId");
			IDfDocument psrDoc = (IDfDocument) dfsession.getObject(new DfId(m_objectId));
			String version = psrDoc.getString("r_version_label");
			version = version.replaceFirst(",CURRENT", "");
			psrDoc.getObjectName();
			String description = psrDoc.getString("description");
			String robjectId = psrDoc.getString("r_object_id");
			String title = psrDoc.getObjectName();
			String ownerName = psrDoc.getString("owner_name");
			String dtCreated = psrDoc.getString("r_creation_date");
			DfLogger.info(this, " :: onInit : ObjectID : "+m_objectId, null, null);
			idocsProperties.load(LinkToPSR.class.getResourceAsStream(IdocsConstants.IDOCS_PROPERTY_FILE));
			drl = idocsProperties.getProperty("IDOCS_DEV_DRL");
			drl = drl + m_objectId;

			DfLogger.info(this, "robjectId: " + robjectId, null, null);
			DfLogger.info(this, "version: " + version, null, null);
			DfLogger.info(this, "title: " + title, null, null);
			DfLogger.info(this, "description: " + description, null, null);
			DfLogger.info(this, "ownerName: " + ownerName, null, null);
			DfLogger.info(this, "dtCreated: " + dtCreated, null, null);

			String strConst = "','";
			
			StringBuffer qryBuffer = new StringBuffer();
			qryBuffer = qryBuffer.append(idocsProperties.getProperty("MSG_UTILITY_DOC_INSERT_QUERY"));
			qryBuffer.append(robjectId);
			qryBuffer.append(strConst);
			qryBuffer.append(version);
			qryBuffer.append(strConst);
			qryBuffer.append(title);
			qryBuffer.append(strConst);
			qryBuffer.append(description);
			qryBuffer.append(strConst);
			qryBuffer.append(drl);
			qryBuffer.append("',date(today),'");
			qryBuffer.append(ownerName+"')");
			
			DfLogger.info(this, "insertQry: " + qryBuffer.toString(), null, null);
			IDfQuery query = new DfQuery();
			query.setDQL(qryBuffer.toString());
			query.execute(dfsession, DfQuery.EXECREAD_QUERY);
			DfLogger.info(this, "ViewDRL :: onInit : DRL : " + drl, null, null);
			m_message = "Document Linked to PSR Successfully";
			
		} catch (IOException e) {
			DfLogger.error(this, "ViewDRL :: onInit Exception >> "
					+ e.getMessage(), null, e);
			m_message = "Document Failed to link to PSR Error : "+e.getMessage();
		} catch (DfException e) {
			DfLogger.error(this, "ViewDRL :: onInit Exception >> "
					+ e.getMessage(), null, e);
			m_message = "Document Failed to link to PSR Error : "+e.getMessage();
		}
		Label finalMessage = (Label)getControl("finalMessage", Label.class);
		finalMessage.setLabel(m_message);
	}

	public void onClose(Button control, ArgumentList args) {
		setComponentReturn();
	}
}
