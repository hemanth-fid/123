package sf.application.custcomm.ccs.core;

import static java.util.concurrent.TimeUnit.SECONDS;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import org.apache.log4j.Logger;

import sf.application.custcomm.ccs.constants.CleanUpConstants;
import sf.application.custcomm.ccs.constants.QueryConstants;
import sf.application.custcomm.ccs.dao.ICleanUpQueryDao;
import sf.application.custcomm.ccs.dao.impl.CleanUpQueryDao;
import sf.application.custcomm.ccs.exceptions.CleanUpServiceException;
import sf.application.custcomm.ccs.purge.PurgeDataCleanupThread;
import sf.application.custcomm.ccs.util.CommonUtils;
import sf.application.custcomm.ccs.util.DocumentumUtils;
import sf.application.custcomm.ccs.util.FileOperationUtils;
import sf.application.custcomm.ccs.util.SortFilter;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfLogger;
import com.emciig.utils.SessionUtils;

public class PurgeDataCleanupService implements Runnable {

	private Map<String, String> parameters;
	private ScheduledExecutorService scheduler;
	private static final String NEW_LINE_SEPARATOR = "\n";
	ICleanUpQueryDao cleanUpQueryDao = null;
	int numOfFolderIdsPerServer = 0;
	private static final Logger LOGGER = DfLogger.getLogger(PurgeDataCleanupService.class);

	/**
	 * Constructor
	 * 
	 * @param params
	 * @param scheduler
	 * @param registeredObject
	 */
	public PurgeDataCleanupService(Map<String, String> params, ScheduledExecutorService scheduler) {

		this.parameters = params;
		this.scheduler = scheduler;

	}

	/**
	 * An unimplemented method inherited from class Runnable which gets
	 * automatically invoked when ExecuteTimerActivities class is instantiated
	 */
	public void run() {

		if (DfLogger.isTraceEnabled(this)) {
			DfLogger.trace(this, "Method CleanupService run() entry", null, null);
		}

		try {

			performOperation(parameters);

		} catch (CleanUpServiceException cleanUpServiceException) {

			LOGGER.error(cleanUpServiceException.getMessage(), cleanUpServiceException);

		} finally {

			scheduleNextRun();

		}

		if (DfLogger.isTraceEnabled(this)) {
			DfLogger.trace(this, "Method CleanupService run() exit", null, null);
		}

	}

	/**
	 * It determines the next run time.
	 * 
	 * 
	 */
	private void scheduleNextRun() {

		if (DfLogger.isTraceEnabled(this)) {
			DfLogger.trace(this, "Method scheduleNextRun() entry", null, null);
		}

		int timerseconds = Integer.parseInt(parameters.get(CleanUpConstants.PARAM_NEXT_RUN_TIME));
		scheduler.schedule(new PurgeDataCleanupService(parameters, scheduler), timerseconds, SECONDS);

		if (DfLogger.isTraceEnabled(this)) {
			DfLogger.trace(this, "Method scheduleNextRun() exit", null, null);
		}

	}

	private void performOperation(Map<String, String> params)  {

		if (DfLogger.isTraceEnabled(this)) {
			DfLogger.trace(this, "Method performOperation() entry", null, null);
		}

		File[] destroyFiles = getTopFiles();
		LOGGER.info("The number of files to be assigned to purge data threads " + destroyFiles.length);

		assignToPurgeDataThreads(destroyFiles);
		assignToPurgeDataThreads(getFilesFromRepo());
		deleteFilesEdcCleanupFolder();

		if (DfLogger.isTraceEnabled(this)) {
			DfLogger.trace(this, "Method performOperation() exit", null, null);
		}

	}

	private void assignToPurgeDataThreads(File[] destroyFiles) {

		ExecutorService executor = Executors.newFixedThreadPool(10);

		for (int i = 0; i < destroyFiles.length; i++) {

			Runnable worker = new PurgeDataCleanupThread(destroyFiles[i], parameters);
			executor.execute(worker);

		}

		executor.shutdown();

	}

	private void assignToPurgeDataThreads(List<String> fileObjectids) {

		ExecutorService executor = Executors.newFixedThreadPool(10);
		for (String fileObjectId : fileObjectids) {

			Runnable worker = new PurgeDataCleanupThread(fileObjectId, parameters);
			executor.execute(worker);

		}

		executor.shutdown();

	}

	private File[] getTopFiles() {

		File dir = new File(parameters.get("drive") + ":\\" + parameters.get("edc_cleanup_folder_path")
				+ parameters.get("ready_to_process"));
		SortFilter filter = new SortFilter(10);
		int length = dir.listFiles(filter).length;
		if (length > 10) {
			File[] topFiles = new File[10];
			return filter.topFiles.toArray(topFiles);
		} else {
			File[] topFiles = new File[length];
			return filter.topFiles.toArray(topFiles);
		}

	}

	private void deleteFilesEdcCleanupFolder() {

		deleteFilesFromCompletedFolder();
		deleteFilesFromErrorFolder();
	}

	// delete files from edc cleanup 'completed' folder which are older then x days
	private void deleteFilesFromCompletedFolder() {

		String path = parameters.get("drive") + ":\\" + parameters.get("edc_cleanup_folder_path")
				+ parameters.get("completed");
		FileOperationUtils.deleteFiles(path,
				Integer.valueOf(parameters.get("completed_files_retention_period")).intValue());

	}

	// delete files from edc cleanup 'error' folder which are older then x days
	private void deleteFilesFromErrorFolder() {

		String path = parameters.get("drive") + ":\\" + parameters.get("edc_cleanup_folder_path")
				+ parameters.get("error");
		FileOperationUtils.deleteFiles(path,
				Integer.valueOf(parameters.get("error_files_retention_period")).intValue());

	}

	private List<String> getFilesFromRepo() {

		IDfSession idfSession = null;
		List<String> fileObjectids = null;
		try {
			idfSession = DocumentumUtils.getSession(parameters);
			cleanUpQueryDao = new CleanUpQueryDao();
			fileObjectids = cleanUpQueryDao.getFilesFromRepo(idfSession, QueryConstants.QRY_READ_FILES_REPO,
					new Object[] { CommonUtils.getLocalHostName().toUpperCase(), "New" });
			LOGGER.info("RepoFiles " + fileObjectids);
		} catch (Exception e) {
			LOGGER.error("Error", e);
		} finally {

			SessionUtils.disconnect(idfSession);

		}

		return fileObjectids;
	}

}