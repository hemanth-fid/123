package com.swbc.letters.commercial.migrate.dbutils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

public class DataBaseConnUtils {

	private static final Logger LOGGER = Logger
			.getLogger(DataBaseConnUtils.class);

	public static Connection createDBConnection(String dbURL,
			String dbUserName, String dbPassword, String dbDriver)
			throws ClassNotFoundException, SQLException {

		
		Connection conn = null;

		try {
			Class.forName(dbDriver);
			conn = DriverManager.getConnection(dbURL, dbUserName, dbPassword);

			System.out
					.println("Database Connection established, connected to DB URL '"
							+ dbURL + "' for User '" + dbUserName + "'");
			LOGGER.info("Database Connection established, connected to DB URL '"
					+ dbURL + "' for User '" + dbUserName + "'");

		} catch (ClassNotFoundException cnfe) {
			LOGGER.error(cnfe);
			throw cnfe;
		} catch (SQLException sqe) {
			LOGGER.error(sqe);
			throw sqe;
		}

		LOGGER.info("Database Connection Created for [" + dbDriver + "] : "
				+ conn.toString());
		return conn;
	}

	public static void closeDBConnection(Connection conn) throws SQLException {
		try {
			if (conn != null)
				LOGGER.debug("Releasing db connection");
				conn.close();
		} catch (SQLException sqe) {
			throw sqe;
		}
	}

	public static boolean executeUpdateQryInDB(Connection dbConn,
			String updateQry, boolean testMode) throws SQLException {

		boolean isUpdate=false;
		

		Statement stmt = null;
		try {
			if (!testMode) {
				stmt = dbConn.createStatement();
				if(stmt.executeUpdate(updateQry)>0){
					isUpdate=true;
				}
				
			}
		} catch (SQLException sqe) {
			throw new SQLException("SQLException in executeUpdateQryInDB() : "
					+ sqe.getMessage());
		} finally {
			if (null != stmt)
				stmt.close();
		}
		
		return isUpdate;
	}

	public static void executeInsertQryInDB(Connection dbConn,
			String insertQry, boolean testMode) throws SQLException {

		

		Statement stmt = null;
		try {
			if (!testMode) {
				stmt = dbConn.createStatement();
				stmt.executeUpdate(insertQry);
			}
		} catch (SQLException sqe) {
			throw new SQLException("SQLException in executeInsertQryInDB() : "
					+ sqe.getMessage());
		} finally {
			if (null != stmt)
				stmt.close();
		}
	}

	public static ResultSet executeSelectQryInDB(Connection dbConn,
			String selectQry) throws SQLException {

		

		Statement stmt = null;
		ResultSet result = null;
		try {
			stmt = dbConn.createStatement();
			result = stmt.executeQuery(selectQry);
		} catch (SQLException sqe) {
			throw new SQLException("SQLException in executeSelectQryInDB() : "
					+ sqe.getMessage());
		}
		return result;
	}

	public static void executeDeleteQryInDB(Connection dbConn,
			String deleteQry, boolean testMode) throws SQLException {

		

		Statement stmt = null;

		try {
			if (!testMode) {
				stmt = dbConn.createStatement();
				stmt.executeUpdate(deleteQry);
			}
		} catch (SQLException sqe) {
			throw new SQLException("SQLException in executeDeleteQryInDB() : "
					+ sqe.getMessage());
		}

	}
	
	public static void closeRS(ResultSet rs) throws SQLException {
	
		if(rs!=null && !rs.isClosed()){
			rs.close();
		}
		
	}
	
}
