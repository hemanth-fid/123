/**
 * IDocsCheckoutActionPrecondition - Precondition to disable the Edit option  
 * disabled for documents which are in released state.
 * 
 * @author SKurian1
 * 
 * #####################################################################
 * Author		DateofChange	Version		ModificationHistory
 * #####################################################################
 * 
 * #####################################################################
 */
package org.ifc.idocs.environment.actions;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.action.IActionPrecondition;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

/**
 * This class will check if the document can be edited by the current
 * user.
 * Conditions
 * 	When the Document is in released state.
 * 		If the Security Classification is 'Official Use Only'
 * 
 * @author SKurian1
 *
 */
public class IDocsCheckoutActionPrecondition implements IActionPrecondition {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Documentum Architecture method to find the requiredParameter for this 
	 * precondition.
	 */
	public String[] getRequiredParams() {
		String[] params = new String[1];
		params[0] = "objectId";
		return params;
	}

	/**
	 * This is a precondition execution method to check the visibility of 
	 * Checkout option for idocs_documents in released state.
	 */
	public boolean queryExecute(String paramString,
			IConfigElement paramIConfigElement, ArgumentList paramArgumentList,
			Context paramContext, Component paramComponent) {
		boolean returnValue = false;
		if(returnValue){
			try {
				String strObjectId = paramArgumentList.get("objectId");
				DfLogger.error(this, " : queryExecute : Parameter strObjectId : " + strObjectId, null, null);
				if(strObjectId!=null && strObjectId.trim().length() > 0 && strObjectId.startsWith("09")
						&& (IDocsConstants.MSG_DRAFT_STATE_NUMBER.equalsIgnoreCase(IDocDocbaseAttributeTagUtility
								.getDocumentState(paramComponent.getDfSession(), strObjectId)) == false)){
					DfLogger.error(this, " : queryExecute : Check Precondition", null, null);
					returnValue = IDocDocbaseAttributeTagUtility.canEditableInReleasedState(paramComponent.getDfSession(),strObjectId, true);
				}else{
					DfLogger.error(this, " : queryExecute : Document Is Invalid or its not in Released state : Precondition SUCCESS", null, null);
					returnValue =  true ; 
				}
			} catch (Exception e) {
				e.printStackTrace();
				DfLogger.error(this, " : queryExecute Exception ", null, null);
			}
		}else{
			DfLogger.error(this, " : queryExecute() returnValue  is false already ", null, null);
		}
		return returnValue;
	}	
}
