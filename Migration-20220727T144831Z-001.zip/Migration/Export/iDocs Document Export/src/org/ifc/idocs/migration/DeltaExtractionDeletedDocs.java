package org.ifc.idocs.migration;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import lotus.domino.Database;
import lotus.domino.DateTime;
import lotus.domino.DbDirectory;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.ViewEntryCollection;

import org.ifc.idocs.migration.common.AppConfig;
import org.ifc.idocs.migration.extract.DBConnection;
import org.ifc.idocs.migration.extract.LogHelper;
import org.ifc.idocs.migration.extract.NotesSession;

public class DeltaExtractionDeletedDocs {

	public DeltaExtractionDeletedDocs() throws IOException, NotesException {

		AppConfig config = AppConfig.getInstance();
		Logger exportDocLogger = LogHelper.getLogger(DeltaExtractionDeletedDocs.class);
		Database DbLog = null;
		java.sql.Date replicaDate = null;
		
		try {
			String server = config.getString("repository.server");
			String replicaCode = null, extractionId = null;
			DbDirectory dbdir  =  NotesSession.getInstance().getDbDirectory(server);
			String LogDbName = config.getString("repository.DeletionLogPath");
			extractionId= config.getString("filters.extractioncriteriacode");
			String[] extInfo = DBConnection.getExtractionInfo(extractionId);
			try{
				if(extInfo != null){
					replicaCode = extInfo[5];
					System.out.println("replicaCode = " + replicaCode);
				}
				ResultSet rs=DBConnection.getReplicaDate(replicaCode);
				try {
					while(rs.next()){
						replicaDate = rs.getDate("REPLICATION_START_DATE");
					}
					rs.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
					exportDocLogger.log(Level.WARNING, "getReplicaDate~-Exception", e1);
				} 
				try{
					DbLog = dbdir.openDatabase(LogDbName);
				}
				catch(NotesException e){
					exportDocLogger.log(Level.WARNING,"PLEASE ENSURE THAT CUSTOM VIEW IS PRESENT IN DELETION LOG DATABASE", e);
					System.exit(1);
				}
				View mainView  =  DbLog.getView("Delete_Agent_Activity");
				ViewEntryCollection viewcol=mainView.getAllEntries();
				Integer totalCount = viewcol.getCount();
				exportDocLogger.warning("Total entries in the deletion view="+totalCount);
				Document doc = mainView.getFirstDocument();
				String action = null, search = "Notes Document Universal ID = ";
				Integer i = 0;
				String[] unid=null;
				String idForUpload = null;
				Integer processed =0,deleted=0;
				java.util.Date date = new java.util.Date(replicaDate.getTime());
				DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
				String date1 = formatter.format(date);
				DateTime cutoff = null;
				Session session =  NotesSession.getInstance();
				try {
					cutoff = session.createDateTime(date1);
				} catch(Exception e) {
					e.printStackTrace();
					exportDocLogger.log(Level.WARNING, "DateFormatting~-Exception", e);
				}
				ArrayList<String> docIds = new ArrayList<String>();
				while(doc != null){					
					DateTime cDate = doc.getCreated();
					if(cDate.timeDifference(cutoff) > 0){
						action = doc.getItemValueString("A$ACTION");
						i = action.indexOf(search);
						if(i != -1){		
							unid = action.split("Notes Document Universal ID =");
							idForUpload = unid[1].trim();
							docIds.add(idForUpload);
							exportDocLogger.warning(idForUpload+ " replica date = " + date1 + " : Created Date = " + cDate + ": TimeDiff = " + cDate.timeDifference(cutoff) + " needs to be deleted");
						}
						deleted = deleted + 1;
						doc = mainView.getNextDocument(doc);
					}
					processed = processed + 1;
				}
				
				try {
					DBConnection.updateDeltaDeletedDocs(docIds);
				} catch (IOException e) {
					e.printStackTrace();
					exportDocLogger.log(Level.WARNING, "Error updating deletion table ~ IOException", e);
				}
				exportDocLogger.warning("Updated deletion entries to table. Processed = " + processed + " : Deleted = " + deleted);
			}
			catch(NotesException e){
				if(e.id == 4043){
					exportDocLogger.warning("ENSURE THAT CUSTOM VIEW IS PRESENT IN DELETION LOG FILE");
				}
				exportDocLogger.log(Level.WARNING, "~NotesException", e);
			}

		}
		finally{
			NotesSession.terminate();
		}
	}
}
