package org.ifc.idocs.report.export;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import lotus.domino.DateTime;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;

import org.ifc.idocs.report.model.DomdocRepository;

/**
 * @author SPankajamsadanan
 *
 */
public class DomdocFolder {

	private String folderkey;
	private Document doc;
	private DomdocRepository domdoc;
	
	private static Map<String,DomdocStorageDb> storageDbs = new HashMap<String,DomdocStorageDb>();
	
	/**
	 * getStorageDbByID method 
	 * @param id
	 * @return DomdocStorageDb 
	 * @throws NotesException
	 */
	private DomdocStorageDb getStorageDbByID(String id) throws NotesException {
		if (!storageDbs.containsKey(id)) {
			DomdocStorageDb sdb = new DomdocStorageDb(domdoc, id);
			storageDbs.put(id, sdb);
		}
		return storageDbs.get(id);		
	}
	
	/**
	 * @return DomdocStorageDb
	 * @throws NotesException
	 */
	public DomdocStorageDb getStorageDb() throws NotesException {
		return getStorageDbByID(this.doc.getItemValueString("documentdbid"));
	}
	
	/**
	 * DomdocFolder constructor
	 * @param domdoc
	 * @param doc
	 * @throws NotesException
	 */
	public DomdocFolder(DomdocRepository domdoc, Document doc){
		try {
			this.doc = doc;
			this.domdoc = domdoc;
			String fkey = doc.getItemValueString("folderkey");
			this.folderkey = (fkey != null && fkey.length() > 0) ? fkey : null;
		} catch (NotesException e) {
			e.printStackTrace();
			this.doc = null;
			this.domdoc = null;
			this.folderkey = null;
		}
	}

	/**
	 * @param query
	 * @param cutoff
	 * @return
	 * @throws NotesException
	 */
	public DocumentCollection findDocuments(String query, DateTime cutoff) throws NotesException {
		String docquery = "(" + query + ") & folderkey='" + this.folderkey + "'";
//		String docquery = " folderkey='" + this.folderkey + "'";
		DomdocStorageDb sdb = getStorageDbByID(this.doc.getItemValueString("documentdbid"));
		return sdb.findDocuments(docquery, cutoff);
	}
	
	/**
	 * @throws NotesException
	 */
	public void recycle() throws NotesException {
		this.doc.recycle();
	}
	
	/**
	 * @throws NotesException
	 */
	public static void recycleCache() throws NotesException {
		Iterator<String> it = storageDbs.keySet().iterator();
		while (it.hasNext()) {
			storageDbs.get(it.next()).recycle();
		}
	}
	
	public String getFolderkey() {
		return folderkey;
	}

	public void setFolderkey(String folderkey) {
		this.folderkey = folderkey;
	}

}
