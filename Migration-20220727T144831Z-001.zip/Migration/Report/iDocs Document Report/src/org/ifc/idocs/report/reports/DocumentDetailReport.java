package org.ifc.idocs.report.reports;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.CellRangeAddress;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.ifc.idocs.report.ReportUtility;
import org.ifc.idocs.report.common.AppConfig;
import org.ifc.idocs.report.common.LogHelper;
import org.ifc.idocs.report.db.ExportDAOImpl;
import org.ifc.idocs.report.db.ReportDAOImpl;
import org.ifc.idocs.report.model.DocumentDetailReportDisplay;


@SuppressWarnings("deprecation")
public class DocumentDetailReport extends ReportUtility{
	
	private static Cell cell = null;
	private static Row newRow = null;
	private static Workbook newWb = null;
	private static Sheet newSheet = null;
	private static CellStyle newStyle = null, colorStyle = null, headerStyle = null;
	private static DocumentDetailReportDisplay ddrd = null;
	private static AppConfig config = AppConfig.getInstance();
	private static ArrayList<DocumentDetailReportDisplay> docReportList = new ArrayList<DocumentDetailReportDisplay>();
	private static String header1 = idocsProperties.getProperty("REPORT_HEADERS1");
	private static String header2 = idocsProperties.getProperty("REPORT_HEADERS2");
	private static Map<String,Integer> docCount = new HashMap<String,Integer>();
	private static Map<String,Double> folderSize = new HashMap<String,Double>();
	private static Logger reportLogger = LogHelper.getLogger(DocumentDetailReport.class);
	
	public static void createDetailReport(String reportType){
		String extractionQuery = config.getString("filters.extractioncriteriacode");
		String[] extCriteria = extractionQuery.split(";");
		for(int k = 0; k < extCriteria.length; k++){
			String extractionId = extCriteria[k];
			String utilityId = ExportDAOImpl.utilityIdIsExists(extractionId);
			if(utilityId != null){
				detailReport(utilityId, reportType);
			}
		}
	}
	
	public static void detailReport(String reportQuery, String reportType){
		reportLogger.warning("DocumentDetailReport :: createDetailReport() : Execution Started..");
		ResultSet rs = ReportDAOImpl.getDocumentDetailReport(reportQuery);
		try {
			while (rs.next()){
				
				ddrd = new DocumentDetailReportDisplay();

				ddrd.setFolderValueCode1(rs.getString("FOLDER_VALUE_CODE"));
				ddrd.setFolderTypeCode1(rs.getString("FOLDER_TYPE_CODE"));
				ddrd.setFolderSize1(rs.getString("LEVEL1_SOURCE_DOC_SIZE_NBR"));
				ddrd.setLevel1FolderSize1(rs.getString("LEVEL1_SOURCE_DOC_SIZE_NBR"));
				ddrd.setLevel1SubFolder1(rs.getString("LEVEL1_FOLDER_NME"));
				ddrd.setLevel1docCount1(rs.getString("LEVEL1_SOURCE_DOC_CNT"));

				ddrd.setFolderValueCode2(rs.getString("FOLDER_VALUE_CODE"));
				ddrd.setFolderTypeCode2(rs.getString("FOLDER_TYPE_CODE"));
				ddrd.setFolderSize2(rs.getString("LEVEL1_" + reportType + "_DOC_SIZE_NBR"));
				ddrd.setLevel1FolderSize2(rs.getString("LEVEL1_" + reportType + "_DOC_SIZE_NBR"));
				ddrd.setLevel1SubFolder2(rs.getString("LEVEL1_FOLDER_NME"));
				ddrd.setLevel1docCount2(rs.getString("LEVEL1_" + reportType + "_DOC_CNT"));
				
				docReportList.add(ddrd);
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			createXLReport();
			reportLogger.info("DocumentReport :: Executed Successfully..");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	protected static void createXLReport() throws IOException {
		
		int i = 3;
		String sheetName = "", colHeaders = "", countSize = "";
		reportLogger.info("DocumentReport :: createDocumentReport() : Execution Started..");
		
		sheetName = idocsProperties.getProperty("Document_detail_report_name");
		colHeaders = idocsProperties.getProperty("Document_detail_report_columns");
		countSize = idocsProperties.getProperty("Document_detail_report_count_size");
		
		String[] subHeadings = colHeaders.split(",");
		String[] sizeCount = countSize.split(",");
		
		newWb = createXLSheet.createReportSheet(sheetName,colHeaders, i, false);
		headerStyle = createXLSheet.createStyle(newWb, HSSFCellStyle.ALIGN_CENTER, "Calibri", 12, Font.BOLDWEIGHT_BOLD);
		newStyle = createXLSheet.createStyle(newWb, HSSFCellStyle.ALIGN_LEFT, "Calibri", 11, Font.BOLDWEIGHT_NORMAL);
		colorStyle = createXLSheet.createStyle(newWb, HSSFCellStyle.ALIGN_LEFT, "Calibri", 11, Font.BOLDWEIGHT_NORMAL, HSSFColor.ORANGE.index);
		newSheet = newWb.getSheet(sheetName);
		setReportHeaders(sheetName);

		String projectId = "", lvl1Size = "", lvl2Size = "";
		Double folderSize1 = 0.0, folderSize2 = 0.0;
		Integer docCount1 = 0, docCount2 = 0;

		for(DocumentDetailReportDisplay ddrd : docReportList){
			if(ddrd.getLevel1FolderSize1() != null){
				if(ddrd.getFolderValueCode1() != null){
					if(folderSize.get(ddrd.getFolderValueCode1() + "1") == null){
						folderSize1 = Double.parseDouble(ddrd.getLevel1FolderSize1());
					}else{
						folderSize1 = folderSize.get(ddrd.getFolderValueCode1() + "1") + Double.parseDouble(ddrd.getLevel1FolderSize1());
					}
					folderSize.put(ddrd.getFolderValueCode1() + "1", folderSize1);
				}else{
					folderSize1 = Double.parseDouble(ddrd.getLevel1FolderSize1());
				}
			}
			if(ddrd.getLevel1FolderSize2() != null){
				if(ddrd.getFolderValueCode2() != null){
					if(folderSize.get(ddrd.getFolderValueCode2() + "2") == null){
						folderSize2 = Double.parseDouble(ddrd.getLevel1FolderSize2());
					}else{
						folderSize2 = folderSize.get(ddrd.getFolderValueCode2() + "2") + Double.parseDouble(ddrd.getLevel1FolderSize2());
					}
					folderSize.put(ddrd.getFolderValueCode2() + "2", folderSize2);
				}else{
					folderSize2 = Double.parseDouble(ddrd.getLevel1FolderSize2());
				}
			}
			if(ddrd.getLevel1docCount1() != null){
				if(ddrd.getFolderValueCode1() != null){
					if(docCount.get(ddrd.getFolderValueCode1() + "1") == null){
						docCount1 = Integer.parseInt(ddrd.getLevel1docCount1());
					}else{
						docCount1 = docCount.get(ddrd.getFolderValueCode1() + "1") + Integer.parseInt(ddrd.getLevel1docCount1());
					}
					docCount.put(ddrd.getFolderValueCode1() + "1", docCount1);
				}else{
					docCount1 = Integer.parseInt(ddrd.getLevel1docCount1());
				}
			}
			if(ddrd.getLevel1docCount2() != null){
				if(ddrd.getFolderValueCode2() != null){
					if(docCount.get(ddrd.getFolderValueCode2() + "2") == null){
						docCount2 = Integer.parseInt(ddrd.getLevel1docCount2());
					}else{
						docCount2 = docCount.get(ddrd.getFolderValueCode2() + "2") + Integer.parseInt(ddrd.getLevel1docCount2());
					}
					docCount.put(ddrd.getFolderValueCode2() + "2", docCount2);
				}else{
					docCount2 = Integer.parseInt(ddrd.getLevel1docCount2());
				}
			}
		}

		reportLogger.info("FOLDER_SIZE1 : " + folderSize1 + " | FOLDER_SIZE2 : " + folderSize2);
		String columnString = "";
		Double size = 0.0;
		Integer count = 0;
		for(DocumentDetailReportDisplay ddrd : docReportList){
			if(!projectId.equals(ddrd.getFolderValueCode1())){
				if(!projectId.equals("")){
					i = i + 2;
				}
				newRow = newSheet.createRow((short) i);
				if(ddrd.getFolderValueCode1().length() > 0){
					createRow(0,ddrd.getFolderTypeCode1() + " : ", newStyle);
					createRow(1,ddrd.getFolderValueCode1(), newStyle);
				}
				if(ddrd.getFolderValueCode2().length() > 0){
			    	createRow(3,ddrd.getFolderTypeCode2() + " : ", newStyle);
			    	createRow(4,ddrd.getFolderValueCode2(), newStyle);
				}

		    	i++;
				newRow = newSheet.createRow((short) i);
				count = docCount.get(ddrd.getFolderValueCode1() + "1");
				if(count != null && count > 0){
			    	createRow(0,sizeCount[0] + " : ", newStyle);
			    	columnString = docCount.get(ddrd.getFolderValueCode1() + "1") == null ? "" : docCount.get(ddrd.getFolderValueCode1() + "1").toString();
			    	createRow(1,columnString, newStyle);
				}
				count = docCount.get(ddrd.getFolderValueCode1() + "2");
				if(count != null && count > 0){
			    	createRow(3,sizeCount[0] + " : ", newStyle);
			    	columnString = docCount.get(ddrd.getFolderValueCode2() + "2") == null ? "" : docCount.get(ddrd.getFolderValueCode2() + "2").toString();
			    	createRow(4,columnString, newStyle);
				}
		    	
		    	i++;
				newRow = newSheet.createRow((short) i);
				size = folderSize.get(ddrd.getFolderValueCode1() + "1");
				if(size != null  && size > 0){
			    	createRow(0,sizeCount[1] + " : ", newStyle);
			    	columnString = folderSize.get(ddrd.getFolderValueCode1() + "1") == null ? "" : folderSize.get(ddrd.getFolderValueCode1() + "1").intValue() + " KB";
			    	createRow(1,columnString, newStyle);
				}
				size = folderSize.get(ddrd.getFolderValueCode1() + "2");
				if(size != null  && size > 0){
			    	createRow(3,sizeCount[1] + " : ", newStyle);
			    	columnString = folderSize.get(ddrd.getFolderValueCode2() + "2") == null ? "" : folderSize.get(ddrd.getFolderValueCode2() + "2").intValue() + " KB";
			    	createRow(4,columnString, newStyle);
				}

		    	i++;
				newRow = newSheet.createRow((short) i);
		    	createRow(0,subHeadings[0], headerStyle);
		    	createRow(1,subHeadings[1], headerStyle);
		    	createRow(2,subHeadings[2], headerStyle);
		    	createRow(3,subHeadings[3], headerStyle);
		    	createRow(4,subHeadings[4], headerStyle);
		    	createRow(5,subHeadings[5], headerStyle);

		    	projectId = ddrd.getFolderValueCode1();
			}
			i++;
			lvl1Size = (ddrd.getLevel1FolderSize1() != null) ?  ddrd.getLevel1FolderSize1() + " KB" : "";
			lvl2Size = (ddrd.getLevel1FolderSize2() != null) ?  ddrd.getLevel1FolderSize2() + " KB" : "";
	    	newRow = newSheet.createRow((short)i);
	    	createRow(0,ddrd.getLevel1SubFolder1());
	    	createRow(1,ddrd.getLevel1docCount1());
	    	createRow(2,lvl1Size);
	    	createRow(3,ddrd.getLevel1SubFolder2());
	    	if(ddrd.getLevel1docCount1().equals(ddrd.getLevel1docCount2())){
	    		createRow(4,ddrd.getLevel1docCount2());
	    	}else{
	    		createRow(4,ddrd.getLevel1docCount2(), colorStyle);
	    	}
	    	createRow(5,lvl2Size);
		}		
		
		//Write data onto the XL Sheet.
		reportLogger.info("DocumentReport :: createDocumentReport() : sheetName : " + sheetName);
		createXLSheet.writeData(newWb,sheetName,idocsProperties,config);
		
		reportLogger.info("DocumentReport :: createDocumentReport() : Execution Completed..");
	}

	private static void setReportHeaders(String sheetName) {
		
		newRow = newSheet.createRow((short) 0);
	    cell = newRow.createCell((short) 0);
	    cell.setCellValue(sheetName);
	    cell.setCellStyle(headerStyle);
	    newSheet.addMergedRegion(new CellRangeAddress( 0, 0, 0, 5));
		
		newRow = newSheet.createRow((short) 1);
	    cell = newRow.createCell((short) 0);
	    cell.setCellValue(header1);
	    cell.setCellStyle(headerStyle);
	    newSheet.addMergedRegion(new CellRangeAddress( 1, 1, 0, 2));
	    
	    cell = newRow.createCell((short) 3);
	    cell.setCellValue(header2);
	    cell.setCellStyle(headerStyle);
	    newSheet.addMergedRegion(new CellRangeAddress( 1, 1, 3, 5));
	    // first row (0-based) last row  (0-based) first column (0-based) last column  (0-based)
	}

	private static void createRow(int j, String folderValueCode1) {
		createRow(j, folderValueCode1, newStyle);
	}

	private static void createRow(int j, String folderValueCode1, CellStyle style) {
		createXLSheet.createCell(newWb, newRow, j, folderValueCode1, style);
		newSheet.autoSizeColumn((short)j);
	}

}
