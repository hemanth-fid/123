/**
* This custom class for import document is used to update attribute fields while importing the document.
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Parag Doshi			09/15/2010		1.0				created
* #######################################################################################################
*/
package org.ifc.idocs.contenttransfer.importcontent;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.ErrorMessageService;
import com.documentum.web.common.LocaleService;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.contentxfer.JobAdapter;
import com.documentum.web.form.Form;
import com.documentum.web.formext.docbase.ObjectCacheUtil;
import com.documentum.webcomponent.library.messages.MessageService;
public class ImportContentContainer extends com.documentum.webcomponent.library.contenttransfer.importcontent.ImportContentContainer{
	
	public static final String MSG_DRAFT_STATE_NUMBER = "0";
	public static final String MSG_RELEASED_STATE_NUMBER="1";
	private static final long serialVersionUID = 1L;
	private static NlsResourceBundle m_nlsResourceBundle;
	private static String m_importDocContainerNlsProp;
	public static final String NEW_OBJECT_IDS = "newObjectIds";
    public static final String VDM_ROOT_FILE_NAME = "vdmRootFileName";
    protected static final String EVENT_ONCHANGEOBJECTTYPE = "onchangeobjecttype";
	private static final String MSG_IMPORTED = "Imported";

    
    public ImportContentContainer()
    {
        super();    
    }
    
    public void onInit(ArgumentList args) {
    	super.onInit(args);
    }
    
    /** This is to remove the confirmation prompt shown to user in 
     * Multiple import */
    public boolean showConfirmPrompt(){
    	return false;
    }
    
    protected void handleOnReturnFromProgressSuccess(Form form, Map map,
			JobAdapter job) {
    	
    	boolean errorMessageStatus=false;
    	String errorMessage="";
    	DfLogger.debug(this, "handleOnReturnFromProgressSuccess Start", null,null);
		super.handleOnReturnFromProgressSuccess(form, map, job);

		// Get all the imported documents object id's
		List newObjectIdsList = (ArrayList) getReturnValue(NEW_OBJECT_IDS);
		DfLogger.info(this, "Imported Object Id's " + newObjectIdsList, null,null);
		DfLogger.debug(this, "Imported Object Id's " + newObjectIdsList, null,null);
		if (newObjectIdsList != null && newObjectIdsList.size() > 0) {
			int newObjectIdsListSize = newObjectIdsList.size();
			for (int iCount = 0; iCount < newObjectIdsListSize; iCount++) {
				try {
					// Iterate for each object and get IDfSysObject
					IDfSysObject newDocument = (IDfSysObject)ObjectCacheUtil.getObject(getDfSession(), newObjectIdsList.get(iCount).toString());
					if(newDocument!=null){
						ImportContent innerComponent = getInnerImportComponent(iCount);
						markImportVersionAndSave(newDocument,innerComponent);	
						IdocsUtil.auditIDocsActivity(MSG_IMPORTED,newDocument.getObjectId().getId(),getDfSession());
					}else{
						DfLogger.error(this, " Save Failed : newDocument = NULL ", null,null);
					}
				}catch (Exception e) {
					DfLogger.error(this, " Save Failed For :" + newObjectIdsList.get(iCount).toString() + " :: " + e.getMessage(), null,null);
					IDfQuery dfQry = new DfQuery();
					errorMessageStatus=true;
		    		dfQry.setDQL("delete dm_document object where r_object_id='"+newObjectIdsList.get(iCount).toString()+"'");
		    		try {
						dfQry.execute(getDfSession(), 0);
					} catch (DfException e1) {
						e1.printStackTrace();
						errorMessageStatus=false;
						DfLogger.error(this, " Delete Failed For :" + newObjectIdsList.get(iCount).toString() + " :: " + e1.getMessage(), null,null);
					}
				}
				if(errorMessageStatus){
					ErrorMessageService.getService().setNonFatalError(m_nlsResourceBundle, "MSG_FULL_CUSTOM_MESSAGE", getContainedComponent(), new String[]{m_nlsResourceBundle.getString("MSG_PLEASE_CREATE_AGAIN", LocaleService.getLocale())}, null);
				}else{
					/***  Default Success Creation will display in message bar */
					DfLogger.debug(this, " No Exceptions Object(S)  uploaded Success fully ", null,null);
				}
			}
		}		
    }
    
    private void markImportVersionAndSave(IDfSysObject newDocument,
			ImportContent innerComponent) throws DfException {
    	DfLogger.info(this, " :: markImportVersion :: Import Version =" + innerComponent.getVersionLabel(), null, null);
    	String stateRequiredNumber = MSG_DRAFT_STATE_NUMBER;
    	if(innerComponent.getVersionLabel().equals("Draft")) {
    		newDocument.mark("0.1,CURRENT");
			DfLogger.info(this, " :: markImportVersion : Mark the document to : 0.1", null, null);        	
        }else {
			DfLogger.info(this, " :: markImportVersion : Mark the document MAJOR : 1.0 (No Change)", null, null);
//			newDocument.mark("1.0,CURRENT");
			stateRequiredNumber =MSG_RELEASED_STATE_NUMBER;
        }
    	newDocument.save();
		attachLifecycle(newDocument,MSG_DRAFT_STATE_NUMBER);
		DfLogger.info(this, " Draft State Is Attached ", null,null);
		if(stateRequiredNumber.equalsIgnoreCase(MSG_RELEASED_STATE_NUMBER)){
			IDfSysObject sysObject = (IDfSysObject)ObjectCacheUtil.getObject(getDfSession(), newDocument.getObjectId().getId());
			sysObject.promote(IDocsConstants.MSG_STATE_RELEASED, false, true);
			sysObject.promote(IDocsConstants.MSG_STATE_RELEASED, false, false);
			DfLogger.info(this, " Double Promote to Released. ", null,null);
		}		
	}

	/**
     * Get the corresponding Import Component 
     * 
     * @param iCount
     * @return
     */
    private ImportContent getInnerImportComponent(int iCount) {
    	int i = 0;
    	ArrayList list = getContainedComponents();
    	ImportContent innerComponent = null;
		for (Iterator iterator = list.iterator(); iterator.hasNext();) {
			Object object = (Object) iterator.next();
			DfLogger.info(this, " Contained Components :: " +object.getClass(),null,null);
			if(object instanceof ImportContent){
				innerComponent = (ImportContent)object;
				if(i == iCount){
					return innerComponent; 
				}else{
					i++;
				}
				DfLogger.info(this, " Inner Component Object Name :: " +innerComponent.getObjectName(),null,null);
				DfLogger.info(this, " Contained Components :: " +innerComponent.getFolderTitle(),null,null);
				DfLogger.info(this, " Contained Components :: " +innerComponent.getSubFolder(),null,null);
			}
			
		}
		return innerComponent;
	}

	/**
     * This method sends the status of the import operation to the user and attaches lifecycles on the 
     * newly imported files.
     */
	protected void addFinalSuccessMessage()
    {
    	DfLogger.info(this, " :: addFinalSuccessMessage : ", null, null);
    	IDfSession dfSession = getDfSession();
        List ids = (List)getReturnValue(NEW_OBJECT_IDS);
        
        int numberOfFiles = ids.size();
        for(int i=0;i<numberOfFiles;i++){
        	String objectId = (String)ids.get(i);
				super.addFinalSuccessMessage();
				DfLogger.info(this, " :: addFinalSuccessMessage !!!!", null, null);
        }
        
        if(ids.size() == 1){
            String objectId = (String)ids.get(0);
            try{
                IDfSysObject obj = (IDfSysObject)dfSession.getObject(new DfId(objectId));
                String lifecycleName = obj.getPolicyName();
                String currentStateName = obj.getString(IDocsConstants.MSG_DOC_STATE);
                if(lifecycleName != null){
                    MessageService.addMessage(this, "MSG_OPERATION_SUCCESSFUL_WITH_LIFECYCLE", new String[] {
                        lifecycleName, currentStateName
                    });
                } else {
                    MessageService.addMessage(this, "MSG_OPERATION_SUCCESSFUL");
                }
            }catch(DfException ex){
                throw new WrapperRuntimeException(ex);
            }
        } else{
            MessageService.addMessage(this, "MSG_OPERATION_SUCCESSFUL");
        }
    }
	
	private IDfSysObject attachLifecycle(IDfSysObject newDoc,String strStateNumber)
			throws DfException {
		DfLogger.debug(this, " :: attachLifecycle : Current r_policy_id : "+newDoc.getString("r_policy_id"),null,null);
		if(newDoc.getString("r_policy_id").equals("0000000000000000")){
			DfLogger.info(this, "attachLifecycle() : If label : "+newDoc.getString("r_version_label"),null,null);
		    StringBuffer strBuff = new StringBuffer(64);
		    strBuff.append("dm_policy where object_name='").append(IDocsConstants.MSG_IDOCS_LIFECYCLE).append("'");
		    com.documentum.fc.common.IDfId policyId = newDoc.getObjectSession().getIdByQualification(strBuff.toString());
		    DfLogger.debug(this, " :: Attach this Lifecycle r_policy_id = "+policyId.getId(),null,null);
			newDoc.attachPolicy(policyId,strStateNumber, "");
		    DfLogger.info(this, " :: attachLifecycle : LifeCycle '"+IDocsConstants.MSG_IDOCS_LIFECYCLE+"' is attached with Draft ",null,null);
		}else{
			DfLogger.info(this, " :: attachLifecycle : Else",null,null);
		}
		return newDoc;
	}
    
    /**
     * This method moves the imported document to the correct path in the IDOCS project structure.
     * @param objectId - Object Id of the document.
     * @throws DfException
     */
/*	private void linkDocumentToProjFolder(IDfSysObject newDoc) throws DfException {
    	IDfClientX clientx = new DfClientX();
    	ArrayList list = getContainedComponents();
        Component component = (Component)list.get(0);
        ImportContent impCont = (ImportContent) component;
    	
        String unlinkPath=((IDfFolder)getDfSession().getObject(newDoc.getFolderId(0))).getFolderPath(0);
		String linkPath=impCont.getParentFolder().getFolderPath(0)+"/"+newDoc.getString(m_nlsResourceBundle.getString("MSG_FOLDER_TITLE", LocaleService.getLocale()))+"/"+newDoc.getString(m_nlsResourceBundle.getString("MSG_DOC_SUBTYPE", LocaleService.getLocale()));
		DfLogger.info(this, " :: linkDocumentToProjFolder : MSG_FOLDER_TITLE : "+newDoc.getString(m_nlsResourceBundle.getString("MSG_FOLDER_TITLE", LocaleService.getLocale())),null,null);
		DfLogger.info(this, " :: linkDocumentToProjFolder : MSG_DOC_SUBTYPE : "+newDoc.getString(m_nlsResourceBundle.getString("MSG_DOC_SUBTYPE", LocaleService.getLocale())),null,null);
		DfLogger.info(this, " :: linkDocumentToProjFolder : unlinkPath : "+unlinkPath,null,null);
		DfLogger.info(this, " :: linkDocumentToProjFolder : linkPath : "+linkPath,null,null);

		if(!unlinkPath.equals(linkPath)){
			newDoc.unlink(unlinkPath);
			newDoc.link(linkPath);
		}
    }*/
	
	/**
	 * This method sets the sub-folder , sub-type code for the document.
	 * @param strNewObjectId
	 * @throws DfException
	 */
	protected void setCustomAttributes(IDfSysObject newDoc,ImportContent componentInstance) throws DfException {
    	try {
    		if(componentInstance !=null ){
		    	newDoc.setString(m_nlsResourceBundle.getString("MSG_DOC_SUBTYPE", LocaleService.getLocale()), componentInstance.getFolderTitle());
		        newDoc.setString(m_nlsResourceBundle.getString("MSG_FOLDER_TITLE", LocaleService.getLocale()), componentInstance.getSubFolder());
		        newDoc.setString(m_nlsResourceBundle.getString("MSG_SEC_CLASS", LocaleService.getLocale()), componentInstance.getSelectedSecClassification());
		        //newDoc.setString(m_nlsResourceBundle.getString("MSG_SEC_CLASS_CODE", LocaleService.getLocale()), componentInstance.getSelectedSecClassificationCode());
		        newDoc.setString(IDocsConstants.MSG_DOC_SUBTYPE_CODE, componentInstance.getSelectedDocType());
		        newDoc.setRepeatingString(IDocsConstants.MSG_IFCDOCS_AUTHORS,0, componentInstance.getIFCDosAuthor());
    		}else{
    			DfLogger.info(this, " :: Component is NULL", null, null);
    		}
    	} catch(Exception e) {
    		DfLogger.error(this, " :: setCustomAttributes Exception >> "+e.getMessage(), null, e);
    	}
    }
    
    static {
    	m_importDocContainerNlsProp = "org.ifc.idocs.contenttransfer.importcontent.ImportContentNlsProp";
        m_nlsResourceBundle = new NlsResourceBundle(m_importDocContainerNlsProp);
    }

    /**
     * Disables the OLEScan enabled request.
     */
	protected boolean getOLEScanEnableFromRequest() {
		return false;
	}

	/**
	 * Disables servelt uploading in IDOCS.
	 */
	protected Collection getUploadedFilesFromRequest() {
		return null;
	}
	
	private static final String DM_POLICY_E_EXIST_NO_BP_LOG="DM_POLICY_E_EXIST_NO_BP_LOG"; 
}
