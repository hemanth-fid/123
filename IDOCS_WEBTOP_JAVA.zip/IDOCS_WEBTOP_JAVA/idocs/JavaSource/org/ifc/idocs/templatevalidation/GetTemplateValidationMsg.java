package org.ifc.idocs.templatevalidation;

public class GetTemplateValidationMsg {

	public GetTemplateValidationMsg() {
		
		
	}
}
