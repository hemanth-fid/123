/**
* This precondition class Enable or Disables the LinkToPSR menu item based 
* on resource entity ID
* ############################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* ############################################################################
* Gangadhar Reddy.V		02/20/2011 	     1.0          Created
* ############################################################################
*/
package org.ifc.idocs.crrpsr.actions;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.main.MainEx;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.action.IActionPrecondition;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

public class LinkToPSRPreCondition implements IActionPrecondition {

	public String[] getRequiredParams() {
		return (new String[] { "objectId" });
	}

	/**
	 *  This method enable or Disables the LinkToPSR menu item based on resource entity ID
	 */
	public boolean queryExecute(String strAction, IConfigElement config,
			ArgumentList arg, Context context, Component component) {
		boolean bExecute = false;
		String sourceName = MainEx.getSourceName(component.getPageContext().getSession());
		if (sourceName != null && sourceName.trim().length()>0 
				&& sourceName.equals(IDocsConstants.MSG_PSR_ENTITY_ID)) {
				return true;
		}
		return bExecute;
	}
}
