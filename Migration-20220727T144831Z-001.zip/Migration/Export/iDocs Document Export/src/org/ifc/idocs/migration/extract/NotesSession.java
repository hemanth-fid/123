package org.ifc.idocs.migration.extract;

import java.util.logging.Level;
import java.util.logging.Logger;

import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

import org.ifc.idocs.migration.ExtractDocuments;
import org.ifc.idocs.migration.common.AppConfig;

/**
 * @author SPankajamsadanan
 *
 */
public class NotesSession {

	private NotesSession() {}
	private static Session session = null;
	private static Logger exportDocLogger = LogHelper.getLogger(ExtractDocuments.class);
	/**
	 * getInstance method
	 * @return Session
	 * @throws NotesException
	 */
	public static Session getInstance(){
		if (session == null) {
			AppConfig config = AppConfig.getInstance();
			@SuppressWarnings("unused")
			String notesPassword = config.getString("connection.notespassword");// for pwd
			try {
				NotesThread.sinitThread();
				session = NotesFactory.createSession();
//				session = NotesFactory.createSessionWithFullAccess(notesPassword);	//for local development
			} catch (NotesException e) {
				if(e.id == 41728){
					System.out.println("Failure in Notes Initialization. Please restart utility");
					exportDocLogger.log(Level.WARNING,"NotesSession.Java-", e);
					System.exit(1)	;
				}
				System.out.println("Lotus Notes Password is wrong. Please check config.xml file.");
				e.printStackTrace();
				System.exit(0);
			}	
		}
		return session;
	}

	/**
	 * terminate method terminates session
	 * @return void
	 */
	public static void terminate() {
		if (session != null) {
			try {
				session.recycle();
			} catch (NotesException e) {
				e.printStackTrace();
				exportDocLogger.log(Level.WARNING,"NotesSession.Java-Terminate Section", e);
			}
			NotesThread.stermThread();
			System.out.println("Notes Thread terminated!!!");
		}
	}
}
