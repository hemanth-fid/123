package org.ifc.idocs.migration.report;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.ifc.idocs.migration.helper.UpdateDB;
import org.ifc.idocs.migration.helper.Utilities;
import org.ifc.idocs.migration.importUtility.ImportUtility;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.common.DfException;

/**
 * ReportingUtility - Generating all the reports. 
 * @author HAnuganti
 * 
 * #############################################################################################
 * Author		            DateofChange	 Version	  ModificationHistory
 * ###########################################################################################
 * Hemachandra Anuganti 
 * ###########################################################################################
 * 
 */
public class ReportingUtility extends ImportUtility{

	/**
	 * @param args
	 * @throws SQLException 
	 */
	
	static ArrayList<String> qryList = new ArrayList<String>();
	static int documentCNT = 0;
	static float documentSize = 0; 
	static HashMap subFldDetalsHM = new HashMap();
	
	public static void updateReportTBL() {
		
		/*
		 Get Projects,Institutions,Countries from regiog table
		 Algorithm:
		 Get the region name for the extraction utility code
		 Query the region table and get the project ids,institution numbers, country codes
		 pass these to below methods and generate all the reports
		 */
		
		//Get the region Name for the extraction ID 
		//System.out.println("extraction criteriaID::"+ config.getString("filters.extractionutilityID"));
		StringTokenizer sTokens = new StringTokenizer(config.getString("filters.extractionutilityID"), "/");
		while(sTokens.hasMoreTokens()){
			String extUtilityCode = sTokens.nextToken();
			//System.out.println("Extraction Code::"+extUtilityCode);
			if(""!=extUtilityCode){
				String getRegionQryStr = idocsProperties.getProperty("MSG_GET_REGION_FRM_EXTCRITERIA")+extUtilityCode+"'";
				importDocLogger.info("Select query::"+getRegionQryStr.toString());
//				ResultSet extrInfo = UpdateDB.getExtractionInfo(extId); //quoted to use common method for select
				ResultSet extrInfo = UpdateDB.selectFrmDatabse(getRegionQryStr.toString());
//				System.out.println("out of::ResultSet extrInfo = UpdateDB.getExtractionInfo(extId);");
				try {
					
					String reportUtilID = getReportUtilityID(extUtilityCode); 
					if(reportUtilID !="" && null != reportUtilID){
						String projectIDs = "";
						String institutionNbrs = "";
						String countries = "";
						String regionName = "";
					while(extrInfo.next()) {
						regionName = extrInfo.getString("region_nme");
						//Get list of projects, institutions and countries from region table
						StringTokenizer getTypes = new StringTokenizer(idocsProperties.getProperty("MSG_STR_ELEMENTS"),",");
						
						while(getTypes.hasMoreTokens()){
							String type = getTypes.nextToken();
							
//							String legacyIDs = getLegacyDocIDs(regionName,extUtilityCode);
							if("projects".equals(type)){
								String getFldValueCode = idocsProperties.getProperty("MSG_DB_GET_REGION_INFO_PRJCTS")
															.replaceFirst("<region_name>", regionName)
																.replaceFirst("<extraction_utility_code>", extUtilityCode);
								ResultSet getMigInf = UpdateDB.selectFrmDatabse(getFldValueCode.toString());
								while(getMigInf.next()){
									if(projectIDs==""){
										projectIDs = getMigInf.getString("folder_value_code");
									}else{
										projectIDs += ","+getMigInf.getString("folder_value_code");
									}
//									projectIDs += getMigInf.getString("folder_value_code")+"','";
									
								}
							}else if("institutions".equals(type)){

								String getFldValueCode = idocsProperties.getProperty("MSG_DB_GET_REGION_INFO_INSTS")
															.replaceFirst("<region_name>", regionName)
																.replaceFirst("<extraction_utility_code>", extUtilityCode);
								ResultSet getMigInf = UpdateDB.selectFrmDatabse(getFldValueCode.toString());
								while(getMigInf.next()){
									
									if(institutionNbrs==""){
										institutionNbrs = getMigInf.getString("folder_value_code");
									}else{
										institutionNbrs += ","+getMigInf.getString("folder_value_code");
									}
//									institutionNbrs += getMigInf.getString("folder_value_code")+"','";
								}
							
							}
							else if("countries".equals(type)){

								String getFldValueCode = idocsProperties.getProperty("MSG_DB_GET_REGION_INFO_CTRYS")
															.replaceFirst("<region_name>", regionName)
																.replaceFirst("<extraction_utility_code>", extUtilityCode);
								ResultSet getMigInf = UpdateDB.selectFrmDatabse(getFldValueCode.toString());
								while(getMigInf.next()){
									
									if(countries==""){
										countries = getMigInf.getString("folder_value_code");
									}else{
										countries += ","+getMigInf.getString("folder_value_code");
									}
									
//									countries += getMigInf.getString("folder_value_code")+"','";
								}
							
							}
//							System.out.println("Total No of Projects::"+projectIDs);
//							System.out.println("Total No of Institutions::"+institutionNbrs);
							//System.out.println("Total No of Countries::"+countries);
						}		
					}if(extrInfo!=null){
						extrInfo.close();
					}
					
					importDocLogger.info("Total No of Projects::"+projectIDs);
					importDocLogger.info("Total No of Institutions::"+institutionNbrs);
					importDocLogger.info("Total No of Countries::"+countries);
					
					//Generate Report for the projects,institutions and counties for the extraction id
					generateReportsforAll(projectIDs,institutionNbrs,countries,extUtilityCode,reportUtilID,regionName);
				}else{
					importDocLogger.warning("Reporting Utility ID not found for the extraction id::" +extUtilityCode);
				}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					importDocLogger.warning("DfException::" + e.getMessage());
					importDocLogger.log(Level.WARNING,"SQLException During fetching the values from region databases", e);
					e.printStackTrace();
				}
			}else{
				importDocLogger.warning("Extraction Utility ID not found in the config.xml file");
			}
		}
	}

	private static String getReportUtilityID(String extUtilityCode) {
		// TODO Auto-generated method stub
		
		String reportUtilityID ="";
		
		String getReportUtilID = idocsProperties.getProperty("MSG_GET_REPORT_ID")
									.replaceFirst("<ext_utility_code>", extUtilityCode);
		ResultSet getReportID = UpdateDB.selectFrmDatabse(getReportUtilID);
		try {
		////System.out.println("Resultset = "+ getReportID.is());

			while(getReportID.next()){
				reportUtilityID = getReportID.getString("REPORT_UTILITY_ID");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException::" + e.getMessage());
			importDocLogger.log(Level.WARNING,"SQLException During Report Utility id processing", e);
			e.printStackTrace();
		}	catch (Exception ex) {
				// TODO Auto-generated catch block
			importDocLogger.warning("DfException::" + ex.getMessage());
			importDocLogger.log(Level.WARNING,"Exception During Report Utility id processing", ex);
				ex.printStackTrace();
		}finally{
			// please close resultset/statement 
			if(getReportID!=null){
				try {
					getReportID.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					importDocLogger.warning("DfException::" + e.getMessage());
					importDocLogger.log(Level.WARNING,"SQLException During closing the resultset", e);
					e.printStackTrace();
				}
			}
		}
		return reportUtilityID;
	}

	private static void generateReportsforAll(String projectIDs,
			String institutionNbrs, String countries, String extUtilityCode, String reportUtilID, String regionName) {
		// TODO Auto-generated method stub
		//importDocLogger.info("Inside updateReportTBL()::"+ReportingUtility.class);
		
		
		//Update First Report for Projects
		if(""!=projectIDs || ""!=reportUtilID || ""!=extUtilityCode){
			importDocLogger.info("Started Updating All Reports For Projects....Please wait..!!!");
			updateReport_1_PRJ_TBL(projectIDs,reportUtilID,extUtilityCode,regionName);
			//Update Second Report For Projects
			updateReport_2_PRJ_TBL(projectIDs,reportUtilID,extUtilityCode,regionName);
			//Update Second Report For Projects
//			updateReport_3_PRJ_TBL(projectIDs,reportUtilID,extUtilityCode,regionName);	
			importDocLogger.info("Ended Updating All Reports for Projects");
		}
		
		if(""!=institutionNbrs || ""!=reportUtilID || ""!=extUtilityCode){
			importDocLogger.info("Started Updating All Reports For Institutions....Please wait..!!!");
			//Update First Report for Institutions
			updateReport_1_INST_TBL(institutionNbrs,reportUtilID,extUtilityCode,regionName);	
			//Update Second Report for Institutions
			updateReport_2_INST_TBL(institutionNbrs,reportUtilID,extUtilityCode,regionName);
			//Update Second Report for Institutions
//			updateReport_3_INST_TBL(institutionNbrs,reportUtilID,extUtilityCode,regionName);
			importDocLogger.info("Ended Updating All Reports for Institutions");
		}
		
		if(""!=countries || ""!=reportUtilID || ""!=extUtilityCode){
			importDocLogger.info("Started Updating All Reports For Countries....Please wait..!!!");
			//Update First Report for Countries
			updateReport_1_CTRY_TBL(countries,reportUtilID,extUtilityCode,regionName);	
			//Update Second Report for Countries
			updateReport_2_CTRY_TBL(countries,reportUtilID,extUtilityCode,regionName);	
			//Update Second Report for Countries
//			updateReport_3_CTRY_TBL(countries,reportUtilID,extUtilityCode,regionName);	
			importDocLogger.info("Ended Updating All Reports for Countries");
		}
		UpdateDB.executeBatch(qryList,UpdateDB.getBatchConnection());
		qryList.clear();
	}

	private static void updateReport_3_CTRY_TBL(String countries, String reportUtilID, String extUtilityCode, String regionName) {
		// TODO Auto-generated method stub
				
		IDfCollection collection = null;
		String docIdentity = idocsProperties.getProperty("MSG_RECON_REPORT_IDENT_CTRY");
		StringTokenizer ctryTokens = new StringTokenizer(countries,",");
		while(ctryTokens.hasMoreTokens()){
			String legIDsQueue="";
			String ctryCode = ctryTokens.nextToken();
			importDocLogger.warning("Processing Security Exception Report for the Country Code::"+ctryCode);
			String getLegacyIds = idocsProperties.getProperty("MSG_DB_GET_LEGACY_IDS_QUEUE_CTRY")
										.replaceFirst("<region_name>", regionName)
											.replaceFirst("<extraction_utility_code>", extUtilityCode)
												.replaceFirst("<folder_value_code>", ctryCode);
			ResultSet getMigInf = UpdateDB.selectFrmDatabse(getLegacyIds.toString());
			try {
				while(getMigInf.next()){
					if(legIDsQueue==""){
						legIDsQueue = getMigInf.getString("LEGACY_DOCUMENT_ID");
					}else{
						legIDsQueue += ","+getMigInf.getString("LEGACY_DOCUMENT_ID");
					}
				}if(getMigInf!= null){
					getMigInf.close();
				}
				String[] legacyIDS = legIDsQueue.split(",");
				int idsLength = legacyIDS.length;
				Float idsCNT = new Float(idsLength);
				Float fltids = idsCNT/100;
				int roundedINT = (int) Math.ceil(fltids);
				int temp = 0;
				int tempCNT = 0;
				for(int i=1;i<=roundedINT;i++){
					if(i==roundedINT){
						tempCNT = idsLength;
					}else{
						tempCNT = tempCNT+100;
					}
					String legIDSQueue = "";
					for(int k=temp;k<tempCNT;k++){
						if(legIDSQueue==""){
							legIDSQueue = legacyIDS[k];
							}else{
								legIDSQueue += "','"+legacyIDS[k];
							}
						}
						temp = temp+100;
						String reportCtryQry = idocsProperties.getProperty("MSG_GET_REPORT3_CNTRY_QUERY")
												.replaceFirst("<country_code>", countries)
													.replaceFirst("<orig_doc_id>", legIDSQueue);
						collection = Utilities.executeQuery(dfSession, reportCtryQry, DfQuery.EXECREAD_QUERY);
						while(collection.next()){
							String fldValueCode = collection.getString("country_code");
							String docName = collection.getString("object_name");
							String docVersion = collection.getString("r_version_label");
							String docSecClass = collection.getString("sec_classification_code");
							String docIChronicleID = collection.getString("i_chronicle_id");
							String docRObjectID = collection.getString("r_object_id");
							String doclegacyID = collection.getString("orig_doc_id");
							String doclegacyUniqueID = collection.getString("orig_doc_unique_id");
							if(doclegacyID==null || doclegacyID==""){
								doclegacyID=" ";
							}
							
							//Update DB for report 3
							addToArrayList(updateReport_3_TBL(fldValueCode,docName,docVersion,docSecClass,doclegacyID,doclegacyUniqueID,docRObjectID,docIChronicleID,reportUtilID));
						}
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				importDocLogger.log(Level.WARNING,"SQLException During updating reconcillation security report for countries", e);
				e.printStackTrace();
			}catch (DfException e) {
				// TODO Auto-generated catch block
				importDocLogger.log(Level.WARNING,"DfException During updating reconcillation security report for countries", e);
				e.printStackTrace();
			}finally{
				if(collection != null){
					try {
						collection.close();
					} catch (DfException e) {
						// TODO Auto-generated catch block
						importDocLogger.log(Level.WARNING,"DfException During updating reconcillation security report closing the resultset for countries", e);
						e.printStackTrace();
					}
				}
			}
		}
			
	}

	private static void updateReport_3_INST_TBL(String institutionNbrs, String reportUtilID, String extUtilityCode, String regionName) {
		// TODO Auto-generated method stub
				
		IDfCollection collection = null;
		String docIdentity = idocsProperties.getProperty("MSG_RECON_REPORT_IDENT_INST");
		StringTokenizer instNbrTokens = new StringTokenizer(institutionNbrs,",");
		while(instNbrTokens.hasMoreTokens()){
			String legIDsQueue="";
			String instNbr = instNbrTokens.nextToken();
			importDocLogger.warning("Processing Security Exception Report for the Institution Nbr::"+instNbr);
			String getLegacyIds = idocsProperties.getProperty("MSG_DB_GET_LEGACY_IDS_QUEUE_INST")
										.replaceFirst("<region_name>", regionName)
											.replaceFirst("<extraction_utility_code>", extUtilityCode)
												.replaceFirst("<folder_value_code>", instNbr);
			ResultSet getMigInf = UpdateDB.selectFrmDatabse(getLegacyIds.toString());
			try {
				while(getMigInf.next()){
					if(legIDsQueue==""){
						legIDsQueue = getMigInf.getString("LEGACY_DOCUMENT_ID");
					}else{
						legIDsQueue += ","+getMigInf.getString("LEGACY_DOCUMENT_ID");
					}
				}if(getMigInf!= null){
					getMigInf.close();
				}
				String[] legacyIDS = legIDsQueue.split(",");
				int idsLength = legacyIDS.length;
				Float idsCNT = new Float(idsLength);
				Float fltids = idsCNT/100;
				int roundedINT = (int) Math.ceil(fltids);
				int temp = 0;
				int tempCNT = 0;
				for(int i=1;i<=roundedINT;i++){
					if(i==roundedINT){
						tempCNT = idsLength;
					}else{
						tempCNT = tempCNT+100;
					}
					String legIDSQueue = "";
					for(int k=temp;k<tempCNT;k++){
						if(legIDSQueue==""){
							legIDSQueue = legacyIDS[k];
							}else{
								legIDSQueue += "','"+legacyIDS[k];
							}
						}
						temp = temp+100;
						String reportInstQry = idocsProperties.getProperty("MSG_GET_REPORT3_INST_QUERY")
												.replaceFirst("<institution_nbr>", instNbr)
													.replaceFirst("<orig_doc_id>", legIDSQueue);
						collection = Utilities.executeQuery(dfSession, reportInstQry, DfQuery.EXECREAD_QUERY);
						while(collection.next()){
							String fldValueCode = collection.getString("institution_nbr");
							String docName = collection.getString("object_name");
							String docVersion = collection.getString("r_version_label");
							String docSecClass = collection.getString("sec_classification_code");
							String docIChronicleID = collection.getString("i_chronicle_id");
							String docRObjectID = collection.getString("r_object_id");
							String doclegacyID = collection.getString("orig_doc_id");
							String doclegacyUniqueID = collection.getString("orig_doc_unique_id");
							if(doclegacyID==null || doclegacyID==""){
								doclegacyID=" ";
							}
							
							//Update DB for report 3
							addToArrayList(updateReport_3_TBL(fldValueCode,docName,docVersion,docSecClass,doclegacyID,doclegacyUniqueID,docRObjectID,docIChronicleID,reportUtilID));
						}
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				importDocLogger.log(Level.WARNING,"SQLException During updating reconcillation security report for institutions", e);
				e.printStackTrace();
			}catch (DfException e) {
				// TODO Auto-generated catch block
				importDocLogger.log(Level.WARNING,"DfException During updating reconcillation security report for institutions", e);
				e.printStackTrace();
			}finally{
				if(collection != null){
					try {
						collection.close();
					} catch (DfException e) {
						// TODO Auto-generated catch block
						importDocLogger.log(Level.WARNING,"SQLException During updating reconcillation security report closing the resultset for institutions", e);
						e.printStackTrace();
					}
				}
			}
		}
			
	}

	private static void updateReport_3_PRJ_TBL(String projectIDs, String reportUtilID, String extUtilityCode, String regionName) {
		// TODO Auto-generated method stub
		
		IDfCollection collection = null;
		String docIdentity = idocsProperties.getProperty("MSG_RECON_REPORT_IDENT_PROJ");
		StringTokenizer projectIDTokens = new StringTokenizer(projectIDs,",");
		while(projectIDTokens.hasMoreTokens()){
			String legIDsQueue="";
			String projectID = projectIDTokens.nextToken();
			importDocLogger.warning("Processing Security Exception Report for the Project ID::"+projectID);
			String getLegacyIds = idocsProperties.getProperty("MSG_DB_GET_LEGACY_IDS_QUEUE_PRJ")
										.replaceFirst("<region_name>", regionName)
											.replaceFirst("<extraction_utility_code>", extUtilityCode)
												.replaceFirst("<folder_value_code>", projectID);
			ResultSet getMigInf = UpdateDB.selectFrmDatabse(getLegacyIds.toString());
			try {
				while(getMigInf.next()){
					if(legIDsQueue==""){
						legIDsQueue = getMigInf.getString("LEGACY_DOCUMENT_ID");
					}else{
						legIDsQueue += ","+getMigInf.getString("LEGACY_DOCUMENT_ID");
					}
				}if(getMigInf!= null){
					getMigInf.close();
				}
				String[] legacyIDS = legIDsQueue.split(",");
				int idsLength = legacyIDS.length;
				Float idsCNT = new Float(idsLength);
				Float fltids = idsCNT/100;
				int roundedINT = (int) Math.ceil(fltids);
				int temp = 0;
				int tempCNT = 0;
				for(int i=1;i<=roundedINT;i++){
					if(i==roundedINT){
						tempCNT = idsLength;
					}else{
						tempCNT = tempCNT+100;
					}
					String legIDSQueue = "";
					for(int k=temp;k<tempCNT;k++){
						if(legIDSQueue==""){
							legIDSQueue = legacyIDS[k];
							}else{
								legIDSQueue += "','"+legacyIDS[k];
							}
						}
						temp = temp+100;
						String reportPrjQry = idocsProperties.getProperty("MSG_GET_REPORT3_PROJ_QUERY")
												.replaceFirst("<project_id>", projectID)
													.replaceFirst("<orig_doc_id>", legIDSQueue);
						collection = Utilities.executeQuery(dfSession, reportPrjQry, DfQuery.EXECREAD_QUERY);
						while(collection.next()){
							String fldValueCode = collection.getString("project_id");
							String docName = collection.getString("object_name");
							String docVersion = collection.getString("r_version_label");
							String docSecClass = collection.getString("sec_classification_code");
							String docIChronicleID = collection.getString("i_chronicle_id");
							String docRObjectID = collection.getString("r_object_id");
							String doclegacyID = collection.getString("orig_doc_id");
							String doclegacyUniqueID = collection.getString("orig_doc_unique_id");
							if(doclegacyID==null || doclegacyID==""){
								doclegacyID=" ";
							}
							String regex = "[^a-zA-Z0-9]";
							docName= docName.replaceAll(regex, " ");
							//Update DB for report 3
							addToArrayList(updateReport_3_TBL(fldValueCode,docName,docVersion,docSecClass,doclegacyID,doclegacyUniqueID,docRObjectID,docIChronicleID,reportUtilID));
						}
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				importDocLogger.log(Level.WARNING,"SQLException During updating reconcillation security report for projects", e);
				importDocLogger.warning("DfException::" + e.getMessage());
				e.printStackTrace();
			}catch (DfException e) {
				// TODO Auto-generated catch block
				importDocLogger.log(Level.WARNING,"DfException During updating reconcillation security report for projects", e);
				importDocLogger.warning("DfException::" + e.getMessage());
				e.printStackTrace();
			}finally{
				if(collection != null){
					try {
						collection.close();
					} catch (DfException e) {
						// TODO Auto-generated catch block
						importDocLogger.log(Level.WARNING,"SQLException During updating reconcillation security report closing the resultset for projects", e);
						importDocLogger.warning("DfException::" + e.getMessage());
						e.printStackTrace();
					}
				}
			}
		}
	}
	
	private static void updateReport_1_INST_TBL(String institutionNbrs, String reportUtilID, String extUtilityCode, String regionName) {
				
		IDfCollection collection = null;
		String docIdentity = idocsProperties.getProperty("MSG_RECON_REPORT_IDENT_INST");
		StringTokenizer InstitutionTokens = new StringTokenizer(institutionNbrs,",");
		while(InstitutionTokens.hasMoreTokens()){
			float docSize = 0;
			int docCNT = 0;
			String legIDsQueue = "";
			String instNbr = InstitutionTokens.nextToken();
			importDocLogger.warning("Processing Document Count Report for the Institution Nbr::"+instNbr);
			String getLegacyIds = idocsProperties.getProperty("MSG_DB_GET_LEGACY_IDS_QUEUE_INST")
										.replaceFirst("<region_name>", regionName)
											.replaceFirst("<extraction_utility_code>", extUtilityCode)
												.replaceFirst("<folder_value_code>", instNbr);
			ResultSet getMigInf = UpdateDB.selectFrmDatabse(getLegacyIds.toString());
			try {
				while(getMigInf.next()){
					if(legIDsQueue==""){
						legIDsQueue = getMigInf.getString("LEGACY_DOCUMENT_ID");
					}else{
						legIDsQueue += ","+getMigInf.getString("LEGACY_DOCUMENT_ID");
					}
				}if(getMigInf!= null){
					getMigInf.close();
				}
				String[] legacyIDS = legIDsQueue.split(",");
				int idsLength = legacyIDS.length;
				Float idsCNT = new Float(idsLength);
				Float fltids = idsCNT/100;
				int roundedINT = (int) Math.ceil(fltids);
				int temp = 0;
				int tempCNT = 0;
				for(int i=1;i<=roundedINT;i++){
					if(i==roundedINT){
						tempCNT = idsLength;
					}else{
						tempCNT = tempCNT+100;
					}
					String legIDSQueue = "";
					for(int k=temp;k<tempCNT;k++){
						if(legIDSQueue==""){
							legIDSQueue = legacyIDS[k];
							}else{
								legIDSQueue += "','"+legacyIDS[k];
							}
						}
						temp = temp+100;
						String reportInstQry = idocsProperties.getProperty("MSG_GET_REPORT1_INST_QUERY")
													.replaceFirst("<institution_nbr>", instNbr)
														.replaceFirst("<orig_doc_id>", legIDSQueue);
						collection = Utilities.executeQuery(dfSession, reportInstQry, DfQuery.EXECREAD_QUERY);
						while(collection.next()){
							docSize = docSize+Float.parseFloat(collection.getString("folder_size"));
							docCNT = docCNT+Integer.parseInt(collection.getString("doc_count"));
						}
				}
				//Update DB for report 1
				addToArrayList(updateReport_1_TBL(instNbr,docSize,docCNT,docIdentity,reportUtilID));
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				importDocLogger.log(Level.WARNING,"SQLException During updating document count report closing the resultset for institutions", e);
				importDocLogger.warning("DfException::" + e.getMessage());
				e.printStackTrace();
			}catch (DfException e) {
				// TODO Auto-generated catch block
				importDocLogger.log(Level.WARNING,"DfException During updating document count report closing the resultset for institutions", e);
				importDocLogger.warning("DfException::" + e.getMessage());
				e.printStackTrace();
			}finally{
				if(collection != null){
					try {
						collection.close();
					} catch (DfException e) {
						// TODO Auto-generated catch block
						importDocLogger.log(Level.WARNING,"SQLException During updating document count report closing the resultset for institutions", e);
						importDocLogger.warning("DfException::" + e.getMessage());
						e.printStackTrace();
					}
				}
			}
			
		}
	}

	private static void updateReport_1_PRJ_TBL(String projectIDs, String reportUtilID, String extUtilityCode, String regionName) {
		// TODO Auto-generated method stub
		
		IDfCollection collection = null;
		String docIdentity = idocsProperties.getProperty("MSG_RECON_REPORT_IDENT_PROJ");
		StringTokenizer projectTokens = new StringTokenizer(projectIDs,",");
		while(projectTokens.hasMoreTokens()){
			float docSize = 0;
			int docCNT = 0;
			String legIDsQueue = "";
			String projectID = projectTokens.nextToken();
			importDocLogger.warning("Processing Document Count Report for the project id::"+projectID);
			String getLegacyIds = idocsProperties.getProperty("MSG_DB_GET_LEGACY_IDS_QUEUE_PRJ")
										.replaceFirst("<region_name>", regionName)
											.replaceFirst("<extraction_utility_code>", extUtilityCode)
												.replaceFirst("<folder_value_code>", projectID);
			ResultSet getMigInf = UpdateDB.selectFrmDatabse(getLegacyIds.toString());
			try {
				while(getMigInf.next()){
					if(legIDsQueue==""){
						legIDsQueue = getMigInf.getString("LEGACY_DOCUMENT_ID");
					}else{
						legIDsQueue += ","+getMigInf.getString("LEGACY_DOCUMENT_ID");
					}
				}if(getMigInf!= null){
					getMigInf.close();
				}
				String[] legacyIDS = legIDsQueue.split(",");
				int idsLength = legacyIDS.length;
				Float idsCNT = new Float(idsLength);
				Float fltids = idsCNT/100;
				int roundedINT = (int) Math.ceil(fltids);
				int temp = 0;
				int tempCNT = 0;
				for(int i=1;i<=roundedINT;i++){
					if(i==roundedINT){
						tempCNT = idsLength;
					}else{
						tempCNT = tempCNT+100;
					}
					String legIDSQueue = "";
					for(int k=temp;k<tempCNT;k++){
						if(legIDSQueue==""){
							legIDSQueue = legacyIDS[k];
							}else{
								legIDSQueue += "','"+legacyIDS[k];
							}
						}
						temp = temp+100;
						String reportPrjQry = idocsProperties.getProperty("MSG_GET_REPORT1_PROJ_QUERY")
												.replaceFirst("<project_id>", projectID)
													.replaceFirst("<orig_doc_id>", legIDSQueue);
						collection = Utilities.executeQuery(dfSession, reportPrjQry, DfQuery.EXECREAD_QUERY);
						while(collection.next()){
							docSize = docSize+Float.parseFloat(collection.getString("folder_size"));
							docCNT = docCNT+Integer.parseInt(collection.getString("doc_count"));
						}
				}

				//Update DB for report 1
				addToArrayList(updateReport_1_TBL(projectID,docSize,docCNT,docIdentity,reportUtilID));

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				importDocLogger.log(Level.WARNING,"SQLException During updating document count report closing the resultset for projects", e);
				importDocLogger.warning("SQLException::" + e.getMessage());
				e.printStackTrace();
			}catch (DfException e) {
				// TODO Auto-generated catch block
				importDocLogger.log(Level.WARNING,"DfException During updating document count report closing the resultset for projects", e);
				importDocLogger.warning("DfException::" + e.getMessage());
				e.printStackTrace();
			}finally{
				if(collection != null){
					try {
						collection.close();
					} catch (DfException e) {
						// TODO Auto-generated catch block
						importDocLogger.log(Level.WARNING,"SQLException During updating document count report closing the resultset for projects", e);
						importDocLogger.warning("DfException::" + e.getMessage());
						e.printStackTrace();
					}
				}
			}
		}
	}

	private static void updateReport_1_CTRY_TBL(String countries, String reportUtilID, String extUtilityCode, String regionName) {
		// TODO Auto-generated method stub
				
		IDfCollection collection = null;
		String docIdentity = idocsProperties.getProperty("MSG_RECON_REPORT_IDENT_CTRY");
		StringTokenizer projectTokens = new StringTokenizer(countries,",");
		while(projectTokens.hasMoreTokens()){
			float docSize = 0;
			int docCNT = 0;
			String legIDsQueue = "";
			String ctryCode = projectTokens.nextToken();
			importDocLogger.warning("Processing Document Count Report for the Country Code::"+ctryCode);
			String getLegacyIds = idocsProperties.getProperty("MSG_DB_GET_LEGACY_IDS_QUEUE_CTRY")
										.replaceFirst("<region_name>", regionName)
											.replaceFirst("<extraction_utility_code>", extUtilityCode)
												.replaceFirst("<folder_value_code>", ctryCode);
			ResultSet getMigInf = UpdateDB.selectFrmDatabse(getLegacyIds.toString());
			try {
				while(getMigInf.next()){
					if(legIDsQueue==""){
						legIDsQueue = getMigInf.getString("LEGACY_DOCUMENT_ID");
					}else{
						legIDsQueue += ","+getMigInf.getString("LEGACY_DOCUMENT_ID");
					}
				}if(getMigInf!= null){
					getMigInf.close();
				}
				String[] legacyIDS = legIDsQueue.split(",");
				int idsLength = legacyIDS.length;
				Float idsCNT = new Float(idsLength);
				Float fltids = idsCNT/100;
				int roundedINT = (int) Math.ceil(fltids);
				int temp = 0;
				int tempCNT = 0;
				for(int i=1;i<=roundedINT;i++){
					if(i==roundedINT){
						tempCNT = idsLength;
					}else{
						tempCNT = tempCNT+100;
					}
					String legIDSQueue = "";
					for(int k=temp;k<tempCNT;k++){
						if(legIDSQueue==""){
							legIDSQueue = legacyIDS[k];
							}else{
								legIDSQueue += "','"+legacyIDS[k];
							}
						}
						temp = temp+100;
						String reportCtryQry = idocsProperties.getProperty("MSG_GET_REPORT1_CTRY_QUERY")
												.replaceFirst("<country_code>", ctryCode)
													.replaceFirst("<orig_doc_id>", legIDSQueue);
						collection = Utilities.executeQuery(dfSession, reportCtryQry, DfQuery.EXECREAD_QUERY);
						while(collection.next()){
							docSize = docSize+Float.parseFloat(collection.getString("folder_size"));
							docCNT = docCNT+Integer.parseInt(collection.getString("doc_count"));
						}
				}
				
				//Update DB for report 1
				addToArrayList(updateReport_1_TBL(ctryCode,docSize,docCNT,docIdentity,reportUtilID));
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				importDocLogger.log(Level.WARNING,"SQLException During updating document count report closing the resultset for countries", e);
				importDocLogger.warning("DfException::" + e.getMessage());
				e.printStackTrace();
			}catch (DfException e) {
				// TODO Auto-generated catch block
				importDocLogger.log(Level.WARNING,"DfException During updating document count report closing the resultset for countries", e);
				importDocLogger.warning("DfException::" + e.getMessage());
				e.printStackTrace();
			}finally{
				if(collection != null){
					try {
						collection.close();
					} catch (DfException e) {
						// TODO Auto-generated catch block
						importDocLogger.log(Level.WARNING,"SQLException During updating document count report closing the resultset for countries", e);
						importDocLogger.warning("DfException::" + e.getMessage());
						e.printStackTrace();
					}
				}
			}
		}
	}
	
	private static void updateReport_2_CTRY_TBL(String countries, String reportUtilID, String extUtilityCode, String regionName) {
		// TODO Auto-generated method stub
		
		IDfCollection collection = null;
		String docIdentity = idocsProperties.getProperty("MSG_RECON_REPORT_IDENT_CTRY");
		StringTokenizer ctryTokens = new StringTokenizer(countries,",");
		while(ctryTokens.hasMoreTokens()){
			String legIDsQueue = "";
			documentCNT = 0;
			documentSize = 0; 
			subFldDetalsHM = new HashMap();
			String ctryCode = ctryTokens.nextToken();
			importDocLogger.warning("Processing Document Detail Report for the Country Code::"+ctryCode);
			String getLegacyIds = idocsProperties.getProperty("MSG_DB_GET_LEGACY_IDS_QUEUE_CTRY")
										.replaceFirst("<region_name>", regionName)
											.replaceFirst("<extraction_utility_code>", extUtilityCode)
												.replaceFirst("<folder_value_code>", ctryCode);
			ResultSet getMigInf = UpdateDB.selectFrmDatabse(getLegacyIds.toString());
			try {
				while(getMigInf.next()){
					if(legIDsQueue==""){
						legIDsQueue = getMigInf.getString("LEGACY_DOCUMENT_ID");
					}else{
						legIDsQueue += ","+getMigInf.getString("LEGACY_DOCUMENT_ID");
					}
				}if(getMigInf!= null){
					getMigInf.close();
				}
				String[] legacyIDS = legIDsQueue.split(",");
				int idsLength = legacyIDS.length;
				Float idsCNT = new Float(idsLength);
				Float fltids = idsCNT/100;
				int roundedINT = (int) Math.ceil(fltids);
				int temp = 0;
				int tempCNT = 0;
				for(int i=1;i<=roundedINT;i++){
					if(i==roundedINT){
						tempCNT = idsLength;
					}else{
						tempCNT = tempCNT+100;
					}
					String legIDSQueue = "";
					for(int k=temp;k<tempCNT;k++){
						if(legIDSQueue==""){
							legIDSQueue = legacyIDS[k];
							}else{
								legIDSQueue += "','"+legacyIDS[k];
							}
						}
						temp = temp+100;
						String reportCtryQry = idocsProperties.getProperty("MSG_GET_REPORT2_CNTRY_QUERY")
												.replaceFirst("<country_code>", ctryCode)
													.replaceFirst("<orig_doc_id>", legIDSQueue);
						collection = Utilities.executeQuery(dfSession, reportCtryQry, DfQuery.EXECREAD_QUERY);
						while(collection.next()){
//							String fldValueCode = collection.getString("country_code");
							String fldTitle = collection.getString("object_name");
							String fldDocSize = collection.getString("folder_size");
							String fldDocCnt = collection.getString("doc_count");
							
							//Grouping subfolder details to a single unit country wise
							addtoHMSubfolderDetails(fldTitle,fldDocSize,fldDocCnt);
						}
				}
				
				//Update DB for report 2
				updateReport_2_TBL(ctryCode,docIdentity,reportUtilID,subFldDetalsHM);
				subFldDetalsHM.clear();
				subFldDetalsHM = null;
				
			}catch (DfException e){
				// TODO Auto-generated catch block
				importDocLogger.warning("DfException::" + e.getMessage());
				importDocLogger.log(Level.WARNING,"DfException During updating subfolder doc count for countries", e);
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				importDocLogger.log(Level.WARNING,"SQLException During updating subfolder doc count for countries", e);
				importDocLogger.warning("DfException::" + e.getMessage());
				e.printStackTrace();
			}finally{
				if(collection != null){
					try {
						collection.close();
					} catch (DfException e) {
						// TODO Auto-generated catch block
						importDocLogger.log(Level.WARNING,"DfException closing collection for subfolder doc count for countries", e);
						importDocLogger.warning("DfException::" + e.getMessage());
						e.printStackTrace();
					}
				}
			}
		}
	}
	
	private static void updateReport_2_PRJ_TBL(String projectIDs, String reportUtilID, String extUtilityCode, String regionName) {
		// TODO Auto-generated method stub
		
		IDfCollection collection = null;
		String docIdentity = idocsProperties.getProperty("MSG_RECON_REPORT_IDENT_PROJ");
		StringTokenizer projectTokens = new StringTokenizer(projectIDs,",");
		while(projectTokens.hasMoreTokens()){
			String legIDsQueue = "";
			documentCNT = 0;
			documentSize = 0; 
			subFldDetalsHM = new HashMap();
			String projectID = projectTokens.nextToken();
			importDocLogger.warning("Processing Document Detail Report for the Project ID::"+projectID);
			String getLegacyIds = idocsProperties.getProperty("MSG_DB_GET_LEGACY_IDS_QUEUE_PRJ")
										.replaceFirst("<region_name>", regionName)
											.replaceFirst("<extraction_utility_code>", extUtilityCode)
												.replaceFirst("<folder_value_code>", projectID);
			ResultSet getMigInf = UpdateDB.selectFrmDatabse(getLegacyIds.toString());
			try {
				while(getMigInf.next()){
					if(legIDsQueue==""){
						legIDsQueue = getMigInf.getString("LEGACY_DOCUMENT_ID");
					}else{
						legIDsQueue += ","+getMigInf.getString("LEGACY_DOCUMENT_ID");
					}
				}if(getMigInf!= null){
					getMigInf.close();
				}
				String[] legacyIDS = legIDsQueue.split(",");
				int idsLength = legacyIDS.length;
				Float idsCNT = new Float(idsLength);
				Float fltids = idsCNT/100;
				int roundedINT = (int) Math.ceil(fltids);
				int temp = 0;
				int tempCNT = 0;
				for(int i=1;i<=roundedINT;i++){
					if(i==roundedINT){
						tempCNT = idsLength;
					}else{
						tempCNT = tempCNT+100;
					}
					String legIDSQueue = "";
					for(int k=temp;k<tempCNT;k++){
						if(legIDSQueue==""){
							legIDSQueue = legacyIDS[k];
							}else{
								legIDSQueue += "','"+legacyIDS[k];
							}
						}
						temp = temp+100;
						String reportPrjQry = idocsProperties.getProperty("MSG_GET_REPORT2_PROJ_QUERY")
												.replaceFirst("<project_id>", projectID)
													.replaceFirst("<orig_doc_id>", legIDSQueue);
						collection = Utilities.executeQuery(dfSession, reportPrjQry, DfQuery.EXECREAD_QUERY);
						while(collection.next()){
	//						String fldValueCode = collection.getString("country_code");
							String fldTitle = collection.getString("object_name");
							String fldDocSize = collection.getString("folder_size");
							String fldDocCnt = collection.getString("doc_count");
							
							//Grouping subfolder details to a single unit project wise
							addtoHMSubfolderDetails(fldTitle,fldDocSize,fldDocCnt);
						}
				}
				
				//Update DB for report 2
				updateReport_2_TBL(projectID,docIdentity,reportUtilID,subFldDetalsHM);
				subFldDetalsHM.clear();
				subFldDetalsHM = null;
				
			}catch (DfException e){
				// TODO Auto-generated catch block
				importDocLogger.log(Level.WARNING,"DfException During updating subfolder doc count for projects", e);
				importDocLogger.warning("DfException::" + e.getMessage());
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				importDocLogger.log(Level.WARNING,"SQLException During updating subfolder doc count for projects", e);
				importDocLogger.warning("DfException::" + e.getMessage());
				e.printStackTrace();
			}finally{
				if(collection != null){
					try {
						collection.close();
					} catch (DfException e) {
						// TODO Auto-generated catch block
						importDocLogger.log(Level.WARNING,"DfException closing collection for subfolder doc count for projects", e);
						importDocLogger.warning("DfException::" + e.getMessage());
						e.printStackTrace();
					}
				}
			}
		}
	}
	
	private static void updateReport_2_INST_TBL(String institutionNbrs, String reportUtilID, String extUtilityCode, String regionName) {
		// TODO Auto-generated method stub
		
		IDfCollection collection = null;
		String docIdentity = idocsProperties.getProperty("MSG_RECON_REPORT_IDENT_INST");
		StringTokenizer instTokens = new StringTokenizer(institutionNbrs,",");
		while(instTokens.hasMoreTokens()){
			String legIDsQueue = "";
			documentCNT = 0;
			documentSize = 0; 
			subFldDetalsHM = new HashMap();
			String instNbr = instTokens.nextToken();
			importDocLogger.warning("Processing Document Detail Report for the Institution Nbr::"+instNbr);
			
			String getLegacyIds = idocsProperties.getProperty("MSG_DB_GET_LEGACY_IDS_QUEUE_INST")
										.replaceFirst("<region_name>", regionName)
											.replaceFirst("<extraction_utility_code>", extUtilityCode)
												.replaceFirst("<folder_value_code>", instNbr);
			ResultSet getMigInf = UpdateDB.selectFrmDatabse(getLegacyIds.toString());
			try {
				while(getMigInf.next()){
					if(legIDsQueue==""){
						legIDsQueue = getMigInf.getString("LEGACY_DOCUMENT_ID");
					}else{
						legIDsQueue += ","+getMigInf.getString("LEGACY_DOCUMENT_ID");
					}
				}if(getMigInf!= null){
					getMigInf.close();
				}
				String[] legacyIDS = legIDsQueue.split(",");
				int idsLength = legacyIDS.length;
				Float idsCNT = new Float(idsLength);
				Float fltids = idsCNT/100;
				int roundedINT = (int) Math.ceil(fltids);
				int temp = 0;
				int tempCNT = 0;
				for(int i=1;i<=roundedINT;i++){
					if(i==roundedINT){
						tempCNT = idsLength;
					}else{
						tempCNT = tempCNT+100;
					}
					String legIDSQueue = "";
					for(int k=temp;k<tempCNT;k++){
						if(legIDSQueue==""){
							legIDSQueue = legacyIDS[k];
							}else{
								legIDSQueue += "','"+legacyIDS[k];
							}
						}
						temp = temp+100;
						String reportInstQry = idocsProperties.getProperty("MSG_GET_REPORT2_INST_QUERY")
												.replaceFirst("<institution_nbr>", instNbr)
													.replaceFirst("<orig_doc_id>", legIDSQueue);
						collection = Utilities.executeQuery(dfSession, reportInstQry, DfQuery.EXECREAD_QUERY);
						while(collection.next()){
	//						String fldValueCode = collection.getString("country_code");
							String fldTitle = collection.getString("object_name");
							String fldDocSize = collection.getString("folder_size");
							String fldDocCnt = collection.getString("doc_count");
							
							//Grouping subfolder details to a single unit project wise
							addtoHMSubfolderDetails(fldTitle,fldDocSize,fldDocCnt);
						}
				}
				
				//Update DB for report 2
				updateReport_2_TBL(instNbr,docIdentity,reportUtilID,subFldDetalsHM);
				subFldDetalsHM.clear();	
				subFldDetalsHM = null;

			}catch (DfException e){
				// TODO Auto-generated catch block
				importDocLogger.log(Level.WARNING,"DfException During updating subfolder doc count for institutions", e);
				importDocLogger.warning("DfException::" + e.getMessage());
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				importDocLogger.log(Level.WARNING,"SQLException During updating subfolder doc count for institutions", e);
				importDocLogger.warning("DfException::" + e.getMessage());
				e.printStackTrace();
			}finally{
				if(collection != null){
					try {
						collection.close();
					} catch (DfException e) {
						// TODO Auto-generated catch block
						importDocLogger.log(Level.WARNING,"DfException closing collection for subfolder doc count for institutions", e);
						importDocLogger.warning("DfException::" + e.getMessage());
						e.printStackTrace();
					}
				}
			}
		}
	}

	private static void addToArrayList(String updateQry) {
		// TODO Auto-generated method stub
		
		if(qryList.size() >=100){
			UpdateDB.executeBatch(qryList,UpdateDB.getBatchConnection());
//			UpdateDB.executeBatch(qryList);
			qryList.clear();
		}
		qryList.add(updateQry);
	}
	
	private static String getLegacyDocIDs(String regionName,String extUtilityCode, String folderValueCode) {
		
		// TODO Auto-generated method stub
		
		String getFldValueCode = idocsProperties.getProperty("MSG_DB_GET_LEGACY_IDS_QUEUE")
									.replaceFirst("<region_name>", regionName)
										.replaceFirst("<extraction_utility_code>", extUtilityCode)
											.replaceFirst("<folder_value_code>", folderValueCode);
		ResultSet getMigInf = UpdateDB.selectFrmDatabse(getFldValueCode.toString());
		String legacyDocIDs = "";
		try {
			while(getMigInf.next()){
				if(legacyDocIDs==""){
					legacyDocIDs = getMigInf.getString("LEGACY_DOCUMENT_ID");
				}else{
					legacyDocIDs += "','"+getMigInf.getString("LEGACY_DOCUMENT_ID");
				}
			}if(getMigInf!=null){
				getMigInf.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException::" + e.getMessage());
			importDocLogger.log(Level.WARNING,"SQLException During fetching the legacy document ids", e);
			e.printStackTrace();
		}
		return legacyDocIDs;
	}

	private static void addtoHMSubfolderDetails(String fldTitle, String fldDocSize, String fldDocCnt) {
		// TODO Auto-generated method stub
		
		if(subFldDetalsHM.containsKey(fldTitle)){
			String hmValue = (String) subFldDetalsHM.get(fldTitle);
			String[] docDetails = hmValue.split("@#");
			String subFldTitle = docDetails[0];
			documentSize = Float.parseFloat(fldDocSize)+Float.parseFloat(docDetails[1]);
			documentCNT = Integer.parseInt(fldDocCnt)+Integer.parseInt(docDetails[2]);
			subFldDetalsHM.put(fldTitle, subFldTitle+"@#"+documentSize+"@#"+documentCNT);
		}else{
			subFldDetalsHM.put(fldTitle, fldTitle+"@#"+fldDocSize+"@#"+fldDocCnt);
		}
		
	}
	
	private static String updateReport_1_TBL(String fldValueCode, Float docSize, Integer docCnt,
			String docIdentity, String reportUtilID) {
		// TODO Auto-generated method stub
		
		String updatReportTBL = idocsProperties.getProperty("MSG_UPDATE_REPORT1_QUERY");
		updatReportTBL = updatReportTBL.replaceFirst("<report_utility_code>", reportUtilID)
							.replaceFirst("<folder_value_code>", fldValueCode)
								.replaceFirst("<folder_size>", docSize.toString())
									.replaceFirst("<document_count>", docCnt.toString())
										.replaceFirst("<document_type>", docIdentity);
		//Updating the Reporting DB with the current stats
		//System.out.println(updatReportTBL);
		//importDocLogger.info("Updating DB with Query::"+updatReportTBL);
//		UpdateDB.updateDatabase(updatReportTBL);
		return updatReportTBL;
	}

	private static void updateReport_2_TBL(String divisionCode,
			String docIdentity, String reportUtilID, HashMap subFldDetalsHM2) {
		// TODO Auto-generated method stub
		Set set = subFldDetalsHM2.entrySet();
		Iterator i = set.iterator();
		String updatReportTBL = "";
		while(i.hasNext()){
			Map.Entry subFldMap = (Map.Entry)i.next();
			String hmKey = (String) subFldMap.getKey();
			String hmValue = (String) subFldMap.getValue();
			String[] subFldValues = hmValue.split("@#");
			String subFldDocSize = subFldValues[1];
			String subFldDocCount = subFldValues[2];
			
			if(hmKey.contains("\\")){
				hmKey = hmKey.replaceAll("\\\\", "/");
			}
			
			updatReportTBL = idocsProperties.getProperty("MSG_UPDATE_REPORT2_QUERY")
										.replaceFirst("<report_utility_code>", reportUtilID)
												.replaceFirst("<folder_value_code>", divisionCode)
														.replaceFirst("<folder_title>",hmKey)
															.replaceFirst("<folder_size>", subFldDocSize)
																.replaceFirst("<document_count>", subFldDocCount)
																	.replaceFirst("<document_type>", docIdentity);
			addToArrayList(updatReportTBL);
		}
	}
	
	private static String updateReport_3_TBL(String fldValueCode, String docName,
			String docVersion, String docSecClass, String doclegacyID,
			String doclegacyUniqueID, String docRObjectID, String docIChronicleID, String reportUtilID) {
		// TODO Auto-generated method stub
		docName = docName.replaceAll("'", "''");
		String updatReportTBL = idocsProperties.getProperty("MSG_UPDATE_REPORT3_QUERY")
									.replaceFirst("<report_utility_code>", reportUtilID)
										.replaceFirst("<folder_value_code>", fldValueCode)
											.replaceFirst("<document_name>", docName)
												.replaceFirst("<doc_version>", docVersion)
													.replaceFirst("<doc_sec_clas>", docSecClass)
														.replaceAll("<i_chronicle_id>", docIChronicleID)
															.replaceAll("<r_object_id>", docRObjectID)
																.replaceAll("<orig_doc_id>", doclegacyID)
																	.replaceAll("<orig_doc_unique_id>", doclegacyUniqueID);
		//Updating the Reporting DB with the current stats
		return updatReportTBL;
	}
}
