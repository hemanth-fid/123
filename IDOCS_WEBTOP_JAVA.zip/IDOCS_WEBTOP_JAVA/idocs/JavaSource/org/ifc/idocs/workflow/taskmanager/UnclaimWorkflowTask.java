/**
* The custom component class is used to unclaim the accepted task
*  
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Parag Doshi			01/10/2011		1.0				created
  Gangadhar				07/14/2011		2.0				modified
* #######################################################################################################
*/
package org.ifc.idocs.workflow.taskmanager;

import com.documentum.bpm.IDfWorkitemEx;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfWorkflow;
import com.documentum.fc.client.IDfWorkitem;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfList;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfList;
import com.documentum.services.workflow.inbox.IWorkflowTask;
import com.documentum.web.common.ArgumentList;
import com.documentum.webcomponent.library.workflow.taskmanager.WorkflowTaskComponent;

public class UnclaimWorkflowTask extends WorkflowTaskComponent {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void onInit(ArgumentList args) {
		super.onInit(args);
		try {
			DfLogger.info(this, " :: onInit : " + getDfSession().getLoginUserName(), null, null);
			unclaim();
			setComponentJump("inboxclassic", "start", getContext());
		} catch (DfException e) {
			DfLogger.error(this, " :: onInit Exception >> " + e.getMessage(),
					null, e);
		}
	}

	public void unclaim() throws DfException {
		String workflowName = null;
		String performer_group = null;
		IDfList m_usersToRepeat = new DfList();
		IWorkflowTask task = super.getWorkflowTask();
		IDfSession session = getDfSession();
		IDfWorkitem objWorkItem = (IDfWorkitem) session.getObject((DfId) task.getItemId());
		IDfWorkflow objWorkflow = (IDfWorkflow) session.getObject((DfId) objWorkItem.getWorkflowId());
		workflowName = objWorkflow.getObjectName();
		String wfObjectId = objWorkflow.getObjectId().getId();
		DfLogger.info(this, "onNextComponent :: Workflow Name : "+ workflowName, null, null);
		DfLogger.info(this, "onNextComponent :: Workflow ID : " + wfObjectId,null, null);
		String actDefId = objWorkItem.getActDefId().toString();
		if (workflowName.startsWith("AS ")) {
			performer_group = "as_" + wfObjectId + "_" + actDefId.substring(10);
		} else if (workflowName.startsWith("Sub Workflow")) {		
			try {
				IDfWorkitemEx workItemEx = (IDfWorkitemEx) getDfSession().getObject(objWorkItem.getObjectId());
				performer_group = (String) workItemEx.getStructuredDataTypeAttrValue("SubProcessVariables","groupName");
			} catch (DfException e) {
				DfLogger.error(this, "Exception in unclaiming activity",null, null);
				e.printStackTrace();
			}
		} else {
			performer_group = "idocs_" + wfObjectId + "_"+ actDefId.substring(10);
		}
		DfLogger.info(this,"Unclaim() :: Performer Group : " + performer_group,null, null);
		m_usersToRepeat.append(performer_group);
		task.setDelegateUser(performer_group);
		task.completeTask();
		setReturnValue("_returnValue", "true");
	}
}
