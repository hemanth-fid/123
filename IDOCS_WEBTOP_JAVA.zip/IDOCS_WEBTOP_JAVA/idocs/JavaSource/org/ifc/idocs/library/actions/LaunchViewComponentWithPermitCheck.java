/**
* This class to check the permisions for the component to validate.
* #######################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################
*/
package org.ifc.idocs.library.actions;

import java.util.HashMap;
import java.util.Map;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.ErrorMessageService;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

public class LaunchViewComponentWithPermitCheck extends
		com.documentum.web.formext.action.LaunchComponentWithPermitCheck {

	private static final long serialVersionUID = 1L;
    private static final NlsResourceBundle s_lookup = new NlsResourceBundle("org.ifc.idocs.action.ValidateGroupMembershipNlsProp");
	private static final String MSG_VIEWED = "Viewed";
	private static final String QRY_VARIABLE_LOGINUSERNAME = "<loginusername>";
	private static final String QRY_VARIABLE_ROLESTRING = "<rolestring>";

	
	String accessRole = null;
	HashMap<String, String> docValuesMap = new HashMap<String, String>();

    /**
     * 
     */
	public boolean execute(String strAction, IConfigElement config, 
			ArgumentList args, Context context, Component component, Map completionArgs){
		if(IdocsUtil.MSG_TASK_ATTACHMENT_COMPONENT_ID.equalsIgnoreCase(component.getComponentId())){
			DfLogger.info(this, " :: LaunchViewComponentWithPermitCheck : ALLOWED : This is from Workflow Task :",null,null);
			return super.execute(strAction, config, args, context, component, completionArgs);
		}else{
			DfLogger.info(this, " :: LaunchViewComponentWithPermitCheck : This is Not from Workflow Task : Continue With further tests",null,null);
		}
		String strObjectId = args.get("objectId");
		docValuesMap= IdocsUtil.getRequiredAttributesValues(strObjectId, component.getDfSession());
		DfLogger.info(this, " :: LaunchViewComponentWithPermitCheck : execute : Object ID "+strObjectId,null,null);
		boolean validated = false;
		try{
			if(strObjectId != null && strObjectId.trim().length()>0 && strObjectId.startsWith(IDocsConstants.MSG_DM_DOC_TYPE_PREF_CODE)){
				String strObjectName =docValuesMap.get(IDocsConstants.MSG_OBJECT_NAME); 
				DfLogger.info(this, " :: execute : Object Name ="+strObjectName,null,null);
				validated = validateUserPermissionsForView(false,strObjectId,component.getDfSession(),docValuesMap);
				DfLogger.info(this, " :: execute : validated ="+validated,null,null);
				if(validated == true ){
					IdocsUtil.auditIDocsActivity(MSG_VIEWED,strObjectId,component.getDfSession());
					return super.execute(strAction, config, args, context, component, completionArgs);
				}else{
					if(accessRole != null && accessRole.trim().length() > 0){
						accessRole = "Core Team,Approvers OR Other Editors";
					}else{
						accessRole= "Core Team,Approvers OR Other Editors";// " Authorized";
					}
			        ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_ACTION_PERMISSION_DENIED", component, new String[]{"View",strObjectName,IdocsUtil.handleLDAPEnvVariable(accessRole, component.getDfSession())}, null);
					return false;
				}			
			}else{
				IdocsUtil.auditIDocsActivity(MSG_VIEWED,strObjectId,component.getDfSession());
				return super.execute(strAction, config, args, context, component, completionArgs);
			}
		}catch (Exception e) {
			DfLogger.error(this, " :: LaunchViewComponentWithPermitCheck :: execute : Exception :"+e.getMessage(),null,null);
		}
		return false;
    }

	/**
	 * 
	 * @param strObjectId
	 * @param completionArgs
	 * @param component
	 * @param session
	 * @return
	 * @throws DfException
	 */
	public static boolean validateUserPermissionsForView(boolean isFromEdit,String strObjectId,IDfSession session,HashMap<String, String> docValuesMap) throws DfException {
		try{
			String strObjectType = ""; 
			String strDocState = "";   
			String strOwnerName = "";  
			String currentSecurityClassificationCode = "";
			if(docValuesMap != null && docValuesMap.size() >0){
				//don't care 
			}else{
				docValuesMap= IdocsUtil.getRequiredAttributesValues(strObjectId, session);
			}
			currentSecurityClassificationCode = docValuesMap.get(IDocsConstants.MSG_SEC_CLASSIFICATION_CODE);
			strObjectType = docValuesMap.get(IdocsConstants.R_OBJECT_TYPE); 
			strDocState = docValuesMap.get(IDocsConstants.MSG_DOC_STATE); 
			strOwnerName = docValuesMap.get(IDocsConstants.MSG_OWNER_NAME);
			
			DfLogger.info(LaunchViewComponentWithPermitCheck.class,"::validateUserPermissionsForView  Document State : " + strDocState, null, null);
			String admingGroupName = IdocsUtil.getMessage("MSG_IDOCS_ADMIN_GRP");
			DfLogger.debug(LaunchViewComponentWithPermitCheck.class, " :: MSG_IDOCS_ADMIN_GRP : "+admingGroupName, null, null);
			if(admingGroupName != null && admingGroupName.trim().length() > 0 
					&& IdocsUtil.isMemberOfGroup(admingGroupName, session)){
				DfLogger.debug(LaunchViewComponentWithPermitCheck.class, " :: validateUserPermissionsForView : IDocs Admin : Allow Delete", null, null);
				return true;
			}
			
			if(isFromEdit == false){				
			
				String readersGroupName = IdocsUtil.getMessage("MSG_IFCDOCS_READERS_GRP");
				DfLogger.debug(LaunchViewComponentWithPermitCheck.class, " :: MSG_IFCDOCS_READERS_GRP : "+readersGroupName, null, null);
				if(readersGroupName != null && readersGroupName.trim().length() > 0 
						&& IdocsUtil.isMemberOfGroup(readersGroupName, session)){
					DfLogger.debug(LaunchViewComponentWithPermitCheck.class, " :: User is part of - "+readersGroupName, null, null);
					return true;
				}
				String projReadersGroup = IdocsUtil.getMessage("MSG_IFCDOCS_PROJ_READER_GRP");
				if(strObjectType != null 
		       			&& strObjectType.equals(IDocsConstants.MSG_IDOCS_PROJECT_DOC)){
					String projectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(session, strObjectId, IDocsConstants.PROJECT_ID, IDocsConstants.MSG_IDOCS_PROJECT_DOC);
					if(projectId !=null && projectId.trim().length() > 0 
							&& projReadersGroup!=null && projReadersGroup.trim().length() > 0
							&& IdocsUtil.isMemberOfGroup(projReadersGroup.replace("#", projectId), session)){
						DfLogger.debug(LaunchViewComponentWithPermitCheck.class, " :: validateUserPermissionsForEdit : Validated Against Proj Writer Group", null, null);
						return true;
					}			
				}
			}
			
			/** If the document is country allow user to edit the permissions  */
			if(strObjectType!=null && strObjectType.trim().length() > 0 
					&& strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_COUNTRY_DOC)){
				return true;
			}
			
			
			
			
			/** Documents owners are allowed to View the document */
			if(strOwnerName!=null && strOwnerName.equalsIgnoreCase(session.getLoginUserName()) == true ){
				return true;
			}
			/** For 'Released' ACL will decide who can View the document */
			//if(strDocState!=null && strDocState.equalsIgnoreCase(IDocsConstants.MSG_STATE_RELEASED) == true ){
			if(strObjectType != null && strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_PROJECT_DOC)){
				String projectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(session,strObjectId,IdocsConstants.PROJ_ID,strObjectType);
//					if(IDocsConstants.MSG_OFFICIAL_CODE.equals(currentSecurityClassificationCode)){
					if(IdocsUtil.isUserPresentInConflictOfInterest(projectId,session) || IdocsUtil.isUserMemberofLDAPGroup(
							IdocsUtil.getMessage(IdocsConstants.CONFLICT_OF_INTEREST_ROLE), projectId, session)){
							DfLogger.info(LaunchViewComponentWithPermitCheck.class,"::validateUserPermissionsForView  User is Present in Conflict Of Interest:", null, null);
							return false;
						}else{
//							return true;
						}
//					}else{
////						return true;
//					}	
				}else{
					/** This was an institution document */
//					return true;
				}
//			}
			
			/** Checks View Permission */
			return handleDraftProjnInstiDocuments(strObjectId, session,
					strObjectType, currentSecurityClassificationCode,
					strOwnerName,isFromEdit);
		}catch (Exception e) {
			DfLogger.info(LaunchViewComponentWithPermitCheck.class, " :: Exception:"+e.getMessage(),null,null);
		}
		return false;
	}

	private static boolean handleDraftProjnInstiDocuments(String strObjectId,
			IDfSession session, String strObjectType,
			String currentSecurityClassificationCode, String strOwnerName, boolean isFromEdit)
			throws DfException {
		String projectRole = null;
		if(strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_PROJECT_DOC)){
			if(IDocsConstants.MSG_OFFICIAL_CODE.equals(currentSecurityClassificationCode)){
				String projectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(session,strObjectId,IdocsConstants.PROJ_ID,strObjectType);
				if(isFromEdit){
					if(IdocsUtil.checkProjectInstiTeamMemberShip(null,projectId, session) == true ){
						return true;
					}else if(checkDepartmentMemberShip(projectId, session) == true ){
						return true;
					}else{
						return false;
					}
				}else{
					String coreGroupName = IdocsUtil.getMessage("MSG_IFC_CORE_GROUP");
					boolean isPresentInIFCCOREGroup = IdocsUtil.isMemberOfGroup(coreGroupName,session);
					if(isPresentInIFCCOREGroup){
						return true;
					}else{
						DfLogger.debug(LaunchViewComponentWithPermitCheck.class, "User '"+session.getLoginUserName()+"' is not part of IFCCoreGroup Continue With Role Validation", null, null);
						return false;
					}
				}
			}else if(IDocsConstants.MSG_CONFIDENTIAL_CODE.equals(currentSecurityClassificationCode)){
				projectRole = IdocsUtil.getMessage("PROJECT_DOCUMENT_VIEW_ROLE_C");
				String projectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(session,strObjectId,IdocsConstants.PROJ_ID,strObjectType);
				if(IdocsUtil.checkProjectInstiTeamMemberShip(null,projectId, session) == true ){
					return true;
				}else if(IdocsUtil.checkProjectInstiTeamMemberShip(projectRole,projectId, session)){
					return true;
				}else if(IdocsUtil.checkDmGroupMemberShip(projectRole, session)){
					return true;
				}else{
					return false;
				}
			}else if(IDocsConstants.MSG_STRICTLY_CONFIDENTIAL_CODE.equals(currentSecurityClassificationCode)){
				projectRole =IdocsUtil.getMessage("PROJECT_DOCUMENT_VIEW_ROLE_S");
				String projectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(session,strObjectId,IdocsConstants.PROJ_ID,strObjectType);
				if(IdocsUtil.checkProjectInstiTeamMemberShip(projectRole,projectId, session)){
					return true;
				}else if(IdocsUtil.checkDmGroupMemberShip(projectRole, session)){
					return true;
				}else{
					return false;
				}
			}else{
				DfLogger.info(LaunchViewComponentWithPermitCheck.class, " :: Exception: Unknown Security Classification Code : "+currentSecurityClassificationCode,null,null);
				if(strOwnerName!=null && strOwnerName.equalsIgnoreCase(session.getLoginUserName()) == true ){
					return true;
				}else{
					return false;
				}
			}
		}else if(strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_INSTITUTION_DOC)){
			if(IDocsConstants.MSG_OFFICIAL_CODE.equals(currentSecurityClassificationCode)){
				if(isFromEdit){
					String institutionNumber = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(session,strObjectId,IdocsConstants.INSTITUTION_ID,strObjectType);
					String clientProjectIds = IdocsUtil.getClientProjects(institutionNumber, session);
					if(clientProjectIds !=null && clientProjectIds.trim().length() >0 
							&& IdocsUtil.checkProjectInstiTeamMemberShip(null,clientProjectIds, session) == true ){
						return true;
					}else if(clientProjectIds !=null && clientProjectIds.trim().length() >0 
							&& checkDepartmentMemberShip(clientProjectIds, session) == true ){
						return true;
					}else{
						return false;
					}
				}else{
					String coreGroupName = IdocsUtil.getMessage("MSG_IFC_CORE_GROUP");
					boolean isPresentInIFCCOREGroup = IdocsUtil.isMemberOfGroup(coreGroupName,session);
					if(isPresentInIFCCOREGroup){
						return true;
					}else{
						DfLogger.debug(LaunchViewComponentWithPermitCheck.class, "User '"+session.getLoginUserName()+"' is not part of IFCCoreGroup Continue With Role Validation", null, null);
						return  false;
					}
				}
			}else if(IDocsConstants.MSG_CONFIDENTIAL_CODE.equals(currentSecurityClassificationCode)){
				String institutionNumber = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(session,strObjectId,IdocsConstants.INSTITUTION_ID,strObjectType);
				String clientProjects = IdocsUtil.getClientProjects(institutionNumber,session);
				projectRole = IdocsUtil.getMessage("PROJECT_DOCUMENT_VIEW_ROLE_C");
				if(IdocsUtil.checkProjectInstiTeamMemberShip(null,clientProjects, session) == true ){
					return true;
				}else if(IdocsUtil.checkProjectInstiTeamMemberShip(projectRole,clientProjects, session)){
					return true;
				}else if(IdocsUtil.checkDmGroupMemberShip(projectRole,session)){
					return true;
				}else{
					return false;
				}			
			}else if(IDocsConstants.MSG_STRICTLY_CONFIDENTIAL_CODE.equals(currentSecurityClassificationCode)){
				String institutionNumber = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(session,strObjectId,IdocsConstants.INSTITUTION_ID,strObjectType);
				String clientProjects = IdocsUtil.getClientProjects(institutionNumber,session);
				projectRole = IdocsUtil.getMessage("PROJECT_DOCUMENT_VIEW_ROLE_S");
				if(IdocsUtil.checkProjectInstiTeamMemberShip(projectRole,clientProjects, session)){
					return true;
				}else if(IdocsUtil.checkDmGroupMemberShip(projectRole,session)){
					return true;
				}else{
					return false;
				}
			}else{
				DfLogger.info(LaunchViewComponentWithPermitCheck.class, " :: Exception: Unknown Security Classification Code : "+currentSecurityClassificationCode,null,null);
				if(strOwnerName!=null && strOwnerName.equalsIgnoreCase(session.getLoginUserName()) == true ){
					return true;
				}else{
					return false;
				}
			}
		}else if(strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_COUNTRY_DOC)){
			DfLogger.debug(LaunchViewComponentWithPermitCheck.class, " :: Country Document : "+currentSecurityClassificationCode,null,null);
			if(strOwnerName!=null && strOwnerName.equalsIgnoreCase(session.getLoginUserName()) == true ){
				return true;
			}else{
//				return false;
			}
			
			String coreGroupName = IdocsUtil.getMessage("MSG_IFC_CORE_GROUP");
			boolean isPresentInIFCCOREGroup = IdocsUtil.isMemberOfGroup(coreGroupName,session);
			if(isPresentInIFCCOREGroup){
				return true;
			}else{
				DfLogger.debug(LaunchViewComponentWithPermitCheck.class, "User '"+session.getLoginUserName()+"' is not part of IFCCoreGroup Continue With Role Validation", null, null);
				return  false;
			}
		}else{
			DfLogger.debug(LaunchViewComponentWithPermitCheck.class, " :: Exception: Unknown Type Allow Owner to View/Edit. ",null,null);
			if(strOwnerName!=null && strOwnerName.equalsIgnoreCase(session.getLoginUserName()) == true ){
				return true;
			}else{
				return false;
			}
		}
	}

	public static boolean checkDepartmentMemberShip(String projectId,IDfSession dfSession){
		boolean validated = false;
		try {
			String grp_Qry = IdocsUtil.getMessage("DEPT_ALPHA_CODE_QRY");
			grp_Qry = grp_Qry.replaceFirst("<projectId>", IdocsUtil.makeQuerySafe(projectId,null));
			DfLogger.info(LaunchViewComponentWithPermitCheck.class, " :: checkDepartmentMemberShip() : DEPT_ALPHA_CODE_QRY : "+grp_Qry,null,null);

			IDfQuery query = new DfQuery();
			query.setDQL(grp_Qry);
			IDfCollection dfCollection = query.execute(dfSession, IDfQuery.DF_READ_QUERY);
			String groupName = "", deptAlphaCode="";
			if(dfCollection.next()){
				deptAlphaCode = dfCollection.getString("dept_alpha_code");
				groupName = deptAlphaCode+" Emergency Data Admin";
				dfCollection.close();
			}
			if(dfCollection != null )dfCollection.close();
			grp_Qry = IdocsUtil.getMessage("QRY_LDAP_GROUP_MEMBER");
			grp_Qry = grp_Qry.replace(QRY_VARIABLE_LOGINUSERNAME, "'"+ IdocsUtil.handleSingleQuote(dfSession.getLoginUserName())+"'");
			grp_Qry = grp_Qry.replace(QRY_VARIABLE_ROLESTRING, "'"+groupName+"'");
			DfLogger.info(LaunchViewComponentWithPermitCheck.class, " :: checkDepartmentMemberShip() : LDAP_GRP_QRY : "+grp_Qry,null,null);
			query.setDQL(grp_Qry);
			dfCollection = query.execute(dfSession, IDfQuery.DF_READ_QUERY);
			while(dfCollection.next() && validated == false){
				validated = true;
			}
			if(dfCollection != null)dfCollection.close();
			
		} catch (DfException e) {
			e.printStackTrace();
			DfLogger.error(LaunchViewComponentWithPermitCheck.class, " :: checkDepartMentMemberShip() : Exception :" + e.getMessage(),null,null);
		}
		return validated ;
	}
	
}