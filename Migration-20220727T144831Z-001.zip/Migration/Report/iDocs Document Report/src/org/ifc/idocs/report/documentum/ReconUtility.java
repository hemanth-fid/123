package org.ifc.idocs.report.documentum;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Logger;

import org.ifc.idocs.report.ReportUtility;
import org.ifc.idocs.report.common.AppConfig;
import org.ifc.idocs.report.common.LogHelper;
import org.ifc.idocs.report.db.ImportSkippedDAOImpl;
import org.ifc.idocs.report.db.ReconDAOImpl;

/**
 * @author VVellakkattumana
 * @see ImportUtility - extracts all sort of documents from lotus notes database
 *
 */
public class ReconUtility extends ReportUtility{
	
	private static AppConfig config = AppConfig.getInstance();
	private Logger exportDocLogger = LogHelper.getLogger(ReconUtility.class);
	private String extractionQuery, prefix, folderTypeCode;

	/**
	 * Constructor for ReconUtility
	 */
	public void runReconUtility() {

		try{
			prefix = config.getString("filters.prefix");
			prefix = prefix.substring(0, 7);
			prefix = prefix + "%";
			extractionQuery = config.getString("filters.extractioncriteriacode");
			exportDocLogger.warning("EXTRACTION CRITERIA ID = " + extractionQuery );
			String[] extCriteria = extractionQuery.split(";");
			String exportPath = config.getString("repository.exportPath"); 

			for(int k = 0; k < extCriteria.length; k++){
				String extractionId = extCriteria[k];
				exportDocLogger.warning("Extraction id = " + extractionId);
				if(extractionId.contains("PRJ")){
					folderTypeCode = "PROJECTS";
				}else if(extractionId.contains("PTR")){
					folderTypeCode = "INSTITUTIONS";
				}
				ReconDAOImpl rdao = new ReconDAOImpl();
				rdao.updateReconTables(prefix, extractionId, folderTypeCode, exportPath);
				exportDocLogger.warning("Reconciliation Report Completed for  : " + extractionId);
				
				getNewUtilityId();
				LogHelper.loggerMap.put("loggerMap",null);
				exportDocLogger = LogHelper.getLogger(ReconUtility.class);
			}
			exportDocLogger.warning("Reconciliation Report Completed Successfully...!!!");			
		}
		catch (Exception e){
			exportDocLogger.warning("Initialization error");
			e.printStackTrace();
			System.exit(0);
		}
	}
	
	public void importSkippedDocsUpdation(){
		try {
			prefix = config.getString("filters.prefix");
			prefix = prefix.substring(0, 7);
			ImportSkippedDAOImpl iSkipped = new ImportSkippedDAOImpl();
			iSkipped.importSkipped(prefix);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
