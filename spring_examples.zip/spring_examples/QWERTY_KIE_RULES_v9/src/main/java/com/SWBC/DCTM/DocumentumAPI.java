package com.SWBC.DCTM;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfTypedObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfLoginInfo;

public class DocumentumAPI {
	
	public static IDfSession getDCTMSession(String user,String pass, String repo, String host,String port)
	{
		  IDfSessionManager sessionManager = null;
		  IDfSession session = null;
		  
		  try {
			sessionManager = createSessionMgr(user, pass, repo,
			              configureConnectionBroker(host, Integer.parseInt(port)));
		} catch (NumberFormatException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (DfException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		  try {
		        session = sessionManager.getSession("swbc_bpm");

		        System.out.println("Session created for Docabase '" + "swbc_bpm"
		                    + "'");
		  } catch (Exception ex) {
		        try {
					throw new Exception(
					            "Exception in DCTMSession(username, password, ) :: "
					                        + ex.getLocalizedMessage());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		  }
		  return session;
		
		
	}
	
	  private static IDfClientX configureConnectionBroker(String hostName, int portNumber)
	            throws DfException {
	      System.out.println("Inside configureConnectionBroker()...");

	      System.out.println("Host Name : '" + hostName + "'");
	      System.out.println("Port Name : '" + portNumber + "'");

	      IDfClientX clientx = new DfClientX();
	      IDfClient client;
	      try {
	            client = clientx.getLocalClient();
	            IDfTypedObject config = client.getClientConfig();
	            config.setString("primary_host", hostName);
	            config.setInt("primary_port", portNumber);

	      } catch (DfException dfe) {
	            throw new DfException(
	                        "DfException in configureConnectionBroker() :: "
	                                    + dfe.getLocalizedMessage());
	      }

	      return clientx;
	}

	private static IDfSessionManager createSessionMgr(String username,
	            String password, String docbasename, IDfClientX clientx)
	            throws DfException {

	      System.out.println("Inside createSessionMgr()...");

	      IDfSessionManager sMgr = null;
	      try {
	            IDfClient client = clientx.getLocalClient();
	            sMgr = client.newSessionManager();
	            IDfLoginInfo login = new DfLoginInfo();
	            login.setUser(username);
	            login.setPassword(password);
	            login.setDomain(null);

	            sMgr.setIdentity(docbasename, login);

	      } catch (DfException dfe) {
	            throw new DfException("DfException in createSessionMgr() :: "
	                        + dfe.getLocalizedMessage());
	      }

	      return sMgr;
	}
	
	

}
