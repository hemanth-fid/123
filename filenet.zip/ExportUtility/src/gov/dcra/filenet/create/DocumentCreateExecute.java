

package gov.dcra.filenet.create;

import gov.dcra.filenet.connection.DCRAFileNetConnection;
import gov.dcra.filenet.constants.Constants;
import gov.dcra.filenet.util.DCRAFileNetUtil;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.filenet.api.admin.StorageArea;
import com.filenet.api.collection.ContentElementList;
import com.filenet.api.constants.AutoClassify;
import com.filenet.api.constants.AutoUniqueName;
import com.filenet.api.constants.CheckinType;
import com.filenet.api.constants.ClassNames;
import com.filenet.api.constants.DefineSecurityParentage;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.core.ReferentialContainmentRelationship;
import com.filenet.api.util.Id;



/**
 * @author Administrator
 *
 */
public class DocumentCreateExecute {

	/**
	 * @param args
	 */

	private final static Logger log = Logger.getLogger(DocumentCreateExecute.class);
	private static String inputFileLoc = null;
	private static int successCtr=0;
	private static int failedCtr=0;

	private final String appPropsFile = Constants.APPLICATION_PROPS;
	private Properties appProps = new Properties();
	private static List<String> failedDeleteLst=null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		StringBuffer statsBuf=new StringBuffer();
		DocumentCreateExecute exec = null;
		try {

			StringBuilder sb = new StringBuilder();
			sb.append("0. Exit").append(Constants.NEWLINE);
			sb.append("1. Process Document Export").append(Constants.NEWLINE);

			sb.append("Please input the number to proceed");

			String sampleOperation = read(sb.toString());
			int op = 0;
			try {
				op = Integer.parseInt(sampleOperation);
				if (op == 0) {
					System.out.println("Thanks, bye....!");
					System.exit(0);
				} else if (op == 1) {
					inputFileLoc = read("Please input the input file path : ");

					while (!isFilenameValid(inputFileLoc)) {
						inputFileLoc = read("Please input a valid file path : ");
					}
				} else {
					System.out.println("Unsupported " + op);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			exec = new DocumentCreateExecute();
			exec.processDelete();
			statsBuf.append("------------------------------------------------------------------").append("\n");
			
			statsBuf.append("Delete Success : "+successCtr).append("\n");
			statsBuf.append("Delete Failed : "+failedCtr).append("\n");
			if(failedCtr>0){
				statsBuf.append("\n");
				statsBuf.append("Failed Records : ").append("\n");
				
				for(String failedDocId : failedDeleteLst){
					
					statsBuf.append("docID : ").append(StringUtils.substringBefore(failedDocId, "~")).
					append(" | Error : ").append(StringUtils.substringAfter(failedDocId, "~")).append("\n");
				}
				
			}
			statsBuf.append("------------------------------------------------------------------").append("\n");
			
			log.info(statsBuf);

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	private void processDelete() {

		DCRAFileNetConnection conn = null;
		DCRAFileNetUtil exportUtil = null;
		Domain domain = null;
		ObjectStore os = null;
		StringTokenizer docIds = null;
		String docId = null;	
		failedDeleteLst=new ArrayList<String>();
		try {

			log.debug("Start Processing......");
			appProps.load(DocumentCreateExecute.class.getResourceAsStream(appPropsFile));
			
			//String filename = appProps.getProperty(Constants.MSG_EXPORT_DIR).concat(Constants.FILESEPARATOR).concat(appProps.getProperty(Constants.MSG_EXPORT_FILENAME));
			conn = new DCRAFileNetConnection();
			exportUtil = new DCRAFileNetUtil();
			domain = conn.getDomain();
			os = exportUtil.getObjectStore(domain,appProps.getProperty(Constants.MSG_OBJECTSTORE_NAME));
			

		if(os!=null){
			
			InputStream file = "";
			String fileName = "";
			int fileSize = "";

			// Create a document instance.
			Document doc = Factory.Document.createInstance(os, ClassNames.DOCUMENT);
			
			if (file != null && fileSize > 0) {
                ContentTransfer contentTransfer = Factory.ContentTransfer.createInstance();
                contentTransfer.setCaptureSource(file);
                ContentElementList contentElementList = Factory.ContentElement.createList();
                contentElementList.add(contentTransfer);
                doc.set_ContentElements(contentElementList);
                contentTransfer.set_RetrievalName(fileName);                       
                doc.set_MimeType(getMimetype(fileName));
            }

			// Set document properties.
			doc.getProperties().putValue("DocumentTitle", "New Document via Java API");
			doc.set_MimeType("text/plain");

			StorageArea sa = Factory.StorageArea.getInstance(os, new Id("{DE42374D-B04B-4F47-A62E-CAC9AC9A5719}") );
			doc.set_StorageArea(sa);

			doc.save(RefreshMode.NO_REFRESH );

			// Check in the document.
			doc.checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);
			doc.save(RefreshMode.NO_REFRESH);

			// File the document.
			Folder folder = Factory.Folder.getInstance(os, ClassNames.FOLDER,
			        new Id("{42A3FC29-D635-4C37-8C86-84BAC73FFA3F}") );
			ReferentialContainmentRelationship rcr = folder.file(doc,
			        AutoUniqueName.AUTO_UNIQUE, "New Document via Java API",
			        DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
			rcr.save(RefreshMode.NO_REFRESH);
			
			
		}else{
			
			log.error("Cannot Process,error fetching objectStore : "+appProps.getProperty(Constants.MSG_OBJECTSTORE_NAME));
		}

		
			log.debug("End Processing......");
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			failedCtr++;
			log.error("Doc Delete failed : " + docId + " Error " + e.getMessage());
			failedDeleteLst.add(docId+"~"+e.getMessage());
			e.printStackTrace();
		}
	}

	public static boolean isFilenameValid(String fileName) {

		File f = new File(fileName);
		return f.isFile();
	}

	public static String read(String prompt) {
		String value = null;
		byte[] bytes = new byte[100];

		try {
			System.out.println(prompt);
			int readed;
			readed = System.in.read(bytes);
			while (readed <= 0) {
				System.out.println(prompt);
				readed = System.in.read(bytes);
			}
			value = new String(bytes, 0, readed).trim();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return value;
	}

}
