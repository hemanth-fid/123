package org.ifc.idocs.migration.importUtility;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.logging.Level;

import org.ifc.idocs.migration.helper.UpdateDB;
import org.ifc.idocs.migration.helper.Utilities;
import org.ifc.idocs.migration.rollback.RollbackUtility;
import org.ifc.idocs.migration.wfAudits.ImportWFAudits;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;
import com.documentum.operations.impl.common.query.IdCollector;
/**
 * ImportExecution - Processing legacy document IDS to initialize the import process and initialize work flow audits upload process. 
 * @author HAnuganti
 * 
 * #############################################################################################
 * Author		            DateofChange	 Version	  ModificationHistory
 * ###########################################################################################
 * Hemachandra Anuganti 
 * ###########################################################################################
 * 
 */
public class ImportExecution extends ImportUtility {

	/*
	 * Import Utility Functions Starts here
	 */
	public static void run(IDfSession dfSession, int choice) {
		try {
			
			//Populate Fldlevel hashmap
			Utilities.addToFldLevelHM();
			
			//Populate Doc Titles to Hashmap
			Utilities.addToDocTitlesHM();
			
			StringTokenizer sTokens = new StringTokenizer(config.getString("filters.extractionutilityID"), ",");
			String extId = "";
			
			// For each Extraction Utility Id
			while (sTokens.hasMoreTokens()) {
				//Fill Template Title and Template Codes to Hashmap
				Utilities.mapTemplateTitles();
				
				//Initializing successful docs imported count for every extraction ID(Only root versions)
				uploadedDocCnt = 0;
//				documentCount = 0;
				//Initializing Totle number of XML/Documents count(Only root versions)
				totalDocsCount=0;
				existingDocsCnt=0;
				// Creation of Import Utility Id
				/*String docBaseIdentity = config.getString("filters.extractionutilityID");
				if(docBaseIdentity.equalsIgnoreCase("DEV")){
					docBaseIdentity = "D";
				}else if(docBaseIdentity.equals("TEST")){
					docBaseIdentity = "T";
				}else if(docBaseIdentity.equals("STAGE")){
					docBaseIdentity = "S";
				}else if(docBaseIdentity.equals("PROD")){
					docBaseIdentity = "P";
				}*/
				Date dt = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("MMddyy_HHmmss");
				impUniqId = idocsProperties.getProperty("MSG_UTILITY_IDENTITY")+ sdf.format(dt).toString().trim();
				
				// extraction utility id
				extId = sTokens.nextToken();
				extractionID = extId;

				// Insert Import Utility Details to Import Utility Info Table with details
				String strQuery = idocsProperties.getProperty("MSG_DB_UTILITYID_INSERT");
				strQuery = strQuery.replaceFirst("<import_utility_code>",impUniqId)
										.replaceFirst("<extraction_utility_code>",extId)
											.replaceFirst("'<import_start_date>'", "SYSDATE")
												.replaceFirst("'<import_status_nme>'", "'WIP'")
													.replaceFirst("'<discussion_import_st_nme>'", "'WIP'")
														.replaceFirst("'<wf_audit_import_st_nme>'", "'WIP'");
				importDocLogger.info(strQuery);
				
				// Insert Query using DB Utility with the start time stamp for the current extraction
				UpdateDB.updateDatabase(strQuery.toString());
				
				//Insert into Import Summary Table
				String importSummaryQry = idocsProperties.getProperty("MSG_DB_IMPORT_SUMMERY_INSERT");
				importSummaryQry = importSummaryQry.replaceFirst("<IMPORT_UTILITY_CODE>", impUniqId)
									.replaceFirst("<EXTRACTION_UTILITY_CODE>", extractionID);
				
				UpdateDB.updateDatabase(importSummaryQry.toString());
				
				// Get details of Location and Region
				String queryString2 = idocsProperties.getProperty("MSG_DB_UTILITYID_SELECT_EXECUTION")
										.replaceFirst("<extraction_utility_code>", extId);
				ResultSet extrInfo = UpdateDB.selectFrmDatabse(queryString2.toString());
				if (extrInfo.next()) {
					region = extrInfo.getString("region_nme");
					location = extrInfo.getString("extract_location_txt");
					importDocLogger.warning("Region Name::" +region+"::Location::"+location+"::Extraction ID::"+extId);
					// Find resultset from region table
					String queryString1 = idocsProperties.getProperty("MSG_DB_GETREGION_INFO_EXECUTION");
					queryString1 = queryString1.replaceFirst("<region_name>", region)
									.replaceFirst("<extraction_utility_code>", extId);
					if(choice == 2){
						importDocLogger.warning("Rollback Started for the Extraction ID:"+extId+" Import Utility ID::"+impUniqId);
						int rlbkSuccessCnt = 0;
						int rlbkFailCnt = 0;
						ResultSet getMigInf = UpdateDB.selectFrmDatabse(queryString1.toString());
						while(getMigInf.next()){
							String domDocLegID = getMigInf.getString("legacy_document_id");
							if(RollbackUtility.performRollback(domDocLegID, "M")){
								rlbkSuccessCnt++;
								importDocLogger.warning("Rolled Back::["+domDocLegID+"]::Document Count::"+rlbkSuccessCnt);
								//Update Region database with rollback successful status
								String qryStrUpdateDB = idocsProperties.getProperty("MSG_UPDATE_DELTA_STATUS_REGN_TBL")
														.replaceFirst("<region>", region)
															.replaceFirst("<extraction_utility_code>", extId)
																.replaceFirst("<orig_doc_id>", domDocLegID);
								
								//Updating migration database with rollback successful for the cleaned up document 
								Utilities.addToArrayList(qryStrUpdateDB);
							}else{
								rlbkFailCnt++;
								importDocLogger.warning("Rolled Back failed::["+domDocLegID+"]:: Document Count::"+rlbkFailCnt);
								//Update Region database with rollback successful status
								String qryStrUpdateDB = idocsProperties.getProperty("MSG_UPDATE_DELTA_STATUS_REGN_TBL_RLBK")
														.replaceFirst("<region>", region)
															.replaceFirst("<extraction_utility_code>", extId)
																.replaceFirst("<orig_doc_id>", domDocLegID);
								
								//Updating migration database with rollback successful for the cleaned up document 
								Utilities.addToArrayList(qryStrUpdateDB);
								
								importDocLogger.warning("Rollabck Failed for the legacy document id::"+domDocLegID);											
								
								String skippedReason = "Rollabck Failed for the legacy document id::"+domDocLegID;
								skippedReason = skippedReason.replaceAll("'", "''");
								skippedReason = skippedReason+"')";
								
								//Adding to Skipped Reason Database on Import Failure
								Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_32"),skippedReason);
								
							}						
						}if(getMigInf!=null){
							getMigInf.close();
						}
						importDocLogger.info("Rollback Successfull for the Extraction ID:"+extId+" Import Utility ID::"+impUniqId);
						importDocLogger.info("Total Number of documents Rolled Back for the current Utility run::"+rlbkSuccessCnt);
						importDocLogger.info("Total Number of documents Failed Roll Back for the current Utility run::"+rlbkFailCnt);
						}else{
							HashMap migrtatedDocKeys = new HashMap();
							String qryMigDocList = idocsProperties.getProperty("MSG_DB_GETREGION_INFO_LEGACYIDS")
								   						.replaceFirst("<region_name>", region);
							ResultSet migratedDocsList = UpdateDB.selectFrmDatabse(qryMigDocList.toString());
							while(migratedDocsList.next()){
								String legacyDocumentID = migratedDocsList.getString("legacy_document_id");
								migrtatedDocKeys.put(legacyDocumentID, null);
							}if(migratedDocsList!=null){
								migratedDocsList.close();
							}
							ResultSet getMigrationInf = UpdateDB.selectFrmDatabse(queryString1.toString());
							
							while(getMigrationInf.next()){
								queryString5 = "";
								skipped_fldValue_code = "";
								skipped_fldType_code = "";
								fld_type_code = "";
								fld_value_code = "";
								legacyDocId = "";
								
								legacyDocId = getMigrationInf.getString("legacy_document_id");
//								importDocLogger.warning("Processing Import for the legacy document id::"+legacyDocId);
								fld_type_code = getMigrationInf.getString("folder_type_code");
								fld_value_code = getMigrationInf.getString("folder_value_code");
								skipped_fldType_code = fld_type_code;
								skipped_fldValue_code = fld_value_code;
								
								if((skipped_fldType_code != null || skipped_fldType_code!="") 
										&& (skipped_fldValue_code != null || skipped_fldValue_code!="")){
								
								//Prepare rollback required query to execute if the import is failed
								queryString5 = idocsProperties.getProperty("MSG_UPDATE_REGION_INFO_RLBK");
								queryString5 = queryString5.replaceAll("<region_name>", region);
								queryString5 = queryString5.replaceAll("<legacy_document_id>", legacyDocId);
								queryString5 = queryString5.replaceAll("<extraction_utility_code>", extractionID);
								
								//Checking whether document is already uploaded in idocs or not
								if(!migrtatedDocKeys.containsKey(legacyDocId)){
									
									//Getting total XMLs count to be parsed
									totalDocsCount++;
									
									//Prepare Query to update the region table
									String queryString3 = idocsProperties.getProperty("MSG_DB_UPDATE_REGION_TBL")
															.replaceFirst("<region_name>", region)
																.replaceFirst("<import_util_code>", impUniqId)
																	.replaceFirst("<extraction_utility_code>", extId)
																		.replaceFirst("<legacy_document_id>", legacyDocId);
																		
									Utilities.addToArrayList(queryString3.toString());
									
									//Block of code runs for Interrupted Import Utility
									if(choice == 12){
										//Check if the document is already uploaded in idocs(If utility is interrupted)
										if(chkAlreadyUploaded(dfSession,legacyDocId)){
											importDocLogger.warning("Cleaning up process started for the legacy document id::"+legacyDocId);
//											System.out.println("Document cleaned up checking the duplicate checks::"+legacyDocId);
											//If uploaded delete the document including versions/ Doc Audits/ Workflow Audits
											if(RollbackUtility.performRollback(legacyDocId, "M")){
												importDocLogger.warning("Cleaning successful for the legacy document id::"+legacyDocId);
											}else{
												importDocLogger.warning("Cleaning failed for the legacy document id::"+legacyDocId);
											}
										}else{
											importDocLogger.warning("Duplicate document doesnot exist in IFCDocs::"+legacyDocId);
										}
									}
									importDocLogger.warning("Processing Import for the legacy document id::["+legacyDocId+"]");
									//Parsing the XML for the relavent legacy ID and Upload the documents
									ParseXML.getXML(legacyDocId, fld_type_code, fld_value_code, location, extId, impUniqId);
								}else{
									//Getting total XMLs count to be parsed
									totalDocsCount++;
									existingDocsCnt++;
									//Prepare Query to update the region table
									String queryString3 = idocsProperties.getProperty("MSG_DB_UPDATE_REGION_TBL")
															.replaceFirst("<region_name>", region)
																.replaceFirst("<import_util_code>", impUniqId)
																	.replaceFirst("<extraction_utility_code>", extId)
																		.replaceFirst("<legacy_document_id>", legacyDocId);
																		
									Utilities.addToArrayList(queryString3.toString());
									
									importDocLogger.info("A document with the same Domino/Legecy document id is existing in iDocs system::["+legacyDocId+"]");
									
									//Make Entry in Migration Skipped documents table as folder is not found
									importDocLogger.warning("Duplicate document found in the documentum system for the legacy document id::["+legacyDocId+"]");											
									
									String skippedReason = "Duplicate document found in the documentum system for the legacy document id::["+legacyDocId+"]";
									skippedReason = skippedReason.replaceAll("'", "''");
									skippedReason = skippedReason+"')";
									
									//Adding to Skipped Reason Database on Import Failure
									Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_30"),skippedReason);
								}
							}else{
								//Folder type code and value code not found
								//Add document to skipped reason documents
								
								importDocLogger.info("Folder Type Code and Folder value code not found for the legacy document ID::["+legacyDocId+"]");
								
								//Make Entry in Migration Skipped documents table as folder is not found
								
								String skippedReason = "Folder Type Code["+skipped_fldType_code+"] and Folder Value Code["+skipped_fldValue_code+"does not fould for the legacy document id::"+legacyDocId;
								skippedReason = skippedReason.replaceAll("'", "''");
								skippedReason = skippedReason+"')";
								
								//Adding to Skipped Reason Database on Failure
								Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_39"),skippedReason);
							}
							}
							if(getMigrationInf!=null){
							getMigrationInf.close();
							}
							
//							importDocLogger.info("Total Number of documents uploaded For this import run::"+uploadedDocCnt);
						}
						/*************************/

					//Update migration databases
					if(dbqryList.size()>=1){
						importDocLogger.warning("Updating Migration Region Databases.........!!!!!");
						UpdateDB.executeBatch(dbqryList,UpdateDB.getBatchConnection());
						importDocLogger.warning("Migration Region Databases Updated Successfully.........!!!!!");
						dbqryList.clear();
					}
					//Call Workflow Audit trail Import functionality based on ececution choice
					/*if(choice != 2){
						ImportWFAudits.importWorkflowAuditTrails(dfSession,extractionID);
						//Update migration databases WITH WORKFLOW UPDATES
						if(dbqryWFList.size()>=1){
						UpdateDB.executeBatch(dbqryWFList,UpdateDB.getBatchConnection());
						dbqryWFList.clear();
						}
					}*/
						}if(extrInfo!=null){
							extrInfo.close();
						}
				StringBuffer strQuery1 = new StringBuffer(idocsProperties.getProperty("MSG_UPDATE_IMP_UTIL_INFO_ONE"));
				strQuery1.append(uploadedDocCnt).append(idocsProperties.getProperty("MSG_UPDATE_IMP_UTIL_INFO_TWO"));
				String strQueryDB = strQuery1.toString()
										.replaceFirst("<import_utility_code>", impUniqId)
											.replaceFirst("<extraction_utility_code>", extractionID);
				
				//Update Migration DB with end time stamp for the current extracted/import run
				UpdateDB.updateDatabase(strQueryDB.toString());
				
				//Run Cleanup for the failed documents for the current run
				importDocLogger.warning("Starting cleaning up docbase for the current import utility failed documents....!!["+region+"]::["+extractionID+"]::["+impUniqId+"]");
				RollbackUtility.cleanUPImportFailures(extractionID,region);
				importDocLogger.warning("Cleaned up docbase for the current import utility failed documents....!!["+region+"]::["+extractionID+"]::["+impUniqId+"]");
				
				//Total Import Summary for the current Import Utility ID run
				
				if(choice==1 || choice==3 || choice==12){
					dbqryList.clear();
					importDocLogger.info("Total Number of documents Quelified for the Current Utility Run::"+totalDocsCount);
					importDocLogger.info("Total Number of Duplicate Documents found in IFCDocs for the Current Utility Run::"+existingDocsCnt);
					importDocLogger.info("Total Number of Documents Uploaded for current Utility Run::"+uploadedDocCnt);
					importDocLogger.info("Total Number of Documents Upload Failed in Current Utility Run::"+(totalDocsCount-(uploadedDocCnt+existingDocsCnt)));
					importDocLogger.info("Total Number of Documents Skipped in Current Utility Run::"+(existingDocsCnt+(totalDocsCount-(uploadedDocCnt+existingDocsCnt))));
					importDocLogger.info("Import Utility Code for the current run::["+impUniqId+"]");
					
					//Update Migration Summary Table
					String importSummaryUpdateQry = idocsProperties.getProperty("MSG_DB_IMPORT_SUMMERY_UPDATE")
														.replaceFirst("<TOTAL_PROCESSED_CNT>", totalDocsCount+"")
														.replaceFirst("<TOTAL_IMPORTED_DOC_CNT>", uploadedDocCnt+"")
														.replaceFirst("<TOTAL_IMPORT_FAILED_DOC_CNT>", (totalDocsCount-(uploadedDocCnt+existingDocsCnt))+"")
														.replaceFirst("<DUPLICATE_IMPORT_DOC_CNT>", existingDocsCnt+"")
														.replaceFirst("<TOTAL_IMPORT_SKIPPED_CNT>", (existingDocsCnt+(totalDocsCount-(uploadedDocCnt+existingDocsCnt)))+"")
														.replaceFirst("<IMPORT_UTILITY_CODE>", impUniqId)
														.replaceFirst("<EXTRACTION_UTILITY_CODE>", extractionID);
																		
					UpdateDB.updateDatabase(importSummaryUpdateQry.toString());
				}
			}
			
		}/* catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException::"+e.getMessage());
			e.printStackTrace();
		}*/ catch (SQLException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("SQLException::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"SQLException during processing legacyid :: "+legacyDocId, e);
			e.printStackTrace();
		} /*catch (IOException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("IOException::"+e.getMessage());
			e.printStackTrace();
		}*/ catch (Exception e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("Exception::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"Exception during processing legacyid :: "+legacyDocId, e);
			e.printStackTrace();
		}
	}

	private static boolean chkAlreadyUploaded(IDfSession dfSession,
			String legacyDocId) {
		// TODO Auto-generated method stub
		int valCount = 0;
		boolean chkFlag = false;
		importDocLogger.warning("Checking for duplicate document in IFCDocs::"+legacyDocId);
		String queryStr = idocsProperties.getProperty("MSG_CHK_UPLOADED_QRY");
		queryStr = queryStr.replaceAll("<orig_doc_id>", legacyDocId);
		try {
			IDfCollection collection = Utilities.executeQuery(dfSession, queryStr, DfQuery.EXECREAD_QUERY);
			if(collection != null && collection.next()){
				valCount = collection.getValueCount("r_object_id");
				//System.out.println("count of the object ids:::::"+valCount);
			}
			collection.close();
				
			//importDocLogger.info("count of the existing objects::"+valCount);
			if(valCount>=1){
				chkFlag = true;
			}else{
				
			}
			if(chkFlag){
				importDocLogger.warning("Document existing in IFCDocs::"+legacyDocId);
			}
			return chkFlag;
		} catch (DfException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return chkFlag;
		}
		
	}

	/*
	 * private static void updateImportUtilityTbl(String queryStr) { // TODO
	 * Auto-generated method stub IDfCollection collection1 = null; IDfQuery
	 * query = new DfQuery(); query.setDQL(queryStr.toString()); try {
	 * collection1 = query.execute(dfSession, DfQuery.EXECREAD_QUERY); } catch
	 * (DfException e) { // TODO Auto-generated catch block e.printStackTrace();
	 * }finally{ if(collection1 != null){ try { collection1 = null;
	 * collection1.close(); } catch (DfException e) { // TODO Auto-generated
	 * catch block e.printStackTrace(); } } } }
	 */

}
