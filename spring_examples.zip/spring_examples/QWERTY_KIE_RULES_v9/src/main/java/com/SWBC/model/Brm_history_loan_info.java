package com.SWBC.model;

public class Brm_history_loan_info {

	private String IH_ACCOUNT_NO;
	private String IH_LOAN_NO;
	private String IH_LOAN_SUFFIX;
	private String IH_COVERAGE_TYPE;
	private String IH_DOCUMENT_NO;
	private String IH_DOCUMENT_ISSUE_DATE;
	private String IH_TRAN_DATE;
	public String getIH_ACCOUNT_NO() {
		return IH_ACCOUNT_NO;
	}
	public void setIH_ACCOUNT_NO(String iH_ACCOUNT_NO) {
		IH_ACCOUNT_NO = iH_ACCOUNT_NO;
	}
	public String getIH_LOAN_NO() {
		return IH_LOAN_NO;
	}
	public void setIH_LOAN_NO(String iH_LOAN_NO) {
		IH_LOAN_NO = iH_LOAN_NO;
	}
	public String getIH_LOAN_SUFFIX() {
		return IH_LOAN_SUFFIX;
	}
	public void setIH_LOAN_SUFFIX(String iH_LOAN_SUFFIX) {
		IH_LOAN_SUFFIX = iH_LOAN_SUFFIX;
	}
	public String getIH_COVERAGE_TYPE() {
		return IH_COVERAGE_TYPE;
	}
	public void setIH_COVERAGE_TYPE(String iH_COVERAGE_TYPE) {
		IH_COVERAGE_TYPE = iH_COVERAGE_TYPE;
	}
	public String getIH_DOCUMENT_NO() {
		return IH_DOCUMENT_NO;
	}
	public void setIH_DOCUMENT_NO(String iH_DOCUMENT_NO) {
		IH_DOCUMENT_NO = iH_DOCUMENT_NO;
	}
	public String getIH_DOCUMENT_ISSUE_DATE() {
		return IH_DOCUMENT_ISSUE_DATE;
	}
	public void setIH_DOCUMENT_ISSUE_DATE(String iH_DOCUMENT_ISSUE_DATE) {
		IH_DOCUMENT_ISSUE_DATE = iH_DOCUMENT_ISSUE_DATE;
	}
	public String getIH_TRAN_DATE() {
		return IH_TRAN_DATE;
	}
	public void setIH_TRAN_DATE(String iH_TRAN_DATE) {
		IH_TRAN_DATE = iH_TRAN_DATE;
	}
	
}
