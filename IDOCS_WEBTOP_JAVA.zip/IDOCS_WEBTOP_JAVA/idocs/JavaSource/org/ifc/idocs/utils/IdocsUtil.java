/**
* This class is for displaying iDocsUtil component provides utilities used for topic page view class.
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.servlet.ServletRequest;
import javax.servlet.jsp.PageContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.exception.IDocsException;
import org.ifc.idocs.library.actions.LaunchViewComponentWithPermitCheck;
import org.ifc.idocs.queryservices.DocTypeTableStructure;
import org.ifc.idocs.queryservices.IDocsQRYVO;
import org.owasp.esapi.ESAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfUser;
import com.documentum.fc.client.IDfWorkflow;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.DfTime;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.fc.common.IDfTime;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.LocaleService;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.drl.DRLComponent;

public class IdocsUtil{
	
	private static final String QRY_LDAP_GROUP_MEMBER = "QRY_LDAP_GROUP_MEMBER";
	private static final String QRY_PROJ_MEMBER = "QRY_PROJ_MEMBER";
	private static final String QRY_DM_USER_MEMBER = "QRY_DM_USER_MEMBER";
	private static final String LOGINUSERNAME = "%loginusername%";
	private static final String PROJECTID2 = "%projectid%";
	private static final String PROJECT_TEAM_MEMBERS_QRY = "PROJECT_TEAM_MEMBERS_QRY";
	private static final String QRY_GET_USER_LOGIN_ID = "QRY_GET_USER_LOGIN_ID";
	private static final String QRY_GET_LDAP_GROUP = "QRY_GET_LDAP_GROUP";
	private static final String QRY_GET_LDAP_GROUP_ALL_ROLES = "QRY_GET_LDAP_GROUP_ALL_ROLES";
	private static final String QRY_GET_USER_FROM_PROJ_LDAP_GROUP = "QRY_GET_USER_FROM_PROJ_LDAP_GROUP";
	private static final String QRY_TEAM_MEMBERS_ALL = "QRY_TEAM_MEMBERS_ALL";
	private static final String QRY_GET_WORKFLOW_ID = "QRY_GET_WORKFLOW_ID";
	private static final String QRY_CLIE_INSTI_PROJECTS = "QRY_CLIE_INSTI_PROJECTS";
	private static final String QRY_GET_GROUP_MEMBERSHIP = "QRY_GET_GROUP_MEMBERSHIP";
	private static final String QRY_AUDIT_IDOCS_ACTIVITIES = "QRY_AUDIT_IDOCS_ACTIVITIES";
	private static final String PROJECT_ID = "project_id";
	private static final String MSG_SPECIAL_NONWORKFLOW_TEMPLATES = "MSG_SPECIAL_NONWORKFLOW_TEMPLATES";
	private static final String MSG_PRODUCT_TEMPLATES = "MSG_PRODUCT_TEMPLATES";
	private static final String QRY_DM_GROUP_MEMBER = "QRY_DM_GROUP_MEMBER";
	private static final String QRY_CONFLICT_OF_INTEREST = "QRY_CONFLICT_OF_INTEREST";
	private static final String QRY_GET_SEC_CRED = "QRY_GET_SEC_CRED";
	private static final String QRY_GET_CSO_FROM_PROJECT = "QRY_GET_CSO_FROM_PROJECT";
	private static final String COMMA = ",";
	private static final String MSG_NON_CSO_VALUES = "MSG_NON_CSO_VALUES";
	private static final String QRY_GET_TEMPLATE_TITLE = "QRY_GET_TEMPLATE_TITLE";
	private static final String GET_PROJECT_TIER = "GET_PROJECT_TIER";
	private static final String GET_PARTNER_TIER = "GET_PARTNER_TIER";
	private static final String PRODUCT_DRL_UPDATE_SERVLET_URL = "PRODUCT_DRL_UPDATE_SERVLET_URL";
	private static final String ASOP_UPDATE_SERVLET_URL2 = "ASOP_UPDATE_SERVLET_URL";
	private static final String AS_TEMP_INTG_URL = "AS_TEMP_INTG_URL";
	private static final String ASOP_UPDATE_SERVLET_URL = ASOP_UPDATE_SERVLET_URL2;
	private static final String WORK_ENV = "WORK_ENV";
	private static final String EMPTY_STRING = "";
	private static final String MSG_IFCDOCS_AUTHOR_NAMES = "MSG_IFCDOCS_AUTHOR_NAMES";
	private static final String MSG_AUTHOR_NAME = "MSG_AUTHOR_NAME";
	private static final String MSG_DOC_CATEGORY = "MSG_DOC_CATEGORY";
	private static final String MSG_REGION_CODE = "MSG_REGION_CODE";
	private static final String MSG_REGION_NME = "MSG_REGION_NME";
	private static final String MSG_CREATED_DATE = "MSG_CREATED_DATE";
	private static final String MSG_COUNTRY_CODE = "MSG_COUNTRY_CODE";
	private static final String MSG_COUNTRY_NME = "MSG_COUNTRY_NME";
	private static final String MSG_DEPT_DIV_NME = "MSG_DEPT_DIV_NME";
	private static final String MSG_DEPT_DIV_CODE = "MSG_DEPT_DIV_CODE";
	private static final String MSG_INSTITUTION_SHORT_NME = "MSG_INSTITUTION_SHORT_NME";
	private static final String MSG_INSTIT_NBR = "MSG_INSTIT_NBR";
	private static final String MSG_PROJ_STATUS_CODE = "MSG_PROJ_STATUS_CODE";
	private static final String MSG_ENV_CATEGORY_CODE = "MSG_ENV_CATEGORY_CODE";
	private static final String MSG_ENV_CATEGORY_NME = "MSG_ENV_CATEGORY_NME";
	private static final String MSG_PROJ_TIER_NME = "MSG_PROJ_TIER_NME";
	private static final String MSG_PROJ_TIRE_CODE = "MSG_PROJ_TIRE_CODE";
	private static final String MSG_SECTOR_NME = "MSG_SECTOR_NME";
	private static final String MSG_SECTOR_CODE = "MSG_SECTOR_CODE";
	private static final String MSG_DEPT_NME = "MSG_DEPT_NME";
	private static final String MSG_DEPT_CODE = "MSG_DEPT_CODE";
	private static final String MSG_PROJ_SUBCATEGORY_NAME = "MSG_PROJ_SUBCATEGORY_NAME";
	private static final String MSG_PROJ_CATEGORY_CODE = "MSG_PROJ_CATEGORY_CODE";
	private static final String MSG_PROJ_CATEGORY_NAME = "MSG_PROJ_CATEGORY_NAME";
	private static final String MSG_PROJ_NAME = "MSG_PROJ_NAME";
	private static final String MSG_PROJ_SHORT_NAME = "MSG_PROJ_SHORT_NAME";
	private static final String MSG_APPROVAL_PROC_CODE = "MSG_APPROVAL_PROC_CODE";
	private static final String MSG_APPROVAL_NAME = "MSG_APPROVAL_NAME";
	private static final String MSG_PROJ_SUBCATEGORY_CODE = "MSG_PROJ_SUBCATEGORY_CODE";
	private static final String MSG_SUBJECT = "MSG_SUBJECT";
	private static final String MSG_PROJ_STAGE_CODE = "MSG_PROJ_STAGE_CODE";
	private static final String MSG_PROJ_STAGE_NAME = "MSG_PROJ_STAGE_NAME";
	private static final String MSG_PROJECT_ID = "MSG_PROJECT_ID";
	private static final String SINGLE_QUOTES = "'";
	private static final String PROCESS_QRY = "PROCESS_QRY";
	private static final String DOUBLE_QUOTES = "''";
	private static final String QRY_GET_IDOCS_CONFIG_INFO = "QRY_GET_IDOCS_CONFIG_INFO";
	private static final String STR_PREFIX_SUB = "Sub ";
	private static final String STR_PREF_AS = "AS ";
	private static final char CHAR_DOUBLE_QUOTES = '"';
	private static final char CHAR_DOT = '.';
	private static final char CHAR_COLON = ':';
	private static final char CHAR_FORWARD_SLASH = '/';
	private static final char CHAR_QUESTION_MARK = '?';
	private static final char CHAR_GREATERTHAN = '>';
	private static final char CHAR_LESSTHAN = '<';
	private static final String PROJECT_TIER_CODE = "project_tier_code";
	private static final String INSTITUTION_TIER_CODE = "institution_tier_code";
	private static final String QRY_VARIABLE_FOLDERTITLE = "<foldertitle>";
	private static final String QRY_VARIABLE_DOCSUBTYPENAME = "<docsubtypename>";
	private static final String QRY_VARIABLE_PROJECTID = "<projectid>";
	private static final String QRY_VARIABLE_ROLESTRING = "<rolestring>";
	private static final String QRY_VARIABLE_LOGINUSERNAME = "<loginusername>";
	private static final CharSequence QRY_VARIABLE_GROUPNAME = "<group_name>";
	private static final String MSG_I_ALL_USERS_NAMES = "i_all_users_names";
	private static final String MSG_ACCESSOR_NME= "accessor_nme";
	private static final String QRY_VARIABLE_QRYSAFELDAPGROUP = "<qrysafeldapgroup>";
	private static final String AUDIT_OBJECT_ID = "<dctmObjectID>";
	private static final String AUDIT_TIME_STAMP = "<timestamp>";
	private static final String AUDIT_ACTION = "<action>";
	private static final String AUDIT_ACTOR = "<actor>";
	private static final String QRY_VARIABLE_OBJECTID = "<objectid>";
	private static final String QRY_VARIABLE_WF_NBR = "<productwfnbr>";
	public static final String MSG_TASK_ATTACHMENT_COMPONENT_ID = "taskattachment";
	
	private static final char CHAR_PLUS = '+';
	private static final char CHAR_PERCENTAGE = '%';
	private static final char CHAR_HASH = '#';
	private static final char CHAR_AMP = '&';
	private static final char CHAR_DOLLAR = '$';
	private static final char CHAR_PIPE = '|';
	private static final char CHAR_BACKWARD_SLASH = '\\';
	private static final char  CHAR_STAR = '*';
	private static String envSuffix = null;
	
	protected static Properties idocsProperties = new Properties();
	private String strFolderId = null;
	
	public IdocsUtil() {
		try {
        	idocsProperties.load(IdocsUtil.class.getResourceAsStream(IdocsConstants.IDOCS_PROPERTY_FILE));	        	       	
        }catch (Exception e) {
        	DfLogger.info(this," :: IdocsUtil : Exception : " + e.getMessage(),null,null);
		}
	}
	
	public String getFolderId() {
		return strFolderId;
	}
	
	/**
	 * 
	 * @param strFolderId
	 */
	public void setFolderId(String strFolderId) {
		this.strFolderId = strFolderId;
		DfLogger.info(this," :: setFolderId : strFolderId : " + strFolderId,null,null);
	}
	
	/**
	 * 
	 * @param pdtWfTypeCode
	 * @param strTemplateName
	 * @return
	 */
	public static boolean ifProductIntegrationRequired(String strTemplateName) {
		String strProductTypeTemplates = IdocsUtil.getMessage("MSG_PDT_INTEGRATION_TEMPLATES");
		if(strProductTypeTemplates != null && strProductTypeTemplates.trim().length() > 0){
			if(IdocsUtil.checkIfTokenPresent(strProductTypeTemplates, strTemplateName, IdocsConstants.MSG_COMMA)){
			 return true;
			}else{
				return false;
			}
		}else{
			return false;
		}			
	}

	/**
	 * 
	 * @param pdtWfTypeCode
	 * @param strTemplateName
	 * @return
	 */
	public static boolean isThisAChildWorkflow(String strTemplateName) {
		String strProductTypeTemplates = IdocsUtil.getMessage("MSG_PDT_INTEGRATION_CHILDWORKFLOW_TEMPLATES");
		if(strProductTypeTemplates != null && strProductTypeTemplates.trim().length() > 0){
			if(IdocsUtil.checkIfTokenPresent(strProductTypeTemplates, strTemplateName, IdocsConstants.MSG_COMMA)){
			 return true;
			}else{
				return false;
			}
		}else{
			return false;
		}			
	}	
	
    /**
     * 
     */
    private static void updateACL(IDfSession sess, IDfSysObject doc, IDfFolder targetIdFolder) throws DfException {
    	doc.setACL(targetIdFolder.getACL());
	    DfLogger.info(IdocsUtil.class, " :: execute ACL Updated", null, null);
	}

	/**
     * 
     * @param sess
     * @param doc
     * @param targetIdFolder
     * @throws DfException
     */
	public static void updateAttribute(IDfSession sess, IDfSysObject doc, IDfFolder targetIdFolder,String operationName) throws DfException {
    	String objectType = doc.getTypeName();
    	String objectName = doc.getObjectName();
    	NlsResourceBundle m_nlsResourceBundle = new NlsResourceBundle("org.ifc.idocs.clipboard.ClipboardErrorsNlsProp");
	    DfLogger.info(IdocsUtil.class, " :: execute Attributes : Type : "+objectType+" : ObjectName : "+objectName, null, null);
    	if(objectType.equals(IdocsConstants.PROJ_DOC_TYPE))
    	{
    		objectName=objectName.replaceFirst(doc.getString(IdocsConstants.PROJ_ID),targetIdFolder.getString(IdocsConstants.PROJ_ID));
    	}
    	else if(objectType.equals(IdocsConstants.INSTITUTION_DOC_TYPE))
    	{
    		objectName=objectName.replaceFirst(doc.getString(IdocsConstants.MSG_INSTITUTION_NBR),targetIdFolder.getString(IdocsConstants.MSG_INSTITUTION_NBR));
    	}
    	else
    	{
    		objectName=objectName.replaceFirst(doc.getString(IdocsConstants.COUNTRY_CODE),targetIdFolder.getString(IdocsConstants.COUNTRY_CODE));
    	}
    	doc.setString(IdocsConstants.OBJECT_NAME, objectName);
    	updateACL(sess, doc, targetIdFolder);
    	if(IdocsConstants.DOC_STATE_RELEASED.equals(doc.getString(m_nlsResourceBundle.getString("MSG_DOC_STATE", LocaleService.getLocale()))) == false){
    		doc.setString(m_nlsResourceBundle.getString("MSG_DOC_STATE", LocaleService.getLocale()),IdocsConstants.DOC_STATE_DRAFT);
    		if(operationName!=null && operationName.equals(IDocsConstants.IDOCS_COPY_OPERATION) == true){
    			doc.mark("0.1,CURRENT");
    		}
    	}
        doc.setString(m_nlsResourceBundle.getString(MSG_COUNTRY_NME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_COUNTRY_NME, LocaleService.getLocale())));
        doc.setString(m_nlsResourceBundle.getString(MSG_COUNTRY_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_COUNTRY_CODE, LocaleService.getLocale())));
        doc.setString(m_nlsResourceBundle.getString(MSG_CREATED_DATE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_CREATED_DATE, LocaleService.getLocale())));
        doc.setString(m_nlsResourceBundle.getString(MSG_REGION_NME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_REGION_NME, LocaleService.getLocale())));
        doc.setString(m_nlsResourceBundle.getString(MSG_REGION_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_REGION_CODE, LocaleService.getLocale())));
        doc.setString(m_nlsResourceBundle.getString(MSG_DOC_CATEGORY, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_FOLDER_CATEGORY", LocaleService.getLocale()))); 
        doc.setString(m_nlsResourceBundle.getString(MSG_AUTHOR_NAME, LocaleService.getLocale()), sess.getLoginUserName());
        if(doc.hasAttr(m_nlsResourceBundle.getString(MSG_IFCDOCS_AUTHOR_NAMES,LocaleService.getLocale()))==true 
        		&& doc.findString(m_nlsResourceBundle.getString(MSG_IFCDOCS_AUTHOR_NAMES,LocaleService.getLocale()), sess.getLoginUserName())== -1){
        	//doc.appendString(m_nlsResourceBundle.getString("MSG_IFCDOCS_AUTHOR_NAMES",LocaleService.getLocale()), sess.getLoginUserName());
        	doc.setRepeatingString(m_nlsResourceBundle.getString(MSG_IFCDOCS_AUTHOR_NAMES,LocaleService.getLocale()), 0, sess.getLoginUserName());
        }
        //set Project Document Attributes
        if(objectType.equals(IdocsConstants.PROJ_DOC_TYPE)){
        	DfLogger.info(IdocsUtil.class, "NewDocument :: onCommitChanges() : for Project Document",null,null);
            doc.setAuthors(0, sess.getLoginUserName());
//            doc.setString(m_nlsResourceBundle.getString("MSG_FILED_BY", LocaleService.getLocale()), sess.getLoginUserName());
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJECT_ID, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_PROJECT_ID, LocaleService.getLocale())));
//            doc.setBoolean(m_nlsResourceBundle.getString("MSG_BIZ_TEMPLATE", LocaleService.getLocale()), true);
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_STAGE_NAME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_STAGE_NAME", LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_STAGE_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_STAGE_NBR", LocaleService.getLocale())));
//            doc.setString(m_nlsResourceBundle.getString("MSG_PUBLISH_STATE", LocaleService.getLocale()), m_nlsResourceBundle.getString("MSG_PUBLISHED", LocaleService.getLocale()));
            doc.setString(m_nlsResourceBundle.getString(MSG_SUBJECT, LocaleService.getLocale()), doc.getObjectName());
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_SUBCATEGORY_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_PROJ_SUB_CATEGORY_CODE", LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_APPROVAL_NAME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_APPROVAL_PROC_NME", LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_APPROVAL_PROC_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_APPROVAL_PROC_CODE, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_SHORT_NAME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_PROJ_SHORT_NAME, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_NAME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_PROJ_NAME, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_CATEGORY_NAME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_PROJ_CATEGORY_NAME, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_CATEGORY_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_PROJ_CATEGORY_CODE, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_SUBCATEGORY_NAME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_PROJ_SUBCATEGORY_NAME, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_DEPT_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_DEPT_CODE, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_DEPT_NME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_DEPT_NME, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_SECTOR_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_SECTOR_CODE, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_SECTOR_NME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_SECTOR_NME, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_TIRE_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_PROJECT_TIRE_CODE", LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_TIER_NME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_PROJECT_TIER_NME", LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_ENV_CATEGORY_NME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_ENV_CATEGORY_NME, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_ENV_CATEGORY_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_ENV_CATEGORY_CODE, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_STATUS_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_PROJ_STATUS_CODE, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_INSTIT_NBR, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_INSTIT_NBR, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_INSTITUTION_SHORT_NME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_INSTITUTION_SHORT_NME, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_DEPT_DIV_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_DEPT_DIV_CODE, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_DEPT_DIV_NME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_DEPT_DIV_NME, LocaleService.getLocale())));
        	
        }
        //set Institution Document Attributes
        else if(objectType.equals(IdocsConstants.INSTITUTION_DOC_TYPE)){
        	DfLogger.info(IdocsUtil.class, "NewDocument :: onCommitChanges() : for Institution Document",null,null);
            doc.setString(m_nlsResourceBundle.getString(MSG_INSTIT_NBR, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_INSTIT_NBR, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString("MSG_INSTIT_SHORT_NME", LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_INSTIT_SHORT_NME", LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString("MSG_INSTIT_LEGAL_NME", LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_INSTIT_LEGAL_NME", LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString("MSG_INSTIT_ROLE_TYPE_CODE", LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_INSTIT_ROLE_TYPE_CODE", LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString("MSG_INSTIT_ROLE_TYPE_NME", LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_INSTIT_ROLE_TYPE_NME", LocaleService.getLocale())));
        }
        //set Country Document Attributes
        else if(objectType.equals(IdocsConstants.COUNTRY_DOC_TYPE)){
        	DfLogger.info(IdocsUtil.class, "NewDocument :: onCommitChanges() : for Country Document",null,null);
            doc.setString(m_nlsResourceBundle.getString("MSG_COUNTRY_LONG_NME", LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_COUNTRY_LONG_NME", LocaleService.getLocale())));
        }else{
        	DfLogger.info(IdocsUtil.class, "NewDocument :: onCommitChanges() : Invalid object Type",null,null);
        }
        doc.setString(m_nlsResourceBundle.getString("MSG_SEC_CLASS", LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_SEC_CLASS", LocaleService.getLocale())));
        doc.save();
        DfLogger.info(IdocsUtil.class, " :: execute Attributes  Updated", null, null);
	}

	/**
	 * This method fetch the property value form the properties file corresponding to the key	 
	 * @param key
	 * @return String
	 */
	public static String getMessage(String key) {
		String message = null;
		try {
			message = idocsProperties.getProperty(key);		
			if(message !=null && message.trim().length() > 0){
				
			}else{
				idocsProperties.load(IdocsUtil.class.getResourceAsStream(IdocsConstants.IDOCS_PROPERTY_FILE));
				message = idocsProperties.getProperty(key);
			}
		} catch (Exception e) {
			try {
				idocsProperties.load(IdocsUtil.class.getResourceAsStream(IdocsConstants.IDOCS_PROPERTY_FILE));
				message = idocsProperties.getProperty(key);
			} catch (IOException e1) {
				DfLogger.error(IdocsUtil.class, " :: getMessage Exception >> "+ e.getMessage(), null, e);			
			}
		}
		//DfLogger.debug(IdocsUtil.class, " :: getMessage : message : " + message,null, null);
		return message;
	}
	
	/**
	 * This method fetch the email address of logged in user	 
	 * @param dfSession
	 * @return String
	 */
	public String getLoginUserAddress(IDfSession dfSession)
	{
		String login_userEmail = null;
		try
		{		
			String strUserName = dfSession.getLoginUserName();	
			IDfUser dfUser = dfSession.getUser(dfSession.getLoginUserName());
			String str_UserObjectId = dfUser.getObjectId().toString();
			DfLogger.info(this," :: getLoginUserAddress : str_UserObjectId : " + str_UserObjectId,null,null);
			if(null != str_UserObjectId && !EMPTY_STRING.equals(str_UserObjectId))
			{
				ArrayList<String> alst_user = new ArrayList<String>();
				alst_user.add(str_UserObjectId);
				ArrayList<String> alst_userAddress = getUserAddress(alst_user,dfSession);
				if(null != alst_userAddress && alst_userAddress.size()>0)
				{
					login_userEmail =  alst_userAddress.get(0);
				}
				login_userEmail = strUserName+"<"+login_userEmail+">";
			}
			DfLogger.info(this," :: getLoginUserAddress : login user Email ID : " + login_userEmail,null,null);
		}
		catch(DfException dfe)
		{
			DfLogger.error(this," :: getLoginUserAddress Exception >> "+dfe.getMessage(),null,dfe);
		}
		return login_userEmail;
	}
	
	/**
	 * This method fetch the email address of users.
	 * @param lst_userObjectID 
	 * @param dfSession
	 * @return ArrayList
	 */
	public ArrayList<String> getUserAddress(List<String> lst_userObjectID,IDfSession dfSession)
	{
		ArrayList<String> aList_userAddress = null;
		String str_dql= getMessage(IdocsConstants.USER_ADDRESS_QUERY);//"select user_address from dm_user where r_object_id in(";
		
		//Execute dql to fetch corresponding roles of the next manual activity of this workflow...
		StringBuilder dqlStr = new StringBuilder(str_dql);	
	
		if(null!=lst_userObjectID && lst_userObjectID.size()>0)
		{
			for(int lstIndex = 0; lstIndex < lst_userObjectID.size();lstIndex++) //iterating through list of userIds
			{
				String strObjectId = (String)lst_userObjectID.get(lstIndex);
				int capacity = strObjectId.length();
				capacity = capacity + 5;
				dqlStr.ensureCapacity(capacity);
				
				if(lstIndex == 0)
					dqlStr.append(SINGLE_QUOTES);
				else
					dqlStr.append(",'");
				
				dqlStr.append(lst_userObjectID.get(lstIndex)).append(SINGLE_QUOTES);	
			}
		}
		dqlStr.append(")");
		
		DfLogger.info(this," :: getUserAddress : dqlStr : "+dqlStr.toString(),null,null);
		
		// getting user_address
		try{
			IDfCollection collection = IdocsUtil.executeQuery(dfSession,dqlStr.toString(),IDfQuery.DF_READ_QUERY);
			aList_userAddress = new ArrayList<String> ();
			
			while(collection.next()){
				aList_userAddress.add((String)collection.getString(IdocsConstants.USER_EMAIL));
			}
			if (collection!=null)
				collection.close();
		}
		catch(DfException dfe)
		{
			DfLogger.error(this," :: getUserAddress : Exception >> "+dfe.getMessage(),null,dfe);
		}
		return aList_userAddress;
	}
	
	/**
	 * This method parses an XML file and returns the contents as a Collection object.
	 * @strFileName File Name 
	 * @strNodeName Node to be read
	 * @blnDataType boolean variable to decide whether ArrayList or HashMap is to be returned 
	 * @return Object Arraylist or HashMap
	 */
	public Object parseXML(String strNodeName, boolean blnDataType,InputStream inputStream) throws IDocsException {
		DfLogger.info(this," :: parseXML : Start parseXML() ",null,null);
		ArrayList objArrayList = new ArrayList();
		HashMap objHashMap = new HashMap();
		try {
			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(inputStream);
			doc.getDocumentElement().normalize();
			NodeList listOfCrit = doc.getElementsByTagName(strNodeName);
			int totalCrit = listOfCrit.getLength();
			ArrayList dump = null;
			String strKey = null;
			String strValue = null;
			for (int s = 0; s < listOfCrit.getLength(); s++) {
				NodeList listOfAttr = (NodeList) listOfCrit.item(s);
				for (int i = 0; i < listOfAttr.getLength(); i++) {
					Node attr = listOfAttr.item(i);
					if (attr.getNodeType() == Node.ELEMENT_NODE) {
						Element firstPersonElement = (Element) attr;
						NodeList firstNameList = firstPersonElement.getElementsByTagName("name");
						Element firstNameElement = (Element) firstNameList.item(0);
						NodeList textFNList = firstNameElement.getChildNodes();
						strKey = ((Node) textFNList.item(0)).getNodeValue().trim();
						NodeList lastNameList = firstPersonElement.getElementsByTagName("value");
						Element lastNameElement = (Element) lastNameList.item(0);
						NodeList textLNList = lastNameElement.getChildNodes();
						if ((Node) textLNList.item(0) != null) {
							strValue = ((Node) textLNList.item(0)).getNodeValue().trim();
						} else {
							strValue = EMPTY_STRING;
						}
						if (blnDataType) {
							dump = new ArrayList();
							dump.add(strKey);
							dump.add(strValue);
							objArrayList.add(dump);
						} else {
							objHashMap.put(strKey, strValue);
						}
					}
				}
			}
		} catch (Exception exception) {
			throw new IDocsException(112, exception);
		}
		DfLogger.info(this," :: parseXML : End parseXML() ",null,null);
		if (blnDataType) {
			return objArrayList;
		} else {
			return objHashMap;
		}
	}
	
	/**
	 * This method checks whether the folder in context is a project folder or not.
	 * @param dfsess 
	 * @param strFolderId 
	 * @return validProjFolderFlag
	 */
	public boolean isValidProjFolder(IDfSession dfsess, String strFolderId){
		boolean validProjFolderFlag = false;		
		IDfFolder parentFolder=null;

        try{
            IDfFolder docFolder = (IDfFolder)dfsess.getObject(new DfId(strFolderId));
            DfLogger.info(this," :: isValidProjFolder : Type of docFolder :"+ docFolder.getTypeName(),null,null);
            if(docFolder.getTypeName().equals(IdocsConstants.PROJ_FOLDER_TYPE)){
            	parentFolder = docFolder;
     	        setFolderId(parentFolder.getObjectId().toString());       	              
    	        validProjFolderFlag = true;
            }else if(docFolder.getTypeName().equals(IdocsConstants.SUB_FOLDER_TYPE)){
    	        IDfFolder docSubFolder = (IDfFolder)dfsess.getObject(docFolder.getFolderId(0));    	       
    	        if(docSubFolder.getTypeName().equals(IdocsConstants.PROJ_FOLDER_TYPE)){
    	        	parentFolder = docSubFolder;
        	        setFolderId(parentFolder.getObjectId().toString());    
    	        	validProjFolderFlag = true;
    	        }else{
    	        	parentFolder=(IDfFolder)dfsess.getObject(docSubFolder.getFolderId(0));
    	        	if(parentFolder.getTypeName().equals(IdocsConstants.PROJ_FOLDER_TYPE)){   
    	        		setFolderId(parentFolder.getObjectId().toString());    	
    	        		validProjFolderFlag = true;
    	        	}
    	        }
            }
        }catch(DfException dfe) {
        	DfLogger.error(this," :: isValidProjFolder Exception >> "+dfe.getMessage(),null,dfe);
        }
        DfLogger.info(this," :: isValidProjFolder : validProjFolderFlag :"+validProjFolderFlag,null,null);
		return validProjFolderFlag;
	}
	
	/**
	 * This method checks whether the folder in context is an institution folder or not.
	 * @param dfsess 
	 * @param strFolderId 
	 * @return validInstitFolderFlag
	 */
	public boolean isValidInstitFolder(IDfSession dfsess, String strFolderId){
		boolean validInstitFolderFlag = false;		
		IDfFolder parentFolder=null;
        	try{
				IDfFolder docFolder = (IDfFolder)dfsess.getObject(new DfId(strFolderId));
            	DfLogger.info(this," :: isValidInstitFolder : Type of docFolder :"+ docFolder.getTypeName(),null,null);

            	if(docFolder.getTypeName().equals(IdocsConstants.INSTITUTION_FOLDER_TYPE)){
            		parentFolder = docFolder;  
            		setFolderId(parentFolder.getObjectId().toString()); 
            		validInstitFolderFlag = true;
            	}else if(docFolder.getTypeName().equals(IdocsConstants.SUB_FOLDER_TYPE)){
    	        		IDfFolder docSubFolder = (IDfFolder)dfsess.getObject(docFolder.getFolderId(0));
    	        		if(docSubFolder.getTypeName().equals(IdocsConstants.INSTITUTION_FOLDER_TYPE)){
							parentFolder = docSubFolder;
							setFolderId(parentFolder.getObjectId().toString()); 
							validInstitFolderFlag = true;
    	        		}else{
    	        			parentFolder=(IDfFolder)dfsess.getObject(docSubFolder.getFolderId(0));
							if(parentFolder.getTypeName().equals(IdocsConstants.INSTITUTION_FOLDER_TYPE)){															
								setFolderId(parentFolder.getObjectId().toString()); 
								validInstitFolderFlag = true;
							}			
    	        		}
            	}
        	}catch(DfException dfe) {
        		DfLogger.error(this," :: isValidInstitFolder Exception >> "+dfe.getMessage(),null,dfe);
        	}
        DfLogger.info(this," :: isValidProjFolder : validInstitFolderFlag :"+validInstitFolderFlag,null,null);
		return validInstitFolderFlag;
	}
	
	/**
	 * This method gets the product type code for the document template.
	 * @param dfsess 
	 * @param strTemplateName 
	 * @return product_wf_code
	 */
	public int getProductTypeCode(IDfSession dfSession,String strTemplateName){
		int product_wf_code = 0;
		try{
			String productQry = getMessage(IdocsConstants.QRY_WORKFLOW_PRODUCT);
			productQry=productQry.replaceFirst(DOUBLE_QUOTES, SINGLE_QUOTES+strTemplateName+SINGLE_QUOTES);	        
		    DfQuery query = new DfQuery();
		    query.setDQL(productQry);
		    IDfCollection collection = query.execute(dfSession, 0);
		    if(collection.next()){
		        	product_wf_code = collection.getInt(IdocsConstants.MSG_PRODUCT_TYPE_CODE);
		            collection.close();
		    }
		    if(collection != null)collection.close();
        }catch(DfException dfe){
        	DfLogger.info(this," :: getProductTypeCode Exception >> "+dfe.getMessage(),null,null);
        }
        DfLogger.info(this," :: getProductTypeCode : product_wf_code : "+product_wf_code,null,null);
        return product_wf_code;
    }
	/*
	public static String [] getTemplateInfoDetails(String attributeNames[],String objectId,IDfSession dfSession) throws DfException{
		
		StringBuilder queryBuilder= new StringBuilder();
		queryBuilder.append("select ");
		
		if(attributeNames != null && attributeNames.length >0){
			String values[] = new String[attributeNames.length];
			for (int i = 0; i < attributeNames.length; i++) {
				String attrName=attributeNames[i];
				if(i == 0){
					queryBuilder.append("inf."+attrName);
				}else{
					queryBuilder.append(","+"inf."+attrName);
				}
			}
			String templateDInfoTable=IdocsUtil.getMessage("QRY_TEMPLATE_DETAILS");
			templateDInfoTable=templateDInfoTable.replace("<objectId>",objectId );
			queryBuilder.append(" "+templateDInfoTable);
			
			IDfCollection dfCollection=null;
			dfCollection=executeQuery(dfSession, queryBuilder.toString(), IDfQuery.DF_READ_QUERY);
			while(dfCollection.next()){
				for (int i = 0; i < attributeNames.length; i++) {
					values[i]=dfCollection.getString(attributeNames[i]);
				}
			}
			if(dfCollection !=  null)
				dfCollection.close();
			return values;
		}else return null;
		
		//return null;//QRY_TEMPLATE_DETAILS
	}*/
	
	/**
	 * This method gets the template code for the document template.
	 * @param dfsess 
	 * @param strTemplateName 
	 * @return template_wf_code
	 */	
	public int getTemplateCode(IDfSession dfSession,String strTemplateName){
		int template_code=0;
		try{
			DocTypeTableStructure docTypeTableStructure = new DocTypeTableStructure(IDocsQRYVO.getTemplateInfoTableData(dfSession));
			boolean exceptionOccured=false; 
			try {
				template_code=Integer.parseInt(docTypeTableStructure.getTemplateInfoTableValue("template_code","template_title",strTemplateName));
			} catch (NumberFormatException e) {
				DfLogger.error(this, " IdocsUtil :: NumberFormatException ::<<Exception block >>"+e.getMessage(), null, null);
				exceptionOccured=true;
			}
			if(template_code == 0 || exceptionOccured){
				String subtypeCodeQry = getMessage(IdocsConstants.QRY_TEMPLATE_CODE);
				DfLogger.info(this," :: getSubTypeCodeQuery Updated >> "+subtypeCodeQry,null,null);
				subtypeCodeQry=subtypeCodeQry.replaceFirst(DOUBLE_QUOTES, SINGLE_QUOTES+strTemplateName+SINGLE_QUOTES);
				DfQuery query = new DfQuery();
				query.setDQL(subtypeCodeQry);
				IDfCollection collection = query.execute(dfSession, 0);
				if(collection.next()){
					template_code = collection.getInt(IdocsConstants.TEMPLATE_CODE);
					DfLogger.info(this," :: subtype_code values >> "+template_code,null,null);
					collection.close();
				}
				if(collection != null)collection.close();
			}else{
				//don't care
			}
		}catch(DfException dfe){
			DfLogger.info(this," :: getSubType Exception >> "+dfe.getMessage(),null,null);
		}
		DfLogger.info(this," :: getSubtypeCode : subtype_code : "+template_code,null,null);
		return template_code;
	}	
	
	
	/**
	 * This method execute the query used for getting the trip data values.	
	 * @param   
	 */
	
	public static IDfCollection executeQuery(IDfSession dfSession, String strQuery, int queryType) throws DfException{
		DfLogger.debug(IdocsUtil.class," :: executeQuery :  Query : "+strQuery,null,null);
		IDfCollection dfCollection = null;
		IDfQuery dfQuery = new DfQuery();
		dfQuery.setDQL(strQuery);
		dfCollection = dfQuery.execute(dfSession,queryType);
		return dfCollection;
	} 
	
	/**
	 * This method execute the servlet.	
	 * @param servletURL  
	 */
	public static void buildAndExecuteServlet(String servletURL) throws Exception{
		DfLogger.info(IdocsUtil.class," :: buildAndExecuteServlet :  servletURL : "+servletURL,null,null);
		URL servletURLObject = new URL( servletURL );
		DfLogger.info(IdocsUtil.class," :: buildAndExecuteServlet : URL Built ",null,null);
		URLConnection servletConnection = servletURLObject.openConnection();
		DfLogger.info(IdocsUtil.class," :: buildAndExecuteServlet : Connection opened ",null,null);
		
		BufferedReader in = new BufferedReader(new InputStreamReader(servletConnection.getInputStream()));
		String responseMsg = EMPTY_STRING;
		
		while ((responseMsg = in.readLine()) != null) {
			if(!responseMsg.contains("null")){
				DfLogger.info(IdocsUtil.class,responseMsg,null,null);
			}else{
				DfLogger.info(IdocsUtil.class," :: buildAndExecuteServlet Exception >> "+responseMsg,null,null);
				in.close();
				throw new Exception("Servlet execution failed..!");
			}
		}
		in.close();
		DfLogger.info(IdocsUtil.class," :: buildAndExecuteServlet() : Servlet execute successful!!! ",null,null);
	}
	
	        
	/**
     * 
     * @param objectId
     * @return
     * @throws DfException
     */
    public static String constructDrl(String objectId,Component componentClass,ServletRequest request) throws DfException {
    	String drlString = DRLComponent.constructDRL(objectId, null, null, componentClass);
    	String fullDrl = null; 
		DfLogger.info(componentClass.getClass(), " : constructDrl :: drlString: " + drlString, null, null);
        if(drlString != null) {
            fullDrl = Component.makeFullUrl(request, drlString);
            DfLogger.info(componentClass.getClass(), " : constructDrl :: fullDrl: " + fullDrl, null, null);
        }else{
        	DfLogger.info(componentClass.getClass(), " : constructDrl :: Unable To Construct DRL", null, null);
        }
        if(fullDrl !=null && fullDrl.trim().length() >0){
        	return fullDrl;
        }else{
        	throw new DfException("Unable to communicate to the server.");
        }
    }
    
    
	/**
	 * This method frames a delimited string from the give array of strings. 
	 * @param roleStringArray
	 * @param separator
	 * @return
	 */
	public static String makeQuerySafe(String roleString, String devSuffix) {
//		devSuffix = null;
		DfLogger.debug(IdocsUtil.class, " :: makeQuerySafe : devSuffix ="+devSuffix,null,null);
		if(roleString != null){
			if(devSuffix != null && devSuffix.trim().length() >0);
			else{devSuffix=EMPTY_STRING;}
			String[] roleStringArray = roleString.split(IdocsConstants.MSG_COMMA);
			StringBuffer roleNames = new StringBuffer(IdocsConstants.MSG_QUOTES);
		    if (roleStringArray.length > 0) {
		    	roleNames.append(roleStringArray[0]);
		        for (int i=1; i <roleStringArray.length; i++) {
//		        	roleNames.append(devSuffix);
		        	roleNames.append(IdocsConstants.MSG_COMMA);
		        	roleNames.append(roleStringArray[i]);
		        }
//		        roleNames.append(devSuffix);
		        roleNames.append(IdocsConstants.MSG_QUOTES);
		        DfLogger.debug(IdocsUtil.class, " :: makeQuerySafe : "+roleNames.toString(),null,null);
		    }else{
		    	DfLogger.debug(IdocsUtil.class, " :: makeQuerySafe : roleStringArray is empty ",null,null);
		    }
		    if(roleNames!=null && roleNames.length()>0){
		    	roleString = roleNames.toString();
		    	roleString = roleString.replaceAll(IdocsConstants.MSG_COMMA, IdocsConstants.MSG_Q_COMMA_Q);
		    	roleString = roleString.replaceAll(IdocsConstants.MSG_HASH, devSuffix);
		    	DfLogger.debug(IdocsUtil.class, " :: makeQuerySafe : roleString ="+roleString,null,null);
		    	return roleString;
		    }
		}else{
			DfLogger.debug(IdocsUtil.class, " :: makeQuerySafe : roleStringArray is empty ",null,null);
		}
	    return null;
	}
	
	
	/**
	 * This static function is to identify the Application Environment.
	 * Made it static as work environment calculation can be done once when the application loads and this will be
	 * reused rather than querying every time. 
	 * @param strEnvSuffixQuery
	 * @param session
	 * @return
	 */
	public static String getLdapSuffixParam(IDfSession session) {
		if(envSuffix == null){
			try {
				envSuffix = IdocsUtil.getIdocsConfigInfoValue(session, WORK_ENV);
			} catch (DfException e) {
				DfLogger.error(IdocsUtil.class, "Unable to find the Workf Env Suffix", null, null);
			}
		}
		return envSuffix;
	}
	
	/**
	 * Tell whether the given string can bee a valid IOM ObjectName.
	 * @param exisitingDocName
	 * @return
	 */
	public static boolean isValidIOMObjectName(String exisitingDocName) {
		boolean isValid = true;
		if(exisitingDocName !=null && ((exisitingDocName.indexOf(CHAR_DOLLAR) != -1) //$
				|| (exisitingDocName.indexOf(CHAR_AMP) != -1) //& 
				|| (exisitingDocName.indexOf(CHAR_HASH) != -1) //#
				|| (exisitingDocName.indexOf(CHAR_PERCENTAGE) != -1) // %
				|| (exisitingDocName.indexOf(CHAR_PLUS) != -1) //+
				|| (exisitingDocName.indexOf(CHAR_PIPE) != -1) //|
				|| (exisitingDocName.indexOf(CHAR_BACKWARD_SLASH) != -1) //\
				|| (exisitingDocName.indexOf(CHAR_STAR) != -1) //*
				|| (exisitingDocName.indexOf(CHAR_LESSTHAN) != -1) //<
				|| (exisitingDocName.indexOf(CHAR_GREATERTHAN) != -1) //>
				|| (exisitingDocName.indexOf(CHAR_QUESTION_MARK) != -1) //?
				|| (exisitingDocName.indexOf(CHAR_FORWARD_SLASH) != -1) // /
				|| (exisitingDocName.indexOf(CHAR_COLON) != -1) // :
				|| (exisitingDocName.indexOf(CHAR_DOT) != -1) // .
				|| (exisitingDocName.indexOf(CHAR_DOUBLE_QUOTES) != -1) // "
				)){
			//$ & # % + | \ * < > ? / : . "
			//$ & # % + | \ * < > ? / : . "  
			isValid = false;
		}
		
		return isValid;
	}

	
	/**
	 * 
	 * @param roleString
	 * @param roleType
	 * @param isWFStarted
	 * @param errorMsg
	 * @return
	 * @throws DfException
	 */
	public static boolean validateRole(String projectId, String roleString,
			String roleType, String strDocumentState,
			boolean isWorkflowRestartable, String errorMsg,
			IDfSession session) throws DfException {
		boolean validated = false; 
		if (strDocumentState != null && strDocumentState.trim().length() > 0
				&& strDocumentState.equals(IdocsConstants.DOC_STATE_RELEASED)
				&& isWorkflowRestartable == false) {
			DfLogger.info(IdocsUtil.class," :: validateRole : Document Is RELEASED : validated ",null, null);
			return false;
		}
		String projMemberQry = EMPTY_STRING;
		String querySafeUserName = new StringBuffer().append(SINGLE_QUOTES).append(handleSingleQuote(session.getLoginUserName())).append(SINGLE_QUOTES).toString();
		if (IdocsConstants.MSG_IDESK_PROJECT_ROLE_TYPE.equals(roleType) == true) {
			boolean userPresentInLDAPGroup = isUserMemberofLDAPGroup(
					roleString, projectId,session);
			if (userPresentInLDAPGroup == true) {
				return true;
			} else {
				DfLogger.debug(IdocsUtil.class,"User is not present in LDAP Group. Continue with Direct User Membership",null, null);
			}
			roleString = IdocsUtil.makeQuerySafe(roleString, null);
			projMemberQry = getMessage(QRY_PROJ_MEMBER);
			projMemberQry = projMemberQry.replaceFirst(DOUBLE_QUOTES, SINGLE_QUOTES + projectId+ SINGLE_QUOTES);
			projMemberQry = projMemberQry.replaceFirst(DOUBLE_QUOTES, roleString);
			projMemberQry = projMemberQry.replaceFirst(DOUBLE_QUOTES, querySafeUserName);
			
		} else if (IdocsConstants.MSG_LDAP_GROUP_TYPE.equals(roleType) == true) {
			String devSuffix = IdocsUtil.getLdapSuffixParam(session);
			roleString = IdocsUtil.makeQuerySafe(roleString, devSuffix);
			projMemberQry = getMessage(QRY_LDAP_GROUP_MEMBER);
			projMemberQry = projMemberQry.replace(QRY_VARIABLE_LOGINUSERNAME, querySafeUserName);
			projMemberQry = projMemberQry.replace(QRY_VARIABLE_ROLESTRING, roleString);
		} else if (IdocsConstants.MSG_DM_GROUP_TYPE.equals(roleType) == true) {
			projMemberQry = getMessage(QRY_DM_GROUP_MEMBER);
			roleString = IdocsUtil.makeQuerySafe(roleString, null);
			projMemberQry = projMemberQry.replace(QRY_VARIABLE_LOGINUSERNAME, querySafeUserName);
			projMemberQry = projMemberQry.replace(QRY_VARIABLE_ROLESTRING, roleString);
		} else if (IdocsConstants.MSG_DM_USER_TYPE.equals(roleType) == true) {
			projMemberQry = idocsProperties.getProperty(QRY_DM_USER_MEMBER);
			roleString = IdocsUtil.makeQuerySafe(roleString, null);
			if (projMemberQry != null
					&& projMemberQry.trim().length() > 0
					&& projMemberQry.contains(session.getLoginUserName()) == false) {
				validated = true;
			} else {
				DfLogger.info(IdocsUtil.class," :: validateProjUserAccess : User is not authenticated : "+ roleString, null, null);
			}
		} else if (IdocsConstants.MSG_PROJECT_TEAM_TYPE.equals(roleType) == true) {
			DfLogger.debug("IdocsUtil.java", " :: for AS Templates validateProjUserAccess : NOT Validated : "+roleString,null,null);
			validated = checkASProjectTeam(projectId, session);
			DfLogger.info(IdocsUtil.class, " :: validateProjUserAccess : AS Documents: "+ validated, null, null);
			return validated;			
		}else {
			DfLogger.info(IdocsUtil.class, " :: validateProjUserAccess : Unknown Role Type : "+ roleType, null, null);
			return false;
		}
		DfLogger.info(IdocsUtil.class," :: validateProjUserAccess : projMemberQry : "+ projMemberQry, null, null);
		if (validated == false) {
			IDfQuery query = new DfQuery(projMemberQry);
			IDfCollection coll = query.execute(session, IDfQuery.DF_READ_QUERY);
			if (coll.next()) {
				validated = true;
				DfLogger.info(IdocsUtil.class," :: validateProjUserAccess : Validated against : "+ roleString, null, null);
				coll.close();
			}
			if(coll != null)coll.close();
		} else {
			DfLogger.info(IdocsUtil.class," :: validateProjUserAccess : Validated against : "+ roleString, null, null);
		}
		return validated;
	}

	/**
	 * 
	 * @param projectId
	 * @param session
	 * @return
	 * @throws DfException
	 */
	public static boolean checkASProjectTeam(String projectId, IDfSession session) throws DfException{
		
		/*
		 * Advisory Services Changes - START 
		 */
		
		boolean validated = false;
		String projectTeamQry =idocsProperties.getProperty(PROJECT_TEAM_MEMBERS_QRY);
		projectTeamQry = projectTeamQry.replaceAll(PROJECTID2, projectId);
		
		List<String> projectTeamList = IdocsUtil.dfCollectionToArrayList(IdocsUtil.executeQuery(session, projectTeamQry, DfQuery.READ_QUERY), IDocsConstants.MSG_ACCESSOR_ID);
		
		String getUserLoginIdQry = idocsProperties.getProperty(QRY_GET_USER_LOGIN_ID);
		getUserLoginIdQry = getUserLoginIdQry.replaceAll(LOGINUSERNAME, session.getLoginUserName());
		
		List<String> userLoginIdList  = IdocsUtil.dfCollectionToArrayList(IdocsUtil.executeQuery(session, getUserLoginIdQry, DfQuery.READ_QUERY), IDocsConstants.USER_OS_NAME);
		
		String userLoginId =  null;
		for (int i = 0; i < userLoginIdList.size(); i++) {
			userLoginId = userLoginIdList.get(i);
		}
		
		String userId = Integer.toString(Integer.parseInt(userLoginId));
		
		if(projectTeamList.contains(userId)){
			validated=true;
		}else{
			validated=false;
		}
		/*
		 * Advisory Services Changes - END 
		 */
		return validated;
	}
	
	/**
	 * 
	 * @param roleString
	 * @param projectId
	 * @param loginUserName
	 * @param session
	 * @return
	 */
	public static boolean isUserMemberofLDAPGroup(String roleString,
	String projectId,IDfSession session) {
	/** 1. Get the LDAP groups present in the Project Team for this Role
	* select distinct project_id from dm_dbo.IDOCS_PROJECT_TEAM where end_date IS NULL and project_id='' and staff_function_code in (select staff_function_code from dm_dbo.IDOCS_STAFF_FUNCTION where staff_function_nme in ('')) and project_team_member_id=(select user_os_name from dm_user where user_name='')
	* select accessor_name from dm_dbo.IDOCS_PROJECT_TEAM where end_date IS NULL and project_id='' and staff_function_code in (select staff_function_code from dm_dbo.IDOCS_STAFF_FUNCTION where staff_function_nme in (''))
	* select distinct ACCESSOR_NME from dm_dbo.IDOCS_ACCESSOR 
	*/
	try{ 
		Properties idocsProperties = new Properties();	
		idocsProperties.load(IdocsUtil.class.getResourceAsStream(IdocsConstants.IDOCS_PROPERTY_FILE));	 
		String devSuffix = IdocsUtil.getLdapSuffixParam(session);
		String queryVariableForLDAPGroup = IDocsConstants.MSG_EMPTY_STRING;
		String strQryGetLDAPGroup = getMessage(QRY_GET_LDAP_GROUP_ALL_ROLES);
		if(roleString != null && roleString.trim().length() > 0){
			strQryGetLDAPGroup = getMessage(QRY_GET_LDAP_GROUP);
			roleString = makeQuerySafe(roleString, null);
			strQryGetLDAPGroup = strQryGetLDAPGroup.replace(QRY_VARIABLE_ROLESTRING, roleString);
		}
		strQryGetLDAPGroup = strQryGetLDAPGroup.replace(QRY_VARIABLE_PROJECTID, makeQuerySafe(projectId, null));
		IDfCollection ldapGroupCollection = executeQuery(session, strQryGetLDAPGroup, IDfQuery.DF_READ_QUERY);
		while(ldapGroupCollection.next()){
			String ldapGroupName = IdocsUtil.handleSingleQuote(ldapGroupCollection.getString(MSG_ACCESSOR_NME));
			if(ldapGroupName != null && ldapGroupName.trim().length() > 0){
				if(queryVariableForLDAPGroup.trim().length()<=0){
					queryVariableForLDAPGroup = ldapGroupName;
				}else{
					queryVariableForLDAPGroup +=IdocsConstants.MSG_COMMA+ldapGroupName;
				}
			}
		}
		if(ldapGroupCollection != null)ldapGroupCollection.close();
		queryVariableForLDAPGroup = makeQuerySafe(queryVariableForLDAPGroup, devSuffix);
		String strQryProjectLdapUser = getMessage(QRY_GET_USER_FROM_PROJ_LDAP_GROUP);	
		strQryProjectLdapUser = strQryProjectLdapUser.replace(QRY_VARIABLE_QRYSAFELDAPGROUP, queryVariableForLDAPGroup);
		strQryProjectLdapUser = strQryProjectLdapUser.replace(QRY_VARIABLE_LOGINUSERNAME, IdocsUtil.handleSingleQuote(session.getLoginUserName()));
		DfLogger.debug(IdocsUtil.class, "queryVariableForLDAPGroup :"+queryVariableForLDAPGroup, null, null);
		DfLogger.debug(IdocsUtil.class, "strQryProjectLdapUser :"+strQryProjectLdapUser, null, null);
		boolean validated = false;
		
		IDfCollection collection = executeQuery(session, strQryProjectLdapUser, IDfQuery.DF_READ_QUERY);
		
		while(collection.next() && validated==false){
			String userName = collection.getString(MSG_I_ALL_USERS_NAMES);
			if(userName!=null && userName.equalsIgnoreCase(session.getLoginUserName())){
				validated = true;
			}
		}
		if(collection != null) {collection.close();}
		return validated;
		}catch (Exception e) {
			DfLogger.error(IdocsUtil.class, " :: isUserMemberofLDAPGroup : Exception:"+e.getMessage(), null, null);
		}
		return false;
	}
	
	/**
	 * This Utility function will check if the current User is part of any Project Roles		 
	 * @param roleString -ProjectRole OR Comma Separated Project Roles
	 * @param projectId - Project Id of the Project OR Comma Separated Client Project Ids of the Institution.
	 * @param dfSession
	 * @return
	 */
	public static boolean checkProjectInstiTeamMemberShip(String roleString,String projectId, IDfSession dfSession) {
		boolean validated = false;
		try {
			String grp_Qry = idocsProperties.getProperty(QRY_TEAM_MEMBERS_ALL);
			if(roleString != null && roleString.trim().length() > 0){
				grp_Qry = idocsProperties.getProperty("QRY_TEAM_MEMBERS");
				grp_Qry = grp_Qry.replaceFirst(QRY_VARIABLE_ROLESTRING,makeQuerySafe(roleString,null));
			}
			grp_Qry = grp_Qry.replaceFirst(QRY_VARIABLE_PROJECTID, makeQuerySafe(projectId,null));
			grp_Qry = grp_Qry.replaceFirst(QRY_VARIABLE_LOGINUSERNAME, IdocsUtil.handleSingleQuote(dfSession.getLoginUserName()));
			DfLogger.info(IdocsUtil.class, " :: checkTeamMemberShip() : grp_Qry :" + grp_Qry,null,null);
			IDfQuery query = new DfQuery();
			query.setDQL(grp_Qry);
			IDfCollection dfCollection = query.execute(dfSession, IDfQuery.DF_READ_QUERY);
			while(dfCollection.next() && validated == false){
				validated = true;
			}
			if(dfCollection != null)dfCollection.close();
			if(validated == false){
				validated = isUserMemberofLDAPGroup(null, projectId, dfSession);
			}
		} catch (DfException e) {
			e.printStackTrace();
			DfLogger.error(LaunchViewComponentWithPermitCheck.class, " :: checkTeamMemberShip() : Exception :" + e.getMessage(),null,null);
		}
		return validated ;
	}	

	/**
     * This will return the object id of the workflows started on this document.
     * @param dfsession
     * @param strObjectId
     * @return
     * @throws DfException
     */
    public static String getWorkflowId(IDfSession dfsession, String strObjectId) {
    	String workflowId = null;
    	String qryWorkflowId =getMessage(QRY_GET_WORKFLOW_ID);
    	qryWorkflowId = qryWorkflowId.replaceFirst(DOUBLE_QUOTES, SINGLE_QUOTES + strObjectId + SINGLE_QUOTES);
    	workflowId = execQuery(dfsession, qryWorkflowId, IDocsConstants.R_WORKFLOW_ID);
		return workflowId;
	}
    
    /**
     * 
     * @param sourceString
     * @param pattern
     * @param separator
     * @return
     */
    public static boolean checkIfTokenPresent(String sourceString, String pattern,
			String separator) {
		try {
			String sourceStringArray[] = sourceString.split(separator);
			for (int i = 0; i < sourceStringArray.length; i++) {
				String token= sourceStringArray[i];
				if(token != null && token.trim().length() >0 && token.equalsIgnoreCase(pattern)){
					return true;
				}
			}
		} catch (Exception e) {		
			DfLogger.error(IdocsUtil.class, " :: checkIfTokenPresent >> Exception : " + e.getMessage(), null, null);
			e.printStackTrace();
		}
		return false;
	}
    
    /**
     * This method executes the query and returns the result
     * 
     * @param dfSession
     * @param queryString
     * @param attrName
     * @return
     */
    private static String execQuery(IDfSession dfSession, String queryString, String attrName) {
    	String queryResult = null;
    	try{
    		DfQuery query = new DfQuery();
    		query.setDQL(queryString);
    		IDfCollection dfCollection = query.execute(dfSession, IDfQuery.DF_READ_QUERY);
    		if(dfCollection.next()) {
    			queryResult = dfCollection.getString(attrName);
    			dfCollection.close();
    		}
    		if(dfCollection != null)dfCollection.close();
    	} catch (DfException dfe) {
    		DfLogger.error(IdocsUtil.class, " :: execQuery >> " + dfe.getMessage(), null, dfe);
    	}
		return queryResult;
	}

    /**
     * Returns the client projects available for this Institution in IDOCS if input is Institution
     * Return the same project Id if input is project
     * @param strInstitutionNumberOrProjectId
     * @param dfSession
     * @param msgIdocsInstitutionDoc 
     * @return
     */
	public static String getClientProjects(
			String institutionNumber, IDfSession dfSession) {
		String clientProjects = IDocsConstants.MSG_EMPTY_STRING;
		try{
			String strClientProjects = getMessage(QRY_CLIE_INSTI_PROJECTS);
			strClientProjects = strClientProjects.replace(DOUBLE_QUOTES, institutionNumber);
			IDfCollection collection = executeQuery(dfSession, strClientProjects, IDfQuery.DF_READ_QUERY);
			while(collection.next()){
				String clientProjectId = collection.getString(PROJECT_ID);
				if(clientProjects.trim().length() <= 0){
					clientProjects = clientProjectId;
				}else{
					clientProjects += IdocsConstants.MSG_COMMA+clientProjectId;
				}
			}
			if(collection != null )collection.close();			
		}catch (Exception e) {
			DfLogger.error(IdocsUtil.class, "getClientProjects ; Exception "+e.getMessage(), null, null);
		}
	return clientProjects;
	}

	/**
	 * 
	 * @param groupName
	 * @param dfSession
	 * @return
	 */
	public static boolean isMemberOfGroup(String groupName , IDfSession dfSession) {
		boolean validated = false;
		try{
			String strQryGetGroupMemberShip = getMessage(QRY_GET_GROUP_MEMBERSHIP);
			strQryGetGroupMemberShip = strQryGetGroupMemberShip.replace(QRY_VARIABLE_GROUPNAME, groupName);
			strQryGetGroupMemberShip = strQryGetGroupMemberShip.replace(QRY_VARIABLE_LOGINUSERNAME, IdocsUtil.handleSingleQuote(dfSession.getLoginUserName()));
			IDfCollection collection = executeQuery(dfSession, strQryGetGroupMemberShip, IDfQuery.DF_READ_QUERY);
			while(collection.next() && validated == false){
				String userName = collection.getString(MSG_I_ALL_USERS_NAMES);
				if(userName != null && userName.equals(dfSession.getLoginUserName())){
					validated = true;
				}
			}
			if(collection != null)collection.close();
		}catch (Exception e) {
			DfLogger.error(IdocsUtil.class, "isMemberOfGroup : Exception"+e.getMessage(), null, null);
		}
		return validated;
	}
	
	public static String getMajorVersionLabel(String checkinVersionlabel){
		String majorVersionLabel = null;
		try{
			DfLogger.debug(IdocsUtil.class,"get Next Major Version From:"+ checkinVersionlabel,null,null);
			if(checkinVersionlabel!=null &&
					checkinVersionlabel.indexOf(IDocsConstants.MSG_SINGLE_SPACE, 0)>0){
				majorVersionLabel = checkinVersionlabel.substring(0,checkinVersionlabel.indexOf(IDocsConstants.MSG_SINGLE_SPACE, 0));
			}
		}catch (Exception e) {
			DfLogger.error(IdocsUtil.class,"Next Major Version : Exception :"+e.getMessage() ,null,null);			
		}		
		return majorVersionLabel;
	}
	
    /**
     * 
     * @param actionName
     * @param loginUserName
     * @param objectId
     */
	public static void auditIDocsActivity(String actionName,String objectId,IDfSession session) {
		try {
			String strAuditQuery = getMessage(QRY_AUDIT_IDOCS_ACTIVITIES);
			strAuditQuery = strAuditQuery.replace(AUDIT_OBJECT_ID, objectId);
			strAuditQuery = strAuditQuery.replace(AUDIT_ACTOR, handleSingleQuote(session.getLoginUserName()));
			strAuditQuery = strAuditQuery.replace(AUDIT_ACTION, actionName);
			strAuditQuery = strAuditQuery.replace(AUDIT_TIME_STAMP, new DfTime().asString(IDfTime.DF_TIME_PATTERN44));
			DfLogger.debug(IdocsUtil.class, ":: Audit :"+strAuditQuery, null, null);
			IDfCollection collection = executeQuery(session, strAuditQuery, IDfQuery.DF_EXEC_QUERY);
			if(collection !=null)collection.close();
		} catch (DfException e) {
			DfLogger.error(IdocsUtil.class, ":: Idocs Audit : Exception :"+e.getMessage(), null, null);
			e.printStackTrace();
		}
		
	}

	public static boolean isDocumentPresentForWorkflow(String productWorkflowNumber,
			String projectId,IDfSession session) {
		boolean validated = false;
		try {
			String strQryFindWfDocument = IdocsUtil.getMessage("QRY_GET_PRODUCT_DOC");
			strQryFindWfDocument = strQryFindWfDocument.replace(QRY_VARIABLE_PROJECTID,projectId);
			strQryFindWfDocument = strQryFindWfDocument.replace(QRY_VARIABLE_WF_NBR,productWorkflowNumber);
			IDfCollection collection = IdocsUtil.executeQuery(session, strQryFindWfDocument, IDfQuery.DF_READ_QUERY);
			while(collection.next() && validated==false){
				String strProjectId = collection.getString(PROJECT_ID);
				if(strProjectId !=null && strProjectId .trim().length() > 0 &&
						strProjectId.equals(projectId)){
					validated = true;
				}
			}
			if(collection != null)collection.close();
		} catch (DfException e) {
			DfLogger.error(IdocsUtil.class, " isDocumentPresentForWorkflow :: Exception ;"+e.getMessage(), null, null);
		}
		return validated;
	}

	
	/**
	 * This method attaches the lifecycle to the newly created document.
	 * @param dfsess
	 * @param strNewObjectId
	 * @throws DfException
	 */
	public static void attachPolicy(IDfSession dfsess, IDfSysObject newSysObject){
		try{
			DfLogger.debug(IdocsUtil.class, " :: attachPolicy : Current r_policy_id : "+newSysObject.getString("r_policy_id"),null,null);
			if(newSysObject.getString("r_policy_id").equals("0000000000000000")){
				DfLogger.debug(IdocsUtil.class, "attachPolicy :: No Lifecycle Attached ",null,null);
				DfLogger.debug(IdocsUtil.class, "attachPolicy :: If label : "+newSysObject.getString("r_version_label"),null,null);
			    StringBuffer strBuff = new StringBuffer(64);
			    strBuff.append("dm_policy where object_name='").append(IDocsConstants.MSG_IDOCS_LIFECYCLE).append(SINGLE_QUOTES);
			    com.documentum.fc.common.IDfId policyId = dfsess.getIdByQualification(strBuff.toString());
			    if(policyId!=null){
			    	DfLogger.debug(IdocsUtil.class, "attachPolicy :: LifeCycle : "+policyId.getId(),null,null);
			    }else{
			    	DfLogger.debug(IdocsUtil.class, "attachPolicy :: LifeCycle NOT FOUND :strBuff="+strBuff,null,null);	
			    }
			    newSysObject.attachPolicy(policyId, "0", EMPTY_STRING);
				DfLogger.debug(IdocsUtil.class, " :: attachPolicy : LifeCycle '"+IDocsConstants.MSG_IDOCS_LIFECYCLE+"' is attached with Stage '",null,null);
			}else{
				DfLogger.debug(IdocsUtil.class, " :: attachPolicy : Lifecycle is already attached",null,null);
			}
		}catch (Exception e) {
			DfLogger.error(IdocsUtil.class, " Lifecycle Attach Failed. "+e.getMessage(), null, null);
		}
	}
	

	/**
     * This method frames the IDESK integration servlet URL for product templates.
	 * @param component 
     * @param dfSession - Login Session
     * @param doc 	- Selected document
     * @param strPdtWfNbr - Product Workflow number from the Template info
     * @param strPdtWfTypeCode - Product Workflow type code from the Template info.
	 * @param pageContext
	 * @param forCancelCheckOut   - While Initial Version Cancel Checkout the table should be updated with Blank DRL.So that the IDEK Create Button reAppears.
     * @return - Servlet URl
     * @throws DfException
     */
	
	
	public static String getIdocsConfigInfoValue(IDfSession dfSession,String itemKey) throws DfException{
		String itemValue=EMPTY_STRING;
		String strIdocsConfigInfoQry =IdocsUtil.getMessage(QRY_GET_IDOCS_CONFIG_INFO);
		strIdocsConfigInfoQry = strIdocsConfigInfoQry.replaceFirst(IdocsConstants.MSG_C_DQ_C, IdocsConstants.MSG_QUOTES+itemKey+IdocsConstants.MSG_QUOTES);
		DfLogger.info(IdocsUtil.class, " :: Idocs Config Info Table query : " +strIdocsConfigInfoQry, null, null);
		DfQuery query = new DfQuery();
		query.setDQL(strIdocsConfigInfoQry);
		IDfCollection urlColl=query.execute(dfSession,IDfQuery.DF_READ_QUERY);
		while(urlColl.next()){
			itemValue=urlColl.getString(IdocsConstants.MSG_ITEM_VALUE);
		}
		DfLogger.debug(IdocsUtil.class, " ::item value from table :  "+itemValue,null,null);
		if(urlColl != null){
			urlColl.close();
		}
		return itemValue.toString();
	 }
	
	
    public static String buildServletURL(Component component, IDfSession dfSession, IDfDocument doc,
			String strPdtWfNbr, String strPdtWfTypeCode, PageContext pageContext,boolean forCancelCheckOut) throws DfException {
    	String servletBasicUrl = IdocsUtil.getIdocsConfigInfoValue(dfSession, PRODUCT_DRL_UPDATE_SERVLET_URL);

    	String strProject_id = doc.getString(PROJECT_ID);
        String strObjectId = doc.getObjectId().toString();
        
        String strDRL = IdocsUtil.constructDrl(strObjectId,component,pageContext.getRequest());
        strDRL = strDRL + "/versionLabel/CURRENT";
        DfLogger.info(IdocsUtil.class, ":: buildServletURL :: strDRL: " + strDRL, null, null);
        StringBuilder servletURL = new StringBuilder(servletBasicUrl);
        servletURL.append("userid").append("=iapplications");
        servletURL.append("&").append("mainresourceid").append("=");
        servletURL.append(strProject_id);
        servletURL.append("&").append("workflow_nbr").append("=");
        servletURL.append(strPdtWfNbr);
        servletURL.append("&").append("workflow_type_code").append("=");
        servletURL.append(strPdtWfTypeCode);
        servletURL.append("&").append("doc_url").append("=");
        if(forCancelCheckOut == false){
        	servletURL.append(strDRL);
        }else{
        	DfLogger.debug(IdocsUtil.class, " This is for Cancel CheckOut So fire Servlet with Blank URL", null, null);
        }
        DfLogger.info(IdocsUtil.class, ":: buildServletURL :: servletURL.toString(): " + servletURL.toString(), null, null);
        return servletURL.toString();
    }
    
    /**
	 * 
	 * @param dfDocument
	 * @param strTemplateName
	 * @return
	 * @throws DfException
	 * @throws IOException
	 */
    public static String asBuildServletURL(IDfDocument dfDocument,
    		String strTemplateName,IDfSession session,String asWorkflowCode) throws DfException, IOException{

    	StringBuffer strBuffer = new StringBuffer();
    	DfLogger.debug(IdocsUtil.class, (new StringBuilder(" :: asBuildServletURL : ")).append(session.getLoginUserName()).toString(), null, null);

    	String tempCategory=getTemplateCategoryCode(strTemplateName);

    	if(tempCategory != null && tempCategory.trim().length() >0){

    		/**If Template document is Supervision or PDP Supervision   then add financial data*/
    		Document documentObject = null;
    		String financialYear = null;
    		String quarter = null;
    		if(tempCategory.equals(IDocsConstants.MSG_AS_SUPERVISION_TEMPCODE) || tempCategory.equals(IDocsConstants.MSG_AS_PDP_SUPERVISION_TEMPCODE)){
    			
    			/** Reading Financial year and quarter values from Servlet*/	
    			try{
    				documentObject = getFinancialData(dfDocument.getString(IDocsConstants.PROJECT_ID), session,tempCategory);
    				XPathFactory xPathFactory = XPathFactory.newInstance();
    				XPath xPath = xPathFactory.newXPath();
    				XPathExpression fyExpression = xPath.compile("/as_supervision/spv_fy");
    				financialYear = fyExpression.evaluate(documentObject);
    				DfLogger.debug(IdocsUtil.class,": Financial Year : "+financialYear,null,null);
    				XPathExpression qtrExpression = xPath.compile("/as_supervision/spv_qtr");
    				quarter = qtrExpression.evaluate(documentObject);
    				DfLogger.debug(IdocsUtil.class,": Financial Quater : "+quarter,null,null);
    				if(financialYear==null){
    					Integer integerObj = new Integer(Calendar.YEAR);
    					financialYear = integerObj.toString();
    				}
    				if(quarter==null){
    					quarter = EMPTY_STRING;
    				}
    			}
    			catch (XPathExpressionException e) {
    				DfLogger.error(IdocsUtil.class, "<< Exception>>"+e.getMessage(), null, null);
    			}
    		}else{
    			DfLogger.debug(IdocsUtil.class, "Not supervision or PDP SuperVision doc "+strTemplateName, null, null);
    		}
    		DfLogger.debug(IdocsUtil.class, "template category code ::"+tempCategory, null, null);
    		String servletBasicUrl = IdocsUtil.getIdocsConfigInfoValue(session, ASOP_UPDATE_SERVLET_URL);
    		DfLogger.debug(IdocsUtil.class, (new StringBuilder(" :: Advisory Services : build Servlet URL  : ").append(servletBasicUrl)).toString(), null, null);
    		if(servletBasicUrl != EMPTY_STRING){
    			strBuffer.append(servletBasicUrl);
    		}
    		SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy~hh-mm-ss~a");
    		Calendar cal = Calendar.getInstance();
    		DfLogger.debug(IdocsUtil.class, (new StringBuilder(dateFormat.format(dfDocument.getTime("r_creation_date").getDate())).append(": Document Creation date")).toString(), null, null);
    		try {
    			strBuffer.append("task=updatestatus&project_id=")
    			.append(dfDocument.getString(PROJECT_ID))
    			.append("&document_id=")
    			.append(dfDocument.getObjectId().getId())
    			.append("&document_version=")
    			.append(dfDocument.getVersionLabel(0))
    			.append("&workflow_id=")
    			.append(EMPTY_STRING)
    			.append("&status=")
    			.append(asWorkflowCode)
    			.append("&status_date=")
    			.append(dateFormat.format(cal.getTime()));
    			if(tempCategory.equals(IDocsConstants.MSG_AS_PDP_SUPERVISION_TEMPCODE) || tempCategory.equals(IDocsConstants.MSG_AS_SUPERVISION_TEMPCODE)){
    				strBuffer.append("&year=").append(financialYear).append("&quarter=").append(quarter);
    			}
    			strBuffer.append("&temp_cat=")
    			.append(tempCategory);
    		} catch (Exception e) {
    			DfLogger.error(IdocsUtil.class, " :: asBuildServletURL: Exception : " + e.getMessage(), null, null);
    		}
    		DfLogger.debug(IdocsUtil.class, (new StringBuilder(" :: Advisory Services : Servlet URL  : ")).append(strBuffer.toString()).toString(), null, null);	
    	}else{
    		DfLogger.debug(IdocsUtil.class, "Template Code is Empty ", null, null);
    	}
    	return strBuffer.toString();
    }
	
	/**
	 * 
	 * @param document
	 * @param dfSession
	 * @return
	 * @throws DfException
	 */
	public static Document getFinancialData(String projectID, IDfSession dfSession,String tempCategory) throws DfException{
		Document doc = null;
		String basicTempIntgUrl = IdocsUtil.getIdocsConfigInfoValue(dfSession, AS_TEMP_INTG_URL);
		if(null != basicTempIntgUrl){
			StringBuffer tempIntgBuffer = new StringBuffer(basicTempIntgUrl);
			if(tempCategory.equals(IDocsConstants.MSG_AS_PDP_SUPERVISION_TEMPCODE)){
				tempIntgBuffer.append("Stage=PDPSupervision&ProjectId=").append(projectID);
			}else{
				tempIntgBuffer.append("Stage=Supervision&ProjectId=").append(projectID);	
			}
			
			DfLogger.info(IdocsUtil.class,": tempIntgBuffer : "+tempIntgBuffer.toString(),null,null);
			DocumentBuilderFactory buildFactory = DocumentBuilderFactory.newInstance();
			try {
				DocumentBuilder docBuilder = buildFactory.newDocumentBuilder();
				URL url = new URL(tempIntgBuffer.toString());
				DfLogger.info(IdocsUtil.class,": url.openStream() : START" ,null,null);
				InputStream in  = url.openStream();
				DfLogger.info(IdocsUtil.class,": url.openStream() : END" ,null,null);
				doc = docBuilder.parse(in);
				DfLogger.info(IdocsUtil.class,": Doc Object Created : "+ doc ,null,null);
			}catch(IOException e){
				DfLogger.error(IdocsUtil.class,": getFinancialData : IOException "+e.getMessage(),null,null);
				e.printStackTrace();
			} catch (ParserConfigurationException e) {
				DfLogger.error(IdocsUtil.class,": getFinancialData : ParserConfigurationException "+e.getMessage(),null,null);
				e.printStackTrace();
			} catch (org.xml.sax.SAXException e) {
				DfLogger.error(IdocsUtil.class,": getFinancialData : SAXException "+e.getMessage(),null,null);
				e.printStackTrace();
			} catch (Exception e) {
				DfLogger.error(IdocsUtil.class,": getFinancialData : Exception "+e.getMessage(),null,null);
				e.printStackTrace();
			}
		}
		return doc;
		
	}
	
	/**
	 * This method enables/disable startworkflow checkbox(during checkin) and menuitem 
	 * @param strDocumentId
	 * @return
	 * @throws DfException
	 */
	
	public static String getPartnerTier(String strDocumentId, IDfSession dfSession) throws DfException {
		String strPartnerTier = null;
		String partnerTierQry = idocsProperties.getProperty(GET_PARTNER_TIER); 
		partnerTierQry = partnerTierQry.replace(QRY_VARIABLE_OBJECTID, strDocumentId);
		DfLogger.info(IdocsUtil.class, " :: getPartnerTier: partnerTierQry: " + partnerTierQry, null, null);
		IDfCollection colPartnerTier = null;
		colPartnerTier = (IDfCollection) executeQuery(dfSession, partnerTierQry, IDfQuery.DF_READ_QUERY);
		while (colPartnerTier.next()) {
			strPartnerTier = colPartnerTier.getString(INSTITUTION_TIER_CODE);
		}
		if (colPartnerTier != null) {
			colPartnerTier.close();
		}
		return strPartnerTier;

	}
	
	/**
	 * 
	 * @param partnerTier
	 * @return
	 */
	public static boolean isValidPartnerTier(String partnerTier) {
		if(partnerTier != null 
				 && partnerTier.trim().length() > 0 
				 && ( partnerTier.equals(IDocsConstants.MSG_TIER_1)
						 || partnerTier.equals(IDocsConstants.MSG_TIER_2)
						 || partnerTier.equals(IDocsConstants.MSG_TIER_CRR_NOT_FOUND)) == true){
			return true;
		}else{
			return false;
		}
	}

	/**
	 * 
	 * @param projectTier
	 * @return
	 */
	public static boolean isValidProjectTier(String projectTier) {
		if (projectTier != null
				&& projectTier.trim().length() > 0
				&& (projectTier.equals(IDocsConstants.MSG_PROJECT_TIER_1)
						|| projectTier.equals(IDocsConstants.MSG_PROJECT_TIER_2)
						|| projectTier.equals(IDocsConstants.MSG_PROJECT_TIER_3) 
						|| projectTier.equals(IDocsConstants.MSG_PROJECT_TIER_NA)) == true) {
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * This method enables/disable startworkflow checkbox(during checkin) and menuitem after Project Tier Validation
	 * @param strDocumentId
	 * @return
	 * @throws DfException
	 */
	public static String getProjectTier(String objectId, IDfSession dfSession)  throws DfException {
		String strProjectTier = null;
		String projectTierQry = idocsProperties.getProperty(GET_PROJECT_TIER); 
		projectTierQry = projectTierQry.replace(QRY_VARIABLE_OBJECTID, objectId);
		DfLogger.info(IdocsUtil.class, " :: getProjectTier: projectTierQry: " + projectTierQry, null, null);
		IDfCollection colProjectTier = null;
		colProjectTier = (IDfCollection) executeQuery(dfSession, projectTierQry, IDfQuery.DF_READ_QUERY);
		while (colProjectTier.next()) {
			strProjectTier = colProjectTier.getString(PROJECT_TIER_CODE);
		}
		if (colProjectTier != null) {
			colProjectTier.close();
		}
		return strProjectTier;
	}	

	/**
	 * 
	 * @param session
	 * @param objectId
	 * @return
	 */
	public static String getTemplateTitle(IDfSession session,String objectId) {
		String strTemplateTitle = null;
		try {
			String strGetTemplateTitleQuery = getMessage(QRY_GET_TEMPLATE_TITLE);
			strGetTemplateTitleQuery = strGetTemplateTitleQuery.replaceFirst(IdocsConstants.MSG_C_DQ_C, IdocsConstants.MSG_QUOTES +
					objectId + IdocsConstants.MSG_QUOTES);
			DfLogger.info(IdocsUtil.class, " :: getTemplateTitle: strGetTemplateTitleQuery: " + strGetTemplateTitleQuery, null, null);
			IDfCollection collection = executeQuery(session, strGetTemplateTitleQuery, IDfQuery.DF_READ_QUERY);
			while(collection.next()){
				strTemplateTitle = collection.getString(IDocsConstants.MSG_TEMPLATE_TITLE);
			}
			if(collection != null )collection.close();
		} catch (DfException e) {
			DfLogger.error(IdocsUtil.class, " :: getTemplateTitle: Exception : " + e.getMessage(), null, null);
		}
		return strTemplateTitle;
	}

	/**
	 * This method finds whether the given template is Rights Issue CSO or not
	 * 
	 * @param session
	 * @param objectId
	 * @param strTemplateTitle
	 * @param strProjectId
	 * @return true -- If template is Rights Issue CSO
	 */
	public static String checkIfRightsIssueCSO(IDfSession session, String objectId, String strTemplateTitle) {
		try {
			DfLogger.debug(IdocsUtil.class," :: checkIfRightsIssueNonCSO : Template is : " + strTemplateTitle,null,null);
			// To get Object Type
			String strObjectType = IDocDocbaseAttributeTagUtility.getSysObjectAttribute(session,
					objectId,IdocsConstants.R_OBJECT_TYPE);
			// To get Project Id
			String strProjectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(session,
					objectId,IdocsConstants.PROJ_ID,strObjectType);
			String rightsIssueTemplateTitleName = idocsProperties.getProperty("MSG_RIGHTS_ISSUE_TEMPLATE_TITLE");
			if(rightsIssueTemplateTitleName !=null && strTemplateTitle !=null && strProjectId!=null
					&& rightsIssueTemplateTitleName.trim().length()>0 && strTemplateTitle.trim().length()>0 && strProjectId.trim().length()>0
					&& rightsIssueTemplateTitleName.equalsIgnoreCase(strTemplateTitle)){
								
				String strSouCode = getSouCodeFromProjectId(strProjectId, session);
				if(strSouCode!=null && strSouCode.trim().length() >0) {
					String nonCSOSouCodes = idocsProperties.getProperty(MSG_NON_CSO_VALUES);
					if(IdocsUtil.checkIfTokenPresent(nonCSOSouCodes,strSouCode,COMMA)) {
						/** Rights Issue NON CSO */
						String nonCSOProcessName = idocsProperties.getProperty("MSG_RIGHTS_ISSUE_NON_CSO_PROCESS_NAME");
						DfLogger.debug(IdocsUtil.class," :: checkIfRightsIssueNonCSO : nonCSOProcessName : " + nonCSOProcessName,null,null);
						return IDocsConstants.MSG_NON_CSO;
					} else {
						/** Rights Issue CSO */
						String CSOProcessName = idocsProperties.getProperty("MSG_RIGHTS_ISSUE_CSO_PROCESS_NAME");
						DfLogger.debug(IdocsUtil.class," :: checkIfRightsIssueNonCSO : CSOProcessName : " + CSOProcessName,null,null);
						return IDocsConstants.MSG_CSO; 
					}
				} else{
					 DfLogger.debug(IdocsUtil.class," :: checkIfRightsIssueNonCSO : SOU_CODE is NULL for Project:  " + strProjectId,null,null);
					 return IDocsConstants.MSG_RIGHTS_ISSUE_INVALID_SOU;
				}
			} else {
				return IDocsConstants.MSG_OTHER; // Template is other than Rights Issue 
			}
		} catch (Exception e) {
			DfLogger.error(IdocsUtil.class," :: checkIfRightsIssueNonCSO : Exception "+e.getMessage(),null,null);
		}
		return IDocsConstants.MSG_EXCEPTION;
	}
	
	
	/**
     * This utility method is to get the sou code from the project
     * @param strprojectId - Id of the project.
     * @return
     */
    public static String getSouCodeFromProjectId(String strprojectId, IDfSession session) {
    	String strSouCode= null;
    	try{
	    	String strGetSouCodeQuery = idocsProperties.getProperty(QRY_GET_CSO_FROM_PROJECT);
	    	strGetSouCodeQuery = strGetSouCodeQuery.replaceFirst(IdocsConstants.MSG_C_DQ_C,  IdocsConstants.MSG_QUOTES+strprojectId+IdocsConstants.MSG_QUOTES);
			IDfCollection collection = IdocsUtil.executeQuery(session, strGetSouCodeQuery, IDfQuery.DF_READ_QUERY);
			while(collection.next()){
				strSouCode = collection.getString(IDocsConstants.MSG_SOU_CODE);
			}
			if(collection != null)collection.close();
	    }catch (Exception e) {
	    	 DfLogger.error(IdocsUtil.class," :: getSouCodeFromProjectId : Exception "+e.getMessage(),null,null);
		}
	    DfLogger.debug(IdocsUtil.class," :: getSouCodeFromProjectId : strSouCod:= "+strSouCode,null,null);
	    return strSouCode;
	}
    
	/**
	* Fetches an Admin Session Manager
	* @return
	* @throws DfException
	*/
	public static IDfSessionManager getAdminSessionManager(IDfSession userSession) throws DfException {
		DfLogger.debug(IdocsUtil.class, " :: getAdminSessionManager : Entered ",null,null);
		String strUserName = null;
		String strPassword = null;
		IDfSessionManager sessionManager = DfClient.getLocalClient().newSessionManager();
	
		IDfQuery dFquery = new DfQuery();
		dFquery.setDQL(getMessage(QRY_GET_SEC_CRED));
		IDfCollection collection = dFquery.execute(userSession, IDfQuery.DF_READ_QUERY);
		while(collection.next()){
			strUserName = collection.getString(IdocsConstants.MSG_ITEM_KEY);
			strPassword = collection.getString(IdocsConstants.MSG_ITEM_VALUE);
		}
		if(collection != null)collection.close();
		IDfLoginInfo login = new DfLoginInfo();
		login.setUser(strUserName);
		try {
			login.setPassword(com.documentum.fc.tools.RegistryPasswordUtils.decrypt(strPassword));
		} catch (Exception e) {
			try{
				login.setPassword(ESAPI.encryptor().decrypt(strPassword));
			}catch (Exception ex) {
				DfLogger.error(IdocsUtil.class, " :: getAdminSessionManager : IFCDecryption ",null,null);
			}
		}
		login.setDomain( null );
		sessionManager.setIdentity(userSession.getDocbaseName(), login );
		DfLogger.debug(IdocsUtil.class, " :: getAdminSessionManager : Exit ",null,null);
		return sessionManager;
	}

	/**
	 * 
	 * @param userName
	 * @return
	 */
	public static String handleSingleQuote(String userName) {
		String tempUserName = EMPTY_STRING;
		if(null != userName && userName.contains(SINGLE_QUOTES))
			tempUserName = userName.replaceAll(SINGLE_QUOTES, DOUBLE_QUOTES);
		else
			tempUserName = userName;
		return tempUserName;
	}
	
	/**
	 * 
	 * @param role
	 * @param session
	 * @return
	 */
	public static String handleLDAPEnvVariable(String role, IDfSession session) {
		DfLogger.debug(IdocsUtil.class, " :: handleLDAPEnvVariable : role before parsing: " + role,null,null);
		String envSuffix = IdocsUtil.getLdapSuffixParam(session);
		String tempRole = IDocsConstants.MSG_EMPTY_STRING;
		if(role !=null && role.trim().length() > 0 
				&& role.contains(IdocsConstants.MSG_HASH)){
			tempRole = role.replaceAll(IdocsConstants.MSG_HASH, envSuffix);
		}else{
			tempRole = role;
		}
		return tempRole;
		
	}
	
	/**
	 * Check the Conflict of interest.
	 * @param projectId
	 * @param session
	 * @return
	 */
	public static boolean isUserPresentInConflictOfInterest(String projectId,IDfSession session) {
		boolean validated = false;
		try{
			String strCOIQuery = getMessage(QRY_CONFLICT_OF_INTEREST);
			strCOIQuery = strCOIQuery.replace(QRY_VARIABLE_PROJECTID,projectId);
			strCOIQuery = strCOIQuery.replace(QRY_VARIABLE_LOGINUSERNAME, IdocsUtil.handleSingleQuote(session.getLoginUserName()));
			IDfCollection collection = IdocsUtil.executeQuery(session, strCOIQuery, IDfQuery.DF_READ_QUERY);
			while(collection.next() && validated == false){
				String projectIdFromCollection = collection.getString(IdocsConstants.PROJ_ID);
				if(projectIdFromCollection !=null && projectIdFromCollection.trim().length() > 0
						&& projectIdFromCollection.equals(projectId)){
					validated = true;
				}
			}
			if(collection !=null)collection.close();
		}catch (Exception e) {
			DfLogger.error(LaunchViewComponentWithPermitCheck.class, ": Exception :"+e.getMessage(), null, null);
		}
		return validated;
	}

	/**
	 * Check whether the current login username is memeber of any of the groupnames
	 * given in comma separated way.
	 * @param projectRole
	 * @param projectId
	 * @param session
	 * @return
	 */
	public static boolean checkDmGroupMemberShip(String groupNames,IDfSession session) {
		boolean validated = false;
		try{
			String dmGroupMemberQry = idocsProperties.getProperty(QRY_DM_GROUP_MEMBER);
			String querySafeUserName = new StringBuffer().append(SINGLE_QUOTES).append(handleSingleQuote(session.getLoginUserName())).append(SINGLE_QUOTES).toString();
			groupNames = handleSingleQuote(groupNames);
			groupNames = IdocsUtil.makeQuerySafe(groupNames, null);
			dmGroupMemberQry = dmGroupMemberQry.replace(QRY_VARIABLE_LOGINUSERNAME, querySafeUserName);
			dmGroupMemberQry = dmGroupMemberQry.replace(QRY_VARIABLE_ROLESTRING, groupNames);
			IDfCollection collection = executeQuery(session, dmGroupMemberQry, IDfQuery.DF_READ_QUERY);
			while(collection.next()){
				String groupName = collection.getString("group_name");
				if(groupName != null && groupName.trim().length() > 0){
					validated = true;
					DfLogger.debug(IdocsUtil.class, " :: checkDmGroupMemberShip ::User is part of groupName :"+groupName, null, null);
					break;
				}
			}
			if(collection != null)collection.close();
		}catch (Exception e) {
			DfLogger.debug(IdocsUtil.class, " :: checkDmGroupMemberShip ::Exception:"+e.getMessage(), null, null);
		}
		return validated;
	}

	/**
	 * 
	 * @param strTemplateName
	 * @return
	 */
	public static boolean isProductTemplate(String strTemplateName) {
		DfLogger.debug(IdocsUtil.class, " :: isProductTemplate :: "+strTemplateName, null, null);
		String strProductTypeTemplates = IdocsUtil.getMessage(MSG_PRODUCT_TEMPLATES);
		if(strProductTypeTemplates != null && strProductTypeTemplates.trim().length() > 0){
			if(IdocsUtil.checkIfTokenPresent(strProductTypeTemplates, strTemplateName, IdocsConstants.MSG_COMMA)){
				DfLogger.debug(IdocsUtil.class, " :: isProductTemplate :: Yes "+strTemplateName+" is a Product Template", null, null);
			 return true;
			}else{
				DfLogger.debug(IdocsUtil.class, " :: isProductTemplate :: "+strTemplateName+" is NOT a Product Template", null, null);
				return false;
			}
		}else{
			DfLogger.debug(IdocsUtil.class, " :: isProductTemplate :: Not able to read MSG_PRODUCT_TEMPLATES from Props", null, null);
			return false;
		}		
	}
	
	/**
	 * This is a utility method to check whether the template is an exception in Non Workflow Documents.
	 * Project Summary is an exception for edit permissions among Non Workflow Documents. 
	 * @param strTemplateName - Name of the Template
	 * @return
	 */
	public static boolean isSpecialNonWorkflowDocument(String strTemplateName) {
		DfLogger.debug(IdocsUtil.class, " :: isSpecialNonWorkflowDocument :: "+strTemplateName, null, null);
		String strProductTypeTemplates = IdocsUtil.getMessage(MSG_SPECIAL_NONWORKFLOW_TEMPLATES);
		if(strProductTypeTemplates != null && strProductTypeTemplates.trim().length() > 0){
			if(IdocsUtil.checkIfTokenPresent(strProductTypeTemplates, strTemplateName, IdocsConstants.MSG_COMMA)){
				DfLogger.debug(IdocsUtil.class, " :: isSpecialNonWorkflowDocument :: Yes "+strTemplateName+" is a Special Non Workflow Document", null, null);
			 return true;
			}else{
				DfLogger.debug(IdocsUtil.class, " :: isSpecialNonWorkflowDocument :: "+strTemplateName+" is NOT a Special Non Workflow Document", null, null);
				return false;
			}
		}else{
			DfLogger.debug(IdocsUtil.class, " :: isProductTemplate :: Not able to read MSG_SPECIAL_NONWORKFLOW_TEMPLATES from Props", null, null);
			return false;
		}
	}
				
	// Code is for Advisory Services - START
		
	/**
	 * This method checks if the template belongs to Advisory Services
	 * Return true if this is Advisory template
	 * @param strTemplateTitle
	 * @return
	 */

	public static boolean isAdvisoryTemplate(String strTemplateTitle) {
		
		boolean isAdvisoryTemplate = false;
		if(strTemplateTitle !=null ){
			if(strTemplateTitle.equals(IDocsConstants.MSG_AS_CONCEPT_NOTE) == true
					|| strTemplateTitle.equals(IDocsConstants.MSG_AS_IMPLEMENTATION_PLAN) == true
					|| strTemplateTitle.equals(IDocsConstants.MSG_AS_SUPERVISION) == true
					|| strTemplateTitle.equals(IDocsConstants.MSG_AS_COMPLETION) == true
					|| strTemplateTitle.equals(IDocsConstants.MSG_AS_DROPPAGE_NOTE) == true
					|| strTemplateTitle.equals(IDocsConstants.MSG_AS_DROPPAGE_MEMO) == true
					|| strTemplateTitle.equals(IDocsConstants.MSG_AS_PLAN)== true
				//New Templates added for 12th OCT 2012 
					|| strTemplateTitle.equals(IDocsConstants.MSG_AS_PDP_IMPL_PLAN) == true
					|| strTemplateTitle.equals(IDocsConstants.MSG_AS_PDP_SUPERVISION) == true){
				isAdvisoryTemplate = true;
				DfLogger.debug(IdocsUtil.class, " :: isAdvisoryTemplate :"+isAdvisoryTemplate, null, null);					
			}else{
				DfLogger.debug(IdocsUtil.class, " :: isAdvisoryTemplate  = "+isAdvisoryTemplate, null, null);
			}
		}else{
			DfLogger.debug(IdocsUtil.class, " :: Template TITLE is NULL :", null, null);
		}		
		return isAdvisoryTemplate;
	}	
	
	/**
	 * 
	 * @param projectTeamCollection
	 * @param userName
	 * @return
	 * @throws DfException
	 */
	public static List<String> dfCollectionToArrayList(IDfCollection projectTeamCollection, String userName) throws DfException {
		
		List<String> projectTeamList = new ArrayList<String>();
		
		try {
			while(projectTeamCollection.next()){
				String prjTeamUserName = projectTeamCollection.getString(userName);
				DfLogger.debug(IdocsUtil.class, " :: User from Project Team :"+prjTeamUserName, null, null);
				projectTeamList.add(prjTeamUserName);				
				
			}
		} catch (DfException e) {
			DfLogger.debug(IdocsUtil.class, " :: dfCollectionToArrayList ::Exception:"+e.getMessage(), null, null);
		}finally{
			if(projectTeamCollection != null){
				projectTeamCollection.close();
			}
		}
		DfLogger.debug(IdocsUtil.class, " :: List of users from  of Project Team :"+projectTeamList.toString(), null, null);
		return projectTeamList;
	}

	/** This utility method is to check the Aspect Type of the document.
	 * Returns String EMAIL if its email Document
	 * Returns String SCANNES if its scanned document */
	public static String isThisEmailOrScanned(String strObjectId,IDfSession dfSession) {
		String documentAspectNature = null;
		try {
			String getAspectsQuery = "select r_aspect_name from idocs_document where r_object_id='"
					+ strObjectId + "'  order by r_aspect_name";
			IDfCollection aspectNameCollection = executeQuery(dfSession,
					getAspectsQuery, IDfQuery.DF_READ_QUERY);
			while(aspectNameCollection.next()){
				String aspectName = aspectNameCollection.getString(IdocsConstants.R_ASPECT_NAME);
				if(aspectName != null && aspectName.trim().length() > 0 
						&& IdocsConstants.IDOCS_EMAIL_DOC_ASPECT.equals(aspectName)){
					documentAspectNature = IdocsConstants.EMAIL;
				}
				if(aspectName != null && aspectName.trim().length() > 0 
						&& IdocsConstants.IDOCS_SCANNING_DOC_ASPECT.equals(aspectName)){
					documentAspectNature = IdocsConstants.SCANNING;
				}					
			}
			if(aspectNameCollection != null)aspectNameCollection.close();			
		} catch (Exception e) {
			DfLogger.debug(IdocsUtil.class, " isThisEmailOrScanned :: Exception:"+e.getMessage(), null, null);
		}
		return documentAspectNature;
	}
	
	
	public static String fetchProcessTemplateName(IDfSession dfSession, String wflowId, Properties idocsProperties) throws DfException 
	{
		
		String processDql = null;
		processDql = idocsProperties.getProperty(PROCESS_QRY);
		processDql = processDql.replaceFirst(DOUBLE_QUOTES, SINGLE_QUOTES+wflowId+SINGLE_QUOTES);

		IDfCollection dfCollection = null;
		dfCollection = executeQuery(dfSession, processDql, IDfQuery.DF_READ_QUERY);
		String wfTemplateName = null;
		try {
			while (dfCollection.next()){
				wfTemplateName = dfCollection.getString(IdocsConstants.OBJECT_NAME);
			}
		} catch (Exception e) {
			DfLogger.info(IdocsUtil.class,"fetchProcessTemplateName() :EXCEPTION OCCURED: "+e.getMessage(),null,null);
		}finally{
			if(dfCollection != null){
				dfCollection.close();
			}
		}

		return wfTemplateName ;
	} 
	
	public static String getDocumentName(IDfSession dfSession, String wfIdStr, String processName, Properties idocsProperties) throws DfException{

		String docName = null;
		String docObjNmeQry = null;
		IDfCollection docObjNmeColl = null;

		docObjNmeQry = idocsProperties.getProperty("AS_WF_DOC_OBJ_NME");
		docObjNmeQry = docObjNmeQry.replaceAll("%wfId%", wfIdStr);
		docObjNmeQry = docObjNmeQry.replaceAll("%docName%", "%"+processName+"%");

		try{
			docObjNmeColl = executeQuery(dfSession, docObjNmeQry, IDfQuery.DF_READ_QUERY);
			while(docObjNmeColl.next()){
				docName = docObjNmeColl.getString("r_component_name");
			}
		}
		finally{
			if(null != docObjNmeColl){
				docObjNmeColl.close();
			}
		}

		return docName;
	}
	
	public static void executeASSevlet(IDfSession adminSession, String projectId, Properties idocsProperties, String workflowId) throws DfException{
		
		String financialYear = null;
		String quater = null;
		String servletBasicUrl = null;
		String documentName = null;
		String processNme = null;
		String basicTempIntgUrl =IdocsUtil.getIdocsConfigInfoValue(adminSession, AS_TEMP_INTG_URL);
		if(null != basicTempIntgUrl){
			StringBuffer tempIntgBuffer = new StringBuffer(basicTempIntgUrl);
			tempIntgBuffer.append("Stage=Supervision&ProjectId=").append(projectId);
			DocumentBuilderFactory buildFactory = DocumentBuilderFactory.newInstance();
			try {
				DocumentBuilder docBuilder = buildFactory.newDocumentBuilder();
				XPathFactory xPathFactory = XPathFactory.newInstance();
				XPath xPath = xPathFactory.newXPath();

				URL url = new URL(tempIntgBuffer.toString());
				InputStream in  = url.openStream();
				Document doc = docBuilder.parse(in);

				XPathExpression fyExpression = xPath.compile("/as_supervision/spv_fy");
				financialYear = fyExpression.evaluate(doc);
				DfLogger.debug(IdocsUtil.class, " financialYear : "+financialYear, null, null);

				XPathExpression qtrExpression = xPath.compile("/as_supervision/spv_qtr");
				quater = qtrExpression.evaluate(doc);
				DfLogger.debug(IdocsUtil.class, " quater :"+quater, null, null);

			}
			catch(IOException e){
				DfLogger.error(IdocsUtil.class, "getFinancialData() : EXCEPTION OCCURED " + e.getMessage(), null, null);
			} catch (SAXException e) {
				DfLogger.error(IdocsUtil.class, "getFinancialData() : EXCEPTION OCCURED " + e.getMessage(), null, null);
			} catch (XPathExpressionException e) {
				DfLogger.error(IdocsUtil.class, "getFinancialData() : EXCEPTION OCCURED " + e.getMessage(), null, null);
			} catch (ParserConfigurationException e) {
				DfLogger.error(IdocsUtil.class, "getFinancialData() : EXCEPTION OCCURED " + e.getMessage(), null, null);
			}
		}
		processNme = fetchProcessTemplateName(adminSession, workflowId, idocsProperties);
		documentName = getDocumentName(adminSession, workflowId, processNme, idocsProperties);
		IDfDocument dfDocument = null;
		dfDocument = (IDfDocument) adminSession.getObjectByQualification("dm_document where object_name = '"+documentName+SINGLE_QUOTES);
		servletBasicUrl = IdocsUtil.getIdocsConfigInfoValue(adminSession, ASOP_UPDATE_SERVLET_URL2);
		String tempCategory = null;
		/** Validating ProcessName is related to Advisory Services */
		if(processNme.equals(IDocsConstants.MSG_AS_CONCEPT_NOTE)){
			tempCategory=IDocsConstants.MSG_AS_CONCEPT_NOTE_TEMPCODE;
			}else if (processNme.equals(IDocsConstants.MSG_AS_PLAN) || processNme.equals(IDocsConstants.MSG_AS_IMPLEMENTATION_PLAN)) {
				tempCategory=IDocsConstants.MSG_AS_IMPLEMENTATION_PLAN_TEMPCODE;
			}else if (processNme.equals(IDocsConstants.MSG_AS_COMPLETION)) {
				tempCategory=IDocsConstants.MSG_AS_COMPLETION_TEMPCODE;
			}else if (processNme.equals(IDocsConstants.MSG_AS_SUPERVISION)) {
				tempCategory=IDocsConstants.MSG_AS_SUPERVISION_TEMPCODE;
			}else if (processNme.equals(IDocsConstants.MSG_AS_DROPPAGE_NOTE) || processNme.equals(IDocsConstants.MSG_AS_DROPPAGE_MEMO)) {
				tempCategory=IDocsConstants.MSG_AS_DROPPAGE_NOTE_TEMPCODE;
			}else if (processNme.equals(IDocsConstants.MSG_AS_PDP_IMPL_PLAN)) {
				tempCategory=IDocsConstants.MSG_AS_PDP_IMPL_PLAN_TEMPCODE;
			}else if (processNme.equals(IDocsConstants.MSG_AS_PDP_SUPERVISION)) {
					tempCategory=IDocsConstants.MSG_AS_PDP_SUPERVISION_TEMPCODE;
			}else{
					tempCategory=EMPTY_STRING;
			}
		
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy~hh-mm-ss~a"); 
		StringBuffer strBuffer = new StringBuffer(servletBasicUrl);
		try {
			strBuffer.append("task=updatestatus&project_id=")
			.append(projectId)
			.append("&document_id=")
			.append(dfDocument.getObjectId().getId())
			.append("&document_version=")
			.append(dfDocument.getVersionLabel(0))
			.append("&workflow_id=")
			.append(workflowId)
			.append("&status=")
			.append("107")
			.append("&status_date=")
			.append(dateFormat.format(calendar.getTime()));
			if(tempCategory.equals("300")){
				strBuffer.append("&year=").append(financialYear).append("&quarter=").append(quater);
			}
			strBuffer.append("&temp_cat=")
			.append(tempCategory);
		}catch (Exception e) {
			DfLogger.error(IdocsUtil.class, "buildASServletWFUpdate() : EXCEPTION OCCURED " + e.getMessage(), null, null);
		}
		
	}

	public static boolean isActiveWorkflow(IDfWorkflow workflowObj) throws DfException{
		boolean isActive = false;
		
		int runtimeState = workflowObj.getRuntimeState();
		if(runtimeState == 0 || runtimeState == 1){
			isActive = true;
		}
		return isActive;
	}
	
		/**
	 * For As 
	 */
	public static Document canCreateServletCall(String project_id,IDfSession dfsess, String tempCategory) throws DfException {
		DfLogger.debug(IdocsUtil.class, " :: Project id::  " + project_id,null, null);
		String validateQry = getMessage("AS_TEMP_VALID_QRY");
		IDfQuery qryObj = new DfQuery();
		qryObj.setDQL(validateQry);
		String basicUrl = EMPTY_STRING;
		Document doc = null;
		IDfCollection validateColl = qryObj.execute(dfsess,IDfQuery.DF_CACHE_QUERY);
		try {
			while (validateColl.next()) {
				basicUrl = validateColl.getString("item_value");
				DfLogger.debug(IdocsUtil.class," :: Basic url ::  " + basicUrl, null, null);
			}
		} finally {
			if (validateColl != null) {
				validateColl.close();
			}
		}
		StringBuffer queryBuilder = new StringBuffer(basicUrl);
		queryBuilder.append("task=cancreate&temp_cat=").append(tempCategory)
				.append("&project_id=").append(project_id);
		DfLogger.debug(IdocsUtil.class, " :: Full servlet URL  "
				+ queryBuilder.toString(), null, null);
		try {
			URL urlObj = new URL(queryBuilder.toString());
			DocumentBuilderFactory buildFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = buildFactory.newDocumentBuilder();
			InputStream in = urlObj.openStream();
			doc = docBuilder.parse(in);
		} catch (Exception e) {
			DfLogger.error(IdocsUtil.class, ":: canCreateServletCall() : Exception Occured  "+ e.getMessage(), null, null);
		}
		return doc;
	}

	/**
	 * 
	 * @param collection
	 * @param strTargetAttr
	 * @return
	 */
	
	public static String getCommaSeparatedStrFromColl(IDfCollection collection, String strTargetAttr){
		StringBuffer strResult = new StringBuffer(IDocsConstants.MSG_EMPTY_STRING);
		try {
			while (collection.next()) {
				strResult = strResult.append(collection.getString(strTargetAttr)).append(IdocsConstants.MSG_COMMA);
			} 
			if (null != strResult && strResult.length() > 0) {
				strResult = strResult.deleteCharAt(strResult.length()-1);
			}

			DfLogger.debug(IDocDocbaseAttributeTagUtility.class," :: getCommaSeparatedStrFromColl: strResult After removing coma: " +
					strResult.toString(), null, null);
			DfLogger.debug(IdocsUtil.class,":: getCommaSeparatedStrFromColl: strResult After removing coma: " +strResult.toString(), null, null);
		} catch (DfException e) {
			DfLogger.error(IdocsUtil.class, " getCommaSeparatedStrFromColl :: Exception:" + e.getMessage(), null, null);
		} 
		return strResult.toString();
	}
	
	public static boolean isIFCDocsAdmin(IDfSession session ) {
		String admingGroupName = IdocsUtil.getMessage("MSG_IDOCS_ADMIN_GRP");
		DfLogger.debug(IdocsUtil.class, " :: MSG_IDOCS_ADMIN_GRP : "+admingGroupName, null, null);
		if(admingGroupName != null && admingGroupName.trim().length() > 0 
				&& IdocsUtil.isMemberOfGroup(admingGroupName,session)){
			DfLogger.debug(IdocsUtil.class, " :: validateUserPermissionsForEdit : IDocs Admin Found", null, null);
			return true;
		}else{
			return false;
		}
	}
	
	public static boolean isAdvisoryServicesWF(String workflowId,
			IDfSession dfsess) {
		boolean advisoryWf = false;
		String objectName = null;
		try {
			IDfWorkflow workflowObj = (IDfWorkflow) dfsess.getObject(new DfId(workflowId));
			objectName = workflowObj.getObjectName();
			DfLogger.debug(IdocsUtil.class," :: isAdvisoryServicesWF : workflow object Name : "+ objectName, null, null);
			if (objectName.startsWith(STR_PREF_AS) || objectName.startsWith(STR_PREFIX_SUB)) {
				advisoryWf = true;
			}
		} catch (DfException e) {
			e.printStackTrace();
		}
		DfLogger.debug(IdocsUtil.class," :: isAdvisoryServicesWF : advisoryWf : " + advisoryWf, null,null);
		return advisoryWf;
	}
	
	public static void updateAttributeAndchildDocDestination(IDfSession sess, IDfSysObject doc, IDfFolder targetIdFolder,String operationName,String hiddenFolder,String strExistedFolder) throws DfException {
    	String objectType = doc.getTypeName();
    	String objectName = doc.getObjectName();
    	NlsResourceBundle m_nlsResourceBundle = new NlsResourceBundle("org.ifc.idocs.clipboard.ClipboardErrorsNlsProp");
	    DfLogger.info(IdocsUtil.class, " :: execute Attributes : Type : "+objectType+" : ObjectName : "+objectName, null, null);
    	if(objectType.equals(IdocsConstants.PROJ_DOC_TYPE))
    	{
    		objectName=objectName.replaceFirst(doc.getString(IdocsConstants.PROJ_ID),targetIdFolder.getString(IdocsConstants.PROJ_ID));
    	}
    	else if(objectType.equals(IdocsConstants.INSTITUTION_DOC_TYPE))
    	{
    		objectName=objectName.replaceFirst(doc.getString(IdocsConstants.MSG_INSTITUTION_NBR),targetIdFolder.getString(IdocsConstants.MSG_INSTITUTION_NBR));
    	}
    	else
    	{
    		objectName=objectName.replaceFirst(doc.getString(IdocsConstants.COUNTRY_CODE),targetIdFolder.getString(IdocsConstants.COUNTRY_CODE));
    	}
    	doc.setString(IdocsConstants.OBJECT_NAME, objectName);
    	updateACL(sess, doc, targetIdFolder);
    	if(IdocsConstants.DOC_STATE_RELEASED.equals(doc.getString(m_nlsResourceBundle.getString("MSG_DOC_STATE", LocaleService.getLocale()))) == false){
    		doc.setString(m_nlsResourceBundle.getString("MSG_DOC_STATE", LocaleService.getLocale()),IdocsConstants.DOC_STATE_DRAFT);
    		if(operationName!=null && operationName.equals(IDocsConstants.IDOCS_COPY_OPERATION) == true){
    			doc.mark("0.1,CURRENT");
    		}
    	}
        doc.setString(m_nlsResourceBundle.getString(MSG_COUNTRY_NME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_COUNTRY_NME, LocaleService.getLocale())));
        doc.setString(m_nlsResourceBundle.getString(MSG_COUNTRY_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_COUNTRY_CODE, LocaleService.getLocale())));
        doc.setString(m_nlsResourceBundle.getString(MSG_CREATED_DATE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_CREATED_DATE, LocaleService.getLocale())));
        doc.setString(m_nlsResourceBundle.getString(MSG_REGION_NME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_REGION_NME, LocaleService.getLocale())));
        doc.setString(m_nlsResourceBundle.getString(MSG_REGION_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_REGION_CODE, LocaleService.getLocale())));
        doc.setString(m_nlsResourceBundle.getString(MSG_DOC_CATEGORY, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_FOLDER_CATEGORY", LocaleService.getLocale()))); 
        doc.setString(m_nlsResourceBundle.getString(MSG_AUTHOR_NAME, LocaleService.getLocale()), sess.getLoginUserName());
       
        /**
         * Changing destination of Email root virtual document child docs 
         */
        
        if(hiddenFolder != null && hiddenFolder.trim().length() >0 && !hiddenFolder.equals(IDocsConstants.BLANK_OBJECT_ID)){
        	doc.link(hiddenFolder);
        	doc.unlink(strExistedFolder);
        	DfLogger.info(IdocsUtil.class, "updateAttributeAndchildDocDestination :: "+strExistedFolder+" to "+hiddenFolder, null, null);
          }
        
        /**
         * End
         */
        if(doc.hasAttr(m_nlsResourceBundle.getString(MSG_IFCDOCS_AUTHOR_NAMES,LocaleService.getLocale()))==true 
        		&& doc.findString(m_nlsResourceBundle.getString(MSG_IFCDOCS_AUTHOR_NAMES,LocaleService.getLocale()), sess.getLoginUserName())== -1){
        	//doc.appendString(m_nlsResourceBundle.getString("MSG_IFCDOCS_AUTHOR_NAMES",LocaleService.getLocale()), sess.getLoginUserName());
        	doc.setRepeatingString(m_nlsResourceBundle.getString(MSG_IFCDOCS_AUTHOR_NAMES,LocaleService.getLocale()), 0, sess.getLoginUserName());
        }
        //set Project Document Attributes
        if(objectType.equals(IdocsConstants.PROJ_DOC_TYPE)){
        	DfLogger.info(IdocsUtil.class, "NewDocument :: onCommitChanges() : for Project Document",null,null);
            doc.setAuthors(0, sess.getLoginUserName());
//            doc.setString(m_nlsResourceBundle.getString("MSG_FILED_BY", LocaleService.getLocale()), sess.getLoginUserName());
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJECT_ID, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_PROJECT_ID, LocaleService.getLocale())));
//            doc.setBoolean(m_nlsResourceBundle.getString("MSG_BIZ_TEMPLATE", LocaleService.getLocale()), true);
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_STAGE_NAME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_STAGE_NAME", LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_STAGE_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_STAGE_NBR", LocaleService.getLocale())));
//            doc.setString(m_nlsResourceBundle.getString("MSG_PUBLISH_STATE", LocaleService.getLocale()), m_nlsResourceBundle.getString("MSG_PUBLISHED", LocaleService.getLocale()));
            doc.setString(m_nlsResourceBundle.getString(MSG_SUBJECT, LocaleService.getLocale()), doc.getObjectName());
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_SUBCATEGORY_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_PROJ_SUB_CATEGORY_CODE", LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_APPROVAL_NAME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_APPROVAL_PROC_NME", LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_APPROVAL_PROC_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_APPROVAL_PROC_CODE, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_SHORT_NAME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_PROJ_SHORT_NAME, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_NAME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_PROJ_NAME, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_CATEGORY_NAME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_PROJ_CATEGORY_NAME, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_CATEGORY_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_PROJ_CATEGORY_CODE, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_SUBCATEGORY_NAME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_PROJ_SUBCATEGORY_NAME, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_DEPT_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_DEPT_CODE, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_DEPT_NME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_DEPT_NME, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_SECTOR_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_SECTOR_CODE, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_SECTOR_NME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_SECTOR_NME, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_TIRE_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_PROJECT_TIRE_CODE", LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_TIER_NME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_PROJECT_TIER_NME", LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_ENV_CATEGORY_NME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_ENV_CATEGORY_NME, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_ENV_CATEGORY_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_ENV_CATEGORY_CODE, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_PROJ_STATUS_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_PROJ_STATUS_CODE, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_INSTIT_NBR, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_INSTIT_NBR, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_INSTITUTION_SHORT_NME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_INSTITUTION_SHORT_NME, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_DEPT_DIV_CODE, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_DEPT_DIV_CODE, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString(MSG_DEPT_DIV_NME, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_DEPT_DIV_NME, LocaleService.getLocale())));
        }
        //set Institution Document Attributes
        else if(objectType.equals(IdocsConstants.INSTITUTION_DOC_TYPE)){
        	DfLogger.info(IdocsUtil.class, "NewDocument :: onCommitChanges() : for Institution Document",null,null);
            doc.setString(m_nlsResourceBundle.getString(MSG_INSTIT_NBR, LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString(MSG_INSTIT_NBR, LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString("MSG_INSTIT_SHORT_NME", LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_INSTIT_SHORT_NME", LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString("MSG_INSTIT_LEGAL_NME", LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_INSTIT_LEGAL_NME", LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString("MSG_INSTIT_ROLE_TYPE_CODE", LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_INSTIT_ROLE_TYPE_CODE", LocaleService.getLocale())));
            doc.setString(m_nlsResourceBundle.getString("MSG_INSTIT_ROLE_TYPE_NME", LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_INSTIT_ROLE_TYPE_NME", LocaleService.getLocale())));
        }
        //set Country Document Attributes
        else if(objectType.equals(IdocsConstants.COUNTRY_DOC_TYPE)){
        	DfLogger.info(IdocsUtil.class, "NewDocument :: onCommitChanges() : for Country Document",null,null);
            doc.setString(m_nlsResourceBundle.getString("MSG_COUNTRY_LONG_NME", LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_COUNTRY_LONG_NME", LocaleService.getLocale())));
        }else{
        	DfLogger.info(IdocsUtil.class, "NewDocument :: onCommitChanges() : Invalid object Type",null,null);
        }
//        IDfTime currentTime = new DfTime();
//        doc.setTime(m_nlsResourceBundle.getString("MSG_DOC_DATE", LocaleService.getLocale()), currentTime);
//        doc.setString(m_nlsResourceBundle.getString("MSG_SEC_CLASS_CODE", LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_SEC_CLASS_CODE", LocaleService.getLocale())));
        doc.setString(m_nlsResourceBundle.getString("MSG_SEC_CLASS", LocaleService.getLocale()), targetIdFolder.getString(m_nlsResourceBundle.getString("MSG_SEC_CLASS", LocaleService.getLocale())));
        doc.save();
        DfLogger.info(IdocsUtil.class, " :: execute Attributes  Updated", null, null);
	}
	
	/**
	 * Purpose : To get The Single Attribute Value using A ChronicleId
	 * @param dfSession
	 * @param strObjectId
	 * @param attributeName
	 * @param strObjectTypeName
	 * @return
	 */
	public static String getSingleAttributeValueUsingChronicleId(IDfSession dfSession,String strObjectId, String attributeName, String strObjectTypeName){
		IDfCollection collection = null;
		String strAttributeValue  = null;
		try{
			if (attributeName != null && attributeName.trim().length() > 0
					&& strObjectTypeName != null && strObjectTypeName.trim().length() > 0 ) {
				String strQuery = new StringBuilder().append(MSG_SELECT).append(
						attributeName).append(" from ").append(strObjectTypeName)
						.append(" where i_chronicle_id='").append(strObjectId)
						.append(SINGLE_QUOTES).toString();
				DfLogger.info(IdocsUtil.class, " : getSingleAttributeValueUsingChronicleId() : Build Query ::"+strQuery, null, null);
				IDfQuery dfQuery = new DfQuery();
				dfQuery.setDQL(strQuery);
				collection = dfQuery.execute(dfSession, IDfQuery.DF_READ_QUERY);
				while (collection.next()) {
					strAttributeValue = collection.getString(attributeName);
				}
			}
		}catch (Exception e) {
			DfLogger.error(IdocsUtil.class, " : getSingleAttributeValue() : Exception "+e.getMessage(), null, null);			
		}finally{
			try {if(collection!=null) {collection.close();}
			} catch (DfException e) {e.printStackTrace();}
		}
		return strAttributeValue;
	}

	/**
	 * To Get the Advisory Services Template Code Value 
	 * @param strTemplateName
	 * @return
	 */
	public static String getTemplateCategoryCode(String strTemplateName) {
		if(strTemplateName.equals(IDocsConstants.MSG_AS_CONCEPT_NOTE)){
			return IDocsConstants.MSG_AS_CONCEPT_NOTE_TEMPCODE;
		}else if (strTemplateName.equals(IDocsConstants.MSG_AS_PLAN) || strTemplateName.equals(IDocsConstants.MSG_AS_IMPLEMENTATION_PLAN)) {
			return IDocsConstants.MSG_AS_IMPLEMENTATION_PLAN_TEMPCODE;
		}else if (strTemplateName.equals(IDocsConstants.MSG_AS_COMPLETION)) {
			return IDocsConstants.MSG_AS_COMPLETION_TEMPCODE;
		}else if (strTemplateName.equals(IDocsConstants.MSG_AS_SUPERVISION)) {
			return IDocsConstants.MSG_AS_SUPERVISION_TEMPCODE;
		}else if (strTemplateName.equals(IDocsConstants.MSG_AS_DROPPAGE_NOTE) || strTemplateName.equals(IDocsConstants.MSG_AS_DROPPAGE_MEMO)) {
			return IDocsConstants.MSG_AS_DROPPAGE_NOTE_TEMPCODE;
		}else if (strTemplateName.equals(IDocsConstants.MSG_AS_PDP_IMPL_PLAN)) {
			return IDocsConstants.MSG_AS_PDP_IMPL_PLAN_TEMPCODE;
		}else if (strTemplateName.equals(IDocsConstants.MSG_AS_PDP_SUPERVISION)) {
			return IDocsConstants.MSG_AS_PDP_SUPERVISION_TEMPCODE;
		}else{
			return EMPTY_STRING;
		}
	}
	
	/**
	 * Purpose : To get required attributes info from doc Object {doc_state,
	 															  sec_classification_code,
	 															  isworkflowrequired,
	 															  owner_name,
	  															  r_lock_owner,
	 															  object_name,
	  															  template_code,
	 															  r_object_type}  
	 * @param strObjectId
	 * @param dfSession
	 * 
	 */
	
	public static HashMap<String, String> getRequiredAttributesValues(String strObjectId,IDfSession dfSession){
		String docDetailsQuery=getMessage("QRY_GET_DOC_DETAILS");
		docDetailsQuery=docDetailsQuery.replace(STR_REPLACE_OBJECT_ID, strObjectId);
		IDfCollection dfCollection=null;
		HashMap<String, String> valuesMap = new HashMap<String, String>(); 
		//doc_state,sec_classification_code,isworkflowrequired,owner_name,r_lock_owner,object_name,template_code,r_object_type
		try {
			dfCollection=executeQuery(dfSession, docDetailsQuery, IDfQuery.DF_READ_QUERY);
			while(dfCollection.next()){
				valuesMap.put(IDocsConstants.MSG_R_OBJECT_TYPE,dfCollection.getString(IDocsConstants.MSG_R_OBJECT_TYPE));
				valuesMap.put(IDocsConstants.MSG_OBJECT_NAME,dfCollection.getString(IDocsConstants.MSG_OBJECT_NAME));
				valuesMap.put(IDocsConstants.MSG_DOC_STATE,dfCollection.getString(IDocsConstants.MSG_DOC_STATE));
				valuesMap.put(IDocsConstants.MSG_OWNER_NAME,dfCollection.getString(IDocsConstants.MSG_OWNER_NAME));
				valuesMap.put(IDocsConstants.MSG_TEMPLATE_CODE,dfCollection.getString(IDocsConstants.MSG_TEMPLATE_CODE));
				valuesMap.put(IDocsConstants.MSG_IS_WORKFLOW_REQUIRED,dfCollection.getString(IDocsConstants.MSG_IS_WORKFLOW_REQUIRED));
				valuesMap.put(IDocsConstants.MSG_R_LOCK_OWNER,dfCollection.getString(IDocsConstants.MSG_R_LOCK_OWNER));
				valuesMap.put(IDocsConstants.MSG_SEC_CLASSIFICATION_CODE,dfCollection.getString(IDocsConstants.MSG_SEC_CLASSIFICATION_CODE));
				} 
			if(dfCollection!=null)
					dfCollection.close();
			
		} catch (DfException e) {
			DfLogger.debug(IdocsUtil.class, "<< Exception block >>"+e.getMessage(), null,null);
		}
		return valuesMap;
		}
	
	private static final String MSG_SELECT = "select ";		
	private static String STR_REPLACE_OBJECT_ID="<objectId>"; 
}