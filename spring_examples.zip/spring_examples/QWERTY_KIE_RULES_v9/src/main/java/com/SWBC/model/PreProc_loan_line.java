package com.SWBC.model;

public class PreProc_loan_line {

	private String tid;
	private String loan_no;
	private String loan_suffix;
	private String cov_type;
	private String acc_no;
	
	
	public String getTid() {
		return tid;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public String getLoan_no() {
		return loan_no;
	}
	public void setLoan_no(String loan_no) {
		this.loan_no = loan_no;
	}
	public String getLoan_suffix() {
		return loan_suffix;
	}
	public void setLoan_suffix(String loan_suffix) {
		this.loan_suffix = loan_suffix;
	}
	public String getCov_type() {
		return cov_type;
	}
	public void setCov_type(String cov_type) {
		this.cov_type = cov_type;
	}
	public String getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(String acc_no) {
		this.acc_no = acc_no;
	}
	
}
