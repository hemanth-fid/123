
package org.ifc.idocs.forms.adaptors;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.documentum.fc.common.DfLogger;
import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.IAdaptorParameter;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.xforms.engine.adaptor.datasource.ISetValueAdaptor;

public class SetClearanceDateValidationFlag implements ISetValueAdaptor {

	public Object execute(IAdaptorParameter[] parameters)
			throws AdaptorException {
		DfLogger.info(this,"SetClearanceDateValidationFlag:: SetClearanceDateValidationFlag",null,null);
		boolean errorValue = true;
		if (parameters.length == 1) {
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			IAdaptorParameter parameter = parameters[0];
			Date dateOfClearance = null;
			Date now = new Date();

				if (parameter != null && parameter.getValue().length() > 0) {
				try {
					dateOfClearance = dateFormat.parse(parameter.getValue());

				} catch (java.text.ParseException e) {
					DfLogger.error(this,": <<Exception>> : "+e.getMessage(),null,e);
				}

				if (dateOfClearance.after(now))
					errorValue = false;
			}
		}
		return errorValue;
	}

	public void destroy() throws AdaptorException {
	}

	public void init(IAdaptorConfiguration arg0) throws AdaptorException {
	}
}