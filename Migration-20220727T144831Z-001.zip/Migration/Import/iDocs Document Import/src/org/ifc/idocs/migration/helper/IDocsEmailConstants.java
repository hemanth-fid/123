package org.ifc.idocs.migration.helper;

public class IDocsEmailConstants {

	// document types
	static final String PROJECT_DOC_TYPE = "idocs_project_doc";
	static final String PARTNER_DOC_TYPE = "idocs_institution_doc";
	// Email Aspect type Attributes
	static final String EMAIL_ASPECT_NME = "idocs_email_doc_aspect";
	
	static final String EMAIL_ASPECT_DOC_TYPE_ATTR = "idocs_email_doc_aspect.idocs_email_doc_type";
	static final String EMAIL_ASPECT_RECD_DT_ATTR = "idocs_email_doc_aspect.idocs_email_received_date";
	static final String EMAIL_ASPECT_MSG_ID_ATTR = "idocs_email_doc_aspect.idocs_email_message_id";
	static final String EMAIL_ASPECT_SENT_FROM_ATTR = "idocs_email_doc_aspect.idocs_email_sent_from";
	
	static final String EMAIL_ASPECT_SENT_TO_ATTR = "idocs_email_doc_aspect.idocs_email_sent_to_list";
	static final String EMAIL_ASPECT_CC_TO_ATTR = "idocs_email_doc_aspect.idocs_email_cc_list";
		
	static final String DOC_TYPE_ATTR = "doc_type";
	static final String RECD_DT_ATTR = "email_received_date";
	static final String MSG_ID_ATTR = "orig_doc_unique_id";
	
	static final String SENT_FROM_ATTR = "email_from";
	static final String SENT_TO_ATTR = "email_to";
	static final String CC_TO_ATTR = "email_cc";
	
	// Scanning Aspect type attributes
	static final String SCANNING_ASPECT_NME = "idocs_scanning_doc_aspect";
	static final String SCANNING_ASPECT_SENDER_IP_ATTR = "idocs_scanning_doc_aspect.ifc_inputsender_ip";
	static final String SCANNING_ASPECT_SENDER_HOST_ATTR = "idocs_scanning_doc_aspect.ifc_inputsender_host";
	static final String SCANNING_ASPECT_INPUT_TYPE_ATTR = "idocs_scanning_doc_aspect.ifc_inputtype";
	
}
