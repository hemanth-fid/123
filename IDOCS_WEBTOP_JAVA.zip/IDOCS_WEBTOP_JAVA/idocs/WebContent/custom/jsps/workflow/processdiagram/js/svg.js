var lastSelectedItem = null;
function displayInstanceData(evt, elObj, _flag)
{
xm=evt.getClientX();ym=evt.getClientY();
svgdoc=evt.getTarget().getOwnerDocument();
root=svgdoc.getElementById("svgROOT");
scale=root.currentScale;
oProp = svgdoc.getElementById("instanceProp");
oPropBox = svgdoc.getElementById("instancePropBox");
oDummy = svgdoc.getElementById("dummy");
var sStartTime = null;
var sEndTime = null;
var sDuration = null;
var elInstance = elObj.getElementsByTagName("instance").item(0);
if (elInstance)
{
var dotPosition = 0;
sStartTime = elInstance.getAttribute("startTime");
dotPosition = sStartTime.indexOf('.', 0);
if (dotPosition > 0)
sStartTime = sStartTime.substr(0, dotPosition);
sEndTime   = elInstance.getAttribute("endTime");
dotPosition = sEndTime.indexOf('.', 0);
if (dotPosition > 0)
sEndTime = sEndTime.substr(0, dotPosition);
sDuration  = elInstance.getAttribute("duration");
dotPosition = sDuration.indexOf('.', 0);
if (dotPosition > 0)
sDuration = sDuration.substr(0, dotPosition);
}
if (_flag == 1 && elInstance)
{
if(sStartTime == null)
{
sStartTime = 'N/A';
}
if(sEndTime == null || sEndTime.search("1970-01-01") >= 0)
{
sEndTime = 'N/A';
}
if(sDuration == null || sDuration == '0')
{
sDuration = 'N/A';
}
var lblWidth = 0;
if (sStartTime.length >= sEndTime.length)
{
if(sStartTime.length > sDuration.length)
{
if(oDummy.getFirstChild() != null)
{
oDummy.getFirstChild().setData(sStartTime);
}
lblWidth = svgdoc.getElementById("startTimeLbl").getComputedTextLength();
}
else
{
if(oDummy.getFirstChild() != null)
{
oDummy.getFirstChild().setData(sDuration);
}
lblWidth = svgdoc.getElementById("durationLbl").getComputedTextLength();
}
}
else if (sEndTime.length > sDuration.length)
{
if(oDummy.getFirstChild() != null)
{
oDummy.getFirstChild().setData(sEndTime);
}
lblWidth = svgdoc.getElementById("endTimeLbl").getComputedTextLength();
}
else
{
if(oDummy.getFirstChild() != null)
{
oDummy.getFirstChild().setData(sDuration);
}
lblWidth = svgdoc.getElementById("durationLbl").getComputedTextLength();
}
var fontSize = 12;
var width = lblWidth + oDummy.getComputedTextLength();
_scale = 1/scale;
tx=root.currentTranslate.x;
ty=root.currentTranslate.y;
xsvg=(xm-tx)*_scale;
ysvg=(ym-ty)*_scale;
if (sDuration == 'N/A')
{
oPropBox.setAttribute('height', 35);
svgdoc.getElementById('durationGrp').setAttribute("visibility","hidden");
}
else
{
oPropBox.setAttribute('height', 50);
svgdoc.getElementById('durationGrp').setAttribute("visibility","visible");
if (svgdoc.getElementById('duration').getFirstChild() != null)
{
svgdoc.getElementById('duration').getFirstChild().setData(sDuration);
}
}
if(svgdoc.getElementById('startTime').getFirstChild() != null)
{
svgdoc.getElementById('startTime').getFirstChild().setData(sStartTime);
}
if (svgdoc.getElementById('endTime').getFirstChild() != null)
{
svgdoc.getElementById('endTime').getFirstChild().setData(sEndTime);
}
oPropBox.setAttribute('width', 0 + width * 1.5);
oProp.setAttribute("visibility","visible");
oProp.setAttribute('transform', 'translate('+(xsvg+5*_scale)+' '+(ysvg+5*_scale)+') scale('+ _scale+')');
}
else
{
svgdoc.getElementById('durationGrp').setAttribute("visibility","hidden");
oProp.setAttribute("visibility","hidden");
}
}
function showProperty(evt, sEntityType, sName, sCondition, _flag)
{
xm=evt.getClientX();ym=evt.getClientY();
svgdoc=evt.getTarget().getOwnerDocument();
root=svgdoc.getElementById("svgROOT");
scale=root.currentScale;
oProp = svgdoc.getElementById("property");
oPropBox = svgdoc.getElementById("propertyBox");
if (_flag == 1)
{
if(sEntityType == null)
{
sEntityType = 'N/A';
}
if(sName == null)
{
sName = 'N/A';
}
if(sCondition == null)
{
sCondition = 'N/A';
}
var fontSize = 12;
var width = 0;
if (sEntityType.length > sName.length)
{
if(sEntityType.length > sCondition.length)
{
width = sEntityType.length;
}
else
{
width = sCondition.length;
}
}
else if (sName.length > sCondition.length)
{
width = sName.length;
}
else
{
width = sCondition.length;
}
_scale = 1/scale;
tx=root.currentTranslate.x;
ty=root.currentTranslate.y;
xsvg=(xm-tx)*_scale;
ysvg=(ym-ty)*_scale;
if (sCondition == 'N/A')
{
oPropBox.setAttribute('height', 35);
svgdoc.getElementById('conditionGrp').setAttribute("visibility","hidden");
}
else
{
oPropBox.setAttribute('height', 50);
svgdoc.getElementById('conditionGrp').setAttribute("visibility","visible");
if (svgdoc.getElementById('condition').getFirstChild() != null)
{
svgdoc.getElementById('condition').getFirstChild().setData(sCondition);
}
}
if(svgdoc.getElementById('eType').getFirstChild() != null)
{
svgdoc.getElementById('eType').getFirstChild().setData(sEntityType);
}
if (svgdoc.getElementById('name').getFirstChild() != null)
{
svgdoc.getElementById('name').getFirstChild().setData(sName);
}
oPropBox.setAttribute('width', 70 + fontSize/2 * width);
oProp.setAttribute("visibility","visible");
oProp.setAttribute('transform', 'translate('+(xsvg+20*_scale)+' '+(ysvg+20*_scale)+') scale('+ _scale+')');
}
else
{
svgdoc.getElementById('conditionGrp').setAttribute("visibility","hidden");
oProp.setAttribute("visibility","hidden");
}
}
function showPosition(evt, _flag)
{
xm=evt.getClientX();ym=evt.getClientY();
svgdoc=evt.getTarget().getOwnerDocument();
root=svgdoc.getElementById("svgROOT");
scale=root.currentScale;
oPosition = svgdoc.getElementById("position");
if (_flag == 1)
{
_scale = 1/scale;
tx=root.currentTranslate.x;
ty=root.currentTranslate.y;
xsvg=Math.round((xm-tx)*_scale);
ysvg=Math.round((ym-ty)*_scale);
oPosition.setAttribute("visibility","visible");
oPosition.setAttribute('transform', 'translate('+(xsvg+20*_scale)+' '+(ysvg+20*_scale)+') scale('+ _scale+')');
svgdoc.getElementById('svgPoint').getFirstChild().setData('SVG Position: '+xm+' '+ym);
svgdoc.getElementById('viewBoxPoint').getFirstChild().setData('ViewBox Position: '+xsvg+' '+ysvg);
svgdoc.getElementById('translation').getFirstChild().setData('Current Translate: '+tx+' '+ty);
svgdoc.getElementById('scale').getFirstChild().setData('Current Scale: '+scale);
}
else
{
oPosition.setAttribute("visibility","hidden");
}
}
function notifyPortal(evt, _id, sKey)
{
var target = evt.target;
var doc = target.getOwnerDocument();
var root = doc.getElementById("svgROOT");
var obj = doc.getElementById(_id);
if(lastSelectedItem != null)
{
lastSelectedItem.setAttribute('class', 'fil-black fnt100');
}
lastSelectedItem = obj;
obj.setAttribute('class', 'fil-blue stroke-blue fnt700');
var nItemId = -1;
var sEType = "";
var nLevelId = -1;
var nProjectId = -1;
var sType = "";
if (obj.getElementsByTagName("itemId").item(0) != null)
{
nItemId = obj.getElementsByTagName("itemId").item(0).getFirstChild().nodeValue;
}
if (obj.getElementsByTagName("projectId").item(0) != null)
{
nProjectId = obj.getElementsByTagName("projectId").item(0).getFirstChild().nodeValue;
}
if (obj.getElementsByTagName("entityType").item(0) != null)
{
sEType = obj.getElementsByTagName("entityType").item(0).getFirstChild().nodeValue;
}
if (obj.getElementsByTagName("subType").item(0) != null)
{
sType = obj.getElementsByTagName("subType").item(0).getFirstChild().nodeValue;
}
var levelId = obj.getElementsByTagName("levelId");
if (levelId != null && levelId.item(0) != null && levelId.item(0).getFirstChild())
nLevelId = levelId.item(0).getFirstChild().nodeValue;
var name = "";
if (obj.getElementsByTagName("NAME").item(0) != null)
{
name = obj.getElementsByTagName("NAME").item(0).getFirstChild().nodeValue;
}
var instanceItemId = "";
var instanceElement = obj.getElementsByTagName("instance").item(0);
if (instanceElement)
{
instanceItemId = instanceElement.getAttribute("activityId");
}
if (evt.detail == 2)
{
if (top.location != self.location)
{
parent.handleDblClkSVGAction(nItemId, nProjectId, nLevelId, sEType);
}
else if (true)
{
if (sKey == "ALERT"){
handleDblClkOnAlert(nItemId, nProjectId, nLevelId, sEType, name, instanceItemId);
}
else{
handleDblClk(sKey, nItemId, nProjectId, nLevelId, sEType, name);
}
}
else {
handleDblClkSVGAction(nItemId, nProjectId, nLevelId, sEType, name);
}
}
else
{
if ( top.location != self.location)
{
if (parent != null){
parent.handleClkSVGAction(nItemId, nProjectId, nLevelId, sEType, name, sType);
}
}
else if (true)
{
if (sKey == "ALERT"){
handleClkOnAlert(nItemId, nProjectId, nLevelId, sEType, name, instanceItemId);
}
else{
handleClk(sKey, nItemId, nProjectId, nLevelId, sEType, name);
}
}
else {
handleClkSVGAction(nItemId, nProjectId, nLevelId, sEType, name);
}
}
evt.stopPropagation();
evt.preventDefault();
}
function updateTip(oTarget,show,sText,x,y, xOffset, yOffset)
{
var SVGDoc = oTarget.getOwnerDocument();
var root = SVGDoc.getElementById("svgROOT");
var oToolTip = SVGDoc.getElementById("toolTip");
var scale=root.currentScale;
var _scale = 1/scale;
var tx=root.currentTranslate.x;
var ty=root.currentTranslate.y;
var xsvg=(x-tx)*_scale;
var ysvg=(y-ty)*_scale;
if (show)
{
var toolTipText1 = SVGDoc.getElementById("toolTipText1");
var toolTipText2 = SVGDoc.getElementById("toolTipText2");
var oText1 = toolTipText1.getFirstChild();
var oText2 = toolTipText2.getFirstChild();
oText1.setData(sText);
oText2.setData(sText);
oToolTip.setAttribute('transform', 'translate('+(xsvg+xOffset*_scale)+' '+(ysvg+yOffset*_scale)+') scale('+ _scale+')');
oToolTip.setAttribute("visibility","visible");
}
else {
oToolTip.setAttribute("visibility","hidden");
}
}
function highlightGridOn(evt, _id, _fillColor, _showText)
{
var target = evt.target;
var doc = target.getOwnerDocument();
var root = doc.getElementById("svgROOT");
var obj = doc.getElementById(_id);
obj.setAttribute('style', 'stroke:rgb(0,0,0);stroke-width:.5;fill-opacity:0.5;fill:'+_fillColor);
if (_showText == 1)
{
var oTitle = obj.getElementsByTagName("text").item(0);
var sTitle = oTitle.getFirstChild().nodeValue;
updateTip(obj,true,sTitle,evt.getClientX(),evt.getClientY(), 10, 20);
}
else
{
updateTip(obj,false);
}
evt.stopPropagation();
evt.preventDefault();
}
function highlightLinkOn(evt, _id, showDesc, cssName)
{
var target = evt.target;
var doc = target.getOwnerDocument();
var root = doc.getElementById("svgROOT");
var obj = doc.getElementById(_id);
if (showDesc > 0)
{
obj.setAttribute('class', cssName);
var oTitle = obj.getElementsByTagName("desc").item(0);
if(oTitle != null)
{
var oTitleNode = oTitle.getFirstChild();
if(oTitleNode != null)
{
var sTitle = oTitleNode.nodeValue;
updateTip(obj,true,sTitle,evt.getClientX(),evt.getClientY(), 10, 20);
}
}
}
else
{
obj.setAttribute('class', cssName);
updateTip(obj,false);
}
evt.stopPropagation();
evt.preventDefault();
}
function highlightItemOn(evt, _id, _x, _y, _color, _zoomFactor, _showProperties)
{
var target = evt.target;
var doc = target.getOwnerDocument();
var root = doc.getElementById("svgROOT");
var obj = doc.getElementById(_id);
var sEType = null;
var sName = null;
var sCondition = null;
if (_zoomFactor > 1)
{
if (!useAlerts && useIcons)
{
_x -=imgHeigh * imgScaleX;
_y -=imgWidth * imgScaleY;
}else
{
_x -= iHeigh/2 * iScaleX;
_y -= iWidth/2 * iScaleY;
}
var oEType = obj.getElementsByTagName("ETNAME").item(0);
sEType = oEType.getFirstChild().nodeValue;
var oName = obj.getElementsByTagName("NAME").item(0);
sName = oName.getFirstChild().nodeValue;
var oCondition = obj.getElementsByTagName("CONDITION").item(0);
if (oCondition != null && oCondition.getFirstChild() != null)
sCondition = oCondition.getFirstChild().nodeValue;
var oCondition = obj.getElementsByTagName("CONDITION").item(0);
if (oCondition != null && oCondition.getFirstChild() != null)
sCondition = oCondition.getFirstChild().nodeValue;
if (_showProperties > 0){
displayInstanceData(evt, obj, 1);
}
}
else
{
displayInstanceData(evt, obj, 0);
}
if (zoomOnHighLight>0)
{
obj.setAttribute('transform', 'translate('+_x+' '+_y+') scale('+ _zoomFactor+')');
}
evt.stopPropagation();
evt.preventDefault();
}
