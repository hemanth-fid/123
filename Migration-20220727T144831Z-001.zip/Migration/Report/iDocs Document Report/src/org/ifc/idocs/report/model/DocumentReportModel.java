package org.ifc.idocs.report.model;

public class DocumentReportModel {
	
	private String reportUtilityCode;
	private String folderValueCode;
	private String folderTypeCode;
	private Integer sourceDocCnt;
	private Double sourceDocSizeNbr;
	private Integer targetDocCnt;
	private Double targetDocSizeNbr;
	private Integer extractDocCnt;
	private Double extractDocSizeNbr;
	private String regionName;
	private String projectCategoryNameCode;
	
	public DocumentReportModel(){}
	
	public DocumentReportModel(DocumentReportModel drm){
		this.reportUtilityCode = drm.reportUtilityCode;
		this.folderValueCode = drm.folderValueCode;
		this.folderTypeCode = drm.folderTypeCode;		
		this.sourceDocCnt = drm.sourceDocCnt;
		this.sourceDocSizeNbr = drm.sourceDocSizeNbr;
		this.targetDocCnt = drm.targetDocCnt;
		this.targetDocSizeNbr = drm.targetDocSizeNbr;
		this.extractDocCnt = drm.extractDocCnt;
		this.extractDocSizeNbr = drm.extractDocSizeNbr;
	}
	
	public String getFolderValueCode() {
		return folderValueCode;
	}
	public void setFolderValueCode(String folderValueCode) {
		this.folderValueCode = folderValueCode;
	}
	public String getFolderTypeCode() {
		return folderTypeCode;
	}
	public void setFolderTypeCode(String folderTypeCode) {
		this.folderTypeCode = folderTypeCode;
	}
	public String getReportUtilityCode() {
		return reportUtilityCode;
	}
	public void setReportUtilityCode(String reportUtilityCode) {
		this.reportUtilityCode = reportUtilityCode;
	}
	public Integer getSourceDocCnt() {
		return sourceDocCnt;
	}
	public void setSourceDocCnt(Integer sourceDocCnt) {
		this.sourceDocCnt = sourceDocCnt;
	}
	public Double getSourceDocSizeNbr() {
		return sourceDocSizeNbr;
	}
	public void setSourceDocSizeNbr(Double sourceDocSizeNbr) {
		this.sourceDocSizeNbr = sourceDocSizeNbr;
	}
	public Integer getTargetDocCnt() {
		return targetDocCnt;
	}
	public void setTargetDocCnt(Integer targetDocCnt) {
		this.targetDocCnt = targetDocCnt;
	}
	public Double getTargetDocSizeNbr() {
		return targetDocSizeNbr;
	}
	public void setTargetDocSizeNbr(Double targetDocSizeNbr) {
		this.targetDocSizeNbr = targetDocSizeNbr;
	}
	public Integer getExtractDocCnt() {
		return extractDocCnt;
	}
	public void setExtractDocCnt(Integer extractDocCnt) {
		this.extractDocCnt = extractDocCnt;
	}
	public Double getExtractDocSizeNbr() {
		return extractDocSizeNbr;
	}
	public void setExtractDocSizeNbr(Double extractDocSizeNbr) {
		this.extractDocSizeNbr = extractDocSizeNbr;
	}
	public String getRegionName() {
		return regionName;
	}
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	public String getProjectCategoryNameCode() {
		return projectCategoryNameCode;
	}
	public void setProjectCategoryNameCode(String projectCategoryNameCode) {
		this.projectCategoryNameCode = projectCategoryNameCode;
	}
}
