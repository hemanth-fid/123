package org.ifc.idocs.migration.updateReferences;

import org.ifc.idocs.migration.helper.Utilities;
import org.ifc.idocs.migration.importUtility.ImportUtility;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.common.DfException;
/**
 * UpdateCRRPSR - Updating CRR/PSR databases. 
 * @author HAnuganti
 * 
 * #############################################################################################
 * Author		            DateofChange	 Version	  ModificationHistory
 * ###########################################################################################
 * Hemachandra Anuganti 
 * ###########################################################################################
 * 
 */
public class UpdateCRRPSR extends ImportUtility {

	public static void updateCRRPSRdrls() {
		// TODO Auto-generated method stub

		// Select UTILITY Schema for updating iDocs DRLs
		try {
			IDfCollection collection = Utilities.executeQuery(dfSession, idocsProperties.getProperty("MSG_CRR_PSR_DOC_QUERY"), DfQuery.EXECREAD_QUERY);
			while (collection.next()) {
				String dominoID = collection.getString("document_id");
				String selectQuery = idocsProperties.getProperty("MSG_CRR_PSR_DOC_SELECT");
				selectQuery = selectQuery.replaceFirst("<orig_doc_id>",dominoID);
				IDfDocument document = (IDfDocument) dfSession.getObjectByQualification(selectQuery);
				if (document != null) {
					if (updateDRLdb(document.getString("r_object_id"), dominoID))
						importDocLogger
								.info("calling updateDRLdb function updateDRLdb");
					{
						updateAttachmentDb(document.getString("r_object_id"),
								dominoID);
						importDocLogger
								.info("calling updateDRLdb function updateAttachmentDb");
					}
				}
				/*
				 * collection1 = dfquery.execute(dfSession,
				 * dfquery.EXECREAD_QUERY); if(collection1 != null &&
				 * collection1.next()){ collection1.getString("r_object_id"); }
				 */
			}//
			if (collection != null){
				collection.close();
				collection = null;
			}
		} catch (DfException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			importDocLogger.warning("Catch block ::   Dfexception" + e.getMessage());
		} 

	}

	private static void updateAttachmentDb(String r_object_id, String dominoID) {
		// TODO Auto-generated method stub

		IDfCollection collection4 = null;
		String objectID = r_object_id;
		String domDocID = dominoID;
		String updateAttchments = idocsProperties.getProperty("MSG_CRR_PSR_ATTACHMENT_QUERY");
		updateAttchments = updateAttchments.replaceFirst("<objectID>", objectID);
		updateAttchments = updateAttchments.replaceFirst("<objectID>", objectID);
		updateAttchments = updateAttchments.replaceFirst("<domDocID>", domDocID);

		//importDocLogger.info("Query String::" + updateAttchments);
		try {
			collection4 = Utilities.executeQuery(dfSession, updateAttchments, DfQuery.EXECREAD_QUERY);
		} catch (DfException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			importDocLogger.warning("Catch block ::   Dfexception" + e.getMessage());
		} finally {
			if (collection4 != null) {
				try {
					collection4.close();
					collection4 = null;
				} catch (DfException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					importDocLogger.warning("Catch block ::   Dfexception" + e.getMessage());
				}
			}
		}
	}

	private static boolean updateDRLdb(String r_object_id, String dominoID) {
		// TODO Auto-generated method stub
		IDfCollection collection3 = null;
		String objectID = r_object_id;
		String domDocID = dominoID;

		String updatedrl = idocsProperties.getProperty("MSG_CRR_PSR_UPDATE_QUERY");
		updatedrl = updatedrl.replaceFirst("<objectID>", objectID);
		updatedrl = updatedrl.replaceFirst("<document_version_nbr>", objectID);
		updatedrl = updatedrl.replaceFirst("<url_text>", idocsProperties.getProperty("MSG_CRR_PSR_DRL"));
		updatedrl = updatedrl.replaceFirst("<domDocID>", domDocID);
		updatedrl = updatedrl.replaceFirst("<r_object_id>", objectID);
		//importDocLogger.info("Query String::" + updatedrl);
		try {
			collection3 = Utilities.executeQuery(dfSession, updatedrl, DfQuery.EXECREAD_QUERY);
			return true;
		} catch (DfException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			importDocLogger.warning("Catch block ::   Dfexception" + e.getMessage());
			return false;
		} finally {
			if (collection3 != null) {
				try {
					collection3.close();
					collection3 = null;
				} catch (DfException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					importDocLogger.warning("Catch block ::   Dfexception" + e.getMessage());
				}
			}
		}
	}

}
