package org.ifc.idocs.workflow.taskmanager;

import com.documentum.webcomponent.library.workflow.taskmanager.FailedAutoTaskActionPrecondition;
import com.documentum.fc.client.IDfWorkitem;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.services.workflow.inbox.IWorkflowTask;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;


public class IDocsFailedAutoTaskActionPrecondition extends
		FailedAutoTaskActionPrecondition {
	public IDocsFailedAutoTaskActionPrecondition()
    {
    }
	
	
    public boolean queryExecute(String strAction, IConfigElement config, ArgumentList args, Context context, Component component)
    {
    	DfLogger.info(this, " :: IDocsFailedAutoTaskActionPrecondition : queryExecute ",null,null);
    
    	boolean bExecute = false;
        String strIsFailedAutoTask;
        String strCanCompleteTask;
        try
        {
	        IWorkflowTask task = getWorkflowTask(component, args.get("objectId"));
	        DfLogger.info(this, " :: IDocsFailedAutoTaskActionPrecondition : queryExecute  ::"+task.getObjectId().toString(),null,null);
	        int rerunTaskpreconditiontaskState = task.getTaskState();
	        DfLogger.info(this, " :: IDocsFailedAutoTaskActionPrecondition : rerunTaskpreconditiontaskState  :: "+rerunTaskpreconditiontaskState,null,null);
	        IDfWorkitem witem = (IDfWorkitem)component.getDfSession().getObject(task.getItemId());
	        String taskOwner = witem.getPerformerName();
	        DfLogger.info(this, " :: IDocsFailedAutoTaskActionPrecondition : taskOwner  :: "+taskOwner,null,null);
	        if(checkPausedStatus(rerunTaskpreconditiontaskState) && taskOwner!=null && taskOwner.trim().length() > 0 && (taskOwner.equals(component.getDfSession().getLoginUserName()) || taskOwner.equals(component.getDfSession().getDocbaseOwnerName()))){
	        	DfLogger.info(this, " :: IDocsFailedAutoTaskActionPrecondition : custom condition to enable rerunbutton",null,null);  
	        	bExecute = true;
	        }else  if((strCanCompleteTask = args.get("canCompleteTask")) != null && strCanCompleteTask.length() > 0 && (strIsFailedAutoTask = args.get("isFailedAutoTask")) != null && strIsFailedAutoTask.length() > 0)
	            bExecute = Boolean.valueOf(strCanCompleteTask).booleanValue() && Boolean.valueOf(strIsFailedAutoTask).booleanValue();
	        else{
	                bExecute = canCompleteTask(task) && task.isFailedAutoTask();
	            }
        }catch(DfException e){
                throw new WrapperRuntimeException(e);
            }
        DfLogger.info(this, " :: IDocsFailedAutoTaskActionPrecondition :rerun enble status"+bExecute,null,null);
        return bExecute;
    }

    public String[] getRequiredParams()
    {
        return (String[])s_requiredParams.clone();
    }

    private boolean checkPausedStatus(int rerunTaskpreconditiontaskState){
       if(rerunTaskpreconditiontaskState == PAUSED || rerunTaskpreconditiontaskState == A_PAUSED || rerunTaskpreconditiontaskState == D_PAUSED || rerunTaskpreconditiontaskState == P_PAUSED)
    	   return true;
       else return false;
    }
    
    private static final String s_requiredParams[] = {
        "objectId"
    };
    
    //private String STR_RETURN_VALUE= "return_value";
    private int PAUSED=3;
    private int D_PAUSED=4;
    private int A_PAUSED=5;
    private int P_PAUSED=6;
}