/**
* This component class used to update Location, 
* Object Type and Catalog search fields in advance search screen.
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* GVennapusa			03/02/2011		1.0				created
* #######################################################################################################
*/
package org.ifc.idocs.search;

import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.LocaleService;

public class SearchInfo extends com.documentum.webcomponent.library.search.SearchInfo {

	private static final long serialVersionUID = 1L;
    private static String m_NewDocNlsProp;
	private static NlsResourceBundle m_nlsResourceBundle;
    public static String QUERYID_PARAM = "queryId";
    
    public SearchInfo() {
    	m_NewDocNlsProp = "org.ifc.idocs.search.Search60NlsProp";
        m_nlsResourceBundle = new NlsResourceBundle(m_NewDocNlsProp);
        DfLogger.info(this, " : Loaded the NLS : " + m_NewDocNlsProp ,null,null);
	}
	public void generateQueryDescription()
    {
		DfLogger.info(this, "generateQueryDescription()" ,null,null);
        super.generateQueryDescription();
	}

	public String getQueryDescription() {
		String currentQueryDescription = super.getQueryDescription();
		if(currentQueryDescription!=null && currentQueryDescription.equals("Complex DQL Query")){
			DfLogger.info(this, "getQueryDescription() : Change to Custom Description " ,null,null);
			return m_nlsResourceBundle.getString("PASSTHROUGH_QUERY_DESCRIPTION", LocaleService.getLocale());
		}else{
			DfLogger.info(this, "getQueryDescription() : Return the default description " ,null,null);
			return currentQueryDescription; 
		}
	    
	}
}
