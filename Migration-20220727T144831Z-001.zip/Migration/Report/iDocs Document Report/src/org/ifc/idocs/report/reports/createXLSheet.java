package org.ifc.idocs.report.reports;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;
import java.util.StringTokenizer;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.ifc.idocs.report.common.AppConfig;

public class createXLSheet {
	
	/**
	 * 
	 * @param sheetName
	 * @param colHeaders
	 * @return
	 * @throws IOException
	 */
	protected static Workbook createReportSheet(String sheetName,String colHeaders) throws IOException{
	    return createReportSheet(sheetName,colHeaders, 2) ;
	}

	/**
	 * 
	 * @param sheetName
	 * @param colHeaders
	 * @return
	 * @throws IOException
	 */
	protected static Workbook createReportSheet(String sheetName,String colHeaders, int lineNo) throws IOException{
	    return createReportSheet(sheetName, colHeaders,  lineNo, true);
	}
	
	/**
	 * 
	 * @param sheetName
	 * @param colHeaders
	 * @param flag
	 * @return
	 * @throws IOException
	 */
	protected static Workbook createReportSheet(String sheetName,String colHeaders, int lineNo, boolean flag) throws IOException{
		System.out.println("createXLSheet :: createReportSheet() : Execution Started.");
		Workbook wb = new HSSFWorkbook();
		//Create cell style. Sets the values of font size, font, alignment...
		CellStyle newStyle = createStyle(wb, HSSFCellStyle.ALIGN_CENTER, "Calibri", 12, Font.BOLDWEIGHT_BOLD);
		Sheet newSheet = wb.createSheet(sheetName);
	    Row row = newSheet.createRow((short)lineNo);
	    if(flag){
		    StringTokenizer st = new StringTokenizer(colHeaders, ",");
		    int x=0;
		    while(st.hasMoreTokens()){
		    	// Create a cell and put a value in it.
			    createCell(wb,row,x,st.nextToken(),newStyle);
			    newSheet.autoSizeColumn((short)x);
			    x++;
		    }
	    }
	    System.out.println("createXLSheet :: createReportSheet() : Created...");
	    return wb;
	}

	/**
	 * 
	 * @param wb
	 * @param sheetName
	 * @param idocsProperties
	 * @param config 
	 * @throws IOException
	 */
	protected static void writeData(Workbook wb,String sheetName,Properties idocsProperties, AppConfig config){
		System.out.println("createXLSheet :: writeData() : Started...");
		Date newDate = new Date();
	    String fileName = newDate.toString().substring(11,19).replaceAll(":", "_");
	    FileOutputStream fileOut;
		try {
//			TODO just ti locate below code
			String dirPath = config.getString("repository.exportPath");
			File fileDir = new File(dirPath);
			if(!fileDir.exists()){
				fileDir.mkdirs();
			}			
			fileOut = new FileOutputStream(dirPath+sheetName+"_"+fileName+idocsProperties.getProperty("REPORT_EXT"));
		    wb.write(fileOut);
		    fileOut.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.exit(0);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}
	    System.out.println("createXLSheet :: writeData() : Created...");
	    System.out.println("Report Location: " + config.getString("repository.exportPath")+sheetName+"_"+fileName+idocsProperties.getProperty("REPORT_EXT"));
	}
	
	/**
	 * 
	 * @param wb
	 * @param row
	 * @param column
	 * @param msg
	 * @param style
	 */
	protected static void createCell(Workbook wb,Row row,int column,String msg,CellStyle style){
	    Cell cell = row.createCell(column);
	    cell.setCellValue(msg);
	    cell.setCellStyle(style);
	}
	
	/**
	 * 
	 * @param wb
	 * @param alignment
	 * @param fontName
	 * @param fontSize
	 * @param fontStyle
	 * @param s 
	 * @return
	 */
	protected static CellStyle createStyle(Workbook wb, short alignment, String fontName, int fontSize, short fontStyle){
	    return createStyle(wb, alignment, fontName, fontSize, fontStyle, (short) 0);
	}
	
	/**
	 * 
	 * @param wb
	 * @param alignment
	 * @param fontName
	 * @param fontSize
	 * @param fontStyle
	 * @param s 
	 * @return
	 */
	protected static CellStyle createStyle(Workbook wb, short alignment, String fontName, int fontSize, short fontStyle, short colorIndex){
		CellStyle style = wb.createCellStyle();
	    style.setAlignment(alignment);
	    style.setWrapText(false);
	    Font font = wb.createFont();
	    font.setFontHeightInPoints((short)fontSize);
	    font.setFontName(fontName);
	    font.setBoldweight(fontStyle);
	    style.setFont(font);
	    if(colorIndex != (short) 0){
		    style.setFillForegroundColor(colorIndex);
	        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	        style.setBorderTop((short) 1);
	        style.setBorderBottom((short) 1);
	        style.setBorderLeft((short) 1);
	        style.setBorderRight((short) 1);
	        
	        style.setBottomBorderColor(HSSFColor.GREY_40_PERCENT.index);
	        style.setTopBorderColor(HSSFColor.GREY_40_PERCENT.index);
	        style.setLeftBorderColor(HSSFColor.GREY_40_PERCENT.index);
	        style.setRightBorderColor(HSSFColor.GREY_40_PERCENT.index);
	        
	    }
	    System.out.println("createXLSheet :: createStyle() : Style Created...");
	    return style;
	}

}
