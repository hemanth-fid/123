/**
 * PCHW070Service.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W;

public interface PCHW070Service extends javax.xml.rpc.Service {
    public java.lang.String getPCHW070ServicePortAddress();

    public gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070ServicePort_Type getPCHW070ServicePort() throws javax.xml.rpc.ServiceException;

    public gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070ServicePort_Type getPCHW070ServicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
