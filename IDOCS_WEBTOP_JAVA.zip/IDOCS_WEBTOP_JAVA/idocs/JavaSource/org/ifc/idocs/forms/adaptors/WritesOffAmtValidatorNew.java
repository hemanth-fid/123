/**
 * 
 */
package org.ifc.idocs.forms.adaptors;

import com.documentum.fc.common.DfLogger;
import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.IAdaptorParameter;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.xforms.engine.adaptor.datasource.ISetValueAdaptor;

/**
 * @author HMuppalanarayana
 *
 */
public class WritesOffAmtValidatorNew implements ISetValueAdaptor{

	public Object execute(IAdaptorParameter[] parameters)
	             throws AdaptorException {

		String amtValue="";
		boolean amtFlag=false;
		if (parameters.length == 1){
			IAdaptorParameter parameter = parameters[0];
			amtValue=parameter.getValue();	
		}
		
		if(null!=amtValue && !"".equals(amtValue)){
			int flagTrueCounter=0;
			int flagFalseCounter=0;
			int bfrDecimal=0;
			int aftrDecimal=0;
			boolean flag = false;
			String concatStr=".00";
			if(!amtValue.contains(".")){
   				
   				amtValue=amtValue.concat(concatStr);
   			}
			
			String amtWithoutDecimal=amtValue.replace(".", "");
			for (int i = 0; i < amtWithoutDecimal.length(); i++) {

				//If we find a non-digit character we return false.
				if (Character.isDigit(amtWithoutDecimal.charAt(i)) && amtValue.contains(".")){
					flagTrueCounter++;
				}else{
					flagFalseCounter++;
				}
			}
			
			if(flagFalseCounter>0){
				flag=false;
			}else{
				flag=true;
			}
			DfLogger.info(this,"Amount Value"+" : "+amtValue,null,null);
			DfLogger.info(this,"Value Length"+" : "+amtValue.length(),null,null);
			int decimalPos=amtValue.indexOf(".");
			for(int i=0;i<decimalPos;i++){
				bfrDecimal++;
			}

			for(int i=decimalPos+1;i<amtValue.length();i++){
				aftrDecimal++;
			}
			DfLogger.info(this,"Flag Value"+" : "+flag,null,null);
			if(!flag || (bfrDecimal>15 || aftrDecimal>2)){
				
				amtFlag=false;
				

			}else{
				
				amtFlag=true;
				
			}
		}else{
			DfLogger.info(this,"Null Value",null,null);
			amtFlag=true;
		}
		return amtFlag;
	}
	public void destroy() throws AdaptorException {
	}

	public void init(IAdaptorConfiguration arg0) throws AdaptorException {
	}
}
