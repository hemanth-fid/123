/**
* This class is for displaying class is extended from LaunchComponent to get workflow details of the document
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* DShivnani				10/02/2010		1.0				created 
* #######################################################################################################
*/
package org.ifc.idocs.workflow.reportdetails;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceClass;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.ErrorMessageService;
import com.documentum.web.formext.action.LaunchComponent;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

public class LaunchReportDetailsComponent extends LaunchComponent
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Properties idocsProperties = new Properties();
	private static final String R_WORKFLOW_ID = "r_workflow_id";
	private static final String OBJECT_NAME = "object_name";
	
    public LaunchReportDetailsComponent()
    {
    }

    
    /**
     * This execution class is customised to show the workflow report of the selected document.
     * This will throw an error if there is not workflow running for this document.
     * 
     * @param strAction - Action name
     * @param config - Config settings
     * @param args - Dictionary of arguments
     * @param context - Context
     * @param component - Caller component (optional)
     * @param completionArgs - Returned complete arguments 
	 *
	 * @return boolean - Whether action executed correctly
     */
	public boolean execute(String strAction, IConfigElement config, 
			ArgumentList args, Context context, Component component, Map completionArgs){
		
    	try {
    		idocsProperties.load(LaunchReportDetailsComponent.class.getResourceAsStream(IdocsConstants.IDOCS_PROPERTY_FILE));
			String strObjectId = args.get("objectId");
			DfLogger.info(this, " :: execute: strObjectId: " + strObjectId, null, null);
			String qryObjectName = idocsProperties.getProperty("QRY_GET_DOCUMENT_NAME");
			qryObjectName = qryObjectName.replaceFirst("''", "'" + strObjectId + "'");
	    	DfLogger.info(this, " :: execute: qryObjectName: " + qryObjectName, null, null);
			String objectName = execQuery(component.getDfSession(), qryObjectName, OBJECT_NAME);
			if(strObjectId != null && strObjectId.trim().length()>0){
				String workflowId = IdocsUtil.getWorkflowId(component.getDfSession(), strObjectId);
				if(workflowId != null && workflowId.trim().length() > 0){
					return super.execute(strAction, config, args, context, component, completionArgs);
				}else{
					NlsResourceClass lookup = NlsResourceClass.getResource("org.ifc.idocs.navigation.doclist.DocListNlsProp");
//			        ActionExecutionUtil.setCompletionError(completionArgs, lookup, "MSG_DOCUMENT_NOT_IN_WORKFLOW", component, new Object[] {objectName}, null);
			        ErrorMessageService.getService().setNonFatalError(lookup, "MSG_DOCUMENT_NOT_IN_WORKFLOW", component, new Object[]{objectName}, null);
					return false;
				}
			}
		} catch (IOException ioe) {
			DfLogger.error(this, " :: execute IOException >> "+ioe.getMessage(), null, ioe);
		} 
		return super.execute(strAction, config, args, context, component, completionArgs);		
    }
    
    /**
     * This method executes the query and returns the result
     * 
     * @param dfSession
     * @param queryString
     * @param attrName
     * @return
     */
    private String execQuery(IDfSession dfSession, String queryString, String attrName) {
    	String queryResult = null;
    	try{
    		DfQuery query = new DfQuery();
    		query.setDQL(queryString);
    		IDfCollection dfCollection = query.execute(dfSession, IDfQuery.DF_READ_QUERY);
    		if(dfCollection.next()) {
    			queryResult = dfCollection.getString(attrName);
    			dfCollection.close();
    		}
    		if(dfCollection != null)dfCollection.close();
    	} catch (DfException dfe) {
    		DfLogger.error(this, " :: execQuery >> " + dfe.getMessage(), null, dfe);
    	}
		return queryResult;
	}

    
    
}