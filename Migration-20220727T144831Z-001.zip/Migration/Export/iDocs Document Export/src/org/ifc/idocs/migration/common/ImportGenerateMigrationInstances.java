package org.ifc.idocs.migration.common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

import org.ifc.idocs.migration.extract.DBConnection;

public class ImportGenerateMigrationInstances {

	private static AppConfig config = AppConfig.getInstance();

	public static void main(String[] args){
		
		String utilIds = config.getString("createInstance.criterias");			
		String[] extUtilList = utilIds.split(";");
		
		String src = config.getString("createInstance.src"), dest = null;
		File srcDir = new File(src);
		
		File trgDir = null;		
		
		for(int i=1; i<= extUtilList.length; i++){
			dest = config.getString("createInstance.dest") + i + "_" + extUtilList[i-1];
			trgDir = new File(dest);
			copy(srcDir, trgDir);
			String exportpath = fetchImportPath(fetchExtractionCriteriaCode(extUtilList[i-1]));
			updateXML(src, dest, extUtilList[i-1], exportpath);
			System.out.println(dest + " folder created.");
		}
	}
	
	public static String fetchExtractionCriteriaCode(String extractionUtilityCode) {
		
		//read reportmap table and return ecc
		return  DBConnection.getExtractiontCriteriaCode(extractionUtilityCode);		

		
	}
	
	public static String fetchImportPath(String extractionCriteriaCode) {
		String cntry = "", utilityId = "";
		String criteriacode = extractionCriteriaCode ;//config.getString("filters.extractioncriteriacode");
		String exportPath = config.getString("export.path");
//		exportPath = exportPath.replace("\\", "/");
		try{
			String[] extInfo = DBConnection.getExtractionInfo(criteriacode);
			utilityId = DBConnection.getExtractiontUtilityId(criteriacode);
			utilityId = utilityId == null ? "" : utilityId;
			if(extInfo != null){
				cntry = extInfo[3] == null ? "" : extInfo[3];
			}
			if (cntry.length() > 3){
				cntry = cntry.substring(0, 3);
			}
		}catch(NullPointerException ne){
			System.out.println("Please provide a valid Extraction Criteria in config.xml.");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String commonPath = exportPath + cntry + "\\";
		if(criteriacode.contains("PRJ")){
			commonPath += "Project";
		}else if(criteriacode.contains("PTR")){
			commonPath += "Partner";
		}
		return commonPath;
	}
	public static void updateXML(String src, String dest, String utilityid, String exportPath){
		
		try{
			FileInputStream fis = new FileInputStream(src + "config.xml");
			FileWriter fw = new FileWriter(dest + "\\config.xml");
			
			DataInputStream in = new DataInputStream(fis);
			BufferedWriter out = new BufferedWriter(fw);
			
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			while ((strLine = br.readLine()) != null)   {
				if(strLine.contains("extractionutilityID")){
					out.write("<extractionutilityID>"+utilityid+"</extractionutilityID>");
				}
				else if(strLine.contains("extractionPath")){
					out.write("<extractionPath>"+exportPath+"</extractionPath>");
				}
				else if(strLine.contains("logFilePath")){
					out.write("<logFilePath>"+dest+"</logFilePath>");
				}else {
					out.write(strLine);
				}
			}
			in.close();
			out.close();
		}catch (Exception e){//Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}

	public static void copy(File sourceLocation, File targetLocation){
		try {
	        if (sourceLocation.isDirectory()) {
	            if (!targetLocation.exists()) {
	                targetLocation.mkdir();
	            }
	            File[] files = sourceLocation.listFiles();
	            for(File file:files){
	                InputStream in = new FileInputStream(file);
	                OutputStream out = new FileOutputStream(targetLocation+"/"+file.getName());

	                byte[] buf = new byte[1024];
	                int len;
	                while ((len = in.read(buf)) > 0) {
	                    out.write(buf, 0, len);
	                }
	                in.close();
	                out.close();
	            }            
	        }
		}catch(IOException ioe){
			ioe.printStackTrace();
		}
	}
}
