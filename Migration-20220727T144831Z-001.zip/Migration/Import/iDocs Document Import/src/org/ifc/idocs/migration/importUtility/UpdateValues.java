package org.ifc.idocs.migration.importUtility;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.logging.Level;

import org.ifc.idocs.migration.helper.Utilities;

import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.common.DfException;
/**
 * UpdateValues - Updating hashmaps with the values parsed from XML. 
 * @author HAnuganti
 * 
 * #############################################################################################
 * Author		            DateofChange	 Version	  ModificationHistory
 * ###########################################################################################
 * Hemachandra Anuganti 
 * ###########################################################################################
 * 
 */
public class UpdateValues extends ImportUtility{

	protected static boolean updateAttrHM(int Index){
		
		//importDocLogger.info(inside xmlParse(Element elem, HashMap hm)::"+UpdateValues.class);
		boolean updateAttrFlag = false; 
		StringTokenizer st;
		String attrValue = "",docFormat="",attrList="",metadataList="",objectType="";
		int attrCount = 0,i=0;
		String attrName = "";
		IDfFolder docFolder;
		IDfFolder parentFld;
		String fldPath = idocsProperties.getProperty("MSG_CABINET_PATH");
		st=new StringTokenizer(idocsProperties.getProperty("IDOCS_META_DATA_LIST"), ",");
		attrCount=st.countTokens();
    	for(i=0;i<attrCount;i++){
			attrName=st.nextToken();
			metaData.put(attrName, idocsProperties.getProperty(attrName));
		}
    	String fileRoom = (String) attributeValueList[0].get("Fileroom");
    	if(fileRoom.equalsIgnoreCase(idocsProperties.getProperty("MSG_INSTITUTION_FILEROOM"))){
//    		String institutionNbr = (String) attributeValueList[0].get(idocsProperties.getProperty("MSG_DOM_INSTITUTION_NBR"));
    		String institutionNbr = fld_value_code;
    		try {
	    			if(null != institutionNbr && "" != institutionNbr){
					parentFld = (IDfFolder) dfSession.getObjectByQualification("idocs_institution_folder where institution_nbr='"+institutionNbr+"'");
					if(parentFld!=null){
						fldPath += parentFld.getString("country_nme");
						fldPath += "/";
						fldPath += "Institution";
						fldPath += "/";
						fldPath += parentFld.getString("object_name");
					//importDocLogger.info(Countries room::"+fileRoom+"Folder Path::"+fldPath);
					}else{
						importDocLogger.info("Utility Unable to fetch and update the folder details of the Institution Nbr::"+institutionNbr);
						raiseDestFldPathBuildException(institutionNbr);
						return false;
					}
					//Update Folder attributes to the hasmaps
					if(fileRoom.equalsIgnoreCase(idocsProperties.getProperty("MSG_INSTITUTIONS_FOLDER")) || fileRoom.equalsIgnoreCase(idocsProperties.getProperty("MSG_INSTITUTION_FOLDER"))){
							docFormat = attributeValueList[Index].get("DocFormat").toString().trim();
							attrList = idocsProperties.getProperty("INSTIT_DOC_ATTR_LIST");
							metadataList = idocsProperties.getProperty("IDOCS_INSTIT_META_DATA_LIST");
							objectType = idocsProperties.getProperty("MSG_IDOCS_INSTIT_DOC");
	
							//Update Hashmap for email documents
							if(docFormat !="" && docFormat.equalsIgnoreCase("Notes")){
								attrData.put("docFormat","Notes");
						    	StringTokenizer stEmailDocTokens = new StringTokenizer(idocsProperties.getProperty("IDOCS_EMAIL_META_DATA_LIST"),",");
								while(stEmailDocTokens.hasMoreTokens()){
									attrName = stEmailDocTokens.nextToken();
									attrValue=(String) attributeValueList[Index].get(attrName);
									attrName = idocsProperties.getProperty(attrName);
									attrData.put(attrName,attrValue);
								}
							}
							//get attribute list for country document from the folder
							docFolder = (IDfFolder) dfSession.getObjectByPath(fldPath);
							if(docFolder != null){
								if(docFolder.getTypeName().equals("idocs_institution_folder")){
									StringTokenizer strTokens = new StringTokenizer(idocsProperties.getProperty("MSG_INSTITUTION_FOLDER_ATTR_LIST"),",");
									while(strTokens.hasMoreTokens()){
										attrName = strTokens.nextToken();
										attrValue=docFolder.getString(attrName);
										attrData.put(attrName,attrValue);	
									}
									docBaseObjectType = objectType;
									//importDocLogger.info(Object Type docBaseObjectType::"+objectType);
						        }
							}else{
								importDocLogger.info("Unable to fetch values for folder values for the path::"+fldPath);
								ImportDocument.raiseDestFldNotFoundException(new NullPointerException(),fldPath);
								return false;
							}
					}	
					attrData.put("folderPath", fldPath);
	    			}else{
	    				raisePrjInstCtryNbrsNotFoundException(institutionNbr);
	    				return false;
    			}
					//Success Condition
					return true;	
			}catch(NullPointerException npe){
				ImportDocument.raiseDestFldNotFoundException(npe,fldPath);
				return false;
			}catch (DfException e) {
				// TODO Auto-generated catch block
				importDocLogger.warning("DfException::"+e.getMessage());
				importDocLogger.log(Level.WARNING,"DfException during generating destination path for the institution number["+institutionNbr+"]", e);
				raiseDestFldPathBuildException(institutionNbr);
				e.printStackTrace();
				return false;
			}
		}else if(fileRoom.equalsIgnoreCase(idocsProperties.getProperty("MSG_PROJECTS_FILEROOM"))){
//			String projectId = (String) attributeValueList[0].get(idocsProperties.getProperty("MSG_PROJECTS_ID"));
			String projectId = fld_value_code;
			try {
					if(null != projectId && "" != projectId){
					//update with other categories
					parentFld = (IDfFolder) dfSession.getObjectByQualification("idocs_project_folder where project_id='"+projectId+"'");
					if(parentFld!=null){
						fldPath += parentFld.getString("country_nme");
						//check if folder path exist, if not then give message in log
						fldPath += "/";
						fldPath += parentFld.getString("folder_category");
						//check if folder path exist, if not give message in log
						fldPath += "/";
						fldPath += parentFld.getString("object_name");
					}else{
						importDocLogger.info("Utility Unable to fetch and update the folder details of the Project ID::"+projectId);
						raiseDestFldPathBuildException(projectId);
						return false;
					}
					//Update Folder attributes to the hasmaps
					if(fileRoom.equalsIgnoreCase(idocsProperties.getProperty("MSG_PROJECTS_FOLDER")) || fileRoom.equalsIgnoreCase(idocsProperties.getProperty("MSG_PROJECT_FOLDER"))){
							
							docFormat = attributeValueList[Index].get("DocFormat").toString().trim();
							objectType = idocsProperties.getProperty("MSG_IDOCS_PROJECT_DOC");
							if(docFormat !="" && docFormat.equalsIgnoreCase("Notes")){
								attrData.put("docFormat","Notes");
						    	StringTokenizer stEmailDocTokens = new StringTokenizer(idocsProperties.getProperty("IDOCS_EMAIL_META_DATA_LIST"),",");
								while(stEmailDocTokens.hasMoreTokens()){
									attrName = stEmailDocTokens.nextToken();
									attrValue=(String) attributeValueList[Index].get(attrName);
									attrName = idocsProperties.getProperty(attrName);
									attrData.put(attrName,attrValue);
								}
							}
							attrList = idocsProperties.getProperty("PROJECT_DOC_ATTR_LIST");
							
							//get attribute list for country document from the folder
							docFolder = (IDfFolder) dfSession.getObjectByPath(fldPath);

							if(docFolder!=null && docFolder.getTypeName().equals("idocs_project_folder")){
								StringTokenizer stPrjDocTokens = new StringTokenizer(idocsProperties.getProperty("MSG_PROJECT_FOLDER_ATTR_LIST"),",");
								while(stPrjDocTokens.hasMoreTokens()){
									attrName = stPrjDocTokens.nextToken();
									attrValue=docFolder.getString(attrName);
									//importDocLogger.info(folder attribute values::"+attrName+"::"+attrValue);
									attrData.put(attrName,attrValue);		
								}
								docBaseObjectType = objectType;
						    	//importDocLogger.info(Object Type docBaseObjectType::"+objectType);
					        }else{
					        	importDocLogger.info("Unable to fetch values for folder values for the path::"+fldPath);
					        	ImportDocument.raiseDestFldNotFoundException(new NullPointerException(),fldPath);
								return false;
					        }
					} 
					attrData.put("folderPath", fldPath);
				}else{
					raisePrjInstCtryNbrsNotFoundException(projectId);
					return false;
				}
					//Success Condition
					return true;	
			}catch(NullPointerException npe){
				ImportDocument.raiseDestFldNotFoundException(npe,fldPath);
				return false;
			} catch (DfException e) {
				// TODO Auto-generated catch block
				importDocLogger.warning("DfException::"+e.getMessage());
				importDocLogger.log(Level.WARNING,"DfException during generating destination path for the project id["+projectId+"]", e);
				raiseDestFldPathBuildException(projectId);
				e.printStackTrace();
				return false;
			}
		}else if(fileRoom.equalsIgnoreCase(idocsProperties.getProperty("MSG_COUNTRIES_FILEROOM"))){
//			String ctryCodes = (String) attributeValueList[0].get(idocsProperties.getProperty("MSG_DOM_COUNTRY_CODE"));
			String ctryCodes = fld_value_code;
			try {
				if(null != ctryCodes && "" != ctryCodes){
					//update with other categories
					parentFld = (IDfFolder) dfSession.getObjectByQualification("idocs_country_folder where country_code='"+ctryCodes+"'");
					if(parentFld!=null){
						fldPath += parentFld.getString("country_nme");
						//check if folder path exist, if not then give message in log
						fldPath += "/";
						fldPath += parentFld.getString("folder_category");
						//check if folder path exist, if not give message in log
						fldPath += "/";
						fldPath += parentFld.getString("object_name");
					}else{
						importDocLogger.info("Utility is Unable to fetch and update the folder details of the Country Code::"+ctryCodes);
						raiseDestFldPathBuildException(ctryCodes);
						return false;
					}
					
					//Update Folder attributes to the hasmaps
					if(fileRoom.equalsIgnoreCase(idocsProperties.getProperty("MSG_COUNTRIES_FOLDER")) || fileRoom.equalsIgnoreCase(idocsProperties.getProperty("MSG_COUNTRY_FOLDER")) || fileRoom.equalsIgnoreCase(idocsProperties.getProperty("MSG_COUNTRIES_MISCELLANEOUS"))){
						//get attribute list for country document from the folder
							docFolder = (IDfFolder) dfSession.getObjectByPath(fldPath);
							if(docFolder!=null && docFolder.getTypeName().equals("idocs_country_folder")){
								StringTokenizer strTokens = new StringTokenizer(idocsProperties.getProperty("MSG_COUNTRY_FOLDER_ATTR_LIST"),",");
								while(strTokens.hasMoreTokens()){
									attrName = strTokens.nextToken();
									attrValue=docFolder.getString(attrName);
									//importDocLogger.info(folder attribute values::"+attrName+"::"+attrValue);
									attrData.put(attrName,attrValue);	
								}
								docBaseObjectType = idocsProperties.getProperty("MSG_IDOCS_COUNTRY_DOC");
							    //importDocLogger.info(Object Type docBaseObjectType::"+objectType);
							}else{
								importDocLogger.info("Unable to fetch values for folder values for the path::"+fldPath);
					        	ImportDocument.raiseDestFldNotFoundException(new NullPointerException(),fldPath);
								return false;
							}
						}
						attrData.put("folderPath", fldPath);
					}else{
						raisePrjInstCtryNbrsNotFoundException(ctryCodes);
						return false;
					}
					//Success Condition
					return true;	
				}catch(NullPointerException npe){
					ImportDocument.raiseDestFldNotFoundException(npe,fldPath);
					return false;
				} catch (DfException e) {
					// TODO Auto-generated catch block
					importDocLogger.warning("DfException::"+e.getMessage());
					importDocLogger.log(Level.WARNING,"DfException during generating destination path for the country code["+ctryCodes+"]", e);
					raiseDestFldPathBuildException(ctryCodes);
					return false;
				}
		}else{
			importDocLogger.warning("Unknown fileroom found in the Metadata XML::["+fileRoom+"]");
			raiseunKnownFileroomFoundException(fileRoom);
			return false;
		}
	}

	private static void raiseunKnownFileroomFoundException(String fileRoom) {
		// TODO Auto-generated method stub
		String skippedReason = "Unknown Fileroom Value found in the Metadata XML::["+xmlPath+"]";
		skippedReason = skippedReason.replaceAll("'", "''");
		skippedReason = skippedReason+"')";
		
		Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_55"),skippedReason);
	}

	private static void raisePrjInstCtryNbrsNotFoundException(
			String prjInstCtryCode) {
		// TODO Auto-generated method stub
		String skippedReason = "Project/Institution/Country codes are not found in the Metadata XML::["+xmlPath+"]";
		skippedReason = skippedReason.replaceAll("'", "''");
		skippedReason = skippedReason+"')";
		
		Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_54"),skippedReason);

	}

	/*private static void raiseDestFldAttrFetchException(String fldPath) {
		// TODO Auto-generated method stub
		String skippedReason = "Utility is Unable to get the handle for the destination path folder::["+fldPath+"]";
		skippedReason = skippedReason.replaceAll("'", "''");
		skippedReason = skippedReason+"')";
		
		Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_54"),skippedReason);

	}*/

	private static void raiseDestFldPathBuildException(String folderIdentityCode) {
		// TODO Auto-generated method stub
		String skippedReason = "Utility is Unable to build the destination folder path for the project/institution/country::["+folderIdentityCode+"]";
		skippedReason = skippedReason.replaceAll("'", "''");
		skippedReason = skippedReason+"')";
		
		Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_52"),skippedReason);
	}

}
