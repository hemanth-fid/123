package org.ifc.idocs.importUtil;

import java.util.StringTokenizer;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.common.DfException;

public class UpdateValues extends ImportUtility{

	@SuppressWarnings("unchecked")
	protected static void updateAttrHM(int Index) throws DfException 
	{
		IDfCollection dataCollection = null;
		StringTokenizer st;
		int attrCount = 0,i=0;
		String attrName = "";

		st=new StringTokenizer(idocsProperties.getProperty("IDOCS_META_DATA_LIST"), ",");
		attrCount=st.countTokens();
    	for(i=0;i<attrCount;i++){
			attrName=st.nextToken();
			mataData.put(attrName, idocsProperties.getProperty(attrName));
		}

		StringBuilder strQuery = null;
		IDfQuery queryObj=new DfQuery();
		String attrValue = "",docFormat="",attrList="",metadataList="",objectType="";
		// update attrData and mataData hashmap as per category from MetaDataMapping class
		if(category.equalsIgnoreCase(idocsProperties.getProperty("MSG_COUNTRIES_FOLDER")) || category.equalsIgnoreCase(idocsProperties.getProperty("MSG_COUNTRY_FOLDER")))
		{
			st=new StringTokenizer(idocsProperties.getProperty("COUNTRY_DOC_ATTR_LIST"), ",");
			attrCount=st.countTokens();
			strQuery = new StringBuilder(idocsProperties.getProperty("QRY_COUNTRY_TBL"));
			strQuery.append(categoryCode).append("' ");
			//strQuery.append(idocsProperties.getProperty("QRY_AND_TEMPLATE")).append(attributeValueList[Index].get(idocsProperties.getProperty("MSG_TEMP_TITLE"))).append("'");
			queryObj.setDQL(strQuery.toString());
			dataCollection=queryObj.execute(dfSession, IDfQuery.READ_QUERY);
		    if(dataCollection.next())
		    {
		    	for(i=0;i<attrCount;i++){
					attrName=st.nextToken();
					attrValue=dataCollection.getString(attrName).trim();
					attrData.put(attrName,attrValue);
				}
		    	dataCollection.close();
		    	st=new StringTokenizer(idocsProperties.getProperty("IDOCS_COUNTRY_META_DATA_LIST"), ",");
				attrCount=st.countTokens();
		    	for(i=0;i<attrCount;i++){
					attrName=st.nextToken();
					mataData.put(attrName, idocsProperties.getProperty(attrName));
				}
		    	docBaseObjectType = idocsProperties.getProperty("MSG_IDOCS_COUNTRY_DOC");
		    }
		    else
	    	{
		    	dominoDocLogger.info("UpdateValues :: updateAttrHM() : The Country, "+categoryCode+", Empty Collection");
	    	}
	    	
		} 
		else if(category.equalsIgnoreCase(idocsProperties.getProperty("MSG_PROJECTS_FOLDER")) || category.equalsIgnoreCase(idocsProperties.getProperty("MSG_PROJECT_FOLDER"))) 
		{
			docFormat = attributeValueList[Index].get("DocFormat").toString().trim();
			if(docFormat.equalsIgnoreCase("Notes"))
			{
				objectType = idocsProperties.getProperty("MSG_IDOCS_EMAIL_DOC");
				attrList = idocsProperties.getProperty("EMAIL_DOC_ATTR_LIST");
				metadataList = idocsProperties.getProperty("IDOCS_EMAIL_META_DATA_LIST");
			}
			else
			{
				objectType = idocsProperties.getProperty("MSG_IDOCS_PROJECT_DOC");
				attrList = idocsProperties.getProperty("PROJECT_DOC_ATTR_LIST");
				metadataList = idocsProperties.getProperty("IDOCS_PROJ_META_DATA_LIST");
			}
			
			st=new StringTokenizer(attrList, ",");
			attrCount=st.countTokens();
			strQuery = new StringBuilder(idocsProperties.getProperty("QRY_PROJECT_TBL"));
			strQuery.append(categoryCode).append("' ");
			//strQuery.append(idocsProperties.getProperty("QRY_AND_TEMPLATE")).append(attributeValueList[Index].get(idocsProperties.getProperty("MSG_TEMP_TITLE"))).append("'");
			queryObj.setDQL(strQuery.toString());
			dataCollection=queryObj.execute(dfSession, IDfQuery.READ_QUERY);
		    if(dataCollection.next())
		    {
		    	projMainCategory=dataCollection.getString(idocsProperties.getProperty("MSG_PROJ_MAIN_CATEGORY"));
		    	for(i=0;i<attrCount;i++){
					attrName=st.nextToken();
					attrValue = dataCollection.getString(attrName).trim();
					attrData.put(attrName,attrValue);
				}
		    	dataCollection.close();
		    	st=new StringTokenizer(metadataList, ",");
				attrCount=st.countTokens();
		    	for(i=0;i<attrCount;i++){
					attrName=st.nextToken();
					mataData.put(attrName, idocsProperties.getProperty(attrName));
				}
		    	docBaseObjectType = objectType;
			}
		    else
	    	{
		    	dominoDocLogger.info("UpdateValues :: updateAttrHM() : The Project, "+categoryCode+", Empty Collection");
	    		
	    	}
		} 
		else if(category.equalsIgnoreCase(idocsProperties.getProperty("MSG_INSTITUTIONS_FOLDER")) || category.equalsIgnoreCase(idocsProperties.getProperty("MSG_INSTITUTION_FOLDER")))
		{
			docFormat = attributeValueList[Index].get("DocFormat").toString().trim();
			if(docFormat.equalsIgnoreCase("Notes"))
			{
				attrList = idocsProperties.getProperty("EMAIL_DOC_ATTR_LIST");
				metadataList = idocsProperties.getProperty("IDOCS_EMAIL_META_DATA_LIST");
				objectType = idocsProperties.getProperty("MSG_IDOCS_EMAIL_DOC");
			}
			else
			{
				attrList = idocsProperties.getProperty("INSTIT_DOC_ATTR_LIST");
				metadataList = idocsProperties.getProperty("IDOCS_INSTIT_META_DATA_LIST");
				objectType = idocsProperties.getProperty("MSG_IDOCS_INSTIT_DOC");
			}
			
			st=new StringTokenizer(attrList, ",");
			attrCount=st.countTokens();
			strQuery = new StringBuilder(idocsProperties.getProperty("QRY_INSTIT_TBL").trim());
			strQuery.append(categoryCode).append("'");
			//strQuery.append(idocsProperties.getProperty("QRY_AND_TEMPLATE")).append(attributeValueList[Index].get(idocsProperties.getProperty("MSG_TEMP_TITLE"))).append("'");
			queryObj.setDQL(strQuery.toString());
			dataCollection=queryObj.execute(dfSession, IDfQuery.READ_QUERY);
			if(dataCollection.next())
		    {
		    	for(i=0;i<attrCount;i++){
					attrName=st.nextToken();
					attrValue = dataCollection.getString(attrName).trim();					
					attrData.put(attrName,attrValue);
				}
		    	dataCollection.close();
		    	st=new StringTokenizer(metadataList, ",");
				attrCount=st.countTokens();
		    	for(i=0;i<attrCount;i++){
					attrName=st.nextToken();
					mataData.put(attrName, idocsProperties.getProperty(attrName));
				}
		    	docBaseObjectType = objectType;
			}
		    else
	    	{
		    	dominoDocLogger.info("UpdateValues :: updateAttrHM() : The Institution, "+categoryCode+",Empty Collection");
	    		
	    	}
			
		} 
	}
}
