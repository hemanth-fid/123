package org.ifc.idocs.migration.common;

public class MigrationSkippedDocuments {

	private String utilityCode;
	private String documentId;
	private String documentUniqueId;
	private String version;
	private String title;
	private String folderTypeCode;
	private String folderValueCode;
	private String fileCabinet;
	private String database;
	private String skipReason;
	private String errorCode;
	
	public String getFolderValueCode() {
		return folderValueCode;
	}
	public void setFolderValueCode(String folderValueCode) {
		this.folderValueCode = folderValueCode;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getUtilityCode() {
		return utilityCode;
	}
	public void setUtilityCode(String utilityCode) {
		this.utilityCode = utilityCode;
	}
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public String getDocumentUniqueId() {
		return documentUniqueId;
	}
	public void setDocumentUniqueId(String documentUniqueId) {
		this.documentUniqueId = documentUniqueId;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFolderTypeCode() {
		return folderTypeCode;
	}
	public void setFolderTypeCode(String folderTypeCode) {
		this.folderTypeCode = folderTypeCode;
	}
	public String getFileCabinet() {
		return fileCabinet;
	}
	public void setFileCabinet(String fileCabinet) {
		this.fileCabinet = fileCabinet;
	}
	public String getDatabase() {
		return database;
	}
	public void setDatabase(String database) {
		this.database = database;
	}
	public String getSkipReason() {
		return skipReason;
	}
	public void setSkipReason(String skipReason) {
		this.skipReason = skipReason;
	}
}
