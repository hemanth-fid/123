/***************************************************************************
 * State Farm
 * Version Template: 2012
 *
 * File Name: QueryException.java
 *
 * Version     ChgDate          Author           Comments
 * ________   __________       ________         ___________
 * 1.0        03/19/2013         t1or         Initial Creation 
 *
 ***************************************************************************/

package sf.application.custcomm.ccs.exceptions;

import com.documentum.fc.common.DfLogger;

/**
 * <i>QueryException</i> is a custom exception class that is built on extending
 * the ExportProcessException.
 * 
 */
public class QueryException extends CleanUpServiceException {

	private static final long serialVersionUID = 763918157604625630L;

	/**
	 * Logs the error message captured within the work-flow module
	 * 
	 * @param message
	 *            Exception message description
	 */
	public QueryException(String message) {
		super(message);
		DfLogger.error(this, message, null, null);
	}

	/**
	 * Logs the error message captured within the work-flow module
	 * 
	 * @param message
	 *            Exception message description
	 * @param throwable
	 *            Throwable class
	 */
	public QueryException(String message, Throwable throwable) {
		super(message, throwable);
		DfLogger.error(this, message, null, throwable);
	}

}
