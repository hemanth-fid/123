package org.ifc.idocs.library.actions;

import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.web.common.AccessibilityService;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.formext.action.IActionPrecondition;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

public class IDocsDeleteDocumentPreCondition  implements IActionPrecondition  {
		
		public String[] getRequiredParams() {
			return (new String[] {"objectId"});
			}

		public boolean queryExecute(String s, IConfigElement iconfigelement,ArgumentList arg, Context context, Component component){
			boolean bExecute = false;
			
			/** Restricting user to not delete virtual document child in side the VDM */
			boolean bAccessibilityOn = AccessibilityService.isAllAccessibilitiesEnabled();
			String strComponentId = component.getComponentId(bAccessibilityOn);
			if(strComponentId.equals("vdmlist") || strComponentId.equals("vdmliststreamline") || strComponentId.equals(TASKATTACHMENT))
				return bExecute;
			if(IdocsUtil.getMessage("STR_DELETE_WRK_DOCUMENT_STATUS").equalsIgnoreCase(IdocsConstants.MSG_YES)){
				bExecute = true;
				}else{
					String strLockOwner = arg.get("lockOwner");
					if(strLockOwner == null)
					{
						String strObjectId = arg.get("objectId");
						if(strObjectId != null){
							IDfSession dfSession = component.getDfSession();
							try{
								IDfSysObject sysobj = (IDfSysObject)dfSession.getObject(new DfId(strObjectId));
								if(sysobj != null)
									strLockOwner = sysobj.getLockOwner();
								}
							catch(DfException e){
								throw new WrapperRuntimeException("Failed to get lock owner", e);
								}
							}
						}
					if(strLockOwner == null || strLockOwner.length() == 0)
						bExecute = true;
					}
			return bExecute;
			}

	/**
	 * This method fetch the property value form the properties file corresponding to the key	 
	 * @param key
	 * @return String
	 *//*
	public String getMessage(String key) {
		String message = null;
		try {
			message = idocsProperties.getProperty(key);		
			if(message !=null && message.trim().length() > 0){
				
			}else{
				idocsProperties.load(IDocsDeleteDocumentPreCondition.class.getResourceAsStream(IdocsConstants.IDOCS_PROPERTY_FILE));
				message = idocsProperties.getProperty(key);
			}
		} catch (Exception e) {
			try {
				idocsProperties.load(IDocsDeleteDocumentPreCondition.class.getResourceAsStream(IdocsConstants.IDOCS_PROPERTY_FILE));
				message = idocsProperties.getProperty(key);
			} catch (IOException e1) {
				DfLogger.error(IdocsUtil.class, " :: getMessage Exception >> "+ e.getMessage(), null, e);			
			}
		}
		return message;
	}*/
	//protected static Properties idocsProperties = new Properties();
	private static final String TASKATTACHMENT="taskattachment";
	
	}