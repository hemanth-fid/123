package org.ifc.idocs.report.transform;


import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Collection;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import lotus.domino.NotesException;

import org.apache.log4j.Logger;
import org.ifc.idocs.report.common.AppConfig;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * @author SPankajamsadanan
 *
 */
public class DocumentTransformer {
	
	static Logger log4j = Logger.getLogger(DocumentTransformer.class);

	private DocumentTransformer(){}



	/**
	 * processAttributes method
	 * @param root
	 * @param config
	 * @param operation
	 * @return void
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked", "unused" })
	private static void processAttributes(Element root, AppConfig config, String operation) throws Exception {
		Object obj = config.getProperty("transform." + operation + ".attribute");
		if (obj != null) {
			if (obj instanceof Collection) {
				int size = ((Collection) obj).size();
				for (int i = 0; i < size; i++) {
					processAttribute(root, config.getString("transform." + operation + ".attribute(" + i + ")"), operation);
				}
			} else if (obj instanceof String) {
				processAttribute(root, config.getString("transform." + operation + ".attribute"), operation);
			}
		}
	}

	/**
	 * processAttribute method
	 * @param root
	 * @param tagName
	 * @param operation
	 * @return void
	 * @throws Exception
	 */
	private static void processAttribute(Element root, String tagName, String operation) throws Exception {
		Node parentTag = root.getElementsByTagName(tagName).item(0);
		if (parentTag.hasChildNodes()) {
			if (parentTag.getFirstChild().getNodeType() == Node.TEXT_NODE) {
				executeOperation(operation, parentTag);	// here its calling lookupUPI / convertNotesNames methods
			} else {
				NodeList values = parentTag.getChildNodes();
				int valuesLength = values.getLength();
				for (int i=0; i < valuesLength; i++) {
					executeOperation(operation, values.item(i));
				}
			}
		}
	}

	/**
	 * executeOperation method
	 * @param operation
	 * @param item
	 * @return void
	 * @throws Exception
	 */
	private static void executeOperation(String operation, Node item) throws Exception {
		Method method = DocumentTransformer.class.getDeclaredMethod(operation, Node.class);
		method.invoke(null, item);
	}

	/**
	 * exportToSharedMetadataFile method
	 * @param path
	 * @param docid
	 * @param docXML
	 * @return void
	 */
	public static void exportToSharedMetadataFile(String path, String docid, Element docXML) {
		try{
			String sharedFileName = docid + "_all_metadata.xml";
			String docunid = docXML.getAttribute("docunid");		
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setIgnoringElementContentWhitespace(true);
			DocumentBuilder docBuilder = dbf.newDocumentBuilder();
			Document sharedXML;
			Element root;

			//import DOM from file system
			File sharedFile = new File(path + "/" + sharedFileName);
			if (sharedFile.exists()) {
				sharedXML = docBuilder.parse(sharedFile);
				root = sharedXML.getDocumentElement();
				//	System.out.println("root="+root);
				//remove the same document from the bundle in case of update
				NodeList docXMLnodes = root.getElementsByTagName("DomdocDocument");
				int nodeCount1 = docXMLnodes.getLength();
				for (int i=0; i < nodeCount1; i++) {
					if ((((Element)docXMLnodes.item(i)).getAttribute("docunid")).equals(docunid)) {
						root.removeChild(docXMLnodes.item(i));
						break;
					}
				}
				//Insert child XML according to the version number
				Float currentVer = Float.parseFloat(docXML.getAttribute("version"));
				Node insertBeforeNode = null;
				int nodeCount2 = docXMLnodes.getLength();
				//System.out.println("nodeCount2="+nodeCount2);
				for (int i=0; i < nodeCount2; i++) {
					if (Float.parseFloat((((Element)docXMLnodes.item(i)).getAttribute("version"))) > currentVer) {
						insertBeforeNode = docXMLnodes.item(i);
						break;
					}
				}
				root.insertBefore(sharedXML.importNode(docXML, true), insertBeforeNode);
			} else {
				sharedXML = docBuilder.newDocument();
				root = sharedXML.createElement("DocumentBundle");
				root.setAttribute("docid", docid);
				sharedXML.appendChild(root);
				root.appendChild(sharedXML.importNode(docXML, true));
			}

			//Export resulting XML to the file system
			TransformerFactory tf = TransformerFactory.newInstance();
			//tf.setAttribute("indent-number", new Integer(2));
			Transformer trans = tf.newTransformer();
			trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			trans.setOutputProperty(OutputKeys.INDENT, "no");
			StreamResult result = new StreamResult(sharedFile);
			DOMSource source = new DOMSource(sharedXML);
			log4j.info("Saving metadata into " + sharedFile);
			trans.transform(source, result);
		
		}catch (TransformerConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
	}
	



	/**
	 * lookupUPI method is invoked in the following manner
	 * processAttributes -> processAttribute -> executeOperation -> method.invoke(null, item)
	 * @param item
	 * @return void
	 * @throws DOMException
	 * @throws NotesException
	 */
	@SuppressWarnings("unused")
	private static void lookupUPI(Node item) throws DOMException, NotesException {
		Node node = item.getFirstChild();
		String entry = node.getNodeValue();
		if (entry.length() == 0) {
			return;
		}
		if (entry.charAt(0) == '[') {  // role name
			return;
		}
		lotus.domino.Document entryDoc = IFCNAB.getInstance().getView("($Users)").getDocumentByKey(entry, true);
		if (entryDoc == null) {
			entryDoc = WBNAB.getInstance().getView("($Users)").getDocumentByKey(entry, true);
		}
		if (entryDoc == null) {
			log4j.warn("Name \"" + entry + "\" was not found in the NAB during UPI lookup.");
			return;
		}
		if (entryDoc.getItemValueString("Type").equals("Group")) { //group name
			return;
		}
		String UPI = entryDoc.getItemValueString("UPI");
		if (UPI.length() == 0) {
			log4j.warn("UPI for the name \"" + entry + "\" is blank or was not found during UPI lookup.");
			return;
		}
		node.setNodeValue(UPI);		
		//IFCNAB.recycle();
		//WBNAB.recycle();
	}

}
