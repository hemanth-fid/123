/***************************************************************************
 * State Farm
 * Version Template: 2012
 *
 * File Name: IExportProcessQueryDao.java
 *
 * Version     ChgDate          Author           Comments
 * ________   __________       ________         ___________
 * 1.0        05/31/2013         t7p9        Initial Creation 
 *
 ***************************************************************************/
package sf.application.custcomm.ccs.dao;

import java.util.List;
import java.util.Map;

import sf.application.custcomm.ccs.exceptions.QueryException;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfSession;

public interface ICleanUpQueryDao {

	



	/**
	 * It retrieves the count of the objects by executing a query.
	 * 
	 * @param queryString
	 *            Query to be executed
	 * @param values
	 *            values that needs to be replaced in query
	 * @param session
	 *            Documentum session
	 * @return Integer output attribute value
	 * 
	 * @throws QueryException
	 *             Custom Exception used within the export services module
	 */
	public int getQueryCount(String queryString, Object[] values, IDfSession session) throws QueryException;



	

	/**
	 * It returns the query results in a form of list of objects.
	 * 
	 * @param session
	 *            Documentum session
	 * @param queryString
	 *            Query to be executed
	 * @param values
	 *            Values that needs to be replaced in query
	 * @param attributeName
	 *            Contains attribute name whose value needs to be fetched
	 * @param dataType
	 *            Determines the data type of the attribute name
	 * @return List of objects
	 * @throws QueryException
	 *             Custom Exception used within the export services module
	 */
	public List<String> getMarkedAsPurgeFolderIds(IDfSession session,
			String queryString,Object[] values) throws QueryException ;
	
	
	
	public List<String> getFolderContents(IDfSession session,
			String queryString,Object[] values) throws QueryException;
	
	
	public String executeContentDestroy(IDfSession session,
			String queryString,Object[] values) throws QueryException;
	
	
	public List<String> getDmrContentIds(IDfSession session,
			String queryString,Object[] values) throws QueryException;
	
	
	public  int getParentCount(IDfSession session,
			String queryString, Object[] values) throws QueryException;
	
	
	public  List<String> getFilesFromRepo(IDfSession session,
			String queryString, Object[] values) throws QueryException;
	
	
	public String getQueryStringValue(String queryString, String attributeName, int queryType, IDfSession session)
			throws QueryException ;
	
	
	public String queryExecute(String dql, Object[] values, IDfSession session)
			throws QueryException ;;

	
}
