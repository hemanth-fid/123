/**
* This class provides the reporting details of the Workflow.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.workflow.reportdetails;

import com.documentum.fc.client.IDfProcess;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.services.workflow.report.IWorkflowReport;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.Link;
import com.documentum.web.formext.control.docbase.DocbaseIcon;

public class ReportDetailsHeader extends  com.documentum.webcomponent.library.workflow.reportdetails.ReportDetailsHeader{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void onInit(ArgumentList args)
	  {
	    super.onInit(args);

	    this.m_component = args.get("component");
	    try
	    {
	    	DfLogger.info(this, " :: onInit : "+getDfSession().getLoginUserName(), null, null);
	    	updateControls();
	    }
	    catch (DfException e)
	    {
	    	DfLogger.error(this, " :: onInit Exception >> "+e.getMessage(), null, e);
	    	throw new WrapperRuntimeException(e);
	    }
	  }

	
	protected void updateControls()
    throws DfException
  {
    DocbaseIcon docIconControl = (DocbaseIcon)getControl("__DOCBASE_ICON_CONTROL_NAME", DocbaseIcon.class);
    docIconControl.setType("dm_workflow");

    IWorkflowReport wfReport = getWorkflowReport(true);

    Label labelControl = (Label)getControl("__WORKFLOW_NAME_CONTROL_NAME", Label.class);
    labelControl.setLabel(getProcessName(wfReport));
   
    Link linkControl = (Link)getControl("__WORKFLOW_SUPERVISOR_CONTROL_NAME", Link.class);
    linkControl.setLabel(getWorkflowSupervisor(wfReport));

    labelControl = (Label)getControl("__WORKFLOW_STATUS_CONTROL_NAME", Label.class);
    labelControl.setLabel(getWorkflowStatus(wfReport));

    labelControl = (Label)getControl("__WORKFLOW_START_DATE_CONTROL_NAME", Label.class);
    labelControl.setLabel(getWorkflowStartDate(wfReport));
  }
	
	  protected String getProcessName(IWorkflowReport wfReport)
	    throws DfException
	  {
	    if (wfReport == null)
	      return null;
	    IDfId  id = wfReport.getProcessId();
	    IDfProcess dfProcess = (IDfProcess)getDfSession().getObject(id);
	    
	    return dfProcess.getObjectName();
	  }
}
