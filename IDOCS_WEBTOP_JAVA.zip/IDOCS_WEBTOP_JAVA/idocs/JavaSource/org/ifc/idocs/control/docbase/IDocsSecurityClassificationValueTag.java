/**
 * IDocsSecurityClassificationValueTag - Tag class to change the behavior of 
 * attributes in idocs application UI.
 * @author SKurian1
 * 
 * #####################################################################
 * Author		DateofChange	Version		ModificationHistory
 * #####################################################################
 * 
 * #####################################################################
 */
package org.ifc.idocs.control.docbase;

import java.io.IOException;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfValueAssistance;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfList;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfTime;
import com.documentum.fc.common.IDfList;
import com.documentum.fc.common.IDfTime;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.control.DateTime;
import com.documentum.web.form.control.DropDownList;
import com.documentum.web.form.control.DropDownListTag;
import com.documentum.web.form.control.OptionTag;
import com.documentum.web.formext.Trace;
import com.documentum.web.formext.control.docbase.DocbaseAttributeCache;
import com.documentum.web.formext.control.docbase.DocbaseAttributeValue;
import com.documentum.web.formext.control.docbase.DocbaseAttributeValueTag;
import com.documentum.web.formext.control.docbase.DocbaseObject;
import com.documentum.web.formext.control.docbase.IDocbaseAttributeValueFormatter;
import com.documentum.web.formext.docbase.ServerUtil;
import com.documentum.web.util.DateUtil;

/**
 * This class is to control the behavior of the security_classification
 * attribute in the idocs application.
 * This marks the attribute as read only for the users who does not have the 
 * CHANGE_PERMIT extended permit on the document.
 * @author SKurian1
 *
 */
public class IDocsSecurityClassificationValueTag extends DocbaseAttributeValueTag {
	private static final String R_FULL_CONTENT_SIZE = "r_full_content_size";
	private static final String R_CONTENT_SIZE = "r_content_size";
	private static final String MSG_NON_OFFICIAL_TEMPLATES = "MSG_NON_OFFICIAL_TEMPLATES";
	/**
	 * 
	 */
	private static final long serialVersionUID = -3368052167667006276L;
	public IDocsSecurityClassificationValueTag() {
		DfLogger.debug(this, " : IDocsSecurityClassificationValueTag >> ", null, null);
	}
	
	/**
	 * This method will render the security classification attribute as ReadOnly
	 * if the logged in user don't have ChangePermit permission on the object.
	 */
	protected void renderSingleAttribute(String strFormattedValue,
			String strValue, boolean bReadonly, boolean bHasCompleteList,
			JspWriter out) throws IOException, JspTagException {
		DfLogger.info(this, " : renderSingleAttribute() : bReadonly = " + bReadonly, null, null);
		if(bReadonly==false){
			DocbaseAttributeValue value = (DocbaseAttributeValue)getControl();
			StringBuffer newValueBuf = new StringBuffer(); 
			out.print("<table><tr><td>");
	         renderVAControls(strValue, newValueBuf, !bHasCompleteList, true, out);
	         String strNewValue = newValueBuf.toString();
	         if(!strNewValue.equals(strValue))
	         {
	             DocbaseObject obj = (DocbaseObject)getForm().getControl(value.getObject());
	             if(obj == null)
	                 throw new WrapperRuntimeException((new StringBuilder()).append("Failed to find associated docbaseobject control:").append(value.getObject()).toString());
	             String strAttr = value.getAttribute();
	             strAttr = substituteAttribute(strAttr);
	             IDocbaseAttributeValueFormatter valueFormatter = obj.getAttributeValueFormatterInstance(strAttr);
	             strFormattedValue = getFormattedValue(strNewValue, valueFormatter);
	         }
	         out.print("</td><td>");
	         out.print("</td></tr></table>");
		}else{
			super.renderSingleAttribute(strFormattedValue, strValue,bReadonly, bHasCompleteList, out);
		}
		DfLogger.debug(this, " : renderSingleAttribute() : Leave ", null, null);
	}
	
	private String substituteAttribute(String strAttribute)
    {
        String strRet = strAttribute;
        if(R_CONTENT_SIZE.equalsIgnoreCase(strAttribute) && ServerUtil.compareDocbaseVersion(5, 1))
        {
            strRet = R_FULL_CONTENT_SIZE;
            setAttribute(strRet);
            DocbaseAttributeValue value = (DocbaseAttributeValue)getControl();
            value.setAttribute(strRet);
        }
        return strRet;
    }
	
	protected void renderVAControls(String strValue, StringBuffer newValueBuf, boolean bEditable, boolean bVisible, JspWriter out){
		DocbaseAttributeValue value = (DocbaseAttributeValue)getControl();
        String strClass = value.getCssClass();
        String strStyle = value.getCssStyle();
        DropDownListTag dropDownList = new DropDownListTag();
        dropDownList.setPageContext(pageContext);
        dropDownList.setParent(this);
        if(strClass != null)
            dropDownList.setCssclass(strClass);
        if(strStyle != null)
            dropDownList.setStyle(strStyle);
        dropDownList.setId(getId());
        dropDownList.setTooltip(value.getToolTip());
        dropDownList.setName(value.getElementName("vavalue"));
        try
        {
            DropDownList dropDownListObj = (DropDownList)dropDownList.getControl();
            if(!value.isEnabled())
                dropDownListObj.setEnabled(false);
            else
                dropDownListObj.setEnabled(true);
            if(!bVisible)
            {
                dropDownListObj.setVisible(false);
            } else
            {
                if(bEditable)
                {
                    int widthThreshold = 256;
                    dropDownListObj.setEditable(true);
                    value.setSize(null);
                    int valSize = Integer.parseInt(value.getSize());
                    if(valSize * 8 > widthThreshold)
                        dropDownListObj.setWidth(Integer.toString(widthThreshold));
                    else
                        dropDownListObj.setWidth(Integer.toString(valSize * 8));
                    dropDownListObj.setAutoCompleteId((new StringBuilder()).append("DBAttr_").append(value.getAttribute()).toString());
                }
                dropDownListObj.setIsRemovable(false);
                dropDownListObj.setVisible(true);
                dropDownListObj.setMutable(true);
                dropDownListObj.clearOptions();
                dropDownListObj.removeContainedControls();
                dropDownListObj.setValue(strValue);
                dropDownListObj.setRunAtClient(true);
                dropDownListObj.setEventHandler("onselect", "preprocessEvent", null);
                dropDownList.addEventArg("controlName", dropDownListObj.getElementName());
                dropDownList.addEventArg("handlerName", value.getElementName());
//                renderSetEvents(dropDownListObj.getElementName(), value.getVaDependenciesProperties(), out);
                DocbaseAttributeCache.updateAttributeAndDependentList(value.getAttribute(), dropDownListObj.getElementName(), value.getVaDependenciesProperties());
                dropDownList.doStartTag();
                renderVAOptions(dropDownList);
                if(strValue != null && strValue.trim().length() >0){
                	DfLogger.debug(this, "Current Value : strValue="+strValue, null, null);  
                	if(folderSecurityClassification != null && folderSecurityClassification.trim().length() > 0){
                		if(folderSecurityClassification.equals(IDocsConstants.MSG_OFFICIAL_CODE)) {
	        				if(strValue.equals(IDocsConstants.MSG_STRICTLY_CONFIDENTIAL)){
	        					strValue = IDocsConstants.MSG_STRICTLY_CONFIDENTIAL;
	        				}else if(strValue.equals(IDocsConstants.MSG_CONFIDENTIAL)){
	        					strValue = IDocsConstants.MSG_CONFIDENTIAL;
	        				}else{
	        					strValue = IDocsConstants.MSG_OFFICIAL_USE_ONLY;
	        				}
                		}else if(folderSecurityClassification.equals(IDocsConstants.MSG_CONFIDENTIAL_CODE)) {
	        				if(strValue.equals(IDocsConstants.MSG_STRICTLY_CONFIDENTIAL)){
	        					strValue = IDocsConstants.MSG_STRICTLY_CONFIDENTIAL;
	        				}else{
	        					strValue = IDocsConstants.MSG_CONFIDENTIAL;
	        				}
	        			}else{
	        				strValue = IDocsConstants.MSG_STRICTLY_CONFIDENTIAL;
	        			}
                		DfLogger.debug(this, "Set Parent Folder Security Classification as Default : strValue"+strValue, null, null);
	                	dropDownListObj.setValue(strValue);
	                }
                }else{
	                if(folderSecurityClassification != null && folderSecurityClassification.trim().length() > 0){
	                	if(folderSecurityClassification.equals(IDocsConstants.MSG_OFFICIAL_CODE)) {
	                		strValue = IDocsConstants.MSG_OFFICIAL_USE_ONLY;
	        			} else if(folderSecurityClassification.equals(IDocsConstants.MSG_CONFIDENTIAL_CODE)) {
	        				strValue = IDocsConstants.MSG_CONFIDENTIAL;
	        			} else if(folderSecurityClassification.equals(IDocsConstants.MSG_STRICTLY_CONFIDENTIAL_CODE)) {
	        				strValue = IDocsConstants.MSG_STRICTLY_CONFIDENTIAL;
	        			}
	                	DfLogger.debug(this, "Set Parent Folder Security Classification as Default : strValue"+strValue, null, null);
	                	dropDownListObj.setValue(strValue);
	                }
                }
                dropDownList.doEndTag();
                dropDownListObj.setRunAtClient(false);
                dropDownListObj.setEventHandler("onselect", "onHandleChangedValues", value);
                newValueBuf.append(dropDownListObj.getValue());
            }
        }
        catch(JspTagException e)
        {
            throw new WrapperRuntimeException(e);
        }
    }

    private synchronized void renderVAOptions(DropDownListTag dropDownList)
    {
        DocbaseAttributeValue value = (DocbaseAttributeValue)getControl();
        try
        {
            boolean bHasValueAssistance = value.hasValueAssistance();
            boolean bRequired = value.isRequired();
            if(bHasValueAssistance)
            {
                if(!bRequired)
                {
                    OptionTag emptyOption = new OptionTag();
                    emptyOption.setPageContext(pageContext);
                    emptyOption.setName((new StringBuilder()).append(value.getElementName("value")).append("0").toString());
                    emptyOption.setValue("");
                    emptyOption.setLabel("");
                    emptyOption.setParent(dropDownList);
                    emptyOption.doStartTag();
                    emptyOption.doEndTag();
                }
                DropDownList dropDownListObj = (DropDownList)dropDownList.getControl();
                dropDownListObj.setForceSelection(bRequired);
                    IDfValueAssistance valueAssistance = value.getValueAssistance();
                    if(valueAssistance == null){
//                        valueAssistance = value.getObjectValueAssistance();
                    }
                    if(valueAssistance != null)
                    {
                        value.setValueAssistance(valueAssistance);
                        IDfList actualValues = valueAssistance.getActualValues();
                        IDfList displayValues = valueAssistance.getDisplayValues();
                        if (value.getAttribute().equalsIgnoreCase(IDocsConstants.MSG_SEC_CLASSIFICATION)) {
                        	try{
                        		IDfSysObject sysObject = null;
                        		DocbaseObject docbaseObject = (DocbaseObject) getForm().getControl(value.getObject());
                        		IDfPersistentObject persistentObject = docbaseObject.getDfObject();
                        		if(persistentObject != null && persistentObject instanceof IDfSysObject){
                        			sysObject = (IDfSysObject) persistentObject;
                        			String currentObjectId = sysObject.getObjectId().getId();
                        			String templateTitle = IdocsUtil.getTemplateTitle(sysObject.getObjectSession(), currentObjectId);
                        			DfLogger.debug(this, "Parent Folder Security Classification : currentObjectId="+currentObjectId, null, null);
                        			folderSecurityClassification = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(sysObject.getObjectSession(), sysObject.getFolderId(0).getId(), 
                        					IDocsConstants.MSG_SEC_CLASSIFICATION_CODE, IDocsConstants.MSG_IDOCS_FOLDER);
                        			DfLogger.debug(this, "Parent Folder Security Classification ="+folderSecurityClassification, null, null);
                        			if(folderSecurityClassification != null && folderSecurityClassification.trim().length() > 0){ 
                        				actualValues.removeAll();
                						displayValues.removeAll();
	                        			if(folderSecurityClassification.equals(IDocsConstants.MSG_OFFICIAL_CODE)) {
	                        				if(canThisBeOfficialDoc(sysObject.getObjectSession(),templateTitle)){
	                        					actualValues.append(IDocsConstants.MSG_OFFICIAL_USE_ONLY);
	                        					displayValues.append(IDocsConstants.MSG_OFFICIAL_USE_ONLY);
	                        				}
	                        				actualValues.append(IDocsConstants.MSG_CONFIDENTIAL);
	                        				displayValues.append(IDocsConstants.MSG_CONFIDENTIAL);
	                        				actualValues.append(IDocsConstants.MSG_STRICTLY_CONFIDENTIAL);
	                        				displayValues.append(IDocsConstants.MSG_STRICTLY_CONFIDENTIAL);
	                        			} else if(folderSecurityClassification.equals(IDocsConstants.MSG_CONFIDENTIAL_CODE)) {
	                        				actualValues.append(IDocsConstants.MSG_CONFIDENTIAL);
	                        				displayValues.append(IDocsConstants.MSG_CONFIDENTIAL);
	                        				actualValues.append(IDocsConstants.MSG_STRICTLY_CONFIDENTIAL);
	                        				displayValues.append(IDocsConstants.MSG_STRICTLY_CONFIDENTIAL);
	                        			} else if(folderSecurityClassification.equals(IDocsConstants.MSG_STRICTLY_CONFIDENTIAL_CODE)) {
	                        				actualValues.append(IDocsConstants.MSG_STRICTLY_CONFIDENTIAL);
	                        				displayValues.append(IDocsConstants.MSG_STRICTLY_CONFIDENTIAL);
	                        			}
                        			}else{
                        				DfLogger.debug(this, "Parent Folder Security Classification Is Null", null, null);
                        			}
                        		}
                        	}catch (Exception e) {
                        		DfLogger.error(this, "Security Classification Calculation failed :"+e.getMessage(), null, null);
							}
                        		
                        }
                        int listCount;
                        if(Trace.DOCBASEATTR)
                        {
                            listCount = displayValues.getCount();
                            Trace.println(value.getAttribute());
                            Trace.println("DocbaseAttrValueTag::RenderVAOptions()");
                            for(int i = 0; i < listCount; i++)
                            {
                                String displayValue = displayValues.getString(i);
                                Trace.println((new StringBuilder()).append("\tdisplay(").append(i).append("): ").append(displayValue).toString());
                            }

                        }
                        listCount = actualValues.getCount();
                        IDfList displayValueList = new DfList(2);
                        for(int i = 0; i < listCount; i++)
                        {
                            String actualValue = actualValues.getString(i);
                            String displayValue = displayValues.getString(i);
                            if(value.getDataType() == 4 && actualValue != null)
                            {
                                actualValue = formatDateTime(actualValue);
                                displayValue = actualValue;
                            }
                            displayValueList.appendString(actualValue);
                            renderVAOptionsHelper(dropDownList, actualValue, displayValue, i + 1);
                        }

                        if(!bRequired && listCount > 0)
                        {
                            String actualValue = actualValues.getString(0);
                            setDropdownListDefaultVaValue(dropDownListObj, actualValue, bRequired);
                        }
                        String strPreviousValue = dropDownListObj.getValue();
                        if(!dropDownListObj.isEditable() && bRequired && strPreviousValue != null && displayValueList.findStringIndex(strPreviousValue) < 0)
                        {
                            dropDownListObj.setValue("");
                            value.setDirty();
                        }
                    }
                }
//            }
        }
        catch(DfException e)
        {
            throw new WrapperRuntimeException(e);
        }
        catch(JspTagException e)
        {
            throw new WrapperRuntimeException(e);
        }
    }
    
    /**
     * There are few templates those cannot be created as Official. Those template 
     * titles are stored in idocsProperties. This method will tell if the given 
     * template can be created as Official Document.
     * 
     * @param objectSession
     * @param templateTitle
     * @return
     */
    private boolean canThisBeOfficialDoc(IDfSession objectSession,
			String templateTitle) {
    	try {
			String nonOfficialTemplates = IdocsUtil.getMessage(MSG_NON_OFFICIAL_TEMPLATES);
			if(nonOfficialTemplates !=null && nonOfficialTemplates.trim().length() > 0
					&& IdocsUtil.checkIfTokenPresent(nonOfficialTemplates, templateTitle, IdocsConstants.MSG_COMMA)){
				DfLogger.debug(this, "canThisBeOfficialDoc :: This document cannot be created as official.", null, null);
				return false;
			}
		} catch (Exception e) {
			DfLogger.error(this, "canThisBeOfficialDoc :: Exception :"+e.getMessage(), null, null);
		}
    	return true;
	}

	private void renderVAOptionsHelper(DropDownListTag dropDownList, String strActualValue, String strDisplayValue, int nIndex)
    {
        DocbaseAttributeValue value = (DocbaseAttributeValue)getControl();
        try
        {
            OptionTag option = new OptionTag();
            option.setPageContext(pageContext);
            option.setName((new StringBuilder()).append(value.getElementName("value")).append(nIndex).toString());
            option.setValue(strActualValue);
            option.setLabel(strDisplayValue);
            option.setParent(dropDownList);
            option.doStartTag();
            option.doEndTag();
        }
        catch(JspTagException e)
        {
            throw new WrapperRuntimeException(e);
        }
    }
    
    private void setDropdownListDefaultVaValue(DropDownList dropDownListObj, String strActualValue, boolean bRequired)
    {
        DocbaseAttributeValue value = (DocbaseAttributeValue)getControl();
        if(bRequired)
        {
            String strValue = dropDownListObj.getValue();
            if(strValue == null || strValue.equals(""))
            {
                dropDownListObj.setValue(strActualValue);
                value.onHandleChangedValues(dropDownListObj, null);
                value.setDirty();
            }
        }
    }
    
    private String formatDateTime(String strDate)
    {
        if(strDate == null)
            return null;
        try
        {
            java.text.DateFormat formatter = DateUtil.getDateTimeFormat(2, 2);
            IDfTime time = new DfTime(strDate, formatter);
            strDate = DateTime.toValue(time.getDate());
        }
        catch(Exception e)
        {
            if(Trace.DOCBASEATTR)
                Trace.error((new StringBuilder()).append("Error occured while formating date. Date Value : ").append(strDate).toString(), e);
        }
        return strDate;
    }
    
    private String folderSecurityClassification = null;
}
