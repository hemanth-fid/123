/**
* This class provides the summary of the Workflow Task.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################################################
*/
package org.ifc.idocs.workflow.reportdetails;


import com.documentum.web.common.ArgumentList;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.control.databound.DataProvider;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.webcomponent.library.workflow.ScrollableResultSetAdapter;
import com.documentum.webcomponent.common.WebComponentErrorService;

public class ReportDetailsSummary extends com.documentum.webcomponent.library.workflow.reportdetails.ReportDetailsSummary
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ReportDetailsSummary(){
		DfLogger.info(this, " :: ReportDetailsSummary()",null,null);
	}

	public void onInit(ArgumentList arg)
	{
		super.onInit(arg);
		try {
			DfLogger.info(this, " :: onInit : "+getDfSession().getLoginUserName(), null, null);
		} catch (DfException e) {
			DfLogger.error(this, " :: onInit Exception >> "+e.getMessage(), null, e);
		}
	}

	public void onRefreshData()
	{
		DfLogger.info(this, " :: onRefreshData : ", null, null);
		super.onRefreshData();
		try{			
			updateControls();
		} catch(Exception e) {
			DfLogger.error(this, " :: onRefreshData Exception >> "+e.getMessage(), null, e);
		}
	} 

	protected void updateControls()
	{
		DfLogger.info(this, " :: updateControls ",null,null);
		updateContext();
		updateShowAttachmentCheckbox();
		updateReportDataGrid();
	}

	protected void updateReportDataGrid()
	{
		Datagrid datagrid;
		DfLogger.info(this, " :: updateReportDataGrid.",null,null);
		try
		{
			datagrid = (Datagrid)getControl("__DATAGRID_CONTROL_NAME", Datagrid.class);
			if (datagrid != null)
			{
				datagrid.setVisibleColumns(this.m_visibleColumns);

				this.m_reportResultSet = new ReportDetailsSummaryResultSet(this, getReportService(), getNlsClass(), this.m_workflowId, this.m_showFilter, this.m_showAttachments);

				this.m_scrollResultSet = new ScrollableResultSetAdapter(this.m_reportResultSet);

				DataProvider provider = datagrid.getDataProvider();

				if (provider.getDataHandler() != null)
				{
					provider.refresh(this.m_scrollResultSet);
				}
				else
				{
					provider.setScrollableResultSet(this.m_scrollResultSet);
				}
			}
		}
		catch (DfException e)
		{
			WebComponentErrorService.getService().setNonFatalError(getNlsClass(), "MSG_NEXT_ITEM_ERROR", this, null, e);
			DfLogger.error(this, " :: updateReportDataGrid Exception >> "+e.getMessage(),null,e);
		}
		catch (WrapperRuntimeException e2)
		{
			WebComponentErrorService.getService().setNonFatalError(getNlsClass(), "MSG_NEXT_ITEM_UNEXPECTED_ERROR", this, null, e2);
			DfLogger.error(this, " :: updateReportDataGrid Exception >> "+e2.getMessage(),null,e2);
		}
	}
}