package org.ifc.idocs.migration.helper;

import org.owasp.esapi.ESAPI;
import org.owasp.esapi.errors.EncryptionException;
import org.worldbank.wbsapi.exception.SecurityException;
import org.worldbank.wbsapi.util.EncryptionService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.documentum.fc.client.DfAuthenticationException;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.DfIdentityException;
import com.documentum.fc.client.DfPrincipalException;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfVersionLabels;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.fc.tools.RegistryPasswordUtils;
import com.documentum.webcomponent.library.contenttransfer.SysobjectContentTransferComponent;

import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.logging.Level;

public class TesttingCode {

	public static void main(String[] args) {
		
		try {
			
			/*			String newdateTime = "22/12/2008";
			newdateTime = newdateTime+" 02:00:00 AM EST";
			Date date = new Date(newdateTime);
			DateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a z"); 
			String dStr = df.format(date); 
			System.out.println("dStr::::"+dStr);
			ArrayList arr = new ArrayList();
			arr.add("hema");
			if(arr.contains("hema")){
				System.out.println("asdasdf");
			}
			
			String[] prjMetadataList = "Project_id,PciWfNbr,PciWfTypeCode".split(",");
			for(int p=0;p<prjMetadataList.length;p++){
				System.out.println(prjMetadataList[p]);;
			}
			System.out.println("asdasdf");
			String a = "Hemachandra anuganti";
			System.out.println(a.length());
			System.out.println(a.substring(0, 19));
		*/	
			String strDocbase = "ifcecmidocs";
			String strUserName = "idocsmigrusrprd";
			String strPassword = "Ifcd0c$Web@dm";
			String pwd = "WmDLLNvNUvl4Xu4eOGSHoQ==";
			String dec = ESAPI.encryptor().decrypt(pwd);
			System.out.println(dec);
			System.out.println(ESAPI.encryptor().encrypt(dec));
			
			IDfSessionManager sessionMgr = getSessionMgr(strUserName,pwd, strDocbase);
			IDfSession dfSession = sessionMgr.getSession(strDocbase);
			System.out.println(dfSession.getDocbaseName());
			System.out.println(dfSession.getLoginUserName());
			
			
			/*String strDirectoy ="test";
			  String strManyDirectories="dir1/dir2/dir3";
			  
			// Create one directory
			  boolean success = (new File(strDirectoy)).mkdir();
			  if (success) {
			  System.out.println("Directory: " + strDirectoy + " created");
			  }  
			  
			  // Create multiple directories
			  success = (new File(strManyDirectories)).mkdirs();
			  if (success) {
			  System.out.println("Directories: " + strManyDirectories + " created");
			  }*/
		/*	String location = "c:\\MyFolder\\Hema\\Hello\\AA";
			 File f = new File(location);
			 if(f.exists()){
				  System.out.println("Directory Already Exists");
			 }else{
				 f.mkdirs();
				 System.out.println("Directory Created Successfully");
			 }*/
		     
			  
		/*String strDocbase = "ifcecmtstidocs";
		String strUserName = "idocsmigrusr";
		String strPassword = "ifc@mIgru3r";
		String rObjectID = "09004e22808df03c";
//		String lifecycleName = "iDocs_lifecycle";
		IDfSessionManager sessionMgr = getSessionMgr(strUserName, strPassword, strDocbase);
		IDfSession dfSession = sessionMgr.getSession(strDocbase);
		IDfDocument newDoc = (IDfDocument)dfSession.getObject(new DfId(rObjectID));*/

		
//		System.out.println("Reading Date CreatedDate_orig_filed_idocs_date::"+newDoc.getString("orig_filed_idocs_date"));
			
		String CreatedDate_orig_filed_idocs_date = "4/18/1931 4:00:50 PM";
		String CreatedDate_orig_filed_idocs_date_1 = "9/29/2004 11:38:47 AM";
		String CreatedDate_orig_filed_idocs_date_2 = "9/29/2004 11:38:47 AM EDT";
		String CreatedDate_orig_filed_idocs_date_3 = "9/29/2004 11:38:47 AM EST";
		String CreatedDate_orig_filed_idocs_date_4 = "9/29/2004";
		String CreatedDate_orig_filed_idocs_date_5 = "20-Oct-09";
		
		String dateTime= "9/29/2004 05:30:00 PM PST";
		System.out.println("dateTime::"+dateTime);
		if(dateTime !="" && dateTime !=null){
			dateTime = dateTime.trim();
			try{
				dateTime = dateTime.replaceAll("\\\\", "/");
				String[] nDate = dateTime.split(":");
				if(nDate.length ==2){
					if(nDate[1].contains(" ")){
						String timeStr = nDate[1].replaceAll(" ", ":00 ");
						dateTime = nDate[0]+":"+timeStr+" EST";
						System.out.println("333::dateTime:::"+dateTime);
//						return convertDateToCSDate(nDate[0]+":"+timeStr);
//						return dateTime;
					}else{
						System.out.println("22::Invalid date::"+dateTime);
//						return dateTime;
					}
				}else{
					if(dateTime.contains("EDT")){
//						dateTime = dateTime.replace("EDT","").trim();
//						return convertDateToCSDate(dateTime);
//						return dateTime;
						System.out.println("EDT Time::"+dateTime);
					}else if(dateTime.contains("EST")){
//						dateTime = dateTime.replace("EDT","").trim();
//						return convertDateToCSDate(dateTime);
//						return dateTime;
						System.out.println("EST Time::"+dateTime);
					}else {
						if(dateTime.contains(" ")){
							if (dateTime.contains("AM") || dateTime.contains("PM")){
								//check for time zone
								//if time zone doesnt exists then add EST and send it
									//if time zone found
									//get the time zone
									//convert to EST and send it
								//else add EST time zone at the end and send it
								
								if(dateTime.contains("AM") && (dateTime.substring(0, dateTime.indexOf("AM")+2).length()!=dateTime.length())){
									String timez = dateTime.substring(dateTime.indexOf("AM")+3, dateTime.length());
									System.out.println("AM timez::"+timez);
									//if time zone found
									//get the time zone
									//convert to EST and send it
									convertDateToESTDate(dateTime,timez);
								}else if(dateTime.contains("PM") && (dateTime.substring(0, dateTime.indexOf("PM")+2).length()!=dateTime.length())){
									String timez = dateTime.substring(dateTime.indexOf("PM")+3, dateTime.length());
									System.out.println("PM timez::"+timez);
									//if time zone found
									//get the time zone
									//convert to EST and send it
									convertDateToESTDate(dateTime,timez);
								}else{
									System.out.println("Date Does not contain time zone::"+dateTime);
									if(dateTime.contains("AM")){
										System.out.println("Time contains AM::"+dateTime);
										System.out.println("Added EST to the time::"+dateTime+" EST");
									}else if(dateTime.contains("PM")){
										System.out.println("Time contains PM::"+dateTime);
										System.out.println("Added EST to the time::"+dateTime+" EST");
									}
								}
							}else{
								System.out.println("Date doesnt contain AM and PM and it is an invalid date::"+dateTime);
							}
							System.out.println(dateTime);
						}else{
							//Treat this date as EST and save as is
							dateTime = dateTime+" 00:00:00 AM EST";
							System.out.println("Date Does not contain only 10 digits so formatted to EST::"+dateTime);
//							return dateTime;
//							return convertDateToCSDate(dateTime);
						}
					}
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}else{
			dateTime = "nulldate";
			System.out.println("dateTime::"+dateTime);
		}
		
		
		
		
		String[] nDate = CreatedDate_orig_filed_idocs_date.split(":");
		if(nDate.length ==2){
			System.out.println("Actual Date::"+CreatedDate_orig_filed_idocs_date);
			System.out.println(nDate[0]);
			if(nDate[1].contains(" ")){
				System.out.println(nDate[1]);
				String nd = nDate[1].replaceAll(" ", ":00 ");
				System.out.println(nDate[0]+":"+nd);
				convertDateToCSDate(nDate[0]+":"+nd);
			}

		}
		
		if(CreatedDate_orig_filed_idocs_date.contains("EDT")){
			CreatedDate_orig_filed_idocs_date = CreatedDate_orig_filed_idocs_date.replace("EDT","").trim();
			convertDateToCSDate(CreatedDate_orig_filed_idocs_date);
		}else if(CreatedDate_orig_filed_idocs_date.contains("EST")){
			CreatedDate_orig_filed_idocs_date = CreatedDate_orig_filed_idocs_date.replace("EDT","").trim();
			convertDateToCSDate(CreatedDate_orig_filed_idocs_date);
		}else {
			if(CreatedDate_orig_filed_idocs_date.contains(" ")){
				if (CreatedDate_orig_filed_idocs_date.contains("AM")){
					CreatedDate_orig_filed_idocs_date = CreatedDate_orig_filed_idocs_date.substring(0, CreatedDate_orig_filed_idocs_date.indexOf("AM")+2);
				}else if (CreatedDate_orig_filed_idocs_date.contains("PM")){
					CreatedDate_orig_filed_idocs_date = CreatedDate_orig_filed_idocs_date.substring(0, CreatedDate_orig_filed_idocs_date.indexOf("PM")+2);
				}else{
					CreatedDate_orig_filed_idocs_date = CreatedDate_orig_filed_idocs_date.substring(0, CreatedDate_orig_filed_idocs_date.lastIndexOf(" ")).trim();
				}
				convertDateToCSDate(CreatedDate_orig_filed_idocs_date);
			}else{
				convertDateToCSDate(CreatedDate_orig_filed_idocs_date);
			}
		}
		
		
		/*Date ESTDate = new Date("03/29/2007 01:15:05 AM");
		
		
		Date EDTDate = new Date("03/29/2007 01:15:05 AM");
		
		DateFormat utcFormat = new SimpleDateFormat();

		TimeZone utcTime = TimeZone.getTimeZone("UTC");
		utcFormat.setTimeZone(utcTime);

		System.out.println("UTC for EST Time: " + utcFormat.format(ESTDate));
		System.out.println("UTC for EDT Time: " + utcFormat.format(EDTDate));
		System.out.println(TimeZone.getDefault().inDaylightTime(new Date()));*/
				
				
/*		System.out.println("Before conversion CreatedDate_orig_filed_idocs_date: " + CreatedDate_orig_filed_idocs_date);
		CreatedDate_orig_filed_idocs_date = convertToEasternTime(CreatedDate_orig_filed_idocs_date);
		System.out.println("After  conversion CreatedDate_orig_filed_idocs_date: " + CreatedDate_orig_filed_idocs_date);		
		  
		newDoc.setString("document_date", CreatedDate_orig_filed_idocs_date);*/
		
	/*	newDoc.setString("doc_state", "Draft");
		newDoc.setRepeatingString("r_version_label", 2, "Draft");
		newDoc.setString("is_migrated", "T");
		newDoc.save();
		System.out.println("Saved Date CreatedDate_orig_filed_idocs_date::"+newDoc.getString("document_date"));*/

		
		
		
		//System.out.println("Saved Date LastModContent_document_date::"+newDoc.getString("document_date"));
		//System.out.println("Saved Date LastModProfile_metadata_modify_date::"+newDoc.getString("metadata_modify_date"));
		//System.out.println("Saved Date LastModContent_content_modify_date::"+newDoc.getString("content_modify_date"));
		
		/*String CreatedDate_orig_filed_idocs_date = "03/29/2007 04:39:49 PM EDT";
		String DocumentDate_document_date = "03/29/2007";
		String LastModProfile_metadata_modify_date = "03/29/2007 07:00:17 PM EDT";
		String LastModContent_content_modify_date = "03/29/2007 04:39:49 PM EDT";*/
		  
		
		/*String CreatedDate_orig_filed_idocs_date = "03/29/2007 04:39:49 AM EDT";
		String DocumentDate_document_date = "03/29/2007";
		String LastModProfile_metadata_modify_date = "03/29/2007 07:00:17 AM EDT";
		String LastModContent_content_modify_date = "03/29/2007 04:39:49 AM EDT";*/
		
		/*String CreatedDate_orig_filed_idocs_date = "03/29/2007 00:39:49 AM EDT";
		String DocumentDate_document_date = "03/29/2007";
		String LastModProfile_metadata_modify_date = "03/29/2007 00:00:17 AM EDT";
		String LastModContent_content_modify_date = "03/29/2007 00:39:49 AM EDT";

		System.out.println("Before conversion CreatedDate_orig_filed_idocs_date: " + CreatedDate_orig_filed_idocs_date);
		CreatedDate_orig_filed_idocs_date = convertToEDT(CreatedDate_orig_filed_idocs_date);
		System.out.println("After  conversion CreatedDate_orig_filed_idocs_date: " + CreatedDate_orig_filed_idocs_date);		
		  
		newDoc.setString("document_date", CreatedDate_orig_filed_idocs_date);
		
		newDoc.save();
		System.out.println("Saved Date CreatedDate_orig_filed_idocs_date::"+newDoc.getString("document_date"));
*/		
		//YSS 
/*		System.out.println("Before conversion DocumentDate_document_date: " + DocumentDate_document_date);
		DocumentDate_document_date = convertToEDT(DocumentDate_document_date);
		System.out.println("After  conversion DocumentDate_document_date: " + DocumentDate_document_date);		
		  
		newDoc.setString("document_date", DocumentDate_document_date);
		
		newDoc.save();
		System.out.println("Saved Date DocumentDate_document_date::"+newDoc.getString("document_date"));
		
		System.out.println("Before conversion LastModProfile_metadata_modify_date: " + LastModProfile_metadata_modify_date);
		LastModProfile_metadata_modify_date = convertToEDT(LastModProfile_metadata_modify_date);
		System.out.println("After  conversion LastModProfile_metadata_modify_date: " + LastModProfile_metadata_modify_date);		
		  
		newDoc.setString("document_date", LastModProfile_metadata_modify_date);
		
		newDoc.save();
		System.out.println("Saved Date LastModProfile_metadata_modify_date::"+newDoc.getString("document_date"));
		
		System.out.println("Before conversion LastModContent_content_modify_date: " + LastModContent_content_modify_date);
		LastModContent_content_modify_date = convertToEDT(LastModContent_content_modify_date);
		System.out.println("After  conversion LastModContent_content_modify_date: " + LastModContent_content_modify_date);		
		  
		newDoc.setString("document_date", LastModContent_content_modify_date);
		
		newDoc.save();
		System.out.println("Saved Date LastModContent_content_modify_date::"+newDoc.getString("document_date"));
		*/
		
		
		/*StringBuffer strBuff = new StringBuffer(64);
		strBuff.append("dm_policy where object_name='iDocs_lifecycle'");
		IDfId policyId = dfSession.getIdByQualification(strBuff.toString());
		System.out.println("policyId::"+policyId);
		
		HashMap templateMappingHM = new HashMap(); 
		IDfCollection templateColl = Utilities.executeQuery(dfSession, "select distinct template_title,template_code from dm_dbo.IDOCS_TEMPLATE_INFO", DfQuery.EXECREAD_QUERY);
		while(templateColl.next()){
			if(templateMappingHM.containsKey(templateColl.getString("template_title"))){
				
			}else{
				templateMappingHM.put(templateColl.getString("template_title"), templateColl.getString("template_code"));
			}
		}templateColl.close();
		
		Set set = templateMappingHM.entrySet();
		Iterator i = set.iterator();
		String updatReportTBL = "";
		while(i.hasNext()){
			Map.Entry subFldMap = (Map.Entry)i.next();
			String hmKey = (String) subFldMap.getKey();
			String hmValue = (String) subFldMap.getValue();
			
			System.out.println("Key::"+hmKey+"::Value::"+hmValue);
		}
		
		String tempTitle = "A Loan Participation (ALPs)";
		String tempCode = "";
		if(templateMappingHM.containsKey("A Loan Participation (ALPs)")){
			tempCode = (String) templateMappingHM.get(tempTitle.toString());
		}else{
			tempCode = "";
		}	
		System.out.println("tempCode::"+tempCode);
		if(newDoc.getString("r_policy_id").equals("0000000000000000")){
//			StringBuffer strBuff = new StringBuffer(64);
//			strBuff.append().append(lifecycleName).append("'");
//			IDfId policyId = dfSession.getIdByQualification("dm_policy where object_name='");
//			System.out.println("");
			newDoc.attachPolicy(policyId, "Draft", "");
			newDoc.save();
			if(newDoc.canPromote()){
				newDoc.promote("Released", false, false);
			}
			newDoc.save();
			System.out.println("Policy name::"+newDoc.getPolicyName());
			System.out.println("Policy ID::"+newDoc.getPolicyId());
			System.out.println("Doc State::"+newDoc.getString("doc_state"));
		}else{
			System.out.println("Life Cycle is already attached to the document");
		}*/
		
		}catch (Exception e){//Catch exception if any
				e.printStackTrace();
			  System.err.println("Error: " + e.getMessage());
		  }
		
	}
	
	
	private static String convertDateToESTDate(String newdateTime,String timez) {
		// TODO Auto-generated method stub

/*//		Date csDate = new Date(dateTime);
		String destFolrmatter = "MM/dd/yyyy hh:mm:ss a z";
		
		DateFormat formatter = new SimpleDateFormat(destFolrmatter);
		Date date;
		try {
			date = formatter.parse(newdateTime);
			newdateTime = formatter.format(date);
			formatter.setTimeZone(TimeZone.getTimeZone("EST"));
			newdateTime = formatter.format(date);
			System.out.println("Converted new Dte::"+newdateTime);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return newdateTime;*/
		
		newdateTime = convertTimezone(newdateTime);
		Date date = new Date(newdateTime);
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a z"); 
		String dStr = df.format(date); 
		String str = dStr.substring(0, dStr.length()-2);
		str = str + ":";
		dStr = str + dStr.substring(dStr.length()-2, dStr.length());
		
		System.out.println("Converted Time Zone:::::++++::"+dStr);
		
		String destFolrmatter = "MM/dd/yyyy hh:mm:ss a z";
		
		DateFormat formatter = new SimpleDateFormat(destFolrmatter);
		Date date1;
		try {
			date1 = formatter.parse(dStr);
			dStr = formatter.format(date1);
			formatter.setTimeZone(TimeZone.getTimeZone("EST"));
			dStr = formatter.format(date1);
			System.out.println("Converted new Dte::"+newdateTime);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return newdateTime; 

	}



		// TODO Auto-generated method stub
		private static String convertTimezone(String timeStamp) {
			String zone = timeStamp.substring(22, timeStamp.length());
			if (zone.equals(" AST")) { zone = " -0400"; }
			else if (zone.equals(" BST")) { zone = " -1100"; }
			else if (zone.equals(" CDT")) { zone = " -0600"; }
			else if (zone.equals(" CEDT")){ zone = " +0100"; }
			else if (zone.equals(" CET")) { zone = " +0100"; }
			else if (zone.equals(" CST")) { zone = " -0600"; }
			else if (zone.equals(" EDT")) { zone = " -0500"; }
			else if (zone.equals(" EST")) { zone = " -0500"; }
			else if (zone.equals(" GDT")) { zone = " -0000"; }
			else if (zone.equals(" ")) { zone = " -0000"; }
			else if (zone.equals(" HST")) { zone = " -1000"; }
			else if (zone.equals(" MDT")) { zone = " -0700"; }
			else if (zone.equals(" MST")) { zone = " -0700"; }
			else if (zone.equals(" NDT")) { zone = " -0330"; }
			else if (zone.equals(" NST")) { zone = " -0330"; }
			else if (zone.equals(" PDT")) { zone = " -0800"; }
			else if (zone.equals(" PST")) { zone = " -0800"; }
			else if (zone.equals(" YDT")) { zone = " -0900"; }
			else if (zone.equals(" YST")) { zone = " -0900"; }
			else if (zone.equals(" YW1")) { zone = " -0100"; }
			else if (zone.equals(" YW2")) { zone = " -0200"; }
			else if (zone.equals(" Z-13")) { zone = " +1300"; }
			else if (zone.equals(" ZE10")) { zone = " +1000"; }
			else if (zone.equals(" ZE11")) { zone = " +1100"; }
			else if (zone.equals(" ZE12")) { zone = " +1200"; }
			else if (zone.equals(" ZE2")) { zone = " +0200"; }
			else if (zone.equals(" ZE3")) { zone = " +0300"; }
			else if (zone.equals(" ZE3B")) { zone = " +0330"; }
			else if (zone.equals(" ZE4")) { zone = " +0400"; }
			else if (zone.equals(" ZE4B")) { zone = " +0430"; }
			else if (zone.equals(" ZE5")) { zone = " +0500"; }
			else if (zone.equals(" ZE5B")) { zone = " +0530"; }
			else if (zone.equals(" ZE5C")) { zone = " +0545"; }
			else if (zone.equals(" ZE6")) { zone = " +0600"; }
			else if (zone.equals(" ZE6B")) { zone = " +0630"; }
			else if (zone.equals(" ZE7")) { zone = " +0700"; }
			else if (zone.equals(" ZE8")) { zone = " +0800"; }
			else if (zone.equals(" ZE9")) { zone = " +0900"; }
			else if (zone.equals(" ZE9B")) { zone = " +0930"; }
			else if (zone.equals(" ZW1")) { zone = " -0100"; }
			else if (zone.equals(" ZW12")) { zone = " -1200"; }
			else if (zone.equals(" ZW2")) { zone = " -0200"; }
			else if (zone.equals(" ZW3")) { zone = " -0300"; } 
			else { zone = " -0000"; }
			timeStamp = (String) timeStamp.subSequence(0, 22);
			timeStamp += zone;
			return timeStamp;
			
	}


	private static void convertDateToCSDate(
			String metadataDate) {
		// TODO Auto-generated method stub
		/*System.out.println("metadataDate::"+metadataDate);
		Date csDate = new Date(metadataDate);
		DateFormat utcFormat = new SimpleDateFormat();
		TimeZone utcTime = TimeZone.getTimeZone("UTC");
		utcFormat.setTimeZone(utcTime);
		System.out.println("UTC for EDT Time: " + utcFormat.format(csDate));
		
		System.out.println("Offset Time Diff::" + csDate.getTimezoneOffset());*/
		
		System.out.println("Incoming Date::"+metadataDate);
		Date csDate = new Date(metadataDate);
		DateFormat utcFormat = new SimpleDateFormat();
		TimeZone utcTime = TimeZone.getTimeZone("UTC");
		utcFormat.setTimeZone(utcTime);
		String newDate = utcFormat.format(csDate);
		System.out.println("New Date::"+newDate);
		
		String[] nDate = newDate.split(":");
		if(nDate.length ==2){
			System.out.println("Actual Date::"+newDate);
			System.out.println(nDate[0]);
			if(nDate[1].contains(" ")){
				System.out.println(nDate[1]);
				String nd = nDate[1].replaceAll(" ", ":00 ");
				System.out.println(nDate[0]+":"+nd);
				newDate = nDate[0]+":"+nd;
				
			}
		}
		
		//String pattern = "";
			
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
		String s = sdf.format(new Date(newDate));
		System.out.println(s);
		//System.out.println(sdf.getCalendar().getTime() + " :: "+ newDate );
		
//		System.out.println(DateFormat.getTimeInstance(DateFormat.).format(new Date(newDate)));
		
//		return newDate;
	}


	public static String formatDateToMMDDYY1(String dateStr) {
		//String retDateStr = "";
		//9/29/2004
		String[] splitDate = dateStr.split("/");
		if((splitDate[0]).length()==1) splitDate[0]= "0"+ splitDate[0];
		if((splitDate[1]).length()==1) splitDate[1]= "0"+ splitDate[1];
		
		StringBuffer sbRetDateStr =  new StringBuffer("");
		sbRetDateStr.append(splitDate[0]).append("/").append(splitDate[1]).append("/").append(splitDate[2]);
			
		return sbRetDateStr.toString();
	}
	
	public static String CustomFormat(String dateStr) {
		//String retDateStr = "";
		//20-Oct-09
		String[] splitDate = dateStr.split("-");
		
		

        try{
		  Integer.parseInt(splitDate[1]);
        }catch(NumberFormatException ne){
        	
        }
		if((splitDate[1]).length()==1) splitDate[1]= "0"+ splitDate[1];
		
		StringBuffer sbRetDateStr =  new StringBuffer("");
		sbRetDateStr.append(splitDate[0]).append("/").append(splitDate[1]).append("/").append(splitDate[2]);
			
		return sbRetDateStr.toString();
	}
	
	public static String convertToEasternTime(String dateTime) {
		
		SimpleDateFormat sdf =  new SimpleDateFormat("MM/dd/yyyy");
		// TODO Auto-generated method stub
		if(dateTime !="" && dateTime !=null){
			dateTime = dateTime.trim();
			try{
				dateTime = dateTime.replaceAll("\\\\", "/");
				if(dateTime.contains(" ")){
					String[] timeDate = dateTime.split(" ");
					int cntTokens = timeDate.length;
					String dateStr = timeDate[0];
					//String dateStr = formatDateToMMDDYY(timeDate[0]);
					
					timeDate[0] = sdf.format(new Date(dateStr));
					StringBuffer sbNewDateTime = new StringBuffer("");
					for(int i=0;i<timeDate.length ; i++){
						sbNewDateTime.append(timeDate[i]).append(" ");
					}
					dateTime = sbNewDateTime.toString().trim();
			
					
					String timeStr = timeDate[1];
					if(dateStr != null && timeStr != null && !dateTime.contains("EST")){
						
						
						if (cntTokens ==3) return dateTime;

						DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a z");
						
						System.out.println("before parsing dates::"+dateTime);
						Date date = formatter.parse(dateTime);
						dateTime = formatter.format(date);
						
						formatter.setTimeZone(TimeZone.getTimeZone("EST"));
						dateTime = formatter.format(date);
						
/*
						formatter.setTimeZone(TimeZone.getTimeZone("GMT"));
						dateTime = formatter.format(date);
						
 					    if("EDT".equals("EST")){
							formatter.setTimeZone(TimeZone.getTimeZone("GMT-4"));
							dateTime = formatter.format(date).replace("GMT-04:00", "EDT");
						}else{
							formatter.setTimeZone(TimeZone.getTimeZone("EST"));
							dateTime = formatter.format(date); 
						}*/
					}
					if(dateTime.contains("AM") || dateTime.contains("PM")){
						String newDt[] = dateTime.split(" ");
						dateTime = newDt[0]+" "+newDt[1]+" "+newDt[2];
						
					}else{
						dateTime = "nulldate";
					}
				}else{
//					importDocLogger.warning("Invalid Date and Time::"+dateTime);
					//dateTime = formatDateToMMDDYY(dateTime);
					
					dateTime = sdf.format(new Date(dateTime))+" 00:00:00 AM";
				}
				System.out.println("after parsing dates::"+dateTime);
				
			}catch(ParseException pe){
				System.out.println("ParseException processing the dates::"+dateTime);
				
				System.out.println("Exception during parsing the date time ::dateTime::"+dateTime);
				pe.printStackTrace();
			}catch(Exception e){
				System.out.println("Exception processing the dates::"+dateTime);
				System.out.println("Exception during parsing the date time ::dateTime::"+dateTime);
				e.printStackTrace();
			}
		}else{
			dateTime = "nulldate";
		}
		return dateTime;
	}

	
	protected static IDfSessionManager getSessionMgr(String strUserName2,
			String strPassword2, String strDocbase2) {
		// TODO Auto-generated method stub

		IDfClient client;
		IDfSessionManager sMgr = null;
		RegistryPasswordUtils rpu = new RegistryPasswordUtils();
		try {
			client = DfClient.getLocalClient();
			sMgr = client.newSessionManager();
			IDfLoginInfo login = new DfLoginInfo();
			login.setUser(strUserName2);
//			login.setPassword(rpu.decrypt(strPassword2));
			login.setPassword(ESAPI.encryptor().decrypt(strPassword2));
			login.setDomain(null);
			sMgr.setIdentity(strDocbase2, login);
		} catch (DfException e) {
			e.printStackTrace();
		} catch (EncryptionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sMgr;
	}

	


	/**
	 * @param args
	 * @throws ParseException 
	 */
	/*public static void main(String[] args){
		String dateTime = "04/23/2007";
		System.out.println("Before conversion : " + dateTime);
		dateTime = convertToEDT(dateTime);
		System.out.println("After  conversion : " + dateTime);		
	}*/

	public static String convertToEDT(String dateTime) {
		// TODO Auto-generated method stub

		dateTime = dateTime.trim();
		try{
			dateTime = dateTime.replaceAll("\\\\", "/");
			if(dateTime.contains(" ")){
				String destFolrmatter = "MM/dd/yyyy hh:mm:ss a z";
				String[] timeDate = dateTime.split(" ");
				String dateStr = timeDate[0];
				String timeStr = timeDate[1];

				if(dateStr != null && timeStr != null && !dateTime.contains("EST")){		
					DateFormat formatter = new SimpleDateFormat(destFolrmatter);
					Date date = formatter.parse(dateTime);
					dateTime = formatter.format(date);

					formatter.setTimeZone(TimeZone.getTimeZone("GMT"));
					dateTime = formatter.format(date);

					if("EDT".equals("EST")){
						formatter.setTimeZone(TimeZone.getTimeZone("GMT-4"));
						dateTime = formatter.format(date).replace("GMT-04:00", "EDT");
					}else{
						formatter.setTimeZone(TimeZone.getTimeZone("EST"));
						dateTime = formatter.format(date); 
					}
			}

				dateTime = dateTime.substring(0, 22);
				
		}else{
			dateTime = dateTime+" 00:00:00";
		}
		}catch(ParseException pe){
			
			pe.printStackTrace();
		}catch(Exception e){
			
			e.printStackTrace();
		}
		return dateTime;
	}


}
