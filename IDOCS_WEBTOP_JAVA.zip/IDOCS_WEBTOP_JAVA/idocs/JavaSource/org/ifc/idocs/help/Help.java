package org.ifc.idocs.help;

import javax.servlet.http.HttpServletRequest;

import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.AccessibilityService;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.LocaleService;
import com.documentum.web.common.SessionState;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.formext.config.ConfigService;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.config.IConfigLookup;
import com.documentum.web.formext.session.SessionManagerHttpBinding;

public class Help extends com.documentum.web.util.Help{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String MSG_QRY_VARIABLE_KEYWORD = "<keywords>";
	public static final String CUSTOM_HELP = "Custom_Help";
	public static final String YES = "YES";
	public Help(){
        helpURL = null;
    }

    public void onInit(ArgumentList args){
        super.onInit(args);
    }

    public void onRender(){
    	super.onRender();
        HttpServletRequest request = (HttpServletRequest)getPageContext().getRequest();
        IConfigLookup configLookup = ConfigService.getConfigLookup();
        IConfigElement configElement = configLookup.lookupElement("component[id=help-index]", new Context());
        IConfigElement helpEntries = configElement.getChildElement("help-entries");
        String strUrl = getHelpURL(request);
        String strTarget = null;
        String strEntry = null;
        String strHelpId = null;
        try{
        	String strObjectId = getCustomHelpFile(request);
        	if(strObjectId != null && strObjectId.trim().length() >0){
        		strDrl=(request.getContextPath()).concat("/drl/objectId/").concat(strObjectId);
        		DfLogger.info(this, " DRL formed : "+strDrl,null,null);
        		SessionState.setAttribute(CUSTOM_HELP, YES);
                helpURL = strDrl;        		
        	}else{
        		if(!AccessibilityService.isAllAccessibilitiesEnabled())
                {
                    strHelpId = request.getParameter("context");
                    String strHelpView = request.getParameter("view");
                    if(strHelpView != null && strHelpView.length() > 0)
                    {
                        strEntry = (new StringBuilder()).append("entry[id=").append(strHelpView).append("_").append(strHelpId).append("]").toString();
                        strTarget = helpEntries.getChildValue(strEntry);
                    }
                    if(strTarget == null || strTarget.length() <= 0)
                    {
                        strEntry = (new StringBuilder()).append("entry[id=").append(strHelpId).append("]").toString();
                        strTarget = helpEntries.getChildValue(strEntry);
                    }
                    if(strTarget == null || strTarget.length() <= 0)
                    {
                        strEntry = "entry[id=default]";
                        strTarget = helpEntries.getChildValue(strEntry);
                    }
                } else
                {
                    strEntry = "entry[id=accessibilityfile]";
                    strTarget = helpEntries.getChildValue(strEntry);
                }
                if(strTarget == null || strTarget.length() <= 0)
                {
                    throw new WrapperRuntimeException((new StringBuilder()).append("Unable to retrieve help or 'default' page for '").append(strHelpId != null ? strHelpId : "").append("'").toString());
                } else
                {
                    helpURL = (new StringBuilder()).append(strUrl).append(strTarget).toString();
                    return;
                }
        	}
        	}catch (Exception e) {
        		DfLogger.info(this, " getHelpURL: Exception : "+e.getMessage(),null,null);
        	} 
    	}

	private String getCustomHelpFile(HttpServletRequest request){
		String strObjectId = null;
		try {
			String strHelpId;
			strHelpId = request.getParameter("context");
			DfLogger.info(this, "Help ID : : : :"+strHelpId,null,null);
			String strHelpView = request.getParameter("view");
			DfLogger.info(this, " Help View : : : :"+strHelpView,null,null);
			String strQryGetCustomHelp = IdocsUtil.getMessage("QRY_GET_CUSTOM_HELP_FILE");
			strQryGetCustomHelp = strQryGetCustomHelp.replace(MSG_QRY_VARIABLE_KEYWORD, strHelpId);
			DfLogger.info(this, " Query : : : :"+strQryGetCustomHelp,null,null);
			DfQuery query = new DfQuery();
			query.setDQL(strQryGetCustomHelp);
			IDfSessionManager sessionManager = SessionManagerHttpBinding.getSessionManager();
			DfLogger.info(this, " Help Current Docbase :: "+SessionManagerHttpBinding.getCurrentDocbase(),null,null);
			IDfSession dfSession = sessionManager.getSession(SessionManagerHttpBinding.getCurrentDocbase());
			IDfCollection dfCollection = query.execute(dfSession,IDfQuery.DF_READ_QUERY);
			while(dfCollection.next()){
				strObjectId=dfCollection.getString("r_object_id");
				DfLogger.info(this, " Object ID : : : : "+strObjectId,null,null);
			}
			if(dfCollection!=null)dfCollection.close();
			if(dfSession!=null)sessionManager.release(dfSession);			
		} catch (Exception e) {
			DfLogger.error(this, " : getCustomHelpFile : Exception :"+e.getMessage(), null, null);
			e.printStackTrace();
		}
		return strObjectId;
	}

    public String getHelpURL(){
        return helpURL;
    }

    public String getHelpURL(HttpServletRequest request){
        return getHelpURLPath(request);
    }

    public static String getHelpURLPath(HttpServletRequest request){
        java.util.Locale locale = LocaleService.getLocale();
        NlsResourceBundle bundle = new NlsResourceBundle("com.documentum.help.helpProp");
        String strUrl = (new StringBuilder()).append(request.getContextPath()).append(bundle.getString("url", locale, true)).toString();
        if(!strUrl.endsWith("/") && !strUrl.endsWith("\\"))
            strUrl = (new StringBuilder()).append(strUrl).append("/").toString();
        return strUrl;
    }
    
   /* private IDfSession getAdmSession() throws DfException {
      	DfLogger.info(this, " ############## Entering getting session method #############",null,null);
    		IDfClient client = DfClient.getLocalClient();
    		IDfSessionManager sMgr = client.newSessionManager();
    		String strUserName, strPassword, strDocbase;
    		strUserName=m_nlsResourceBundle.getString("MSG_USER_NAME", LocaleService.getLocale());
    		strPassword=m_nlsResourceBundle.getString("MSG_PASSWORD", LocaleService.getLocale());
    		strDocbase=m_nlsResourceBundle.getString("MSG_DOCBASE", LocaleService.getLocale());
    		
    		DfLogger.info(this, " User name : "+strUserName,null,null);
    		DfLogger.info(this, " Password : "+strPassword,null,null);
    		DfLogger.info(this, " Docbase : "+strDocbase,null,null);
    		
    		
    		IDfLoginInfo login = new DfLoginInfo();
    		login.setUser(strUserName);
    		login.setPassword(strPassword);
    		login.setDomain(null);
    		sMgr.setIdentity(strDocbase, login);
    		return sMgr.newSession(strDocbase);
    	}*/
    
    
    private String strDrl="";
    private String helpURL;
    protected static final String HELP_PROPERTY_FILE = "com.documentum.help.helpProp";
//    private static NlsResourceBundle m_nlsResourceBundle = new NlsResourceBundle("org.ifc.idocs.workflow.CredentialsNlsProp");


}

