package org.ifc.idocs.report.reports;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Logger;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.CellRangeAddress;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.ifc.idocs.report.ReportUtility;
import org.ifc.idocs.report.common.AppConfig;
import org.ifc.idocs.report.common.LogHelper;
import org.ifc.idocs.report.db.ExportDAOImpl;
import org.ifc.idocs.report.db.ReportDAOImpl;
import org.ifc.idocs.report.model.SecurityExceptionReportDisplay;


@SuppressWarnings("deprecation")
public class SecurityExceptionReport extends ReportUtility{
	
	private static AppConfig config = AppConfig.getInstance();
	private static Row newRow = null;
	private static Workbook newWb = null;
	private static Sheet newSheet = null;
	private static CellStyle newStyle = null, colorStyle = null;
	private static SecurityExceptionReportDisplay drd = null;
	private static Logger reportLogger = LogHelper.getLogger(SecurityExceptionReport.class);
	private static ArrayList<SecurityExceptionReportDisplay> docReportList = new ArrayList<SecurityExceptionReportDisplay>();
	
	public static void createSecurityExceptionReport(String reportType){
		String extractionQuery = config.getString("filters.extractioncriteriacode");
		String[] extCriteria = extractionQuery.split(";");
		for(int k = 0; k < extCriteria.length; k++){
			String extractionId = extCriteria[k];
			String utilityId = ExportDAOImpl.utilityIdIsExists(extractionId);
			if(utilityId != null){
				securityExceptionReport(utilityId, reportType);
			}
		}
	}
	
	public static void securityExceptionReport(String utilityId, String reportType){
		
		String projects = config.getString("securityExceptionReport.projects");
		String documents = config.getString("securityExceptionReport.documents");
		
		if((projects == null || projects.length() == 0) && (documents == null || documents.length() == 0)){
			reportLogger.warning("To generate Security Exception Report, Please specify the project id(s) / document id(s) in config.xml file");
			System.exit(0);
		}

		reportLogger.info("SecurityExceptionReport :: createSecurityExceptionReport() : Execution Started..");
		ResultSet rs = ReportDAOImpl.getSecurityExceptionReport(getQuery(utilityId, projects, documents));
		try {
			while (rs.next()){				
				drd = new SecurityExceptionReportDisplay();
				drd.setFolderValueCode1(rs.getString("FOLDER_VALUE_CODE"));
				drd.setLegacyId1(rs.getString("SOURCE_DOC_ID"));
				drd.setDocUniqueId1(rs.getString("SOURCE_DOC_UNIQUE_ID"));
				drd.setDocName1(rs.getString("SOURCE_DOC_NME"));
				drd.setVersion1(rs.getString("SOURCE_DOC_VER_NBR"));
				drd.setSecurityClassification1(rs.getString("SOURCE_SECURITY_CLASS_CODE"));
				
				drd.setFolderValueCode2(rs.getString("FOLDER_VALUE_CODE"));
				drd.setLegacyId2(rs.getString(reportType + "_DOC_ID"));
				drd.setDocUniqueId2(rs.getString(reportType + "_DOC_UNIQUE_ID"));
				drd.setDocName2(rs.getString(reportType + "_DOC_NME"));
				drd.setVersion2(rs.getString(reportType + "_DOC_VER_NBR"));
				drd.setSecurityClassification2(rs.getString(reportType + "_SECURITY_CLASS_CODE"));
				docReportList.add(drd);
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			createXLReport();
			reportLogger.info("DocumentReport :: Executed Successfully..");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	protected static void createXLReport() throws IOException {
		
		int i = 2;
		String folderValue = "";
		String sheetName = "", colHeaders = "";
		reportLogger.info("DocumentReport :: createDocumentReport() : Execution Started..");
		
		sheetName = idocsProperties.getProperty("Security_exception_report_name");
		colHeaders = idocsProperties.getProperty("Security_exception_report_columns");
		
		newWb = createXLSheet.createReportSheet(sheetName,colHeaders);
		newStyle = createXLSheet.createStyle(newWb, HSSFCellStyle.ALIGN_LEFT, "Calibri", 11, Font.BOLDWEIGHT_NORMAL);
		colorStyle = createXLSheet.createStyle(newWb, HSSFCellStyle.ALIGN_LEFT, "Calibri", 11, Font.BOLDWEIGHT_NORMAL, HSSFColor.ORANGE.index);
		newSheet = newWb.getSheet(sheetName);
		setReportHeaders(sheetName);

		for(SecurityExceptionReportDisplay drd : docReportList){
			i++;
	    	newRow = newSheet.createRow((short)i);
	    	createRow(0,drd.getFolderValueCode1());
	    	createRow(1,drd.getLegacyId1());
	    	createRow(2,drd.getDocUniqueId1());
	    	createRow(3,drd.getDocName1());	    	
	    	createRow(4,drd.getVersion1());
	    	createRow(5,drd.getSecurityClassification1());
	    	
	    	folderValue = (drd.getLegacyId2() == null) ? "" : drd.getFolderValueCode2();
	    	createRow(6,folderValue);
	    	createRow(7,drd.getLegacyId2());
	    	createRow(8,drd.getDocUniqueId2());
	    	createRow(9,drd.getDocName2());
	    	
	    	if(drd.getVersion1().equals(drd.getVersion2())){
	    		createRow(10,drd.getVersion2());
	    	}else{
	    		createRow(10,drd.getVersion2(),colorStyle);
	    	}
	    	
	    	if(drd.getSecurityClassification1().equals(drd.getSecurityClassification2())){
	    		createRow(11,drd.getSecurityClassification2());
	    	}else{
	    		createRow(11,drd.getSecurityClassification2(),colorStyle);
	    	}
		}		
		
		//Write data onto the XL Sheet.
		reportLogger.info("DocumentReport :: createDocumentReport() : sheetName : "+sheetName);
		createXLSheet.writeData(newWb,sheetName,idocsProperties, config);
		
		reportLogger.info("DocumentReport :: createDocumentReport() : Execution Completed..");
	}

	private static void setReportHeaders(String sheetName) {

		String header1 = idocsProperties.getProperty("REPORT_HEADERS1");
		String header2 = idocsProperties.getProperty("REPORT_HEADERS2");
		CellStyle headerStyle = createXLSheet.createStyle(newWb, HSSFCellStyle.ALIGN_CENTER, "Calibri", 12, Font.BOLDWEIGHT_BOLD);
		
		newRow = newSheet.createRow((short) 0);
	    Cell cell = newRow.createCell((short) 0);
	    cell.setCellValue(sheetName);
	    cell.setCellStyle(headerStyle);
	    newSheet.addMergedRegion(new CellRangeAddress( 0, 0, 0, 11));
		
		newRow = newSheet.createRow((short) 1);
	    cell = newRow.createCell((short) 0);
	    cell.setCellValue(header1);
	    cell.setCellStyle(headerStyle);
	    newSheet.addMergedRegion(new CellRangeAddress( 1, 1, 0, 5));
	    
	    cell = newRow.createCell((short) 6);
	    cell.setCellValue(header2);
	    cell.setCellStyle(headerStyle);
	    newSheet.addMergedRegion(new CellRangeAddress( 1, 1, 6, 11));
	    // first row (0-based) last row  (0-based) first column (0-based) last column  (0-based)
	}

	private static void createRow(int j, String folderValueCode1) {
		createRow(j, folderValueCode1, newStyle);
	}

	private static void createRow(int j, String folderValueCode1, CellStyle style) {
		createXLSheet.createCell(newWb, newRow, j, folderValueCode1, style);
		newSheet.autoSizeColumn((short)j);
	}

	
	private static String getQuery(String reportQuery, String projects, String documents) {
		String projectQry = "", docQry = "";
		if(projects != null){
			String[] projectList = projects.split(";");
			for(String pid : projectList){
				projectQry = (projectQry.length() == 0) ? "'" + pid.trim() + "'" : projectQry + ",'" + pid.trim() + "'";
			}
		}
		
		if(documents != null){
			String[] docList = documents.split(";");
			for(String did : docList){
				docQry = (docQry.length() == 0) ? "'" + did.trim() + "'" : docQry + ",'" + did.trim() + "'";
			}
		}
		
		String queryStr = "";
		if(projectQry.length() > 0 && docQry.length() > 0){
			queryStr = "' and (FOLDER_VALUE_CODE in (" + projectQry + ") or SOURCE_DOC_ID in (" + docQry + ")) ";
		}else if(projectQry.length() > 0){
			queryStr = "' and (FOLDER_VALUE_CODE in (" + projectQry + ")) ";
		}else if(docQry.length() > 0){
			queryStr = "' and (SOURCE_DOC_ID in (" + docQry + ")) ";
		}
		
		String query = reportQuery + queryStr;
		return query;
	}
}
