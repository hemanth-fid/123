package org.ifc.idocs.migration.helper;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.apache.log4j.FileAppender;
/**
 * LogHelper - Initialize the Import Loggers and setting the trace levels. 
 * @author HAnuganti
 * 
 * #############################################################################################
 * Author		            DateofChange	 Version	  ModificationHistory
 * ###########################################################################################
 * Hemachandra Anuganti 
 * ###########################################################################################
 * 
 */
public class LogHelper {
	/*
	 * Get the logger for a particular object.
	 * @param object
	 * @return
	 */
	protected static AppConfig config = AppConfig.getInstance();
	public static Logger getLogger(Object object)
 	{
		Logger logger = null;
		try
		{

			SimpleFormatter simpFormatter = new SimpleFormatter();
			Date now = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("MMddyy_HHmmss");
			String timeStamp = formatter.format(now);
//			String fileName = idocsLogProperties.getProperty("MSG_LOG_PATH")+timeStamp+".log";
			String logFolderPath = config.getString("logPath.logFilePath");
			File logFilePath = new File(logFolderPath);
			if(logFilePath.exists()){
				String fileName = config.getString("logPath.logFilePath")+"\\"+"IMPORT_"+config.getString("filters.extractionutilityID")+".log";
				FileHandler fileHandler = new FileHandler(fileName, 5120000, 100, false);
				fileHandler.setLevel(Level.ALL);
				fileHandler.setFormatter(simpFormatter);
				
				logger = Logger.getLogger(object.getClass().getName());
				logger.addHandler(fileHandler);
				FileAppender app = new FileAppender();
				app.setFile(fileName);
				app.setBufferSize(10000);
				ConsoleHandler consoleHandler = new ConsoleHandler();
				consoleHandler.setLevel(Level.ALL);
				//logger.addHandler(consoleHandler);
				return logger;
			}else{
				logFilePath.mkdirs();
				if(logFilePath.exists()){
					String fileName = config.getString("logPath.logFilePath")+"\\"+"IMPORT_"+config.getString("filters.extractionutilityID")+".log";
					FileHandler fileHandler = new FileHandler(fileName, 5120000, 100, false);
					fileHandler.setLevel(Level.ALL);
					fileHandler.setFormatter(simpFormatter);
					logger = Logger.getLogger(object.getClass().getName());
					logger.addHandler(fileHandler);
					FileAppender app = new FileAppender();
					app.setFile(fileName);
					app.setBufferSize(10000);
					ConsoleHandler consoleHandler = new ConsoleHandler();
					consoleHandler.setLevel(Level.ALL);
					//logger.addHandler(consoleHandler);
					return logger;
				}else{
					System.out.println("Unable to locate log file path : "+ logFilePath);
					System.out.println("Please ensure that log file path exists at the specified location : "+ logFilePath);
					System.out.println("Exiting the Utility.....!!");
	                System.exit(0);  
	                return null;
				}
			}
			
		}catch (Exception ex)
		{
			//if no logging what to do. just printout for now.
			logger.warning("Logger Exception = "+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	} 
}
