/**
* The class is provided to add a new child document to a virtual document by creating a new document.
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created
* #######################################################################################################
*/
package org.ifc.idocs.library.vdm.addcomponent;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.action.IActionCompleteListener;
import java.util.Map;

public class AddNewVirtualDocumentNode extends com.documentum.webcomponent.library.vdm.addcomponent.AddNewVirtualDocumentNode
    implements IActionCompleteListener
{
	private boolean m_checkoutProcessed;
    public AddNewVirtualDocumentNode()
    {
        m_checkoutProcessed = false;
    }
	public void onComplete(String strAction, boolean bSuccess, Map completionArgs)
    {
        try {
        	ArgumentList arguments = getInitArgs();
	        String objectId = arguments.get("objectId");
	        DfLogger.info(this, " :: onComplete : "+getDfSession().getLoginUserName(), null, null);
	        arguments.add("vdmRootObjectId", objectId);
	        super.onComplete(strAction, bSuccess, completionArgs);
        } catch(Exception e){
        	DfLogger.error(this, " :: onComplete Exception >> "+e.getMessage(), null, e);
        }
    }
}
