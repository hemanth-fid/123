/**
* The class is provided to add a new child document from the clipboard to a virtual document.
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* CVattathara			10.21.2010		1.0					created
* #######################################################################################################
*/
package org.ifc.idocs.library.vdm.addcomponent;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.action.IActionCompleteListener;
public class AddVirtualDocumentNodeFromClipboard extends com.documentum.webcomponent.library.vdm.addcomponent.AddVirtualDocumentNodeFromClipboard
    implements IActionCompleteListener
{

    protected String m_objectIdArg;
    protected String m_vdmRootObjectIdArg;
    protected String m_nodeIdArg;
    protected String m_insertAfterNodeId;

    public AddVirtualDocumentNodeFromClipboard()
    {
        m_objectIdArg = null;
        m_vdmRootObjectIdArg = null;
        m_nodeIdArg = null;
        m_insertAfterNodeId = null;
    }

    public void onInit(ArgumentList arg)
    {
        try {
        	m_objectIdArg = arg.get("objectId");
	        DfLogger.info(this, " :: onInit : "+getDfSession().getLoginUserName(), null, null);
	        arg.add("vdmRootObjectId",m_objectIdArg);
	        super.onInit(arg);
        } catch(Exception e) {
        	DfLogger.error(this, " :: onInit Exception >> "+e.getMessage(), null, e);
        }
    }
}
