package org.ifc.idocs.report.model;

public class CountryProjectDoc {

	private String countryCode;
	private String folderValueCode;
	private String sourceDocId;
	
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getFolderValueCode() {
		return folderValueCode;
	}
	public void setFolderValueCode(String folderValueCode) {
		this.folderValueCode = folderValueCode;
	}
	public String getSourceDocId() {
		return sourceDocId;
	}
	public void setSourceDocId(String sourceDocId) {
		this.sourceDocId = sourceDocId;
	}
	
}
