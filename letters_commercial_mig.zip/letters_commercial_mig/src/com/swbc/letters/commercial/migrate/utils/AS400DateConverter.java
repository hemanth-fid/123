package com.swbc.letters.commercial.migrate.utils;


import java.text.SimpleDateFormat;
import java.util.Date;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfTime;

/**
 * @author Rene Wagner (Gimmal LLC)
 *
 */

public class AS400DateConverter {

	private String m_runmode = null;

	
	public static void main(String[] args) 
	{
		String stdDate = null; 
		AS400DateConverter theService = new AS400DateConverter();
	
		//int as400Date = 1160430;	//04/30/2016
		//int as400Date = 1160603;
		int as400Date = 0;
		
		try 
		{
			theService.setRunmode("Application");
			stdDate = theService.convertAS400DateToDateStr(as400Date);
			System.out.println("Converted to String Date : " + stdDate);
			
			IDfTime dctmDate = theService.convertAS400DateToIDfTime(as400Date);
			System.out.println("Converted to DCTM Date : " + dctmDate.toString());
			
			int as400Out = theService.changeDateToAS400Int(dctmDate);
			System.out.println("Converted to AS400 Date (1160430): " + as400Out);
			

		} 
		catch (Exception e){
			e.printStackTrace();
		}
	}

        
	/**
	 * convert AS400Date to MM/DD/YYYY string format
	 * @param as400Date (int format)
	 */
	public static String convertAS400DateToDateStr(int as400Date) {

	System.out.println("NoOp Diagnosting Message: Entered Date Converter with AS400 Date " + as400Date);
	String as400DateStr = Integer.toString(as400Date);
	
	String strDate = "";

       if (as400DateStr.matches("\\d{2}\\/\\d{2}\\/\\d{4}") || (as400DateStr.isEmpty())) {
           strDate = as400DateStr;
       } else if (as400DateStr.equalsIgnoreCase("0") || as400DateStr.equalsIgnoreCase("0.0") )
       {
             strDate = "";
       } else
       {
           int idate = Integer.parseInt(as400DateStr.replace(".0", ""));
           int iday = idate % 100;
           idate /= 100;
           int imonth = idate % 100;
           idate /= 100;
           int iyear = idate + 1900;
           strDate = padLeft(String.valueOf(imonth),2,"0").concat("/").concat(padLeft(String.valueOf(iday),2,"0")).concat("/").concat(padLeft(String.valueOf(iyear),4,"0"));
       }

       return strDate;
	}
	
	
	/**
	 * convert AS400Date to IDFTime object
	 * @param as400Date (int format)
	 */
	public static IDfTime convertAS400DateToIDfTime(int as400Date) {

	System.out.println("NoOp Diagnosting Message: Entered Date Converter with AS400 Date " + as400Date);
	String as400DateStr = Integer.toString(as400Date);
	
	IDfTime dctmDate = null;
	IDfClientX clientx = new DfClientX();
	String now = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new Date());
	
	
       if (as400DateStr.matches("\\d{2}\\/\\d{2}\\/\\d{4}") || (as400DateStr.isEmpty())) {
           dctmDate = clientx.getTime("as400DateStr", IDfTime.DF_TIME_PATTERN44);
           
       } else if (as400DateStr.equalsIgnoreCase("0") || as400DateStr.equalsIgnoreCase("0.0") )
       {
    	   dctmDate = clientx.getTime(null, IDfTime.DF_TIME_PATTERN44);
       } else
       {
           int idate = Integer.parseInt(as400DateStr.replace(".0", ""));
           int iday = idate % 100;
           idate /= 100;
           int imonth = idate % 100;
           idate /= 100;
           int iyear = idate + 1900;
           String tmp = padLeft(String.valueOf(imonth),2,"0").concat("/").concat(padLeft(String.valueOf(iday),2,"0")).concat("/").concat(padLeft(String.valueOf(iyear),4,"0")); 
           
           dctmDate = clientx.getTime(tmp, IDfTime.DF_TIME_PATTERN44);
       }

       return dctmDate;
	}
	

	
	/**
	 * convert IDfTime Date to AS400Date
	 * @param as400Date (int format)
	 */
	public int changeDateToAS400Int(IDfTime dctmDate){
		
		int as400Date = 0;		//default to 0 if nulldate
		String strDate = null;
		
		try{
		
			if(dctmDate.isNullDate()){
				
				return as400Date;
				
			}else
			{
				//Convert Date to FS400 format
				String year = Integer.toString(dctmDate.getYear());
				boolean isNewMillenium = false;
				
				if(year.startsWith("2"))
					isNewMillenium = true;
					
				year = year.substring(2);

				String month = Integer.toString(dctmDate.getMonth());
				if (month.length() == 1) 
					month = "0" + month;
				   
			   	String day = Integer.toString(dctmDate.getDay()); 
			   	if (day.length() == 1) 
			   		day = "0" + day;
				   
			   	if (isNewMillenium)
			   		strDate = "1" + year + month + day;	//Prefix date with '1' for '2000' years
			   	else
			   		strDate = "0" + year + month + day;	
			   	
			   	as400Date = Integer.parseInt(strDate);
				
			}
			
		}catch(Exception e){
			
			System.out.println("AS400DataService.changeDateToAS400Int...could not convert Date to Int: " + e.getMessage());
			
		}
		
		return as400Date;
	}
	
	
	

	private static String padLeft(String instring, int length, String padstring) {
        while (instring.length() < length) {
            instring = padstring.concat(instring);
        }
        return instring;
    }
	    

		
	/**
	 * Sets Application runmode if executed via MAIN
	 * @param runmode
	 */
	private void setRunmode(String runmode) 
	{
		this.m_runmode = runmode;
	}

}

