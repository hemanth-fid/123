package org.ifc.idocs.migration.extract;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import lotus.domino.Database;
import lotus.domino.DateTime;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.View;
import lotus.domino.ViewEntry;
import lotus.domino.ViewEntryCollection;

import org.ifc.idocs.migration.common.Country;
import org.ifc.idocs.migration.common.DomdocRepository;

/**
 * @author SPankajamsadanan
 *
 */
public class FoldermanDb {

	protected Database db;
	protected DomdocRepository domdoc;
	Logger exportDocLogger = LogHelper.getLogger(FoldermanDb.class);

	/**
	 * FoldermanDb constructor
	 * @param domdoc
	 * @param path
	 * @throws NotesException
	 */
	public FoldermanDb(DomdocRepository domdoc, String path) throws NotesException {
		this.domdoc = domdoc;
		this.db = NotesSession.getInstance().getDatabase(domdoc.getServerName(), path);
	}

	/**
	 * @throws NotesException
	 */
	public void recycle() throws NotesException {
		this.db.recycle();		
	}

	/**
	 * @return
	 * @throws NotesException
	 */
	@SuppressWarnings("unchecked")
	public List<Country> getCountries() throws NotesException  {
		List<Country> countries = new ArrayList<Country>();
		View countryView = db.getView("FoldersCountry");
		ViewEntryCollection countryColl = countryView.getAllEntries();
		ViewEntry countryVector = countryColl.getFirstEntry();
		while (countryVector != null) {
			Vector v = countryVector.getColumnValues();
			countries.add(new Country(v.elementAt(0).toString(), v.elementAt(1).toString()));
			countryVector = countryColl.getNextEntry(countryVector);
		}
		countryColl.recycle();
		countryView.recycle();
		return countries;
	}



	public DocumentCollection findFolders(String query) throws NotesException {
		String baseQuery = "Form='Folder'";
		String searchStr;
		if (query.length()>0) {
			searchStr = baseQuery + " & " + query ;
		} else {
			searchStr = baseQuery;
		}
		exportDocLogger.warning("Folderman search query : " + searchStr);
		return this.db.search(searchStr);
	}

	/**
	 * export method
	 * @param path
	 * @param folderQuery
	 * @param query
	 * @param cutoff
	 * @return void
	 * @throws Exception
	 */
	public void export(String path, String folderQuery, String query, DateTime cutoff) throws Exception {
		DocumentCollection folderdocs = findFolders(folderQuery);
		Document folderdoc = folderdocs.getFirstDocument();
		while (folderdoc != null) {
			DomdocFolder folder = new DomdocFolder(domdoc, folderdoc);
			folder.export(path, query, cutoff);
			folderdoc = folderdocs.getNextDocument(folderdoc);
		}
		folderdocs.recycle();
	}

	/**
	 * getAuditTrials method sets the views and invoke getWorkflowAuditTrials for extraction
	 * @param utilityId
	 * @param viewName 
	 * @param activityView 
	 * @param isBaseline 
	 */
	public void getAuditTrials(String utilityId, String workflowView, String activityView, boolean isBaseline){
		try{
			View ifc_instanceDos = db.getView(workflowView);
			View osAuditAllByInstanceId = db.getView(activityView);

			WorkflowFoldermanDb wf = new WorkflowFoldermanDb();
			wf.getWorkflowAuditTrials(ifc_instanceDos, osAuditAllByInstanceId, utilityId, isBaseline);
		}catch(NotesException e){
			exportDocLogger.warning("Database has not been opened yet");
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"FoldermanDB.java-NotesException", e);
		}
	}
}
