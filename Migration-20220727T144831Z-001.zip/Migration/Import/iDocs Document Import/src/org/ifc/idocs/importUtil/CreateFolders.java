package org.ifc.idocs.importUtil;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.StringTokenizer;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;

public class CreateFolders extends ImportUtility{
	private static final String createFolderPropFile = "/CreateFolders.properties";
	private static Properties creteFolderProperties = new Properties();
	private static IDfCollection dataCollection = null;
	private static IDfCollection tempColl = null;
	private static String path = "/";
	private static String strInstitution = null;
	private static String strCountry = null;
	private static String strAdvisoryServices = null;
	private static String strInvestmentOperations = null;
	private static String strCabinetType = null;
	private static String striDocsFolderType = null;
	private static String strProjectFolderType = null;
	private static String strInstitutionFolderType = null;
	private static String strCountryType = null;
	private static String strSubFolderType = null;
	private static String strProjectId = null;
	private static String strProjName = null;
	private static String strProjMainCategory=null;
	private static String strInstitId = null;
	private static String strInstitName = null;
	private static String strCountryCode = null;
	private static String strCountryName = null;
	private static String strRegionName = null;
	private static String strLevel1SubFldr = null;
	private static String strLevel2SubFldr = null;
	private static int countFolder=0;
	private static String projectIds="";
	private static String institutionIds="";
	private static String countryIds="";

	public static void startExecution() throws DfException, IOException 
	{
		dominoDocLogger.info("CreateFolders :: Execution Started....");

		//Loading the Properties File
		InputStream inputStream = CreateFolders.class.getResourceAsStream(createFolderPropFile);
		creteFolderProperties.load(inputStream);

		//set variables
		strInstitution =creteFolderProperties.getProperty("MSG_strInstitution");
		strCountry = creteFolderProperties.getProperty("MSG_strCountry");
		strAdvisoryServices = creteFolderProperties.getProperty("MSG_strAdvisoryServices");
		strInvestmentOperations = creteFolderProperties.getProperty("MSG_strInvestmentOperations");
		strCabinetType = creteFolderProperties.getProperty("MSG_strCabinetType");
		striDocsFolderType = creteFolderProperties.getProperty("MSG_striDocsFolderType");
		strProjectFolderType = creteFolderProperties.getProperty("MSG_strProjectFolderType");
		strInstitutionFolderType = creteFolderProperties.getProperty("MSG_strInstitutionFolderType");
		strCountryType = creteFolderProperties.getProperty("MSG_strCountryType");
		strSubFolderType = creteFolderProperties.getProperty("MSG_strSubFolderType");
		strProjectId = creteFolderProperties.getProperty("MSG_strProjectId");
		strProjName = creteFolderProperties.getProperty("MSG_strProjName");
		strProjMainCategory=creteFolderProperties.getProperty("MSG_strProjMainCategory");
		strInstitId = creteFolderProperties.getProperty("MSG_strInstitId");
		strInstitName = creteFolderProperties.getProperty("MSG_strInstitName");
		strCountryCode = creteFolderProperties.getProperty("MSG_strCountryCode");
		strCountryName = creteFolderProperties.getProperty("MSG_strCountryName");
		strRegionName = creteFolderProperties.getProperty("MSG_strRegionName");
		strLevel1SubFldr = creteFolderProperties.getProperty("MSG_strLevel1SubFldr");
		strLevel2SubFldr = creteFolderProperties.getProperty("MSG_strLevel2SubFldr");

		StringBuilder Query = new StringBuilder(creteFolderProperties.getProperty("QRY_READ_PENDING"));
//		System.out.println("QRY_PROJECT_ATTR :"+Query.toString());
		tempColl=executeQuery(Query.toString());
		int i =0;
	    while(tempColl.next())
	    {
	    	i++;
	    	if(tempColl.getString("idocs_folder_category").equals(creteFolderProperties.getProperty("MSG_CATEGORY_PROJECTS"))){
	    		
	    		if(i==1){
	    			projectIds=tempColl.getString("idocs_id");
	    		}
	    		else{
		    		projectIds =projectIds + "','"+tempColl.getString("idocs_id")+"";
	    		}
	    	}else 
	    	if(tempColl.getString("idocs_folder_category").equals(creteFolderProperties.getProperty("MSG_CATEGORY_INSTITUTIONS"))){
	    		if(i==1){
	    			institutionIds=tempColl.getString("idocs_id");
	    		}
	    		else{
	    			institutionIds =institutionIds + "','"+tempColl.getString("idocs_id")+"";
	    		}
	    	}else{
	    		if(i==1){
	    			countryIds=tempColl.getString("idocs_id");
	    		}
	    		else{
	    			countryIds =countryIds + "','"+tempColl.getString("idocs_id")+"";
	    		}
	    	}
	    }
	    tempColl.close();

		Query = new StringBuilder(creteFolderProperties.getProperty("QRY_PROJECT_ATTR"));
		Query.append(projectIds+"')");
//		System.out.println("QRY_PROJECT_ATTR :"+Query.toString());
		dataCollection=executeQuery(Query.toString());

	    while(dataCollection.next())
	    {
			path = "/";
	    	//PROJ_MAIN_CATEGORY provides segregation of Investment Operations and Advisory Services
	    	createCabinetCountry(dataCollection.getString(strProjMainCategory));
	    }
	    dataCollection.close();

	    Query = new StringBuilder(creteFolderProperties.getProperty("QRY_INSTITUTION_ATTR"));
		Query.append(institutionIds+"')");
//	    System.out.println("QRY_INSTITUTION_ATTR :"+Query.toString());
		dataCollection=executeQuery(Query.toString());
	    while(dataCollection.next())
	    {
			path = "/";
	    	createCabinetCountry(creteFolderProperties.getProperty(strInstitution));
	    }
	    dataCollection.close();

	    Query = new StringBuilder(creteFolderProperties.getProperty("QRY_COUNTRY_ATTR"));
		Query.append(countryIds+"')");
//	    System.out.println("QRY_COUNTRY_ATTR :"+Query.toString());
	    dataCollection=executeQuery(Query.toString());
	    while(dataCollection.next())
	    {
			path = "/";
	    	createCabinetCountry(creteFolderProperties.getProperty(strCountry));
	    }
	    dataCollection.close();
//	    System.out.println("Total Folder created : "+countFolder);
	    dominoDocLogger.info("Total Folder created : "+countFolder);
	}

//Common Functions

	private static void createCabinetCountry(String category) throws DfException 
	{
		dominoDocLogger.info("CreateFolders :: Checking Existing Folders for "+category);
		String currentPath=path;
		String regionName="",countryName="";
		StringBuilder dqlStr = new StringBuilder(creteFolderProperties.getProperty("QRY_REGION_DETAILS"));
	    dqlStr.append(dataCollection.getString(strCountryCode)).append("'");
	    tempColl=executeQuery(dqlStr.toString());
	    if(tempColl.next())
	    {
	    	regionName=tempColl.getString(strRegionName).replace("/", "\\").trim();
	    	countryName=tempColl.getString(strCountryName).replace("/", "\\").trim();
	    	currentPath=path+regionName;
//	    	System.out.println("Current Path :" +currentPath);
	    	if(!isExist(currentPath))
	    	{
	    		dominoDocLogger.info("CreateFolders :: Creating Folders....");
				createFolder("",strCabinetType,regionName);
				createFolder(currentPath,striDocsFolderType,countryName);
//				System.out.println("folderCreated: "+currentPath+"/"+countryName);
	    	}
	    else{
	    		if(!isExist(currentPath+"/"+countryName))
	    		{
		    		dominoDocLogger.info("CreateFolders :: Creating Folders....");
		    		createFolder(currentPath,striDocsFolderType,countryName);
//					System.out.println("folderCreated: "+currentPath+"/"+countryName);
	    		}
	    		else{
//	    			System.out.println("folderExist : "+currentPath+"/"+countryName);
	    		}
	    	}
	    	path=currentPath+"/"+countryName;
			subfolderstructure(path,category);
			tempColl.close();
	    }
	}

	public static void createFolder(String path,String type,String objectName) throws DfException
	{
    	if(!isExist(path+"/"+objectName))
    	{
//    		System.out.println("Type : "+type+" for : "+path+"/"+objectName);
			if(type.equals(strCabinetType))
			{
				IDfSysObject newCabinet =(IDfFolder) dfSession.newObject(type);
				newCabinet.setObjectName(objectName);
				newCabinet.save();
				countFolder++;
			}
			else
			{
				IDfSysObject newFolder = (IDfFolder) dfSession.newObject(type);
				newFolder.setObjectName(objectName);
				newFolder.link(path);
				newFolder.save();
				setAttributes(newFolder.getType().getName(),newFolder.getObjectId(),objectName);
				countFolder++;
			}
//			System.out.println("folder created : "+objectName);
    	}
	}

	private static void setAttributes(String typeName, IDfId dfId,String objectname) throws DfException 
	{
		StringTokenizer st = null;
		String attrValue = "";
		int i=0, attrCount=0;
		String attrName="";

		if(!typeName.equals(strSubFolderType))
		{

			if(typeName.equals(striDocsFolderType)){
				//ATTR_LIST_IDOCS_FOLDER
				st=new StringTokenizer(creteFolderProperties.getProperty("ATTR_LIST_IDOCS_FOLDER"), ",");
			}
			else if(typeName.equals(strProjectFolderType)){
				//ATTR_LIST_PROJECT_FOLDER
				st=new StringTokenizer(creteFolderProperties.getProperty("ATTR_LIST_PROJECT_FOLDER"), ",");
			}
			else if(typeName.equals(strInstitutionFolderType)){
				//ATTR_LIST_INSTIT_FOLDER
				st=new StringTokenizer(creteFolderProperties.getProperty("ATTR_LIST_INSTIT_FOLDER"), ",");
			}
			else if(typeName.equals(strCountryType)){
				//ATTR_LIST_COUNTRY_FOLDER
				st=new StringTokenizer(creteFolderProperties.getProperty("ATTR_LIST_COUNTRY_FOLDER"), ",");
			}
			else{
//				System.out.println("Folder Type Not found : "+typeName);
			}

			IDfSysObject folder = (IDfSysObject)dfSession.getObject(dfId);
			folder.setString("folder_category",objectname);

			if(!st.equals(null)){
				attrCount=st.countTokens();
		    	for(i=0;i<attrCount;i++){
					attrName=st.nextToken();
					attrValue=dataCollection.getString(attrName).trim();
					folder.setString(attrName, attrValue);
				}
			}
			folder.save();
		}
		else
		{
			//System.out.println("No Attributes are set for :"+typeName+":"+objectname);	
		}
	}

	private static void subfolderstructure(String countryPath,String category) throws DfException 
	{
		category=category.replace("/", "\\").trim();
		String currentPath="";
		String codeIdFolder="";
		String FolderType="";
		currentPath=countryPath+"/"+category;

		if(!isExist(currentPath))
		{
			createFolder(countryPath,striDocsFolderType,category);
		}

		if(category.equals(creteFolderProperties.getProperty(strAdvisoryServices))||category.equals(creteFolderProperties.getProperty(strInvestmentOperations)))
		{
			codeIdFolder=dataCollection.getString(strProjectId)+" - "+dataCollection.getString(strProjName);
			codeIdFolder.replace("/", "\\").trim();
			FolderType=strProjectFolderType;
		}
		else if(category.equals(creteFolderProperties.getProperty(strInstitution)))
		{
			codeIdFolder=dataCollection.getString(strInstitId)+" - "+dataCollection.getString(strInstitName);
			codeIdFolder.replace("/", "\\").trim();
			FolderType=strInstitutionFolderType;
		}
		else if(category.equals(creteFolderProperties.getProperty(strCountry)))
		{
			codeIdFolder=dataCollection.getString(strCountryCode)+" - "+dataCollection.getString(strCountryName);
			codeIdFolder.replace("/", "\\").trim();
			FolderType=strCountryType;
		}

		if(!isExist(currentPath+"/"+codeIdFolder))
		{
			createFolder(currentPath,FolderType,codeIdFolder);
		}

		path=currentPath+"/"+codeIdFolder.trim();
		treeStructure(path,category);
	}

	private static void treeStructure(String projectPath,String category) throws DfException 
	{
		String currentPath=projectPath;
		String level1SubFolder="",level2SubFolder="";
		StringBuilder dqlStr = new StringBuilder(creteFolderProperties.getProperty("QRY_FOLDER_TREE"));
	    dqlStr.append(category).append("'");
//		System.out.println("QRY_FOLDER_TREE : "+dqlStr.toString());
	    tempColl = executeQuery(dqlStr.toString());
	    while(tempColl.next())
	    {
	    	level1SubFolder=tempColl.getString(strLevel1SubFldr).replace("/", "\\").trim();
	    	level2SubFolder=tempColl.getString(strLevel2SubFldr).replace("/", "\\").trim();
	    	currentPath=projectPath+"/"+level1SubFolder;
	    	if(!isExist(currentPath))
	    	{
				createFolder(projectPath,strSubFolderType,level1SubFolder);
				createFolder(currentPath,strSubFolderType,level2SubFolder);
				dominoDocLogger.info("CreateFolders :: Folder Created :  "+currentPath+"/"+level2SubFolder);
	    	}
	    	else
	    	{
	    		if(!isExist(currentPath+"/"+level2SubFolder))
	    		{
					createFolder(currentPath,strSubFolderType,level2SubFolder);
					dominoDocLogger.info("CreateFolders :: Folder Created :  "+currentPath+"/"+level2SubFolder);
	    		}
	    	}
		}tempColl.close();
	}

	public static IDfCollection executeQuery(String Query) throws DfException
	{
		IDfCollection queryCollection = null;
		IDfQuery queryObj=new DfQuery();
		queryObj.setDQL(Query);
		queryCollection=queryObj.execute(dfSession, IDfQuery.READ_QUERY);
		return queryCollection;
	}

	public static boolean isExist(String arg) throws DfException
	{
		@SuppressWarnings("unused")
		IDfSysObject obj = null;
		if(( obj = (IDfSysObject) dfSession.getObjectByPath(arg))!=null)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}