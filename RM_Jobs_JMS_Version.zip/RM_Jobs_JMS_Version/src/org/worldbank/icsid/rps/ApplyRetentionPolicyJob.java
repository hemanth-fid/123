package org.worldbank.icsid.rps;

/**
 * 
 */

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Map;
import java.util.Properties;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.owasp.esapi.ESAPI;
import org.owasp.esapi.errors.EncryptionException;

import com.documentum.com.DfClientX;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfLoginInfo;

/**
 * 
 * @author wb385372
 * 
 */
public class ApplyRetentionPolicyJob {
	
	public static void main(String[] args) {
		try {
			ApplyRetentionPolicyJob applyRetentionPolicyJob = new ApplyRetentionPolicyJob();
			if(args.length >= 2){
				applyRetentionPolicyJob.m_totalInstanceNbr= args[0];
				applyRetentionPolicyJob.m_currentInstanceNbr = args[1];				
			}
			applyRetentionPolicyJob.execute(null, null);			
		} catch (DfException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void execute(Map params, PrintWriter writer)
			throws ClassNotFoundException, Exception {
		Date dtStart = new Date();
		bundle = ResourceBundle.getBundle("icsidconnection");
		m_docbase = bundle.getString("DOCBASE_NAME");
		try{
			m_userName = ESAPI.encryptor().decrypt(bundle.getString("USER_NAME"));
			m_password = ESAPI.encryptor().decrypt(bundle.getString("PASSWORD"));
		}catch(EncryptionException exp){
	    	return;
	    }
		
		m_sessionMgr = login();
		try {
			m_session = m_sessionMgr.getSession(m_docbase);
			PolicyUtils.writeLog("<<<<<<<<<<<<<<<<<<<<<<<<< ICSIDApplyPolicy >>>>>>>>>>>>>>>>>>>>>>>>> ");
			doProcessing(m_session);	
			System.exit(0);
		} catch (IOException e) {
			log.error(e);
			throw e;
		} catch (ClassNotFoundException e) {
			log.error(e);
		} finally {
			if (m_session != null) {
				m_sessionMgr.release(m_session);
			}
		}
	}

	/**
	 * This method is the starting point of the batch Execution. This reads the
	 * task entries from the registered table and starts processing one by one
	 * 
	 * @param m_File		- Output File
	 * @param dfSession		- DfSession
	 * @throws Exception
	 */
	protected void doProcessing(IDfSession dfSession) throws Exception {
		bundle = ResourceBundle.getBundle("icsidconnection");
		PolicyUtils.writeLog("doProcessing  >> " + new Date());
		IDfCollection inputTaskIdCollection = PolicyUtils.checkForNewRPSApplyTasks(m_totalInstanceNbr,m_currentInstanceNbr,m_session);
		int numberOfTasksProcessed = 0;
		while (inputTaskIdCollection.next()) {
			if(checkProcessCommand() != true){
				PolicyUtils.writeLog("Instance " + m_currentInstanceNbr + " " + "Receive signal to stop ");
				break;
			}
			String m_policyTaskId = null ; 
			String m_folderPath = null ; 
			String m_retentionPolicyName = null ; 
			String m_isProcessed = null ; 
			String m_action = null ;  
			try{
				m_policyTaskId = inputTaskIdCollection.getString(Constants.APPLY_POLICY_TASK_ID);
				int taskId=Integer.parseInt(m_policyTaskId);
				PolicyUtils.writeLog("m_currentInstanceNbr :: "+m_currentInstanceNbr);
				if((taskId%Integer.parseInt(m_totalInstanceNbr))!=Integer.parseInt(m_currentInstanceNbr)){
					PolicyUtils.writeLog("taskId%Integer.parseInt(m_totalInstanceNbr) :: "+taskId%Integer.parseInt(m_totalInstanceNbr));
					continue;
				}
				numberOfTasksProcessed ++;
				m_folderPath = inputTaskIdCollection.getString(Constants.FOLDER_PATH);
				m_retentionPolicyName = inputTaskIdCollection.getString(Constants.RETENTION_POLICY_NAME);
				m_isProcessed = inputTaskIdCollection.getString(Constants.ISPROCESSED);
				m_action = inputTaskIdCollection.getString(Constants.ACTION);
				PolicyUtils.updateRPSApplyStartEndTime(m_policyTaskId,Constants.START_TIME,dfSession);
				PolicyUtils.writeLog(m_policyTaskId + "########################################");
				PolicyUtils.writeLog("Process New Task : RPS Action = '"+m_action+"' and Processes Status ='"+m_isProcessed+"'");
				if(m_isProcessed != null && m_isProcessed.trim().length() > 0 && m_isProcessed.equalsIgnoreCase("N") ){
					if(m_folderPath != null && m_folderPath.trim().length() > 0 &&  PolicyUtils.isFolderPathExisting(m_folderPath,dfSession)){
						PolicyUtils.writeLog("Folder Exists : " + m_folderPath);
						String m_RetentionPolicyId = PolicyUtils.getRetentionPolicyObjectId(m_retentionPolicyName, dfSession);
						PolicyUtils.writeLog("Got Retention Policy Id : " + m_RetentionPolicyId);
						if (m_RetentionPolicyId != null && m_RetentionPolicyId.trim().length() > 0) {
							/**  Check if this policy is already applied on this folder */
							boolean isPolicyAlreadyApplied = PolicyUtils.checkIfPolicyIsAppliedOnTheFolder(m_RetentionPolicyId, m_folderPath, dfSession);
							PolicyUtils.writeLog("isPolicyAlreadyApplied = " + isPolicyAlreadyApplied);
							if(m_action != null && m_action.trim().length()>0 && m_action.equalsIgnoreCase("APPLY") == true ){
								PolicyUtils.executeApplyPolicy(dfSession, m_policyTaskId,m_folderPath, m_retentionPolicyName,m_RetentionPolicyId,isPolicyAlreadyApplied,m_client,bundle);
							}else if(m_action != null && m_action.trim().length()>0 && m_action.equalsIgnoreCase("REMOVE") == true ){
								PolicyUtils.executeRemovePolicy(dfSession, m_policyTaskId,m_folderPath, m_retentionPolicyName,m_RetentionPolicyId,isPolicyAlreadyApplied,m_client,bundle);
							}else if(m_action != null && m_action.trim().length()>0 && m_action.equalsIgnoreCase("UPDATE") == true ){
								PolicyUtils.writeLog("executeUpdate Action >>");
								String totalExecTime=Constants.TOTAL_EXECUTION_TIME;
								long strtTime=PolicyUtils.getTimeInMs();
								
								PolicyUtils.processExecLogTableRecords(m_policyTaskId, m_RetentionPolicyId, dfSession,bundle); 
								PolicyUtils.updateRPSApplyTaskProcessedStatus(m_policyTaskId,"Y",dfSession);
								
								long endTime=PolicyUtils.getTimeInMs();
								PolicyUtils.updateExecutionTime(m_policyTaskId,strtTime,endTime,totalExecTime,dfSession);
								PolicyUtils.writeLog("executeUpdate Action <<");
							}else{
								PolicyUtils.writeLog("Task Id :"+ m_policyTaskId + " :: action :'"+ m_action +"'  is unknown..");
							}
						}else {
							PolicyUtils.writeLog("Exception : Retention Policy Name :"+ m_retentionPolicyName + " not found");
						}
					}else{
						PolicyUtils.writeLog("Task Id :"+ m_policyTaskId+ " :: Exception : Invalid  m_folderPath:" + m_folderPath);
					}
				}else{
					PolicyUtils.writeLog("Processing >> Task Id :"+ m_policyTaskId+ " :: Exception : Invalid Is Processed Status :" + m_isProcessed);
				}
				PolicyUtils.updateRPSApplyStartEndTime(m_policyTaskId,Constants.END_TIME,dfSession);
				PolicyUtils.writeLog(m_action + " Completed >> Task Id :"+ m_policyTaskId + " :: folderPath :"+ m_folderPath + " :: retention Policy Name :"+ m_retentionPolicyName);
			}catch (Exception e) {
				e.printStackTrace();
			}			
			System.gc();
		}// end of while()
		if (inputTaskIdCollection != null)inputTaskIdCollection.close();
		PolicyUtils.writeLog("numberOfTasksProcessed : " + numberOfTasksProcessed);
		PolicyUtils.writeLog("doProcessing  << " + new Date());
	}



	protected IDfSessionManager login() throws DfException {
		if (m_docbase == null || m_userName == null)
			return null;
		// now login
		m_client = new DfClientX().getLocalClient();;

		if (m_client != null) {
			IDfLoginInfo li = new DfLoginInfo();
			li.setUser(m_userName);
			li.setPassword(m_password);
			li.setDomain(m_domain);

			IDfSessionManager sessionMgr = m_client.newSessionManager();
			sessionMgr.setIdentity(m_docbase, li);
			return sessionMgr;			
		}
		return null;
	}

	
	public boolean checkProcessCommand(){
		boolean keepAlive = true;
		try{
			Properties properties = new Properties();
			InputStream fis = ApplyRetentionPolicyJob.class.getResourceAsStream("/keepAlive.properties");  
			properties.load(fis);
			String command = properties.getProperty("COMMAND");
			    if(command.equalsIgnoreCase("STOP")){
			    	keepAlive = false;
			    }
			    fis.close();
		} catch (IOException e) {
			e.printStackTrace();
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return keepAlive;
	}
	
	IDfClient m_client = null;
	// Declaration of various variables needed in the method
	protected IDfSessionManager m_sessionMgr = null;
	protected String m_docbase = null;
	protected String m_userName = null;
	protected String m_password = null;
	protected String m_domain = null;
	protected String m_jobid = null;
	protected String m_mtl = "0";
	protected String m_strJobName = null;
	protected String m_strServerLog = "";
	protected String m_strFilename = "";
	protected ResourceBundle bundle=null;
	
	//custom job params
	protected String m_totalInstanceNbr = "1";
	protected String m_currentInstanceNbr = "0";
	
	protected IDfSession m_session = null;
	private Logger log = Logger.getLogger(ApplyRetentionPolicyJob.class);
}
