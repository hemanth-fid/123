/**
 * PCHW070Request_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W;

public class PCHW070Request_Type  implements java.io.Serializable {
    private gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070In_Type PCHW070In;

    public PCHW070Request_Type() {
    }

    public PCHW070Request_Type(
           gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070In_Type PCHW070In) {
           this.PCHW070In = PCHW070In;
    }


    /**
     * Gets the PCHW070In value for this PCHW070Request_Type.
     * 
     * @return PCHW070In
     */
    public gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070In_Type getPCHW070In() {
        return PCHW070In;
    }


    /**
     * Sets the PCHW070In value for this PCHW070Request_Type.
     * 
     * @param PCHW070In
     */
    public void setPCHW070In(gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070In_Type PCHW070In) {
        this.PCHW070In = PCHW070In;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PCHW070Request_Type)) return false;
        PCHW070Request_Type other = (PCHW070Request_Type) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.PCHW070In==null && other.getPCHW070In()==null) || 
             (this.PCHW070In!=null &&
              this.PCHW070In.equals(other.getPCHW070In())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPCHW070In() != null) {
            _hashCode += getPCHW070In().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PCHW070Request_Type.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "PCHW070Request_Type"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PCHW070In");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "PCHW070In"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "PCHW070In_Type"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
