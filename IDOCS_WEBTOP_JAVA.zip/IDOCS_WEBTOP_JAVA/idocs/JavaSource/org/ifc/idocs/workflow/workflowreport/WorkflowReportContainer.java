package org.ifc.idocs.workflow.workflowreport;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.component.PropertySheetContainer;

public class WorkflowReportContainer extends PropertySheetContainer{

	@Override
	public void onInit(ArgumentList arg0) {
		// TODO Auto-generated method stub
		super.onInit(arg0);
	}
	
	@Override
	public boolean onCancelChanges() {
		setComponentReturn();
		return true;
	}
	
	@Override
	public boolean onCommitChanges() {
		
		return false;
	}
}
