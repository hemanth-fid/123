package org.ifc.idocs.report;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Random;

import org.ifc.idocs.report.common.AppConfig;
import org.ifc.idocs.report.common.CommonUtils;
import org.ifc.idocs.report.db.ExportDAOImpl;
import org.ifc.idocs.report.db.ReportDAOImpl;
import org.ifc.idocs.report.documentum.ImportUtility;
import org.ifc.idocs.report.documentum.ReconUtility;
import org.ifc.idocs.report.export.CountryProjectDocExtraction;
import org.ifc.idocs.report.export.DeltaExportUtility;
import org.ifc.idocs.report.export.ExportUtility;
import org.ifc.idocs.report.reports.DocumentDetailReport;
import org.ifc.idocs.report.reports.DocumentReport;
import org.ifc.idocs.report.reports.SecurityExceptionReport;

public class ReportUtility {

	protected static final String propertiesFile = "/Report.properties";
	protected  static Properties idocsProperties = new Properties();
	private static AppConfig config = AppConfig.getInstance();

	public static Map<String,String> utilityMap = new HashMap<String,String>();
	
	/**
	 * 
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args){
		
//		TODO - create report for migration skipped docs both for import and export
//		TODO - remove the overload of adding report util code in xml
		
		initialCheck();
		getNewUtilityId();
		int choice=0;
	
		try{
			System.out.println("");
			System.out.println("*******************************************************************");
			System.out.println("*              iDocs - Documents Report Utilities                 *");
			System.out.println("*******************************************************************");
			System.out.println("");
			System.out.println("\t 1. Run Report Utility on Lotus Domino");
			System.out.println("\t 2. Delta Run Report Utility on Lotus Domino");
			System.out.println("\t 3. Generate Complete Reports (After Import)");
			System.out.println("\t 4. Run Report on Selected Documents from Table");
			System.out.println("\t 5. Run Report Utility on Documentum");
			System.out.println("\t 6. Update Recon Security Report ");
			System.out.println("\t 7. Update Import Skipped Table ");
			System.out.println("\t 8. Exit ");
			System.out.println("");
			System.out.println("*******************************************************************");
			System.out.print("Enter your Choice : ");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String menuChoice = br.readLine();
			System.out.println("");
		
			if(!menuChoice.equals("") || !menuChoice.equals(null)){
				try{
					choice = Integer.parseInt(menuChoice);
				}catch(NumberFormatException nfe){
					choice=0;
				}
			}
			if(((choice != 3)&&(choice != 0))){
				System.out.println("Choice : " + choice);
			}
			switch(choice){
				case 0 :
						String extractionQuery = config.getString("filters.extractioncriteriacode");
						String[] extCriteria = extractionQuery.split(";");
						for(int k = 0; k < extCriteria.length; k++){
							String extractionId = extCriteria[k];
							String utilityId = ExportDAOImpl.utilityIdIsExists(extractionId);
							if(utilityId != null){
								System.out.println("Are you sure, you want to delete all records related to  : " + utilityId + " ?");
								System.out.println("\t 1. Yes");
								System.out.println("\t 2. No");
								System.out.println("");
								System.out.print("Enter your Choice : ");
								br = new BufferedReader(new InputStreamReader(System.in));
								menuChoice = br.readLine();
								if(menuChoice.equals("1")){
									ReportDAOImpl.deleteAllReportRcords(utilityId);
								}
							}
						}
						break;
				case 1 :System.out.println("Run Report Utility on Lotus Domino...");				
						// Extract documents from lotus notes and saves in to migration report tables - for reporting
						new ExportUtility();
						break;
				case 2 :System.out.println("Delta Run Report Utility on Lotus Domino...");				
						// Extract documents only after cutoff date from lotus notes and saves in to migration report tables
						DeltaExportUtility.ExportUtilityDeltaRun();
						break;
				case 3 :
						// Report will generate XLS with details Id, Document Size and Document Count
						System.out.println("Generating Document Report...");					
						DocumentReport.createDocumentReport("TARGET");
						
						// Report will generate XLS with details of Level 1 SubFolders and Document Count
//						System.out.println("Generating Document Detail Report...");
//						DocumentDetailReport.createDetailReport("TARGET");
						
						// Report will generate XLS with Security Exceptions
						System.out.println("Generating Security Exception Report...");
						SecurityExceptionReport.createSecurityExceptionReport("TARGET");
						break;
				case 4 :
						System.out.println("Run Report on Selected Documents from Table");					
						new CountryProjectDocExtraction();
						break;
				case 5 :
						System.out.println("Run Report on Import side");					
						new ImportUtility();
						break;
				case 6 :
						System.out.println("Update Recon Security Table");					
						ReconUtility run = new ReconUtility();
						run.runReconUtility();
						break;
				case 7 :
						System.out.println("Update Import Skipped Table");					
						ReconUtility ru = new ReconUtility();
						ru.importSkippedDocsUpdation();
						break;
				case 8 :System.out.println("Exit - Execution Ended.");
						System.exit(0);
						break;
				case 9 :
					// Report will generate XLS with details Id, Document Size and Document Count
					System.out.println("Generating Document Report...");					
					DocumentReport.createDocumentReport("TARGET");
					break;
				case 10 :
					// Report will generate XLS with details of Level 1 SubFolders and Document Count
					System.out.println("Generating Document Detail Report...");
					DocumentDetailReport.createDetailReport("TARGET");
					break;
				case 11 :
					// Report will generate XLS with Security Exceptions
					System.out.println("Generating Security Exception Report...");
					SecurityExceptionReport.createSecurityExceptionReport("TARGET");
					break;

				default:System.out.println("Invalid Entry Please provide your selection again...");
			}	
		}catch(IOException ioe){
			System.out.println("IOException occurred. Exiting.");
			System.exit(0);
		}
	}

	/**
	 * initialCheck - checks all possible errors can occur during migration. 
	 * Displays error messages, if any required credentials are missing
	 * @return void
	 */
	private static void initialCheck(){
//		System.out.println("Java Library Path : " + System.getProperty("java.library.path"), false);
		System.out.println("Initial check is under process...");
		
		System.out.println("Checking properties file...");
		CommonUtils.checkForConfigFile(idocsProperties, ReportUtility.class.getResourceAsStream(propertiesFile), "Report", true);
		
		System.out.println("Checking folderman path...");
		CommonUtils.checkConfigAttributes("repository.foldermanPath", "Folderman Path", true);
		System.out.println("Checking server path...");
		CommonUtils.checkConfigAttributes("repository.server", "Server Name", true);
		System.out.println("Checking library path...");
		CommonUtils.checkConfigAttributes("repository.libPath", "Library Path", true);
//		System.out.println("Checking export path...");
//		CommonUtils.checkConfigAttributes("repository.exportPath", "Export Path", true);
//		System.out.println("Checking log path...");
//		CommonUtils.checkConfigAttributes("repository.logPath", "Log Path", true);

		System.out.println("Checking Databse driver...");
		CommonUtils.checkConfigAttributes("connection.driver", "Migration Database Driver", true);
		System.out.println("Checking Databse connection...");
		CommonUtils.checkConfigAttributes("connection.connectionName", "Migration Database Connection Name", true);
		System.out.println("Checking Databse user name...");
		CommonUtils.checkConfigAttributes("connection.u_name", "Migration Database User Name", true);
		System.out.println("Checking Databse password...");
		CommonUtils.checkConfigAttributes("connection.password", "Migration Database Password", true);

		System.out.println("Checking Extraction Criteria Code...");
		CommonUtils.checkConfigAttributes("filters.extractioncriteriacode", "Extraction Criteria Code", true);
		
//		System.out.println("Checking Databse tables... Please wait...");
//		ExportDAOImpl.databaseTableCheck();
		
	}

	/**
	 * getNewUtilityId sets the new utility id in the hash map
	 * @return void
	 */
	public static void getNewUtilityId(){
		String prefix = config.getString("filters.prefix");
		if(prefix != null){
			Date dts = new Date();
			Random randomGenerator = new Random();
			int randomInt = randomGenerator.nextInt(1000);
			String rndString = randomInt < 100 ? "0" + randomInt : randomInt + "";
			SimpleDateFormat sdt = new SimpleDateFormat("MMddyy_HHmmss");
			String utilityId = prefix + sdt.format(dts).toString()+ "_" + rndString;
			utilityMap.put("utilityId",utilityId);
		}else{
			System.out.println("Please add filters.prefix in config.xml");
			System.exit(0);
		}
	}
		
	
}
