package org.ifc.idocs.report.model;

public class DocumentDetailReportModel {
	
	private String reportUtilityCode;
	private String folderValueCode;
	private String folderTypeCode;
	private String level1FolderNme;
	private Integer level1SourceDocCnt;
	private Integer level1TargetDocCnt;
	private Integer level1ExtractDocCnt;
	private Double level1SourceDocSizeNbr;
	private Double level1TargetDocSizeNbr;	
	private Double level1ExtractDocSizeNbr;

	public DocumentDetailReportModel(){}
	
	public DocumentDetailReportModel(DocumentDetailReportModel ddrm){
		this.reportUtilityCode = ddrm.reportUtilityCode;
		this.folderValueCode = ddrm.folderValueCode;
		this.folderTypeCode = ddrm.folderTypeCode;		
		this.level1FolderNme = ddrm.level1FolderNme;
		this.level1SourceDocCnt = ddrm.level1SourceDocCnt;
		this.level1TargetDocCnt = ddrm.level1TargetDocCnt;
		this.level1SourceDocSizeNbr = ddrm.level1SourceDocSizeNbr;
		this.level1TargetDocSizeNbr = ddrm.level1TargetDocSizeNbr;
		this.level1ExtractDocCnt = ddrm.level1ExtractDocCnt;
		this.level1ExtractDocSizeNbr = ddrm.level1ExtractDocSizeNbr;
	}
	
	public String getFolderValueCode() {
		return folderValueCode;
	}
	public void setFolderValueCode(String folderValueCode) {
		this.folderValueCode = folderValueCode;
	}
	public String getFolderTypeCode() {
		return folderTypeCode;
	}
	public void setFolderTypeCode(String folderTypeCode) {
		this.folderTypeCode = folderTypeCode;
	}
	public String getReportUtilityCode() {
		return reportUtilityCode;
	}
	public void setReportUtilityCode(String reportUtilityCode) {
		this.reportUtilityCode = reportUtilityCode;
	}
	public String getLevel1FolderNme() {
		return level1FolderNme;
	}
	public void setLevel1FolderNme(String level1FolderNme) {
		this.level1FolderNme = level1FolderNme;
	}
	public Integer getLevel1SourceDocCnt() {
		return level1SourceDocCnt;
	}
	public void setLevel1SourceDocCnt(Integer level1SourceDocCnt) {
		this.level1SourceDocCnt = level1SourceDocCnt;
	}
	public Integer getLevel1TargetDocCnt() {
		return level1TargetDocCnt;
	}
	public void setLevel1TargetDocCnt(Integer level1TargetDocCnt) {
		this.level1TargetDocCnt = level1TargetDocCnt;
	}
	public Double getLevel1SourceDocSizeNbr() {
		return level1SourceDocSizeNbr;
	}
	public void setLevel1SourceDocSizeNbr(Double level1SourceDocSizeNbr) {
		this.level1SourceDocSizeNbr = level1SourceDocSizeNbr;
	}
	public Double getLevel1TargetDocSizeNbr() {
		return level1TargetDocSizeNbr;
	}
	public void setLevel1TargetDocSizeNbr(Double level1TargetDocSizeNbr) {
		this.level1TargetDocSizeNbr = level1TargetDocSizeNbr;
	}
	public Integer getLevel1ExtractDocCnt() {
		return level1ExtractDocCnt;
	}
	public void setLevel1ExtractDocCnt(Integer level1ExtractDocCnt) {
		this.level1ExtractDocCnt = level1ExtractDocCnt;
	}
	public Double getLevel1ExtractDocSizeNbr() {
		return level1ExtractDocSizeNbr;
	}
	public void setLevel1ExtractDocSizeNbr(Double level1ExtractDocSizeNbr) {
		this.level1ExtractDocSizeNbr = level1ExtractDocSizeNbr;
	}

}
