package org.ifc.idocs.importUtil;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class LogHelper {
	/*
	 * Get the logger for a particular object.
	 * @param object
	 * @return
	 */
	protected static final String LogHelperFile = "/logHelper.properties";
	protected  static Properties idocsLogProperties = new Properties();

	public static Logger getLogger(Object object)
 	{
		try
		{
			InputStream inputStream = LogHelper.class.getResourceAsStream(LogHelperFile);
			idocsLogProperties.load(inputStream);

			SimpleFormatter simpFormatter = new SimpleFormatter();
			Date now = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("dd_MM_yy_hh_mm_ss");
			String timeStamp = formatter.format(now);
			String fileName = idocsLogProperties.getProperty("MSG_LOG_PATH")+timeStamp+".log";
			FileHandler fileHandler = new FileHandler(fileName, 1024000, 10, false);
			fileHandler.setLevel(Level.ALL);
			fileHandler.setFormatter(simpFormatter);

			Logger logger = Logger.getLogger(object.getClass().getName());
			logger.addHandler(fileHandler);

			ConsoleHandler consoleHandler = new ConsoleHandler();
			consoleHandler.setLevel(Level.ALL);
			//logger.addHandler(consoleHandler);
			return logger;
		}
		catch (Exception ex)
		{
			//if no logging what to do. just printout for now.
//			ex.printStackTrace();
			return null;
		}
	} 
}
