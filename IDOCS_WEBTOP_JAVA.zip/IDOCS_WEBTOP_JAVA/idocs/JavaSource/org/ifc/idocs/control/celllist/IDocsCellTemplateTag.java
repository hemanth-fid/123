package org.ifc.idocs.control.celllist;

import java.io.IOException;

import javax.servlet.jsp.JspTagException;
import com.documentum.web.form.*;
import com.documentum.web.form.TagException;
import com.documentum.web.form.control.databound.CellTemplateTag;

public class IDocsCellTemplateTag extends CellTemplateTag {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	
	
	public IDocsCellTemplateTag()
    {
        m_strField = null;
        m_strType = null;
        m_strCurrentField = null;
        m_strCurrentLabel = null;
    }

    public void release()
    {
        super.release();
        m_strField = null;
        m_strType = null;
    }

    public void setField(String strField)
    {
        m_strField = strField;
    }

    public void setType(String strType)
    {
        m_strType = strType;
    }

    public String getCurrentField()
    {
        return m_strCurrentField;
    }

    public String getCurrentLabel()
    {
        return m_strCurrentLabel;
    }

    public int doStartTag()
        throws JspTagException
    {
    	IDocsCellTemplate template = (IDocsCellTemplate)getControl();
    	IDocsCellListTag parent = (IDocsCellListTag)findAncestorWithClass(this,IDocsCellListTag.class);
        if(parent == null)
            throw new IllegalStateException("CellTemplateTag must have a parent CellListTag!");
        IDocsCellList cellList = (IDocsCellList)parent.getControl();
        m_strCurrentField = null;
        if(template.isVisible())
        {
            m_strCurrentField = getNextField(template, cellList);
            return m_strCurrentField == null ? 0 : 2;
        } else
        {
            return 0;
        }
    }

    public int doAfterBody()
        throws JspTagException
    {
    	IDocsCellTemplate template = (IDocsCellTemplate)getControl();
        try
        {
            renderBody(getForm(), template);
        }
        catch(IOException e)
        {
            throw new TagException(e);
        }
        IDocsCellListTag parent = (IDocsCellListTag)findAncestorWithClass(this,IDocsCellListTag.class);
        IDocsCellList cellList = (IDocsCellList)parent.getControl();
        cellList.addCellTemplateOutput(m_strCurrentField, bodyContent.getString());
        m_strCurrentField = getNextField(template, cellList);
        if(m_strCurrentField != null)
        {
            bodyContent.clearBody();
            return 2;
        } else
        {
            return 0;
        }
    }

    public int doEndTag()
        throws JspTagException
    {
        try
        {
            renderEnd(getForm(), (IDocsCellTemplate)getControl());
        }
        catch(IOException e)
        {
            throw new TagException(e);
        }
        return 6;
    }

    protected Class getControlClass()
    {
        return IDocsCellTemplate.class;
    }

    protected void setControlProperties(Control control)
    {
        super.setControlProperties(control);
        IDocsCellTemplate template = (IDocsCellTemplate)control;
        if(m_strField != null && m_strType != null)
            throw new IllegalStateException("Type and field attributes are mutually exclusive!");
        if(m_strField != null)
            template.setField(m_strField);
        if(m_strType != null)
            template.setType(m_strType);
    }

    protected void renderBody(Form form, IDocsCellTemplate template)
        throws IOException
    {
        if(!template.isVisible())
            bodyContent.clearBody();
    }

    protected void renderEnd(Form form1, IDocsCellTemplate celltemplate)
        throws IOException
    {
    }

    private String getNextField(IDocsCellTemplate template, IDocsCellList cellList)
    {
        String strField;
        if(template.getField() != null)
            strField = cellList.getNextFieldForName(template.getField());
        else
        if(template.getType() != null)
            strField = cellList.getNextFieldForType(template.getType());
        else
            strField = cellList.getNextField();
        if(strField != null)
        {
            m_strCurrentLabel = cellList.lookupLabelForField(strField);
            if(m_strCurrentLabel == null)
                m_strCurrentLabel = strField;
        } else
        {
            m_strCurrentLabel = null;
        }
        return strField;
    }

    private String m_strField;
    private String m_strType;
    private String m_strCurrentField;
    private String m_strCurrentLabel;
	
	
	
	
	
	
	

}
