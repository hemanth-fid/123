/**
 * 
 */
package gov.dcra.filenet.ingest.impl;

import gov.dcra.filenet.ingest.constants.IngestConstants;
import gov.dcra.filenet.ingest.dbutils.DataBaseConnUtils;
import gov.dcra.filenet.ingest.filenetutils.FileNetConnectionUtil;
import gov.dcra.filenet.ingest.inter.IProjectDoxIngestProcessor;
import gov.dcra.filenet.ingest.utils.CommonUtils;
import gov.dcra.filenet.ingest.utils.PropertyReader;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;

import com.filenet.api.core.Domain;
import com.filenet.api.core.ObjectStore;

/**
 * @author Administrator
 *
 */

public class ProjectDoxIngestProcessor implements IProjectDoxIngestProcessor{

	private final static Logger log = Logger.getLogger(ProjectDoxIngestProcessor.class);
	private PropertyReader credentialsProps = null;
	private PropertyReader appProps = null;
	protected  Connection dbConn=null;
	private Map<String,String> docFormatMap=null;
	private static int ingestSuccessCntr;
	private static int ingestFailedCntr;
	private static StringBuffer ingestSuccessRprt=null;
	private static StringBuffer ingestfailedRprt=null;
	
	public Map<String, String> getDocFormatMap() {
		return docFormatMap;
	}

	public void setDocFormatMap(Map<String, String> docFormatMap) {
		this.docFormatMap = docFormatMap;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			ProjectDoxIngestProcessor proc=new ProjectDoxIngestProcessor();
			proc.processIngest();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	public void processIngest() {
		
		ingestSuccessCntr=0;
		ingestFailedCntr=0;
		ingestSuccessRprt=new StringBuffer();
		ingestfailedRprt=new StringBuffer();
		Domain domain = null;
		ObjectStore os = null;
		Connection dbConn=null;
		
		try {
			
			log.debug("Start Processing......");
			appProps=new PropertyReader(IngestConstants.APPLICATION_PROPS);
			credentialsProps=new PropertyReader(IngestConstants.CREDENTAILS_PROPS);
			
			domain = FileNetConnectionUtil.getDomain();
			os = FileNetConnectionUtil.getObjectStore(domain,appProps.getProperty(IngestConstants.MSG_OBJECTSTORE_NAME));
			
			dbConn=DataBaseConnUtils.createDBConnection
			(credentialsProps.getProperty(IngestConstants.DB_URL), 
					credentialsProps.getProperty(IngestConstants.DB_USER_NAME), 
					credentialsProps.getProperty(IngestConstants.DB_PASSWORD), 
					credentialsProps.getProperty(IngestConstants.DB_DRIVER_NAME));
			
			
			setDocFormatMap(CommonUtils.getDocFormatMap(appProps));
			
			String srcIngestQry="qry";
			ResultSet srcIngestRs=DataBaseConnUtils.executeSelectQryInDB(dbConn, srcIngestQry);

			while(srcIngestRs.next()){
				
				try{
					
					
					String projectID=srcIngestRs.getString("ProjectID");
					
					
					//Map<String,String> propertiesMap=buildPropertiesMap();
					//String docId=FileNetUtil.create(parent, fileStream, propertiesMap);
					
					/*if(StringUtils.isNotBlank(docId)){

						String updateQry=MessageFormat.format("update Success Qry","");
						DataBaseConnUtils.executeUpdateQryInDB(dbConn, updateQry,false);
						
						ingestSuccessCntr++;
						append ingestSuccessRprt with success record
						
					}*/
					
					
					
				}catch(Exception e){

					String updateQry=MessageFormat.format("update Fail Qry","");
					try {
						log.debug(updateQry);
						DataBaseConnUtils.executeUpdateQryInDB(dbConn, updateQry,false);
					} catch (SQLException e1) {
						log.error("Error Inserting record in table: "+ExceptionUtils.getFullStackTrace(e1.fillInStackTrace()));
					}
					ingestFailedCntr++;
					//append ingestfailedRprt with fail record
				}
			}
					
			//create(getFolder(os,folderPath),new FileInputStream(new File(file)),FilenameUtils.getBaseName(file));
			
			StringBuffer jobReport=new StringBuffer();

			jobReport.append(IngestConstants.NEWLINE);

			jobReport.append("Total No. of Records Processed ").append(": ").append(ingestSuccessCntr+ingestFailedCntr).append(IngestConstants.NEWLINE);
			jobReport.append("------------------------------------------------------").append(IngestConstants.NEWLINE);
			jobReport.append("Success ").append(": ").append(ingestSuccessCntr).append(IngestConstants.NEWLINE);
			jobReport.append(ingestSuccessRprt.toString()).append(IngestConstants.NEWLINE);


			jobReport.append("Failed ").append(": ").append(ingestFailedCntr).append(IngestConstants.NEWLINE);
			jobReport.append(ingestfailedRprt.toString());
			jobReport.append("------------------------------------------------------").append(IngestConstants.NEWLINE);
			log.info(IngestConstants.NEWLINE+jobReport.toString());

			log.info("End Processing");
			
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{

			try{
				DataBaseConnUtils.closeDBConnection(dbConn);
			}catch(SQLException e){
				log.error("Error Closing Connection : "+ExceptionUtils.getFullStackTrace(e.fillInStackTrace()));
			}

			try {
				//release filenet conn
			} catch (Exception e) {
				log.error("Error releasing Connection : "+ExceptionUtils.getFullStackTrace(e.fillInStackTrace()));
			}
		}

	}

	private  Map<String, String> buildPropertiesMap(String projectId,String projectName,String fileName) throws Exception {
		Map<String,String> propertiesMap = new HashMap<String,String>();
		
		//if(rs!=null){

				//map.put("attrName","attrVal");
				String folderPath=appProps.getProperty(IngestConstants.TARGET_FOLDER_PATH);
				propertiesMap.put("fielFormat",getDocFormatMap().get("sub string file extension"));
		//	}
		return propertiesMap;
		}
	
}
