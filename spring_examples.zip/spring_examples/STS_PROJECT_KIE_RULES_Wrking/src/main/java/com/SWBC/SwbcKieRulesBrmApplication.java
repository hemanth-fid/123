package com.SWBC;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.core.SpringVersion;


@SpringBootApplication
public class SwbcKieRulesBrmApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		
		
		SpringApplication.run(SwbcKieRulesBrmApplication.class, args);

	}

}
