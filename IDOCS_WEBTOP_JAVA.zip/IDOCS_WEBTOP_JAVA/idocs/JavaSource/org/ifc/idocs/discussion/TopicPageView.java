/**
 * users selected in to, cc and bcc fields and send mail to selected users.
 * 
 * #########################################################################
 * Author		 	  DateofChange	 Version		ModificationHistory
 * #########################################################################
 * Chitra Vattathara    10/17/2010	     1.0          Created
 * #########################################################################
 * L V Sudhakar         08/02/2012	     1.1          modified
 * #########################################################################
 */

package org.ifc.idocs.discussion;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;


import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.services.EmailSender;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;


import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfUser;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.form.Form;
import com.documentum.web.form.FormActionReturnListener;
import com.documentum.web.form.control.Breadcrumb;
import com.documentum.web.form.control.Button;
import com.documentum.web.form.control.ListBox;
import com.documentum.web.form.control.Option;
import com.documentum.web.form.control.Text;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.control.richtext.RichTextEditor;
import com.documentum.web.formext.drl.DRLComponent;
import com.documentum.webcomponent.common.WebComponentErrorService;

public class TopicPageView extends com.documentum.webtop.webcomponent.discussion.TopicPageView
{
	private static final String COC_VP_RESPONSE = "COC Comment or Response : ";
	private static final String QRY_PACKAGE_DETAILS = "QRY_PACKAGE_DETAILS";
	private static final String QRY_COC_DATE = "QRY_COC_DATE";
	private static final String WF_FORM = "Wf_Form";
	private static final String R_COMPONENT_ID = "r_component_id";
	private static final String R_PACKAGE_NAME = "r_package_name";
	private static final String NULLDATE = "nulldate";
	private static final String CALL_FOR_MEETING = " - Call for Meeting";
	private static final String STR_CLOSING_BRACK = ")";
	private static final String DUE = " (Due :";
	private static final String CIRCULATION2 = " - Circulation";
	private static final String CIRCULATION = "Circulation";
	private static final String MEETING = "Meeting";
	private static final String LD_CHOICE = "ld_choice";
	private static final String COC_DUE_DATE = "coc_due_date";
	private static final String PDS_CONCEPT = " PDS Concept";

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String GROUP_NAME="group_nme";
	private String USER_EMAIL = "user_address";
	HashMap<String, String> map_topicDetails;
	HashMap<String, ArrayList<String>> map_emailAddress =null;
	private String template_title;
	private String workflow_Id;
	private String DOC_NAME = "docName";
	private String PROJECT_NAME = "projName";
	private String PROJECT_ID = "projID";
	private String WRKFLOW_STATUS=null;
	private String SEPARATOR = " : ";
	boolean validcoc=false;
	private int  c_type;

	static final String TO_LIST= "toList";
	static final String CC_LIST= "ccList";
	static final String BCC_LIST= "bccList";
	static final String content_type= "text/html";

	public static final String TITLE_BOX = "attribute_object_name";
	public static final String COMMENT_BODY = "comment_body";

	public static final String KEY_PROJECT = "project";
	public static final String KEY_INSTITUTION = "institution";
	public static final String KEY_COUNTRY = "country";
	private static final String QRY_VARIABLE_OBJECTID = "<objectid>";
	IdocsUtil idocs_util = null;
     
	public String CALLER_COMPONENT="";
	boolean addCommentFlag=false;
	private static final String CALLER_ARGS="caller"; 
	private String objectId="";
	public boolean callerExistanceStatus=false;
    public boolean topicAspectexisted=false;
    public boolean updateService=false;
    public boolean adminUpdateServiceEnable=false;
    public String lockOwnerName=null;
    public boolean nonUpdateSerVice=false;
   /**
	 * Constructor for TopicPageView.
	 * 
	 */
	public TopicPageView(){
		this.map_topicDetails = new HashMap<String, String>();
		idocs_util = new IdocsUtil();
	}
	
	public void navigator(Breadcrumb control, ArgumentList args){
		
		String strFolderPath = control.getValue();
        int iFirstSlash = strFolderPath.indexOf('/', 1);
        if(iFirstSlash != -1)
            strFolderPath = strFolderPath.substring(iFirstSlash);
        else
            strFolderPath = "";
        navigateToFolder(strFolderPath);
	}
	
	public void onClickStartDiscussion(Control control, ArgumentList args)
    {
		IDfCollection dfCollection =null;
        try
        {
        	dfCollection = IdocsUtil.executeQuery(getDfSession(),"select r_lock_owner from idocs_document where r_object_id='"+objectId+"'",IDfQuery.DF_READ_QUERY);
        	while(dfCollection.next()){
        		lockOwnerName=dfCollection.getString(IdocsConstants.R_LOCK_OWNER);
        	}
        
        	if(lockOwnerName != null &&  lockOwnerName .trim().length() >0 ){
        		if(lockOwnerName.equals(getDfSession().getLoginUserName())){
        			 updateService=true;
        		 }else if(lockOwnerName.equals(getDfSession().getDocbaseOwnerName())){
        			 nonUpdateSerVice=true;
        			 lockOwnerName="IFCDocs System";
        		 }else{
        			nonUpdateSerVice=true;
        		}
        	}else{
        		  updateService=true;
        		}
          /**validating to enable discussions or not */
        	if(updateService){
        		m_topicId = ((IDfSysObject)createTopic()).getObjectId().toString();
        	}else{
        		DfLogger.info(this," onClickStartDiscussion :: discussions can not enable on this document .. it is locked by another user",null,null);
        	}
            topicAspectexisted=true;
        }catch(DfException de)
        {
            WebComponentErrorService.getService().setNonFatalError(this, "MSG_ERROR_ACCESSING_TOPIC", de);
        }finally{
        	if(dfCollection != null){
        		try {
					dfCollection.close();
				} catch (DfException e) {
					// TODO Auto-generated catch block
					DfLogger.error(this, "colletion close Exception"+e.getMessage(),null, null);
				} 
        	}
        }
    }
	 
/**
 * 
 */
 public void onClickFolderPath(Breadcrumb control, ArgumentList args) {
  if (CALLER_COMPONENT != null && CALLER_COMPONENT.length() > 0) {
		callerNavigation(control, args);
	}else {
	/** no caller component leave it to default */
		DfLogger.info(this," onClickFolderPath :: Caller Component for Discussions not existed ",null, null);
		navigator(control, args);
	 }
	}
	
	/**
	 * onInit method of showtopic component. This method is overriden and setTitle() method is called which 
	 * sets the title to 'COC/VP Response' if the loggedin user is a memeber of COC or VP groups.
	 * args ArgumentList	  
//	 * @return void
	 */
 public void onInit(ArgumentList args)
 {
	 DfLogger.info(this, " :: onInit",null,null);
	 objectId=args.get("objectId");
	 CALLER_COMPONENT=args.get(CALLER_ARGS);
	/** To Redirect to Main again */
	 if(CALLER_COMPONENT != null && CALLER_COMPONENT. length() > 0){
		 DfLogger.info(this,"Caller Component for Discussions existed "+CALLER_COMPONENT,null,null);
		 callerExistanceStatus=true;
		 IDfCollection dfCollection =null;
		 try {
			 String latestVesrionId="";
			 String queryGetLatestVersion=IdocsUtil.getMessage("QRY_GETLATEST_VERSION_DOC");
			 queryGetLatestVersion=queryGetLatestVersion.replace(STR_OBJECT_ID_REPLACE_STRING,(IdocsConstants.MSG_QUOTES+objectId+IdocsConstants.MSG_QUOTES));
			 DfLogger.info(this, "onInit :: queryGetLatestVersion"+queryGetLatestVersion,null,null);
			 dfCollection=IdocsUtil.executeQuery(getDfSession(),queryGetLatestVersion, IDfQuery.DF_READ_QUERY);
			 if(dfCollection != null){
				 while(dfCollection.next()){
					 latestVesrionId= dfCollection.getString(IdocsConstants.R_OBJECT_ID);
					 }
				 }
			 if(latestVesrionId != null && latestVesrionId.trim().length() >0 && !latestVesrionId.equals(IDocsConstants.BLANK_OBJECT_ID)){
				 objectId=latestVesrionId;
				 args.replace("objectId", latestVesrionId);
			 }else{
				 DfLogger.info(this, "onInit :: Failed to get Latest Varsion",null,null);
			 }
			 
			 String discussionEnabledOrQuery=IdocsUtil.getMessage("QRY_DISCUSSIONENABLED_OR_NOT");
			 discussionEnabledOrQuery=discussionEnabledOrQuery.replace(STR_OBJECT_ID_REPLACE_STRING,(IdocsConstants.MSG_QUOTES+objectId+IdocsConstants.MSG_QUOTES));
			 dfCollection=IdocsUtil.executeQuery(getDfSession(),discussionEnabledOrQuery, IDfQuery.DF_READ_QUERY);
			 
			 if(dfCollection != null){
				 while(dfCollection.next()){
					 String rObjectID = dfCollection.getString(IdocsConstants.R_OBJECT_ID);
					 if(rObjectID != null && rObjectID.trim().length() >0 && !rObjectID.equals(IDocsConstants.BLANK_OBJECT_ID)){
						 topicAspectexisted=true;
						 }
					 }
				 }
			 }catch (DfException e) {
				 DfLogger.error(this,"onInit Exception  ::"+e.getMessage(),null,null);
				 }finally{
					 if(dfCollection != null){
						 try {
							 dfCollection.close();
							 } catch (DfException e) {
								 DfLogger.error(this,"onInit Exception  ::"+e.getMessage(),null,null);
								 }
							 }
					 }
				 
				 if(topicAspectexisted){
					 DfLogger.info(this, "No need to redirect topic existed ",null ,null);
					 }else{
						 DfLogger.info(this, "Need to redirect topic not existed ",null ,null);
						 }
				 }else{
					 DfLogger.info(this,"Caller Component for Discussions not existed ",null,null);
					 }
	 super.onInit(args);
	 validcoc=isCOCVPMember();
	 DfLogger.info(this, " :: Valid coc :"+validcoc,null,null);
	 setTitle(validcoc);
	}
	
	/**
	 * 
	 * @param control
	 * @param args
	 */
	private void callerNavigation(Breadcrumb control,ArgumentList args){
  
	  if(CALLER_COMPONENT != null && CALLER_COMPONENT. length() > 0){
	  IDfCollection typeCollection=null;
	  /** adding attributes and redirect to main component back */ 
	  DfLogger.info(this," callerNavigation :: Caller Component for Discussions existed "+CALLER_COMPONENT,null,null);
	  if(objectId != null && objectId.trim().length()> 0 && ! objectId.equals(IDocsConstants.BLANK_OBJECT_ID)){
		 try {
			 String query="select r_object_type from idocs_document where r_object_id='"+objectId+"'";
			 String type ="";
			 typeCollection= IdocsUtil.executeQuery(getDfSession(), query, IDfQuery.DF_READ_QUERY);
			 String argsProjectOrPartenrOrCountryName="";
			 String argsProjectOrPartnerOrCountryValue="";
			 String argTypeName="type";
			 String argTypeVaue="";
			 if(typeCollection != null){
					while(typeCollection.next()){
						type=typeCollection.getString(IdocsConstants.R_OBJECT_TYPE);
					}
			if(type != null && type.trim().length() >0){
			if(type.equals(IDocsConstants.MSG_IDOCS_PROJECT_DOC)){
				argsProjectOrPartenrOrCountryName="projectId";
				String queryforProj=IdocsUtil.getMessage("QRY_IDOCS_PROJECT_OBJECT_ID");
				queryforProj=queryforProj.replace(STR_OBJECT_ID_REPLACE_STRING,(IdocsConstants.MSG_QUOTES+objectId+IdocsConstants.MSG_QUOTES));
				typeCollection = IdocsUtil.executeQuery(getDfSession(), queryforProj, IDfQuery.DF_READ_QUERY);
				if(typeCollection != null){
					while(typeCollection.next()){
						argsProjectOrPartnerOrCountryValue=typeCollection.getString(IDocsConstants.PROJECT_ID);
						}
					argTypeVaue=STR_PROJECT_TYPE;
					}else{
						DfLogger.info(this, "callerNavigation :: project_id not existed on document of type idocs_project_doc", null, null);
					 }
			 }else if(type.equals(IDocsConstants.MSG_IDOCS_INSTITUTION_DOC)){
				 argsProjectOrPartenrOrCountryName="partnerId";
				 String queryforInstitution=IdocsUtil.getMessage("QRY_IDOCS_INSTITUTION_OBJECT_ID");
				 queryforInstitution=queryforInstitution.replace(STR_OBJECT_ID_REPLACE_STRING,(IdocsConstants.MSG_QUOTES+objectId+IdocsConstants.MSG_QUOTES));
				 typeCollection = IdocsUtil.executeQuery(getDfSession(),queryforInstitution, IDfQuery.DF_READ_QUERY);
				 if(typeCollection != null){
					 while(typeCollection.next()){
						 argsProjectOrPartnerOrCountryValue=typeCollection.getString(IDocsConstants.INSTITUTION_NBR);
						 }
					 argTypeVaue=STR_PARTNER_TYPE;
					 }else{
						 DfLogger.info(this, "callerNavigation :: institution_nbr not existed on document of type idocs_institution_doc", null, null);
						 }
			}else if(type.equals(IDocsConstants.MSG_IDOCS_INSTITUTION_DOC)){
				argsProjectOrPartenrOrCountryName="country_code";
				String queryforCountry=IdocsUtil.getMessage("QRY_IDOCS_COUNTRY_OBJECT_IDselect");
				queryforCountry=queryforCountry.replace(STR_OBJECT_ID_REPLACE_STRING,("'"+objectId+"'"));
				typeCollection = IdocsUtil.executeQuery(getDfSession(),queryforCountry, IDfQuery.DF_READ_QUERY);
				if(typeCollection != null){
					while(typeCollection.next()){
						argsProjectOrPartnerOrCountryValue=typeCollection.getString("country_code");
						}
					argTypeVaue=STR_COUNTRY_TYPE;
					}else{
						DfLogger.info(this, "callerNavigation :: country_code not existed on document of type idocs_country_doc", null, null);
						}
				}else{
					DfLogger.info(this, "callerNavigation :: document is not the type of IFCDocs "+argsProjectOrPartenrOrCountryName, null, null);
					}
			}
		/** Verifying Values before redirecting */
			if(argsProjectOrPartenrOrCountryName != null && argsProjectOrPartenrOrCountryName.trim().length() >0
					&& argsProjectOrPartnerOrCountryValue != null && argsProjectOrPartnerOrCountryValue.trim().length() >0
					&& argTypeVaue != null && argTypeVaue.trim().length() >0){
				args.add(argsProjectOrPartenrOrCountryName, argsProjectOrPartnerOrCountryValue);
				args.add(argTypeName, argTypeVaue);
				setComponentJump("main", args, getContext());
				}else{
					navigator(control,args);
					}
			}else{
				navigator(control,args);
				}
			 }catch (DfException e){
				 DfLogger.error(this,"callerNavigation :: Exception ::"+e.getMessage(),null,null);
			 }finally{
				 if(typeCollection != null){
					 try {
						 typeCollection.close();
						 } catch (DfException e) {
							 DfLogger.error(this,"callerNavigation :: Exception ::"+e.getMessage(),null,null);
							 }
						 }else{
							 DfLogger.debug(this,"callerNavigation ::typeCollection is Null no need to close", null,null);
							 }
				 }
			 }else{
			 /** no caller component leave it to default */
				 DfLogger.info(this," onClickFolderPath :: Caller Component for Discussions not existed ",null,null);
				 navigator(control,args);
				 }
	  }
	  }
	
	public void onClickBackButton(Button button,ArgumentList args){
		
		Breadcrumb breadcrumb = (Breadcrumb)getControl("commentlist_breadcrumb", Breadcrumb.class);
		
		String strFolderPath = breadcrumb.getValue();
        int iFirstSlash = strFolderPath.indexOf('/', 1);
        if(iFirstSlash != -1)
            strFolderPath = strFolderPath.substring(iFirstSlash);
        else
            strFolderPath = "";
        if(CALLER_COMPONENT != null && CALLER_COMPONENT. length() > 0){
        	callerNavigation(breadcrumb,args);
		}else{
			DfLogger.info(this,"Caller Component for Discussions not existed ",null,null);
			 navigateToFolder(strFolderPath);
		}
	}
	/**
	 * onRender method of showtopic component. This method is overriden and setTitle() method is called which 
	 * sets the title to 'COC/VP Response' if the loggedin user is a memeber of COC or VP groups.
	 * args ArgumentList	  
	 * @return void
	 */	
	public void onRender()
	{
		super.onRender();
		DfLogger.info(this, " :: Valid coc :"+validcoc,null,null);
		setTitle(validcoc);		
	}

	/**
	 * The method which is called when user clicks on 'Ok and Notify' button in comment editor.
	 * This method calls onSelectRecipients() which invokes the discussionuserorgrouplocator component.
	 * @param button	
	 * @param args  
	 * @return void
	 * @throws DfException 
	 */
	public void onClickOkNNotify(Control button, ArgumentList args) throws DfException
	{
		String circulationDueDate = null;
		String leadDirectorChoice = null;
		boolean isCallForMeeting = false;
		boolean isCirculation = false;
		String workflowPackageName = null;
		String componentObjectId = null;
		DfLogger.info(this, " :: onClickOkNotify",null,null);
		
		super.validate();
		if(getIsValid() == true)
		{
			onSelectRecipients();
		}

		/**Setting subject for email*******************/
		StringBuffer emailSubject = new StringBuffer();
		Text nameTextControl = (Text)getControl(TITLE_BOX, Text.class);
		String strCommentTitle = nameTextControl.getValue();
		DfLogger.info(this, " :: Comment Title : " + strCommentTitle,null,null);
		emailSubject.append(strCommentTitle).append(SEPARATOR);		

		String strDocObjectID = this.m_dfObjId.toString();
		System.out.println("m_dfObjId"+m_dfObjId);
		HashMap<String, String> mp_docProps = getDocProperties(strDocObjectID);		

		int type = getFolderType(strDocObjectID);

		if(null != mp_docProps)
		{		
			template_title = IdocsUtil.getTemplateTitle(getDfSession(), strDocObjectID);
			DfLogger.debug(this, " :: Template tile : " + template_title,null,null);
			DfLogger.debug(this, " :: Workflow status : " +mp_docProps.get(WRKFLOW_STATUS),null,null);
			DfLogger.debug(this, " :: Tier Name : " +mp_docProps.get(IdocsConstants.MSG_PROJECT_TIER_NME),null,null);
			String strPDSConceptTemplateTitle = IdocsUtil.getMessage("MSG_TEMPLATE_PDS_CONCEPT");
			DfLogger.debug(this, " :: Template : " +strPDSConceptTemplateTitle,null,null);
			//PDS concept mail subject
			if(strPDSConceptTemplateTitle!=null && strPDSConceptTemplateTitle.trim().length() > 0 
					&& strPDSConceptTemplateTitle.equals(template_title) == true){
					DfLogger.debug(this, " :: PDS Concept found, COC email subject calculation : ",null,null);
					try{
						if(mp_docProps.get(WRKFLOW_STATUS)==null){
							emailSubject.append(mp_docProps.get(DOC_NAME)).append(SEPARATOR).append(mp_docProps.get(PROJECT_NAME)).append(SEPARATOR).append(mp_docProps.get(PROJECT_ID));
							DfLogger.debug(this, " :: Doc not part of workflow :emailSubject = "+emailSubject,null,null);
						}else if(!((mp_docProps.get(WRKFLOW_STATUS).trim()).length()>0) ){
						
							emailSubject.append(mp_docProps.get(DOC_NAME)).append(SEPARATOR).append(mp_docProps.get(PROJECT_NAME)).append(SEPARATOR).append(mp_docProps.get(PROJECT_ID));
							DfLogger.debug(this, " :: Doc not part of workflow :emailSubject = "+emailSubject,null,null);
						}else{
//							Get workflow id from document id
							workflow_Id = IdocsUtil.getWorkflowId(getDfSession(), strDocObjectID);
							DfLogger.info(this, "Workflow Id of this Document ="+workflow_Id, null, null);
							if(workflow_Id!=null){
								//Get package type
								String strQrygetPackagetype = IdocsUtil.getMessage(QRY_PACKAGE_DETAILS);
								strQrygetPackagetype=strQrygetPackagetype.replace("''","'"+workflow_Id+"'");
								DfLogger.info(this, "strQrygetPackagetype="+strQrygetPackagetype, null, null);
								IDfCollection PackageCollection = executeQuery(strQrygetPackagetype);
								while(PackageCollection.next()) {
									workflowPackageName = PackageCollection.getString(R_PACKAGE_NAME);
									componentObjectId=PackageCollection.getString(R_COMPONENT_ID);
									if(workflowPackageName.equals(WF_FORM)== true )
										break;
								}
								if(PackageCollection!=null)PackageCollection.close();
							}
							DfLogger.info(this, "Package name ="+workflowPackageName +" :: Component Id ="+componentObjectId, null, null);
				
							if(componentObjectId!=null && componentObjectId.trim().length()>0){	
								circulationDueDate = null;
								String strQrygetCocDate = IdocsUtil.getMessage(QRY_COC_DATE);
								strQrygetCocDate=strQrygetCocDate.replace("''","'"+componentObjectId+"'");
								DfLogger.info(this, "strQrygetCocDate="+strQrygetCocDate, null, null);
								IDfCollection cocCollection = executeQuery(strQrygetCocDate);
								while(cocCollection.next()) {
									circulationDueDate = cocCollection.getString(COC_DUE_DATE);
									leadDirectorChoice = cocCollection.getString(LD_CHOICE);									
								}
								if(cocCollection != null ){cocCollection.close();}
							}	
							DfLogger.info(this, "COC due date ="+circulationDueDate +" :: LD choice ="+leadDirectorChoice, null, null);
							if(circulationDueDate.equals(NULLDATE)==true){
								emailSubject.append(mp_docProps.get(DOC_NAME)).append(SEPARATOR).append(mp_docProps.get(PROJECT_NAME)).append(SEPARATOR).append(mp_docProps.get(PROJECT_ID));
													
							}else{
								if(leadDirectorChoice !=null && leadDirectorChoice.trim().length() > 0){
									if(leadDirectorChoice.contains(MEETING)){
										isCallForMeeting = true;
									}else if(leadDirectorChoice.contains(CIRCULATION)){
										isCirculation = true;
									}
								}DfLogger.info(this, "isCirculation="+isCirculation+" isCallForMeeting="+isCallForMeeting+" circulationDueDate="+circulationDueDate, null, null);
								DfLogger.info(this, "COC due date before formatting : "+circulationDueDate, null, null);
								SimpleDateFormat cocinputdate = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss"); 
								SimpleDateFormat cocdateformat = new SimpleDateFormat("MM/dd/yyyy");  
								String cocduedate = cocdateformat.format(cocinputdate.parse(circulationDueDate)); 
								DfLogger.info(this, "COC due date after formatting : "+cocduedate, null, null);
								if(isCirculation == true
										||(isCallForMeeting == true && circulationDueDate != null)){
									if(isCallForMeeting){//Append Call for Meeting
										emailSubject.append(PDS_CONCEPT).append(SEPARATOR)
													.append(mp_docProps.get(IdocsConstants.COUNTRY_NAME)).append(SEPARATOR)
													.append(mp_docProps.get(PROJECT_NAME)).append(SEPARATOR)
													.append(mp_docProps.get(PROJECT_ID)).append(SEPARATOR)
													.append(mp_docProps.get(IdocsConstants.MSG_PROJECT_TIER_NME))
													.append(CALL_FOR_MEETING);
									}else if(isCirculation){
										//Append - Circulation (e.g. Due 12/19/2011)					
										emailSubject.append(PDS_CONCEPT).append(SEPARATOR)
													.append(mp_docProps.get(IdocsConstants.COUNTRY_NAME)).append(SEPARATOR)
													.append(mp_docProps.get(PROJECT_NAME)).append(SEPARATOR)
													.append(mp_docProps.get(PROJECT_ID)).append(SEPARATOR)
													.append(mp_docProps.get(IdocsConstants.MSG_PROJECT_TIER_NME))
													.append(CIRCULATION2).append(DUE).append(cocduedate).append(STR_CLOSING_BRACK);	
									}
								}				
							}
						}
					}catch (Exception e) {
						DfLogger.error(this, "Exception in calculating the Discussion Email :"+e.getMessage(), null, null);
					}
			}else{
				DfLogger.debug(this, " :: Not a PDS Concept, normal email subject : ",null,null);
				emailSubject.append(mp_docProps.get(DOC_NAME)).append(SEPARATOR);
				switch(type){
				
					case IdocsConstants.PROJECT_TYPE 	:	
					{
						if(null!= mp_docProps.get(PROJECT_NAME)){
							emailSubject.append(mp_docProps.get(PROJECT_NAME)).append(SEPARATOR);
						}
						if(null!= mp_docProps.get(PROJECT_ID)){
							emailSubject.append(mp_docProps.get(PROJECT_ID));
						}					
						break;
					}
					
					case IdocsConstants.INSTITUTION_TYPE 	:
					{
						emailSubject.append(mp_docProps.get(IdocsConstants.INSTITUTION_SHORT_NAME)).append(SEPARATOR);
						emailSubject.append(mp_docProps.get(IdocsConstants.INSTITUTION_ID));
						break;
					}
					
					case IdocsConstants.COUNTRY_TYPE 		:	
					{
						emailSubject.append(mp_docProps.get(IdocsConstants.COUNTRY_NAME)).append(SEPARATOR);
						emailSubject.append(mp_docProps.get(IdocsConstants.COUNTRY_CODE));
						break;
					}
					
					default: 
						break;
				}		
			}
		}
		
		DfLogger.info(this, " :: Email full Subject : " + emailSubject.toString(),null,null);
		map_topicDetails.put(IdocsConstants.MAIL_SUBJECT, emailSubject.toString());
		/**Setting message  for email*******************/
		RichTextEditor rtControl = (RichTextEditor)getControl(COMMENT_BODY, com.documentum.web.formext.control.richtext.RichTextEditor.class);
		String strComment = rtControl.getValue();
		//String str_StaticMessage = prepareEmailMessage(strDocObjectID);
		String str_StaticMessage = prepareEmailMessageForDicussion(strDocObjectID);
		strComment = strComment + str_StaticMessage;		
		map_topicDetails.put(IdocsConstants.MAIL_BODY, strComment);

		/**Saving the comment*******************/
		//super.validate();
		if (getIsValid() == true){
			if ((this.m_editorType != null) && (this.m_editorType.equals("is_editor_open"))){
				editComment();
			}else if (this.m_editorType != null){
				createNewComment();
			}
			setRefreshDataRequired(true, false);
		}else{
			enableRemoveControls(false);
		}
		DfLogger.info(this, " :: End of onclick ok notify..",null,null);
	}

	
	/**
	 * The method which is called from onClickOkNNotify method when user clicks on 'Ok and Notify' button 
	 * in comment editor. This method sets the argumentlists and invokes 
	 * the 'discussionuserorgrouplocatorcontainer' component.
	 * @return void
	 */
	public void onSelectRecipients(){
		DfLogger.info(this, " :: onSelectRecipients: ",null,null);

		ArgumentList myargs = new ArgumentList();
		myargs.add("multiselect", "true");

		//Object ID of the document
		IDfId m_dfObjId=this.m_dfObjId;
		String project_id=null;
		String type = null;

		int c_parentFolderType = getFolderType(m_dfObjId.toString());
		DfLogger.info(this, " :: onSelectRecipients:: c_parentFolderType: " + c_parentFolderType,null,null);
		switch(c_parentFolderType){
			case IdocsConstants.PROJECT_TYPE :
			{
				project_id = getProjectId(m_dfObjId.toString());	
				type = KEY_PROJECT;
				break;
			}
			
			case IdocsConstants.INSTITUTION_TYPE :
			{
				project_id = getProjectId();
				type = KEY_INSTITUTION;
				break;
			}
			
			case IdocsConstants.COUNTRY_TYPE :
			{
				type=KEY_COUNTRY;
				break;
			}
		}
		myargs.add("projectId", project_id);
		myargs.add("type", type);
		myargs.add("documentID",m_dfObjId.toString());
		//Calling usergroup locator container
		invokeRecipientLocator("discussionuserorgrouplocatorcontainer", myargs);
	}

	/**
	 * This method sets the static part of the email message. It also appends the DRL of the document in the message
	 * @param strObjectID - r_object_id of the document on which the comment is posted
	 * @return String - static email message string
	 */
	private String prepareEmailMessage(String strObjectID){
		String drlString = DRLComponent.constructDRL(strObjectID, null, null, this);
		DfLogger.info(this, " : constructDrl :: drlString: " + drlString, null, null);
		String drl  = Component.makeFullUrl(getPageContext().getRequest(), drlString);
		DfLogger.info(this, " :: Document DRL : " + drl,null,null);
		StringBuffer msgBuffer = new StringBuffer();
		msgBuffer.append(IdocsUtil.getMessage(IdocsConstants.DOC_DISCUSSION_EMAIL_BODY_DIV))
		.append(IdocsUtil.getMessage(IdocsConstants.DOC_DISCUSSION_STATIC_MESSAGE_1))
		.append("</font>" )
		.append("<p><a href='").append(drl).append("'>").append(IdocsUtil.getMessage(IdocsConstants.DOC_DISCUSSION_STATIC_MESSAGE_2)).append("</a></p>")
		.append("</div>");
			
		return msgBuffer.toString();
	}
	
	private String prepareEmailMessageForDicussion(String strObjectID){
		String drlString = DRLComponent.constructDRL(strObjectID, null, null, this);
		DfLogger.info(this, " : constructDrl :: drlString: " + drlString, null, null);
		String drl  = Component.makeFullUrl(getPageContext().getRequest(), drlString);
		DfLogger.info(this, " :: Document DRL : " + drl,null,null);
		StringBuffer msgBuffer = new StringBuffer();
		
		String urlTokkens[]=drl.split("drl");
		for (int i = 0; i < urlTokkens.length; i++) {
			DfLogger.info(this, urlTokkens[i],null, null);
		}
		StringBuilder loBuilder= new StringBuilder();
		loBuilder.append(urlTokkens[0]);
		loBuilder.append("component/showtopic?objectId="+objectId+"&caller=WRK");
		DfLogger.info(this, "loBuilder"+loBuilder,null, null);
		
		msgBuffer.append(IdocsUtil.getMessage(IdocsConstants.DOC_DISCUSSION_EMAIL_BODY_DIV))
		.append(IdocsUtil.getMessage(IdocsConstants.DOC_DISCUSSION_STATIC_MESSAGE_2_1))
		.append("</font>" )
		.append("<p><a href='").append(loBuilder).append("'>").append(IdocsUtil.getMessage(IdocsConstants.DOC_DISCUSSION_STATIC_MESSAGE_2)).append("</a></p>")
		.append("</div>");
		
		DfLogger.info(this, " Mail Body ::",null, null);
		return msgBuffer.toString();
	}
	
	public String getProjectId(){
		String strProjectID = null;
		try {
			// Get the folder instance using the document ID.
			IDfDocument doc = (IDfDocument)(getDfSession().getObject(this.m_dfObjId));
			IDfId folderID = doc.getFolderId(0);
			String strFolderId =  folderID.toString();
			DfLogger.info(this, " :: getProjectId : strFolderId: "+strFolderId, null, null);
			IDfFolder parentFolder = null;
			
			 IDfFolder docFolder = (IDfFolder)getDfSession().getObject(new DfId(strFolderId));
	            if( docFolder.getTypeName().equals(IdocsConstants.INSTITUTION_FOLDER_TYPE)){
	    	        parentFolder = docFolder;
	            }else{
	    	        docFolder = (IDfFolder)getDfSession().getObject(docFolder.getFolderId(0));
	    	        if(docFolder.getTypeName().equals(IdocsConstants.INSTITUTION_FOLDER_TYPE)){
	    	        	parentFolder = docFolder;
	    	        }else{
	    	        	parentFolder=(IDfFolder)getDfSession().getObject(docFolder.getFolderId(0));
	    	        }
	            }
	          
	        DfLogger.info(this, " :: onCommitChanges() : Parent Folder ID : " +
	        		parentFolder.getObjectId().toString()+" Object Name : " + parentFolder.getObjectName(),null,null);
			
			String project_id_query = IdocsUtil.getMessage(IdocsConstants.INSTIT_FOLDER_PROJID_QUERY);
			project_id_query = project_id_query  + parentFolder.getObjectId().toString() + "'";

			DfLogger.info(this, " :: Query to get projectId for institution folder : " + project_id_query,null,null);
			IDfCollection collection = IdocsUtil.executeQuery(getDfSession(), project_id_query, IDfQuery.DF_READ_QUERY);
			if(collection.next()){
				strProjectID=collection.getString("project_id");
				DfLogger.info(this, " :: getProjectId :: "+strProjectID,null,null);
			}
			if(collection != null )collection.close();
		} catch (DfException e) {
			DfLogger.error(this, " :: getProjectId <<Exception>> : "+e.getMessage(),null,e);
		}
		return strProjectID;
	}
	
	/**
	 * This method executes the DQL query and returns the result in a collection object
	 * 
	 * @param queryString - Query String that is to be executed
	 * @return collectionObj - Collection object containing execution results
	 * @throws DfException
	 */
	private IDfCollection executeQuery(String queryString) throws DfException{
		IDfCollection collectionObj = null;
		DfLogger.info(this, " :: executeQuery :: queryString: " + queryString , null, null);
		IDfQuery query = new DfQuery();
		query.setDQL(queryString);		
		collectionObj = query.execute(getDfSession(), DfQuery.EXECREAD_QUERY);
		return collectionObj;
	}
	
	/**
	 * This method gets the projectID
	 * @param m_dfObjId - r_object_id of the document on which the comment is posted
	 * @return String - projectId associated with document
	 */
	private String getProjectId(String m_dfObjId) {
		String project_id="";
		String project_id_query = getMessage(IdocsConstants.DOC_PROJID_QUERY);
		project_id_query = project_id_query+m_dfObjId+"'";

		DfLogger.info(this, " :: Query to get projectId : "+project_id_query,null,null);
		IDfQuery query = new DfQuery();
		query.setDQL(project_id_query);
		try {
			IDfCollection collection = IdocsUtil.executeQuery(getDfSession(),project_id_query,IDfQuery.DF_READ_QUERY);
			if(collection.next()){
				project_id=collection.getString("project_id");
				DfLogger.info(this, " :: getProjectId :: "+project_id,null,null);
			}
			if(collection != null )collection.close();
		} catch (DfException e) {
			DfLogger.error(this, " :: getProjectId <<Exception>> : "+e.getMessage(),null,e);
		}
		return project_id;
	}

	/**
	 * This method calls the discussionusergrouplocator container and passes the arguments.
	 * @param locatorComponentName - component name
	 * @param args
	 * @return void
	 */
	protected void invokeRecipientLocator(String locatorComponentName, ArgumentList args)
	{
		DfLogger.info(this, " :: invokeRecipientLocator",null,null);
		setComponentNested(locatorComponentName, args, getContext(), new FormActionReturnListener(this, "onReturnFromRecipients"));
	}

	/**
	 * This method is called when user clicks on 'Ok' or 'Cancel' button in 'discussionusergrouplocatorcontainer' 
	 * If the user added any recipients to the to,cc or bcc listboxes in the usergrouplocator component, 
	 * this method will invoke the EmailSender which inturn sends the email notification.
	 * @param form - Form
	 * @param map Map
	 * @return void
	 */
	public void onReturnFromRecipients(Form form, Map<String, ListBox> map)
	{
		DfLogger.info(this, " :: this.m_dfObjId : " + m_dfObjId,null,null);

		map_emailAddress = getAddressMap(map);
		map_topicDetails.put(IdocsConstants.MAIL_CONTENT_TYPE, content_type);
		if(null!=map_emailAddress && !map_emailAddress.isEmpty())
		{
			EmailSender email = new EmailSender();
			String ifDocsEmailId=IdocsUtil.getMessage("MAIL_IFCDOCS_ID");
			if(ifDocsEmailId != null && ifDocsEmailId.trim().length() >0){
				email.sendMail(map_topicDetails , ifDocsEmailId ,map_emailAddress, getDfSession() );
			}else{
				email.sendMail(map_topicDetails , getLoginUserAddress() ,map_emailAddress, getDfSession() );	
			}
			
			
		}
	}

	private String getMessage(String key){
		String message = null; 
		Properties idocsProperties = new Properties();	    
		try {
			idocsProperties.load(TopicPageView.class.getResourceAsStream(IdocsConstants.IDOCS_PROPERTY_FILE));	        	       	
			message = idocsProperties.getProperty(key);	    		
		}catch(IOException e){
			DfLogger.error(this, " :: getMessage <<Exception>> : "+e.getMessage(),null,e);
		}
		return message;
	}

	private HashMap<String, String> getDocProperties(String docId){
		HashMap<String, String> hmap_docProps = new HashMap<String, String>();
		String strDocName = null;
		int c_FolderType = getFolderType(docId);
		IDfCollection collection = null ;
		String docProp_query=null;
		DfLogger.info(this, " :: c_FolderType...."+ c_FolderType,null,null);
		switch(c_FolderType){
			case IdocsConstants.PROJECT_TYPE :{
				docProp_query = getMessage(IdocsConstants.PROJDOC_DETAILS_QRY)+m_dfObjId+"'";
				break;
				}
			case IdocsConstants.INSTITUTION_TYPE :{
				docProp_query = getMessage(IdocsConstants.INSTITUTION_DOC_DETAILS_QRY)+m_dfObjId+"'";
				break;
				}
			case IdocsConstants.COUNTRY_TYPE :{
				docProp_query = getMessage(IdocsConstants.COUNTRYDOC_DETAILS_QRY)+m_dfObjId+"'";
				break;
			}
		}
		DfLogger.info(this, " :: Query to get docDetails : "+docProp_query,null,null);
		try {
			collection = IdocsUtil.executeQuery(getDfSession(), docProp_query, IDfQuery.DF_READ_QUERY);
			if(collection.next()){
				strDocName = collection.getString(IdocsConstants.OBJECT_NAME);
				hmap_docProps.put(DOC_NAME, strDocName);

				if(collection.hasAttr(IdocsConstants.PROJ_ID)){					
					hmap_docProps.put(PROJECT_ID, collection.getString(IdocsConstants.PROJ_ID));
				}
				if(collection.hasAttr(IdocsConstants.MSG_PROJECT_TIER_NME)){					
					hmap_docProps.put(IdocsConstants.MSG_PROJECT_TIER_NME, collection.getString(IdocsConstants.MSG_PROJECT_TIER_NME));
				}
				if(collection.hasAttr(IdocsConstants.INSTITUTION_ID)){					
					hmap_docProps.put(IdocsConstants.INSTITUTION_ID, collection.getString(IdocsConstants.INSTITUTION_ID));
				}

				if(collection.hasAttr(IdocsConstants.PROJ_SHORT_NAME)){					
					hmap_docProps.put(PROJECT_NAME, collection.getString(IdocsConstants.PROJ_SHORT_NAME));
				}

				if(collection.hasAttr(IdocsConstants.INSTITUTION_SHORT_NAME)){					
					hmap_docProps.put(IdocsConstants.INSTITUTION_SHORT_NAME, collection.getString(IdocsConstants.INSTITUTION_SHORT_NAME));
				}

				if(collection.hasAttr(IdocsConstants.COUNTRY_CODE)){					
					hmap_docProps.put(IdocsConstants.COUNTRY_CODE, collection.getString(IdocsConstants.COUNTRY_CODE));
				}

				if(collection.hasAttr(IdocsConstants.COUNTRY_NAME)){					
					hmap_docProps.put(IdocsConstants.COUNTRY_NAME, collection.getString(IdocsConstants.COUNTRY_NAME));
				}
				if(collection.hasAttr(IdocsConstants.MSG_WORKFLOW_STATUS)){					
					hmap_docProps.put(WRKFLOW_STATUS, collection.getString(IdocsConstants.MSG_WORKFLOW_STATUS));
					
				}
			}
			if(collection != null )collection.close();

		} catch (DfException e) {
			DfLogger.error(this, " :: getProjectId <<Exception>> : "+e.getMessage(),null,e);
		}
		return hmap_docProps;
	}

	/**
	 * This method sets the title to 'COC/VP Response' if the loggedin user is a memeber of COC or VP groups.
	 * This file im modifying for the third time to check the merge issue
	 * @return void
	 */
	public void setTitle(boolean isCOC){
		DfLogger.info(this, " :: setTitle:: ",null,null);
		
		if(isCOC){
			Text nameTextControl = (Text)getControl(TITLE_BOX, Text.class);
			DfLogger.info(this, " :: Title "+nameTextControl.getValue(),null,null);
			if(nameTextControl.getValue()==null){
				nameTextControl.setValue(COC_VP_RESPONSE);
			}
		}else{
			Text nameTextControl = (Text)getControl(TITLE_BOX, Text.class);
			DfLogger.info(this, " :: Title :  "+nameTextControl.getValue(),null,null);
			if(nameTextControl.getValue()==null){
				if ((this.m_editorType != null) && (this.m_editorType.equals("is_reply_open"))){
								nameTextControl.setValue("Re: ");
				}
			}
			
			}
	}
	
	/**
	 * 
	 * @return
	 */
	private String getLoginUserAddress(){
		String login_userEmail = null;
		try{			
			IDfSession dfSession = getDfSession();
			String strUserName = dfSession.getLoginUserName();	
			IDfUser dfUser = dfSession.getUser(dfSession.getLoginUserName());
			String str_UserObjectId = dfUser.getObjectId().toString();
			DfLogger.info(this, " :: str_UserObjectId : " + str_UserObjectId ,null,null);
			if(null != str_UserObjectId && str_UserObjectId.trim().length() > 0){
				ArrayList<String> alst_user = new ArrayList<String>();
				alst_user.add(str_UserObjectId);
				ArrayList<String> alst_userAddress = getUserAddress(alst_user);
				if(null != alst_userAddress && alst_userAddress.size()>0){
					login_userEmail =  alst_userAddress.get(0);
				}
				login_userEmail = strUserName+"<"+login_userEmail+">";
			}
			DfLogger.info(this, " :: login user Email ID : " + login_userEmail,null,null);
		}catch(DfException dfe){
			DfLogger.error(this, " :: getLoginUserAddress <<Exception>> : "+dfe.getMessage(),null,dfe);
		}
		return login_userEmail;
	}

	/**
	 * Purpose :To Know login user is COCVP or not 
	 * @return
	 */
	protected boolean isCOCVPMember(){
		boolean isMemberFlag = false;
		try{
			IDfSession dfSession = getDfSession();
			String dqlQuery = IdocsUtil.getMessage(IdocsConstants.QRY_LDAP_GROUP_MEMBER);
			dqlQuery = dqlQuery.replace(QRY_VARIABLE_LOGINUSERNAME, "'"+ IdocsUtil.handleSingleQuote(dfSession.getLoginUserName())+"'");
			dqlQuery = dqlQuery.replace(QRY_VARIABLE_ROLESTRING,"'COC Assistants','COC Members'");
			IDfQuery query = new DfQuery();
			query.setDQL(dqlQuery);
			IDfCollection collection = query.execute(dfSession, IDfQuery.DF_READ_QUERY);
			while(collection.next() && isMemberFlag == false){
				isMemberFlag = true;
			}
				
		}catch(DfException dfe){
			DfLogger.error(this, " :: isCOCVPMember <<Exception>> : "+dfe.getMessage(),null,dfe);
		}
		return isMemberFlag;
	}

	/**
	 * To Get the email -id's(TO,CC) from locator values 
	 * @param map
	 * @return
	 */
	
	private HashMap<String, ArrayList<String>> getAddressMap(Map<String,ListBox> map){
		int index = 0;
		DfLogger.info(this, " :: onReturnFromRecipients : ",null,null);
		HashMap<String, ArrayList<String>> map_recipients = new HashMap<String, ArrayList<String>>();
		ArrayList<String> lst_address=null;
		if (map != null){
			//getting value of listbox from map
			ListBox listbox=(ListBox) map.get(TO_LIST);
			if(listbox!=null){
				List<String> lst_TouserIds = new ArrayList<String>();
				DfLogger.info(this, "Map Listbox Test : "+listbox+" Size : "+listbox.getOptions().size(),null,null);
				index = 0;
				while(index < listbox.getOptions().size()){ //iterating through list of options
					DfLogger.info(this, "Option ["+index+"] for To : "+((Option)listbox.getOptions().get(index)).getValue(),null,null);
					String str_ToObjectId = ((Option)listbox.getOptions().get(index)).getValue();
					if(null!= str_ToObjectId && !"".equals(str_ToObjectId)){
						lst_TouserIds.add(str_ToObjectId);
					}
					index++;
				}
				
				if(null!= lst_TouserIds && lst_TouserIds.size()>0){
					lst_address = getUserAddress(lst_TouserIds);
					DfLogger.info(this, "lst_address_to ..size "+ lst_address.size(),null,null);
					map_recipients.put(IdocsConstants.MAIL_TO, lst_address);
				}
			}

			listbox=(ListBox) map.get(CC_LIST);
			if(listbox!=null){
				List<String> lst_CcuserIds = new ArrayList<String>();
				DfLogger.info(this, "Map Listbox Test : "+listbox+" Size : "+listbox.getOptions().size(),null,null);
				index = 0;
				while(index < listbox.getOptions().size()){ //iterating through list of options
					DfLogger.info(this, "Option ["+index+"] for Cc : "+((Option)listbox.getOptions().get(index)).getValue(),null,null);
					String str_CcObjectId = ((Option)listbox.getOptions().get(index)).getValue();
					if(null!= str_CcObjectId && !"".equals(str_CcObjectId)){
						lst_CcuserIds.add(str_CcObjectId);
					}
					index++;
				}
				
				if(null!= lst_CcuserIds && lst_CcuserIds.size()>0){
					lst_address = getUserAddress(lst_CcuserIds);
					map_recipients.put(IdocsConstants.MAIL_CC, lst_address);
				}
			}
			listbox=(ListBox) map.get(BCC_LIST);
			if(listbox!=null){
				List<String> lst_BccuserIds = new ArrayList<String>();
				DfLogger.info(this, "Map Listbox Test : "+listbox+" Size : "+listbox.getOptions().size(),null,null);
				index = 0;
				while(index <listbox.getOptions().size()){ //iterating through list of options
					DfLogger.info(this, "Option ["+index+"] for Bcc : "+((Option)listbox.getOptions().get(index)).getValue(),null,null);
					String str_BccObjectId = ((Option)listbox.getOptions().get(index)).getValue();
					if(null!= str_BccObjectId && !"".equals(str_BccObjectId)){
						lst_BccuserIds.add(str_BccObjectId);
					}
					index++;
				}
				
				if(null!= lst_BccuserIds && lst_BccuserIds.size()>0){
					lst_address = getUserAddress(lst_BccuserIds);
					map_recipients.put(IdocsConstants.MAIL_BCC, lst_address);
				}
			}
		}
		return map_recipients;
	}

	public ArrayList<String> getUserAddress(List<String> lst_userObjectID){
		ArrayList<String> aList_userAddress = null;
		String str_dql= IdocsUtil.getMessage(IdocsConstants.USER_ADDRESS_QUERY);//"select user_address from dm_user where r_object_id in(";
		//Execute dql to fetch corresponding roles of the next manual activity of this workflow...
		//StringBuffer dqlStr = new StringBuffer();
		StringBuilder dqlStr = new StringBuilder(str_dql);	
		if(null!=lst_userObjectID && lst_userObjectID.size()>0){
			for(int lstIndex = 0; lstIndex < lst_userObjectID.size();lstIndex++){ //iterating through list of userIds
				String strObjectId = (String)lst_userObjectID.get(lstIndex);
				DfLogger.info(this, " :: getUserAddress : strObjectId: " + strObjectId,null,null);
				if (strObjectId.startsWith(IDocsConstants.MSG_USER_OBJ_TYPE)) {
					int capacity = strObjectId.length();
					capacity = capacity + 5;
					dqlStr.ensureCapacity(capacity);

					if(lstIndex == 0)
						dqlStr.append("'");
					else
						dqlStr.append(",'");

					dqlStr.append(lst_userObjectID.get(lstIndex)).append("'");	
				} else {
					String usersInGrpQry = IdocsUtil.getMessage("USERS_IN_GROUP");
					usersInGrpQry = usersInGrpQry.replace(QRY_VARIABLE_OBJECTID, strObjectId);
					try{
						IDfCollection collection = IdocsUtil.executeQuery(getDfSession(),usersInGrpQry,IDfQuery.DF_READ_QUERY);
						int count = 0;
						int userCount = 0;
						while(collection.next()){
							String userObjectID = collection.getString(IDocsConstants.MSG_R_OBJECT_ID);
							DfLogger.info(this, " :: getUserAddress : Looping Collection of user object ids .." + userObjectID,null,null);
							int capacity = strObjectId.length();
							capacity = capacity + 5;
							dqlStr.ensureCapacity(capacity);

							if(count == 0)
								dqlStr.append("'");
							else
								dqlStr.append(",'");
							count++;
							userCount++;
							dqlStr.append(userObjectID).append("'");	
						}
						if (collection!=null) collection.close();
						DfLogger.info(this, " :: getUserAddress:  userCount : " + userCount,null,null);
						if (userCount == 0) {
							dqlStr.append("''");
						}
					}catch(DfException dfe){
						DfLogger.error(this, " :: getUserAddress : Error in getting user_address : " +dfe.getMessage(),null,null);
					}
				}
				
			}
		}
		dqlStr.append(STR_CLOSING_BRACK);

		DfLogger.info(this, " :: getUserAddress: Get user email address :: dqlStr : "+dqlStr.toString(),null,null);
		// getting user_address
		try{
			IDfCollection collection = IdocsUtil.executeQuery(getDfSession(),dqlStr.toString(),IDfQuery.DF_READ_QUERY);
			aList_userAddress = new ArrayList<String> ();
			while(collection.next()){
				DfLogger.info(this, "Looping Collection of user_address .." + collection.getString(USER_EMAIL),null,null);
				aList_userAddress.add((String)collection.getString(USER_EMAIL));
			}
			if (collection!=null) collection.close();
		}catch(DfException dfe){
			DfLogger.error(this, "Error in getting user_address : " +dfe.getMessage(),null,null);
		}
		return aList_userAddress;
	}

	/**
	 * 
	 * @param strObjID
	 * @return
	 */
	public int getFolderType(String strObjID){
		try {
			IDfSession dfSession  = getDfSession();
			String rObjectTypeQuery=IdocsUtil.getMessage("QRY_DISCUSSION_OBJECT_TYPE");
			rObjectTypeQuery=rObjectTypeQuery.replace(STR_OBJECT_ID_REPLACE_STRING, IdocsConstants.MSG_QUOTES+strObjID+IdocsConstants.MSG_QUOTES);
			String objectType="";
			IDfCollection collection =null; 
			collection=IdocsUtil.executeQuery(dfSession,rObjectTypeQuery, IDfQuery.DF_EXECREAD_QUERY);
			while(collection.next()){
				objectType=collection.getString(IDocsConstants.MSG_R_OBJECT_TYPE);
			}
			DfLogger.info(this, "getFolderType ::"+objectType,null, null);
			if (objectType.equals(IDocsConstants.MSG_IDOCS_PROJECT_DOC)){
				c_type = IdocsConstants.PROJECT_TYPE;
			}
			else if (objectType.equals(IDocsConstants.MSG_IDOCS_INSTITUTION_DOC)) {
				c_type = IdocsConstants.INSTITUTION_TYPE;
				
			} else if (objectType.equals(IDocsConstants.MSG_IDOCS_COUNTRY_DOC)) {
				c_type = IdocsConstants.COUNTRY_TYPE;
			}
		}
		catch (DfException e) {
			DfLogger.error(this, " :: getFolderType <<Exception>> : "+e.getMessage(),null,e);
		}
		return c_type;
	}
	
	public static final String STR_PROJECT_TYPE = "PROJECT";
	public static final String STR_PARTNER_TYPE = "PARTNER";
	public static final String STR_COUNTRY_TYPE = "COUNTRY";
	private static final String STR_OBJECT_ID_REPLACE_STRING="'<objectId>'"; 
	private static final String QRY_VARIABLE_LOGINUSERNAME = "<loginusername>";
	private static final String QRY_VARIABLE_ROLESTRING = "<rolestring>";
}
