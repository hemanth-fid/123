/**
* This class to check the permitions for the component to validate.
* #######################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################
*/
package org.ifc.idocs.library.actions;

import java.util.HashMap;
import java.util.Map;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.ErrorMessageService;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

public class LaunchExportComponentWithPermitCheck extends
		com.documentum.web.formext.action.LaunchComponentWithPermitCheck {

	private static final long serialVersionUID = 1L;
    private static final NlsResourceBundle s_lookup = new NlsResourceBundle("org.ifc.idocs.action.ValidateGroupMembershipNlsProp");
	String accessRole = null;

    public String[] getRequiredParams(){
    	DfLogger.info(this, " :: LaunchExportComponentWithPermitCheck : getRequiredParams ",null,null);
        return (new String[] {
            "objectId"
        });
    }
    
    /**
     * 
     */
	public boolean execute(String strAction, IConfigElement config, 
			ArgumentList args, Context context, Component component, Map completionArgs){
		if(IdocsUtil.MSG_TASK_ATTACHMENT_COMPONENT_ID.equalsIgnoreCase(component.getComponentId())){
			DfLogger.info(this, " :: LaunchExportComponentWithPermitCheck : ALLOWED : This is from Workflow Task :",null,null);
			return super.execute(strAction, config, args, context, component, completionArgs);
		}else{
			DfLogger.info(this, " :: LaunchExportComponentWithPermitCheck : This is Not from Workflow Task : Continue With further tests",null,null);
		}
		
		String strObjectId = args.get("objectId");
		DfLogger.info(this, " :: LaunchExportComponentWithPermitCheck : execute : Object ID "+strObjectId,null,null);
		boolean validated = false;
		try{
			if(strObjectId != null && strObjectId.trim().length()>0 && strObjectId.startsWith(IDocsConstants.MSG_DM_DOC_TYPE_PREF_CODE)){
				
				HashMap<String, String> docValuesMap = new HashMap<String, String>();
				docValuesMap=IdocsUtil.getRequiredAttributesValues(strObjectId, component.getDfSession());
				
				String strObjectName = docValuesMap.get(IDocsConstants.MSG_OBJECT_NAME);
				DfLogger.info(this, " :: execute : Object Name ="+strObjectName,null,null);
				validated = LaunchViewComponentWithPermitCheck.validateUserPermissionsForView(false,strObjectId,component.getDfSession(),docValuesMap);
				DfLogger.info(this, " :: execute : validated ="+validated,null,null);
				if(validated == true ){
					return super.execute(strAction, config, args, context, component, completionArgs);
				}else{
					if(accessRole != null && accessRole.trim().length() > 0){
						accessRole = "Core Team,Approvers OR Other Editors";
					}else{
						accessRole= "Core Team,Approvers OR Other Editors";// " Authorized";
					}
			        ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_ACTION_PERMISSION_DENIED", component, new String[]{"Export",strObjectName,accessRole}, null);
					return false;
				}			
			}else{
				return super.execute(strAction, config, args, context, component, completionArgs);
			}
		}catch (Exception e) {
			DfLogger.error(this, " :: execute : Exception :"+e.getMessage(),null,null);
		}
		return false;
    }
}