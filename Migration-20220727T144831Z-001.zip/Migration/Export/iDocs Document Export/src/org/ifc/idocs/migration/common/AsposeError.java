package org.ifc.idocs.migration.common;

public class AsposeError {

	private String utilityCode;
	private String documentId;
	private String version;
	private String title;
	private String folderTypeCode;
	private String folderValueCode;
	private String countryCode;
	private String absoluteFilePath;
	private String exceptionMessage;
	
	public String getUtilityCode() {
		return utilityCode;
	}
	public void setUtilityCode(String utilityCode) {
		this.utilityCode = utilityCode;
	}
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFolderTypeCode() {
		return folderTypeCode;
	}
	public void setFolderTypeCode(String folderTypeCode) {
		this.folderTypeCode = folderTypeCode;
	}
	public String getFolderValueCode() {
		return folderValueCode;
	}
	public void setFolderValueCode(String folderValueCode) {
		this.folderValueCode = folderValueCode;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getAbsoluteFilePath() {
		return absoluteFilePath;
	}
	public void setAbsoluteFilePath(String absoluteFilePath) {
		this.absoluteFilePath = absoluteFilePath;
	}
	public String getExceptionMessage() {
		return exceptionMessage;
	}
	public void setExceptionMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}
}
