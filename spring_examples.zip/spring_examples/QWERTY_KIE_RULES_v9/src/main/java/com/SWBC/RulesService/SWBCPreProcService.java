package com.SWBC.RulesService;

import org.kie.api.event.rule.DefaultAgendaEventListener;
import org.kie.api.runtime.KieContainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
@Component
@PropertySource(value = { "classpath:application.properties" })
public class SWBCPreProcService extends DefaultAgendaEventListener {
	
	
	private KieContainer kieContainer;
	
	@Autowired
	public SWBCPreProcService(KieContainer kieContainer) {
		this.kieContainer = kieContainer;
	}

}
