package org.ifc.idocs.queryservices;


import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.formext.component.Component;

public class IDocsQueriesComponent extends Component{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	StringBuilder stringMeessageBuilder= new StringBuilder();
	public boolean exceptionblock=false;
	public void onInit(ArgumentList arg) {
		super.onInit(arg);
		
		try {
			String timeInterval =arg.get("timeInterval");
			String refreshRequired =arg.get("refreshRequired");
			if(timeInterval != null && timeInterval.length() >0){
				DfLogger.info(this,"Time Value"+timeInterval,null, null);
				long timeIntervale=Long.parseLong(timeInterval);
				IDocsQRYVO.customTimeInterval=timeIntervale;
				stringMeessageBuilder.append("Custom time Interval Value updated to :: "+timeIntervale);
			}else{
				DfLogger.info(this,"<< No Date Time Value >>",null, null);
			}
			DfLogger.info(this, "onInit ::query Services are intiating", null, null);
			if(refreshRequired.equalsIgnoreCase(IdocsConstants.MSG_YES)){
				IDocsQRYVO.IntiateQRYServices(getDfSession());
				DfLogger.info(this , "onInit :: Template Map is Updated ... No of Values added to Template  MAP are "+IDocsQRYVO.noOfTemplateRecords, null, null);
				DfLogger.info(this , "onInit :: SubFolder Map is Updated ...No of Values added to SubFolder MAP are "+IDocsQRYVO.noOfsubfolderRecords, null, null);
			}else{
				DfLogger.info(this , "onInit :: Don't Update the Queries", null, null);
			}	
		} catch (NumberFormatException e) {
			exceptionblock=true;
			e.printStackTrace();
			stringMeessageBuilder.append("<<Exception>> "+e.getMessage());
		}
	}
	
	public String setTemplateQuery(){
		return IdocsUtil.getMessage("TEMPLATE_NAME_QUERY");
	}
	
	public String setFolderCategory(){
		return IdocsUtil.getMessage("DOCTYPE_INFO_QRY");
	}
	
	public void navigateToMain(Control control, ArgumentList args){
		setComponentJump("main", args,getContext());
	}
	public String getTemplateMapValue(){
		return IDocsQRYVO.noOfTemplateRecords+IDocsConstants.MSG_EMPTY_STRING;	
	}
	
	public String getSubfolderMapValue(){
		return IDocsQRYVO.noOfsubfolderRecords+IDocsConstants.MSG_EMPTY_STRING;	
	}
	
	
	public String getSuccessMessage(){
	return stringMeessageBuilder.toString();	
	}
}