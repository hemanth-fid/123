package org.ifc.idocs.environment.actions;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.clipboard.IClipboardPasteHandler;
import com.documentum.web.formext.component.Component;
import com.documentum.webcomponent.navigation.ClipboardPasteHandler;

final class HereActionHelper
{

    HereActionHelper()
    {
    }

    static String[] getRequiredParams()
    {
        return (new String[] {
            "objectId"
        });
    }

    static IClipboardPasteHandler getClipboardPasteHandler(ArgumentList args, Component component)
    {
        String folderId = args.get("objectId");
        DfLogger.info(HereActionHelper.class, " :: getClipboardPasteHandler : folderId: "+folderId,null,null);
        return new ClipboardPasteHandler(component, folderId);
    }
}
