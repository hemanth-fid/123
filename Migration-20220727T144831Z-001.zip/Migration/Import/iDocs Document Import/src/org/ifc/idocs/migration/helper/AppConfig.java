package org.ifc.idocs.migration.helper;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;
/**
 * AppConfig - Configuration file config.xml initialization. 
 * @author HAnuganti
 * 
 * #############################################################################################
 * Author		            DateofChange	 Version	  ModificationHistory
 * ###########################################################################################
 * Hemachandra Anuganti 
 * ###########################################################################################
 * 
 */
public class AppConfig extends XMLConfiguration {

	private static final long serialVersionUID = 239973206750886170L;
	private static AppConfig instance;
    private static String configFile = "config.xml";

    // Singleton initializer
    static {
    	instance = new AppConfig(configFile);
    }

    /**
     * Constructor
     *
     * @param fileName Configuration file name.
     */
    private AppConfig(String fileName) {
        init(fileName);
    }

    /**
     * Initialize the class.
     *
     * @param fileName Configuration file name.
     */
    private void init(String fileName) {
        setFileName(fileName);
        try {
            load();
        } catch (ConfigurationException configEx) {
            configEx.printStackTrace();
        }
    }

    /**
     * Singleton access method.
     *
     * @return Singleton
     */
    public static AppConfig getInstance() {
        return instance;
    }
}

