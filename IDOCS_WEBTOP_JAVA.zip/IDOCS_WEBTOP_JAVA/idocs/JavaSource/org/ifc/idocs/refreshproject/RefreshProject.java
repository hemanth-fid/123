package org.ifc.idocs.refreshproject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfGroup;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.form.control.databound.ScrollableResultSet;
import com.documentum.web.form.control.databound.TableResultSet;
import com.documentum.web.formext.component.Component;

public class RefreshProject extends Component {
	private static final String LOCKED = "Locked";
	private static final String CANNOT_BE_REFRESHED_AS_DOCUMENT_IS_LOCKED = "This work item cannot be refreshed as the document is locked";
	private static final String DORMANT = "DORMANT";
	private static final String THIS_WORK_ITEM_CANNOT_BE_REFRESHED = "This work item cannot be refreshed";
	private static final String STRHASH = "::";
	private static final String THERE_IS_NO_WORKITEM_WHICH_IS_IN_DORMANT_STATE = "There is no activity which is in Dormant State";
	
	private static final String NO_CHANGE_IN_WORKFLOW_PERFORMERS = "No change in workflow performers";
	private static final String WORKFLOW_TASK_PERFORMER_S_UPDATED_SUCCESSFULLY = "Workflow task performer(s) updated successfully";
	private static final String ACQUIRED = "ACQUIRED";
	private static final String NOCHANGE = "NOCHANGE";
	private static final String EXCLUDED = "EXCLUDED";
	private static final String REFRESHSTATUS = "refreshstatus";
	private static final String ACTIVITYNAME2 = "activityname";
	private static final String ACTIVITYNO = "activityno";
	private static final String WORKITEM_ID = "workitem_id";
	private static final String PERFORMER = "performer";
	private static final String DM_BPS_INBOUND_USER = "dm_bps_inbound_user";
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String OBJECT_ID = "objectId";
	private static final String REFRESH="refresh";
	private static final String EMPTY="";
	public int count=0;
	private boolean showDataGrid=false;
	
	public boolean getShowDataGridFlag() {
		return showDataGrid;
	}
	
	public void onInit(ArgumentList args) {
		try{
			showDataGrid = false;
			super.onInit(args);
			String strDocumentObjectId = null;
			strDocumentObjectId=args.get(OBJECT_ID);
			updateWorkflowPerformers(strDocumentObjectId);
			Label refreshFinalStatusLabel=(Label)getControl(REFRESH,Label.class);
			if(currentWorkflowNameMap!=null && currentWorkflowNameMap.size()>0){
				if(currentWorkItemMap!=null && currentWorkItemMap.size()>0
					&& currentActivityNameMap != null && currentActivityNameMap.size()>0){
					ScrollableResultSet rs = populateResultSet();
					Datagrid dg = (Datagrid) getControl("refreshPerformerDataGrid", Datagrid.class);
					if(dg != null){
						dg.getDataProvider().setDfSession(getDfSession());
						dg.getDataProvider().setScrollableResultSet(rs);
						showDataGrid = true;
					}else{
						DfLogger.info(this,"Workflow Performers cannot be refreshed as there is no activity which is in Dormant state",null,null);
						refreshFinalStatusLabel.setLabel("Workflow Performers cannot be refreshed as there is no activity which is in Dormant state");
					}							
				}else{
					DfLogger.info(this,"Workflow Performers cannot be refreshed as there is no activity which is in Dormant state",null,null);
					refreshFinalStatusLabel.setLabel("Workflow Performers cannot be refreshed as there is no activity which is in Dormant state");
				}
			}else{
				DfLogger.info(this,"Workflow Performers cannot be refreshed as this document is not part of any workflow",null,null);
				refreshFinalStatusLabel.setLabel("Workflow Performers cannot be refreshed as this document is not part of any workflow");
			}				
		}catch(Exception e){
			DfLogger.info(this,"Workflow Performers cannot be refreshed :"+e.getMessage(),null,null);
		}
	}

	private TableResultSet populateResultSet() {
		int counter=1;
		String[] columnHeaders = new String[] { ACTIVITYNO,ACTIVITYNAME2,REFRESHSTATUS };
		TableResultSet ts = new TableResultSet(columnHeaders);
		Iterator<Entry<String, String>> iterator = finalMessageMap.entrySet().iterator();
		while(iterator.hasNext()) {
			StringBuffer labelmessage = new StringBuffer();
			Map.Entry<String, String> entry = iterator.next();
			String workItemId = (String) entry.getKey();
			workItemId = workItemId.substring(0, workItemId.indexOf(STRHASH));
			String activityName = currentActivityNameMap.get(workItemId);
			String[] tableRow = new String[3];
			tableRow[0] =EMPTY+counter;
			
		if(entry.getValue().equals(EXCLUDED)==true){
			tableRow[1] =activityName;
			tableRow[2] =THIS_WORK_ITEM_CANNOT_BE_REFRESHED;
		}
		if(entry.getValue().equals(NOCHANGE)==false 
				&& entry.getValue().equals(EXCLUDED)==false
				&& entry.getValue().equals(ACQUIRED)==false){
				if(entry.getValue().length()==2){
					tableRow[1] =activityName;
					tableRow[2] =WORKFLOW_TASK_PERFORMER_S_UPDATED_SUCCESSFULLY;
									
				}
				else if(entry.getValue().equals(LOCKED)==true){
					tableRow[1] =activityName;
					tableRow[2] =CANNOT_BE_REFRESHED_AS_DOCUMENT_IS_LOCKED;
				}
				else{
					tableRow[1] =activityName;
					labelmessage.append("Added ").append((String)entry.getValue());
					tableRow[2] =labelmessage.toString();
				}
					
			}
		if(entry.getValue().equals(NOCHANGE)==true){
			tableRow[1] =activityName;
			tableRow[2] =NO_CHANGE_IN_WORKFLOW_PERFORMERS;
		}
		if(entry.getValue().equals(ACQUIRED)==true){
			tableRow[1] =activityName;
			tableRow[2] =THERE_IS_NO_WORKITEM_WHICH_IS_IN_DORMANT_STATE;
		}
		
		counter++;
		ts.add(tableRow);
			
		}
		return ts;
	}
	
	private void updateWorkflowPerformers(String strDocumentObjectId)  {
		try {
			fetchCurrentWorkflowDetails(getDfSession(), strDocumentObjectId);
			
			if(currentWorkflowNameMap!=null && currentWorkflowNameMap.size()>0){
				if(currentWorkItemMap !=null && currentWorkItemMap.size() >0 ){
					/** Found few Running Unclaimed Workflow Tasks for this document . Start Processing... */
					Iterator<Entry<String, String>> iterator = currentWorkItemMap.entrySet().iterator();
			    	while (iterator.hasNext()) {
			    		Map.Entry<String,String> entry = iterator.next();
				        String workItemId = (String)entry.getKey();
				        String workflowId = (String)entry.getValue();
				        if(currentRuntimeStateMap != null 
				        		 && currentRuntimeStateMap.size()>0 
				        		 && currentRuntimeStateMap.get(workItemId).equals("0")==true){
				        	DfLogger.debug(this,"-------------------Start----"+currentWorkflowNameMap.get(workflowId)+"'s "+currentActivityNameMap.get(workItemId)+"-----------------------",null,null);
					        try{
					        	/** Is this an excluded Item **/
						        boolean isExluded = isExcluded(getDfSession(), currentActivityNameMap.get(workItemId), currentWorkflowNameMap.get(workflowId));
						        if(isExluded ==  true){
						        	finalMessageMap.put(workItemId+STRHASH+currentWorkflowNameMap.get(workflowId),EXCLUDED);
						        	DfLogger.info(this,"This work Item is an excluded one. Cannot be refreshed", null, null);
						        }else{
						        	DfLogger.debug(this,"Start Refreshing the Performers",null,null);
						        	ArrayList<String> currentPerformerNames = RefreshPerformerUtility.getGroupMembersAsList(getDfSession(),currentperformerGroupMap.get(workItemId));
						        	DfLogger.debug(this,"Current Performers :" + currentPerformerNames,null,null);
						        	if(refreshRequiredAsItsLDAP == true){
						        		finalMessageMap.put(workItemId+STRHASH+currentWorkflowNameMap.get(workflowId), currentActivityNameMap.get(workItemId) + " This is LDAP Performer Activity ");
						        		DfLogger.info(this,"This is LDAP Performer Activity", null, null);
						        	}else{
						        		finalMessageMap.put(workItemId+STRHASH+currentWorkflowNameMap.get(workflowId), currentActivityNameMap.get(workItemId) + " This is a Normal Activity ");
						        	}
						        	String strProjectID = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(getDfSession(), strDocumentObjectId, RefreshPerformerUtility.PROJECT_ID,RefreshPerformerUtility.IDOCS_PROJECT_DOC);
						        	ArrayList<String> futurePerformerList = new ArrayList<String>();
						        	String processName = currentWorkflowNameMap.get(workflowId);
						        	if(processName.startsWith(RefreshPerformerUtility.SUB_WORKFLOW)){
						        		/** Handle Sub Workflows */
						        		finalMessageMap.put(workItemId+STRHASH+currentWorkflowNameMap.get(workflowId), currentActivityNameMap.get(workItemId) + " - This is a Sub Workflow. Getting the performers from AS Portal");
						        		DfLogger.info(this,"This is a Sub Workflow. Getting the performers from AS Portal", null, null);
						        		futurePerformerList = RefreshPerformerUtility.getSubWfPerformersFromIdesk(currentperformerGroupMap.get(workItemId), strProjectID,getDfSession());
						        	}else{
						        		/** Handle Normal Workflows Both IO and AS */
										finalMessageMap.put(workItemId+STRHASH+currentWorkflowNameMap.get(workflowId), currentActivityNameMap.get(workItemId) + " - This is not a Sub Workflow. Getting the performers from IDESK");
										DfLogger.info(this,"This is not a Sub Workflow. Getting the performers from IDESK", null, null);
										futurePerformerList = RefreshPerformerUtility.getPerformersFromIdesk(getDfSession(), processName, currentActivityNameMap.get(workItemId), strProjectID, workflowId);										
									}
						        	
						        	/** Find out if there is any change in the performers by comparing the list */ 
						        	if(futurePerformerList.equals(currentPerformerNames)){
						        		finalMessageMap.put(workItemId+STRHASH+currentWorkflowNameMap.get(workflowId),NOCHANGE);
						        		DfLogger.debug(this,"No change in workflow performers",null,null);
						        	}else{
						        		ArrayList<String> correctPerformerArray = cloneTheArrayList(futurePerformerList);
					        			ArrayList<String> wrongPerformerArray = cloneTheArrayList(currentPerformerNames);
					        			wrongPerformerArray.removeAll(futurePerformerList);
					        			futurePerformerList.removeAll(currentPerformerNames);
					        			if(futurePerformerList !=null && futurePerformerList.size()>0){
					        				DfLogger.debug(this,"These Performers Are Missing :" + futurePerformerList,null,null);
						        			//finalMessageMap.put(workItemId+STRHASH+currentWorkflowNameMap.get(workflowId),futurePerformerList.toString());		
						        			correctPerformerGroupMap.put(workItemId, correctPerformerArray);
						        			updateWfPerformerGrpReqd=true;
					        			}else if(wrongPerformerArray != null && wrongPerformerArray.size()>0){
					        				//finalMessageMap.put(workItemId+STRHASH+currentWorkflowNameMap.get(workflowId),futurePerformerList.toString());	
						        			correctPerformerGroupMap.put(workItemId, correctPerformerArray);
						        			updateWfPerformerGrpReqd=true;
					        			}else{
					        				finalMessageMap.put(workItemId+STRHASH+currentWorkflowNameMap.get(workflowId),NOCHANGE);
					        				DfLogger.debug(this,"No change in workflow performers",null,null);
					        			}
					        			if(updateWfPerformerGrpReqd){
						        			if(updateWorkflowPerformerGroup(getDfSession(),futurePerformerList,wrongPerformerArray,workflowId,workItemId,strDocumentObjectId)){
						        				finalMessageMap.put(workItemId+STRHASH+currentWorkflowNameMap.get(workflowId),futurePerformerList.toString());		
						        				DfLogger.debug(this,"Updated workflow performers",null,null);
						        			}
						        			else{
						        				finalMessageMap.put(workItemId+STRHASH+currentWorkflowNameMap.get(workflowId),LOCKED);
						        				DfLogger.debug(this,"Document locked",null,null);
						        			}
					        			}
						        	}					        	
						        }
					        }catch (Exception e) {
					        	 finalMessageMap.put(workItemId+STRHASH+currentWorkflowNameMap.get(workflowId), currentActivityNameMap.get(workItemId) + " - Exception Occurred : "+e.getMessage());
					        }
				        }else{
				        	finalMessageMap.put(workItemId+STRHASH+currentWorkflowNameMap.get(workflowId),ACQUIRED);
				        	DfLogger.info(this,"There is no activity which is in Dormant State.", null, null);
				        }
			    	}	
				}else{
					finalMessageMap.put(strDocumentObjectId,DORMANT);	
					DfLogger.info(this,"There is no activity which is in Dormant State.", null, null);
				}
			}else{
				DfLogger.info(this,"Document is not part of any workflow", null, null);
				finalMessageMap.put(strDocumentObjectId,"This document is not part of any workflow");				
			}	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private ArrayList<String> cloneTheArrayList(
			ArrayList<String> futurePerformerList) {
		return (ArrayList<String>) ((ArrayList<String>) futurePerformerList).clone();
	}
	
	
	private boolean updateWorkflowPerformerGroup(IDfSession dfSession,
			ArrayList<String> futurePerformerList, ArrayList<String> wrongPerformerArray, String workflowId, String workItemId,String strDocumentObjectId) throws IOException {
		boolean canRefresh=true;
		try {
			if((futurePerformerList != null && futurePerformerList.size() > 0)
					|| (wrongPerformerArray != null && wrongPerformerArray.size() > 0)){
				DfLogger.debug(this,"Updating Project Team Members...\n",null,null);
				ArrayList<String> removedPerformerList = new ArrayList<String>();
				IDfSessionManager sessMgr =IdocsUtil.getAdminSessionManager(dfSession); 
				IDfSession adminSession =sessMgr.newSession(dfSession.getDocbaseName());
				IDfGroup performeGrp = (IDfGroup)adminSession.getObjectByQualification("dm_group where group_name='"+currentperformerGroupMap.get(workItemId)+RefreshPerformerUtility.QRY_VARIABLE_SQ);
				
				/** First Remove All those Users */				
				for (int i=0;i<wrongPerformerArray.size();i++){			
					if(performeGrp.isUserInGroup(wrongPerformerArray.get(i).toString())){
						performeGrp.removeUser(wrongPerformerArray.get(i).toString());
						removedPerformerList.add(wrongPerformerArray.get(i).toString());
						DfLogger.debug(this,"Removed \t:"+wrongPerformerArray.get(i).toString(),null,null);
					}else{
						DfLogger.debug(this,"\n"+wrongPerformerArray.get(i).toString() + " is not present in the group.",null,null);
					}
				}
				DfLogger.debug(this,"--------------Completed Removing Users-------------\n",null,null);
				/** Now Add Those Missing Users */
				for (int i=0;i<futurePerformerList.size();i++){			
					if(performeGrp.isUserInGroup(futurePerformerList.get(i).toString()) == false){
						performeGrp.addUser(futurePerformerList.get(i).toString());
						DfLogger.debug(this,"Added \t:"+futurePerformerList.get(i).toString(),null,null);
					}else{
						DfLogger.debug(this,"\n "+futurePerformerList.get(i).toString() + " is already present in the group.",null,null);
					}
				}
				DfLogger.debug(this,"----------------Completed Adding Users-------------\n",null,null);
				performeGrp.save();
				
			// Updating the permission on the document if the newly added user does not have permission
				if(performeGrp!=null){
					 canRefresh=RefreshPerformerUtility.updateDocSecurity(strDocumentObjectId,performeGrp,adminSession);
					if(canRefresh){
						DfLogger.debug(this,currentWorkflowNameMap.get(workflowId) +STRHASH+currentActivityNameMap.get(workItemId)+ " - Project Team members Updated ...",null,null);
					}
					else{
						DfLogger.info(this,"Cannot refresh performers as document is locked", null, null);
						for (int i=0;i<futurePerformerList.size();i++){			
							if(performeGrp.isUserInGroup(futurePerformerList.get(i).toString()) == true){
								performeGrp.removeUser(futurePerformerList.get(i).toString());
								DfLogger.debug(this,"Removed \t:"+futurePerformerList.get(i).toString(),null,null);
							}
						}
						performeGrp.save();
				 }
				sessMgr.release(adminSession);
				}else{
				DfLogger.debug(this,currentWorkflowNameMap.get(workflowId) +STRHASH+currentActivityNameMap.get(workItemId)+ " - Not Updating the performer group.",null,null);
				}
			}
		}catch (DfException e) {
			e.printStackTrace();
			finalMessageMap.put(currentWorkflowNameMap.get(workflowId), currentActivityNameMap.get(workItemId) + " - Exception Occurred : "+e.getMessage());
		}
		return canRefresh;
	}
	
	private void fetchCurrentWorkflowDetails(IDfSession dfSession,
			String strDocumentId) throws DfException {
		String QRY_GET_WORKFLOW_ID = GET_WORKFLOW_ID.replaceFirst(RefreshPerformerUtility.QRY_VARIABLE_OBJECT_ID, strDocumentId);
		DfLogger.debug(this,"QRY_GET_WORKFLOW_ID : " + QRY_GET_WORKFLOW_ID,null,null);
		IDfCollection collection = (IDfCollection) IdocsUtil.executeQuery(dfSession, QRY_GET_WORKFLOW_ID, IDfQuery.DF_READ_QUERY);
		while (collection.next()) {
			String strWorkflowId = collection.getString(RefreshPerformerUtility.R_OBJECT_ID);
			String strProcessName = collection.getString(RefreshPerformerUtility.OBJECT_NAME);
			DfLogger.debug(this,"workflow id : " + strWorkflowId,null,null);
			fetchWorkItemDetails(dfSession, strWorkflowId);
			currentWorkflowNameMap.put(strWorkflowId,strProcessName);
		}
		if (collection != null)
			collection.close();
	}

	private void fetchWorkItemDetails(IDfSession dfSession,
			String strWorkflowId) throws DfException {
		String QRY_GET_WORKITEM_FR_WF = GET_WORKITEM_FR_WF.replaceAll(RefreshPerformerUtility.QRY_VARIABLE_WORKFLOW_ID, strWorkflowId);
		DfLogger.debug(this,"fetchWorkItemDetails : QRY_GET_WORKITEM_FR_WF="+QRY_GET_WORKITEM_FR_WF,null,null);
		IDfCollection coll = IdocsUtil.executeQuery(dfSession,QRY_GET_WORKITEM_FR_WF, IDfQuery.DF_READ_QUERY);
		try {
			while (coll.next()) {
				String strPerformerName = coll.getString(PERFORMER);
				if(strPerformerName !=null && strPerformerName.trim().length() > 0
						&& DM_BPS_INBOUND_USER.equalsIgnoreCase(strPerformerName)==false){
					String strWorkitemID = coll.getString(WORKITEM_ID);
					currentWorkItemMap.put(strWorkitemID,strWorkflowId);
					currentActivityNameMap.put(strWorkitemID, coll.getString(RefreshPerformerUtility.R_ACTIVITY_NAME));
					currentperformerGroupMap.put(strWorkitemID, coll.getString(PERFORMER));
					currentRuntimeStateMap.put(strWorkitemID, coll.getString("workitem_runitme_state"));
				}else{
					DfLogger.debug(this, " fetchWorkItemDetails : This is a delay activity. Do not show it to the user.", null, null);
				}
			}		 
		}catch(DfException e){
			DfLogger.debug(this, " fetchWorkItemDetails : Exception :"+e.getMessage(), null, null);			
		}finally {
			if (coll != null) {
				coll.close();
			}
		}
	}

	private boolean isExcluded(IDfSession dfSession,String strActivityName, String strProcessName) throws DfException {
		boolean isExcluded = false;
		refreshRequiredAsItsLDAP  = false;
		String QRYIS_REFRESH_REQUIRED = IS_REFRESH_REQUIRED;
		QRYIS_REFRESH_REQUIRED= QRYIS_REFRESH_REQUIRED.replace(RefreshPerformerUtility.QRY_VARIABLE_STR_PROCESS_NAME, strProcessName);
		QRYIS_REFRESH_REQUIRED = QRYIS_REFRESH_REQUIRED.replace(RefreshPerformerUtility.QRY_VARIABLE_STR_ACTIVITY_NAME, strActivityName);
		IDfCollection coll = IdocsUtil.executeQuery(dfSession, QRYIS_REFRESH_REQUIRED,IDfQuery.DF_READ_QUERY);
		while (coll.next()) {
			String roleType = coll.getString(RefreshPerformerUtility.ROLE_TYPE);
			if(roleType != null && roleType.trim().length() > 0 ){
				if(roleType.equals(RefreshPerformerUtility.LDAP_GROUP_ROLE)){
					refreshRequiredAsItsLDAP  = true;
				}else if(roleType.equals(RefreshPerformerUtility.ROLE_EXCLUDED)){
					isExcluded = true;
				}
			}
		}
		if (coll != null)coll.close();

		return isExcluded;
	}

	
	private boolean refreshRequiredAsItsLDAP = false;
	
	private static String GET_WORKFLOW_ID = IdocsUtil.getMessage(RefreshPerformerUtility.REFRESH_GET_WORKFLOW_ID);
	private static String GET_WORKITEM_FR_WF = IdocsUtil.getMessage(RefreshPerformerUtility.REFRESH_GET_WORKITEM_FR_WF);
	private static String IS_REFRESH_REQUIRED = IdocsUtil.getMessage(RefreshPerformerUtility.REFRESH_IS_REFRESH_REQUIRED);
	
	private HashMap<String,String> currentWorkflowNameMap = new HashMap<String,String>();
	private HashMap<String, String> currentWorkItemMap = new HashMap<String, String>();
	private HashMap<String, String> currentActivityNameMap = new HashMap<String, String>();
	private HashMap<String, String> currentperformerGroupMap = new HashMap<String, String>();
	private HashMap<String, String> currentRuntimeStateMap = new HashMap<String, String>();
	private HashMap<String, ArrayList<String>> correctPerformerGroupMap = new HashMap<String, ArrayList<String>>();
	private HashMap<String, String> finalMessageMap = new HashMap<String, String>();
	public static final String serialNoLabelName = "serialNoLabel";
	public static final String activityLabelName = "activityLabel";
	public static final String refreshStatusLabelName = "refreshStatusLabel";
	private boolean updateWfPerformerGrpReqd = false;

	
}
