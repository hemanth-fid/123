package org.worldbank.icsid.rps;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.TimeZone;

import com.documentum.com.DfClientX;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfList;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.fc.common.IDfTime;
import com.documentum.rpm.services.IRpmRetentionService;
import com.documentum.rps.retention.RetentionBean;
import com.documentum.rps.retention.RetentionResultBean;

public class PolicyUtils {
	
	protected static void executeRemovePolicy(IDfSession dfSession,String m_policyTaskId, String m_folderPath,
			String m_retentionPolicyName, String m_RetentionPolicyId,boolean isPolicyAlreadyApplied, IDfClient m_client,ResourceBundle bundle) throws DfException {
		writeLog("executeRemovePolicy >>");		
		String totalExecTime=Constants.TOTAL_EXECUTION_TIME;

		long strtTime=getTimeInMs();
		boolean applyPolicyStatus;
		if (isPolicyAlreadyApplied == true) {
			storeSystemAttributesForPostProcessing(m_folderPath, m_policyTaskId, dfSession);
			applyPolicyStatus = removeRetentionPolicy(m_policyTaskId,m_folderPath,m_RetentionPolicyId, isPolicyAlreadyApplied,m_client, dfSession);
			if(applyPolicyStatus == true){
				processExecLogTableRecords(m_policyTaskId, m_RetentionPolicyId, dfSession,bundle); 
				updateRPSApplyTaskProcessedStatus(m_policyTaskId,"Y",dfSession);
			}else{
				writeLog("Remove Policy Failed >> Task Id :"+ m_policyTaskId+ " :: Exception : Retention Policy Name :"+ m_retentionPolicyName+ " folder :" + m_folderPath);
			}
		}else{
			/** Just Update the Table that this task is processed. */
			updateRPSApplyTaskProcessedStatus(m_policyTaskId,"Y",dfSession);
			writeLog("Policy is Not Applied . No Action Required .. ");
		}
		
		long endTime=getTimeInMs();
		updateExecutionTime(m_policyTaskId,strtTime,endTime,totalExecTime,dfSession);
		writeLog("executeRemovePolicy <<");
	}

	protected static void executeApplyPolicy(IDfSession dfSession,String m_policyTaskId, String m_folderPath,
			String m_retentionPolicyName, String m_RetentionPolicyId,boolean isPolicyAlreadyApplied, IDfClient m_client,ResourceBundle bundle) throws DfException {
		writeLog("executeApplyPolicy >>");
		String totalExecTime=Constants.TOTAL_EXECUTION_TIME;
		long strtTime=getTimeInMs();
		
		boolean applyPolicyStatus;
		if (isPolicyAlreadyApplied == false) {
			storeSystemAttributesForPostProcessing(m_folderPath, m_policyTaskId, dfSession);
			applyPolicyStatus = applyRetentionPolicy(m_policyTaskId,m_folderPath,m_RetentionPolicyId, isPolicyAlreadyApplied,m_client,dfSession);
			if(applyPolicyStatus == true){
				processExecLogTableRecords(m_policyTaskId, m_RetentionPolicyId, dfSession,bundle);
				updateRPSApplyTaskProcessedStatus(m_policyTaskId,"Y",dfSession);
			}else{
				writeLog("Apply Policy Failed >> Task Id :"+ m_policyTaskId+ " :: Exception : Retention Policy Name :"+ m_retentionPolicyName+ " folder :" + m_folderPath);
			}
		}else{
			/** Just Update the Table that this task is processed. */
			updateRPSApplyTaskProcessedStatus(m_policyTaskId,"Y",dfSession);
			writeLog("Policy is Already Applied . No Action Required .. ");
		}
		long endTime=getTimeInMs();
		updateExecutionTime(m_policyTaskId,strtTime,endTime,totalExecTime,dfSession);
		writeLog("executeApplyPolicy <<");
	}
	
	/**
	 * This Method Reads the Apply Policy Input Task id and returns the collection.
	 * @param m_File 
	 * @param dfSession
	 * @return
	 * @throws Exception
	 */
	public static IDfCollection checkForNewRPSApplyTasks(String totalInstanceNbr,String currentInstanceNbr,IDfSession dfSession) throws Exception{
		String strFetchAppyPolicyTaskInputTasks = "select apply_policy_task_id,folder_path,retention_policy_name,isprocessed,action from dm_dbo.ICSID_RPS_BATCH_JOB_PROCESS where isprocessed='N'"; 
				//fetchProcessingQry(totalInstanceNbr,currentInstanceNbr,dfSession);
		IDfCollection applyPolicyInputTaskCollection= executeQuery(strFetchAppyPolicyTaskInputTasks, IDfQuery.DF_READ_QUERY,dfSession);
		return applyPolicyInputTaskCollection;
	} 
	
	
	public static String fetchProcessingQry(String totalInstanceNbr,String currentInstanceNbr,IDfSession dfSession) throws Exception{
		
		String strQry = "select apply_policy_task_id,folder_path,retention_policy_name,isprocessed,action from dm_dbo.ICSID_RPS_BATCH_JOB_PROCESS where isprocessed='N'";
		IDfCollection dfColl= executeQuery(strQry, IDfQuery.DF_READ_QUERY,dfSession);
		StringBuffer taskIds=new StringBuffer();
		while(dfColl.next()){
			int taskId=Integer.parseInt(dfColl.getString("apply_policy_task_id"));

			if((taskId%Integer.parseInt(totalInstanceNbr))==Integer.parseInt(currentInstanceNbr)){
				System.out.println("taskId :: "+taskId);
				taskIds=taskIds.append(","+"'"+taskId+"'");
			}
		}if(dfColl!=null)dfColl.close();
	
		taskIds.deleteCharAt(0);
		strQry=strQry.concat(" and apply_policy_task_id IN ("+taskIds+")");
		
		return strQry;
	}
	
	public static void storeSystemAttributesForPostProcessing(String folderPath,String m_policyTaskId,IDfSession dfSession) {
		IDfCollection dfColl = null;
		String objectId=null;
		String modifyDate=null;
		String modifier=null;
		try{
			folderPath = folderPath.replaceAll("'", "''");
			String strQuery = "select r_object_id,r_modify_date,r_modifier from dm_document(ALL) where folder('"+folderPath+"',descend)" +
					" UNION select r_object_id,r_modify_date,r_modifier from dm_folder where folder('"+folderPath+"',descend)" +
					" UNION select r_object_id,r_modify_date,r_modifier from dm_folder where any r_folder_path ='"+folderPath+"'";
			writeLog("strQuery : " + strQuery );
			dfColl  = executeQuery(strQuery, IDfQuery.DF_QUERY,dfSession);
			int i=0;
			while(dfColl.next()) {
				i++;
				objectId=dfColl.getString("r_object_id");
				modifyDate=dfColl.getString("r_modify_date");
				modifier=dfColl.getString("r_modifier");
				writeLog(objectId +" : "+modifyDate +" : "+modifier);
				insertIntoExecutionLogTable(objectId,modifyDate,modifier,m_policyTaskId,dfSession);
			}if(dfColl!=null){
				dfColl.close();
			}
		writeLog("UNION Records ::: "+i);
		}catch(DfException e){
			e.printStackTrace();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	public static void processExecLogTableRecords(String m_policyTaskId,String m_retentionPolicyId,IDfSession dfSession,ResourceBundle bundle) {
		IDfCollection dfColl = null;
		String objectId=null;
		String modifyDate=null;
		String modifier=null;
		String str_isLocked=null;
		String str_isPolicyApplied=null;
		String str_status=null;
		String str_isProcessed=null;
		
		try{
			String strQry="select r_object_id,r_modify_date,r_modifier from dm_dbo.ICSID_RPS_EXECUTION_LOG where apply_policy_task_id='<policy_task_id>' and processed='N'";
			strQry=strQry.replace("<policy_task_id>", m_policyTaskId);
			dfColl  = executeQuery(strQry, IDfQuery.DF_QUERY,dfSession);
			int totalNumberOfObjectsProcessed = 0;
			while(dfColl.next()) {
				totalNumberOfObjectsProcessed ++;
				//Initialize flag values of ICSID_RPS_EXECUTION_LOG
				str_isLocked="N";
				str_isPolicyApplied="N";
				str_status="Not Updated";
				str_isProcessed="N";
				objectId=dfColl.getString("r_object_id");
				modifyDate=dfColl.getTime("r_modify_date").asString(IDfTime.DF_TIME_PATTERN26);
				modifyDate = convertDate(modifyDate,bundle);
				modifier=dfColl.getString("r_modifier");
				
				IDfSysObject sysObject = (IDfSysObject)dfSession.getObject(new DfId(objectId.toString()));
				
				//Check if sysObject Checkedout and policy applied
				if(sysObject!=null){
					str_isProcessed="Y";
					if(isDocCheckedOut(sysObject)){
						str_isLocked="Y";
					}else if(isPolicyApplied(sysObject,m_retentionPolicyId,dfSession)){
						str_isPolicyApplied="Y";
					}
				}
				
				//update r_modify_date and r_modifier
				//if(str_isLocked.equalsIgnoreCase("N") && str_isPolicyApplied.equalsIgnoreCase("Y")){
				if(str_isLocked.equalsIgnoreCase("N")){	
					if(updateReadOnlyAttributes(objectId,modifyDate,modifier,dfSession)){
						str_status="Updated";
					}
				}else{
					writeLog("Object r_modify_date and r_modifer not updated : "+objectId);
				}				
				//update ICSID_RPS_EXECUTION_LOG with the flag values
				updateExecLogTableRecords(m_policyTaskId,str_isLocked,str_isPolicyApplied,str_isProcessed,str_status,objectId,dfSession);
			}if(dfColl!=null){
				dfColl.close();
			}
			writeLog("Total Number Of Objects Processed for Task : "+ m_policyTaskId +"  :: "+ totalNumberOfObjectsProcessed);
		}catch(DfException e){
			e.printStackTrace();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static boolean isPolicyApplied(IDfSysObject sysObject,String m_retentionPolicyId,IDfSession dfSession) throws DfException {
		boolean isPolicyApplied=false;
		if(sysObject!=null){
			for (int i = 0; i < sysObject.getRetainerCount(); i++) {
				String currentRetainerId = sysObject.getRetainerId(i).getId();
				String appliedPolicyId = getRetentionPolicyIdFromRetainerId(currentRetainerId,dfSession);
				if (new DfId(m_retentionPolicyId).getId().equals(appliedPolicyId)) {
					isPolicyApplied=true;
				}
			}
		}
		return isPolicyApplied;
	}
	
	private static void updateExecLogTableRecords(String m_policyTaskId,
			String isLocked, String isPolicyApplied, String processed,
			String status, String objectId,IDfSession dfSession) throws DfException {
		IDfCollection dfColl=null;
		String updateQry="update dm_dbo.ICSID_RPS_EXECUTION_LOG set is_locked='<is_locked>'," +
				"is_policy_applied='<is_policy_applied>',processed='<processed>'," +
				"status='<status>',time_stamp=DATE(NOW) where r_object_id='<r_object_id>' and " +
				"apply_policy_task_id='<apply_policy_task_id>'";
		
		updateQry=updateQry.replace(Constants.QRY_STRING_IS_LOCKED, isLocked);
		updateQry=updateQry.replace(Constants.QRY_STRING_IS_POLICY_APPLIED, isPolicyApplied);
		updateQry=updateQry.replace(Constants.QRY_STRING_PROCESSED, processed);
		updateQry=updateQry.replace(Constants.QRY_STRING_STATUS, status);
		updateQry=updateQry.replace(Constants.QRY_STRING_R_OBJECT_ID, objectId);
		updateQry=updateQry.replace(Constants.QRY_STRING_APPLY_POLICY_TASK_ID, m_policyTaskId);
		//writeLog("updateExecutionLogTableQry" + updateQry);
		dfColl  = executeQuery(updateQry, IDfQuery.DF_EXEC_QUERY,dfSession);
		
		while(dfColl.next()){
			//writeLog(dfColl.getString("rows_updated"));
		
		}if(dfColl != null)
			dfColl.close();

	}

	private static boolean isDocCheckedOut(IDfSysObject sysObject)
			throws DfException {
		boolean isCheckout = false;
		if (sysObject != null) {
			if (sysObject.isCheckedOut()
					&& sysObject.getLockOwner().trim().length() > 0) {
				isCheckout = true;
			}
		}
		return isCheckout;
	}

	/*
	 * DFC API can not set r_modifier_name, r_modify_date, r_creator_name and r_creation_date by design. In order to maintain 
	 * those information from IRIS, use super user rights through SQL to set those values.
	 */
	private static boolean updateReadOnlyAttributes(String strObjectId,
			String strRModifyDate, String strRModifier,IDfSession dfSession) throws DfException {
		boolean executionStatus = false;
		try {
			strRModifier=strRModifier.replaceAll("'", "''''");
			String strUpdateReadOnlyAttributesQuery = "EXECUTE exec_sql with query='update dm_sysobject_s set r_modifier=''"
					+ strRModifier
					+ "'', r_modify_date=TO_DATE(''"
					+ strRModifyDate
					+ "'',''YYYY/MM/DD HH24:MI:SS'') where r_object_id=''"
					+ strObjectId + "'''";
			//writeLog(strUpdateReadOnlyAttributesQuery);
			writeLog("strUpdateReadOnlyAttributesQuery : " + strUpdateReadOnlyAttributesQuery);
			IDfCollection dfColl = executeQuery(strUpdateReadOnlyAttributesQuery,IDfQuery.DF_EXEC_QUERY,dfSession);
			while (dfColl.next()) {
				//writeLog("updateReadOnlyAttributes  :" + dfColl.getString("result"));
				executionStatus = true;
			}
			if (dfColl != null)
				dfColl.close();
		} catch (DfException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}

		return executionStatus;
	}
	

	private  static void insertIntoExecutionLogTable(String objectId,
			String modifyDate, String modifier, String policyTaskId,
			IDfSession dfSession)  {
		try{
			//IDfCollection dfInsertColl = null;
			//int insertExecLogCntr = 0;
			modifier = modifier.replaceAll("'", "''");
			String strQuery = "insert into dm_dbo.ICSID_RPS_EXECUTION_LOG (apply_policy_task_id,r_object_id,r_modify_date,r_modifier,is_locked,is_policy_applied,processed,status,userid,time_stamp) " +
					"values ('<apply_policy_task_id>','<r_object_id>',DATE('<r_modify_date>','dd/mm/yyyy hh:mi:ss am'),'<r_modifier>','N','N','N','Not Updated','<userid>',DATE(NOW))";
			strQuery = strQuery.replace(Constants.QRY_STRING_APPLY_POLICY_TASK_ID,policyTaskId.trim());
			strQuery = strQuery.replace(Constants.QRY_STRING_R_OBJECT_ID, objectId.trim());
			strQuery = strQuery.replace(Constants.QRY_STRING_R_MODIFY_DATE, modifyDate.trim());
			strQuery = strQuery.replace(Constants.QRY_STRING_R_MODIFIER, modifier.trim());
			strQuery = strQuery.replace(Constants.QRY_STRING_USERID, dfSession.getLoginUserName());
			// @ TODO User names may contain special characters
			//dfInsertColl = executeQuery(strQuery, IDfQuery.DF_EXEC_QUERY, dfSession);
			writeLog("insert into dm_dbo.ICSID_RPS_EXECUTION_LOG strQuery : " + strQuery);
			IDfCollection collection = executeQuery(strQuery, IDfQuery.DF_EXEC_QUERY, dfSession);
			while(collection.next()){
				//writeLog("Rows Inserted :" + collection.getString("rows_inserted"));
			}if(collection != null)collection.close();
			//while (dfInsertColl.next()) {
			//writeLog("Record inserted : " + objectId);
			//insertExecLogCntr++;
			//}if (dfInsertColl != null)
			//	dfInsertColl.close();
			//writeLog(" insertExecLogCntr : " + insertExecLogCntr);
		}catch (DfException e) {
			e.printStackTrace();
		}
	}
	
	public static String getRetentionPolicyIdFromRetainerId(String retainerId,
			IDfSession m_session) {
		String m_RetentionRetainerId = null;
		try {
			String strQuery = "select retention_policy_id from dmc_rps_retainer where r_object_id='"+ retainerId + "'";
			IDfCollection collection = executeQuery(strQuery,IDfQuery.DF_READ_QUERY, m_session);
			while(collection.next()){
				m_RetentionRetainerId = collection.getString("retention_policy_id");
			} 
			if(collection != null)collection.close();

			if(m_RetentionRetainerId  != null && m_RetentionRetainerId.trim().length() > 0){
				//writeLog(retainerId + " = " + m_RetentionRetainerId );
			}else {
				writeLog(strQuery);
				writeLog(retainerId + " Not Found !!!!");
			}

		} catch (DfException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return m_RetentionRetainerId;
	}
	
	public static boolean applyRetentionPolicy(String policyTaskId,String folderId,
			String retentionPolicyId, boolean isPolicyAlreadyApplied, IDfClient m_client, IDfSession dfSession) {
		writeLog("applyRetentionPolicy >> :" + new  Date());
		String rpsExecTime=Constants.RPS_EXECUTION_TIME;
		long strtTime=getTimeInMs();
		
		boolean applyPolicyStatus = false;
		try {
			IDfSysObject sysObject = (IDfSysObject) dfSession.getObjectByPath(folderId);
			IRpmRetentionService retentionService = (IRpmRetentionService) m_client
					.newModule(dfSession.getDocbaseName(),com.documentum.rpm.services.IRpmRetentionService.class.getName(), dfSession.getSessionManager());
			RetentionBean retentionBean = new RetentionBean();
			retentionBean.setRetentionPolicyId(new DfId(retentionPolicyId));
			IDfList resultList = retentionService.applyRetentionAndSave(sysObject, retentionBean);
			if (resultList != null) {
				for (int i = 0; i < resultList.getCount(); i++) {
					Object obj = resultList.get(i);
					if (obj instanceof RetentionResultBean) {
						RetentionResultBean retResultBean = (RetentionResultBean) obj;
						writeLog("getMessage() = " + retResultBean.getMessage() + ",isSuccess = " + retResultBean.getSuccess());
					}
				}
			}
			applyPolicyStatus = true;
		 
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		long endTime=getTimeInMs();
		updateExecutionTime(policyTaskId,strtTime,endTime,rpsExecTime,dfSession);
		writeLog("applyRetentionPolicy <<" + new  Date());
		return applyPolicyStatus;
	}
	
	public static String getRetentionPolicyObjectId(
			String retentionPolicyName,IDfSession m_session) throws DfException {
		String strFindRetainerIdQuery = "select r_object_id from dmc_rps_retention_policy where object_name='"+retentionPolicyName+"'";
		IDfCollection collection = executeQuery(strFindRetainerIdQuery, IDfQuery.DF_READ_QUERY, m_session);
		String retentionPolicyObjectId = null;
		while(collection.next()){
			retentionPolicyObjectId = collection.getString("r_object_id");
		}
		if(collection != null)collection.close();
		return retentionPolicyObjectId;
	}
	
	public static void writeLog(String messageText) {
		try {
			System.out.println(messageText);
//			log.error(e);
			
			/*Calendar cal = Calendar.getInstance();
			SimpleDateFormat m_formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			writeLog(m_formatter.format(cal.getTime()) + " " + messageText);*/
			
		} catch (Exception e) {
			e.printStackTrace();
		}/*	catch (Exception e) {
			e.printStackTrace();
		}*/		
	}

	private static  IDfCollection executeQuery(String strQuery, int queryType,IDfSession dfSession) throws DfException{
		IDfQuery dfQuery = new DfQuery();
		dfQuery.setDQL(strQuery);
		//writeLog (strQuery);
		IDfCollection dfCollection = dfQuery.execute(dfSession,queryType);
		return dfCollection;
	}
	
	public static void updateRPSApplyTaskProcessedStatus(String m_policyTaskId,
			String attrVal, IDfSession dfSession2) throws DfException {
		String updateQry="update dm_dbo.ICSID_RPS_BATCH_JOB_PROCESS set isprocessed='<processed>' where apply_policy_task_id='<apply_policy_task_id>'";
		updateQry=updateQry.replace(Constants.QRY_STRING_PROCESSED, attrVal);
		updateQry=updateQry.replace(Constants.QRY_STRING_APPLY_POLICY_TASK_ID, m_policyTaskId);
		executeQuery(updateQry,IDfQuery.DF_EXEC_QUERY,dfSession2);
		
	}
	
	public static void updateRPSApplyStartEndTime(String m_policyTaskId,
			String attrName, IDfSession dfSession2) throws DfException {
		String updateQry="update dm_dbo.ICSID_RPS_BATCH_JOB_PROCESS set <attr_name>=DATE(NOW) where apply_policy_task_id='<apply_policy_task_id>'";
		updateQry=updateQry.replace("<attr_name>", attrName);
		updateQry=updateQry.replace(Constants.QRY_STRING_APPLY_POLICY_TASK_ID, m_policyTaskId);
		executeQuery(updateQry,IDfQuery.DF_EXEC_QUERY,dfSession2);
		
	}
	
	public static IDfSessionManager createDfSessionManager(String userName,String pwd,String docbase) {
		IDfSessionManager sessionMgr = null;
		try {
			String username = userName;
			String password = pwd;
			String repository = docbase;
			DfClientX clientx = new DfClientX();
			IDfClient client = clientx.getLocalClient();
			sessionMgr = client.newSessionManager();
			IDfLoginInfo logininfo = clientx.getLoginInfo();
			logininfo.setUser(username);
			logininfo.setPassword(password);
			sessionMgr.setIdentity(repository, logininfo);
		} catch (DfException e) {
			e.printStackTrace();
		}
		return sessionMgr;
	}
	
	public static boolean removeRetentionPolicy(String policyTaskId,String folderId,
			String retentionPolicyId, boolean isPolicyAlreadyApplied, IDfClient m_client, IDfSession dfSession) {
		writeLog("removeRetentionPolicy >>" + new  Date());
		String rpsExecTime=Constants.RPS_EXECUTION_TIME;
		long strtTime=getTimeInMs();
		
		boolean removePolicyStatus = false;
		try {
			IDfSysObject sysObject = (IDfSysObject) dfSession.getObjectByPath(folderId);
			if (sysObject != null) {
				writeLog("Start removing policy");
				IRpmRetentionService retentionService = (IRpmRetentionService) m_client
						.newModule(dfSession.getDocbaseName(),com.documentum.rpm.services.IRpmRetentionService.class.getName(), dfSession.getSessionManager());
				RetentionBean retentionBean = new RetentionBean();
				retentionBean.setRetentionPolicyId(new DfId(retentionPolicyId));

				IDfList resultList = retentionService.removeRetention(sysObject, new DfId(retentionPolicyId));
				writeLog("End removing policy");

				if (resultList != null) {
					for (int i = 0; i < resultList.getCount(); i++) {
						Object obj = resultList.get(i);
						if (obj instanceof RetentionResultBean) {
							RetentionResultBean retResultBean = (RetentionResultBean) obj;
							writeLog("getMessage() = " + retResultBean.getMessage() + ",isSuccess = " + retResultBean.getSuccess());
						}
					}
				}
			}
			removePolicyStatus = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		long endTime=getTimeInMs();
		updateExecutionTime(policyTaskId,strtTime,endTime,rpsExecTime,dfSession);
		writeLog("removeRetentionPolicy <<" + new  Date());
		return removePolicyStatus;
	}
	
	public static boolean checkIfPolicyIsAppliedOnTheFolder(String retentionPolicyId,
			String m_folderPath, IDfSession dfSession) {
		try {
			IDfSysObject sysObject = (IDfSysObject) dfSession.getObjectByPath(m_folderPath);
			for (int i = 0; i < sysObject.getRetainerCount(); i++) {
				String currentRetainerId = sysObject.getRetainerId(i).getId();
				String appliedPolicyId = PolicyUtils.getRetentionPolicyIdFromRetainerId(currentRetainerId,dfSession);
				if (retentionPolicyId.equals(appliedPolicyId)) {
					writeLog("Retention Policy already exists for this document");
					return true;
				} else {
					writeLog("Retention Policy is not applied on this document");
				}
			}
		} catch (DfException e) {
			e.printStackTrace();
		}
		return false;
	}

	public static boolean isFolderPathExisting(String folderPath,IDfSession dfSession) {

		boolean isFolderExisting=false;
		IDfCollection dfColl = null;
		try{
			folderPath = folderPath.replaceAll("'", "''");
			String strQuery = "select r_object_id from dm_folder where any r_folder_path='"+folderPath+"'";
			dfColl  = executeQuery(strQuery, IDfQuery.DF_READ_QUERY,dfSession);

			if(dfColl.next()) {
				isFolderExisting=true;
				writeLog("Folder Path : "+folderPath +" exists");
			}else{
				writeLog("Folder Path : "+folderPath +"does not exist");
			}


			// end of while()
			if (dfColl!=null)
				dfColl.close();
		}catch (DfException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

			

		} 

		return isFolderExisting;
	}	

	public static void updateExecutionTime(String taskId,long strtTime,long endTime,String attrName,IDfSession dfSession){
		
		//System.out.println("TimeUnit.MILLISECONDS.toMinutes :: "+TimeUnit.MILLISECONDS.toMinutes(endTime-strtTime));
		//System.out.println("TimeUnit.MILLISECONDS.toSeconds :: "+TimeUnit.MILLISECONDS.toSeconds(endTime-strtTime));
		
		//System.out.println("Method Name : "+methodNme +"-- m_policyTaskId ::  "+taskId +" "+"-- ACTION : "+action +"-- Execution Time : "+TimeUnit.MILLISECONDS.toMinutes(endTime-strtTime)+" min    "+TimeUnit.MILLISECONDS.toSeconds(endTime-strtTime)+" secs");
		//writeLog("Method Name : "+methodNme +"-- m_policyTaskId ::  "+taskId +" "+"-- ACTION : "+action +"-- Execution Time : "+TimeUnit.MILLISECONDS.toMinutes(endTime-strtTime)+" min    "+TimeUnit.MILLISECONDS.toSeconds(endTime-strtTime)+" secs");
		
		
		try {
			String timeDiff=String.valueOf(endTime-strtTime);
			writeLog("updateExecutionTime() ::: timeDiff : attrName : "+timeDiff);
			
			String updateQry="update dm_dbo.ICSID_RPS_BATCH_JOB_PROCESS set <attr_name>='<attrVal>' where apply_policy_task_id='<apply_policy_task_id>'";
			updateQry=updateQry.replace("<attr_name>", attrName);
			updateQry=updateQry.replace(Constants.QRY_STRING_APPLY_POLICY_TASK_ID, taskId);
			updateQry=updateQry.replace("<attrVal>", timeDiff);
			executeQuery(updateQry,IDfQuery.DF_EXEC_QUERY,dfSession);
		
		} catch (DfException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static String convertDate(String strDate,ResourceBundle bundle){
//		String utcDate = null;
		try{
//		System.out.println(strDate + bundle.getString("TIME_ZONE"));
		String timeZone = bundle.getString("TIME_ZONE");
		DateFormat indfm = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		//indfm.setTimeZone(TimeZone.getTimeZone("America/New_York"));
		indfm.setTimeZone(TimeZone.getTimeZone(timeZone));
		Date purchaseDate = indfm.parse(strDate);

		DateFormat outdfm = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		
		outdfm.setTimeZone(TimeZone.getTimeZone("GMT"));
		
		
		return(outdfm.format(purchaseDate));
		}catch ( Exception ex){
			ex.printStackTrace();
			return "" ;
		}
	}
	
	public static long getTimeInMs(){
		return System.currentTimeMillis();
	}
}
