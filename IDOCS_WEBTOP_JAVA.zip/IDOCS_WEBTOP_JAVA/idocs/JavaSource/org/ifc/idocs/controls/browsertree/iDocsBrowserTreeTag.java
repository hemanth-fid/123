/**
 * This is the tag library class for the custom browser tree control - iDocsBrowserTreeControl
 */
package org.ifc.idocs.controls.browsertree;

import com.documentum.webtop.control.WebTopBrowserTreeTag;

/**
 * @author CVattathara
 *
 */
public class iDocsBrowserTreeTag extends WebTopBrowserTreeTag
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * This method is to return the custom browser tree control class
	 * @return Class
	 */
	@SuppressWarnings("unchecked")
	protected Class getControlClass()
	{
		return org.ifc.idocs.controls.browsertree.iDocsBrowserTreeControl.class;
	}
}
