
package org.ifc.idocs.changedoctype;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.LocaleService;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.Panel;
import com.documentum.web.form.control.Text;
import com.documentum.web.form.control.databound.DataDropDownList;
import com.documentum.web.form.control.databound.TableResultSet;
import com.documentum.web.formext.component.Component;

public class ChangeDocType extends Component{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String MSG_UPDATED_DOCUMENT_TYPE = "Changed Document Type";
	private String m_NewDocNlsProp = "org.ifc.idocs.contenttransfer.importcontent.ImportContentNlsProp";
	private NlsResourceBundle m_nlsResourceBundleCreateDoc = new NlsResourceBundle(m_NewDocNlsProp);
	private String folderCategory = IDocsConstants.MSG_EMPTY_STRING;
	String subFolderTitle = IDocsConstants.MSG_EMPTY_STRING;
	String docTypeName = IDocsConstants.MSG_EMPTY_STRING;
	String docTypeCode =  IDocsConstants.MSG_EMPTY_STRING;
	String docInputName=IDocsConstants.MSG_EMPTY_STRING;
	IDfDocument docObject = null;
	private final String PANEL_SUCCESS = "success";
	private final String PANEL_FAILURE = "failure";
	String currentPanel = PANEL_FAILURE ;	
	
	/**
	 * 
	 */
	public void onInit(ArgumentList args) {
		try {
			// Success Panel
	        Panel successpanel = (Panel)getControl(PANEL_SUCCESS,Panel.class);
	        // Failure Panel
	        Panel failurepanel = (Panel)getControl(PANEL_FAILURE,Panel.class);
	        IDfSession dfSession = getDfSession();
			String strObjectId = args.get("objectId");
			DfLogger.debug(this, " :: onInit : strObjectId: " + strObjectId,null,null);
			docObject = (IDfDocument)(dfSession.getObject(new DfId(strObjectId)));
			if(getDfSession().getLoginUserName().equals(docObject.getOwnerName())==false){
				DfLogger.debug(this, " :: onInit :: Only Owner has access to this component ", null, null);
				failurepanel.setVisible(true);
		        successpanel.setVisible(false);
		        currentPanel = PANEL_FAILURE;
		        Label checkedoutLabel = (Label)getControl("checkedoutlabel",Label.class);
				checkedoutLabel.setVisible(false);
				Label messageLabel = (Label)getControl("cannotchangelabel",Label.class);
				messageLabel.setVisible(false);	
				Label onlyOwnerError = (Label)getControl("onlyownerallowedtochange",Label.class);
				onlyOwnerError.setLabel("Only the document owner '"+docObject.getOwnerName()+"' can perform this operation");
				onlyOwnerError.setVisible(true);
	        }else{
				IDfId folderID = docObject.getFolderId(0);
				String strFolderId =  folderID.toString();
				DfLogger.debug(this, " :: onInit : strFolderId: " + strFolderId, null, null);
				IDfFolder parentFolder=null;
				IDfFolder docFolder = (IDfFolder)dfSession.getObject(new DfId(strFolderId));
		        if (docFolder.getTypeName().equals(IdocsConstants.PROJ_FOLDER_TYPE)
		           	|| docFolder.getTypeName().equals(IdocsConstants.INSTITUTION_FOLDER_TYPE)
		           	|| docFolder.getTypeName().equals(IdocsConstants.COUNTRY_FOLDER_TYPE)) {	    	       
		        		parentFolder = docFolder;	        		
		        } else {
		    	       docFolder = (IDfFolder)dfSession.getObject(docFolder.getFolderId(0));
		    	       if(docFolder.getTypeName().equals(IdocsConstants.PROJ_FOLDER_TYPE) 
		    	        	|| docFolder.getTypeName().equals(IdocsConstants.INSTITUTION_FOLDER_TYPE) 
		    	        	|| docFolder.getTypeName().equals(IdocsConstants.COUNTRY_FOLDER_TYPE)) {
		    	    	   	parentFolder = docFolder;	    	        		
		    	        }else {
		    	        	parentFolder=(IDfFolder)dfSession.getObject(docFolder.getFolderId(0));
		    	        }
		        }
		        DfLogger.debug(this, " :: onInit() : Parent Folder ID : " + parentFolder.getObjectId()+
		        		" Object Name : " + parentFolder.getObjectName(),null,null);
		        folderCategory = parentFolder.getString(IDocsConstants.MSG_FOLDER_CATEGORY);	
		        DfLogger.debug(this, " :: onInit : parent folder category: " + folderCategory, null, null);
		        
		        if (docObject != null){
					String currentObjectTypeName = docObject.getTypeName();
					if (currentObjectTypeName != null && currentObjectTypeName.trim().length() > 0){
						if(docObject!=null && docObject.isCheckedOut()){
							 failurepanel.setVisible(true);
						     successpanel.setVisible(false);
							 currentPanel = PANEL_FAILURE;
							 Label checkedoutLabel = (Label)getControl("checkedoutlabel",Label.class);
							 checkedoutLabel.setVisible(true);
							 
							 Label messageLabel = (Label)getControl("cannotchangelabel",Label.class);
							 messageLabel.setVisible(false);
							 Label onlyOwnerError = (Label)getControl("onlyownerallowedtochange",Label.class);
							 onlyOwnerError.setVisible(false);
							 
						}else if(docObject.hasAttr(IDocsConstants.MSG_TEMPLATE_CODE) && (
								currentObjectTypeName.equalsIgnoreCase(IdocsConstants.PROJ_DOC_TYPE) == true 
								|| currentObjectTypeName.equalsIgnoreCase(IdocsConstants.INSTITUTION_DOC_TYPE) == true
								|| currentObjectTypeName.equalsIgnoreCase(IdocsConstants.COUNTRY_DOC_TYPE) == true)){
							String template_code = docObject.getString(IDocsConstants.MSG_TEMPLATE_CODE);
							boolean canChangeDocTypeInfo = false;
							boolean canChangeObjectName = false;
							if(template_code != null && template_code.trim().length() > 0){
								/** As template code is not null this is a Workflow/Template Document We
								 * should not change the DocType of workflow documents */
								canChangeDocTypeInfo = false;
								String strTemplateTitle = IdocsUtil.getTemplateTitle(getDfSession(), strObjectId);
								/** Check for NONWorkflow templates. We can allow user to change the object name of non
								 * workflow templates is its mentioned in the idocsproperties */
								if(strTemplateTitle !=null && strTemplateTitle.trim().length() > 0){
									canChangeDocTypeInfo = IdocsUtil.checkIfTokenPresent(IdocsUtil.getMessage("MSG_NONWORKFLOW_TEMPLATES"),strTemplateTitle, IdocsConstants.MSG_COMMA);
								}else{
									canChangeDocTypeInfo = true;
								}
							}else{
								/** If the document is not having template code it can be either
								 * 1. Imported Document
								 * 2. Scanning Document
								 * 3. Email Documents
								 * 
								 *  We can allow owner to edit the name  and doctype info of these kind of documents. */
								canChangeDocTypeInfo = true;
								canChangeObjectName = true;
							}
							
							if(canChangeDocTypeInfo){
								//Enable DocTYpe Panel
								failurepanel.setVisible(false);
						        successpanel.setVisible(true);
						        currentPanel = PANEL_SUCCESS;
						        Label presentFolderValue = (Label) getControl("presentfoldervalue", Label.class);
						        Label presentDoctypeValue = (Label) getControl("presentdoctypevalue", Label.class);
						        presentFolderValue.setLabel(docObject.getString(IDocsConstants.MSG_FOLDER_TITLE));
								presentDoctypeValue.setLabel(docObject.getString(IDocsConstants.MSG_DOC_SUBTYPE_NAME));					       
						        setupTypeList();
						        docInputName=docObject.getObjectName();
						        DfLogger.debug(this,"Document name : "+ docInputName,null,null);
						        Text textinput=(Text) getControl("objectnamevalue",Text.class);
						        textinput.setValue(docInputName);
								if(canChangeObjectName){
									// Enable Object Name Change Panel
									String user=getDfSession().getLoginUserName();
							        DfLogger.debug(this, "Author : "+user, null, null);
							        if(user.equals(docObject.getOwnerName())==false){
							        	textinput.setEnabled(false);
							        }						        	
								}else{
									textinput.setEnabled(false);
								}
							}else{
								DfLogger.debug(this, " :: onInit :: You cannot copy template documents in IFCDocs ", null, null);
								failurepanel.setVisible(true);
						        successpanel.setVisible(false);
						        currentPanel = PANEL_FAILURE;
						        Label checkedoutLabel = (Label)getControl("checkedoutlabel",Label.class);
								checkedoutLabel.setVisible(false);
								Label messageLabel = (Label)getControl("cannotchangelabel",Label.class);
								messageLabel.setVisible(true);	
								Label onlyOwnerError = (Label)getControl("onlyownerallowedtochange",Label.class);
								onlyOwnerError.setVisible(false);
							}
						}	
					}
		        }
	        }
	    } catch (DfException e) {
			DfLogger.error(this, ":: onInit:: Exception : " + e.getMessage(), null, e);
		}
    }   
	
	
	/**
     * This prepares the drop down list with allowed document sub type names.
     * @throws DfException
     */
    public void setupTypeList() throws DfException {
		try {
			TableResultSet typeResultSet = new TableResultSet(new String[] {"type_name", "label_text"});
			typeResultSet.add(new String[] {IDocsConstants.MSG_EMPTY_STRING, "Select"});
			DataDropDownList typeList = (DataDropDownList)getControl("docsubtypenamelist", DataDropDownList.class);
			//typeList.setValue(docObject.getTypeName());
			typeList.clearOptions();
			DfQuery query = new DfQuery();
			String typeListQry = m_nlsResourceBundleCreateDoc.getString("QUERY_SELECT_TYPE", LocaleService.getLocale());
			typeListQry = typeListQry.replaceFirst("''", "'" + folderCategory + "'");
			DfLogger.debug(this," :: setupTypeList: typeListQry : "+typeListQry,null,null);
			query.setDQL(typeListQry);
			IDfCollection collection = query.execute(getDfSession(), 0);
			while(collection.next()) {
			        String typeName = collection.getString("doc_type_code");
			        String typeLabel = collection.getString("doc_type_name");
			        typeResultSet.add(new String[] {typeName, typeLabel});
			}
			if(collection !=null)collection.close();
			typeList.getDataProvider().setScrollableResultSet(typeResultSet);
		} catch (Exception e) {
			DfLogger.error(this, ":: setupTypeList:: Exception : " + e.getMessage(), null, e);
		}
    }
    
    /**
	 * Method to populate the sub folder name during import and for documents that doesn't
	 * have doc sub type code.
	 * @param typeList
	 * @param args
	 * @throws DfException
	 */
    public void onSelectDocList(DataDropDownList typeList,ArgumentList args) throws DfException {
    	
		DfQuery query = new DfQuery();
		String subFolderQry = m_nlsResourceBundleCreateDoc.getString("QUERY_FOLDER_TITLE", LocaleService.getLocale());
    	subFolderQry = subFolderQry.replaceFirst("''", "'"+typeList.getValue()+"'");
    	subFolderQry = subFolderQry.replaceFirst("''", "'"+folderCategory+"'");
    	query.setDQL(subFolderQry);
    	IDfCollection dfCollection = query.execute(getDfSession(), 0);
    	if (dfCollection.next()) {
    		subFolderTitle = dfCollection.getString("subfolder_title");
    		docTypeName = dfCollection.getString("doc_type_name");
    	}
		if(dfCollection != null) dfCollection.close();
    	docTypeCode = typeList.getValue();
    	DfLogger.debug(this," :: onSelectDocList: docTypeCode : " + docTypeCode, null, null);
    	DfLogger.debug(this," :: onSelectDocList: subFolderTitle : " + subFolderTitle, null, null);
    	DfLogger.debug(this," :: onSelectDocList: docTypeName : " + docTypeName, null, null);
    	updateSubfolder();
    }
    
    /**
     * Updating the corresponding folder title to UI and object
     * 
     * @param subFolder - folder_title selected
     * @throws DfException
     */
    private void updateSubfolder() throws DfException {
		Label label = (Label)getControl("foldertitlevalue", Label.class);
    	label.setLabel(subFolderTitle);
    	DfLogger.debug(this," :: updateSubfolder: subFolderTitle : " + subFolderTitle, null, null);
    }
    
    /**
     * 
     */
    public boolean onCommitChanges() {
    	if(PANEL_SUCCESS.equalsIgnoreCase(currentPanel)) {
    		boolean isValid = getIsValid();
	    	try {
	    		DfLogger.debug(this," :: onCommitChanges:",null,null);
	    		if (isValid == false) {
	    			return false;
	    		} else {
	    			boolean changedStatus=false;
	    			
	    			if (docObject.isImmutable() == false) {
	    				String ObjectName=docObject.getObjectName();
	    				if(docTypeCode!=null  && subFolderTitle!=null  
	    						&& docTypeCode.trim().length() > 0 && subFolderTitle.trim().length() > 0 && docTypeName != null && docTypeName.trim().length() > 0){
	    					docObject.setString("doc_subtype_code", docTypeCode);
		    				docObject.setString("folder_title", subFolderTitle);
		    				docObject.setString("doc_subtype_nme", docTypeName);
		    				IdocsUtil.auditIDocsActivity(MSG_UPDATED_DOCUMENT_TYPE,docObject.getObjectId().getId(),getDfSession());
	    					changedStatus=true;
						}
	    				Text textinput=(Text) getControl("objectnamevalue",Text.class);		    					
				  		docInputName=textinput.getValue();
	    				if(docInputName != null && docInputName.length() >0 && !ObjectName.equalsIgnoreCase(docInputName)){
	    					docObject.setString("object_name", docInputName);
	    					changedStatus=true;
	    				}
	    				
	    				if(changedStatus){
	    					DfLogger.debug(this,"Document new name : "+ docInputName,null,null);
	 	    			    docObject.save();	
	    				}else{
	    					DfLogger.debug(this," :: onCommitChanges: Not saving Object ", null, null);
	    				}    				    				
	    			}else {
	    				DfLogger.debug(this," :: onCommitChanges: Previous Version Object", null, null);
	    			}
	    		}    		
			} catch (DfException e) {
				DfLogger.error(this, ":: onCommitChanges:: Exception : " + e.getMessage(), null, e);
			}
    	}
    	return super.onCommitChanges();    	
    }
}
