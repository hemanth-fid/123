/***************************************************************************
 * State Farm
 * Version Template: 2012
 *
 * File Name: InvokeExportController.java
 *
 * Version     ChgDate          Author           Comments
 * ________   __________       ________         ___________
 * 1.0        06/01/2013        t7p9          Initial Creation 
 *
 ***************************************************************************/

package sf.application.custcomm.ccs.main;

import static java.util.concurrent.TimeUnit.SECONDS;

import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import sf.application.custcomm.ccs.constants.CleanUpConstants;
import sf.application.custcomm.ccs.core.PurgeDataWriterService;
import sf.application.custcomm.ccs.exceptions.CleanUpServiceException;
import sf.application.custcomm.ccs.util.CleanUpHelper;
import sf.application.custcomm.ccs.util.FileOperationUtils;

import com.documentum.fc.common.DfLogger;

/**
 * <i> Invoke WorkFlowTimer Services </i> class provides the functionality to
 * acquire and complete the timer activities for the scheduled time.
 * 
 */

public final class InvokePurgeDataWriterServices {

	/**
	 * private Constructor
	 */

	private InvokePurgeDataWriterServices() {

	}

	/**
	 * It's a main method to invoke the WorkFlowTimer Services.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		if (DfLogger.isTraceEnabled(InvokePurgeDataWriterServices.class)) {
			DfLogger.trace(InvokePurgeDataWriterServices.class,
					"Create Files Services main() entry", null, null);
		}

		try {

			// cleanup existing log files

			performTask();
		} catch (CleanUpServiceException wfTimerServiceException) {

			DfLogger.error(InvokePurgeDataWriterServices.class,
					wfTimerServiceException.getMessage(), null,
					wfTimerServiceException);
		}

		if (DfLogger.isTraceEnabled(InvokePurgeDataWriterServices.class)) {
			DfLogger.trace(InvokePurgeDataWriterServices.class,
					"Workflow Timer Services main() exit", null, null);
		}
	}

	/**
	 * It executes the functionality of WorkFlow Timer Services by initiating
	 * the scheduler.
	 * 
	 * @throws CleanUpServiceException
	 *             Custom Workflow Service Exception
	 * 
	 */
	private static void performTask() throws CleanUpServiceException {

		if (DfLogger.isTraceEnabled(InvokePurgeDataWriterServices.class)) {
			DfLogger.trace(InvokePurgeDataWriterServices.class,
					"performTask() entry", null, null);
		}
		Map<String, String> params = CleanUpHelper.initializeParameters();
		FileOperationUtils.createFolderstructure(params);
		startPurgeDataWriterServices(params);
		if (DfLogger.isTraceEnabled(InvokePurgeDataWriterServices.class)) {
			DfLogger.trace(InvokePurgeDataWriterServices.class,
					"performTask() exit", null, null);
		}
	}

	/**
	 * It create's the scheduler object and invokes workflow timer services
	 * 
	 * @param params
	 */
	private static void startPurgeDataWriterServices(Map<String, String> params) {

		if (DfLogger.isTraceEnabled(InvokePurgeDataWriterServices.class)) {
			DfLogger.trace(InvokePurgeDataWriterServices.class,
					"startPurgeDataWriterServices() entry", null, null);
		}
		ScheduledExecutorService purgeDataWriterServiceScheduler = Executors
				.newScheduledThreadPool(1);
		purgeDataWriterServiceScheduler.schedule(new PurgeDataWriterService(
				params, purgeDataWriterServiceScheduler),
				CleanUpConstants.NUMBER_ONE, SECONDS);
		if (DfLogger.isTraceEnabled(InvokePurgeDataWriterServices.class)) {
			DfLogger.trace(InvokePurgeDataWriterServices.class,
					"startPurgeDataWriterServices() exit", null, null);
		}
	}

}
