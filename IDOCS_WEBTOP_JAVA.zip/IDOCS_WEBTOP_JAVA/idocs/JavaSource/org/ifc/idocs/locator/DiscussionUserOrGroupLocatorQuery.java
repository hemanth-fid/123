/**
* This customized class is used to generate query for project specific users. 
* This query is used to display list of users in the user / group location.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Parag Doshi			11/02/2010		1.0				created
* #######################################################################################################
*/
package org.ifc.idocs.locator;

import java.util.Properties;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.discussion.TopicPageView;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.DfAuthenticationException;
import com.documentum.fc.client.DfIdentityException;
import com.documentum.fc.client.DfPrincipalException;
import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfGroup;
import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfUser;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfUtil;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.query.ExpressionSet;
import com.documentum.web.form.query.ParsedExpression;
import com.documentum.web.formext.docbase.ServerUtil;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import com.documentum.webcomponent.library.locator.LocatorItemResultSet;
import com.documentum.webcomponent.library.locator.LocatorQuery;

public class DiscussionUserOrGroupLocatorQuery extends LocatorQuery
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String COC_GROUP_NAMES = ",'COC Members','COC Assistants','IPS-COCOthers-PDS-Concept'";
	private static Properties idocsProperties = new Properties();

	static class UserOrGroupLocatorItemResultSet extends LocatorItemResultSet
    {
        /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		protected Object getObjectAttributeValue(IDfPersistentObject iObject, String strAttrName)
        {
            Object objVal = null;
            try
            {
                if(iObject instanceof IDfUser)
                {
                    IDfUser iuser = (IDfUser)iObject;
                    if(strAttrName.equals("object_name"))
                    {
                        objVal = iuser.getUserName();
                    } else
                    if(strAttrName.equals("address_"))
                    {
                        objVal = iuser.getUserAddress();
                    } else
                    if(strAttrName.equals(IDocsConstants.MSG_R_OBJECT_TYPE))
                    {
                        objVal = "dm_user";
                    } else
                    if(strAttrName.equals("owner_name"))
                    {
                        objVal = "";
                    } else
                    if(strAttrName.equals("workflow_disabled"))
                    {
                        objVal = String.valueOf(iuser.isWorkflowDisabled());
                    } else
                    {
                        objVal = super.getObjectAttributeValue(iObject, strAttrName);
                    }
                } else
                if(iObject instanceof IDfGroup)
                {
                    IDfGroup igroup = (IDfGroup)iObject;
                    if(strAttrName.equals("object_name"))
                    {
                        objVal = igroup.getGroupName();
                    } else
                    if(strAttrName.equals("address_"))
                    {
                        objVal = igroup.getGroupAddress();
                    } else
                    if(strAttrName.equals(IDocsConstants.MSG_R_OBJECT_TYPE))
                    {
                        objVal = "dm_group";
                    } else
                    if(strAttrName.equals("user_os_name"))
                    {
                        objVal = "";
                    } else
                    if(strAttrName.equals("workflow_disabled"))
                    {
                        objVal = "";
                    } else
                    {
                        objVal = super.getObjectAttributeValue(iObject, strAttrName);
                    }
                }
            }
            catch(DfException e)
            {
                throw new WrapperRuntimeException("Failed to get folder path", e);
            }
            return objVal;
        }

        public UserOrGroupLocatorItemResultSet(String strType)
        {
            super(strType, new String[] {
                "object_name", IDocsConstants.MSG_R_OBJECT_TYPE, "address_", "owner_name", "user_os_name", "workflow_disabled"
            });
        }

        protected UserOrGroupLocatorItemResultSet(String strType, String strExtraColumns[])
        {
            super(strType, strExtraColumns);
        }
    }

    private boolean m_fShowPrivateGroups;
    private boolean m_fShowWorkQueueGroups;
    protected boolean m_fIs53Docbase;
    private boolean m_showUnlistedUsers;
    private String m_projectId;
    private String m_type;
    private String m_documentID;

    public DiscussionUserOrGroupLocatorQuery()
    {
        super("a");
        
        try {
	        idocsProperties.load(DiscussionUserOrGroupLocatorQuery.class.getResourceAsStream(IdocsConstants.IDOCS_PROPERTY_FILE));
        }catch (Exception e) {
        	DfLogger.info(this, "DiscussionUserOrGroupLocatorQuery :: Exception"+e.getMessage(), null, null);
		}
        m_fShowPrivateGroups = false;
        m_fShowWorkQueueGroups = false;
        m_fIs53Docbase = false;
        m_showUnlistedUsers = false;
        setViewDocbaseType("dm_user");
        m_projectId=null;
        m_fIs53Docbase = ServerUtil.compareDocbaseVersion(5, 3);
    }

    /*
     * Set Project ID to m_projectId
     */
    public void setProjectId(String project_id)
    {
    	m_projectId=project_id;
    	DfLogger.info(this,"Before querying..m_projectId : " + m_projectId,null,null);
    }
    
    public void setType(String type)
    {
    	m_type = type;
    	DfLogger.info(this,"Before querying..m_type : " + m_type,null,null);
    }
    
    public void setDocID(String strObjectID)
    {
    	m_documentID = strObjectID;
    	DfLogger.info(this,"Before querying..m_documentID : " + m_documentID,null,null);
    }
    public void setPrivateGroupVisible(boolean fShowPrivateGroups)
    {
        m_fShowPrivateGroups = fShowPrivateGroups;
    }

    public boolean isPrivateGroupVisible()
    {
        return m_fShowPrivateGroups;
    }

    public void setWorkQueueGroupVisible(boolean fShowWorkQueueGroups)
    {
        m_fShowWorkQueueGroups = fShowWorkQueueGroups;
    }

    public boolean isWorkQueueGroupVisible()
    {
        return m_fShowWorkQueueGroups;
    }

    public void setShowUnlistedUsers(boolean showUnlistedUsers)
    {
        m_showUnlistedUsers = showUnlistedUsers;
    }

    public boolean getShowUnlistedUsers()
    {
        return m_showUnlistedUsers;
    }

    public LocatorItemResultSet createItemResultSet()
    {
        return new UserOrGroupLocatorItemResultSet(getSelectableDocbaseType());
    }

    protected String getRootViewStatement()
    {
    	StringBuffer bufStatement = new StringBuffer(512);
		try {
			SessionManagerHttpBinding httpBinding = new SessionManagerHttpBinding();
			IDfSessionManager sessionManager = httpBinding.getSessionManager();
			IDfSession dfSession = sessionManager.getSession(httpBinding.getCurrentDocbase());
			boolean fUnion = false;
			DfLogger.debug(this,"Before querying..m_projectId : " + m_projectId,null,null);
			DfLogger.debug(this,"Before querying..m_type" +m_type ,null,null);
			
			//			if(!isTypeExcluded("dm_group")) //ALWAYS ADD GRUOP
			if(true)
			{
			    fUnion = true;
			    setFromClause("dm_group a");
			    ExpressionSet predicate = new ExpressionSet();
			    if(!isPrivateGroupVisible())
			    {
			        predicate.addExpression("AND", new ParsedExpression("(a.is_private=0 or a.owner_name=user)"));
			    }
			    if(m_fIs53Docbase)
			    {
			        predicate.addExpression("AND", new ParsedExpression("(a.group_native_room_id = '0000000000000000')"));
			        if(!isWorkQueueGroupVisible())
			        {
			            predicate.addExpression("AND", new ParsedExpression("(a.group_class IS NULL OR a.group_class!='queue')"));
			        }
			        if(!getShowUnlistedUsers())
			        {
			            predicate.addExpression("AND", new ParsedExpression("(a.group_name!='dce_hidden_users')"));
			        }
			    }
			    if(predicate.getExpressionSet().size() == 0)
			    {
			        setBaseViewExpression(null);
			    } else
			    {
			        setBaseViewExpression(predicate);
			    }
			    processNameStartsWith("a.group_name");
			    setGroupSelectAttributes();
			    bufStatement.append("SELECT").append(" ").append(getSelectForPermitSnippet()).append(" ").append(getSelectType()).append(" ");
			    bufStatement.append(prepareSelectValuesSnippet());
			    bufStatement.append(" ").append("FROM").append(" ");
			    bufStatement.append(getFromClause());
			    bufStatement.append(" ");
			    bufStatement.append(" WHERE ((a.is_private=0 or a.owner_name=user) AND (a.group_native_room_id = '0000000000000000') AND (a.group_class IS NULL OR a.group_class!='queue') AND (a.group_name!='dce_hidden_users')) ");
			    /** Add COC Members */
			    if (m_type != null && (m_type.equals(IDocsConstants.MSG_EMPTY_STRING) == false) && m_type.equals(TopicPageView.KEY_PROJECT))
			    {
			    	bufStatement.append(" AND a.description IN (");
			    	String projTeamMemQry = idocsProperties.getProperty("QRY_PROJ_TEAM_MEMBER_DISCUSSION").replaceFirst("''","'"+m_projectId+"'");
			    	DfLogger.info(this," :: getRootViewStatement: projTeamMemQry:  " + projTeamMemQry,null,null);
			    	String projTeamMemQryValues = getProjTeamMembers(dfSession, projTeamMemQry);
			    	DfLogger.info(this, ":: getRootViewStatement: projTeamMemQryValues: " + projTeamMemQryValues, null, null);
			    	bufStatement.append(projTeamMemQryValues);
			    	bufStatement.append(COC_GROUP_NAMES+")");
			    } else if (m_type != null && (m_type.equals(IDocsConstants.MSG_EMPTY_STRING) == false) && m_type.equals(TopicPageView.KEY_INSTITUTION) )
			    {
			    	DfLogger.info(this,":: getRootViewStatement:: Institution team members...",null,null);
			    	bufStatement.append(" AND a.description IN (");
			    	String strInstitutionNumber = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(dfSession,  m_documentID, IdocsConstants.MSG_INSTITUTION_NBR, IDocsConstants.MSG_IDOCS_INSTITUTION_DOC);
			    	String frameClientProjects = idocsProperties.getProperty("QRY_CLIE_INSTI_PROJECTS").replaceFirst("''", strInstitutionNumber);
			    	String projTeamMemQry = idocsProperties.getProperty("QRY_PROJ_TEAM_MEMBER_MULTI_DISCUSSION").replaceFirst("''", frameClientProjects);
			    	DfLogger.info(this," :: getRootViewStatement: projTeamMemMultiQry:  " + projTeamMemQry,null,null);
			    	String projTeamMembers = getProjTeamMembers(dfSession, projTeamMemQry);
					bufStatement.append(projTeamMembers);
					bufStatement.append(COC_GROUP_NAMES+")");
			    }else if(m_type != null && (m_type.equals(IDocsConstants.MSG_EMPTY_STRING) == false) && m_type.equals(TopicPageView.KEY_COUNTRY))
			    {
			    	bufStatement.append(" AND a.group_name IN ('"+idocsProperties.getProperty("MSG_IFC_CORE_GROUP")+"'"+COC_GROUP_NAMES+")");
			    } else{	        	
					DfLogger.info(this,"getRootViewStatement:: Document doesnt belongs to any above types" ,null,null);
				}
			    String appendQry = getPresetEntriesAsQueryString();
			    DfLogger.info(this, ":: getRootViewStatement::appendQry : " + appendQry, null, null);
			    if(appendQry != null && appendQry.length() > 0)
			    {
			        bufStatement.append(" ");
			        bufStatement.append("AND");
			        bufStatement.append(" ");
			        bufStatement.append("a.group_name in");
			        bufStatement.append(" ");
			        bufStatement.append(appendQry);
			    }
			}
			if(getViewDocbaseType().equals("dm_user"))
			{
				DfLogger.info(this, ":: getRootViewStatement::getViewDocbaseType : " + getViewDocbaseType(), null, null);
			    setFromClause("dm_user a");
			    setBaseViewExpression(new ParsedExpression("a.r_is_group=0"));
			    processNameStartsWith("a.user_name");
			    if(fUnion)
			    {
			        bufStatement.append(" union ");
			    }
			    setUserSelectAttributes();
			    bufStatement.append("SELECT").append(" ").append(getSelectForPermitSnippet()).append(" ").append(getSelectType()).append(" ");
			    bufStatement.append(prepareSelectValuesSnippet());
			    bufStatement.append(" ").append("FROM").append(" ");
			    bufStatement.append(getFromClause());
			    bufStatement.append(" ");
			    bufStatement.append(prepareWhereClauseSnippet());
			    DfLogger.info(this, ":: getRootViewStatement::prepareWhereClauseSnippet 2 : " + prepareWhereClauseSnippet(), null, null);
			    
			    // Query is updated to get proper list of users custom
			    // Fetch users from table
			    if (m_type != null && (m_type.equals(IDocsConstants.MSG_EMPTY_STRING) == false) && m_type.equals(TopicPageView.KEY_PROJECT))
			    {
			    	DfLogger.info(this," getRootViewStatement:: Project team members...",null,null); 
			    	bufStatement.append(" AND a.user_name IN (");
			    	String projTeamMemQry = idocsProperties.getProperty("QRY_PROJ_TEAM_MEMBER_DISCUSSION").replaceFirst("''", "'" + m_projectId + "'");
			    	String projTeamMembers = getProjTeamMembers(dfSession, projTeamMemQry);
					bufStatement.append(projTeamMembers);
					bufStatement.append(" )");
					
			    }
			    else if (m_type != null && (m_type.equals(IDocsConstants.MSG_EMPTY_STRING) == false) && m_type.equals(TopicPageView.KEY_INSTITUTION) )
			    {
			    	DfLogger.info(this,":: getRootViewStatement:: Institution Project team members...",null,null);
			    	bufStatement.append(" AND a.user_name IN (");
			    	String strInstitutionNumber = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(dfSession,  m_documentID, IdocsConstants.MSG_INSTITUTION_NBR, IDocsConstants.MSG_IDOCS_INSTITUTION_DOC);
			    	String frameClientProjects = idocsProperties.getProperty("QRY_CLIE_INSTI_PROJECTS").replaceFirst("''", strInstitutionNumber);
			    	String projTeamMemQry = idocsProperties.getProperty("QRY_PROJ_TEAM_MEMBER_MULTI_DISCUSSION").replaceFirst("''", frameClientProjects);
			    	String projTeamMembers = getProjTeamMembers(dfSession, projTeamMemQry);
					bufStatement.append(projTeamMembers);
					bufStatement.append(" )");			    	
			    }
			    else if(m_type != null && (m_type.equals(IDocsConstants.MSG_EMPTY_STRING) == false) && m_type.equals(TopicPageView.KEY_COUNTRY))
			    {
			    	DfLogger.info(this,":: getRootViewStatement:: Country Project team members...",null,null);
			    	//bufStatement.append(" AND a.user_name IN (select i_all_users_names from dm_group where group_name='"+idocsProperties.getProperty("MSG_IFC_CORE_GROUP")+"')");
			    	bufStatement.append(" AND a.user_name IN (");
			    	String coreGrpMembersQry = "select i_all_users_names from dm_group where group_name='" + idocsProperties.getProperty("MSG_IFC_CORE_GROUP") + "'";
//			    	String coreGrpMembers = getGroupMembers(coreGrpMembersQry, dfSession);
//			    	DfLogger.info(this,":: getRootViewStatement:: coreGrpMembers: " + coreGrpMembers, null, null);
			    	bufStatement.append(coreGrpMembersQry);
			    	bufStatement.append(" )");
			    }

            String appendQry = getPresetEntriesAsQueryString();
            DfLogger.info(this,":: getRootViewStatement:: appendQry: " + appendQry, null, null);
            if(appendQry != null && appendQry.length() > 0)
            {
                bufStatement.append(" ");
                bufStatement.append("AND");
                bufStatement.append(" ");
                bufStatement.append("a.user_name IN (Select i_all_users_names from dm_group where group_name in ");
                bufStatement.append(appendQry);
                bufStatement.append(")");
            }
//            if(!getShowUnlistedUsers())
//            {
//                //bufStatement.append(" AND  a.user_name NOT IN (Select i_all_users_names from dm_group where group_name='dce_hidden_users')");
//            	bufStatement.append(" AND  a.user_name NOT IN (");
//            	String dceHiddenUsersQry = "select i_all_users_names from dm_group where group_name='dce_hidden_users'";
//            	String dceHiddenUsers = getGroupMembers(dceHiddenUsersQry, dfSession);
//		    	DfLogger.info(this,":: getRootViewStatement:: dceHiddenUsers: " + dceHiddenUsers, null, null);
//		    	bufStatement.append(dceHiddenUsers);
//		    	bufStatement.append(" )");
//            	
//            }
        }
		DfLogger.info(this,":: getRootViewStatement:: Debug 1", null, null);	
        removeAllOrderByAttributes();
        addOrderByAttribute("idunion", "ASC");
        addOrderByAttribute("objname", "ASC");
        bufStatement.append(" ");
        bufStatement.append(prepareOrderBySnippet());
        DfLogger.info(this,":: getRootViewStatement:: Debug 2", null, null);
       if((null != m_type && !"".equals(m_type))&& m_type.equals("country"))
        {
    	   bufStatement.append(" ENABLE (ROW_BASED)");
        }
        
        DfLogger.info(this,"DiscussionUserOrGroupLocatorQuery :: getRootViewStatement :: Query : "+bufStatement.toString(),null,null);

			
		} catch (DfIdentityException e) {
			DfLogger.error(this," :: getRootViewStatement: projTeamMemQryValues:: DfIdentityException  " + e.getMessage(),null,null);
		} catch (DfAuthenticationException e) {
			DfLogger.error(this," :: getRootViewStatement: projTeamMemQryValues:: DfAuthenticationException  " + e.getMessage(),null,null);
		} catch (DfPrincipalException e) {
			DfLogger.error(this," :: getRootViewStatement: projTeamMemQryValues:: DfPrincipalException  " + e.getMessage(),null,null);
		} catch (DfServiceException e) {
			DfLogger.error(this," :: getRootViewStatement: projTeamMemQryValues:: DfServiceException  " + e.getMessage(),null,null);
		} catch (DfException e) {
			DfLogger.error(this," :: getRootViewStatement: projTeamMemQryValues:: DfException  " + e.getMessage(),null,null);
		}
		return bufStatement.toString();
    }

    /**
     * 
     * @param grpMembersQry
     * @param dfSession
     * @return
     */
    private String getGroupMembers(String grpMembersQry,
			IDfSession dfSession) {
    	
		String groupMembers = "'";
		IDfCollection grpMembersQryColl = null;
		DfLogger.info(this," :: getGroupMembers: grpMembersQry:  " + grpMembersQry,null,null);
		try {
			grpMembersQryColl = IdocsUtil.executeQuery(dfSession, grpMembersQry, IDfQuery.DF_READ_QUERY);
			while (grpMembersQryColl.next()) {
				String userOfGroup = IdocsUtil.handleSingleQuote(grpMembersQryColl.getString("i_all_users_names"));
				groupMembers = groupMembers + userOfGroup +"','";
			}
			if (groupMembers.length() > 1) {
				groupMembers = groupMembers.substring(0, (groupMembers.length()-2));
			} else {
				groupMembers = groupMembers + "'";
			}
		} catch (DfException e) {
			DfLogger.error(this, " :: getGroupMembers:: Exception  " + e.getMessage(), null, null);
		} finally {
			if (grpMembersQryColl!= null){ 
				try {
					grpMembersQryColl.close();
				} catch (DfException e) {
					DfLogger.error(this, " :: getGroupMembers:: Exception :: Unable to close collection" + e.getMessage(), null, null);
				}
			}			
		}
		DfLogger.info(this," :: getGroupMembers: groupMembers:  " + groupMembers,null,null);
		return groupMembers;
	}

private String getProjTeamMembers(IDfSession dfSession,	String projTeamMemQry) {
		
		String projTeamMemQryValues="'";
		IDfCollection projTeamMemQryColl = null;
		try {
			projTeamMemQryColl = IdocsUtil.executeQuery(dfSession, projTeamMemQry, IDfQuery.DF_READ_QUERY);
			while (projTeamMemQryColl.next()) {
				projTeamMemQryValues = projTeamMemQryValues + IdocsUtil.handleSingleQuote(projTeamMemQryColl.getString("accessor_nme"))+"','";
			}
			if (projTeamMemQryValues.length() > 1) {
				projTeamMemQryValues = projTeamMemQryValues.substring(0, (projTeamMemQryValues.length()-2));
			} else {
				projTeamMemQryValues = projTeamMemQryValues + "'";
			}
		} catch (Exception e) {
			DfLogger.error(this," :: getProjTeamMembers :: Exception : "+e.getMessage(),null,null);
		} finally {
			try {
				if (projTeamMemQryColl!= null) projTeamMemQryColl.close();
			} catch (DfException e) {
				DfLogger.error(this," :: getProjTeamMembers :: Exception : Unable to close collection" + e.getMessage(), null, null);
			}
		}
		DfLogger.info(this," :: getProjTeamMembers: projTeamMemQryValues:  " + projTeamMemQryValues,null,null);
		return projTeamMemQryValues;
	}

	private String getProjTeamMembers(IDfSession dfSession, String projTeamMemQry, String projLDAPTeamMemQry) {
    	String projTeamMemQryValues = "'";
    	String userName = "";
    	try {
			
			DfLogger.info(this," :: getRootViewStatement: projTeamMemQry:  " + projTeamMemQry,null,null);
			
				IDfCollection projTeamMemQryColl = IdocsUtil.executeQuery(dfSession, projTeamMemQry, IDfQuery.DF_READ_QUERY);
				
				while (projTeamMemQryColl.next()) {
					userName  = IdocsUtil.handleSingleQuote(projTeamMemQryColl.getString("accessor_nme"));
					projTeamMemQryValues = projTeamMemQryValues + userName +"','";
				}
				if (projTeamMemQryValues.length() > 1) {
					projTeamMemQryValues = projTeamMemQryValues.substring(0, (projTeamMemQryValues.length()-2));
					
					
					projLDAPTeamMemQry = projLDAPTeamMemQry.replaceFirst("''",projTeamMemQryValues);
					DfLogger.info(this," :: getRootViewStatement: projTeamLDAPMemQry:  " + projLDAPTeamMemQry,null,null);
					IDfCollection projLDAPTeamMemQryColl = IdocsUtil.executeQuery(dfSession, projLDAPTeamMemQry, IDfQuery.DF_READ_QUERY);
					String projLDAPTeamMemQryValues = "'";
					while (projLDAPTeamMemQryColl.next()) {
						userName = IdocsUtil.handleSingleQuote(projLDAPTeamMemQryColl.getString("i_all_users_names"));
						projLDAPTeamMemQryValues = projLDAPTeamMemQryValues + userName +"','";
					}
					if (projLDAPTeamMemQryValues.length() > 1) {
						projLDAPTeamMemQryValues = projLDAPTeamMemQryValues.substring(0, (projLDAPTeamMemQryValues.length()-2));
					} else {
						projLDAPTeamMemQryValues = projLDAPTeamMemQryValues + "'";
					}

					DfLogger.info(this," :: getRootViewStatement: projTeamMemQryValues:  " + projLDAPTeamMemQryValues,null,null);
					if (projLDAPTeamMemQryColl!= null) projLDAPTeamMemQryColl.close();
					
					projTeamMemQryValues = projTeamMemQryValues +IdocsConstants.MSG_COMMA+ projLDAPTeamMemQryValues;
					
				} else {
					projTeamMemQryValues = projTeamMemQryValues + "'";
				}

				DfLogger.info(this," :: getRootViewStatement: projTeamMemQryValues:  " + projTeamMemQryValues,null,null);
				if (projTeamMemQryColl!= null) projTeamMemQryColl.close();
		} catch (DfException e) {
			DfLogger.error(this," :: getRootViewStatement: projTeamMemQryValues:: Exception  " + e.getMessage(),null,null);
		}
		return projTeamMemQryValues;
	}

    protected String getGroupNameExpression(String fromGroupSymbol)
    {
        StringBuffer rv = new StringBuffer();
        if(fromGroupSymbol != null && fromGroupSymbol.length() != 0)
        {
            rv.append(fromGroupSymbol);
            rv.append(".");
        }
        rv.append((new StringBuilder()).append("group_name = '").append(getGroupName()).append("'").toString());
        return rv.toString();
    }

    protected String getGroupBaseExpression()
    {
        return (new StringBuilder()).append("exists (select * from dm_group b where ").append(getGroupNameExpression("b")).append(" and any b.groups_names = a.group_name)").toString();
    }

    protected String getUserBaseExpression()
    {
        return (new StringBuilder()).append("exists (select * from dm_group b where ").append(getGroupNameExpression("b")).append(" and any b.users_names = a.user_name) ").toString();
    }

    protected String getContainerViewStatement()
    {
        boolean fUnion = false;
        StringBuffer bufStatement = new StringBuffer(512);
        if(!isTypeExcluded("dm_group"))
        {
            fUnion = true;
            setFromClause("dm_group a");
            String strBaseExpression = "";
            if(!isPrivateGroupVisible())
            {
                strBaseExpression = "(a.is_private=0 or a.owner_name=user) and ";
            }
            if(m_fIs53Docbase && !isWorkQueueGroupVisible())
            {
                strBaseExpression = (new StringBuilder()).append(strBaseExpression).append("(a.group_class IS NULL OR a.group_class!='queue') and ").toString();
            }
            strBaseExpression = (new StringBuilder()).append(strBaseExpression).append(getGroupBaseExpression()).toString();
            setBaseViewExpression(new ParsedExpression(strBaseExpression));
            processNameStartsWith("a.group_name");
            setGroupSelectAttributes();
            bufStatement.append("SELECT").append(" ").append(getSelectForPermitSnippet()).append(" ").append(getSelectType()).append(" ");
            bufStatement.append(prepareSelectValuesSnippet());
            bufStatement.append(" ").append("FROM").append(" ");
            bufStatement.append(getFromClause());
            bufStatement.append(" ");
            bufStatement.append(prepareWhereClauseSnippet());
        }
        if(getViewDocbaseType().equals("dm_user"))
        {
            setFromClause("dm_user a");
            String strBaseExpression = "";
            if(!isPrivateGroupVisible())
            {
                strBaseExpression = "a.r_is_group=0 and ";
            }
            strBaseExpression = (new StringBuilder()).append(strBaseExpression).append(getUserBaseExpression()).toString();
            setBaseViewExpression(new ParsedExpression(strBaseExpression));
            processNameStartsWith("a.user_name");
            if(fUnion)
            {
                bufStatement.append(" union ");
            }
            setUserSelectAttributes();
            bufStatement.append("SELECT").append(" ").append(getSelectForPermitSnippet()).append(" ").append(getSelectType()).append(" ");
            bufStatement.append(prepareSelectValuesSnippet());
            bufStatement.append(" ").append("FROM").append(" ");
            bufStatement.append(getFromClause());
            bufStatement.append(" ");
            bufStatement.append(prepareWhereClauseSnippet());
        }
        removeAllOrderByAttributes();
        addOrderByAttribute("idunion", "ASC");
        addOrderByAttribute("objname", "ASC");
        bufStatement.append(" ");
        bufStatement.append(prepareOrderBySnippet());
        DfLogger.debug(this,"Query for User or Group 2 : "+bufStatement.toString(),null,null);
        return bufStatement.toString();
    }

    protected String getFlatListViewStatement()
    {
        return getRootViewStatement();
    }

    protected String getGroupName()
    {
        String strGroup = m_strFolderPath;
        int iSlash = m_strFolderPath.lastIndexOf('/');
        if(iSlash >= 0)
        {
            strGroup = m_strFolderPath.substring(iSlash + 1);
        }
        return DfUtil.escapeQuotedString(strGroup);
    }

    protected void setGroupSelectAttributes()
    {
        addSelectValue("1", "idunion");
        addSelectValue("upper(a.group_name)", "objname");
        addSelectValue("a.group_name", "object_name");
        addSelectValue("a.group_address", "address_");
        addSelectValue("a.description", null);
        addSelectValue("a.r_modify_date", null);
        addSelectValue("a.r_object_id", null);
        addSelectValue("'dm_group'", IDocsConstants.MSG_R_OBJECT_TYPE);
        addSelectValue("''", "user_os_name");
        addSelectValue("a.owner_name", "owner_name");
        addSelectValue("-1", "workflow_disabled");
        if(!isContainerSelectable())
        {
            addSelectValue("''", "selectable");
        } else
        {
            addSelectValue("'y'", "selectable");
        }
        if(isFlatListEnabled())
        {
            addSelectValue("''", "navigatable");
            addSelectValue("'y'", "notnavigatable");
        } else
        {
            addSelectValue("'y'", "navigatable");
            addSelectValue("''", "notnavigatable");
        }
    }

    protected void setUserSelectAttributes()
    {
        addSelectValue("2", "idunion");
        addSelectValue("upper(a.user_name)", "objname");
        addSelectValue("a.user_name", "object_name");
        addSelectValue("a.user_address", "address_");
        addSelectValue("a.description", null);
        addSelectValue("a.r_modify_date", null);
        addSelectValue("a.r_object_id", null);
        addSelectValue("'dm_user'", IDocsConstants.MSG_R_OBJECT_TYPE);
        addSelectValue("a.user_os_name", "user_os_name");
        addSelectValue("''", "owner_name");
        addSelectValue("a.workflow_disabled", "workflow_disabled");
        addSelectValue("'y'", "selectable");
        addSelectValue("''", "navigatable");
        addSelectValue("'y'", "notnavigatable");
    }
}
