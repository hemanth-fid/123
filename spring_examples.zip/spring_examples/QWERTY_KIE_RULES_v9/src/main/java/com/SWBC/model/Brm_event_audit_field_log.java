package com.SWBC.model;



//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.Table;

import org.springframework.stereotype.Service;

//@Entity
//@Service("Brm_event_audit_field_log")
//@Table(name = "brm_event_audit_field_log")
public class Brm_event_audit_field_log {
	
	
//	@Id
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
//	private int id;
//	private int event_id;
//	private String field_name;
//	private String field_value_before;
//	private String field_value_after;
//	
//	public int getId() {
//		return id;
//	}
//	public void setId(int id) {
//		this.id = id;
//	}
//	public int getEvent_id() {
//		return event_id;
//	}
//	public void setEvent_id(int event_id) {
//		this.event_id = event_id;
//	}
//	public String getField_name() {
//		return field_name;
//	}
//	public void setField_name(String field_name) {
//		this.field_name = field_name;
//	}
//	public String getField_value_before() {
//		return field_value_before;
//	}
//	public void setField_value_before(String field_value_before) {
//		this.field_value_before = field_value_before;
//	}
//	public String getField_value_after() {
//		return field_value_after;
//	}
//	public void setField_value_after(String field_value_after) {
//		this.field_value_after = field_value_after;
//	}
//	
//	
	

}
