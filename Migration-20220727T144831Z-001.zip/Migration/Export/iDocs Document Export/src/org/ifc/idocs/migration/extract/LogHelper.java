package org.ifc.idocs.migration.extract;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.ifc.idocs.migration.ExtractDocuments;
import org.ifc.idocs.migration.WorkflowAuditTrial;
import org.ifc.idocs.migration.common.AppConfig;

/**
 * @author SPankajamsadanan
 *
 */
public class LogHelper extends ExtractDocuments{

	private static AppConfig config = AppConfig.getInstance();
	public static Logger logger = null;
	public static Map<String,Logger> loggerMap = new HashMap<String,Logger>();
	
	
	/**
	 * getLogger method creates new logger object and keeps it in session. 
	 * If logger object already exists in session then returns that object
	 * @param object
	 * @return Logger
	 */
	public static Logger getLogger(Object object){
		try{
			if(loggerMap.get("loggerMap") == null){ // if no logger exists in the session
				SimpleFormatter simpFormatter = new SimpleFormatter();				
				utilityId = WorkflowAuditTrial.workflowMap.get("utilityId");
				String dirPath = config.getString("export.logPath");
				
				File fileDir = new File(dirPath);
				if(!fileDir.exists()){
					fileDir.mkdirs();
					String fileName =  dirPath+ utilityId + ".log";
					FileHandler fileHandler = new FileHandler(fileName, 10240000, 10, false);
					fileHandler.setLevel(Level.WARNING);
					fileHandler.setFormatter(simpFormatter);
					logger = Logger.getLogger(object.getClass().getName());
					logger.setLevel(Level.WARNING);//only warnings will be printed in log file
					logger.addHandler(fileHandler);
					loggerMap.put("loggerMap",logger);
				}else{
					String fileName =  dirPath+ utilityId + ".log";
					FileHandler fileHandler = new FileHandler(fileName, 10240000, 10, false);
					fileHandler.setLevel(Level.WARNING);
					fileHandler.setFormatter(simpFormatter);
					logger = Logger.getLogger(object.getClass().getName());
					logger.setLevel(Level.WARNING);//only warnings will be printed in log file
					logger.addHandler(fileHandler);
					loggerMap.put("loggerMap",logger);
				}
				
			}else{
				logger = loggerMap.get("loggerMap"); // assigns the logger from session
			}
		}catch (Exception ex){
			System.out.println("Log path not found / Path is write protected. Please update config.xml with a valid log path");
			System.exit(0);
			return null;
		}
		return logger;
	}
}