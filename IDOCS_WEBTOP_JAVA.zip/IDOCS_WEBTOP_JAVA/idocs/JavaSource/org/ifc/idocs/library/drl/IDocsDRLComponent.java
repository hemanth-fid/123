package org.ifc.idocs.library.drl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.library.actions.LaunchEditComponentWithPermitCheck;
import org.ifc.idocs.library.actions.LaunchViewComponentWithPermitCheck;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfFormat;
import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.LocaleService;
import com.documentum.web.common.SessionState;
import com.documentum.web.common.URLEncoderCache;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.form.control.Button;
import com.documentum.web.form.control.Checkbox;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.Panel;
import com.documentum.web.formext.action.ActionService;
import com.documentum.web.formext.action.IActionCompleteListener;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.ConfigService;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.config.IConfigLookup;
import com.documentum.web.formext.control.docbase.DocbaseIcon;
import com.documentum.web.formext.docbase.ObjectCacheUtil;
import com.documentum.web.formext.docbase.TypeUtil;
import com.documentum.web.formext.session.AuthenticationService;
import com.documentum.web.formext.session.DocbaseUtils;
import com.documentum.web.formext.session.IAuthenticationService;
import com.documentum.web.formext.session.PasswordExpiredException;
import com.documentum.web.formext.session.SessionManagerHttpBinding;
import com.documentum.web.formext.session.TrustedAuthenticatorUtils;

public class IDocsDRLComponent extends Component
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String MSG_VIEWED = "Viewed";
	private class DRLLogoffOnComplete
        implements IActionCompleteListener
    {

        /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public void onComplete(String strAction, boolean bSuccess, Map map)
        {
            doLogout("/component/logoff?afterLogoff=closeWindow");
        }

        final IDocsDRLComponent this$0;

        private DRLLogoffOnComplete()
        {
            super();
            this$0 = IDocsDRLComponent.this;
        }

    }

    private class SysObject
    {

        public String getObjectName()
        {
            return m_strObjectName;
        }

        public String getObjectType()
        {
            return m_strObjectType;
        }

        public String getFormat()
        {
            return m_strFormat;
        }

        public String getVersionLabels()
        {
            return m_strVersionLabels;
        }

        public boolean canView()
        {
            if(m_canView == null)
                m_canView = Boolean.valueOf(m_strObjectId != null && ActionService.queryExecute("drlview", m_actionArgs, m_actionContext, IDocsDRLComponent.this));
            return m_canView.booleanValue();
        }

        public boolean canEdit()
        {
            if(m_canEdit == null)
                m_canEdit = Boolean.valueOf(m_strObjectId != null && ActionService.queryExecute("drledit", m_actionArgs, m_actionContext, IDocsDRLComponent.this));
            return m_canEdit.booleanValue();
        }

        public void doView()
        {
            if(m_strObjectId != null)
                if(m_bUsingAnonymousAccount && !hasViewPermissions())
                    doLogoutAndDispatchAction("drlview");
                else
                    executeAction("drlview");
        }

        public void doEdit()
        {
            if(m_strObjectId != null)
                if(m_bUsingAnonymousAccount && !hasEditPermissions())
                    doLogoutAndDispatchAction("drledit");
                else
                    executeAction("drledit");
        }

        private void executeAction(String strActionId)
        {
            IActionCompleteListener completeListener = null;
            if(m_bUsingAnonymousAccount && m_bLogoffAnonymousAccounts)
            {
                completeListener = new DRLLogoffOnComplete();
                m_actionArgs.add("navigateOnComplete", Boolean.FALSE.toString());
            }
            ActionService.execute(strActionId, m_actionArgs, m_actionContext, IDocsDRLComponent.this, completeListener);
        }

        private void doLogoutAndDispatchAction(String strActionId)
        {
            StringBuffer logoffUrl = new StringBuffer("/component/logoff?afterLogoff=forward&forwardUrl=");
            logoffUrl.append(constructActionUrl(strActionId, m_actionArgs, true));
            doLogout(logoffUrl.toString());
        }

        private boolean hasEditPermissions()
        {
            boolean bHasEditPermissions = false;
            if(!canEdit())
                bHasEditPermissions = false;
            else
                bHasEditPermissions = hasPermissions(5);
            return bHasEditPermissions;
        }

       
		private boolean hasViewPermissions()
        {
            boolean bHasViewPermissions = false;
            if(!canView())
                bHasViewPermissions = false;
            else
            if("dm_folder".equals(getObjectType()))
                bHasViewPermissions = hasPermissions(2);
            else
                bHasViewPermissions = hasPermissions(3);
           
            return bHasViewPermissions;
        }

       
		private boolean hasPermissions(int dfPermit)
        {
            boolean bHasPermissions = false;
            try
            {
                IDfSysObject sysObject = (IDfSysObject)ObjectCacheUtil.getObject(getDfSession(), m_strObjectId);
                if(sysObject != null)
                {
                    int permit = sysObject.getPermit();
                    bHasPermissions = permit >= dfPermit;
                }
            }
            catch(DfException dfe)
            {
                throw new WrapperRuntimeException(dfe);
            }
            catch(ClassCastException e)
            {
                throw new WrapperRuntimeException("Expecting IDfSysObject", e);
            }
            return bHasPermissions;
        }

        public boolean equals(SysObject object)
        {
            return m_strObjectId != null && object.m_strObjectId != null && m_strObjectId.equals(object.m_strObjectId);
        }

        private boolean isCurrentVersion()
        {
            return equals(m_objectCurrent);
        }

        private String m_strObjectId;
        private String m_strObjectName;
        private String m_strObjectType;
        private String m_strFormat;
        private String m_strVersionLabels;
        private Context m_actionContext;
        private ArgumentList m_actionArgs;
        private Boolean m_canEdit;
        private Boolean m_canView;
        private static final String DRL_VIEW_ACTION = "drlview";
        private static final String DRL_EDIT_ACTION = "drledit";
        final IDocsDRLComponent this$0;

        SysObject(String strObjectId, String strVersionLabel, String strFormat)
        {
        	super();
        	this$0 = IDocsDRLComponent.this;
            m_strObjectId = null;
            m_strObjectName = "";
            m_strObjectType = "";
            m_strFormat = "";
            m_strVersionLabels = "";
            m_actionContext = null;
            m_actionArgs = null;
            m_canEdit = null;
            m_canView = null;
            try
            {
                IDfPersistentObject perObject = ObjectCacheUtil.getObject(getDfSession(), strObjectId);
                if(perObject instanceof IDfSysObject)
                {
                    IDfSysObject sysObject = (IDfSysObject)perObject;
                    if(strVersionLabel != null && strVersionLabel.length() > 0)
                    {
                        String strChronicleId = sysObject.getString("i_chronicle_id");
                        StringBuffer buf = new StringBuffer(128);
                        buf.append("dm_sysobject (all) where i_chronicle_id='").append(strChronicleId).append("' and any r_version_label='").append(strVersionLabel).append("'");
                        sysObject = (IDfSysObject)getDfSession().getObjectByQualification(buf.toString());
                    }
                    if(sysObject != null)
                    {
                        m_strObjectId = sysObject.getObjectId().getId();
                        m_strObjectName = sysObject.getObjectName();
                        m_strObjectType = sysObject.getType().getName();
                        if(!(sysObject instanceof IDfFolder))
                        {
                            if(strFormat == null || strFormat.length() == 0)
                            {
                                IDfFormat format = sysObject.getFormat();
                                if(format != null)
                                    strFormat = format.getName();
                            }
                            m_strFormat = strFormat;
                            StringBuffer buf = new StringBuffer(100);
                            int nVersionLabel = sysObject.getVersionLabelCount();
                            for(int iVersionLabel = 0; iVersionLabel < nVersionLabel; iVersionLabel++)
                            {
                                if(iVersionLabel > 0)
                                    buf.append(", ");
                                buf.append(sysObject.getVersionLabel(iVersionLabel));
                            }

                            m_strVersionLabels = buf.toString();
                        }
                        m_actionArgs = new ArgumentList();
                        m_actionArgs.add("objectId", m_strObjectId);
                        m_actionArgs.add("contentType", strFormat);
                        m_actionArgs.add("isVirtualDoc", Boolean.toString(sysObject.isVirtualDocument()));
                        m_actionArgs.add("assembledFromId", sysObject.getAssembledFromId().getId());
                        m_actionContext = new Context(getContext());
                        m_actionContext.set("objectId", m_strObjectId);
                    }
                }
            }
            catch(DfException e)
            {
                m_strObjectId = null;
            }
        }
    }


    public IDocsDRLComponent()
    {
        m_showPermissionsErrorMessage = false;
        m_hideControls = false;
        m_strPermissionsErrorMessageNlsId = null;
        m_strObjectId = null;
        m_strVersionLabel = null;
        m_strFormat = null;
        m_objectVersion = null;
        m_objectCurrent = null;
        m_objectActive = null;
        m_bUsingAnonymousAccount = false;
        m_bLogoffAnonymousAccounts = true;
    }

    public void onInit(ArgumentList args)
    {
        super.onInit(args);
        m_strObjectId = args.get("objectId");
        m_strVersionLabel = args.get("versionLabel");
        
        if(m_strVersionLabel!=null && m_strVersionLabel .trim().length() > 0){
        	DfLogger.debug(this, "VersionLabel Argument From URL :", null, null);            
        }else{
        	m_strVersionLabel = "CURRENT";
        }
        
        m_strFormat = args.get("format");
        if(m_strObjectId == null || m_strObjectId.length() == 0)
            throw new IllegalArgumentException("DRLComponent requires an objectId.");
        String strRequestedDocbase = DocbaseUtils.getDocbaseNameFromId(m_strObjectId);
        if(strRequestedDocbase == null)
        {
            showError("MSG_DOCBROKER_ERROR");
            return;
        }
        SessionManagerHttpBinding.setClientDocbase(strRequestedDocbase);
        if(!isAuthenticated(strRequestedDocbase))
        {
            attemptAnonymousLogin(strRequestedDocbase);
            setComponentJump("drlauthenticate", args, getContext());
        } else
        {
            m_bUsingAnonymousAccount = Boolean.TRUE.equals(getPageContext().getRequest().getAttribute("drlUsingAnonymousAccount"));
            m_bLogoffAnonymousAccounts = Boolean.TRUE.equals(lookupBoolean("defaultaccounts.logoffoncomplete"));
            if(!viewNonSysObj(m_strObjectId, args))
            {
                updateDocbaseObjects();
                if(!m_objectActive.hasViewPermissions() && !m_objectActive.hasEditPermissions())
                {
                    processNoPrivilegesError();
                    return;
                }
                setErrorPanelVisible(false);
                initDRLComponentControls();
                if(m_objectActive.isCurrentVersion() && m_objectActive.hasViewPermissions() && !m_objectActive.hasEditPermissions())
                    m_objectActive.doView();
            }
        }
    }

    public boolean isAuthenticated(String strDocbase)
    {
        boolean bAuthenticated = false;
        if(SessionManagerHttpBinding.isConnectedToDocbase(strDocbase))
        {
            bAuthenticated = true;
        } else
        {
            IAuthenticationService authService = AuthenticationService.getService();
            try
            {
                HttpServletRequest request = (HttpServletRequest)getPageContext().getRequest();
                HttpServletResponse response = (HttpServletResponse)getPageContext().getResponse();
                String authDocbase = authService.authenticate(request, response, strDocbase);
                if(authDocbase != null)
                    bAuthenticated = authDocbase.equals(strDocbase);
            }
            catch(DfException ignore) { }
        }
        return bAuthenticated;
    }

    public void onRender()
    {
        super.onRender();
        if(m_showPermissionsErrorMessage)
        {
            showMessage(m_strPermissionsErrorMessageNlsId, m_hideControls);
            m_showPermissionsErrorMessage = false;
        } else
        {
            setErrorPanelVisible(false);
        }
    }

    public void onOpenCurrent(Checkbox checkbox, ArgumentList args)
    {
        updateDocbaseObjects();
        updateDRLComponentButtons();
    }

    public void onViewClicked(Button button, ArgumentList args)
    {
        updateDocbaseObjects();
        if(m_objectActive.canView())
        {
            m_objectActive.doView();
            IdocsUtil.auditIDocsActivity(MSG_VIEWED,m_strObjectId,getDfSession());
        } else
        {
            showWarning("MSG_NO_VIEW_PERMISSION");
            updateDRLComponentButtons();
        }
    }

    public void onEditClicked(Button button, ArgumentList args)
    {
        updateDocbaseObjects();
        if(m_objectActive.canEdit())
        {
            m_objectActive.doEdit();          
        } else
        {
            showWarning("MSG_NO_EDIT_PERMISSION");
            updateDRLComponentButtons();
        }
    }

    public void onCloseClicked(Button button, ArgumentList args)
    {
        if(m_bUsingAnonymousAccount && m_bLogoffAnonymousAccounts)
            doLogout("/component/logoff?afterLogoff=closeWindow");
        else
            setComponentJump("main", args, getContext());
    }

    public static String constructDRL(String strObjectId, String strVersionLabel, String strFormat, Component component)
    {
        if(component == null)
            throw new IllegalArgumentException("component is mandatory");
        if(strObjectId == null || strObjectId.length() == 0)
            throw new IllegalArgumentException("Cannot create a bookmark without an objectId");
        if(!hasDRLActions(strObjectId, null, component))
            return null;
        StringBuffer buf = new StringBuffer(256);
        HttpServletRequest request = (HttpServletRequest)component.getPageContext().getRequest();
        buf.append(request.getContextPath()).append("/drl/objectId/").append(strObjectId);
        if(strVersionLabel != null && strVersionLabel.length() > 0)
            buf.append("/versionLabel/").append(strVersionLabel);
        if(strFormat != null && strFormat.length() > 0)
            buf.append("/format/").append(strFormat);
        return buf.toString();
    }

    public static boolean hasDRLActions(String strObjectId, String strObjectType, Component component)
    {
        if(component == null)
            throw new IllegalArgumentException("component is mandatory");
        if(strObjectId == null || strObjectId.length() == 0 || !(new DfId(strObjectId)).isObjectId())
            return false;
        if(strObjectType == null || strObjectType.length() == 0)
            try
            {
                strObjectType = TypeUtil.getObjectType(strObjectId);
            }
            catch(Exception e)
            {
                return false;
            }
        return _hasDRLActions(strObjectId, strObjectType, component);
    }

    private static boolean _hasDRLActions(String strObjectId, String strObjectType, Component component)
    {
        Map cacheMap = (Map)SessionState.getAttribute("hasDRLActionMap");
        if(cacheMap == null)
        {
            cacheMap = new Hashtable();
            SessionState.setAttribute("hasDRLActionMap", cacheMap);
        }
        String key = (new StringBuilder()).append(SessionManagerHttpBinding.getCurrentDocbase()).append(strObjectType).toString();
        Boolean hasAction = (Boolean)cacheMap.get(key);
        if(hasAction == null)
        {
            hasAction = Boolean.valueOf(false);
            Context actionContext = new Context(component.getInitialContext());
            actionContext.set("objectId", strObjectId);
            actionContext.set("type", strObjectType);
            IConfigLookup lookup = ConfigService.getConfigLookup();
            if(lookup.lookupElement("action[id=drlview]", actionContext) != null || lookup.lookupElement("action[id=drledit]", actionContext) != null)
                hasAction = Boolean.valueOf(true);
            cacheMap.put(key, hasAction);
        }
        return hasAction.booleanValue();
    }

    protected String constructAuthenticatedDRL(String strObjectId, String strVersionLabel, String strFormat, boolean bEncode)
    {
        if(strObjectId == null || strObjectId.length() == 0)
            throw new IllegalArgumentException("Cannot construct a DRL without an objectId");
        StringBuffer buf = new StringBuffer(128);
        buf.append("/component/").append("drlauthenticate").append("?objectId=").append(strObjectId);
        if(strVersionLabel != null && strVersionLabel.length() > 0)
            buf.append("&versionLabel=").append(strVersionLabel);
        if(strFormat != null && strFormat.length() > 0)
            buf.append("&format=").append(strFormat);
        String url = makeUrl(getPageContext().getRequest(), buf.toString());
        if(bEncode)
            try
            {
                url = URLEncoderCache.getEncodedString(url, "UTF-8");
            }
            catch(UnsupportedEncodingException e)
            {
                throw new WrapperRuntimeException(e);
            }
        return url;
    }

    protected void doLogout(String logoffUrl)
    {
        setComponentPage("logout");
        ArgumentList args = null;
        if(logoffUrl != null && logoffUrl.length() > 0)
        {
            args = new ArgumentList();
            args.add("homeurl", logoffUrl);
        }
        ActionService.execute("logout", args, getContext(), this, null);
    }

    private void attemptAnonymousLogin(String strRequestedDocbase)
    {
        boolean bAttemptAnonymousAuthentication = false;
        if(m_strObjectId != null && m_strObjectId.startsWith("09"))
            bAttemptAnonymousAuthentication = true;
        if(bAttemptAnonymousAuthentication)
        {
            boolean success = authenticateUsingAnonymousAccount(strRequestedDocbase);
            if(success)
                getPageContext().getRequest().setAttribute("drlUsingAnonymousAccount", Boolean.TRUE);
        }
    }

    private void showError(String strErrorNlsId)
    {
        m_showPermissionsErrorMessage = true;
        m_hideControls = true;
        m_strPermissionsErrorMessageNlsId = strErrorNlsId;
    }

    private void showWarning(String strErrorNlsId)
    {
        m_showPermissionsErrorMessage = true;
        m_hideControls = false;
        m_strPermissionsErrorMessageNlsId = strErrorNlsId;
    }

    private void showMessage(String strErrorNlsId, boolean hideControls)
    {
        if(hideControls)
        {
            Panel detailsPanel = (Panel)getControl("details", com.documentum.web.form.control.Panel.class);
            detailsPanel.setVisible(false);
            Button viewBtn = (Button)getControl("view", com.documentum.web.form.control.Button.class);
            viewBtn.setVisible(false);
            Button editBtn = (Button)getControl("edit", com.documentum.web.form.control.Button.class);
            editBtn.setVisible(false);
        }
        setErrorPanelVisible(true);
        Label error = (Label)getControl("error_message", com.documentum.web.form.control.Label.class);
        error.setLabel(getString(strErrorNlsId));
    }

    private void setErrorPanelVisible(boolean visible)
    {
        Panel errorPanel = (Panel)getControl("error", com.documentum.web.form.control.Panel.class);
        errorPanel.setVisible(visible);
    }

    private void processNoPrivilegesError()
    {
        boolean bAnonymousAccountNotPriviledged = false;
        if(m_strFormat == null)
        {
            if(m_objectCurrent.m_strObjectId == null)
            {
                if(m_strObjectId != null && m_strObjectId.startsWith("0b"))
                    showError("MSG_FOLDER_DOES_NOT_EXIST");
                else
                if(m_bUsingAnonymousAccount)
                    bAnonymousAccountNotPriviledged = true;
                else
                    showError("MSG_DOCUMENT_DOES_NOT_EXIST");
            } else
            {
                showError("MSG_CONTENTLESS_OBJECT_ERROR");
            }
        } else
        if(m_bUsingAnonymousAccount)
            bAnonymousAccountNotPriviledged = true;
        else
            showError("MSG_SUCURITY_ERROR");
        if(m_bUsingAnonymousAccount && bAnonymousAccountNotPriviledged)
        {
            StringBuffer logoffUrl = new StringBuffer("/component/logoff?afterLogoff=forward&forwardUrl=");
            logoffUrl.append(constructAuthenticatedDRL(m_strObjectId, m_strVersionLabel, m_strFormat, true));
            doLogout(logoffUrl.toString());
        }
    }

    private void updateDocbaseObjects()
    {
        m_objectVersion = new SysObject(m_strObjectId, m_strVersionLabel, m_strFormat);
        m_objectCurrent = new SysObject(m_strObjectId, "CURRENT", getInitArgs().get("format"));
        if(isCurrentVersionSelected())
            m_objectActive = m_objectCurrent;
        else
            m_objectActive = m_objectVersion;
    }

    private void initDRLComponentControls()
    {
        Checkbox openCurrCheckbox = (Checkbox)getControl("opencurrent", com.documentum.web.form.control.Checkbox.class);
        boolean bIsOpenCurrentCheckBoxVisible = !m_objectVersion.isCurrentVersion();
        openCurrCheckbox.setVisible(bIsOpenCurrentCheckBoxVisible);
        Label objectNameLabel = (Label)getControl("object_name", com.documentum.web.form.control.Label.class);
        objectNameLabel.setLabel(m_objectVersion.getObjectName());
        Label objectVersionLabel = (Label)getControl("object_version", com.documentum.web.form.control.Label.class);
        objectVersionLabel.setLabel(m_objectVersion.getVersionLabels());
        Label objectFormatLabel = (Label)getControl("object_format", com.documentum.web.form.control.Label.class);
        objectFormatLabel.setLabel(m_objectVersion.getFormat());
        DocbaseIcon docbaseIcon = (DocbaseIcon)getControl("object_icon", com.documentum.web.formext.control.docbase.DocbaseIcon.class);
        docbaseIcon.setType(m_objectVersion.getObjectType());
        m_strFormat = m_strFormat == null ? m_objectVersion.getFormat() : m_strFormat;
        docbaseIcon.setFormat(m_strFormat);
        updateDRLComponentButtons();
    }

    private void updateDRLComponentButtons(){
    	boolean bCanView = m_objectActive.hasViewPermissions();
        boolean bCanEdit = m_objectActive.hasEditPermissions();
        boolean bhasIFCDocsEdit = false;
	    try{
	    	HashMap<String, String> docValuesMap = new HashMap<String, String>();
			docValuesMap=IdocsUtil.getRequiredAttributesValues(m_strObjectId,getDfSession());
			String strObjectType = docValuesMap.get(IDocsConstants.MSG_R_OBJECT_TYPE);//
	        if(bCanEdit  == true ){
	        	if(strObjectType != null && strObjectType.trim().length() >0
	        			&& strObjectType.startsWith(IDocsConstants.MSG_IDOCS)){
	        		ArgumentList promptArguments = new ArgumentList();
	        		promptArguments.add("objectId", m_strObjectId);
	        		bCanEdit = new LaunchEditComponentWithPermitCheck().execute(null, null, promptArguments, null, this, null);
	        		bhasIFCDocsEdit = true;		        	
	        		//	checkApplicationSecurityEditPermission();
		       }
	        }
		        
	    	if(bhasIFCDocsEdit == false ){
	    		// Dont check for View permission as this user already had Write.
	    		DfLogger.debug(this, " :: updateDRLComponentButtons : user has Write : Allow View :",null,null);
	    		bCanView = true;
	        }else{
	        	if(bCanView == true ){
		        	if(strObjectType != null && strObjectType.trim().length() >0 
		            		&& strObjectType.startsWith(IDocsConstants.MSG_IDOCS)){
		           	 bCanView = LaunchViewComponentWithPermitCheck.validateUserPermissionsForView(false,m_strObjectId,getDfSession(),docValuesMap);
		            } 
	    		}
	        }
	    }catch (Exception e) {
	    	DfLogger.debug(this, " :: checkApplicationSecurityViewPermission : Exception :"+e.getMessage(),null,null);
		}
        DfLogger.debug(this, " :: checkApplicationSecurityViewPermission : bCanView ="+bCanView,null,null);
        DfLogger.debug(this, " :: checkApplicationSecurityViewPermission : bCanEdit ="+bCanEdit,null,null);
        if(m_bUsingAnonymousAccount){
        	bCanView = true;
        	bCanEdit = true;
        }
        Button viewBtn = (Button)getControl("view", com.documentum.web.form.control.Button.class);
        viewBtn.setEnabled(bCanView); 
        Button editBtn = (Button)getControl("edit", com.documentum.web.form.control.Button.class);
        editBtn.setEnabled(bCanEdit);
        Button closeBtn = (Button)getControl("close", com.documentum.web.form.control.Button.class);
        Label erroLabel = (Label) getControl("idocs_error_message",Label.class);
        if(bCanEdit ==false && bCanView==false){
        	closeBtn.setVisible(true);
        	closeBtn.setEnabled(true);
        	if(erroLabel!=null){
        		erroLabel.setLabel(nls_lookup.getString("DRL_NO_PERMISSIONS", LocaleService.getLocale()));
        		erroLabel.setVisible(true);
        		erroLabel.setEnabled(true);
        	}
        	DfLogger.debug(this, " updateDRLComponentButtons :: View And Edit is Disabled So Enable Close Button", null, null);
        }else{
        	erroLabel.setVisible(false);
    		erroLabel.setEnabled(false);
        	closeBtn.setVisible(getCallerForm() != null);
        }
        editBtn.setVisible(m_objectActive.getFormat() != null);
    }

   private boolean isCurrentVersionSelected()
    {
        Checkbox openCurrCheckbox = (Checkbox)getControl("opencurrent", com.documentum.web.form.control.Checkbox.class);
        return openCurrCheckbox.getValue();
    }

    private boolean viewNonSysObj(String strObjectId, ArgumentList args)
    {
        boolean fViewed = false;
        try
        {
            IDfSession dfSession = getDfSession();
            IDfPersistentObject docbaseObject = ObjectCacheUtil.getObject(dfSession, strObjectId);
            Context actionContext = new Context(getContext());
            actionContext.set("objectId", strObjectId);
            actionContext.set("type", docbaseObject.getType().getName());
            if(!(docbaseObject instanceof IDfSysObject) && ActionService.queryExecute("drlview", args, actionContext, this))
                fViewed = ActionService.execute("drlview", args, actionContext, this, null);
        }
        catch(DfException e) { }
        return fViewed;
    }

    private boolean authenticateUsingAnonymousAccount(String strRequestedDocbase)
    {
        boolean bSuccessfullyAuthenticated = false;
        IDfLoginInfo loginInfo = getAnonymousAccountLoginInfo(strRequestedDocbase);
        if(loginInfo != null)
            try
            {
                AuthenticationService.getService().login(getPageContext().getSession(), strRequestedDocbase, loginInfo.getUser(), loginInfo.getPassword(), loginInfo.getDomain());
                bSuccessfullyAuthenticated = true;
            }
            catch(PasswordExpiredException ignore)
            {
                bSuccessfullyAuthenticated = false;
            }
            catch(DfException ignore)
            {
                bSuccessfullyAuthenticated = false;
            }
        return bSuccessfullyAuthenticated;
    }

    private IDfLoginInfo getAnonymousAccountLoginInfo(String strRequestedDocbase)
    {
        IDfLoginInfo loginInfo = null;
        IConfigLookup configLookup = ConfigService.getConfigLookup();
        Context ctx = getContext();
        if(strRequestedDocbase != null)
        {
            ctx = new Context(getContext());
            ctx.set("docbase", strRequestedDocbase);
        }
        IConfigElement accInfo = configLookup.lookupElement((new StringBuilder()).append("component[id=").append(getComponentId()).append("].defaultaccounts.account").toString(), ctx);
        if(accInfo == null)
            accInfo = configLookup.lookupElement((new StringBuilder()).append("component[id=").append(getComponentId()).append("].defaultaccounts.defaultaccount").toString(), ctx);
        if(accInfo != null)
        {
            String strUserId = accInfo.getChildElement("username").getValue();
            if(strUserId != null)
            {
                loginInfo = new DfLoginInfo();
                loginInfo.setUser(strUserId);
                IConfigElement newpwElem = accInfo.getChildElement("new-pw");
                if(newpwElem != null)
                {
                    try
                    {
                        loginInfo.setPassword(TrustedAuthenticatorUtils.decryptByDES(newpwElem.getValue()));
                    }
                    catch(GeneralSecurityException gse)
                    {
                        throw new WrapperRuntimeException(gse);
                    }
                    catch(IOException ioe)
                    {
                        throw new WrapperRuntimeException(ioe);
                    }
                } else
                {
                    String strPassword = accInfo.getChildElement("password").getValue();
                    loginInfo.setPassword(TrustedAuthenticatorUtils.decrypt(strPassword));
                }
                String strDomain = accInfo.getChildElement("domain").getValue();
                if(strDomain != null && strDomain.length() > 0)
                    loginInfo.setDomain(strDomain);
            }
        }
        return loginInfo;
    }

    private String constructActionUrl(String strActionId, ArgumentList args, boolean bEncode)
    {
        if(strActionId == null || strActionId.length() == 0)
            throw new IllegalArgumentException("Action Id is required");
        StringBuffer buf = new StringBuffer(256);
        buf.append(".action/").append(strActionId).append("?");
        if(args != null)
        {
            Iterator argIterator = args.nameIterator();
            boolean firstArg = true;
            while(argIterator.hasNext()) 
            {
                String arg = (String)argIterator.next();
                String values[] = args.getValues(arg);
                int i = 0;
                while(i < values.length) 
                {
                    if(firstArg)
                        firstArg = false;
                    else
                        buf.append("&");
                    buf.append(arg).append("=").append(values[i]);
                    i++;
                }
            }
        }
        String url = makeUrl(getPageContext().getRequest(), buf.toString());
        if(bEncode)
            try
            {
                url = URLEncoderCache.getEncodedString(url, "UTF-8");
            }
            catch(UnsupportedEncodingException e)
            {
                throw new WrapperRuntimeException(e);
            }
        return url;
    }
    
    private static final NlsResourceBundle nls_lookup = new NlsResourceBundle("org.ifc.idocs.action.ValidateGroupMembershipNlsProp");
    String accessRole = null;
    boolean isWorkflowRestartable = false;
    private boolean m_showPermissionsErrorMessage;
    private boolean m_hideControls;
    private String m_strPermissionsErrorMessageNlsId;
    private String m_strObjectId;
    private String m_strVersionLabel;
    private String m_strFormat;
    private SysObject m_objectVersion;
    private SysObject m_objectCurrent;
    private SysObject m_objectActive;
    private boolean m_bUsingAnonymousAccount;
    private boolean m_bLogoffAnonymousAccounts;
    public static final String VIEW = "view";
    public static final String EDIT = "edit";
    public static final String CLOSE = "close";
    public static final String DETAILS_PANEL = "details";
    public static final String ERROR_PANEL = "error";
    public static final String ERROR_MESSAGE = "error_message";
    public static final String OBJ_VERSION = "object_version";
    public static final String OBJ_FORMAT = "object_format";
    public static final String OBJ_NAME = "object_name";
    public static final String OBJ_ICON = "object_icon";
    public static final String OPEN_CURRENT = "opencurrent";
}
