package com.SWBC.RulesService;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SWBC.model.PreProc_Doca_Ucap;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.common.DfException;

import static com.SWBC.utilities.BRMConstants.*;
import com.SWBC.utilities.BRMUtilities;

@Service("SetDOCAAttributeValues")
public class SetDOCAAttributeValues {

	@Autowired
	private PreProc_Doca_Ucap docaObj;

	public PreProc_Doca_Ucap setAttr(IDfCollection coll) throws ParseException {
		// PreProc_Doca_Ucap docaObj = new PreProc_Doca_Ucap();
		try {
			while (coll.next()) {
			

				docaObj.setDoc_scan_date(coll.getTime("doc_scan_date").toString() == "nulldate"
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: new SimpleDateFormat("MM/dd/yyyy").parse(coll.getTime("doc_scan_date").toString()));
				docaObj.setFollow_up_date(coll.getTime("follow_up_date").toString() == "nulldate"
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: new SimpleDateFormat("MM/dd/yyyy").parse(coll.getTime("follow_up_date").toString()));
				docaObj.setPolicy_expiration_date(coll.getTime("policy_expiration_date").toString() == "nulldate"
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: new SimpleDateFormat("MM/dd/yyyy").parse(coll.getTime("policy_expiration_date").toString()));
				docaObj.setPolicy_cancel_date(coll.getTime("policy_cancel_date").toString() == "nulldate"
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: new SimpleDateFormat("MM/dd/yyyy").parse(coll.getTime("policy_cancel_date").toString()));
				docaObj.setPremium_due_date(coll.getTime("premium_due_date").toString() == "nulldate"
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: new SimpleDateFormat("MM/dd/yyyy").parse(coll.getTime("premium_due_date").toString()));
				docaObj.setDoc_issue_date(coll.getTime("doc_issue_date").toString() == "nulldate"
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: new SimpleDateFormat("MM/dd/yyyy").parse(coll.getTime("doc_issue_date").toString()));
				docaObj.setDoc_notice_effective_date(coll.getTime("doc_notice_effective_date").toString() == "nulldate"
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: new SimpleDateFormat("MM/dd/yyyy")
								.parse(coll.getTime("doc_notice_effective_date").toString()));
				docaObj.setDoc_delivery_date(coll.getTime("doc_delivery_date").toString() == "nulldate"
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: new SimpleDateFormat("MM/dd/yyyy").parse(coll.getTime("doc_delivery_date").toString()));
				docaObj.setDoc_notice_date(coll.getTime("doc_notice_date").toString() == "nulldate"
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: new SimpleDateFormat("MM/dd/yyyy").parse(coll.getTime("doc_notice_date").toString()));
				docaObj.setReinstatement_date(coll.getTime("reinstatement_date").toString() == "nulldate"
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: new SimpleDateFormat("MM/dd/yyyy").parse(coll.getTime("reinstatement_date").toString()));
				docaObj.setPolicy_effective_date(coll.getTime("policy_effective_date").toString() == "nulldate"
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: new SimpleDateFormat("MM/dd/yyyy").parse(coll.getTime("policy_effective_date").toString()));
				docaObj.setDoc_received_date(coll.getTime("doc_received_date").toString() == "nulldate"
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: new SimpleDateFormat("MM/dd/yyyy").parse(coll.getTime("doc_received_date").toString()));
				docaObj.setAs400_post_date(coll.getTime("as400_post_date").toString() == "nulldate"
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: new SimpleDateFormat("MM/dd/yyyy").parse(coll.getTime("as400_post_date").toString()));

				docaObj.setPercent_primary_coverage(coll.getDouble("percent_primary_coverage"));
				docaObj.setPolicy_premium(coll.getDouble("policy_premium"));
				docaObj.setPercent_deductible(coll.getDouble("percent_deductible"));
				docaObj.setCoverage_amount(coll.getDouble("coverage_amount"));
				docaObj.setAdditional_coverage_amount(coll.getDouble("additional_coverage_amount"));
				docaObj.setAdditional_premium_amt(coll.getDouble("additional_premium_amt"));
				docaObj.setDeductible(coll.getDouble("deductible"));
				docaObj.setBase_coverage_other_structs(coll.getDouble("base_coverage_other_structs"));
				docaObj.setBatch_number(coll.getInt("batch_number"));
				docaObj.setNumber_of_condos(coll.getInt("number_of_condos"));
				docaObj.setBatch_seq_no(coll.getInt("batch_seq_no"));
				docaObj.setFlood_zone(coll.getString("flood_zone") == null ? "" : coll.getString("flood_zone").toString().trim());
				docaObj.setHo_6_flag(coll.getString("ho_6_flag") == null ? "" : coll.getString("ho_6_flag").toString().trim());
				docaObj.setGrandfater_zone(coll.getString("grandfater_zone") == null ? "" : coll.getString("grandfater_zone").toString().trim());
				docaObj.setEarthquake_excluded(coll.getString("earthquake_excluded") == null ? "" : coll.getString("earthquake_excluded").toString().trim());
				docaObj.setGrandfather_zone(coll.getString("grandfather_zone") == null ? "" : coll.getString("grandfather_zone").toString().trim());
				docaObj.setReplace_cost_ind(coll.getString("replace_cost_ind") == null ? "" : coll.getString("replace_cost_ind").toString().trim());
				docaObj.setBill_indicator(coll.getString("bill_indicator") == null ? "" : coll.getString("bill_indicator").toString().trim()) ;
				docaObj.setPercent_add_other_structure(coll.getString("percent_add_other_structure") == null ? "" : coll.getString("percent_add_other_structure").toString().trim());
				docaObj.setWind_excluded(coll.getString("wind_excluded") == null ? "" : coll.getString("wind_excluded").toString().trim());
				docaObj.setDocument_sub_type(coll.getString("document_sub_type") == null ? "" : coll.getString("document_sub_type").toString().trim());
				docaObj.setFollow_up_reason(coll.getString("follow_up_reason") == null ? "" : coll.getString("follow_up_reason").toString().trim());
				docaObj.setAgent_email(coll.getString("agent_email") == null ? "" : coll.getString("agent_email").toString().trim());
				docaObj.setCov_type(coll.getString("cov_type") == null ? "" : coll.getString("cov_type").toString().trim());
				docaObj.setIs_qc_candidate(coll.getString("is_qc_candidate") == null ? "" : coll.getString("is_qc_candidate").toString().trim());
				docaObj.setDocument_type(coll.getString("document_type") == null ? "" : coll.getString("document_type").toString().trim());
				docaObj.setLoan_type(coll.getString("loan_type") == null ? "" : coll.getString("loan_type").toString().trim());
				docaObj.setCarrier_zip(coll.getString("carrier_zip") == null ? "" : coll.getString("carrier_zip").toString().trim());
				docaObj.setTransaction_status(coll.getString("transaction_status") == null ? "" : coll.getString("transaction_status").toString().trim());
				docaObj.setOrig_file_name(coll.getString("orig_file_name") == null ? "" : coll.getString("orig_file_name").toString().trim());
				docaObj.setProperty_zip(coll.getString("property_zip") == null ? "" : coll.getString("property_zip").toString().trim());
				docaObj.setLoan_number(coll.getString("loan_number") == null ? "" : coll.getString("loan_number").toString().trim());
				docaObj.setAgency_number(coll.getString("agency_number") == null ? "" : coll.getString("agency_number").toString().trim());
				docaObj.setEscrow_indicator(coll.getString("escrow_indicator") == null ? "" : coll.getString("escrow_indicator").toString().trim());
				docaObj.setMailing_address(coll.getString("mailing_address") == null ? "" : coll.getString("mailing_address").toString().trim());
				docaObj.setAccount_number(coll.getString("account_number") == null ? "" : coll.getString("account_number").toString().trim());
				docaObj.setAccount_tax_id(coll.getString("account_tax_id") == null ? "" : coll.getString("account_tax_id").toString().trim());
				docaObj.setProperty_address_1(coll.getString("property_address_1") == null ? "" : coll.getString("property_address_1").toString().trim());
				docaObj.setProperty_address_2(coll.getString("property_address_2") == null ? "" : coll.getString("property_address_2").toString().trim());
				docaObj.setMailing_state(coll.getString("mailing_state") == null ? "" : coll.getString("mailing_state").toString().trim());
				docaObj.setPayee_code(coll.getString("payee_code") == null ? "" : coll.getString("payee_code").toString().trim());
				docaObj.setClient_number(coll.getString("client_number") == null ? "" : coll.getString("client_number").toString().trim());
				docaObj.setQc_response_code(coll.getString("qc_response_code") == null ? "" : coll.getString("qc_response_code").toString().trim());
				docaObj.setScan_id(coll.getString("scan_id") == null ? "" : coll.getString("scan_id").toString().trim());
				docaObj.setProperty_city(coll.getString("property_city") == null ? "" : coll.getString("property_city").toString().trim());
				docaObj.setPolicy_number(coll.getString("policy_number") == null ? "" : coll.getString("policy_number").toString().trim());
				docaObj.setMortgagee_zip(coll.getString("mortgagee_zip") == null ? "" : coll.getString("mortgagee_zip").toString().trim());
				docaObj.setMortgagee_name(coll.getString("mortgagee_name") == null ? "" : coll.getString("mortgagee_name").toString().trim());
				docaObj.setAgent_city(coll.getString("agent_city") == null ? "" : coll.getString("agent_city").toString().trim());
				docaObj.setImpairment_code(coll.getString("impairment_code") == null ? "" : coll.getString("impairment_code").toString().trim());
				docaObj.setAgent_name(coll.getString("agent_name") == null ? "" : coll.getString("agent_name").toString().trim());
				docaObj.setMailing_city(coll.getString("mailing_city") == null ? "" : coll.getString("mailing_city").toString().trim());
				docaObj.setPolicy_cancel_reason(coll.getString("policy_cancel_reason") == null ? "" : coll.getString("policy_cancel_reason").toString().trim() );
				docaObj.setMortgagee_city(coll.getString("mortgagee_city") == null ? "" : coll.getString("mortgagee_city").toString().trim());
				docaObj.setAgent_zip(coll.getString("agent_zip") == null ? "" : coll.getString("agent_zip").toString().trim());
				docaObj.setAccount_name(coll.getString("account_name") == null ? "" : coll.getString("account_name").toString().trim());
				docaObj.setTransaction_id(coll.getString("transaction_id") == null ? "" : coll.getString("transaction_id").toString().trim());
				docaObj.setTransaction_source(coll.getString("transaction_source") == null ? "" : coll.getString("transaction_source").toString().trim());
				docaObj.setCo_policy_holder_name(coll.getString("co_policy_holder_name") == null ? "" : coll.getString("co_policy_holder_name").toString().trim());
				docaObj.setProperty_state(coll.getString("property_state") == null ? "" : coll.getString("property_state").toString().trim());
				docaObj.setCarrier_city(coll.getString("carrier_city") == null ? "" : coll.getString("carrier_city").toString().trim());
				docaObj.setAgent_phone(coll.getString("agent_phone") == null ? "" : coll.getString("agent_phone").toString().trim());
				docaObj.setCarrier_name(coll.getString("carrier_name") == null ? "" : coll.getString("carrier_name").toString().trim());
				docaObj.setLoan_suffix(coll.getString("loan_suffix") == null ? "" : coll.getString("loan_suffix").toString().trim());
				docaObj.setMortgagee_address(coll.getString("mortgagee_address") == null ? "" : coll.getString("mortgagee_address").toString().trim());
				docaObj.setCarrier_state(coll.getString("carrier_state") == null ? "" : coll.getString("carrier_state").toString().trim());
				docaObj.setAgent_address(coll.getString("agent_address") == null ? "" : coll.getString("agent_address").toString().trim());
				docaObj.setInstitution_code(coll.getString("institution_code") == null ? "" : coll.getString("institution_code").toString().trim());
				docaObj.setCarrier_address_1(coll.getString("carrier_address_1") == null ? "" : coll.getString("carrier_address_1").toString().trim());
				docaObj.setAgent_state(coll.getString("agent_state") == null ? "" : coll.getString("agent_state").toString().trim());
				docaObj.setPolicy_holder_name(coll.getString("policy_holder_name") == null ? "" : coll.getString("policy_holder_name").toString().trim());
				docaObj.setTransaction_type(coll.getString("transaction_type") == null ? "" : coll.getString("transaction_type").toString().trim());
				docaObj.setMailing_zip(coll.getString("mailing_zip") == null ? "" : coll.getString("mailing_zip").toString().trim());
				docaObj.setMortgagee_state(coll.getString("mortgagee_state") == null ? "" : coll.getString("mortgagee_state").toString().trim());
				docaObj.setCarrier_phone(coll.getString("carrier_phone") == null ? "" : coll.getString("carrier_phone").toString().trim());

			}

		} catch (DfException e) {

			e.printStackTrace();
		}

		return docaObj;
	}

	public PreProc_Doca_Ucap setCarrierInfo(List<Map<String, Object>> rowACCT,
			List<Map<String, Object>> rowCarrierFMS053, PreProc_Doca_Ucap docaObj) {

		// PreProc_Doca_Ucap docaObj = new PreProc_Doca_Ucap();

		for (Map row : rowACCT) {
			docaObj.setFC_FORMAT(row.get("FC_FORMAT").toString().trim());
			docaObj.setFC_ACCOUNT(row.get("FC_ACCOUNT").toString().trim());
			docaObj.setFIRE(row.get("FIRE").toString().trim());
			docaObj.setHOME(row.get("HOME").toString().trim());
			docaObj.setFLOOD(row.get("FLOOD").toString().trim());
			docaObj.setWIND(row.get("WIND").toString().trim());
			docaObj.setCONT(row.get("CONT").toString().trim());
			docaObj.setLIAB(row.get("LIAB").toString().trim());
			docaObj.setEQUIP(row.get("EQUIP").toString().trim());
			docaObj.setQUAKE(row.get("QUAKE").toString().trim());
			docaObj.setGAP(row.get("GAP").toString().trim());
			docaObj.setOTHR(row.get("OTHR").toString().trim());
		}

		for (Map row : rowCarrierFMS053) {
			docaObj.setCO_ALIAS(row.get("CO_ALIAS").toString().trim());
			docaObj.setCO_NAME(row.get("CO_NAME").toString().trim());
			docaObj.setCO_TRAN_DATE(row.get("CO_TRAN_DATE").toString().trim());
			docaObj.setCO_OPERATOR_ID(row.get("CO_OPERATOR_ID").toString().trim());
		}

		return docaObj;

	}

	public PreProc_Doca_Ucap setShortNameAndPayeeInfo(List<Map<String, Object>> dbrow, PreProc_Doca_Ucap docaObj) {

		List<String> shortName = new ArrayList<String>();
		List<String> payee = new ArrayList<String>();

		for (Map row : dbrow) {

			shortName.add(row.get("SHORTNAME").toString().trim());
			payee.add(row.get("PAYEE").toString().trim());

		}

		docaObj.setSHORTNAME(shortName);
		docaObj.setPAYEE(payee);

		return docaObj;

	}

	public PreProc_Doca_Ucap setRule3_4_PreProc_AgentCode_PolicyScore(List<Map<String, Object>> dbrow,
			PreProc_Doca_Ucap docaObj) {

		for (Map row : dbrow) {

			docaObj.setPolicy_score(BRMUtilities.getPolicyNumberScore(docaObj.getPolicy_number(),
					row.get("ISLOANPOLICYNO").toString().trim()));
			docaObj.setIS_AGENT_CODE(row.get("AGENTCODE").toString().trim());

		}

		return docaObj;
	}

	public PreProc_Doca_Ucap setMasterPayee(String masterPayeeFlag, PreProc_Doca_Ucap docaObj) {
		docaObj.setMasterPayee(masterPayeeFlag);

		return docaObj;

	}

	public PreProc_Doca_Ucap setShortNameCarrier_Rule_3_2(List<Map<String, Object>> dbrow, PreProc_Doca_Ucap docaObj) {
		
		
		List<String> shortNameCarrier = new ArrayList<String>();
		List<String> payeeCarrier = new ArrayList<String>();

		for (Map row : dbrow) {

			if(row.get("SHORTNAME") == null)
			{
				shortNameCarrier.add(docaObj.getCarrier_name());
				payeeCarrier.add(row.get("PAYEE").toString().trim());
			}
			else
			{
				shortNameCarrier.add(row.get("SHORTNAME").toString().trim());
				payeeCarrier.add(row.get("PAYEE").toString().trim());
			}
				
			

		}

		docaObj.setSHORTNAME_CARRIER(shortNameCarrier);
		docaObj.setPAYEE_CARRIER(payeeCarrier);

		return docaObj;

		

	}

}
