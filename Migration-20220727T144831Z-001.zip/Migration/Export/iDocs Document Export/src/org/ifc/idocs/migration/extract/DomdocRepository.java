package org.ifc.idocs.migration.extract;

import lotus.domino.NotesException;

public class DomdocRepository {

	String serverName;
	//private String userName;
	//private String userPassword;
	private String foldermanPath;
	private DomdocLibrary library;
	private FoldermanDb folderman;

	public DomdocRepository(DomdocRepositoryDescriptor initparams) throws NotesException{
		this.serverName = initparams.getServername();
		//this.userName = initparams.getUsername();
		//this.userPassword = initparams.getUserpassword();
		this.foldermanPath = initparams.getFoldermanpath();
	}
	
	public FoldermanDb getFoldermanDb() throws NotesException {
		if (this.folderman == null) {
			this.folderman = new FoldermanDb(this, this.foldermanPath);
		}
		return this.folderman;
	}
	
	public void recycle() throws NotesException {
		if (this.library != null) {
			library.recycle();
		}
		if (this.folderman != null) {
			folderman.recycle();
		}
	}

	public DomdocLibrary getLibrary() throws NotesException {
		if (this.library == null) {
			this.library = new DomdocLibrary(this);
		} 
		return this.library;	
	}
	
}
