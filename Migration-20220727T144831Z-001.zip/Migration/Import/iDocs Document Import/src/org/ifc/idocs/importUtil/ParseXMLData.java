package org.ifc.idocs.importUtil;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.common.DfException;

public class ParseXMLData extends ImportUtility{
	// ReadMatadataXML for specific xml to parse its data to hashmap
	@SuppressWarnings("unchecked")
	static void ReadMatadataXML(String XMLPath) throws ParserConfigurationException, SAXException, IOException, DfException 
	{
		try
		{
		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
        Document doc = docBuilder.parse (new File(XMLPath));

        NodeList listOfVersions = doc.getElementsByTagName(idocsProperties.getProperty("MSG_DomdocDocument"));
        int totalVersions = listOfVersions.getLength();
//		dominoDocLogger.info("ParseXMLData :: ReadMatadataXML() : No of Versions : "+totalVersions);
        attributeValueList = new HashMap[totalVersions];
        for(int s=0; s<totalVersions; s++)
        {
        	Node versionNode = listOfVersions.item(s);
        	if(versionNode.getNodeType() == Node.ELEMENT_NODE)
            {
        		HashMap hm = new HashMap();
                Element versionElement = (Element)versionNode;
                //update attribute value list hashmap from xmlParse function
                attributeValueList[s] = xmlParse(versionElement, hm);
            }
        }

        //UpdateValueClass
        UpdateValues.updateAttrHM(0);

        //Import The Files.
        ImportDocument.importFile(totalVersions);
        
		}
		catch(Exception e)
		{
			failedXMLList.add(XMLPath);
			dominoDocLogger.warning("ParseXMLData :: ReadMetaDataXml() : XMLParsing Fail for : XMLPath : "+XMLPath+" : "+e.getMessage());
			e.printStackTrace();
		}
    }

	//store xml details in hashmap
	@SuppressWarnings("unchecked")
	private static HashMap xmlParse(Element elem,HashMap hm) throws DfException
	{
		String CSV = "";
		hm.put(idocsProperties.getProperty("MSG_VERSION"), elem.getAttribute(idocsProperties.getProperty("MSG_VERSION")));
		NodeList list = elem.getChildNodes();
		 for(int i=0;i<list.getLength();i++)
         {
         	Node firstPersonNode = list.item(i);
             if(firstPersonNode.getNodeType() == Node.ELEMENT_NODE)
             {
                 Element firstPersonElement = (Element)firstPersonNode;
                 NodeList textFNList = firstPersonElement.getChildNodes();
                 int length = textFNList.getLength();
                 switch(length)
                 {
	                 case 1 : 	String key = firstPersonElement.getNodeName();
	                 			textFNList = firstPersonElement.getElementsByTagName(idocsProperties.getProperty("MSG_VALUE_TAG"));
	                 			String value = textFNList.item(0).getChildNodes().item(0).getNodeValue().trim();
			         			if (value.contains("/")){
			         				value = value.replace("/", "\\");
			         			}
			         			if(key.equals(idocsProperties.getProperty("MSG_AUTHORORSENDER")))
			         			{
			         				hm.put(idocsProperties.getProperty("MSG_SENDER"), value);
			         			}
//			         			dominoDocLogger.info(" 88888888888888888888888888 Case 1 :: key : "+key+" Value : "+value);
			        	 		hm.put(key, value);
			        	 		break;
	
	                 case 0 : 	hm.put(firstPersonElement.getNodeName(),"");
	                	 		continue;
	 
	                 default :  key = firstPersonElement.getNodeName();
				      			NodeList activityList = firstPersonElement.getElementsByTagName(idocsProperties.getProperty("MSG_VALUE_TAG"));
				      			int count = activityList.getLength();
				      			for(int j=0;j<count;j++)
				     			{
				     				NodeList newList = textFNList.item(j).getChildNodes();
				     				int newLength = newList.getLength();
				     				switch(newLength)
				     				{
					     				case 1: if(textFNList.item(j).getChildNodes().item(0) != null)
							     				{
					     							CSV = CSV + textFNList.item(j).getChildNodes().item(0).getNodeValue().trim() + "#" ;
							     				}
					     						break;
					     						
					     				case 0:  break;
					     				default : HashMap newHM = new HashMap();
					     						  for(int x=0;x<newLength;x++){
						     						  if(newList.item(x).getChildNodes().item(0) != null)
									     			  {
								     						key = newList.item(x).getNodeName().toString();
								     						value = newList.item(x).getChildNodes().item(0).getNodeValue().trim();
								     						if (value.contains("/")){
										         				value = value.replace("/", "\\");
										         			}
									     					newHM.put(key, value);
									     			  }
					     						  }
					     						 String actor = "";

//							         			   System.out.println("Actor Attribute "+newHM.get(idocsProperties.getProperty("MSG_ACTOR")));
							         			   if(newHM.get(idocsProperties.getProperty("MSG_ACTOR"))!=null){
								         			   actor = newHM.get(idocsProperties.getProperty("MSG_ACTOR")).toString();
							         			   }else{
							         				   actor="";
							         			   }
					     						   if (actor.contains("'")){
					     							  actor = actor.replaceAll("'", "''");
								         		   }
									               String action = "";
							         			   if(newHM.get(idocsProperties.getProperty("MSG_ACTION"))!=null){
							         				   action = newHM.get(idocsProperties.getProperty("MSG_ACTION")).toString();
							         			    }else{
							         				   action="";
							         			    }
									            	if (action.contains("'")){
									            		action = action.replaceAll("'", "''");
								         			}
									            	String timeStamp = newHM.get(idocsProperties.getProperty("MSG_TIMESTAMP")).toString();
									            	IDfQuery dfquery = new DfQuery();
							 	            		String query = idocsProperties.getProperty("QRY_INSERT_AUDIT_REPORT")+hm.get(idocsProperties.getProperty("MSG_VERSION")) +"',date('"+timeStamp+"','dd\\mm\\yyyy hh\\mi\\ss am z'),'"+action+"','"+actor+"')";
							 	            		dfquery.setDQL(query);
							 	            		dfquery.execute(dfSession, IDfQuery.DF_EXEC_QUERY );
					     						  }
			 	            	}
				     			if (CSV.contains("/")){
			         				value = CSV.replace("/", "\\");
			         			}
//				     			dominoDocLogger.info("22222222222222222222222 Case 1 :: key : "+key+" CSV : "+CSV);
				     			hm.put(key, CSV);
				     			CSV="";
				}
             }
         }
		return hm;
	}
}
