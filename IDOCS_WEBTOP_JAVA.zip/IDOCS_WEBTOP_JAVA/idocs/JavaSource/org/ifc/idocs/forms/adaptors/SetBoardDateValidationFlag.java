
package org.ifc.idocs.forms.adaptors;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.documentum.fc.common.DfLogger;
import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.IAdaptorParameter;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.xforms.engine.adaptor.datasource.ISetValueAdaptor;

public class SetBoardDateValidationFlag implements ISetValueAdaptor {

	public Object execute(IAdaptorParameter[] parameters)
			throws AdaptorException {
		DfLogger.info(this,"SetBoardDateValidationFlag:: SetBoardDateValidationFlag",null,null);
		String envCat="";
		String dateStr="";
		//if (parameters.length == 1) {
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			for (int i=0;i<parameters.length;i++)
		   	{
		   		DfLogger.info(this,"Inside for: "+parameters[i].getValue(),null,null);
		   		
				if (null!=parameters[i].getValue()&& !"".equals(parameters[i].getValue()))
					dateStr=parameters[0].getValue();
					envCat=parameters[1].getValue();
		   	}
			//IAdaptorParameter parameter = parameters[0];
			int dateDiff = 0;
			Date date = null;
			Date now = new Date();

			if (dateStr != null && dateStr.length() > 0) {
				try {
					date = dateFormat.parse(dateStr);

				} catch (java.text.ParseException e) {
					DfLogger.error(this,": <<Exception>> : "+e.getMessage(),null,e);
				}

				 dateDiff =  (int)((date.getTime()-now.getTime())/(1000*60*60*24));
				//String dateInStr=Integer.toString(dateDiff);
				if (dateDiff < 31 && !envCat.equalsIgnoreCase("A"))
					dateDiff = 30;
				else if (dateDiff < 61 && envCat.equalsIgnoreCase("A"))
					dateDiff = 60;

			}

		//}

		return dateDiff;
	}

	public void destroy() throws AdaptorException {
	}

	public void init(IAdaptorConfiguration arg0) throws AdaptorException {
	}
}