package org.ifc.idocs.workflow.taskmanager;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.component.Component;

public class ASTaskConfirmation extends Component {

	@Override
	public void onInit(ArgumentList arg0) {
		DfLogger.info(this, "ASTaskConfirmation called",null,null);
		super.onInit(arg0);
	}
	
	
}
