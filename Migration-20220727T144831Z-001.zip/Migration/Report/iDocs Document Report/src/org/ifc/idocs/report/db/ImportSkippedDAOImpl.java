package org.ifc.idocs.report.db;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Logger;

import org.ifc.idocs.report.common.LogHelper;

public class ImportSkippedDAOImpl extends DBFactory{
	
	private static Calendar calender = null;
	private Logger exportDocLogger = LogHelper.getLogger(ImportSkippedDAOImpl.class);
	private int docDiff = 0;
	private Set<String> missingSet = new HashSet<String>();
	private Set<String> sourceSet = new HashSet<String>();
	private Set<String> destSet = new HashSet<String>();

	private long st = 0, et = 0;
	
	public static void main(String args[]) throws SQLException, IOException{
		ImportSkippedDAOImpl iSkipped = new ImportSkippedDAOImpl();
		iSkipped.importSkipped("28OCT11");
	}
	
	public void importSkipped(String prefix) throws IOException, NumberFormatException, SQLException{
		try{
			calender = Calendar.getInstance();
			st = calender.getTimeInMillis(); 
			idocsProperties.load(inputStream);
			getConnection();
			getDocumentReport(prefix + "_PRJ", "PROJECTS");		
			getDocumentReport(prefix + "_PTR", "INSTITUTIONS");			
			conn.close();
			conn = null;			
			calender = Calendar.getInstance();
			et = calender.getTimeInMillis();
			exportDocLogger.warning("Total Time in Minutes : " + (et - st)/60000);
			System.gc();
		}catch(IOException ioe){
			ioe.printStackTrace();
		}catch(NumberFormatException nfe){
			nfe.printStackTrace();
		}catch(SQLException sqle){
			sqle.printStackTrace();
		}
	}

	public void getDocumentReport(String prefix, String folderTypeCode) throws SQLException{
		String idQry = "SELECT DISTINCT FOLDER_VALUE_CODE FROM RECON_DOC_COUNT_REPORT WHERE (FOLDER_TYPE_CODE != 'COUNTRY') AND FOLDER_TYPE_CODE='" + folderTypeCode + "' AND REPORT_UTILITY_CODE LIKE '" + prefix + "%' ORDER BY FOLDER_VALUE_CODE ASC";
		Set<String> fololderValueSet = new HashSet<String>(fireQuery(idQry));
		ArrayList<String> fololderValueList = new ArrayList<String>(fololderValueSet);
		int min = 0, max = 500;
		while(max <= fololderValueSet.size()){
			ArrayList<String> fololderValueSubList = new ArrayList<String>(fololderValueList.subList(min, max));
			String  idString = fololderValueSubList.toString();
			idString = idString.replaceAll(", ", "', '");
			idString = idString.substring(1, idString.length()-1);
			exportDocLogger.warning(min + " - " + max);
			executeQuery(prefix, folderTypeCode, idString);
			min = max;
			max += 500;
		}
		if(missingSet.size() > 0){
			updateImportSkipped(prefix, missingSet);
		}
		missingSet.clear();
	}

	private Set<String> fireQuery(String qry) throws SQLException{
		Set<String> returnVal = new HashSet<String>();
//		exportDocLogger.warning(qry);
		PreparedStatement stmt = conn.prepareStatement(qry);
		rs = stmt.executeQuery();
		while (rs.next()){
			returnVal.add(rs.getString(1));			
		}
		rs.close();
		stmt.close();
		return returnVal;
	}

	private void executeQuery(String prefix, String folderTypeCode, String idString) throws SQLException {
		sourceSet.clear();destSet.clear();
		sourceSet.addAll(fireQuery("SOURCE_DOC_ID", "RECON_SECURITY_REPORT", idString, folderTypeCode, prefix));
		destSet.addAll(fireQuery("DOC_ID", "IMPORT_COMPLETED_DOCS", idString, folderTypeCode, prefix));
		sourceSet.removeAll(destSet);
		docDiff = docDiff + sourceSet.size();
		missingSet.addAll(sourceSet);
	}

	private void updateImportSkipped(String setCode, Set<String> missingSet) throws SQLException {
		Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		conn.setAutoCommit(false);
		for(String docUnid : missingSet){
			stmt.addBatch("INSERT INTO IMPORT_SKIPPED_DOCS VALUES ('" + setCode + "', '" + docUnid + "')");
		}
		int[] updateCounts = stmt.executeBatch();
		exportDocLogger.warning("Document Report saved : " +  updateCounts.length);
		stmt.close();
		conn.commit();
		System.gc();
	}

	private Set<String> fireQuery(String column, String tableName, String fvCode, String folderTypeCode, String prefix) throws SQLException {
		String qry = "SELECT DISTINCT " + column + " FROM " + tableName + " WHERE FOLDER_VALUE_CODE in ('" 
			+ fvCode + "') AND FOLDER_TYPE_CODE='" + folderTypeCode + "' AND REPORT_UTILITY_CODE LIKE '" + prefix + "%'";
		
		Set<String> returnVal = new HashSet<String>();
//		exportDocLogger.warning(qry);
		PreparedStatement stmt = conn.prepareStatement(qry);
		rs = stmt.executeQuery();
		while (rs.next()){
			returnVal.add(rs.getString(1));			
		}
		rs.close();
		stmt.close();
		return returnVal;
	}
}
