package com.SWBC.RulesService;

import static com.SWBC.utilities.BRMConstants.DATE_FORMAT;
import static com.SWBC.utilities.BRMConstants.NULL_DATE_VALUE;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import com.SWBC.DataService.TrecService;
import com.SWBC.model.Brm_loan_info;
import com.SWBC.model.Brm_processing_info;
import com.SWBC.model.Trec;
import com.SWBC.utilities.BRMUtilities;

@Service("SetAPIAttributeValues")
public class SetAPIAttributeValues {

	// private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private Environment env;
	@Autowired
	private ArrayList<String> getAllTransTypes;

	public Trec checkTransType(String transType, Brm_processing_info proc_info, Brm_loan_info loan_info,
			TrecService trecService, Trec trec) {

		if (getAllTransTypes.contains(transType)) {
			trec.setRuleVersion("API_VERSION");
			return setCommonAttr(proc_info, loan_info, trecService, trec);
		} else {
			return null;
		}

	}

	public Trec setBICDate(Trec trec, List<Map<String, Object>> bicRows) {
		for (Map row : bicRows) {

			try {
				System.out.println(row.get("BICEffectiveDate").toString());
				
				trec.setbICEffectiveDate(new SimpleDateFormat("yyyy-MM-dd").parse(row.get("BICEffectiveDate").toString()));
				trec.setbICExpirationDate(new SimpleDateFormat("yyyy-MM-dd").parse(row.get("BICExpirationDate").toString()));
				trec.setIs_Letter_cycle(row.get("IS_LETTER_CYCLE").toString());
				
			} catch (Exception e) {
			
			}
		

		}

		return trec;

	}

	public String trimPolicyNumber(String policyNo) {
		policyNo = policyNo.replaceAll(env.getRequiredProperty("policy.number.zeros.regex"), "").trim();
		policyNo = policyNo.replaceAll(env.getRequiredProperty("policy.number.regex"), "").trim();
		return policyNo;
	}

	public Trec setCommonAttr(Brm_processing_info proc_info, Brm_loan_info loan_info, TrecService trecService,
			Trec trec) {

		List<String> xlcPolicyCancelReasonList = trecService.getPolicyCancelReason();
		List<String> xlcTransactionInsurer = trecService.getTransactionInsurer();

		

			trec.setTransaction_id(proc_info.getTransaction_id().toString().trim());
			trec.setPolicyCancelReasonList(xlcPolicyCancelReasonList);
			trec.setTransactionInsurerList(xlcTransactionInsurer);
			trec.setTransaction_type(proc_info.getTransaction_type().toString().trim());
			trec.setPolicy_number(trimPolicyNumber(proc_info.getTransaction_policy_no().toString().trim()));
			trec.setPolicy_cancel_date(proc_info.getTransaction_cancel_date());
			trec.setTransactionInsurer(proc_info.getTransactionInsurer().toString().trim());
			// trec.setTransaction_document_date(BRMUtilities.evaluateNullDate(proc_info.getTransaction_doc_issue_date()));
			trec.setTransaction_document_date(proc_info.getTransaction_doc_issue_date());
			// trec.setTransaction_effective_date(
			// BRMUtilities.evaluateNullDate(proc_info.getTransaction_effective_date()));
			trec.setPolicy_cancel_reason(proc_info.getTransaction_policy_reason().toString().trim());
			trec.setMortgageeTransaction(proc_info.getTransaction_mortgagee_name().toString().trim());
			trec.setPolicyDecision(proc_info.getTransactionPolicyDecision().toString().trim());
			trec.setDoc_cancel_date(BRMUtilities.evaluateNullDate(proc_info.getTransaction_cancel_date()));
			trec.setDoc_cancel_date(BRMUtilities.evaluateNullDate(proc_info.getTransaction_cancel_date()));
			trec.setTransaction_cov_type(proc_info.getTransaction_cov_type());
			trec.setTransaction_effective_date(proc_info.getTransaction_effective_date());
			System.out.println(proc_info.getTransaction_effective_date().toString());
			// - Dup
			trec.setTransaction_impairment_code(proc_info.getTransaction_impairment_code());
			trec.setTransaction_em_flood_zone(proc_info.getTransaction_flood_zone());
			trec.setTransaction_em_cov_amt(proc_info.getTransaction_coverage_amt());
			trec.setTransaction_premium_amt(proc_info.getTransaction_premium_amt());
			trec.setTransaction_expiration_date(
					BRMUtilities.evaluateNullDate(proc_info.getTransaction_expiration_date()));
			trec.setTransaction_premium_net_amt(proc_info.getTransaction_premium_net_amt());
			trec.setReinstatement_date(BRMUtilities.evaluateNullDate(proc_info.getTransaction_reinstatement_date()));
			trec.setTransaction_deductible_amt(proc_info.getTransaction_deductible_amt());
			trec.setTransaction_edi_deductible_per(proc_info.getTransaction_edi_deductible_per());
			trec.setTransaction_non_edi_deductible_per(proc_info.getTransaction_non_edi_deductible_per());
			// trec.setPolicy_number(trimPolicyNumber(proc_info.getTransaction_policy_no().toString().trim()));
			// --Dup
			// trec.setTransactionInsurer(proc_info.getTransactionInsurer());
			// --D

			// trec.setLoan_policy_no(trimPolicyNumber(loan_info.getLoan_policy_no().toString().trim()));
			// --Dup
			// trec.setLoanExpirationDate(loan_info.getLoan_expiration_date());
			// --Dup
			trec.setLoan_doc_issue_date(loan_info.getLoan_doc_issue_date());
			trec.setLoan_insurance_status(loan_info.getLoan_insur_status().toString().trim());
			trec.setMortgageeLoan(loan_info.getLoan_mortgagee_name().toString().trim());
			trec.setEscrowClient(loan_info.getLoan_escrow_client().toString().trim());
			trec.setEscrowLine(loan_info.getLoan_escrow_code().toString().trim());
			trec.setTrec_loan_es_bill_date(loan_info.getLoan_pme_bill_date());
			trec.setLoan_uninsured_date(BRMUtilities.evaluateNullDate(loan_info.getLoan_uninsured_date()));
			trec.setLoan_insurance_type(loan_info.getLoan_insur_type().toString().trim());
			trec.setPolicy_expiration_date(BRMUtilities.evaluateNullDate(loan_info.getLoan_expiration_date()));
			trec.setLoanHistReiDate(BRMUtilities.evaluateNullDate(loan_info.getLoan_his_rei_date()));
			trec.setLoanCompanyName(loan_info.getLoan_company_name().toString().trim());
			// trec.setLoanHistoryDualPolicy(loan_info.getLoan_his_dual_policy_no());
			// --Dup
			trec.setPolicyNumberScore(loan_info.getPolicyScore());
			trec.setLoanEffectiveDate(BRMUtilities.evaluateNullDate(loan_info.getLoan_effective_date()));
			trec.setPMEDayDiff(loan_info.getPMEDays());
			trec.setREIDayDiff(loan_info.getREIDays());
			trec.setDual_policy_score(loan_info.getLoan_dual_policy_score());
			trec.setTransaction_pme_policy_score(loan_info.getLoan_pme_policy_score());
			trec.setPme_current_term(loan_info.getLoan_pme_current_term());
			// trec.setTransaction_pme_policy_no(trimPolicyNumber(loan_info.getLoan_pme_es_policy_no()));
			// trec.setLoan_policy_no(trimPolicyNumber(loan_info.getLoan_policy_no().toString().trim()));
			// trec.setTransaction_pme_policy_no(trimPolicyNumber(loan_info.getLoan_pme_es_policy_no()));
			trec.setLoan_policy_no(trimPolicyNumber(loan_info.getLoan_policy_no().toString().trim()));
			trec.setTransaction_pme_policy_no(loan_info.getLoan_pme_es_policy_no() == null ? ""
					: trimPolicyNumber(loan_info.getLoan_pme_es_policy_no()));

			trec.setLoan_policy_no(loan_info.getLoan_policy_no().toString().trim() == null ? ""
					: trimPolicyNumber(loan_info.getLoan_policy_no().toString().trim()));

			// trec.setLoan_policy_no(trimPolicyNumber(loan_info.getLoan_policy_no().toString().trim()));
			// trec.setLoanHistoryDualPolicy(loan_info.getLoan_his_dual_policy_no().toString().trim());
			// --Dup
			trec.setReiFMRDateCheck(loan_info.getRei_fmr_date_check());
			trec.setLoan_pme_premium_amt(loan_info.getLoan_pme_premium_amt());
			// trec.setLoan_policy_no(loan_info.getLoan_policy_no().toString().trim());
			// --Dup
			trec.setLoanHistoryDualPolicy(
					trimPolicyNumber(loan_info.getLoan_his_dual_policy_no().toString().trim()));
			trec.setLoan_es_check_no(loan_info.getLoan_es_check_no());
			trec.setTrec_loan_es_eff_date(loan_info.getLoan_es_eff_date());
			trec.setTrec_loan_es_exp_date(loan_info.getLoan_es_exp_date());
			trec.setTrec_loan_es_rcvd_date(loan_info.getLoan_es_rcvd_date());
			trec.setSwbc_chk(loan_info.getLoan_swbc_check());
			trec.setPme_creation_date(loan_info.getLoan_pme_creation_date());
			trec.setLoan_pme_effective_date(loan_info.getLoan_pme_effective_date());
			trec.setLoan_pme_expiration_date(loan_info.getLoan_pme_expiration_date());
			trec.setLoanExpirationDate(BRMUtilities.evaluateNullDate(loan_info.getLoan_expiration_date()));
			trec.setLoan_impairment_code(loan_info.getLoan_is_impairment_code());
			trec.setLoan_ag_spare_code_2(loan_info.getLoan_ag_spare_code());
			trec.setLoan_ag_flood_zone(loan_info.getLoan_flood_zone());
			trec.setLoan_ag_coverage_amt(loan_info.getLoan_ag_coverage_amt());
			trec.setLoan_transaction_id(loan_info.getLoan_transaction_id());
			// trec.setMortgageeLoan(loan_info.getLoan_mortgagee_name());--Dup
			trec.setLoanDisbursementFlag(loan_info.getDisbursementFlag());
			// trec.setLoanCompanyName(loan_info.getLoan_company_name());
			// --Dup
			// trec.setMortgageeTransaction(proc_info.getTransaction_mortgagee_name());
			// --Dup
			trec.setLoan_ag_deductible_amt(loan_info.getLoan_ag_deductible_amt());
			trec.setLoan_ag_deductible_pct(loan_info.getLoan_ag_deductible_pct());
			trec.setLoan_escrow_premium_amt(loan_info.getLoan_escrow_premium_amt());

			// Set GAP Info
			trec.setLoan_gap_line(loan_info.getLoan_gap_line());
			trec.setLoan_gap_effective_date(loan_info.getLoan_gap_effective_date());
			trec.setLoan_gap_expiration_date(loan_info.getLoan_gap_expiration_date());

			// Get NAIC Code
			trec.setTransaction_naic_code(proc_info.getTransaction_naic_code().toString().trim());

			trec.setPolicy_type(proc_info.getPolicy_type());
			trec.setDelete_counter(proc_info.getDelete_counter());

			trec.setAccount_no(proc_info.getAccountNumber().trim());

			trec.setLoanNo(proc_info.getTransaction_loan_no().trim());
			trec.setTransactionSuffix(proc_info.getTansactionLoanSuffix().trim());

			trec.setLoanVSIPolicyNumber(loan_info.getVSIPolicyNo().trim());

			trec.setTransaction_operator_id(proc_info.getTransaction_operator_id());

			trec.setEs_void(loan_info.getEs_void().trim());

			trec.setLoan_ag_spare_code3(loan_info.getLoan_ag_spare_code3().trim());
//			trec.setbICEffectiveDate(loan_info.getbICEffectiveDate());
//			trec.setbICExpirationDate(loan_info.getbICExpirationDate());
//			trec.setIs_Letter_cycle(loan_info.getIs_Letter_cycle());
			
			
			try {
				trec.setbICEffectiveDate((java.util.Date) loan_info.getbICEffectiveDate() == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) loan_info.getbICEffectiveDate());
				
				trec.setbICExpirationDate((java.util.Date) loan_info.getbICExpirationDate() == null
						? new SimpleDateFormat(DATE_FORMAT).parse(NULL_DATE_VALUE)
						: (java.util.Date) loan_info.getbICExpirationDate());
				
				trec.setIs_Letter_cycle(loan_info.getIs_Letter_cycle() == null ? "" : loan_info.getIs_Letter_cycle().toString().trim());
				
			} catch (ParseException e) {

				
			}

			
			trec.setWaive_code(loan_info.getWaive_code());
			trec.setLoan_board_date(loan_info.getLoan_board_date());
			trec.setMax_prem_amt(Double.parseDouble(loan_info.getMax_prem_amt()));
			trec.setTol_prem_pct(Double.parseDouble(loan_info.getTol_prem_pct()));
			

		return trec;

	}
}
