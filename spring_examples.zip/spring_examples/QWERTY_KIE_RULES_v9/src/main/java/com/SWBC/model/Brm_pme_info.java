package com.SWBC.model;

import java.util.Date;

public class Brm_pme_info 
{
	
	private String transaction_id;
	private String transaction_type;
	private String es_account_no;
	private String es_loan_no;
	private String es_loan_suffix;
	private String es_coverage_type;
	private String es_policy_no;
	private Date es_bill_date;
	private Date es_eff_date;
	private Date es_expiration_date;
	private Date es_date_added;
	private Integer es_current_term;
	private Double es_premium_amt;
	private String es_no_pme_days;
	
	public String getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}
	public String getTransaction_type() {
		return transaction_type;
	}
	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}
	public String getEs_account_no() {
		return es_account_no;
	}
	public void setEs_account_no(String es_account_no) {
		this.es_account_no = es_account_no;
	}
	public String getEs_loan_no() {
		return es_loan_no;
	}
	public void setEs_loan_no(String es_loan_no) {
		this.es_loan_no = es_loan_no;
	}
	public String getEs_loan_suffix() {
		return es_loan_suffix;
	}
	public void setEs_loan_suffix(String es_loan_suffix) {
		this.es_loan_suffix = es_loan_suffix;
	}
	public String getEs_coverage_type() {
		return es_coverage_type;
	}
	public void setEs_coverage_type(String es_coverage_type) {
		this.es_coverage_type = es_coverage_type;
	}
	public String getEs_policy_no() {
		return es_policy_no;
	}
	public void setEs_policy_no(String es_policy_no) {
		this.es_policy_no = es_policy_no;
	}
	public Date getEs_bill_date() {
		return es_bill_date;
	}
	public void setEs_bill_date(Date es_bill_date) {
		this.es_bill_date = es_bill_date;
	}
	public Date getEs_eff_date() {
		return es_eff_date;
	}
	public void setEs_eff_date(Date es_eff_date) {
		this.es_eff_date = es_eff_date;
	}
	public Date getEs_expiration_date() {
		return es_expiration_date;
	}
	public void setEs_expiration_date(Date es_expiration_date) {
		this.es_expiration_date = es_expiration_date;
	}
	public Date getEs_date_added() {
		return es_date_added;
	}
	public void setEs_date_added(Date es_date_added) {
		this.es_date_added = es_date_added;
	}
	public Integer getEs_current_term() {
		return es_current_term;
	}
	public void setEs_current_term(Integer es_current_term) {
		this.es_current_term = es_current_term;
	}
	public Double getEs_premium_amt() {
		return es_premium_amt;
	}
	public void setEs_premium_amt(Double es_premium_amt) {
		this.es_premium_amt = es_premium_amt;
	}
	public String getEs_no_pme_days() {
		return es_no_pme_days;
	}
	public void setEs_no_pme_days(String es_no_pme_days) {
		this.es_no_pme_days = es_no_pme_days;
	}

}
