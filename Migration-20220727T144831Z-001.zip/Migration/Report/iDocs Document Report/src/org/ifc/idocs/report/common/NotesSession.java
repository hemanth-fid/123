package org.ifc.idocs.report.common;

import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

/**
 * @author SPankajamsadanan
 *
 */
public class NotesSession {
	
	private NotesSession() {}
	private static Session session = null;

	/**
	 * getInstance method
	 * @return Session
	 * @throws NotesException
	 */
	public static Session getInstance(){
		if (session == null) {
			try {
				
				AppConfig config = AppConfig.getInstance();
				@SuppressWarnings("unused")
				String notesPwd = config.getString("connection.notespassword");
				NotesThread.sinitThread(); 
				session = NotesFactory.createSession();	//for deployment
//				session = NotesFactory.createSessionWithFullAccess(notesPwd);	 //for local development
			} catch (NotesException e) {
				System.out.println("Lotus Notes Password is wrong. Please check config.xml file.");
				System.exit(0);
			}
		}
		return session;
	}

	/**
	 * terminate method terminates session
	 * @return void
	 */
	public static void terminate() {
		if (session != null) {
			try {
				session.recycle();
			} catch (NotesException e) {
				e.printStackTrace();
			}
			session = null;
			NotesThread.stermThread();
		}
	}
}
