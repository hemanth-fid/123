package org.ifc.idocs.migration.extract;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import lotus.domino.Database;
import lotus.domino.DbDirectory;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.View;

import org.ifc.idocs.migration.ExportUtilityMain;
import org.ifc.idocs.migration.common.AppConfig;
import org.ifc.idocs.migration.common.CountryRegionMap;

/**
 * @author SPankajamsadanan
 * 
 * Logic: Open library DB->get filecabinet(which matches the region & country as per extraction criteria ID given
 * in confi.xml)-> from file cabinet, get the target binder database replica ID.
 * Once you get handle of binderDB, from the server configuration you will get all assosiated document database.
 * Get the discussion document view.Filter and get the parent documents.Get the docid of parent.For each docID,
 * search the document Db for all matching documents & print the details into xml file.
 * Update summary into extraction utility info table 
 *  
 */

public class Discussion {

	/**
	 * extractDocuments method
	 * @param region
	 * @param country
	 * @param displayPath
	 * @param utilityId
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static void extractDocuments(String region, String country, String displayPath, String utilityId) throws Exception {
		Object document = null;
		AppConfig config  =  AppConfig.getInstance();
		Logger exportDocLogger  =  LogHelper.getLogger(ExportUtilityMain.class);
		//exportDocLogger.info("iDocs- Discussion Document Extraction Started");
		Database binderDb = null;
		DbDirectory dbdir = null;
		Database Lib =null;
		View mainView  = null;
		DocumentCollection docCollection = null;
		Document doc = null;	
		View binderView =null;
		Document binderProfile = null;
		Document tempDoc = null;
		Vector documentDb = null;
		try {
			String server = config.getString("repository.server");	//for getting server name
			String dbReplicaId;
			CountryRegionMap countryRegionMap = new CountryRegionMap();
			String realRegion = countryRegionMap.getCountryRegion(country);
			
			String libraryDbPath = config.getString("repository.libPath");
			dbdir  =  NotesSession.getInstance().getDbDirectory(server);
			Lib = dbdir.openDatabase(libraryDbPath);
			mainView  =  Lib.getView("vaMainView");	//getting the main view from lib database
			if (realRegion.equals("EUROPE")){
				realRegion="ECA";
			}
			docCollection = mainView.getAllDocumentsByKey(realRegion);
			exportDocLogger.warning("Count of navigation/binder documents in library with region as ~ " + realRegion + " = " + docCollection.getCount());
			doc = docCollection.getFirstDocument();
			Integer docCounter = 0;
			
			while (doc != null){
				String title = doc.getItemValueString("DbTitle");
				if (title.equals(country)){
					dbReplicaId = doc.getItemValueString("BinderDBReplicaID");	//getting replica ID of target binder DB from filecabinet
					binderDb = dbdir.openDatabaseByReplicaID(dbReplicaId);	//opening the binder db
					binderView = binderDb.getView("vaServerProfileList");
					binderProfile = binderView.getFirstDocument();
					documentDb = binderProfile.getItemValue("ListOfDocDBs");
					Integer docDbCount = documentDb.size();	//getting the number of document databases for this binder
					exportDocLogger.warning(docDbCount + " ~ document databases ~ " + documentDb + " ~ found for region ~ " + realRegion + " ~ country ~ " + country);
					docCounter = 0;
					
					while(docCounter < docDbCount){
						 document = documentDb.elementAt(docCounter);
						//exportDocLogger.info(docCounter + "'th element = " + document);
						DiscussionMetadata.getDiscussionDocs(documentDb, document, dbdir, displayPath, utilityId, region);
						docCounter++;
					}
				}
				else{
					exportDocLogger.warning("Skipping database...as navigation/binder document title = "+title+" doesnt match the target country "+country);
//					exportDocLogger.warning("No matching discussion document databases found for region ~ " + region + " ~ country ~ " + country);
				}
				tempDoc = docCollection.getNextDocument();
				//doc.recycle commented as it was not completing discussion extraction. Also was not throwing any
				//error message
//				doc.recycle();
				doc= tempDoc;
//				doc = docCollection.getNextDocument(); 
//				if (doc!= null ){
//					doc.recycle();
//				}
				documentDb  = null;
				if(binderProfile != null){
					binderProfile.recycle();
				}
				if(binderView != null){
					binderView.recycle();
				}
				if (binderDb != null){
					binderDb.recycle();
				}
			}
			docCollection.recycle();
			mainView.recycle();
			Lib.recycle();
			dbdir.recycle();
			
			
		} catch (NotesException e) {
			exportDocLogger.warning(document+" ~Database open failed. Please provide correct library path config.xml file");
			exportDocLogger.log(Level.WARNING,"Discussion.java-Exception", e);
		}
	}	
}



