/**
 * IDocDocbaseAttributeTagUtility - Utility Class to have the common 
 * methods required for both DocbaseAttributeTag and 
 * 
 * @author SKurian1
 * 
 * #####################################################################
 * Author		DateofChange	Version		ModificationHistory
 * #####################################################################
 * 
 * #####################################################################
 */
package org.ifc.idocs.control.docbase;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfACL;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.formext.control.docbase.DocbaseAttributeValue;

public class IDocDocbaseAttributeTagUtility {
	
	private static final String I_ALL_USERS_NAMES = "i_all_users_names";
	private static final String R_POLICY_ID_0000000000000000_AND_R_OBJECT_ID = " r_policy_id <>'0000000000000000' and r_object_id='";
	private static final String SELECT_R_CURRENT_STATE_FROM_DM_SYSOBJECT_WHERE_AND = "select r_current_state from dm_sysobject where and ";
	private static final String MSG_R_CURRENT_STATE = "r_current_state";
	private static final String MSG_FROM_DM_SYSOBJECT_ALL_WHERE_R_OBJECT_ID = " from dm_sysobject(all) where r_object_id='";
	private static final String MSG_FROM_DM_SYSOBJECT_WHERE_I_CHRONICLE_ID = " from dm_sysobject where i_chronicle_id='";
	private static final String MSG_FROM_DM_SYSOBJECT_WHERE_R_OBJECT_ID = " from dm_sysobject where r_object_id='";
	private static final String MSG_SELECT = "select ";
	private static final String QRY_VARIABLE_TARGET_ATTR = "<targetAttr>";
	private static final String QRY_VARIABLE_OBJECT_TYPE = "<objectType>";
	private static final String QRY_VARIABLE_VALIDATING_ATTR = "<validatingAttr>";
	private static final String QRY_VARIABLE_COMMA_SEPARATED_STRING = "<commaSeparatedStrVal>";
	
	/**
	 * This method checks whether the logged in user has Change_Permit 
	 * permission on the document.
	 * @param bReadonly - Argument Passed by Documentum
	 * @param sysObject
	 * @param value
	 * @return
	 * @throws DfException
	 */
	public static boolean canFieldBeEditable(boolean bReadonly, IDfSysObject sysObject,
			DocbaseAttributeValue value) throws DfException {
		DfLogger.debug(IDocDocbaseAttributeTagUtility.class, " : canEditable() : "+ value.getAttribute(), null, null);
		DfLogger.debug(IDocDocbaseAttributeTagUtility.class," : canEditable() : Current Object Name : "+ sysObject.getObjectName()+" \t DocbaseAttributeValue :: "+value.getAttribute(),null, null);
		if (sysObject!=null && sysObject.hasPermission(
				IDfACL.DF_XPERMIT_CHANGE_PERMIT_STR, sysObject.getObjectSession().getLoginUserName()) == false) {
			DfLogger.debug(IDocDocbaseAttributeTagUtility.class, sysObject.getObjectSession().getLoginUserName()+ " Don't have CHANGE PERMIT", null, null);
			DfLogger.debug(IDocDocbaseAttributeTagUtility.class," : canEditable() : Render the Attribute As ReadOnly", null,null);
			bReadonly = IDocsConstants.FLAG_RENDER_READONLY ;
		} else {
			DfLogger.debug(IDocDocbaseAttributeTagUtility.class, sysObject.getObjectSession().getLoginUserName()+ " has CHANGE PERMIT", null, null);
		}
		return bReadonly;
	}

	/**
	 * canEditableInReleasedState method is used to decide whether the attribute can be editable in the UI
	 * for the documents which are in released state
	 * @param currentSysObject    -  currentSysObject
	 * @param currentReadonlyFlag - currentValue of ReadOnly Flag
	 * @return
	 */
	public static boolean canEditableInReleasedState(IDfSession session,String strCurrentSysObjectId,boolean currentReadonlyFlag) {
		DfLogger.debug(IDocDocbaseAttributeTagUtility.class, "canEditableInReleasedState Enter ID =" + strCurrentSysObjectId, null, null);
		boolean canEditableFlag = false;
		try {
			String currentObjectType = getSysObjectAttribute(session, strCurrentSysObjectId, IDocsConstants.MSG_R_OBJECT_TYPE);
			DfLogger.debug(IDocDocbaseAttributeTagUtility.class, "canEditableInReleasedState currentObjectType =" + currentObjectType, null, null);
			String currentSecurityClassificationCode = getSingleAttributeValue(session, strCurrentSysObjectId,
					IDocsConstants.MSG_SEC_CLASSIFICATION_CODE, currentObjectType) ;
			DfLogger.debug(IDocDocbaseAttributeTagUtility.class, "canEditableInReleasedState currentSecurityClassificationCode =" + currentSecurityClassificationCode, null, null);
			if(IDocsConstants.MSG_OFFICIAL_CODE.equals(currentSecurityClassificationCode)){
				/** Official Use Only */
				if(IDocsConstants.MSG_IDOCS_PROJECT_DOC.equals(currentObjectType)){
					/** Project Document READ ONLY to idocs_pr_<%projid%>_ed_off_grp */					
					canEditableFlag = isUserMemberOfGroup(session,strCurrentSysObjectId,IDocsConstants.MSG_PR_ED_OFF_GROUP,IDocsConstants.MSG_IDOCS_PROJECT_DOC);
				}else if(IDocsConstants.MSG_IDOCS_INSTITUTION_DOC.equals(currentObjectType)){							
				/**  Institution Document	READ ONLY to idocs_inst_<%inst nbr%>_ed_off_grp */
					canEditableFlag = isUserMemberOfGroup(session,strCurrentSysObjectId,IDocsConstants.MSG_INST_ED_OFF_GRUP,IDocsConstants.MSG_IDOCS_INSTITUTION_DOC);
				} else if(IDocsConstants.MSG_IDOCS_COUNTRY_DOC.equals(currentObjectType)){	
				/** Country Document NO UPDATE */
					DfLogger.debug(IDocDocbaseAttributeTagUtility.class, "canEditableInReleasedState() : Skip Country Document ", null, null);
				}else{
				/** Unknown Type */
					DfLogger.debug(IDocDocbaseAttributeTagUtility.class, "canEditableInReleasedState Leave : " +
							"Unknown Object Type = " + currentObjectType , null, null);
					return currentReadonlyFlag ;
				}
			}else if(IDocsConstants.MSG_CONFIDENTIAL_CODE.equals(currentSecurityClassificationCode)){
				/** Confidential  */
				if(IDocsConstants.MSG_IDOCS_PROJECT_DOC.equals(currentObjectType)){
				/** Project Document READ ONLY to idocs_pr_<%projid%>_ed_con_grp */
					canEditableFlag = isUserMemberOfGroup(session,strCurrentSysObjectId,IDocsConstants.MSG_PR_ED_CON_GROUP,IDocsConstants.MSG_IDOCS_PROJECT_DOC);
				}else if(IDocsConstants.MSG_IDOCS_INSTITUTION_DOC.equals(currentObjectType)){
				/**	Institution Document READ ONLY to idocs_inst_<%inst nbr%>_ed_con_grp */
					canEditableFlag = isUserMemberOfGroup(session,strCurrentSysObjectId,IDocsConstants.MSG_INST_ED_CON_GROUP,IDocsConstants.MSG_IDOCS_INSTITUTION_DOC);
				}else if(IDocsConstants.MSG_IDOCS_COUNTRY_DOC.equals(currentObjectType)){
				/** Country Document NO UPDATE */
					DfLogger.debug(IDocDocbaseAttributeTagUtility.class, "canEditableInReleasedState() : Skip Country Document ", null, null);
				}else{
				/** Unknown Type */
					DfLogger.debug(IDocDocbaseAttributeTagUtility.class, "canEditableInReleasedState Leave : " +
							"Unknown Object Type = " + currentObjectType , null, null);
					return currentReadonlyFlag ;
				}
			}else if(IDocsConstants.MSG_STRICTLY_CONFIDENTIAL_CODE.equals(currentSecurityClassificationCode)){
				/** Strictly Confidential  */
				if(IDocsConstants.MSG_IDOCS_PROJECT_DOC.equals(currentObjectType)){
				/** READ ONLY to "idocs_pr_<%projid%>_tl_grp : idocs_pr_<%projid%>_po_grp" */
					if(isUserMemberOfGroup(session,strCurrentSysObjectId,IDocsConstants.MSG_PR_TL_GROUP,IDocsConstants.MSG_IDOCS_PROJECT_DOC) &&
							isUserMemberOfGroup(session,strCurrentSysObjectId,IDocsConstants.MSG_PR_PO_GROUP,IDocsConstants.MSG_IDOCS_PROJECT_DOC)){
						return true;
					}
				}else if(IDocsConstants.MSG_IDOCS_INSTITUTION_DOC.equals(currentObjectType)){	
				/** Institution Document READ ONLY to "idocs_inst_<%inst nbr%>_tl_grp : idocs_inst_<%inst nbr%>_po_grp" */
					if(isUserMemberOfGroup(session,strCurrentSysObjectId,IDocsConstants.MSG_INST_TL_GROUP,IDocsConstants.MSG_IDOCS_INSTITUTION_DOC) &&
							isUserMemberOfGroup(session,strCurrentSysObjectId,IDocsConstants.MSG_INST_PO_GROUP,IDocsConstants.MSG_IDOCS_INSTITUTION_DOC)){
						return true;
					}
				} else if(IDocsConstants.MSG_IDOCS_COUNTRY_DOC.equals(currentObjectType)){
				/** Country Document NO UPDATE */
					DfLogger.debug(IDocDocbaseAttributeTagUtility.class, "canEditableInReleasedState() : Skip Country Document ", null, null);
				}else{
				/** Unknown Type */
					DfLogger.debug(IDocDocbaseAttributeTagUtility.class, "canEditableInReleasedState Leave : " +
							"Unknown Object Type = " + currentObjectType , null, null);
					return currentReadonlyFlag ;
				}
			}else{
				DfLogger.debug(IDocDocbaseAttributeTagUtility.class, "canEditableInReleasedState Leave : " +
						"Unknown Security Classification Code = " + currentSecurityClassificationCode , null, null);
				return currentReadonlyFlag ;
			}
		} catch (Exception e) {
			DfLogger.debug(IDocDocbaseAttributeTagUtility.class, "canEditableInReleasedState Leave : Exception = " + e.getMessage() , null, null);
			e.printStackTrace();
		}
		DfLogger.info(IDocDocbaseAttributeTagUtility.class, "canEditableInReleasedState Leave : canEditableFlag = " + canEditableFlag , null, null);
		return canEditableFlag;
	}

	/**
	 * This method checks whether the logged in user is part of the given project group
	 * or not.
	 * @param currentSysObject - current Object
	 * @param strGroupTemplateName - templateName of the group
	 * @param objectType - Type Name of the Current Object
	 * @return
	 */
	public static boolean isUserMemberOfGroup(IDfSession session,String strCurrentSysObjectId,
			String strGroupTemplateName,String objectType) {
		IDfCollection userNamesCollection = null;
		try {
			String loginUserName = session.getLoginUserName();
			String finalGroupName = null;
			if(IDocsConstants.MSG_IDOCS_PROJECT_DOC.equals(objectType)){
				finalGroupName = getProjectGroupName(session,strCurrentSysObjectId,strGroupTemplateName,objectType);
			}else if(IDocsConstants.MSG_IDOCS_INSTITUTION_DOC.equals(objectType)){
				finalGroupName = getInstitutionGroupName(session,strCurrentSysObjectId,strGroupTemplateName,objectType);
			}else if(IDocsConstants.MSG_IDOCS_COUNTRY_DOC.equals(objectType)){
				finalGroupName = getCountryGroupName(session,strCurrentSysObjectId,strGroupTemplateName,objectType);
			}
			if(finalGroupName!=null && finalGroupName.trim().length() > 0){
				IDfQuery dfQuery = new DfQuery();
				String strQuery = new StringBuilder().append(IDocsConstants.QRY_GRUOP_FROM)
				.append(finalGroupName).append(IDocsConstants.QRY_SUFF_ALLUSER_NAMES)
				.append(IdocsUtil.handleSingleQuote(loginUserName)).append("'") // Handling single quote in username
				.toString();
				dfQuery.setDQL(strQuery);
				DfLogger.debug(IDocDocbaseAttributeTagUtility.class, " : isUserMemberOfGroup() : strQuery = "+strQuery , null, null);
				userNamesCollection = dfQuery.execute(session, IDfQuery.DF_READ_QUERY);
				while(userNamesCollection.next()){
					String userName = userNamesCollection.getString(I_ALL_USERS_NAMES);
					if(userName!=null && userName.trim().length()>0){
						DfLogger.debug(IDocDocbaseAttributeTagUtility.class, " : isUserMemberOfGroup() :" 
								+loginUserName +" IS A MEMBER of "+finalGroupName, null, null);
						return true;
					}
				}
				DfLogger.info(IDocDocbaseAttributeTagUtility.class, " : isUserMemberOfGroup() :" 
						+ loginUserName + " IS NOT A MEMBER of "+finalGroupName, null, null);
			}else{
				DfLogger.debug(IDocDocbaseAttributeTagUtility.class, " : isUserMemberOfGroup() : Invalid Group Name", null, null);
			}
		} catch (DfException e) {
			e.printStackTrace();
			DfLogger.error(IDocDocbaseAttributeTagUtility.class, " : isUserMemberOfGroup() : Exception " + e.getMessage(), null, null);
		}finally{
			if(userNamesCollection!=null){
				try {userNamesCollection.close();}
				catch (DfException e) {e.printStackTrace();
				DfLogger.error(IDocDocbaseAttributeTagUtility.class, " : isUserMemberOfGroup() : Finally : Exception : " + e.getMessage(), null, null);}
			}
		}
		return false;
	}

	/**
	 * This method is to frame the groupName for Project Documents from the 
	 * given Group template name
	 * @param currentSysObject
	 * @param string
	 */
	private static String getProjectGroupName(IDfSession session,String strCurrentSysObjectId,
			String strGroupTemplateName,String strCurrentObjectType) {
		String groupName = null;
		try{
			String projectId = getSingleAttributeValue(session, strCurrentSysObjectId, IdocsConstants.PROJ_ID, strCurrentObjectType);
			groupName = strGroupTemplateName.replace(IdocsConstants.MSG_HASH, projectId);
		}catch (Exception e) {
			e.printStackTrace();
			DfLogger.info(IDocDocbaseAttributeTagUtility.class, " : getProjectGroupName() : Exception in generating the groupName", null, null);
		}
		DfLogger.info(IDocDocbaseAttributeTagUtility.class, " : getProjectGroupName() : groupName ="+groupName, null, null);
		return groupName;
	}
	
	/**
	 * This method is to frame the groupName for Institution Documents from the 
	 * given Group template name
	 * @param currentSysObject
	 * @param string
	 */
	private static String getInstitutionGroupName(IDfSession session,String strCurrentSysObjectId,
			String strGroupTemplateName,String strCurrentObjectType) {
		String groupName = null;
		try{
			String institutionNumber = getSingleAttributeValue(session, strCurrentSysObjectId, IdocsConstants.INSTITUTION_ID, strCurrentObjectType);
			groupName = strGroupTemplateName.replace(IdocsConstants.MSG_HASH, institutionNumber);
		}catch (Exception e) {
			e.printStackTrace();
			DfLogger.info(IDocDocbaseAttributeTagUtility.class, " : getInstitutionGroupName() : Exception in generating the groupName", null, null);
		}
		DfLogger.info(IDocDocbaseAttributeTagUtility.class, " : getInstitutionGroupName() : groupName ="+groupName, null, null);
		return groupName;
	}
	
	/**
	 * This method is to frame the groupName for Country Documents from the 
	 * given Group template name
	 * @param currentSysObject
	 * @param string
	 */
	private static String getCountryGroupName(IDfSession session,String strCurrentSysObjectId,
			String strGroupTemplateName,String strCurrentObjectType) {
		String groupName = null;
		try{
			String countryCode = getSingleAttributeValue(session, strCurrentSysObjectId, IdocsConstants.COUNTRY_CODE, strCurrentObjectType);
			groupName = strGroupTemplateName.replace(IdocsConstants.MSG_HASH, countryCode);
		}catch (Exception e) {
			e.printStackTrace();
			DfLogger.info(IDocDocbaseAttributeTagUtility.class, " : getCountryGroupName() : Exception in generating the groupName", null, null);
		}
		DfLogger.info(IDocDocbaseAttributeTagUtility.class, " : getCountryGroupName() : groupName ="+groupName, null, null);
		return groupName;
	}
	
	/**
	 * This Utility Method returns the current lifecycle state of the document
	 * @param session - IDfSession object
	 * @param strObjectId - r_object_id of the document;
	 * @return String corresponding to the state name of the document OR null;
	 */
	public static  String getDocumentState(IDfSession session , String strObjectId){
		DfLogger.debug(IDocDocbaseAttributeTagUtility.class, " : getDocumentState() : ", null, null);
		IDfCollection collection = null;
		String strCurrentState  = null;
		try{
			String strQuery = new StringBuilder().append(SELECT_R_CURRENT_STATE_FROM_DM_SYSOBJECT_WHERE_AND)
			.append(R_POLICY_ID_0000000000000000_AND_R_OBJECT_ID).append(strObjectId).append(IdocsConstants.MSG_QUOTES).toString();
			DfLogger.info(IDocDocbaseAttributeTagUtility.class, " : getDocumentState() : stQuery :" + strQuery, null, null);
			IDfQuery dfQuery = new DfQuery();
			dfQuery.setDQL(strQuery);
			collection = dfQuery.execute(session, IDfQuery.DF_READ_QUERY);
			while(collection.next()){
				strCurrentState = collection.getString(MSG_R_CURRENT_STATE);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {if(collection!=null) {collection.close();}
			} catch (DfException e) {e.printStackTrace();}
		}
		return strCurrentState;
	}
	
	/**
	 * This Utility Method returns the current Object state of the document
	 * @param session - IDfSession object
	 * @param strObjectId - r_object_id of the document;
	 * @return String corresponding to the state name of the document OR null;
	 */
	public static  String getSysObjectAttribute(IDfSession session , String strObjectId,String attributeName){
		IDfCollection collection = null;
		String strCurrentState  = null;
		try{
			String strQuery = new StringBuilder().append(MSG_SELECT).append(attributeName)
			.append(MSG_FROM_DM_SYSOBJECT_ALL_WHERE_R_OBJECT_ID).append(strObjectId).append(IdocsConstants.MSG_QUOTES).toString();
			IDfQuery dfQuery = new DfQuery();
			dfQuery.setDQL(strQuery);
			collection = dfQuery.execute(session, IDfQuery.DF_READ_QUERY);
			while(collection.next()){
				strCurrentState = collection.getString(attributeName);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {if(collection!=null) {collection.close();}
			} catch (DfException e) {e.printStackTrace();
			DfLogger.debug(IDocDocbaseAttributeTagUtility.class, " : getSysObjectAttribute() : Exception " + e.getMessage() , null, null);
			}
		}
		return strCurrentState;
	}
	
	/**
	 * This Utility Method returns the current Object state of the document
	 * @param session - IDfSession object
	 * @param strObjectId - r_object_id of the document;
	 * @return String corresponding to the state name of the document OR null;
	 */
	public static  String getCurrentSysObjectAttributeFromChronicleId(IDfSession session , String strChronicleId,String attributeName){
		IDfCollection collection = null;
		String strCurrentState  = null;
		try{
			String strQuery = new StringBuilder().append(MSG_SELECT).append(attributeName)
			.append(MSG_FROM_DM_SYSOBJECT_WHERE_I_CHRONICLE_ID).append(strChronicleId).append(IdocsConstants.MSG_QUOTES).toString();
			IDfQuery dfQuery = new DfQuery();
			dfQuery.setDQL(strQuery);
			collection = dfQuery.execute(session, IDfQuery.DF_READ_QUERY);
			while(collection.next()){
				strCurrentState = collection.getString(attributeName);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {if(collection!=null) {collection.close();}
			} catch (DfException e) {e.printStackTrace();
			DfLogger.debug(IDocDocbaseAttributeTagUtility.class, " : getSysObjectAttribute() : Exception " + e.getMessage() , null, null);
			}
		}
		return strCurrentState;
	}
	
	/**
	 * This Utility Method returns the current Object state of the document
	 * @param session - IDfSession object
	 * @param strObjectId - r_object_id of the document;
	 * @return String corresponding to the state name of the document OR null;
	 */
	public static  String getCurrentSysObjectAttribute(IDfSession session , String strObjectId,String attributeName){
		IDfCollection collection = null;
		String strAttributeValue  = null;
		try{
			String strQuery = new StringBuilder().append(MSG_SELECT).append(attributeName)
			.append(MSG_FROM_DM_SYSOBJECT_WHERE_R_OBJECT_ID).append(strObjectId).append(IdocsConstants.MSG_QUOTES).toString();
			IDfQuery dfQuery = new DfQuery();
			dfQuery.setDQL(strQuery);
			collection = dfQuery.execute(session, IDfQuery.DF_READ_QUERY);
			while(collection.next()){
				strAttributeValue = collection.getString(attributeName);
			}
			DfLogger.debug(IDocDocbaseAttributeTagUtility.class, " : getCurrentSysObjectAttribute() : "+attributeName+"="+ strAttributeValue , null, null);
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {if(collection!=null) {collection.close();}
			} catch (DfException e) {e.printStackTrace();
			DfLogger.debug(IDocDocbaseAttributeTagUtility.class, " : getCurrentSysObjectAttribute() : Exception " + e.getMessage() , null, null);
			}
		}
		return strAttributeValue;
	}
	
	/**
	 * This utility method is to get the SingleAttribute value of any document 
	 * with DQL for keeping the performance
	 * @param session - Documentum IDfSession
	 * @param strObjectId - ObjectId of the document
	 * @param attributeName - Name of the attribute to getch
	 * @param strObjectTypeName - ObjectType of the document;
	 * @return - Attribute value of the document
	 */
	public static String getSingleAttributeValue(IDfSession session,
			String strObjectId, String attributeName, String strObjectTypeName) {
		IDfCollection collection = null;
		String strAttributeValue  = null;
		try{
			if (attributeName != null && attributeName.trim().length() > 0
					&& strObjectTypeName != null && strObjectTypeName.trim().length() > 0 ) {
				String strQuery = new StringBuilder().append(MSG_SELECT).append(
						attributeName).append(" from ").append(strObjectTypeName)
						.append("(all) where r_object_id='").append(strObjectId)
						.append("'").toString();
				IDfQuery dfQuery = new DfQuery();
				dfQuery.setDQL(strQuery);
				collection = dfQuery.execute(session, IDfQuery.DF_READ_QUERY);
				while (collection.next()) {
					strAttributeValue = collection.getString(attributeName);
				}
			}
		}catch (Exception e) {
			DfLogger.error(IDocDocbaseAttributeTagUtility.class, " : getSingleAttributeValue() : Exception "+e.getMessage(), null, null);			
		}finally{
			try {if(collection!=null) {collection.close();}
			} catch (DfException e) {e.printStackTrace();}
		}
		return strAttributeValue;
	}
	
	/**
	 * 
	 * @param strTargetAttr
	 * @param objTypeName
	 * @param strValidatingAttr
	 * @param strCommaSeparatedStrVal
	 * @param session
	 * @return
	 */
	public static IDfCollection fetchAnyAttrValFrmAnyType(String strTargetAttr, String objTypeName, String strValidatingAttr,
											String strCommaSeparatedStrVal, IDfSession session) {

		IDfCollection targetAttrValColl = null;
		try {
			String qrySafeParamStr = IdocsUtil.makeQuerySafe(strCommaSeparatedStrVal, null);
			DfLogger.debug(IDocDocbaseAttributeTagUtility.class, " :: fetchAnyAttrValFrmAnyType: qrySafeParamStr: " +
					qrySafeParamStr, null, null);
			String qryFetchAnyAttr = IdocsUtil.getMessage("QRY_FETCH_ANY_ATTR_VAL_FRM_ANY_TYPE");
			qryFetchAnyAttr = qryFetchAnyAttr.replace(QRY_VARIABLE_TARGET_ATTR, strTargetAttr);
			qryFetchAnyAttr = qryFetchAnyAttr.replace(QRY_VARIABLE_OBJECT_TYPE, objTypeName);
			qryFetchAnyAttr = qryFetchAnyAttr.replace(QRY_VARIABLE_VALIDATING_ATTR, strValidatingAttr);
			qryFetchAnyAttr = qryFetchAnyAttr.replace(QRY_VARIABLE_COMMA_SEPARATED_STRING, qrySafeParamStr);
			DfLogger.debug(IDocDocbaseAttributeTagUtility.class," :: fetchAnyAttrValFrmAnyType: qryFetchAnyAttr: " + qryFetchAnyAttr, null, null);
			targetAttrValColl = IdocsUtil.executeQuery(session, qryFetchAnyAttr, IDfQuery.DF_READ_QUERY);
			
		} catch (DfException e) {
			DfLogger.error(IDocDocbaseAttributeTagUtility.class, " :: fetchAnyAttrValFrmAnyType : " + e.getMessage(), null, null);
		}
		return targetAttrValColl;
	}
}
