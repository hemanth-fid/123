package org.ifc.idocs.migration.importUtility;

import java.io.File;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.logging.Level;

import org.ifc.idocs.migration.discussions.GetDiscussionDocs;
import org.ifc.idocs.migration.helper.Utilities;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.DfAttributeValueException;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfId;
import com.documentum.operations.IDfCheckinNode;
import com.documentum.operations.IDfCheckinOperation;
import com.documentum.operations.IDfCheckoutOperation;
import com.documentum.operations.IDfFile;
import com.documentum.operations.IDfImportNode;
import com.documentum.operations.IDfImportOperation;
/**
 * ImportDocument - Uploading the document and setting all the documents related attributes. 
 * @author HAnuganti
 * 
 * #############################################################################################
 * Author		            DateofChange	 Version	  ModificationHistory
 * ###########################################################################################
 * Hemachandra Anuganti 
 * ###########################################################################################
 * 
 */
public class ImportDocument extends ImportUtility{

	
	static String queryString4 = "";
	static String fileRoom = "";
	
	//import file with specific version
	@SuppressWarnings("unchecked")
	protected static boolean importFile(int total) throws DfException
	{
		//importDocLogger.info("inside importFile(int total)::"+ImportDocument.class);
		IDfClientX clientx = new DfClientX();
		IDfFile file = null;
		IDfId fid = null;
		String fullPath = "";
			fullPath=getDestinationPath(0);
			if(null == fullPath || "".equals(fullPath.trim())){
				raiseDestFldNotFoundException(new NullPointerException(),fullPath);
				return false;
			}
			//Get Source file path.
			getSourceFile(0);
			file = clientx.getFile(sourceFilePath);
			if(file.exists()){
				try{
					if(dfSession == null){
						raiseDocbaseSessionNotFoundException();
						return false;
					}else{
						fid = dfSession.getFolderByPath(fullPath).getObjectId();
					}
				}catch(NullPointerException npe){
					raiseDestFldNotFoundException(npe,fullPath);
					return false;
				}
				if(null != fid){
					IDfImportOperation opi = clientx.getImportOperation();
					opi.setSession(dfSession);
					opi.setDestinationFolderId(fid);
					IDfImportNode node = (IDfImportNode) opi.add(file);
					node.setDocbaseObjectType(docBaseObjectType);
					
					opi.execute();
					newId = node.getNewObjectId();
					IDfSysObject importedDoc = (IDfSysObject)dfSession.getObject(newId);
					if(null == importedDoc){
						raiseNewDocCreationException();
						return false;
					}
					
					// TO BE DELETED
					//importedDoc.getString("acl_name");
					
					importedDoc.setString("sec_classification_code", "");
					
					if(attributeValueList[0].get(idocsProperties.getProperty("MSG_VERSION")).equals("0.1")){
						importedDoc.mark("0.1");
					}else if(attributeValueList[0].get(idocsProperties.getProperty("MSG_VERSION")) != null){
						String versionNum = (String) attributeValueList[0].get(idocsProperties.getProperty("MSG_VERSION"));
						String versionLbl = importedDoc.getVersionLabel(0);
						if(!versionLbl.equals(versionNum)){
							importedDoc.mark(versionNum+",CURRENT");
						}
					}
					//Set is migrated documents attribute to TRUE
					if(!saveSysObject(importedDoc)){
						return false;
					}
					boolean attrSetFlag = setAttributes(newId, dfSession, 0);
					if(attrSetFlag){
						if(total > 1){
							prevVerFolderPath = fullPath;
							for(int j=1;j<total;j++){
								boolean setVersionFlag = checkinNextVersion(dfSession,j);
								if(!setVersionFlag){
									Utilities.addToArrayList(queryString5.toString());
									return false;
								}
								getSourceFile(j-1);
							}
						}
						getSourceFile(total-1);
					}else{
						//importDocLogger.info("Updating the database with rollback status"+queryString5.toString());
						Utilities.addToArrayList(queryString5.toString());
						return false;
					}
					return true;
				}else{
					raiseDestFldNotFoundException(new NullPointerException(),fullPath);
					return false;
				}
			}else{
				raiseSourceFileNotFoundException();
				return false;
			}
	}
	private static void raiseSourceFileNotFoundException() {
		// TODO Auto-generated method stub
		importDocLogger.warning("Source File "+sourceFilePath+" not found for the metadata xml::"+xmlPath);
		
		String skippedReason = "Source File "+sourceFilePath+" not found for the metadata xml::"+xmlPath;
		skippedReason = skippedReason.replaceAll("'", "''");
		skippedReason = skippedReason+"')";
		
		Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_38"),skippedReason);
	}
	private static void raiseDocbaseSessionNotFoundException() {
		// TODO Auto-generated method stub
		String skippedReason = "Unable to process the document::["+xmlPath+"]import as docbase session is not available";
		skippedReason = skippedReason.replaceAll("'", "''");
		skippedReason = skippedReason+"')";
		
		Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_50"),skippedReason);
	}
	private static void raiseNewDocCreationException() {
		// TODO Auto-generated method stub
		String skippedReason = "Document contained in:: "+xmlPath+" :: could not be imported as utility is unable to get document handle during document creation";
		skippedReason = skippedReason.replaceAll("'", "''");
		skippedReason = skippedReason+"')";
		Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_51"),skippedReason);
		importDocLogger.warning("Document contained in:: "+xmlPath+" :: could not be imported as utility is unable to get document handle during document creation");
	}
	protected static void raiseDestFldNotFoundException(NullPointerException npe,String fullPath) {
		// TODO Auto-generated method stub
		String skippedReason = "Document contained in:: "+xmlPath+" :: could not be imported as following destination folder is not found :: "+fullPath;
		skippedReason = skippedReason.replaceAll("'", "''");
		skippedReason = skippedReason+"')";
		
		Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_15"),skippedReason);
		
//		skippedDocQry = skippedDocQry+"Document contained in:: "+xmlPath+" :: could not be imported as following destination folder is not found :: "+fullPath+"')";											
		importDocLogger.warning("Document contained in:: "+xmlPath+" :: could not be imported as following destination folder is not found :: "+fullPath);
		importDocLogger.log(Level.WARNING,"Document contained in:: "+xmlPath+" :: could not be imported as following destination folder is not found :: "+fullPath, npe);
//		Utilities.addToArrayList(skippedDocQry.toString());
		npe.printStackTrace();
	}
	private static boolean checkinNextVersion(IDfSession dfSession,int j) throws DfException {
//		importDocLogger.info("inside checkinNextVersion(IDfSession dfSession,int j)::"+ImportDocument.class);
		IDfClientX clientx = new DfClientX();
		IDfCheckoutOperation cop = clientx.getCheckoutOperation();
		newVerFolderPath = getDestinationPath(j);
		getSourceFile(j);
		File srcFile = new File(sourceFilePath);
		if(srcFile.exists()){
		IDfSysObject sysObj = (IDfSysObject) dfSession.getObject(newId);
		cop.add(sysObj);
		cop.execute();
		if(sysObj.isCheckedOut()){
			IDfCheckinOperation cin = clientx.getCheckinOperation();
			float versionValue = Float.parseFloat(attributeValueList[j].get(idocsProperties.getProperty("MSG_VERSION")).toString());
			if((int)versionValue == versionValue){
				cin.setCheckinVersion(IDfCheckinOperation.NEXT_MAJOR);
				cin.setVersionLabels("CURRENT");
			}else{
				cin.setCheckinVersion(IDfCheckinOperation.NEXT_MINOR);
			}
			IDfCheckinNode node = (IDfCheckinNode) cin.add(sysObj);
			if(cin.execute()){
				IDfId newCheckinId =  node.getNewObjectId();
				
				//if newCheckinId == 0000
				
				//take chro9nicale id and gety latest version and assign the id to newCheckinId
				if("0000000000000000".equals(newCheckinId.toString())){
					raiseUnableToChkinFoundException(newCheckinId.toString());
					return false;
				}
				
				//Set the exact version label to the destination document as source 
				IDfSysObject newIFCdocsDocumentId = (IDfSysObject)dfSession.getObject(newCheckinId);
				if(attributeValueList[j].get(idocsProperties.getProperty("MSG_VERSION")) != null){
					String versionNum = (String) attributeValueList[j].get(idocsProperties.getProperty("MSG_VERSION"));
					String versionLbl = newIFCdocsDocumentId.getVersionLabel(0);
					if(!versionLbl.equals(versionNum)){
						newIFCdocsDocumentId.mark(versionNum);
					}
				}
				if(!saveSysObject(newIFCdocsDocumentId)){
					return false;
				}
				
				boolean attrSetFlag = setAttributes(newCheckinId, dfSession, j);
				if(attrSetFlag)	{
					IDfSysObject Obj = (IDfSysObject)dfSession.getObject(newCheckinId);
					newId = newCheckinId;
					Obj.setFile(sourceFilePath);
					//Set is migrated documents attribute to TRUE
					if(!saveSysObject(Obj)){
						return false;
					}
					if (!prevVerFolderPath.equals(newVerFolderPath)){
						Obj.unlink(prevVerFolderPath);
						Obj.link(newVerFolderPath);
						//Set is migrated documents attribute to TRUE
						if(!saveSysObject(Obj)){
							return false;
						}
					}
//		     		documentCount++;
		     		prevVerFolderPath = newVerFolderPath;
		     		return true;
				}else{
					return false;
				}
			}else{
				importDocLogger.info("ImportDocument :: checkinNextVersion() : Checkin Failed.");
				return false;
			}
		}
		return true;
		}else{
			raiseSourceFileNotFoundException();
			return false;
		}
	}
	
	private static void getSourceFile(int index) {
		sourceFilePath = "";
		String extractFilename = "";
		
		sourceFilePath =  sourceRoot;
		String domDocFileName = attributeValueList[index].get("DocID").toString()
									+"_"+attributeValueList[index].get(idocsProperties.getProperty("MSG_VERSION")).toString()
									+"_"+attributeValueList[index].get("Filename").toString();
		if (sourceRoot.length() > max_path - 4) {
			importDocLogger.warning("Folder Path is exceeding the length of 250 Chars::" +sourceRoot);
		}
		if (sourceRoot.length() + domDocFileName.length() > max_path) {
			extractFilename = domDocFileName.substring(0, max_path - 5 - sourceRoot.length() - 1) + domDocFileName.substring(domDocFileName.length() - 4, domDocFileName.length());
			importDocLogger.warning("Truncating filename from " + domDocFileName + " to::" + extractFilename);
		} else {
			extractFilename = domDocFileName;
		}
		sourceFilePath = sourceFilePath+extractFilename;
	}

	//get destination path based on category
	protected static String getDestinationPath(int index){
		String destPath=idocsProperties.getProperty("MSG_CABINET_PATH");
		fileRoom = (String) attributeValueList[0].get("Fileroom");
		destPath=(String) attrData.get("folderPath");
//		importDocLogger.info("Building complete destination path by appending two level folders");
		String subFldLevel1 = (String) attributeValueList[0].get(idocsProperties.getProperty("MSG_SUBFOLDER"));
		String subFldLevel2 = (String) attributeValueList[0].get(idocsProperties.getProperty("MSG_DOC_TYPE"));
//		importDocLogger.info("Subfolder1::"+subFldLevel1);
//		importDocLogger.info("Subfolder2::"+subFldLevel2);
		
		return destPath;
	}

	//set attributes to uploaded file
	@SuppressWarnings({ "unchecked", "deprecation" })
	private static boolean setAttributes(IDfId fileId,IDfSession dfSession,int index){
		
		boolean attrFlag = true;
		String exceptionKey = "";
		String exceptionValue = "";
		
		try {
//			importDocLogger.info("File Room::"+fileRoom);
			IDfSysObject sysObj;
			sysObj = (IDfSysObject) dfSession.getObject(fileId);
			Set set = attributeValueList[index].entrySet();
			
			if(index == 0){
				queryString4 = idocsProperties.getProperty("MSG_UPDATE_REGION_INFO");
				queryString4 = queryString4.replaceAll("<region_name>", region);
				queryString4 = queryString4.replaceAll("<documentum_doc_id>", sysObj.getObjectId().toString().trim());
				queryString4 = queryString4.replaceAll("<legacy_doc_id>", legacyDocId);
				queryString4 = queryString4.replaceAll("<extraction_utility_code>", extractionID);
				Utilities.addToArrayList(queryString4.toString());
			}
			
			//Setting Orig_Doc_Id and Orig_Doc_Unique_Id and save the object as these are the critical attributes for the migrated documents
			if(updateDocIDandDocUNId(sysObj,attributeValueList[index],index)){
				//Set Doc State and Version Label for the document
				if(setDocStateVersionLabel(sysObj)){
					//Set All Folder Related Attributes to the document and save the objects
					if(setAllFolderAttributesToDoc(sysObj)){
						//Start Updating Document Specific attributes parsed from the XML
						if(setXMLAttributesToDoc(set, sysObj)){
							//Create Document Discussions if available
							String legacyDocumentID = sysObj.getString("orig_doc_id");
							String legacyVersion = sysObj.getVersionLabel(0);
							if(GetDiscussionDocs.getDiscussionXML(sysObj.getObjectId().toString(),legacyDocumentID,legacyVersion,dfSession)){
								//Do Nothing as discussions are uploaded successfully
							}else{
								//Adding to Skipped Reason Database on Discussion Import Failure
								raiseDiscussionFailureException(legacyDocumentID);
								return false;
							}//end of if for uploading discussions
						}else{
							//Exception catched and skipped in setXMLAttributesToDoc
							return false;
						}
					}else{
						//Exception catched and skipped in setAllFolderAttributesToDoc
						return false;
					}
				}else{
					//Exception catching here and skipping it because it is not handled in setDocStateVersionLabel
					raiseDocVersionLabelNotUpdatedException(sysObj.getObjectId().toString(),sysObj.getString("orig_doc_unique_id"));
					return false;
				}
			}else{
				//Exception catching here and skipping it because it is not handled in updateDocIDandDocUNId
				raiseDocAndDocUNIdNotUpdatedException(sysObj.getObjectId().toString(),legacyDocId);
				return false;
			}
			return true;
		} catch (DfException e) {
			// TODO Auto-generated catch block
			raiseUnknownImportException(fileId);
			e.printStackTrace();
			return false;
		}
	}
	
	private static void raiseUnableToChkinFoundException(String docObjID) {
		// TODO Auto-generated method stub
		String skippedReason = "Checkin Failed Unable to get the new r_object_id::["+docObjID+"]";
		skippedReason = skippedReason.replaceAll("'", "''");
		skippedReason = skippedReason+"')";
		
		//Adding to Skipped Reason Database on Import Failure
		Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_60"),skippedReason);
	}
	private static void raiseUnknownImportException(IDfId fileId) {
		// TODO Auto-generated method stub
		String skippedReason = "Unable to process the document for import document id ["+fileId+"]";
		skippedReason = skippedReason.replaceAll("'", "''");
		skippedReason = skippedReason+"')";
		
		//Adding to Skipped Reason Database on Import Failure
		Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_48"),skippedReason);
	}
	private static void raiseDiscussionFailureException(String legacyDocumentID) {
		// TODO Auto-generated method stub
		String skippedReason = "Unable to upload the discussion for the legacy document id ["+legacyDocumentID+"]";
		skippedReason = skippedReason.replaceAll("'", "''");
		skippedReason = skippedReason+"')";
		
		//Adding to Skipped Reason Database on Import Failure
		Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_48"),skippedReason);
	}
	private static boolean setXMLAttributesToDoc(Set set, IDfSysObject sysObj) {
		// TODO Auto-generated method stub
		
		String exceptionKey = "";
		String exceptionValue = "";
		int securityClass = 0;
		String compReaders = "";
		String compAuthors = "";
		String compEditors = "";
		String compManagers = "";
		String descriptionVal = "";
		String documentDescription = "";
		String versionComment = "";
		String tempTitle = "";
		String wfProcessName = "";
		String descValue = "";
		String tempCode = "";
		String docTitle = "";
		String fileNameDescription = "";
		IDfCollection collection = null;
		
		if(null ==sysObj){
			//TODO raise an exception 
			return false;
		}
		
			try {
				
			Iterator i = set.iterator();
			while(i.hasNext()){
				String key,value = "";
				Map.Entry me = (Map.Entry)i.next();
				if(metaData.get(me.getKey().toString()) != null){
					key = metaData.get(me.getKey().toString()).toString();
					exceptionKey = key;
					value = me.getValue().toString();
					exceptionValue = value;
					//setting object name and title fields
					if(key.equals("title")){
						if(value.length() <= 255){
							docTitle = value;
							sysObj.setObjectName(value);
							sysObj.setTitle(value);
						}else if(value.length()>= 400){
							docTitle = value;
							String titleValue = value;
							sysObj.setObjectName(titleValue.substring(0, 255));
							sysObj.setTitle(titleValue.substring(0, 400));
						}else{
							docTitle = value;
							sysObj.setObjectName(docTitle.substring(0, 255));
							sysObj.setTitle(docTitle);
						}
					}
					
	//				importDocLogger.info("setting common attributes to the object::"+key+"::"+value);
					if(!key.equals("template_title") && !key.equals("version_comment") && !key.equals("description_document") && !key.equals("description") && !key.equals("title") && !key.equals("custom_security") && !key.equals("computed_readers") && !key.equals("computed_authors") && !key.equals("computed_editors") && !key.equals("computed_managers") && !key.equals("workflow_process_name")){
						if(key.equalsIgnoreCase("ifcdocs_authors")){
							if(Utilities.setDocRepeatingAuthors(sysObj, key, value)){
								//All the Repesting authors are updated successfully
							}else{
								//No need to skip this here as this has been skipped in setDocRepeatingAuthors
								return false;
							}
						}else if(key.equalsIgnoreCase("file_name") && value.length()>Integer.parseInt(idocsProperties.getProperty("MSG_FILE_NAME_LENGTH"))){
							fileNameDescription = value;
							value = value.substring(0, 200);
							sysObj.setString(key, value);
						}else if(key.equalsIgnoreCase(idocsProperties.getProperty("WorkflowStatus"))){
							//Setting WorkFlow Status to the document
							setWorkflowStatus(sysObj,key,value);
						}else if(key.equalsIgnoreCase(idocsProperties.getProperty("SecurityClassification_Code"))){
							//Setting Security Classification To the document
							setSecurityClassification(sysObj,key,value);
						}else if(key.equalsIgnoreCase("orig_filed_idocs_date") || key.equalsIgnoreCase("metadata_modify_date") || key.equalsIgnoreCase("content_modify_date") || key.equalsIgnoreCase("document_date")){
							if(value.contains(".") || value.contains("-")){
								sysObj.setString(key, value);
							}else{
								sysObj.setString(key, Utilities.convertToEasternTime(value));
							}
						}else if(key.equalsIgnoreCase("doc_subtype_nme") || key.equalsIgnoreCase("folder_title")){
							if(levelFldHM.containsKey(value)){
								value = (String) levelFldHM.get(value);
							}
							sysObj.setString(key, value);
						}else{
							if(key.equals("owner_name") && (value == "" || value == null)){
								value = dfSession.getLoginUserName();
							}
							sysObj.setString(key, value);
						}
					}else if(key.equals("custom_security") && value!=null && value!=""){
						securityClass = Integer.parseInt(value);
					}else if(key.equals("computed_readers")){
						compReaders = value;
					}else if(key.equals("computed_authors")){
						compAuthors = value;
					}else if(key.equals("computed_editors")){
						compEditors = value;
					}else if(key.equals("computed_managers")){
						compManagers = value;
					}else if(key.equals("description")){
						descriptionVal = value;
					}else if(key.equals("description_document")){
						documentDescription = value;
					} else if(key.equals("version_comment")){
						versionComment = value;
					} else if(key.equals("workflow_process_name")){
						wfProcessName = value;
					} else if(key.equals("template_title")){
						if(docTitleMapHM.containsKey(value)){
							value = (String) docTitleMapHM.get(value);
						}
						tempTitle = value;
					}
				}
				//Assign is_migrated value
				sysObj.setString(idocsProperties.getProperty("MSG_DOC_IS_MIGRATED"), "T");
			}
			//Set doc_type_code to the document
			if(!setDocTypeCode(dfSession,sysObj)){
				raiseUnableToUpdateAttributesException("doc_subtype_code","");
				return false;
			}
			
			//Set Description of the document
			if(descriptionVal.length() > 0){
				descriptionVal = descriptionVal+" "+fileNameDescription;
				descValue = getDescriptionValue(descriptionVal);
			}else if(documentDescription.length() > 0){
				documentDescription = documentDescription+" "+fileNameDescription;
				descValue = getDescriptionValue(documentDescription);
			}else if(versionComment.length() > 0){
				versionComment = versionComment+" "+fileNameDescription;
				descValue = getDescriptionValue(versionComment);
			}else{
				descValue = getDescriptionValue(fileNameDescription);
			}
			exceptionKey = "description";
			exceptionValue = descValue;
			sysObj.setString("description", descValue);
			
			//Setting Object Name for Template Based documents
			if(sysObj.getString("iscreatedfrombiztemplate").equals("T")){
				
				//Get Template Code from idocs template info table
				if(tempTitle != ""){
					if(templateMappingHM.containsKey(tempTitle)){
						tempCode = (String) templateMappingHM.get(tempTitle.toString());
					}else{
						tempCode = "";
					}	
					exceptionKey = "template_code";
					exceptionValue = tempCode;
					sysObj.setString("template_code",tempCode);
				
					//Set Document name for Template based documents if Template is not empty
					exceptionKey = "object_name";
					exceptionValue = tempTitle;
					setDocumentObjectName(sysObj, tempTitle);
				}else if(wfProcessName != "" || "User Defined Workflow".equals(wfProcessName)){
					//Set Document name with workflow process name if template title is empty for a template based document
					
					if(templateMappingHM.containsKey(wfProcessName)){
						tempCode = (String) templateMappingHM.get(wfProcessName.toString());
					}else{
						tempCode = "";
					}
					exceptionKey = "template_code";
					exceptionValue = tempCode;
					sysObj.setString("template_code",tempCode);
					
					//Set Document name if Template Title is empty for the document
					exceptionKey = "object_name";
					exceptionValue = wfProcessName;
					setDocumentObjectName(sysObj, wfProcessName);
				}else if(docTitle != ""){
					if(templateMappingHM.containsKey(docTitle)){
						tempCode = (String) templateMappingHM.get(docTitle.toString());
					}else{
						tempCode = "";
					}
					exceptionKey = "template_code";
					exceptionValue = tempCode;
					sysObj.setString("template_code",tempCode);
					
					//Set Document name with document title with document title if workflow process name && template title is empty for a template based document
					exceptionKey = "object_name";
					exceptionValue = docTitle;
					setDocumentObjectName(sysObj, docTitle);
				}else{
					exceptionKey = "";
					exceptionValue = "";
					importDocLogger.warning("tempTitle and wfProcessName and docTitle not found for the Templatebased Document docID::["+legacyDocId+"]::DocUNID::["+sysObj.getString("orig_doc_unique_id")+"]");
				}
			}
			
			importDocLogger.warning("ORIG DOC ID::"+sysObj.getString("orig_doc_id")+"::DOC UNIQUE ID::"+sysObj.getString("orig_doc_unique_id")+"::VERSION LABEL::"+sysObj.getVersionLabel(0));
			//Set is migrated documents attribute to TRUE
			if(!saveSysObject(sysObj)){
				return false;
			}
				//Check custom security attribute from metadata map
			if(securityClass >1){
				//Setting Custom Security to true for custom security enabled documents
				sysObj.setBoolean("is_custom_security", true);
				if(setDocumentObjectACL(dfSession,sysObj.getObjectId().toString(),compReaders, compAuthors, compEditors, compManagers)){
					//Set is migrated documents attribute to TRUE
					//Set is migrated documents attribute to TRUE
					if(!saveSysObject(sysObj)){
						return false;
					}
				}else{
					//Do not add to skipped documents as this is already handled in updateDocumentACL
					return false;
				}
			}
			return true;
		}catch(DfAttributeValueException ave){
			raiseUnableToUpdateAttributesException(exceptionKey,exceptionValue);
			ave.printStackTrace();
			return false;
		}catch(Exception e){
			e.printStackTrace();
			raiseUnableToUpdateAttributesException(exceptionKey,exceptionValue);
			return false;
		}
	}
	private static boolean setDocTypeCode(IDfSession dfSession, IDfSysObject sysObj) {
		// TODO Auto-generated method stub
		String docTyprCodeQry = idocsProperties.getProperty("MSG_GET_DOC_TYPE_CODE");
		try {
			docTyprCodeQry = docTyprCodeQry.replaceFirst("<folder_category>", sysObj.getString("doc_category"))
								.replaceFirst("<doc_type_name>", sysObj.getString("doc_subtype_nme"))
									.replaceFirst("<subfolder_title>", sysObj.getString("folder_title"));
			IDfCollection docTypeCodeColl = Utilities.executeQuery(dfSession, docTyprCodeQry, DfQuery.EXECREAD_QUERY);
			while(docTypeCodeColl.next()){
				sysObj.setString("doc_subtype_code", docTypeCodeColl.getString("doc_type_code"));
			}
			docTypeCodeColl.close();
			return true;
		} catch (DfException dfe) {
			// TODO Auto-generated catch block
			importDocLogger.info("Utility Failed while updating doc_subtype_code to the document");
			importDocLogger.log(Level.WARNING,"Utility Failed while updating doc_subtype_code to the document:: "+dfe);
			dfe.printStackTrace();
			return false;
		}
	}
	private static boolean saveSysObject(IDfSysObject sysObj) {
		// TODO Auto-generated method stub
		try{
			sysObj.setString(idocsProperties.getProperty("MSG_DOC_IS_MIGRATED"), "T");
			sysObj.save();
			return true;
		}catch(NullPointerException ne){
			raiseUnableToSaveException(ne.getMessage());
			return false;
		} catch (DfException e) {
			raiseUnableToSaveException(e.getMessage());
			return false;
		}
	}
	private static void raiseUnableToSaveException(String message) {
		// TODO Auto-generated method stub
		importDocLogger.log(Level.WARNING,"Utility Unable to save the document:: "+message);
		
		//Make Entry in Migration Skipped documents table as folder is not found
		String skippedReason = "Utility is Unable to save the document(TBO):: "+message;
		skippedReason = skippedReason.replaceAll("'", "''");
		skippedReason = skippedReason+"')";
		
		//Adding to Skipped Reason Database on Import Failure
		Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_58"),skippedReason);

	}
	public static void raiseUnableToUpdateAttributesException(String exceptionKey, String exceptionValue) {
		// TODO Auto-generated method stub

		if(exceptionValue.length() > 2000){
			exceptionValue = exceptionValue.substring(0, 2000);
		}
		importDocLogger.log(Level.WARNING,"Exception during updating attributes to the document:: "+sourceFilePath+":: and XML path::"+xmlPath);
		
		//Make Entry in Migration Skipped documents table as folder is not found
		String skippedReason = "Unable to update the attributes [Key="+exceptionKey+" and Value ="+exceptionValue+"] for the document::"+sourceFilePath+" with the metadata xml::"+xmlPath;
		skippedReason = skippedReason.replaceAll("'", "''");
		skippedReason = skippedReason+"')";
		
		//Adding to Skipped Reason Database on Import Failure
		Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_35"),skippedReason);

	}
	private static boolean setAllFolderAttributesToDoc(IDfSysObject sysObj) {
		// TODO Auto-generated method stub
		String fldExceptionKey = "";
		String fldExceptionValue = "";
		StringTokenizer st;
		int j=0, attrCount=0;
		String attrName="";
		String projectStagName = "";
		IDfQuery query = new DfQuery();
		try {
			if(fileRoom.equalsIgnoreCase(idocsProperties.getProperty("MSG_COUNTRIES_FOLDER")) || fileRoom.equalsIgnoreCase(idocsProperties.getProperty("MSG_COUNTRY_FOLDER")) || fileRoom.equalsIgnoreCase(idocsProperties.getProperty("MSG_COUNTRIES_MISCELLANEOUS"))){
				st=new StringTokenizer(idocsProperties.getProperty("MSG_COUNTRY_FOLDER_ATTR_LIST"), ",");
				attrCount=st.countTokens();
		    	for(j=0;j<attrCount;j++){
					attrName=st.nextToken();
					fldExceptionKey = attrName;
					fldExceptionValue = (String)attrData.get(attrName);
					sysObj.setString(attrName, fldExceptionValue);
				}
				//Set is migrated documents attribute to TRUE after setting folder specific attributes to the documents
		    	if(!saveSysObject(sysObj)){
					return false;
				}

			}else if(fileRoom.equalsIgnoreCase(idocsProperties.getProperty("MSG_INSTITUTIONS_FOLDER")) || fileRoom.equalsIgnoreCase(idocsProperties.getProperty("MSG_INSTITUTION_FOLDER"))){
				st=new StringTokenizer(idocsProperties.getProperty("MSG_INSTITUTION_FOLDER_ATTR_LIST"), ",");
				attrCount=st.countTokens();
		    	for(j=0;j<attrCount;j++){
					attrName=st.nextToken();
					fldExceptionKey = attrName;
					fldExceptionValue = (String)attrData.get(attrName);
					sysObj.setString(attrName, fldExceptionValue);
				}
		    	
				//Set is migrated documents attribute to TRUE after setting folder specific attributes to the documents
		    	if(!saveSysObject(sysObj)){
					return false;
				}

		    	//Creating Aspects for the institution email documents
			    if("Notes".equals(attrData.get("docFormat"))){
		    		st=new StringTokenizer(idocsProperties.getProperty("EMAIL_DOCUMENT_ATTRIBUTE_LIST"), ",");
		    		attrCount=st.countTokens();
		    		HashMap hmAspects = new HashMap();
		    		hmAspects.put("orig_doc_unique_id",sysObj.getString("orig_doc_unique_id"));
	    			hmAspects.put("doc_type","Institution");
		    		for(j=0;j<attrCount;j++){
			    		attrName=st.nextToken();
			    		String keyValue = (String)attrData.get(attrName);
		    			hmAspects.put(attrName,keyValue);
					}//end of for loop
		    		
		    		//Call function to attach Aspects to the email document
		    		if(Utilities.attachDocAspects(dfSession,sysObj.getObjectId(),hmAspects)){
		    			//Dont do anything
		    		}else{
		    			//Exception catched and skipped in attachDocAspects
		    			return false;
		    		}
		    	}
			}else{
				st=new StringTokenizer(idocsProperties.getProperty("MSG_PROJECT_FOLDER_ATTR_LIST"), ",");
				attrCount=st.countTokens();
		    	for(j=0;j<attrCount;j++){
		    		attrName=st.nextToken().trim();
		    		fldExceptionKey = attrName;
					fldExceptionValue = (String)attrData.get(attrName);
		    		String fldAttrValues = "";
					if(attrName.equals("stage_nbr")){
						String getStgNameQry =  idocsProperties.getProperty("MSG_GET_STAGE_NME");
						getStgNameQry = getStgNameQry.replaceFirst("<stage_nbr>", fldAttrValues);
						query.setDQL(getStgNameQry);
						IDfCollection collectionStg = null;
						collectionStg = query.execute(dfSession, DfQuery.EXECREAD_QUERY);
						while(collectionStg.next()){
							projectStagName = collectionStg.getString("stage_nme");
							sysObj.setString("project_stage_nme", projectStagName);
						}
						collectionStg.close();
					}else{
//						System.out.println("Fld KEY::["+fldExceptionKey+"]::Value::["+fldExceptionValue+"]");
						sysObj.setString(fldExceptionKey, fldExceptionValue);
					}
				}
		    	//set 
		    	
				//Set is migrated documents attribute to TRUE after setting folder specific attributes to the documents
		    	if(!saveSysObject(sysObj)){
					return false;
				}
		    	if("Notes".equals(attrData.get("docFormat"))){
		    		st=new StringTokenizer(idocsProperties.getProperty("EMAIL_DOCUMENT_ATTRIBUTE_LIST"), ",");
		    		attrCount=st.countTokens();
		    		HashMap hmAspects = new HashMap();
		    		hmAspects.put("orig_doc_unique_id",sysObj.getString("orig_doc_unique_id"));
		    		hmAspects.put("doc_type","Project");
		    		for(j=0;j<attrCount;j++){
			    		attrName=st.nextToken();
			    		String keyValue = (String)attrData.get(attrName);
		    			hmAspects.put(attrName,keyValue);
					}//end of for loop
		    		
		    		//Call function to attach Aspects to the email document
		    		if(Utilities.attachDocAspects(dfSession,sysObj.getObjectId(),hmAspects)){
		    			//Dont do anything
		    		}else{
		    			//Exception catched and skipped in attachDocAspects
		    			return false;
		    		}
		    	}
			}
			return true;
		} catch (DfException e) {
			// TODO Auto-generated catch block
			raiseUnableToUpdateAttributesException(fldExceptionKey,fldExceptionValue);
			e.printStackTrace();
			return false;
		}
	}
	
	private static void raiseDocVersionLabelNotUpdatedException(String docRObjectID,
			String strLegacyUNID) {
		// TODO Auto-generated method stub
		String skippedReason = "Utility unable to update doc_state and Version Label for the legacy document::["+strLegacyUNID+"] and rObjectID::["+docRObjectID+"]";
		skippedReason = skippedReason.replaceAll("'", "''");
		skippedReason = skippedReason+"')";
		Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_56"),skippedReason);
		importDocLogger.warning("Utility unable to update doc_state and Version Label for the legacy document::["+strLegacyUNID+"] and rObjectID::["+docRObjectID+"]");

	}
	private static void raiseDocAndDocUNIdNotUpdatedException(String docRObjectID, String legacyDomDocId) {
		// TODO Auto-generated method stub
		String skippedReason = "Utility unable to update docID and DocUNID of the legacy document::["+legacyDomDocId+"] and rObjectID::["+docRObjectID+"]";
		skippedReason = skippedReason.replaceAll("'", "''");
		skippedReason = skippedReason+"')";
		Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_56"),skippedReason);
		importDocLogger.warning("Utility unable to update docID and DocUNID of the legacy document::["+legacyDomDocId+"] and rObjectID::["+docRObjectID+"]");
	}
	private static boolean updateDocIDandDocUNId(IDfSysObject sysObj, HashMap hashMap, int index) {
		// TODO Auto-generated method stub
		try {
			sysObj.setString("orig_doc_id", attributeValueList[index].get("DocID").toString());
			sysObj.setString("orig_doc_unique_id", attributeValueList[index].get("legacyUNID").toString());
			
			if(sysObj.getTypeName().equals("idocs_project_doc")){
				String[] prjMetadataList = idocsProperties.getProperty("IDOCS_PRODUCT_WF_ATTR_LIST").split(",");
				for(int p=0;p<prjMetadataList.length;p++){
					sysObj.setString(idocsProperties.getProperty(prjMetadataList[p]), attributeValueList[index].get(prjMetadataList[p]).toString());
				}
			}
			if(!saveSysObject(sysObj)){
				return false;
			}
			return true;
		} catch (DfException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		

	}
	private static boolean setDocStateVersionLabel(IDfSysObject sysObj) {
		// TODO Auto-generated method stub
		try {
			String docVerion= getDocumentVersion(sysObj);
			if(""!=docVerion && "Minor"==docVerion){
				sysObj.setString("doc_state", "Draft");
				sysObj.setRepeatingString("r_version_label", 2, "Draft");
			}else if(""!=docVerion && "Major"==docVerion){
				sysObj.setString("doc_state", "Released");
				sysObj.setRepeatingString("r_version_label", 2, "Released");
			}
			return true;
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException while setting docstate and version label to the document");
			importDocLogger.log(Level.WARNING,"DfException while setting docstate and version label to the document", e);
			e.printStackTrace();
			return false;
		}
	}

	private static String getDocumentVersion(IDfSysObject sysObj) {
		// TODO Auto-generated method stub
		
		String legacyVersionNbr = "";
		try {
			legacyVersionNbr = sysObj.getVersionLabel(0);
			if(legacyVersionNbr.substring(legacyVersionNbr.lastIndexOf(".")+1).equals("0")){
				return "Major";
				}else{
					return "Minor";
				}	
		} catch (DfException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			importDocLogger.warning("DfException During fetching document vesion of the document::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"DfException During fetching document vesion of the document:: "+sourceFilePath+":: and XML path::"+xmlPath, e);
			return "";
		}
	}
	private static void setWorkflowStatus(IDfSysObject sysObj, String key,
			String value) {
		// TODO Auto-generated method stub
		try {
		if(value.equals("0") || value.equals("1") || value.equals("2") || value.equals("4")){
			value = "";
		}else if(value.equals("3")){
			value = idocsProperties.getProperty("MSG_WF_STATUS_COMPLETED");
		}else {
			value = "";
		}
		sysObj.setString(key, value);
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("Exception During setting Workflow Status to the document::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"Exception during setting Workflow Status to the document:: "+sourceFilePath+":: and XML path::"+xmlPath, e);
			e.printStackTrace();
			
		}
	}
	private static void setSecurityClassification(IDfSysObject sysObj, String key, String value) {
		// TODO Auto-generated method stub
		
		try {
		if(key.equalsIgnoreCase(idocsProperties.getProperty("SecurityClassification_Code")) && value.equalsIgnoreCase("O")){
//			sysObj.setString(key, value);
			sysObj.setString(idocsProperties.getProperty("MSG_SECURITY_CLASSIFICATION_KEY"), idocsProperties.getProperty("MSG_SECURITY_CLASSIFICATION_O_VALUE"));
		}else if(key.equalsIgnoreCase(idocsProperties.getProperty("SecurityClassification_Code")) && value.equalsIgnoreCase("C")){
//			sysObj.setString(key, value);
			sysObj.setString(idocsProperties.getProperty("MSG_SECURITY_CLASSIFICATION_KEY"), idocsProperties.getProperty("MSG_SECURITY_CLASSIFICATION_C_VALUE"));
		}else if(key.equalsIgnoreCase(idocsProperties.getProperty("SecurityClassification_Code")) && value.equalsIgnoreCase("S")){
//			sysObj.setString(key, value);
			sysObj.setString(idocsProperties.getProperty("MSG_SECURITY_CLASSIFICATION_KEY"), idocsProperties.getProperty("MSG_SECURITY_CLASSIFICATION_S_VALUE"));
		}else{
			value = "";
			sysObj.setString(key, value);
			sysObj.setString(idocsProperties.getProperty("MSG_SECURITY_CLASSIFICATION_KEY"), value);
		}
			
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("Exception During setting Security Classification::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"Exception during setting Security Classification:: "+sourceFilePath+":: and XML path::"+xmlPath, e);
			e.printStackTrace();
			
		}
	}
	
	private static void setDocumentObjectName(IDfSysObject sysObj,
			String documentName) {
		// TODO Auto-generated method stub
		String docObjNme = "";
		try {
			if(sysObj.getTypeName().toString().equals("idocs_project_doc") || sysObj.getTypeName().toString().equals("idocs_project_email")){
				if((sysObj.getString("project_id")+"_"+documentName).length()>255){
					docObjNme = (sysObj.getString("project_id")+"_"+documentName).substring(0, 255);
				}else{
					docObjNme = sysObj.getString("project_id")+"_"+documentName;
				}
				sysObj.setObjectName(docObjNme);
			}else if(sysObj.getTypeName().equals("idocs_institution_doc")){
				if((sysObj.getString("institution_nbr")+"_"+documentName).length()>255){
					docObjNme = (sysObj.getString("institution_nbr")+"_"+documentName).substring(0, 255);
				}else{
					docObjNme = sysObj.getString("institution_nbr")+"_"+documentName;
				}
				sysObj.setObjectName(docObjNme);
			}else if(sysObj.getTypeName().equals("idocs_country_doc")){
				if((sysObj.getString("country_code")+"_"+documentName).length()>255){
					docObjNme = (sysObj.getString("country_code")+"_"+documentName).substring(0, 255);
				}else{
					docObjNme = sysObj.getString("country_code")+"_"+documentName;
				}
				sysObj.setObjectName(docObjNme);
			}
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("Exception During setting document object Name::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"Exception during updating object name to the document:: "+sourceFilePath+":: and XML path::"+xmlPath, e);
			e.printStackTrace();
		}
		
	}
	private static String getDescriptionValue(String descriptionField) {
		// TODO Auto-generated method stub
		
		if(descriptionField.length() > 0 && descriptionField.length() <= 4000){
			
		}else if(descriptionField.length() > 4000){
			descriptionField = descriptionField.substring(0, 3500);
		} else{
			
		} 
		return descriptionField;
	}

	private static boolean setDocumentObjectACL(IDfSession dfSession, String objectIDofDoc, String compReaders, String compAuthors, String compEditors, String compManagers) {
		// TODO Auto-generated method stub
		
		
		if(compReaders !=null || !compReaders.equals("") 
				|| compAuthors !=null || !compAuthors.equals("")
					|| compEditors !=null || !compEditors.equals("")
						|| compManagers !=null || !compManagers.equals("")){
			
			if(updateDocumentACL(objectIDofDoc,3,compReaders)){
				if(updateDocumentACL(objectIDofDoc,6,compAuthors)){
					if(updateDocumentACL(objectIDofDoc,6,compEditors)){
						if(updateDocumentACL(objectIDofDoc,7,compManagers)){
							return true;
						}else{
							return false;
						}
					}else{
						return false;
					}
				}else{
					return false;
				}
			}else{
				return false;
			}
		}else{
			return true;
		}
		
	}

	private static boolean updateDocumentACL(String objectIDofDoc,int permLevel, String value) {
		// TODO Auto-generated method stub
		StringTokenizer stringTokenizer = new StringTokenizer(value,"#");
		String tokenValue = "";
		try {
			IDfSysObject syso = (IDfSysObject) dfSession.getObject(new DfId(objectIDofDoc));
			while(stringTokenizer.hasMoreTokens()){
				tokenValue = stringTokenizer.nextToken();
				String userNmeGrp = chkUserOSNameGroup(tokenValue);
				if(userNmeGrp != null && userNmeGrp.equals("")== false)
					{
					syso.grant(userNmeGrp, permLevel, "");
					}
			}
			return true;
		} catch (DfException e) {
			// TODO Auto-generated catch block
			raiseSetDocACLException(objectIDofDoc,tokenValue);
			//importDocLogger.info("Unable grant permissions to the user or group::");
			importDocLogger.warning("Updating failure for the custom security of the document::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"Exception during updating ACL to the document:: "+sourceFilePath+":: and XML path::"+xmlPath, e);
			e.printStackTrace();
			return false;
		}
	}

	private static void raiseSetDocACLException(String objectIDofDoc,
			String tokenValue) {
		// TODO Auto-generated method stub
		String skippedReason = "Utility is unable to update custom security to the document::["+objectIDofDoc+"]::["+tokenValue+"]";
		skippedReason = skippedReason.replaceAll("'", "''");
		skippedReason = skippedReason+"')";
		Utilities.addToSkippedReason(impUniqId,skipped_fldType_code,skipped_fldValue_code,legacyDocId,idocsProperties.getProperty("MIG_ERROR_CODE_57"),skippedReason);
	}
	private static String chkUserOSNameGroup(String tokenValue) {
		// TODO Auto-generated method stub
		IDfCollection collection = null;
		String userName = "";
		tokenValue = tokenValue.replaceAll("'", "''");
		String strUserQuery = idocsProperties.getProperty("MEG_GET_USER_QRY");
		strUserQuery = strUserQuery.replaceAll("<Token_Value>", tokenValue);
		String strGroupQuery = idocsProperties.getProperty("MEG_GET_GROUP_QRY");
		strGroupQuery = strGroupQuery.replaceAll("<Token_Value>", tokenValue);
		try {
			collection = Utilities.executeQuery(dfSession, strUserQuery,DfQuery.EXECREAD_QUERY);
			if(collection != null && collection.next()){
				userName = collection.getString("user_name");
				collection.close();
			}
		} catch (DfException e) {
			// TODO Auto-generated catch block
			//importDocLogger.info("Unable to fetch the value for the token::"+tokenValue);
			importDocLogger.warning("Unable to fetch the value for the token::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"Exception during fetching users names for ACL to the document:: "+sourceFilePath+":: and XML path::"+xmlPath, e);
			e.printStackTrace();
		}
		
		if(userName == null || userName.trim().equals("")== true){
			try {
				collection = Utilities.executeQuery(dfSession, strGroupQuery,DfQuery.EXECREAD_QUERY);
				if(collection != null && collection.next()){
					userName = collection.getString("group_name");
					collection.close();
				}
			} catch (DfException e) {
				// TODO Auto-generated catch block
				//importDocLogger.info("Unable to fetch the value for the token::"+tokenValue);
				importDocLogger.warning("Unable to fetch the value for the token::"+e.getMessage());
				importDocLogger.log(Level.WARNING,"Exception during fetching users names for ACL to the document:: "+sourceFilePath+":: and XML path::"+xmlPath, e);
				e.printStackTrace();
			}
		}
		//importDocLogger.info("Updating the custom security of the document");
		return userName;
	}
}