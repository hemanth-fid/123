package org.ifc.idocs.report.common;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.ifc.idocs.report.export.ExportUtility;

/**
 * @author SPankajamsadanan
 *
 */
public class LogHelper extends ExportUtility{

	private static AppConfig config = AppConfig.getInstance();
	
	protected static final String LogHelperFile = "/Report.properties";
	protected static Properties idocsLogProperties = new Properties();
	
	public static Logger logger = null;
	public static Map<String,Logger> loggerMap = new HashMap<String,Logger>();
	
	
	/**
	 * getLogger method creates new logger object and keeps it in session. 
	 * If logger object already exists in session then returns that object
	 * @param object
	 * @return Logger
	 */
	public static Logger getLogger(Object object){
		try{
			if(loggerMap.get("loggerMap") == null){ // if no logger exists in the session
				SimpleFormatter simpFormatter = new SimpleFormatter();
				utilityId = ExportUtility.utilityMap.get("utilityId");
				
				String dirPath = config.getString("repository.logPath");
				String fileName = dirPath+utilityId +".log";
				File fileDir = new File(dirPath);
				if(!fileDir.exists()){
						fileDir.mkdirs();
						FileHandler fileHandler = new FileHandler(fileName, 10240000, 10, false);
						fileHandler.setLevel(Level.WARNING);
						fileHandler.setFormatter(simpFormatter);
						logger = Logger.getLogger(object.getClass().getName());
						logger.setLevel(Level.WARNING);//only warnings will be printed in log file
						logger.addHandler(fileHandler);
						loggerMap.put("loggerMap",logger);
				}
				else
				{
					 fileName = config.getString("repository.logPath")+utilityId +".log";
					FileHandler fileHandler = new FileHandler(fileName, 10240000, 10, false);
					fileHandler.setLevel(Level.WARNING);
					fileHandler.setFormatter(simpFormatter);
					logger = Logger.getLogger(object.getClass().getName());
					logger.setLevel(Level.WARNING);//only warnings will be printed in log file
					logger.addHandler(fileHandler);
					loggerMap.put("loggerMap",logger);
				}
			}else{
				logger = loggerMap.get("loggerMap"); // assigns the logger from session
			}
		}catch (IOException ex){
			System.out.println("Log path not found / Path is write protected. Please update config.xml with a valid log path");
			System.exit(0);
			return null;
		}
		return logger;
	}
}