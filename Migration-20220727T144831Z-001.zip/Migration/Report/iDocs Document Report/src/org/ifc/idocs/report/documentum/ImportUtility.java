package org.ifc.idocs.report.documentum;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

import org.ifc.idocs.report.ReportUtility;
import org.ifc.idocs.report.common.AppConfig;
import org.ifc.idocs.report.common.LogHelper;
import org.ifc.idocs.report.db.ExportDAOImpl;
import org.ifc.idocs.report.db.ImportDAOImpl;

/**
 * @author VVellakkattumana
 * @see ImportUtility - extracts all sort of documents from lotus notes database
 *
 */
public class ImportUtility extends ReportUtility{
	
	private static AppConfig config = AppConfig.getInstance();
	private Logger exportDocLogger = LogHelper.getLogger(ImportUtility.class);
	private String folderQuery, country, extractionQuery, tableName, columnName, prefix, folderTypeCode;

	/**
	 * Constructor for ImportUtility
	 */
	public ImportUtility() {

		try{
			prefix = config.getString("filters.prefix");
			prefix = prefix.substring(0, 7);
			prefix = prefix + "%";
			extractionQuery = config.getString("filters.extractioncriteriacode");
			exportDocLogger.warning("EXTRACTION CRITERIA ID = " + extractionQuery );
			String[] extCriteria = extractionQuery.split(";");

			for(int k = 0; k < extCriteria.length; k++){
				String extractionId = extCriteria[k];
				exportDocLogger.warning("Extraction id = " + extractionId);
				ResultSet rs = ExportDAOImpl.getExtractionInfo(extractionId);
				try {
					while (rs.next()){
						folderQuery = rs.getString("FOLDER_QUERY_TXT");
						int start = folderQuery.indexOf("'");
						int end = folderQuery.lastIndexOf("'");
						country = folderQuery.substring(start + 1, end);
					}
					rs.close();
				} catch (SQLException e) {
					exportDocLogger.warning("Error : " + e);
				}

				if (country.length() > 3){
					country = country.substring(0, 3);
				}
				if(extractionId.contains("PRJ")){
					tableName = "idocs_project_doc(all)";
					columnName = "project_id";
					folderTypeCode = "PROJECTS";
				}else if(extractionId.contains("PTR")){
					tableName = "idocs_institution_doc(all)";
					columnName = "institution_nbr";
					folderTypeCode = "INSTITUTIONS";
				}
				ImportDAOImpl idao = new ImportDAOImpl();
				idao.updateReconTables(country, tableName, columnName, prefix, folderTypeCode, extractionId);
				exportDocLogger.warning("Reconciliation Report Completed for  : " + country);
				
				getNewUtilityId();
				LogHelper.loggerMap.put("loggerMap",null);
				exportDocLogger = LogHelper.getLogger(ImportUtility.class);
			}
			exportDocLogger.warning("Reconciliation Report Completed Successfully...!!!");			
		}
		catch (Exception e){
			exportDocLogger.warning("Initialization error");
			e.printStackTrace();
			System.exit(0);
		}
	}
}
