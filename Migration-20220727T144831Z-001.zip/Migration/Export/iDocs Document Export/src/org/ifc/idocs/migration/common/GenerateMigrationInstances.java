package org.ifc.idocs.migration.common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

public class GenerateMigrationInstances {

	private static AppConfig config = AppConfig.getInstance();

	public static void main(String[] args){
		
		String criterias = config.getString("createInstance.criterias");			
		String[] extCriteria = criterias .split(";");
		
		String src = config.getString("createInstance.src"), dest = null;
		File srcDir = new File(src);
		File trgDir = null;		
		
		for(int i=1; i<= extCriteria.length; i++){
			dest = config.getString("createInstance.dest") + i + "/";
			trgDir = new File(dest);
			copy(srcDir, trgDir);
			updateXML(src, dest, extCriteria[i-1]);
			System.out.println(dest + " folder created.");
		}
	}
	
	public static void updateXML(String src, String dest, String criteria){
		try{
			FileInputStream fis = new FileInputStream(src + "config.xml");
			FileWriter fw = new FileWriter(dest + "config.xml");
			
			DataInputStream in = new DataInputStream(fis);
			BufferedWriter out = new BufferedWriter(fw);
			
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			while ((strLine = br.readLine()) != null)   {
				if(strLine.contains("extractioncriteriacode")){
					out.write("<extractioncriteriacode>"+criteria+"</extractioncriteriacode>");
				}else{
					out.write(strLine);
				}
			}
			in.close();
			out.close();
		}catch (Exception e){//Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}

	public static void copy(File sourceLocation, File targetLocation){
		try {
	        if (sourceLocation.isDirectory()) {
	            if (!targetLocation.exists()) {
	                targetLocation.mkdir();
	            }
	            File[] files = sourceLocation.listFiles();
	            for(File file:files){
	                InputStream in = new FileInputStream(file);
	                OutputStream out = new FileOutputStream(targetLocation+"/"+file.getName());

	                byte[] buf = new byte[1024];
	                int len;
	                while ((len = in.read(buf)) > 0) {
	                    out.write(buf, 0, len);
	                }
	                in.close();
	                out.close();
	            }            
	        }
		}catch(IOException ioe){
			ioe.printStackTrace();
		}
	}
}
