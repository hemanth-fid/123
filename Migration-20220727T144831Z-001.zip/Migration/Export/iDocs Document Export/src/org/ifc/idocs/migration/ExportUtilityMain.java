package org.ifc.idocs.migration;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.Random;
import java.util.logging.Logger;

import org.ifc.idocs.migration.common.AppConfig;
import org.ifc.idocs.migration.common.CommonUtils;
import org.ifc.idocs.migration.extract.AsposeUtilities;
import org.ifc.idocs.migration.extract.DBConnection;
import org.ifc.idocs.migration.extract.LogHelper;

/**
 * @author VVellakkattumana
 * @see ExportUtilityMain - The main class of Export Utility
 * 
 */
public class ExportUtilityMain extends ExtractionRelatedVariables{
	protected static final String propertiesFile = "/Export.properties";
	protected static Properties idocsProperties = new Properties();
	private static AppConfig config = AppConfig.getInstance();
	private static String extractionCriteria = null;
	public static boolean fromTable = false;
	
	/**
	 * main method - starting of Export Utility
	 * @param args
	 * @return void
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		int choice = 0;
		extractionCriteria = config.getString("filters.extractioncriteriacode");
		getNewUtilityId();
		Logger exportDocLogger = LogHelper.getLogger(ExportUtilityMain.class);
		initialCheck();
		InputStream inputStream = ExportUtilityMain.class.getResourceAsStream(propertiesFile);
		try {
			idocsProperties.load(inputStream);
			System.out.println(System.getProperty("file.encoding"));
			System.out.println("");
			System.out.println("*******************************************************************");
			System.out.println("*              iDocs - Documents Export Utilities                 *");
			System.out.println("*******************************************************************");
			System.out.println("");
			System.out.println("\t 1. Baseline Export - Execute Export Utility ");
			System.out.println("\t 2. Baseline Export - Execute Export Workflow Audit Trial");
			System.out.println("");
			System.out.println("\t 3. Delta Export - Created/Updated Documents ");
			System.out.println("\t 4. Delta Export - Update Deletion Entries to Migration Table");
			System.out.println("\t 5. Delta Export - Workflow Audit Trial");
			System.out.println("\t 6. Delta Export - Modified Discussion Documents ");
			System.out.println("");
			System.out.println("\t 7. Delta Export - Documents Failed in Baseline Import");
			System.out.println("\t 8. Delta Export - Documents Failed in Baseline Export");
			System.out.println("");
			System.out.println("\t 9. Extract in Workflow/Checked out Documents");
			System.out.println("");
			System.out.println("\t 10. Baseline Extraction - Re-run");
			System.out.println("");
			System.out.println("\t 11. Extract Selected Documents From Table");
			System.out.println("");
			System.out.println("\t 12. Aspose Utility Re-run");
			System.out.println("");
			System.out.println("\t 13. Exit ");
			System.out.println("");
			System.out.println("*******************************************************************");
			System.out.print("Enter your Choice : ");
			
			String menuChoice = "";
			if(args.length < 1){
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				menuChoice = br.readLine();
			}else{
				menuChoice = args[0];
			}
			System.out.println("");

			if (menuChoice!= "") {
				try {
					choice = Integer.parseInt(menuChoice);
				} catch (NumberFormatException nfe) {
					choice = 0;
				}
			}

			switch (choice) {
			case 0:
				//Checks the memory status of the system
				exportDocLogger.warning("System Inspection :: " + choice);
				System.out.println("System Inspection...");
				break;
			case 1:
				exportDocLogger.warning("Execution Started...for menu choice :: " + choice);
				System.out.println("Executing Export Utility...");
				skipExtractedDocs = false;
				new ExtractDocuments();
				break;
			case 2:
				System.out.println("Executing Export Workflow Audit Trial...");
				new WorkflowAuditTrial();
				break;
			case 3:
				System.out.println("Delta Migration...Only modified documents will be extracted");
				new DeltaExtraction();
				break;
			case 4:
				System.out.println("Delta Migration- Updating deletion entries into migration table");
				new DeltaExtractionDeletedDocs();
				break;
			case 5:
				System.out.println("Delta Run - Workflow Audit Trial...");
				WorkflowAuditTrial.WorkflowAuditTrialDelta();
				break;			
			case 6:
				System.out.println("Delta Migration...Modified Discussion Documents");
				new DeltaDiscussionExtract();
				break;			
			case 7:
				System.out.println("Delta Migration of documents that failed during Import");
				new DeltaImportFailedDocs();
				break;
			case 8:
				System.out.println("Delta Migration of documents that failed during Extraction");
				new DeltaExtractFailedDocs();
				break;
			case 9:
				System.out.println("Extraction of checked out/Pending workflow documents started");
//				new GoLiveExtraction();
				break;
			case 10:
				System.out.println("Baseline Extraction - for abrupt utility termination");
				skipExtractedDocs = true;
				new ExtractDocuments();
				break;
			case 11:
				System.out.println("Extract Selected Documents From Table");
				fromTable = true;
				getNewUtilityId();
				new CountryProjectDocExtraction();
				break;
			case 12:
				System.out.println("Running Aspose Utilities now.");
				AsposeUtilities au = new AsposeUtilities();
				au.updateCustomProperties();
				exportDocLogger.warning("Aspose utility completed successfully");				
				break;
			case 13:
				System.out.println("Exit - Execution Ended.");
				exportDocLogger.warning("Execution Started...for menu choice :: " + choice);
				System.exit(0);
				break;
			default:
				exportDocLogger.warning("Invalid Entry Please provide your selection again..." + choice);
			}
		} catch (IOException e) {
			exportDocLogger.warning("IOException Exceptions in accessing the files :: " + e.getMessage());
			e.printStackTrace();
		}
	}
	
	/**
	 * initialCheck - checks all possible errors can occur during migration. 
	 * Displays error messages if any required credentials are missing
	 * @return void
	 */
	private static void initialCheck(){
//		System.out.println("Java Library Path : " + System.getProperty("java.library.path"), false);
		System.out.println("Initial check is under process...");
		System.out.println("Checking properties file...");
		CommonUtils.checkForConfigFile(idocsProperties, ExportUtilityMain.class.getResourceAsStream(propertiesFile), "Report", true);
		System.out.println("Checking folderman path...");
		CommonUtils.checkConfigAttributes("repository.foldermanPath", "Folderman Path", true);
		System.out.println("Checking server path...");
		CommonUtils.checkConfigAttributes("repository.server", "Server Name", true);
		System.out.println("Checking library path...");
		CommonUtils.checkConfigAttributes("repository.libPath", "Library Path", true);
		System.out.println("Checking export path...");
		CommonUtils.checkConfigAttributes("export.path", "Export Path", true);
		System.out.println("Checking log path...");
		CommonUtils.checkConfigAttributes("export.logPath", "Log Path", true);

		System.out.println("Checking Database driver...");
		CommonUtils.checkConfigAttributes("connection.driver", "Migration Database Driver", true);
		System.out.println("Checking Database connection...");
		CommonUtils.checkConfigAttributes("connection.connectionName", "Migration Database Connection Name", true);
		System.out.println("Checking Database user name...");
		CommonUtils.checkConfigAttributes("connection.u_name", "Migration Database User Name", true);
		System.out.println("Checking Database password...");
		CommonUtils.checkConfigAttributes("connection.password", "Migration Database Password", true);

		System.out.println("Checking Extraction Criteria Code...");
		CommonUtils.checkConfigAttributes("filters.extractioncriteriacode", "Extraction Criteria Code", true);
		
		System.out.println("Checking Database tables... Please wait...");
		DBConnection.databaseTableCheck();		
	}

	/**
	 * getNewUtilityId sets the new utility id in the hash map
	 * @return void
	 */
	public static void getNewUtilityId(){
		Date dts = new Date();
		Random randomGenerator = new Random();
		int randomInt = randomGenerator.nextInt(1000);
		String rndString = randomInt < 100 ? "0" + randomInt : randomInt + "";
		SimpleDateFormat sdt = new SimpleDateFormat("MMddyy_HHmmss");

		if(fromTable){
			LogHelper.loggerMap.put("loggerMap",null);
			utilityId = extractionCriteria + "_" + sdt.format(dts).toString();
			WorkflowAuditTrial.workflowMap.put("utilityId",utilityId);
		}else{
			utilityId = "EXPORTC_" + sdt.format(dts).toString()+ "_" + rndString;
			WorkflowAuditTrial.workflowMap.put("utilityId",utilityId);
		}
	}

}
