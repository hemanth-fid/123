package org.ifc.idocs.titlebar;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.LocaleService;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.Tabbar;
import com.documentum.webtop.app.AppSessionContext;


public class TitleBar extends
	com.documentum.webtop.webcomponent.titlebar.TitleBar {
	
	private static final long serialVersionUID = 637594505790388407L;
	private NlsResourceBundle nlsResourceBundle = new NlsResourceBundle("org.ifc.idocs.titlebar.TitleBarNlsProp");
	private Locale locale = LocaleService.getLocale();
	public void onInit(ArgumentList args) {
		super.onInit(args);
		try {
			setLoginUserName(getDfSession().getLoginUserName());
			setStrSearch(nlsResourceBundle.getString("MSG_GO", locale));
			strEntryId = args.get("entryNode");
			setHaveEntrySection(strEntryId != null && strEntryId.length() > 0);
			String entrySectionDetails=AppSessionContext.getEntryPointInView();
			if(entrySectionDetails != null && entrySectionDetails.trim().length() >0 && entrySectionDetails.equals(CONTROL_INBOX)){
				setTab(CONTROL_INBOX);
				AppSessionContext.setEntryPointInView(CONTROL_INBOX);
			}else{
				HttpServletRequest request = (HttpServletRequest) this.getPageContext().getRequest();
				String pageUrl=request.getRequestURL().toString();
				if(pageUrl.contains(TitleBar.STR_TASK_STARTINGARGS1) ||pageUrl.contains(TitleBar.STR_TASK_STARTINGARGS2)){
					AppSessionContext.setEntryPointInView(TitleBar.CONTROL_INBOX);
				}else{
					firstHit=true;
					if(isHaveEntrySection()){
						setTab(CONTROL_CABINETS);
						AppSessionContext.setEntryPointInView(CONTROL_CABINETS);
					}else{
						setTab(strDefaultTab);
						AppSessionContext.setEntryPointInView(strDefaultTab);
					}
				}
			}
		} catch (DfException e) {
			DfLogger.error(this, " :: onInit Exception >>> :: "+e.getMessage(),null,null);
		}
	}
		
	public void onLoadPageEventInbox(Control control, ArgumentList args){
		setTab(CONTROL_INBOX);
	}
	
	public void onTabClick(Control control, ArgumentList args){
		fireTabClick(control.getName(), true);
	}

	private void fireTabClick(String strTabId, boolean refreshComponent) {
		String selectedComp= AppSessionContext.getEntryPointInView();
		if(selectedComp != null && selectedComp.length() > 0 &&!selectedComp.equals(strTabId) ){
			AppSessionContext.setEntryPointInView(strTabId);
		}
		ArgumentList clientArgs = new ArgumentList();
		clientArgs.add("compid", strTabId);
		clientArgs.add("refreshComponent", Boolean.toString(refreshComponent));
		setTab(strTabId);
		setClientEvent("onClickTab",clientArgs);	
	}
	public void onClickfolderPath(Control control, ArgumentList args){
		setTab(CONTROL_CABINETS);
	}
	
	public void onClickFavorites(Control control, ArgumentList args){
		setTab(strDefaultTab);
	}
	
	public void onClickInboxClassic(Control control, ArgumentList args){
		setTab(CONTROL_INBOX);
	}
	
	public boolean isOnClickImageStatus() {
		return onClickImageStatus;
	}

	public void setOnClickImageStatus(boolean onClickImageStatus) {
		this.onClickImageStatus = onClickImageStatus;
	}
	
	public void onClickImage(Control control, ArgumentList args){
		Tabbar tabbar = (Tabbar) getControl(CONTROL_TABBAR,Tabbar.class);
		setOnClickImageStatus(true);
		fireTabClick(tabbar.getValue(), true);
	}
	public boolean isHaveEntrySection() {
		return haveEntrySection;
	}
	public void setHaveEntrySection(boolean haveEntrySection) {
		this.haveEntrySection = haveEntrySection;
	}
	public String getStrSearch() {
		return strSearch;
	}
	public void setStrSearch(String strSearch) {
		this.strSearch = strSearch;
	}

	public String getLoginUserName() {
		return LoginUserName;
	}

	public void setLoginUserName(String loginUserName) {
		LoginUserName = loginUserName;
	}

	private void setTab(String entryTab){
		Tabbar tabbar = (Tabbar) getControl(CONTROL_TABBAR,Tabbar.class);
		if(tabbar != null){
			tabbar.setValue(entryTab);	
		}
	 }
	public String getLastSelectedTab(){
		Tabbar tabbar = (Tabbar) getControl(CONTROL_TABBAR,Tabbar.class);
		return tabbar.getValue();
	}

	public static String CONTROL_TABBAR="titletabs";
	public static String CONTROL_INBOX="inboxclassic";
	public static String CONTROL_SUBSCRIPTIONS="subscriptions_classic";
	public static String CONTROL_SAVEDSEARCHES="searchstoreclassic";
	public static String CONTROL_CABINETS="cabinets";
	public static String CONTROL_HELP="help";
	public String LoginUserName=""; 	
	public static String STR_TASK_STARTINGARGS1="objectId=1b";
	public static String STR_TASK_STARTINGARGS2="objectId/1b"; 
	private String strSearch="";
	boolean haveEntrySection =false;
	private String strEntryId="";
	private String strDefaultTab ="subscriptions_classic";
	boolean firstHit=false;
	private boolean onClickImageStatus=false; 
	public final static String ARG_ENTRY_NODE = "entryNode";
	public final static String ARG_ENTRY_ID = "entryId";

 }
