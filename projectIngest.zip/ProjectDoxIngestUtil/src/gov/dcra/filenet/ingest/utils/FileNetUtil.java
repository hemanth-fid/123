package gov.dcra.filenet.ingest.utils;

import java.io.InputStream;
import java.util.Map;

import org.apache.log4j.Logger;

import com.filenet.api.collection.ContentElementList;
import com.filenet.api.constants.AutoClassify;
import com.filenet.api.constants.AutoUniqueName;
import com.filenet.api.constants.CheckinType;
import com.filenet.api.constants.DefineSecurityParentage;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.Document;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.util.Id;

/**
 * @author Administrator
 *
 */
public class FileNetUtil {

	private static Logger log = Logger.getLogger(FileNetUtil.class);
	
	public Folder getFolder(ObjectStore os,String folderPath) throws Exception {
		Folder folder=null;
		folder=Factory.Folder.fetchInstance(os, folderPath, null); 
		return folder;
	}
	
	public static Id create(Object parent,InputStream fileStream,Map<String, String> propertiesMap) throws Exception {
		
		Id docId=null;
		Folder folder = (Folder) parent;
		
		Document document = createDocument(folder.getObjectStore(),fileStream,propertiesMap);
		folder.file(document, AutoUniqueName.AUTO_UNIQUE, null,
				DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE).save(
						RefreshMode.NO_REFRESH);
		docId=document.get_Id();
		return docId;
	}

	private static Document createDocument(ObjectStore objectStore,InputStream fileStream,Map<String, String> propertiesMap) throws Exception  {
		Document document = Factory.Document.createInstance(objectStore, propertiesMap.get("className"));
		setProperties(document.getProperties(),propertiesMap);
		document.set_ContentElements( getContentElements(fileStream,propertiesMap));
		document.checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION );
		document.save(RefreshMode.REFRESH);
		return document;
	}

	private static void setProperties(com.filenet.api.property.Properties p,Map<String, String> propertiesMap) {
		for(Map.Entry<String,String> map:propertiesMap.entrySet()){
			p.putValue(map.getKey(),map.getValue());
		}
	}
	
	@SuppressWarnings("unchecked")
	private static ContentElementList getContentElements(InputStream fileStream,Map<String, String> propertiesMap)  throws Exception {
		ContentElementList contentElementList = Factory.ContentElement.createList();
		contentElementList.add( createStringContent(fileStream,propertiesMap) );
		return contentElementList;
	}

	private static ContentTransfer createStringContent(InputStream fileStream,Map<String, String> propertiesMap)  throws Exception {
		ContentTransfer content = Factory.ContentTransfer.createInstance();
		content.set_RetrievalName(propertiesMap.get("fileName"));
		content.setCaptureSource(fileStream);
		//content.set_ContentType("text/plain");
		content.set_ContentType(propertiesMap.get("fileFormat"));
		
		return content;
	}
	
	
	public static void deleteDoc(ObjectStore os,String docId) throws Exception {
		Document doc = Factory.Document.fetchInstance(os, new Id(docId),null);
		doc.delete();
		doc.save(RefreshMode.REFRESH);
	}

}
