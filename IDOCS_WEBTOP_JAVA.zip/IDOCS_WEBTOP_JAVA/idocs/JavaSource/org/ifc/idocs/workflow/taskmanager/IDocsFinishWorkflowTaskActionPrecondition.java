package org.ifc.idocs.workflow.taskmanager;

import com.documentum.fc.client.IDfWorkitem;
import com.documentum.fc.common.DfException;
import com.documentum.services.workflow.inbox.IWorkflowTask;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.WrapperRuntimeException;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.webcomponent.library.workflow.WorkflowUtil;

public class IDocsFinishWorkflowTaskActionPrecondition extends com.documentum.webcomponent.library.workflow.taskmanager.FinishWorkflowTaskActionPrecondition{
	
	public boolean queryExecute(String strAction, IConfigElement config, ArgumentList args, Context context, Component component)
    {
        boolean bExecute = false;
        try
        {
            IWorkflowTask task = getWorkflowTask(component, args.get("objectId"));
            int finishTaskpreconditiontaskState = task.getTaskState();
            IDfWorkitem witem = (IDfWorkitem)component.getDfSession().getObject(task.getItemId());
            String taskOwner = witem.getPerformerName();
            String strIsManual;
            String strIsFailedAutoTask;
            String strCanCompleteTask;
            String strHasEmptyMandatoryPkg;
            if(finishTaskpreconditiontaskState==1 && taskOwner!=null && taskOwner.trim().length() > 0 && taskOwner.equals(component.getDfSession().getLoginUserName())){
            	bExecute = true;
            }else if((strCanCompleteTask = args.get("canCompleteTask")) != null && strCanCompleteTask.length() > 0 && (strIsManual = args.get("isManual")) != null && strIsManual.length() > 0 && (strIsFailedAutoTask = args.get("isFailedAutoTask")) != null && strIsFailedAutoTask.length() > 0 && (strHasEmptyMandatoryPkg = args.get("hasEmptyMandatoryPkg")) != null && strHasEmptyMandatoryPkg.length() > 0)
                bExecute = Boolean.valueOf(strCanCompleteTask).booleanValue() && !Boolean.valueOf(strIsManual).booleanValue() && !Boolean.valueOf(strIsFailedAutoTask).booleanValue() && !Boolean.valueOf(strHasEmptyMandatoryPkg).booleanValue() && canCompleteTask(task, args, component);
            else
                bExecute = canCompleteTask(task) && !task.isManualTransition() && !task.isFailedAutoTask() && !WorkflowUtil.hasEmptyMandatoryPackage(task) && canCompleteTask(task, args, component);
        }
        catch(DfException e)
        {
            throw new WrapperRuntimeException(e);
        }
        return bExecute;
    }

    public String[] getRequiredParams()
    {
        return (String[])s_requiredParams.clone();
    }

    private static final String s_requiredParams[] = {
        "objectId"
    };
    
}
