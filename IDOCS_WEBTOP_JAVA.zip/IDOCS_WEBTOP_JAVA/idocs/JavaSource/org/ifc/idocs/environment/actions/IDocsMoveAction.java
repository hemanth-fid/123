package org.ifc.idocs.environment.actions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.library.actions.LaunchViewComponentWithPermitCheck;
import org.ifc.idocs.utils.IDocsClipboardPasteHandler;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.ErrorMessageService;
import com.documentum.web.formext.clipboard.IClipboard;
import com.documentum.web.formext.clipboard.IClipboardPasteHandler;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.docbase.FolderUtil;
import com.documentum.web.formext.docbase.ObjectCacheUtil;
import com.documentum.webcomponent.environment.actions.MoveAction;

public class IDocsMoveAction extends MoveAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String MOVE_OPERATION_NAME = "Move";
	public static final String MSG_MOVED = "Document Moved";
	public static NlsResourceBundle m_nlsResourceBundle = new NlsResourceBundle("org.ifc.idocs.clipboard.ClipboardErrorsNlsProp");
	private static final String STR_REPLACE_FROMQUERY="'<objectId>'";

    public boolean execute(String strAction, IConfigElement config, ArgumentList args, 
    		Context context, Component component, Map completionArgs){
        boolean bExecutionSucceded = false;
        IClipboard clipboard = component.getClipboard();
        IClipboardPasteHandler handler;
        boolean canProceed = false;
        if((handler = getClipboardPasteHandler(args, component)) != null){
        	if(clipboard.hasItems()){
                String clipItems[] = clipboard.getItemIds();
                String destinationFolderId = handler.getDestinationId();
            	try {
					preProcessObjects(destinationFolderId,clipItems,component);
					canProceed = true;
				} catch (DfException e) {
					ErrorMessageService.getService().setNonFatalError(m_nlsResourceBundle, "MSG_FULL_CUSTOM_MESSAGE", component, new String[]{e.getMessage()}, null);					
				}
				if(canProceed == false){
					DfLogger.debug(this, "Move operation cannot proceed as the Document Validation Failed ", null, null);
					return false;
				}else{
					DfLogger.debug(this, "Move operation Proceed as the Document Validation Success. ", null, null);
				}
        	
            	if(clipItems != null){
                    String arrParentFolderPaths[] = getFolderPaths(component.getComponentId(), component.getCurrentDocbase(), clipItems);
                    component.getPageContext().setAttribute("PROPERTY_HIDDEN_COLLAPSE", arrParentFolderPaths, 3);
                }
                
            	clipboard.pasteAsMove(clipboard.getItemIds(), handler);
                bExecutionSucceded = true;  
                canProceed = postMoveAttributeUpdation(clipItems,destinationFolderId,component);
            }
        } else {
            throw new IllegalArgumentException("Component must implement IClipboardPasteHandler!");
        }
        return bExecutionSucceded;
    }
    
    private void preProcessObjects(String destinationFolderId, String[] clipItems, Component component) throws DfException {
    	for (int i = 0; i < clipItems.length; i++) {
    		String currentObjectId = clipItems[i];
    		if(currentObjectId!=null && currentObjectId.trim().length() > 0){
    			IDfSysObject currentObject = (IDfSysObject)ObjectCacheUtil.getObject(component.getDfSession(), currentObjectId);
    			ArgumentList promptArguments = new ArgumentList();
        		promptArguments.add("objectId", currentObject.getObjectId().getId());
        		
        		HashMap<String, String> docValuesMap = new HashMap<String, String>();
				docValuesMap=IdocsUtil.getRequiredAttributesValues(currentObject.getObjectId().getId(), component.getDfSession());
				
    			if(LaunchViewComponentWithPermitCheck.validateUserPermissionsForView(true,currentObject.getObjectId().getId(), component.getDfSession(),docValuesMap) == false){
    				throw new DfException("You are not Authorised to Move '"+currentObject.getObjectName()+"'.");
    			}
    			IDocsClipboardPasteHandler.checkIDocsDocumentCopyOperationRule(currentObject, destinationFolderId, component.getDfSession(),MOVE_OPERATION_NAME);
    		}else{
    			DfLogger.error(this, " : Object Id got from Clipboard in Null ", null, null);
    		}
		}
	}
    
  
	/**
	 * 
	 * @param clipItems
	 * @param destinationFolderId
	 * @param component
	 * @return
	 */

	private boolean postMoveAttributeUpdation(String[] clipItems,String destinationFolderId, Component component){
		try{
			IDfFolder targerFolder = null;
			IDfFolder parentTargetFolder = null;
			if(destinationFolderId != null && destinationFolderId.trim().length() > 0){
				targerFolder = (IDfFolder)ObjectCacheUtil.getObject(component.getDfSession(), destinationFolderId);
				parentTargetFolder = IDocsClipboardPasteHandler.getParentFolder(component.getDfSession(),targerFolder);
			}
			
			for (int i = 0; i < clipItems.length; i++) {
				String destinationObjectId = clipItems[i];
				if(destinationObjectId!=null && destinationObjectId.trim().length()>0
						&& parentTargetFolder != null ){
					IDfSysObject movedObject = (IDfSysObject)ObjectCacheUtil.getObject(component.getDfSession(), destinationObjectId);
					IdocsUtil.updateAttribute(component.getDfSession(), movedObject, parentTargetFolder, IDocsConstants.IDOCS_MOVE_OPERATION);
					IdocsUtil.auditIDocsActivity(MSG_MOVED,destinationObjectId,component.getDfSession());
					/**
					 * Virtual Document Move operation Handling   
					 */
					if(movedObject.isVirtualDocument()){
						/** verifying Email Aspect attached or not ... */
						ArrayList<String> aspectNames= new ArrayList<String>();	
						boolean aspectExistance=false;
						int aspectCount=movedObject.getValueCount(IdocsConstants.R_ASPECT_NAME);
						if(aspectCount > 0){
							for (int iter1 = 0; iter1 < aspectCount; iter1++) {
								aspectNames.add(movedObject.getRepeatingString(IdocsConstants.R_ASPECT_NAME, iter1));
							}
						}else {
							DfLogger.debug(this, "postMoveAttributeUpdation :: Aspect are not attached on this docuemnt ", null, null);
							DfLogger.info(this, "postMoveAttributeUpdation :: Aspect are not attached on this docuemnt ", null, null);
						}
						if(aspectNames != null && aspectNames.size() > 0){
							if(aspectNames.contains(IdocsConstants.IDOCS_EMAIL_DOC_ASPECT)){
								aspectExistance=true;
								DfLogger.debug(this, "postMoveAttributeUpdation :: Email virtual document aspectNames "+aspectNames, null, null);
								DfLogger.info(this, "postMoveAttributeUpdation :: Email virtual document aspectNames "+aspectNames, null, null);
							}else{
								DfLogger.debug(this, "postMoveAttributeUpdation :: Email aspect is not attached ::"+aspectNames, null, null);
								DfLogger.info(this, "postMoveAttributeUpdation :: Email aspect is not attached ::"+aspectNames, null, null);
							}
						}else{
							DfLogger.debug(this, "copyObjectEx :: aspectNames are none ", null, null);
							DfLogger.info(this, "copyObjectEx :: aspectNames are none ", null, null);
						}
						
						DfLogger.info(this, "postMoveAttributeUpdation :: Email virtual document aspect Existance "+aspectExistance, null, null);
						if(aspectExistance){
							List<String> emailVirtualdocChilds= getChildDocumentIds(movedObject.getObjectId().toString(), component.getDfSession());
							DfLogger.info(this, "postMoveAttributeUpdation :: Email virtual document "+emailVirtualdocChilds, null, null);
							if(emailVirtualdocChilds != null && emailVirtualdocChilds.size() >0){
								/** emailed virtual document  is having children */
								String hiddenFolderObjectId= null;	
								
								/** Checking for hidden folder inside the project/partner/(country) folder */
								String hiddenFolderQuery="select r_object_id from dm_folder where any i_folder_id='"+destinationFolderId+"'";
								IDfCollection templateDocCollection = IdocsUtil.executeQuery(component.getDfSession(),hiddenFolderQuery,IDfQuery.DF_EXEC_QUERY);
								if(templateDocCollection != null){
									while (templateDocCollection.next()){
										hiddenFolderObjectId =templateDocCollection.getString(IDocsConstants.MSG_R_OBJECT_ID);
								    }
								}else {
									 DfLogger.info(this, "postMoveAttributeUpdation :: Hidden folder Collection is null ", null, null);
								}
								for (int idxNewObj = 0; idxNewObj < emailVirtualdocChilds.size(); idxNewObj++) {
									IDfSysObject newObj = (IDfSysObject)component.getDfSession().getObject(new DfId(emailVirtualdocChilds.get(idxNewObj)));
									String docFolder =newObj.getRepeatingString("i_folder_id", 0);
									if(hiddenFolderObjectId != null && hiddenFolderObjectId.trim().length() >0
											&& !hiddenFolderObjectId.equals(IDocsConstants.BLANK_OBJECT_ID)){
										DfLogger.info(this, "postMoveAttributeUpdation :: Hidden folder is Existed ", null, null);
										IdocsUtil.updateAttributeAndchildDocDestination(component.getDfSession(), newObj, parentTargetFolder,IDocsConstants.IDOCS_MOVE_OPERATION,hiddenFolderObjectId,docFolder);
									}else {
										DfLogger.info(this, "postMoveAttributeUpdation :: Hidden folder not is Existed ", null, null); 
										/**Creating Hidden folder */
										
										String category = getFolderCategoryString(parentTargetFolder);
										if(category != null && category.trim().length()>0){
											String folderId = createFolder(category,parentTargetFolder.getObjectId(),component.getDfSession());
											if(folderId != null && folderId.trim().length() >0 && ! folderId.equals(IDocsConstants.BLANK_OBJECT_ID)){
												DfLogger.info(this, "postMoveAttributeUpdation :: new-folder(Hidden) folderId ::"+folderId, null, null);
												IdocsUtil.updateAttributeAndchildDocDestination(component.getDfSession(), newObj, parentTargetFolder,IDocsConstants.IDOCS_MOVE_OPERATION,folderId,docFolder);
											}else{	
												DfLogger.info(this, "postMoveAttributeUpdation :: new folder Creation got failed :: Updating Attributes and listing in parent folder", null, null);
												IdocsUtil.updateAttribute(component.getDfSession(), newObj, parentTargetFolder, IDocsConstants.IDOCS_MOVE_OPERATION);
											}
										}else{
											DfLogger.info(this, "postMoveAttributeUpdation :: Category Creation fialed  ::", null, null);
											IdocsUtil.updateAttribute(component.getDfSession(), newObj, parentTargetFolder, IDocsConstants.IDOCS_MOVE_OPERATION);
										}
									}
									IdocsUtil.auditIDocsActivity(MSG_MOVED,newObj.getObjectId().getId(),component.getDfSession());
								}
							}else{
								DfLogger.info(this, "postMoveAttributeUpdation :: virtual document not having child ::", null, null);
							}
						}else{
							DfLogger.info(this, "postMoveAttributeUpdation :: Aspect Not Attached ::", null, null);
						}
					}else{
						DfLogger.info(this, "postMoveAttributeUpdation :: Not a Virtual document ::", null, null);
					}
				}else{
					DfLogger.info(this, "postMoveAttributeUpdation :: No destination folder ::", null, null);
				}
			}
		}catch (Exception e) {
			DfLogger.error(this, " : Attribute Updation Failed : Abort "+e.getMessage(), null, null);
			return false;
		}	
		return true;
	}

	IClipboardPasteHandler getClipboardPasteHandler(ArgumentList args, Component component){
        return component.getClipboardPasteHandler();
    }
	
    private String[] getFolderPaths(String componentId, String strDocbaseName, String clipItems[])
    {
        String arrFolderPaths[] = new String[clipItems.length];
        for(int iValue = 0; iValue < clipItems.length; iValue++)
        {
            String strFolderId = FolderUtil.getFolderIdsFromPath(FolderUtil.getPrimaryFolderPath(clipItems[iValue]));
            if(strFolderId == null)
                continue;
            String strFolderIds = strFolderId.substring(strFolderId.indexOf(".0b") + 1, strFolderId.length());
            StringBuffer sbFolderPath = new StringBuffer("_ROOT");
            sbFolderPath.append(".").append(strDocbaseName).append(".");
            if(componentId.equals("objectlist"))
                sbFolderPath.append("/").append(strDocbaseName).append(".").append(strFolderId);
            else
                sbFolderPath.append(componentId).append(".").append(strFolderIds);
            arrFolderPaths[iValue] = sbFolderPath.toString();
        }

        return arrFolderPaths;
    }
    
	/**
	 * 
	 * @param parentFolder
	 * @return
	 */
	private String getFolderCategoryString(IDfFolder parentFolder){
		String categoryString=null;
		try {
			if (parentFolder != null) {
				// check if it s an allowed folder
				if (parentFolder.getTypeName().equals(IdocsConstants.PROJ_FOLDER_TYPE)){
					categoryString="PROJECT_"+parentFolder.getString(IDocsConstants.PROJECT_ID);
				}else if(parentFolder.getTypeName().equals(IdocsConstants.INSTITUTION_FOLDER_TYPE)){
					categoryString="PARTNER_"+parentFolder.getString(IDocsConstants.INSTITUTION_NBR);
				}
			}
		} catch (DfException e) {
			// TODO Auto-generated catch block
			DfLogger.error(this, " getFolderCategoryString :: "+e.getMessage(), null, null);
		}
		return categoryString;
	}
	
	/**
	 * 
	 * @param objectName
	 * @param folderPath
	 * @return
	 * @throws IOException
	 */
	
	private String createFolder(String objectName, IDfId  parentFolder, IDfSession dfSession) throws IOException {
		try {
			IDfSysObject newFolder = (IDfFolder) dfSession.newObject("dm_folder");
			newFolder.setObjectName(objectName);
			newFolder.link(parentFolder.getId());
			newFolder.setBoolean("a_is_hidden", true);
			newFolder.save();
			return newFolder.getObjectId().toString();
		} catch(DfException e){
			DfLogger.error(this, " createFolder ::"+e.getMessage(), null, null);
			return null;
		}
	}
	
   /**
	 * 
	 * @param objectId
	 * @param dfSession
	 * @return
	 */
	private static List<String> getChildDocumentIds(String objectId,IDfSession dfSession){
		String childDocuemntsQuery= IdocsUtil.getMessage("VDM_CHILDQUERY");
		childDocuemntsQuery =childDocuemntsQuery.replace(STR_REPLACE_FROMQUERY,("'"+objectId+"'"));
	    IDfCollection childCollection= null;
	    List<String> childObjectIds = new ArrayList<String>();
	    try {
			childCollection= IdocsUtil.executeQuery(dfSession,childDocuemntsQuery,IDfQuery.DF_EXEC_QUERY);
			DfLogger.info(IDocsClipboardPasteHandler.class, " getChildDocumentIds : childObjectIds query "+childDocuemntsQuery, null, null);
			String childObjectId=null;
			if(childCollection != null){
				while (childCollection.next()){
					childObjectId  =childCollection.getString(IDocsConstants.MSG_R_OBJECT_ID);
					if(childObjectId != null && childObjectId.trim().length() >0 && !childObjectId.equals(IDocsConstants.BLANK_OBJECT_ID))
						childObjectIds.add(childObjectId);
				}
				DfLogger.info(IDocsClipboardPasteHandler.class, " getChildDocumentIds : childObjectIds for("+objectId+")"+childObjectIds, null, null);
			}
		} catch (DfException e) {
			// TODO Auto-generated catch block
			DfLogger.error(IDocsClipboardPasteHandler.class, " getChildDocumentIds : " + e.getMessage(), null, null);
		}
		return childObjectIds;
	}
	
	/**
	 * 
	 * @param componentId
	 * @param strDocbaseName
	 * @param clipItems
	 * @return
	 */

    
}
