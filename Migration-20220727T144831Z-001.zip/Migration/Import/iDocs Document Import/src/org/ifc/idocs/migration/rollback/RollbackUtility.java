package org.ifc.idocs.migration.rollback;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.StringTokenizer;
import java.util.logging.Level;

import org.ifc.idocs.migration.helper.UpdateDB;
import org.ifc.idocs.migration.helper.Utilities;
import org.ifc.idocs.migration.importUtility.ImportUtility;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
/**
 * RollbackUtility - Rollback utility to clean up migration failed documents and modified documents. 
 * @author HAnuganti
 * 
 * #############################################################################################
 * Author		            DateofChange	 Version	  ModificationHistory
 * ###########################################################################################
 * Hemachandra Anuganti 
 * ###########################################################################################
 * 
 */
public class RollbackUtility extends ImportUtility {

	public static void performFunction() {
		String region = idocsProperties.getProperty("MSG_REGION_NAME");
		StringTokenizer regionTokens = new StringTokenizer(region, ",");
		while (regionTokens.hasMoreTokens()) {
			String ext_region_name = regionTokens.nextToken();
			String queryLegacyID = idocsProperties.getProperty("MSG_SELECT_LEGACY_DOCUMENT_ID");
			queryLegacyID = queryLegacyID.replaceAll("<region>", ext_region_name);

			//Getting DB Connection
			ResultSet rsLegacyIDs = UpdateDB.selectFrmDatabse(queryLegacyID);
			String rlbkLegacyDocId = "";
			try {
				while (rsLegacyIDs.next()) {
					rlbkLegacyDocId = rsLegacyIDs.getString("LEGACY_DOCUMENT_ID");

					//Querying for r_object_id and performing the roll back
					String rlbkStatus = "R";
					if(performRollback(rlbkLegacyDocId,rlbkStatus)){
					
						//Updating region table
						updateRegionTable(ext_region_name,rlbkLegacyDocId);
					}
				}
				if(rsLegacyIDs != null){
					rsLegacyIDs.close();
				}
				//importDocLogger.info("no more legacy id in " + ext_region_name+ " region");
			} catch (SQLException e) {
				importDocLogger.warning("SQLException::"+e.getMessage());
				importDocLogger.log(Level.WARNING,"SQLException during processing legacyid :: "+rlbkLegacyDocId, e);
				e.printStackTrace();
			}
		}//end of while
	}

	private static boolean checkObjectID(String objectId, String Table,String type) {
		// TODO Auto-generated method stub
		boolean chkObjectIDFlag = false;
		String chkObjectID = idocsProperties.getProperty("MSG_CHECK_ID");
		chkObjectID = chkObjectID.replaceAll("<table>", Table);
		chkObjectID = chkObjectID.replaceAll("<r_object_id>", objectId);
		chkObjectID = chkObjectID.replaceAll("<type>", type);
		try {
			IDfCollection collection6 = Utilities.executeQuery(dfSession, chkObjectID, DfQuery.EXECREAD_QUERY);
			if (collection6 != null && collection6.next()) {
				chkObjectIDFlag = true;
				collection6.close();
			} 
		} catch (DfException e) {
			importDocLogger.warning("DfException::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"DfException during Checking the object id:: "+objectId, e);
			e.printStackTrace();
			return chkObjectIDFlag;
		}
		return chkObjectIDFlag;
	}

	public static void callCleanup() {
		// TODO Auto-generated method stub
		
		String cleanLegacyDocId = "";
		try {
			String SelectLegacyIDfrmDeletion = idocsProperties.getProperty("MSG_SELECT_LEGACY_FRM_DELETION");
			ResultSet LegacyIDfrmDelTBL = UpdateDB.selectFrmDatabse(SelectLegacyIDfrmDeletion);
			while (LegacyIDfrmDelTBL.next()) {
				cleanLegacyDocId = LegacyIDfrmDelTBL.getString("LEGACY_DOCUMENT_UNID");
				String deltaStatus = "D";
					String ident = "";
						if(performRollback(cleanLegacyDocId,deltaStatus)){

							//Update deletion list table
							ident = "Y";
							updateDeletionList(cleanLegacyDocId,ident);
						}else{
							ident = "N";
							updateDeletionList(cleanLegacyDocId,ident);
						}
					}
			if(LegacyIDfrmDelTBL != null){
				LegacyIDfrmDelTBL.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("SQLException::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"DfException during Checking the object id:: "+cleanLegacyDocId, e);
			e.printStackTrace();
		}
	}

	private static void updateDeletionList(String legacyDocId3, String ident) {
		// TODO Auto-generated method stub
		String updateQuery = idocsProperties.getProperty("MSG_UPDATE_LEGACY_FRM_DELETION");
		if(ident.equals("Y")){
			updateQuery = updateQuery.replaceFirst("<Identity>", ident);
		}else if(ident.equals("N")){
			updateQuery = updateQuery.replaceFirst("<Identity>", ident);
		}
		updateQuery = updateQuery.replaceFirst("<legacy_doc_unid>", legacyDocId3);
		UpdateDB.updateDatabase(updateQuery);
	}

	public static boolean performRollback(String legacyDocId,String deltaStatus) {
		// TODO Auto-generated method stub
		boolean rbkFlag = false;

		String queryObjectID = "";
		if(deltaStatus.equals("M") || deltaStatus.equals("R")){
			queryObjectID = idocsProperties.getProperty("MSG_SELECT_OBJECT_M_R_CLEANUP_LEGACY_ID");
			queryObjectID = queryObjectID.replaceFirst("<orig_doc_id>", legacyDocId);	
		}else if(deltaStatus.equals("D")){
			queryObjectID = idocsProperties.getProperty("MSG_SELECT_OBJECT_D_CLEANUP_LEGACY_ID");
			queryObjectID = queryObjectID.replaceFirst("<orig_doc_unique_id>", legacyDocId);
		}
		String iChronicleID = "";
		String rObjectID = "";
		IDfCollection legColection = null;
		boolean hasUniqueIDsFound = false;
		try {
			legColection = Utilities.executeQuery(dfSession, queryObjectID, DfQuery.DF_READ_QUERY);
				while (legColection.next()) {
					hasUniqueIDsFound =true; 
					rObjectID = legColection.getString("r_object_id");
					iChronicleID = legColection.getString("i_chronicle_id");

					// delete document history HISTORY
					if (checkObjectID(rObjectID, idocsProperties.getProperty("MSG_DEL_OLD_DOC_AUDIT_REPORT"), idocsProperties.getProperty("MSG_DEL_OLD_DOC_TYPE"))) {
						
//						Delete History for the object id
						String delHistory = idocsProperties.getProperty("MSG_DELETE_HISTORY");
						delHistory = delHistory.replaceAll("<r_object_id>",rObjectID);
						Utilities.executeQuery(dfSession, delHistory, DfQuery.EXECREAD_QUERY);
					} else {
						//importDocLogger.info("no corresponding OBJECT_ID found in document_audit_report");
					}

					//					Delete Workflow audits in all the WF tables
					if (checkObjectID(rObjectID, idocsProperties.getProperty("MSG_DEL_OLD_WORKFLOW_AUDIT_REPORT"), idocsProperties.getProperty("MSG_DEL_OLD_WORKFLOW_DOCID"))) {
						String wfAuditRep = idocsProperties.getProperty("MSG_DEL_WF_AUDITS");
						wfAuditRep = wfAuditRep.replaceFirst("<documentid>", rObjectID);
						IDfCollection wfCollection1 = Utilities.executeQuery(dfSession, wfAuditRep, DfQuery.DF_READ_QUERY);
						while(wfCollection1.next()){
							String wfID = wfCollection1.getString("workflowid");
							String tabls = idocsProperties.getProperty("MSG_WF_AUDITS_TABLES"); 
							StringTokenizer wfTblTokens = new StringTokenizer(tabls,",");
							while(wfTblTokens.hasMoreTokens()){
								String tblName = wfTblTokens.nextToken();
								String deleteAuditsQry = "Delete from "+tblName+" where workflowid='"+wfID+"'";
								Utilities.executeQuery(dfSession, deleteAuditsQry, DfQuery.EXECREAD_QUERY);
							}
						}
						if(wfCollection1!=null){
							wfCollection1.close();
						}
					}
					//Delete all the Comment objects
					//Delete all the child objects
					//delete all the relation objects
					deleteChildComments(rObjectID);
					
					rbkFlag = true;
				}
				if(hasUniqueIDsFound){
					if("M".equals(deltaStatus) || "R".equals(deltaStatus)){
						destroyAllVersionsDoc(iChronicleID);
					}else if("D".equals(deltaStatus)){
						destroySingleVersion(rObjectID);
					}
				hasUniqueIDsFound = false;
				}
			if(legColection!=null){
				legColection.close();
			}
		} catch (DfException e) {
			e.printStackTrace();
			importDocLogger.warning("DfException::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"DfException during processing document for clean up:: "+legacyDocId, e);
			rbkFlag = false;
		}
		if(rbkFlag){
			
		}
		return rbkFlag;
	}

	private static void destroySingleVersion(String objectID) throws DfException {
		// TODO Auto-generated method stub
		IDfDocument rlbkDoc = (IDfDocument) dfSession.getObject(new DfId(objectID));
		if(rlbkDoc.isCheckedOut()){
			//Check in the document(Cancel checkout)
			importDocLogger.warning("Performinig Cancel Chekout for the doc id::"+objectID);
			rlbkDoc.cancelCheckout();
		}
		//Destroy the document
		rlbkDoc.destroy();
	}

	private static void destroyAllVersionsDoc(String chronicleId) throws DfException {
		// TODO Auto-generated method stub
		IDfDocument rlbkDoc = (IDfDocument) dfSession.getObject(new DfId(chronicleId));
		if(rlbkDoc.isCheckedOut()){
			//Check in the document(Cancel checkout)
			importDocLogger.warning("Performinig Cancel Chekout for the doc id::"+chronicleId);
			rlbkDoc.cancelCheckout();
		}
		rlbkDoc.destroyAllVersions();
	}

	private static void deleteChildComments(String objectId) {
		// TODO Auto-generated method stub

		String qryChilds = "select r_object_id,i_folder_id from dmc_comment where any i_folder_id in(select child_id from dm_relation where parent_id='"+objectId+"')";
		String childFolderID = "";
		String childObjectID = "";
		try {
			IDfCollection childsCollection = Utilities.executeQuery(dfSession, qryChilds, DfQuery.DF_READ_QUERY);
			while(childsCollection.next()){
				childObjectID = childsCollection.getString("r_object_id");
				childFolderID = childsCollection.getString("i_folder_id");
				String delChildQry = "delete dmc_comment object where r_object_id='"+childObjectID+"'";
				Utilities.executeQuery(dfSession, delChildQry, DfQuery.EXECREAD_QUERY);
				}
			if(childsCollection!=null){
				childsCollection.close();
			}
			if(!childFolderID.equals("") && childFolderID!=null){
				deleteTopicFolders(childFolderID,objectId);
			}
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"DfException during deleting the comments for the document:: "+objectId, e);
			e.printStackTrace();
		}
		
	}
	
	private static void deleteTopicFolders(String childFolderID,String objectId) {
		// TODO Auto-generated method stub
			try {
				if(childFolderID!=null & childFolderID!=""){
					String delTopicFld = "delete dm_folder objects where r_object_id='"+childFolderID+"'";
					Utilities.executeQuery(dfSession, delTopicFld, DfQuery.EXECREAD_QUERY);
				}else{
					//importDocLogger.info("No Topics found for the id::"+objectId);
				}
				deleteRelationObj(objectId);
				//importDocLogger.info("Relations Destroyed for the document object id::"+objectId);
				
			} catch (DfException e) {
				// TODO Auto-generated catch block
				importDocLogger.warning("DfException::"+e.getMessage());
				importDocLogger.log(Level.WARNING,"DfException during topic folder deletion:: "+childFolderID, e);
				e.printStackTrace();
			}
	}
	
	private static void deleteRelationObj(String objectId) {
		// TODO Auto-generated method stub
		try {
			if(objectId!=null && objectId!=""){
				String delRelationQry = "delete dm_relation object where parent_id='"+objectId+"'";
				Utilities.executeQuery(dfSession, delRelationQry, DfQuery.EXECREAD_QUERY);
			}else{
				//importDocLogger.info("No Relations found for the id::"+objectId);
			}
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"DfException during relation object deletion:: "+objectId, e);
			e.printStackTrace();
		}
	}

	private static void updateRegionTable(String ext_region_name, String legacyDocId1) {
		// TODO Auto-generated method stub
		
		// Updating Region Table
		String queryUpdateRollback = idocsProperties.getProperty("MSG_UPDATE_REGION_TABLE");
		queryUpdateRollback = queryUpdateRollback.replaceAll("<region>", ext_region_name);
		queryUpdateRollback = queryUpdateRollback.replaceAll("<orig_doc_id>", legacyDocId1);
		UpdateDB.updateDatabase(queryUpdateRollback);
	}

	public static void cleanUPImportFailures(String extractionID, String region) {
		// TODO Auto-generated method stub
		int processedCNT = 0; 
		String queryLegacyID = idocsProperties.getProperty("MSG_SELECT_LEGACY_DOCUMENT_ID_FOR_CURRENT_IMP_RUN");
		queryLegacyID = queryLegacyID.replaceAll("<region>", region)
							.replaceAll("<extraction_utility_code>", extractionID);
						
		//Getting DB Connection
		ResultSet rsLegacyIDs = UpdateDB.selectFrmDatabse(queryLegacyID);
		String rlbkLegacyDocId = "";
		try {
			while (rsLegacyIDs.next()) {
				processedCNT++;
				rlbkLegacyDocId = rsLegacyIDs.getString("LEGACY_DOCUMENT_ID");
				importDocLogger.warning("Processing Cleanup for the legacyID::["+rlbkLegacyDocId+"]");
				//Querying for r_object_id and performing the roll back
				String rlbkStatus = "R";
				if(performRollback(rlbkLegacyDocId,rlbkStatus)){
					//Updating region table
					updateRegionTable(region,rlbkLegacyDocId);
				}
			}
			if(rsLegacyIDs != null){
				rsLegacyIDs.close();
			}
			importDocLogger.info("Total Number of Cleaned up documents::"+processedCNT);
		} catch (SQLException e) {
			importDocLogger.warning("SQLException::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"SQLException during processing legacyid :: "+rlbkLegacyDocId, e);
			e.printStackTrace();
		}
	}
}