/**
 * 
 * This precondition class enables/disable the 'Add to Clip Board action based 
 * on the business rules. 
 * 	
 * #############################################################################
 * Author		 	  DateofChange	 Version		ModificationHistory
 * #############################################################################
 * Chitra Vattathara    10/03/2010	     1.0          Created
 *
 * #############################################################################
*/
package org.ifc.idocs.environment.actions;

import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.utils.IdocsConstants;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.web.formext.docbase.FolderUtil;

public class AddToClipboardActionPrecondition extends com.documentum.webcomponent.environment.actions.AddToClipboardAction
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * This disables the Add to Clipboard action when the selected document is project 
	 * document and the workflow is running.
	 */
    public boolean queryExecute(String strAction, IConfigElement config, ArgumentList arg, Context context, Component component){
    	boolean bExecute = false, validated = false;
    	try {
			bExecute = super.queryExecute(strAction, config, arg, context, component);
		    String strObjectId = arg.get("objectId");
	        if(bExecute && strObjectId != null && 
	        		!(FolderUtil.isFolderType(strObjectId) || FolderUtil.isCabinetType(strObjectId))){
	            validated = true;
	        }else{
	        	bExecute = false;
	        	validated = false;
	        }

	        if(validated){
	        	bExecute = false;
	        	String currentObjectType = IDocDocbaseAttributeTagUtility.getSysObjectAttribute(component.getDfSession(), strObjectId, IdocsConstants.R_OBJECT_TYPE);
	        	if(currentObjectType!=null && currentObjectType.trim().length() > 0 
	        			&& (currentObjectType.equals(IdocsConstants.PROJ_DOC_TYPE)
	        					|| currentObjectType.equals(IdocsConstants.INSTITUTION_DOC_TYPE) 
	    	        			|| currentObjectType.equals(IdocsConstants.COUNTRY_DOC_TYPE))){
	        		String strTemplateCode = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(component.getDfSession(), strObjectId, IdocsConstants.TEMPLATE_CODE, currentObjectType);
					if(strTemplateCode!=null &&  strTemplateCode.trim().length() > 0){
				        bExecute = false;
		    		}else{
		    			bExecute = true;
		    		}
	        	}else {
	        		bExecute = true;
	        	}
	        }
		}catch (Exception e) {
			DfLogger.error(this, " :: queryExecute Exception >> "+e.getMessage(), null, null);
		}
        return bExecute;
    }
}
