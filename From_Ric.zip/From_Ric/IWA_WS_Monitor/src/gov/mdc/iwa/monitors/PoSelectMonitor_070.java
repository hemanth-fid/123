package gov.mdc.iwa.monitors;

import gov.mdc.iwa.monitors.utils.Email;
import gov.mdc.iwa.monitors.utils.Host;
import gov.mdc.iwa.monitors.utils.MonitorConfig;
import gov.mdc.iwa.monitors.utils.Result;
import gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070InHdr_Type;
import gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070In_Type;
import gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070Out_Type;
import gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070Request_Type;
import gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070Response_Type;
import gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070ServiceBindingStub;
import gov.mdc.iwa.stubs.CICS.TWBA.PCHW070W.PCHW070ServiceLocator;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.rpc.ServiceException;
import org.apache.log4j.Logger;

public class PoSelectMonitor_070 {
	
	private static String className =  PoGLLookupMonitor_078.class.getName();
	private static Logger log = Logger.getLogger(className);
	private static final String CONFIG_FILE = "monitor078.config";
	private static String hostname = Host.getHostName();
	private static StringBuffer msg = new StringBuffer("IWA WEB SERVICE MONITOR - " + className + "\n\n");
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Throwable
	{
		log.info(className + " - START");			
		//MonitorConfig config = new MonitorConfig(CONFIG_FILE); 
		
		//String url = "http://ibmprd.metro-dade.com:4002/CICS/TWBA/CSCWKI2X/PCHW070W"; 
		String url = "http://ibmtst.metro-dade.com:4002/CICS/TWBA/CSCWKI2X/PCHW070W";		
		
		Result result = doPoLookup(url);
		
		
		// If connection to the web service failed 
//		if( ! result.getConnectionOk()  ){
//			msg.append("Unable to connect to Web Service   " + config.getUrl() +   "\n");
//			msg.append("Error: " + result.getMessage() + "\n\n") ;
//			msg.append("Host: " + hostname  + "\n");
//			msg.append("Program: PoGLLookupMonitor_078 - Web Service PCHW078W\n") ;			
//			Email.Send(config, msg.toString());
//		}else{
//			if( result.getMessage().toUpperCase().indexOf("SUCCESS") > -1 || 
//				result.getMessage().toUpperCase().indexOf("PLEASE TRY AGAIN") > -1)
//			{
//				// OK, dont do anything   -- SendEmail(config, "SUCCESS");
//			}else{
//				msg.append("Web service  " + config.getUrl() + " is not retunring the correct values.\n");
//				msg.append("Error  : " + result.getMessage() + "\n\n") ;
//				msg.append("Host: " + hostname  + "\n");
//				msg.append("Program: PoGLLookupMonitor_078 - Web Service PCHW078W\n");
//				Email.Send(config, msg.toString() );
//			}
//		}
		log.info(className + " - END");
		
		
		//doPoLookup();
		//doPoLookup(args[0]);
		//doPoLookup("http://ibmtst.metro-dade.com:4004/CICS/TWBA/CSCWKI2X/PCHW070W/PCHW070");
	}
	
	
	public PoSelectMonitor_070()
    {	
    }	

    //public static List doPoLookup(String url, String inDept1, String vendorNo, String un, String pw) throws ServiceException, RemoteException
	//public static List doPoLookup(String url) throws ServiceException, RemoteException
	public static Result doPoLookup(String url) throws ServiceException, RemoteException
	{
		
		Result result = new Result();
		
		//String url = "http://iwaws.metro-dade.com:4002/CICS/TWBA/CSCWKI2X/PCHW070W";  
		//String url = "http://ibmprd.metro-dade.com:4002/CICS/TWBA/CSCWKI2X/PCHW070W";
		//String url = "http://ibmtst.metro-dade.com:4004/CICS/TWBA/CSCWKI2X/PCHW070W/PCHW070";    //"http://ibmtst.metro-dade.com:4004/CICS/TWBA/CSCWKI2X/PCHW070W";
		//String url = "http://localhost:9999/CICS/TWBA/CSCWKI2X/PCHW070W";    //"http://ibmtst.metro-dade.com:4004/CICS/TWBA/CSCWKI2X/PCHW070W";
		String inDept1 = "FR"; //"BU";
		String vendorNo = "650224861";   //"113695944"  OK;
		String un = "IWAINWS";
		String pw = "Fin123";
		
        //Logger logger = Logger.getLogger(com/beachstreet/mdc/iwa/adaptor/datasource/PoLookupConnector);   
        int inc = 0;
        //logger.debug((new StringBuilder("Doing Po Lookup, args are: ")).append(inDept1).append(" and ").append(vendorNo).toString());
        List rs = new ArrayList();
        PCHW070ServiceLocator serviceLoc = new PCHW070ServiceLocator();
        
        //serviceLoc.set
        //serviceLoc.setEndpointAddress("4004", "http://ibmtst.metro-dade.com:4004/CICS/TWBA/CSCWKI2X/PCHW070W/PCHW070");
        
        if(url != null && url.length() > 0){
            serviceLoc.setPCHW070ServicePortEndpointAddress(url);
            //PCHW070ServicePort_Type tt = (PCHW070ServicePort_Type) serviceLoc.getPCHW070ServicePort();
            //serviceLoc.setEndpointAddress(new QName("http://ibmtst.metro-dade.com:4004/CICS/TWBA/PCHW070W", "StreamInputSessionId") , address)
            //String aa = ""; 
        }
        PCHW070ServiceBindingStub stub = (PCHW070ServiceBindingStub)serviceLoc.getPCHW070ServicePort();
        
        if(un != null && un.length() > 0 && pw != null && pw.length() > 0)
        {
            stub._setProperty("javax.xml.rpc.security.auth.username", un);
            stub._setProperty("javax.xml.rpc.security.auth.password", pw);
            //logger.debug("Using simple http authentication");
        }
        PCHW070Request_Type request = new PCHW070Request_Type();
        PCHW070InHdr_Type pht = new PCHW070InHdr_Type();
        PCHW070In_Type params = new PCHW070In_Type();
        pht.setStreamInputSessionId("");
        params.setPCHW070InHdr(pht);  
        params.setINDEPT1(inDept1);
        params.setVENDORNO(vendorNo);
        //params.setLINKTO("");
        //params.setFRISSDTE("");
        //params.setLINKNAME("");
        //params.setPONUM2360("");
        //params.setVENNO9520("");
        //params.setVENSFX9520("");
        //params.setRMCODE("");
        request.setPCHW070In(params);
        PCHW070Response_Type response = stub.PCHW070(request);
        
        PCHW070Out_Type respD = response.getPCHW070Out();

        String msgText = respD.getMSGTEXT();
        String retMsg = respD.getRETURNMSG();
        
        System.out.println("Response -> " + msgText);
        
        //logger.debug((new StringBuilder("Return value is ")).append(retMsg).toString());
        if(retMsg != null && !retMsg.equalsIgnoreCase("error"))
        {
            List data = new ArrayList();
            List keys = new ArrayList();
            //data.add(respD.getArrayOfPONUM());
            //keys.add("PONUM");
            //data.add(respD.getArrayOfPOSTATUS());
            //keys.add("POSTATUS");
            //data.add(respD.getArrayOfREMBALNCE());
            //keys.add("REMBALNCE");
            data.add(respD.getArrayOfTCITY());
            keys.add("TCITY");
            data.add(respD.getArrayOfTCOUNTRY());
            keys.add("TCOUNTRY");
            data.add(respD.getArrayOfTDBANAME());
            keys.add("TDBANAME");
            data.add(respD.getArrayOfTPONUM());
            keys.add("TPONUM");
            data.add(respD.getArrayOfTPOTITLE());
            keys.add("TPOTITLE");
            data.add(respD.getArrayOfTSTATE());
            keys.add("TSTATE");
            //data.add(respD.getArrayOfTSTATUS());
            //keys.add("TSTATUS");
            data.add(respD.getArrayOfTSTREET());
            keys.add("TSTREET");
            data.add(respD.getArrayOfTVENNO());
            keys.add("TVENNO");
            data.add(respD.getArrayOfTVENSFX());
            keys.add("TVENSFX");
            data.add(respD.getArrayOfTZIPCODE());
            keys.add("TZIPCODE");
//            Map row = null;
//            for(; inc < keys.size(); inc++)
//            {
//                String k = (String)keys.get(inc);
//                String vals[] = (String[])data.get(inc);
//                if(vals != null)
//                {
//                    for(int j = 0; j < vals.length; j++)
//                    {
//                        if(rs.size() > j)
//                        {
//                            row = (Map)rs.get(j);
//                        } else
//                        {
//                            row = new HashMap();
//                            rs.add(row);
//                        }
//                        row.put(k, vals[j]);
//                        rs.set(j, row);
//                    }
//                }
//            }
        }
        //logger.debug((new StringBuilder("Returned ")).append(inc).append(" entries").toString());
        //return rs;
        return result;
    }

//    public static final String PONUM = "PONUM";
//    public static final String POSTATUS = "POSTATUS";
//    public static final String REMBALNCE = "REMBALNCE";
//    public static final String TCITY = "TCITY";
//    public static final String TCOUNTRY = "TCOUNTRY";
//    public static final String TDBANAME = "TDBANAME";
//    public static final String TPONUM = "TPONUM";
//    public static final String TPOTITLE = "TPOTITLE";
//    public static final String TSTATE = "TSTATE";
//    public static final String TSTATUS = "TSTATUS";
//    public static final String TSTREET = "TSTREET";
//    public static final String TVENNO = "TVENNO";
//    public static final String TVENSFX = "TVENSFX";
//    public static final String TZIPCODE = "TZIPCODE";

}

