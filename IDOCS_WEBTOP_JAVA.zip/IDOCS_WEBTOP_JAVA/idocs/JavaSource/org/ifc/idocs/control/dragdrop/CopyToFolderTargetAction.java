/**
* This custom component class provides query for the users can copy 
* the document to the Folder.
* 
* #########################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #########################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #########################################################################
*/
package org.ifc.idocs.control.dragdrop;

import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.dragdrop.IDragDropDataProvider;
import com.documentum.web.form.Form;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.control.dragdrop.DragDropClipboard;
import com.documentum.web.formext.docbase.FolderUtil;
import com.documentum.webcomponent.common.WebComponentErrorService;

public class CopyToFolderTargetAction extends com.documentum.web.formext.control.dragdrop.CopyToFolderTargetAction
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	NlsResourceBundle lookup = new NlsResourceBundle("org.ifc.idocs.clipboard.ClipboardErrorsNlsProp");

	/**
	 * Method overwritten to change the copy operation.
	 */
	public boolean execute(Form form, String position, IDragDropDataProvider sourceDataProvider[], IDragDropDataProvider targetDataProvider, String sourceItemData[], String targetItemData)
    {
		boolean bExecute = false;
        if(!(form instanceof Component))
        {
            throw new IllegalArgumentException("CopyToFolderTargetAction.execute() expects a Component as the first argument");
        }
    	IDfSession sess = ((Component) form).getDfSession();
        try {
			DfLogger.info(this, " :: execute : "+sess.getLoginUserName(), null, null);
		} catch (DfException e) {
    		DfLogger.error(this, " :: execute Exception >> "+e.getMessage(), null, e);
		}
        Component component = (Component)form;
        com.documentum.web.dragdrop.IDragDropData targetData = getTargetDataFromProvider(targetDataProvider, targetItemData);
        String strTargetObjId = getObjectIdFromData(targetData);
        DfLogger.info(this, " :: execute : strSourceObjId : "+strTargetObjId, null, null);
        for(int i = 0; i < sourceItemData.length && sourceItemData.length == sourceDataProvider.length; i++){
            com.documentum.web.dragdrop.IDragDropData sourceData = getSourceDataFromProvider(sourceDataProvider[i], sourceItemData[i]);
            String strSourceObjId = getObjectIdFromData(sourceData);
            DfLogger.info(this, " :: execute : strSourceObjId : "+strSourceObjId, null, null);
            if(strSourceObjId != null && 
            		!(FolderUtil.isCabinetType(strSourceObjId) 
            		|| FolderUtil.isFolderType(strSourceObjId))){
            	try{
	    			IDfDocument doc = (IDfDocument)sess.getObject(new DfId(strSourceObjId));
	    			String workflowStatus = null ;
	    			if(doc.hasAttr("workflow_status")){
	    				workflowStatus = doc.getString("workflow_status");
	    			}
    	    		DfLogger.info(this, " :: execute : workflowStatus : "+workflowStatus, null, null);
    	    		if(workflowStatus==null || workflowStatus.equals("") || workflowStatus.equals("Completed")){
    			        bExecute = true;
    	    		}else{
    	    			bExecute = false;
    	    		}
		            com.documentum.web.formext.clipboard.IClipboardPasteHandler handler = component.getClipboardPasteHandler(strTargetObjId);
		            if(handler != null && bExecute){
		                DragDropClipboard dragDropClipboard = new DragDropClipboard();
		                dragDropClipboard.pasteAsCopy(strSourceObjId, handler);
		            } else if(!bExecute){
		                WebComponentErrorService.getService().setNonFatalError(lookup, "MSG_CLIPBOARD_COPY_FAIL", component, new Object[] {
		                		doc.getObjectName()
		                }, null);
		                DfLogger.info(this, " :: execute : User not allowed to copy/move/link/unlink this document", null, null);
		            }else{
		                throw new IllegalArgumentException("Component must implement IClipboardPasteHandler!");
		            }
            	}catch(DfException e){
            		DfLogger.error(this, " :: execute Exception >> "+e.getMessage(), null, e);
            	}
            }else{
    			bExecute = false;
				try {
					IDfSysObject obj = (IDfSysObject)sess.getObject(new DfId(strSourceObjId));
	                WebComponentErrorService.getService().setNonFatalError(lookup, "MSG_CLIPBOARD_COPY_FAIL", component, new Object[] {
	                		obj.getObjectName()
	                }, null);
	                DfLogger.info(this, " :: execute : User not allowed to copy/move/link/unlink this document", null, null);
				} catch(DfException e){
            		DfLogger.error(this, " :: execute Exception >> "+e.getMessage(), null, e);
            	}
            }
        }
        return bExecute;
    }
}
