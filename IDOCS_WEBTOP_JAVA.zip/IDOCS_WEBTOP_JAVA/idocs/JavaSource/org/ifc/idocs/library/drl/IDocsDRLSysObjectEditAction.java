package org.ifc.idocs.library.drl;

import java.util.Map;


import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.action.ActionService;
import com.documentum.web.formext.action.IActionCompleteListener;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;
import com.documentum.webtop.webcomponent.drl.DRLSysObjectEditAction;

public class IDocsDRLSysObjectEditAction extends DRLSysObjectEditAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public boolean execute(String strAction, IConfigElement config,ArgumentList args, final Context context,Component component, Map completionArgs){
	 
	class ActionListener implements IActionCompleteListener
		 {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		
		public ActionListener(Component component, Context context, ArgumentList args, IActionCompleteListener listener)
			{
				m_component = component;
				m_context = context;
				m_listener = listener;
				m_args = args;
				DfLogger.info(this, " inner Class ActionListener :: Constructor :: ", null, null);
			}
		  
		  public void onComplete(String strAction, boolean bSuccess, Map map)
			{
			// execute 'editfile' action and navigate to 'appropriate project folder' on completion.  Note that this action's
				if (m_listener != null)
				{
					m_listener.onComplete(strAction, bSuccess, map);
				}
				
				boolean bNavigateOnComplete = true;
				
				if (m_args != null && m_args.get("navigateOnComplete") != null)
				{
					bNavigateOnComplete = Boolean.valueOf(m_args.get("navigateOnComplete")).booleanValue();
				}
				if (bNavigateOnComplete)
				{
				if (m_component.lookupString("pages.redirect") != null)
				{
					m_component.setComponentPage("redirect", m_args);
				}
				else
				{
					m_component.setComponentJump("main", m_args, m_context);
			    }
			 }
			}
		  
			private Context m_context;
			private Component m_component;
			private IActionCompleteListener m_listener;
			private ArgumentList m_args;
			}
			
			IActionCompleteListener completeListener = (IActionCompleteListener)completionArgs.remove(ActionService.COMPLETE_LISTENER);
			ActionListener actionListener = new ActionListener(component, context, args, completeListener);
			args.add( "skipVersionCheck", "true");
			return ActionService.execute("editfile", args, context, component, actionListener);
	}
	
	public String[] getRequiredParams()
    {
        return (new String[] {
            "objectId"
        });
    }
}
