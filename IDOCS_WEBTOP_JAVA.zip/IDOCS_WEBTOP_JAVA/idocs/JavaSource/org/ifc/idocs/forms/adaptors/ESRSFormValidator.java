package org.ifc.idocs.forms.adaptors;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;

import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.Pointer;
import org.w3c.dom.Document;

import com.documentum.fc.common.DfLogger;
import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.xforms.engine.XFormsProcessorException;
import com.documentum.xforms.engine.adaptor.validator.IDocumentValidator;

@SuppressWarnings("unused")
public class ESRSFormValidator implements IDocumentValidator {

	public boolean validate(Document document) throws XFormsProcessorException {
		boolean retvalue = true;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		System.out
				.println("ESRSFormValidator:: Inside ESRSFormValidator");
		
		JXPathContext validateContext = JXPathContext.newContext(document);
		Pointer nodePointer5 = validateContext
				.getPointer("/iDOCs_ESRS_Form/EnvSpecialistClearGrp/ValidationFilter");
		System.out
		.println("ESRSFormValidator:: IsValidatorRequired"+nodePointer5.getValue().toString());
		if (nodePointer5.getValue().toString().equals("env1")) {
			System.out
			.println("ESRSFormValidator:: Inside Env1 Validation");
			Pointer nodePointer1 = validateContext
					.getPointer("/iDOCs_ESRS_Form/EnvSpecialistClearGrp/FactualAccuracyClearance");
			Pointer nodePointer2 = validateContext
					.getPointer("/iDOCs_ESRS_Form/EnvSpecialistClearGrp/DateOfClearance");
			Pointer nodePointer3 = validateContext
					.getPointer("/iDOCs_ESRS_Form/LimitedDisclosureGrp/LtdDisclosureRationale");

			Date now = new Date();
			String exception = "";
			if (nodePointer1.getValue().toString().length() <= 0) {
				retvalue = false;
				exception = exception
						.concat("\nClient Clearance cannot be empty.");
			} else if (nodePointer1.getValue().equals("no")) {

				retvalue = false;
				exception = exception
						.concat("\nClient Clearance is required to complete the activity.");

			} else if (nodePointer1.getValue().equals("yes")
					&& nodePointer2.getValue().toString().length() > 0) {

				Date dateOfClearance = new Date();
				try {

					dateOfClearance = dateFormat.parse(nodePointer2.getValue()
							.toString());

					System.out
							.println("ClientCleranceValidator:: Clearance Date from XPath is "
									+ dateOfClearance);

				} catch (java.text.ParseException e) {
					DfLogger.error(this,": <<Exception>> : "+e.getMessage(),null,e);
				}
				if (dateOfClearance.after(now)) {
					retvalue = false;
					exception = exception
							.concat("\nClearance date cannot be future date.");

				}

			} else {
				retvalue = false;
				exception = exception
						.concat("\nClearance date cannot be empty.");
			}

			if (retvalue == false) {
				XFormsProcessorException e = new XFormsProcessorException(
						exception);
				throw e;
			}
		} else if (nodePointer5.getValue().toString().equals("env2")) {
			System.out
			.println("ESRSFormValidator:: Inside Env2 Validation");
			Pointer nodePointer1 = validateContext
					.getPointer("/iDOCs_ESRS_Form/LimitedDisclosureGrp/LimitedDisclosure");
			Pointer nodePointer2 = validateContext
					.getPointer("/iDOCs_ESRS_Form/LimitedDisclosureGrp/LtdDisclosureRationale");
			Pointer nodePointer3 = validateContext
					.getPointer("/iDOCs_ESRS_Form/LimitedDisclosureGrp/RationaleFlag");

			String exception = "";
			if (nodePointer1.getValue().toString().equals("yes")
					&& nodePointer2.getValue().toString().length() <= 0) {
				retvalue = false;
				exception = exception.concat("\nRationale cannot be empty.");
				nodePointer3.setValue("true");
			}else{
				nodePointer3.setValue("false");
			}

			if (retvalue == false) {
				XFormsProcessorException e = new XFormsProcessorException(
						exception);
				throw e;
			}
		}
		System.out
		.println("ESRSFormValidator:: No validation required");
		return retvalue;
	}

	public void destroy() throws AdaptorException {
	}

	public void init(IAdaptorConfiguration arg0) throws AdaptorException {
	}
}