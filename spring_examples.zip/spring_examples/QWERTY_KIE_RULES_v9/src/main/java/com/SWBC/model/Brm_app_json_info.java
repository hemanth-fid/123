package com.SWBC.model;

public class Brm_app_json_info {
	
	private String input_param;
	private String jsonOutValue;
	
	
	public String getInput_param() {
		return input_param;
	}
	public void setInput_param(String input_param) {
		this.input_param = input_param;
	}
	public String getJsonOut() {
		return jsonOutValue;
	}
	public void setJsonOut(String jsonOut) {
		this.jsonOutValue = jsonOut;
	}
	
	

}
