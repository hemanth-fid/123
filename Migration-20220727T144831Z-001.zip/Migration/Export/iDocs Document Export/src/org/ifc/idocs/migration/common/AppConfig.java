package org.ifc.idocs.migration.common;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;

/**
 * @author SPankajamsadanan
 *
 */

public class AppConfig extends XMLConfiguration {

	private static final long serialVersionUID = 239973206750886170L;
	private static AppConfig instance;
	private static String configFile = "config.xml";

	// Singleton initializer
	static {
		instance = new AppConfig(configFile);
	}

	/**
	 * @param fileName
	 */
	private AppConfig(String fileName) {
		init(fileName);
	}

	/**
	 * @param fileName
	 * @return void
	 */
	private void init(String fileName) {
		setFileName(fileName);
		try {
			load();
		} catch (ConfigurationException configEx) {
			System.out.println("Cannot locate configuration xml file. Please check the file name or the file location");
			System.exit(0);
		}
	}

	/**
	 * @return AppConfig object - singleton class
	 */
	public static AppConfig getInstance() {
		return instance;
	}
}

