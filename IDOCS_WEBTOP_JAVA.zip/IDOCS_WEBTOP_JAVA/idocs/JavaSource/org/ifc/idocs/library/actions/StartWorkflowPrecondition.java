/****************************************************************************
 * Module Name: 						StartWorkflowPrecondition						                     
 * Module Description: 					This is the precondition check before 
 * 										enable/disable 'Start Workflow'.			  	                       
 * Author name: SKurian1                Date: 03-May-2011                    
 * Module Version Number: 1.0                                             	 
 ****************************************************************************
 * Modification History                                                      
 * 1: Change author name:                                                    
 *    Change date:                                                           
 *    Module Version Number: 1.0                                             
 *    Description of change and/or reference to other documentation:
 * 
 */
package org.ifc.idocs.library.actions;


import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.action.IActionPrecondition;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

public class StartWorkflowPrecondition  implements IActionPrecondition{

	//private static Properties idocsProperties = new Properties();
	public String[] getRequiredParams() {
		DfLogger.info(this,"::  getRequiredParameters : " , null, null);
		return (new String[] {"objectId"});
	}

	public boolean queryExecute(String strAction, IConfigElement config,
			ArgumentList arg, Context context, Component component) {
		try {
			String strObjectId = arg.get("objectId");
			if(strObjectId !=null && strObjectId.trim().length()>0 
					&& strObjectId.startsWith(IDocsConstants.MSG_DM_DOC_TYPE_PREF_CODE)){
				String workflowId = IdocsUtil.getWorkflowId(component.getDfSession(), strObjectId);
				if(workflowId!=null && workflowId.trim().length()>0){
//					DfLogger.debug(this, "Document has a workflow : Workflow Id="+workflowId, null, null);
					return false;
				}
				String startWorkflowQuery = IdocsUtil.getMessage("QRY_START_WORKFLOW_PRECONDITION");
				startWorkflowQuery = startWorkflowQuery.replaceFirst(IdocsConstants.MSG_C_DQ_C,IdocsConstants.MSG_QUOTES+strObjectId+IdocsConstants.MSG_QUOTES);
				//DfLogger.debug(this, "startWorkflowQuery :"+startWorkflowQuery, null, null);
				try {
					String isworkflowrestartable= null;
					String workflow_status= null;
					String r_lock_owner=null;
					IDfCollection collection = IdocsUtil.executeQuery(component.getDfSession(), startWorkflowQuery, IDfQuery.DF_READ_QUERY);
					if(collection!=null){
						boolean hasCollectionGotResults = false;
						while(collection.next()){
							r_lock_owner = collection.getString(IDocsConstants.MSG_R_LOCK_OWNER);
							isworkflowrestartable = collection.getString(IDocsConstants.MSG_IS_WORKFLOW_RESTARTABLE);
							workflow_status = collection.getString(IDocsConstants.MSG_WORKFLOW_STATUS);
							hasCollectionGotResults = true;
						}
						if(collection!=null)collection.close();
						if(hasCollectionGotResults == false ){
							//DfLogger.debug(this, " This is not a template Document . Check Failed ", null, null);
							return false;
						}else{
//							DfLogger.debug(this, " This is a template Document . Proceed with further Checks", null, null);
						}
						if(r_lock_owner !=null && r_lock_owner.trim().length()>0){
//							DfLogger.debug(this, " Document is Locked by : "+r_lock_owner, null, null);
							return false;
						}else{
							if(workflow_status != null && workflow_status.trim().length() >0){
								if(isworkflowrestartable != null && isworkflowrestartable.trim().length()>0
										&& isworkflowrestartable .equalsIgnoreCase(IDocsConstants.MSG_WORKFLOW_RESTARTABLE)
										&& workflow_status.equalsIgnoreCase(IDocsConstants.MSG_COMPLETED)){
//									DfLogger.debug(this, "Workflow is Completed and its Restartable", null, null);
									return true;
								}else{
//									DfLogger.debug(this, "Workflow is not Completed OR its not Restartable", null, null);
									return false;
								}
							}else{
//								DfLogger.debug(this, "Workflow is not started. Check Success!!", null, null);
								return true;
							}
						}
					}else{
//						DfLogger.debug(this, "startWorkflowQuery Collection NULL : Check Failed.", null, null);
						return false;
					}
				} catch (DfException e) {
//					DfLogger.debug(this, "startWorkflowQuery  Failed.", null, null);
					return false;
				}
			}else{
				return true;
			}
		} catch (Exception e) {
			DfLogger.debug(this, " :Exception :"+e.getMessage(), null, null);			
		}
		return false;
	}

}
