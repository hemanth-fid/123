/***************************************************************************
 * State Farm
 * Version Template: 2012
 *
 * File Name: QueryConstants.java
 *
 * Version     ChgDate          Author           Comments
 * ________   __________       ________         ___________
 * 1.0        05/31/2013         t7p9         		Initial Creation 
 *
 *  Version     ChgDate          Author           Comments
 * ________   __________       ________         ___________
 * 2.0        07/07/2014         diw6        		Updated
 *
 ***************************************************************************/

package sf.application.custcomm.ccs.constants;
/**
 * <i> QueryConstants </i> contains all the DQL queries as constants that are
 * commonly used in Export Process components
 * 
 * 
 */
public final class QueryConstants {

	/**
	 * private Constructor
	 */
	private QueryConstants() {

	}


    
	//this query will return the folders ids where status=exported
	public static final String QRY_GET_EXPORTED_FOLDERS= "select distinct  f.r_object_id as folderid,f.object_name as foldername,edc.r_object_id as edcobjectid,edc.object_name,edc.sf_filetype,edc.r_creation_date ,edc.sf_status from dm_folder f,edc_sf_document edc where edc.sf_filetype in ('EA','E','Z','D') and edc.sf_status = 'Exported' and edc.r_object_id=f.object_name and f.subject!='Marked as Purge' and DATEDIFF(day, edc.r_creation_date, DATE(NOW))>%1 order by edc.r_creation_date desc enable (return_top %2)";
	////this query will return the folders ids where status=purge or error
	public static final String QRY_GET_ERROR_FOLDERS= "select distinct  f.r_object_id as folderid,f.object_name as foldername,edc.r_object_id as edcobjectid,edc.object_name,edc.sf_filetype,edc.r_creation_date ,edc.sf_status from dm_folder f,edc_sf_document edc where edc.sf_filetype in ('EA','E','Z','D') and edc.sf_status in ('Purge','Error') and edc.r_object_id=f.object_name and f.subject!='Marked as Purge' and DATEDIFF(day, edc.r_creation_date, DATE(NOW))>%1 order by edc.r_creation_date desc enable (return_top %2)";
	public static final String QRY_COUNT_EXPORTED_FOLDERS="select count(*) from dm_folder f,edc_sf_document edc where edc.sf_filetype in ('EA','E','Z','D') and edc.sf_status='Exported' and edc.r_object_id=f.object_name and f.subject!='Marked as Purge' and DATEDIFF(day, edc.r_creation_date, DATE(NOW))>%1";
	public static final String QRY_GET_FOLDER_CONTENTS="select r_object_id from dm_sysobject where FOLDER(ID ('%1')) order by r_is_virtual_doc desc";
    public static final String QRY_DESTROY_CONTENT="EXECUTE destroy_content FOR '%1'";
    public static final String QRY_GET_DMR_CONTENT_IDS="select r_object_id from dmr_content where  any parent_id='%1'";
    public static final String QRY_GET_DMR_CONTENT_PARENT_COUNT="select parent_count from dmr_content where r_object_id='%1'";
	public static final String QRY_COUNT_ERRORED_FOLDERS = "select count(*) from dm_folder f,edc_sf_document edc where edc.sf_filetype in ('EA','E','Z','D') and edc.sf_status in ('Purge','Error') and edc.r_object_id=f.object_name and f.subject!='Marked as Purge' and DATEDIFF(day, edc.r_creation_date, DATE(NOW))>%1";;
	public static final String QRY_READ_FILES_REPO="select r_object_id from dm_document where folder('/Temp/EDC Cleanup',descend) and subject='%1' and title='%2'";
	public static final String QRY_OBJECT_ID_EXISTS="select count(r_object_id) from dm_sysobject where r_object_id='%1'";
	public static final String QRY_GET_EXPORTED_RETENTION_PERIOD="SELECT gc_value  FROM dbo.rt_general_config WHERE gc_name = 'exported_retention_period'";
	public static final String QRY_GET_ERROR_RETENTION_PERIOD="SELECT gc_value  FROM dbo.rt_general_config WHERE gc_name = 'Error_retention_period'";
	public static final String QRY_UPDATE_STATUS="update dm_document object set title='%1',set object_name='%2' where r_object_id='%3'";
	public static final String QRY_GET_I_CONTENT_ID="select i_contents_id from dm_document where r_object_id='%1' ";
	public static final String QRY_GET_OBJECT_NAME="select object_name from dm_document where r_object_id='%1' ";
	public static final String QRY_GET_PATH="execute get_path for '%1'";
	public static final String QRY_GET_FOLDER_PATH="select r_folder_path from dm_folder where r_object_id in (select i_folder_id  from dm_document where r_object_id='%1') order by r_folder_path desc";
	//Updating the subject of the folder  to 'Marked as Purge' to 'empty' string in case the folder didn't delete by the datacleanup thread.
	public static final String QRY_UPDATE_FOLDER_SUBJECT="update dm_folder object set subject=' ' where subject='Marked as Purge' and r_object_id='%1'";
	
}
