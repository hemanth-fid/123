/***************************************************************************
 * State Farm
 * Version Template: 2012
 *
 * File Name: ExportProcessHelper.java
 *
 * Version     ChgDate          Author           Comments
 * ________   __________       ________         ___________
 * 1.0        05/31/2013         t7p9         Initial Creation 
 * 
 * Version     ChgDate          Author           Comments
 * ________   __________       ________         ___________
 * 2.0        07/07/2014         diw6         Updated 
 *
 ***************************************************************************/

package sf.application.custcomm.ccs.util;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import sf.application.custcomm.ccs.constants.CleanUpConstants;
import sf.application.custcomm.ccs.constants.ExceptionConstants;
import sf.application.custcomm.ccs.constants.QueryConstants;
import sf.application.custcomm.ccs.dao.ICleanUpQueryDao;
import sf.application.custcomm.ccs.dao.impl.CleanUpQueryDao;
import sf.application.custcomm.ccs.exceptions.CleanUpServiceException;

import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfLogger;
import com.emciig.utils.MiscUtils;
import com.emciig.utils.SessionUtils;

/**
 * <i> WorkFlowTimerHelper </i> class provides the functionality to initiate the
 * export process.
 * 
 */
public final class CleanUpHelper {

	/**
	 * Private Constructor
	 */
	private CleanUpHelper() {

	}

	/**
	 * It reads the properties file and initializes the parameters for further
	 * processing.
	 * 
	 * @return Key value pairs of information from properties file
	 * 
	 * @throws CleanUpServiceException
	 *             Custom Workflow Timer Service Exception
	 */
	public static Map<String, String> initializeParameters() throws CleanUpServiceException {

		// get map of properties file
		if(DfLogger.isTraceEnabled(CleanUpHelper.class)) {
			DfLogger.trace(CleanUpHelper.class, "Method initializeParameters() entry", null, null);
		}
	Map<String, String> params = DocumentumUtils.getPropertiesMap(CleanUpConstants.SYSTEM_PROPERTIES);
	params.put("exported_retention_period", getExportedRetentionPeriod(params));
	params.put("error_retention_period", getErrorRetentionPeriod(params));
		/*params.put(
				CleanUpConstants.PASSWORD,
				decryptPassword(params.get(CleanUpConstants.PARAM_TICKET),
						params.get(CleanUpConstants.PARAM_KEY_LOCATION), CleanUpConstants.SVC_EDC_EXPORT_KEY));
	
		params.put(
				CleanUpConstants.PASSWORD,params.get(CleanUpConstants.PARAM_TICKET));*/

		if(DfLogger.isTraceEnabled(CleanUpHelper.class)) {
			DfLogger.trace(CleanUpHelper.class, "Method initializeParameters() exit", null, null);
		}
		return params;
	}
	
	

	/**
	 * It returns a scheduler instance.
	 * @param requiredThreadCount 
	 * 
	 * @return ScheduledExecutorService
	 */
	public static ScheduledExecutorService getScheduler(int requiredThreadCount) {
		return Executors.newScheduledThreadPool(requiredThreadCount);
	}

	/**
	 * It decrypts the encrypted password.
	 * 
	 * @param encryptedPassword
	 *            encrypted password
	 * @param serviceKeyLocation
	 *            Location of the service key
	 * @param passKeyReference
	 *            Reference of the pass key
	 * @return decrypted password
	 * @throws ExportProcessException
	 *             Custom Export Process Exception
	 */
	public static String decryptPassword(String encryptedPassword, String serviceKeyLocation, String passKeyReference)
			throws CleanUpServiceException {
		if(DfLogger.isTraceEnabled(CleanUpHelper.class)) {
			DfLogger.trace(CleanUpHelper.class, "Method decryptPassword() entry", null, null);
		}
		Map<String, String> servicePropsMap = null;
		try {
			servicePropsMap = MiscUtils.getPropertiesArrayList(serviceKeyLocation);

			CryptoUtils cryptoUtil = CryptoUtils.getInstance(servicePropsMap.get(passKeyReference));

			if(DfLogger.isTraceEnabled(CleanUpHelper.class)) {
				DfLogger.trace(CleanUpHelper.class, "Method decryptPassword() exit", null, null);
			}

			return cryptoUtil.decrypt(encryptedPassword);

		} catch(IOException ioException) {
			throw new CleanUpServiceException(ExceptionConstants.ERROR_WHILE_LOADING_PROPERTIES, ioException);
		}

	}
	
	






public static  String[] getServerNames(Map<String, String> parameters) {
	
	
	String [] serverNames=parameters.get("server_names").split(",");
	
	return serverNames;
	
	
}



/**
 * 
 * 
 * @param Map<String, String> params
 * @return String
 * @throws CleanUpServiceException
 *            
 */



public static String getExportedRetentionPeriod(Map<String, String> params) throws CleanUpServiceException {
	
    String expRetentionPeriod=null;
    IDfSession idfSession = null;
    try{
    idfSession = DocumentumUtils.getSession(params);
    ICleanUpQueryDao cleanUpQueryDao= new CleanUpQueryDao();
    expRetentionPeriod=cleanUpQueryDao.getQueryStringValue(QueryConstants.QRY_GET_EXPORTED_RETENTION_PERIOD, "gc_value", IDfQuery.DF_READ_QUERY,idfSession);
	 }finally{
    	
    	SessionUtils.disconnect(idfSession);
    }
	
	return expRetentionPeriod;
}



/**
 * 
 * 
 * @param Map<String, String> params
 * @return String
 * @throws CleanUpServiceException
 *            
 */



public static String getErrorRetentionPeriod(Map<String, String> params) throws CleanUpServiceException {
	
    String errRetentionPeriod=null;
    IDfSession idfSession = null;
    try{
    idfSession = DocumentumUtils.getSession(params);
    ICleanUpQueryDao cleanUpQueryDao= new CleanUpQueryDao();
    errRetentionPeriod=cleanUpQueryDao.getQueryStringValue(QueryConstants.QRY_GET_ERROR_RETENTION_PERIOD, "gc_value", IDfQuery.DF_READ_QUERY,idfSession);
	 }finally{
    	
    	SessionUtils.disconnect(idfSession);
    }
	
	return errRetentionPeriod;
}


	
	
	
	
}


	
	











