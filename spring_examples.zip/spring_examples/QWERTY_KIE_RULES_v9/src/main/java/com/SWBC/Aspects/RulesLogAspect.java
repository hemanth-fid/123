package com.SWBC.Aspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import com.SWBC.model.PreProc_Doca_Ucap;

import com.SWBC.DataService.TrecService;

@Aspect
@Component
public class RulesLogAspect {


	@Autowired
	private PreProc_Doca_Ucap preProc_Doca_Ucap;


	@Autowired
	@Lazy
	private TrecService trecService;

	@Before("execution(void com.SWBC.model.PreProc_Doca_Ucap.set*(*))")
	public void before(JoinPoint jp) throws Exception {
		String prop = jp.getSignature().getName().substring(3);
		Object target = jp.getTarget();
		Object before = target.getClass().getMethod("get" + prop).invoke(target);
		Object now = jp.getArgs()[0];
		// System.out.println(target.toString()+"::"+before+"::"+now);

		if (!prop.equalsIgnoreCase("CO_NAME") && !prop.equalsIgnoreCase("CO_ALIAS") && !prop.equalsIgnoreCase("Pp_flag") && !prop.equalsIgnoreCase("LogJoinID")) {
			if (before != null) {
				
				if(now != null)
				{

				if (before.toString().trim().equals("0.0") || before.toString().trim().equals("0") || now.toString().trim().equals("0.0") || now.toString().trim().equals("0")) {
					
					
					
				} 
				else {
					
					
						if (!before.toString().equals(now.toString())) {
							System.out.println(prop + " changed from " + before + " to " + now);
							trecService.saveEventAuditField(preProc_Doca_Ucap.getLogJoinID(), prop.toString(), before.toString(),
									now.toString());
						}
					
					
					

				}
				
				
				}
				
				
				
				
				
				

			}
		}

	}

}
