package com.SWBC.model;

import org.springframework.stereotype.Service;

@Service("rule_log")
public class Brm_rule_lookup_log {
	
	String rule_name;
	String rule_outcome;
	String rule_msg;
	String rule_category;
	
	
	public String getRule_name() {
		return rule_name;
	}
	public void setRule_name(String rule_name) {
		this.rule_name = rule_name;
	}
	public String getRule_outcome() {
		return rule_outcome;
	}
	public void setRule_outcome(String rule_outcome) {
		this.rule_outcome = rule_outcome;
	}
	public String getRule_msg() {
		return rule_msg;
	}
	public void setRule_msg(String rule_msg) {
		this.rule_msg = rule_msg;
	}
	public String getRule_category() {
		return rule_category;
	}
	public void setRule_category(String rule_category) {
		this.rule_category = rule_category;
	}

}
