
package org.ifc.idocs.forms.adaptors;

import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.IAdaptorParameter;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.xforms.engine.adaptor.datasource.ISetValueAdaptor;

public class SetAttachmentValidationFlag implements ISetValueAdaptor {

	public Object execute(IAdaptorParameter[] parameters)
			throws AdaptorException {
		System.out
				.println("SetAttachmentValidation:: Inside SetAttachmentValidation");
		boolean errorValue = true;

		IAdaptorParameter parameter1 = parameters[0];
		IAdaptorParameter parameter2 = parameters[1];
		String attachmetId[] = parameter1.getValues();
		String attachmentName[] = parameter2.getValues();
		if (attachmetId.length != attachmentName.length)
			errorValue = false;

		return errorValue;
	}

	public void destroy() throws AdaptorException {
	}

	public void init(IAdaptorConfiguration arg0) throws AdaptorException {
	}
}