package org.ifc.idocs.report.model;

public class DocumentDetailReportDisplay {
	
	private String folderValueCode1;
	private String folderTypeCode1;
	private String documentCount1;
	private String folderSize1;
	private String level1FolderSize1;
	private String level1SubFolder1;
	private String level1docCount1;
	
	private String folderValueCode2;
	private String folderTypeCode2;
	private String documentCount2;
	private String folderSize2;
	private String level1FolderSize2;
	private String level1SubFolder2;
	private String level1docCount2;
	
	public String getFolderValueCode1() {
		return folderValueCode1;
	}
	public void setFolderValueCode1(String folderValueCode1) {
		this.folderValueCode1 = folderValueCode1;
	}
	public String getDocumentCount1() {
		return documentCount1;
	}
	public void setDocumentCount1(String documentCount1) {
		this.documentCount1 = documentCount1;
	}
	public String getFolderSize1() {
		return folderSize1;
	}
	public void setFolderSize1(String folderSize1) {
		this.folderSize1 = folderSize1;
	}
	public String getFolderValueCode2() {
		return folderValueCode2;
	}
	public void setFolderValueCode2(String folderValueCode2) {
		this.folderValueCode2 = folderValueCode2;
	}
	public String getDocumentCount2() {
		return documentCount2;
	}
	public void setDocumentCount2(String documentCount2) {
		this.documentCount2 = documentCount2;
	}
	public String getFolderSize2() {
		return folderSize2;
	}
	public void setFolderSize2(String folderSize2) {
		this.folderSize2 = folderSize2;
	}
	public String getLevel1SubFolder1() {
		return level1SubFolder1;
	}
	public void setLevel1SubFolder1(String level1SubFolder1) {
		this.level1SubFolder1 = level1SubFolder1;
	}
	public String getLevel1docCount1() {
		return level1docCount1;
	}
	public void setLevel1docCount1(String level1docCount1) {
		this.level1docCount1 = level1docCount1;
	}
	public String getLevel1SubFolder2() {
		return level1SubFolder2;
	}
	public void setLevel1SubFolder2(String level1SubFolder2) {
		this.level1SubFolder2 = level1SubFolder2;
	}
	public String getLevel1docCount2() {
		return level1docCount2;
	}
	public void setLevel1docCount2(String level1docCount2) {
		this.level1docCount2 = level1docCount2;
	}
	public String getFolderTypeCode1() {
		return folderTypeCode1;
	}
	public void setFolderTypeCode1(String folderTypeCode1) {
		this.folderTypeCode1 = folderTypeCode1;
	}
	public String getFolderTypeCode2() {
		return folderTypeCode2;
	}
	public void setFolderTypeCode2(String folderTypeCode2) {
		this.folderTypeCode2 = folderTypeCode2;
	}
	public String getLevel1FolderSize1() {
		return level1FolderSize1;
	}
	public void setLevel1FolderSize1(String level1FolderSize1) {
		this.level1FolderSize1 = level1FolderSize1;
	}
	public String getLevel1FolderSize2() {
		return level1FolderSize2;
	}
	public void setLevel1FolderSize2(String level1FolderSize2) {
		this.level1FolderSize2 = level1FolderSize2;
	}
}
