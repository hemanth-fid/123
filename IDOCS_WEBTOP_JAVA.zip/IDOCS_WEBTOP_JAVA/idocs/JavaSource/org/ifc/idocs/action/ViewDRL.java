/**
* This custom class is used to get object id of the document and generate drl for it.
* 
* ####################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* ####################################################################################
* Gangadhar Reddy.V		02/15/2011		1.0				created

* ####################################################################################
*/
package org.ifc.idocs.action;

import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.Button;
import com.documentum.web.form.control.TextArea;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.drl.DRLComponent;

/**
 * This custom class is used to get object id of the document and generate drl for it.
 * @author Gangadhar
 *
 */
public class ViewDRL extends Component
{
	private String m_objectId;
	static Properties idocsProperties = new Properties();
	private static final long serialVersionUID = 1L;

	public ViewDRL() {
		m_objectId = "";
	}

	/**
	 * This method generates the DRL for the selected document and displays it in the UI
	 * @param args - Context Arguments
	 */
	public void onInit(ArgumentList args) {
		String fullDrl = "";
		try {
			DfLogger.info(this, "ViewDRL :: onInit : Login Username"+getDfSession().getLoginUserName(), null, null);
			m_objectId = args.get("objectId");
			HttpServletRequest request = (HttpServletRequest) this.getPageContext().getRequest();
			String drlString = DRLComponent.constructDRL(m_objectId, null, null, this);
			if(drlString != null) {
                fullDrl = Component.makeFullUrl(request, drlString);
                DfLogger.info(this, "ViewDRL :: fullDrl: " + fullDrl, null, null);
                TextArea drl = (TextArea)getControl("viewdrl", TextArea.class);
    			drl.setValue((new StringBuilder(String.valueOf(fullDrl))).toString());
    		}else {
            	DfLogger.info(this, "Unable To Construct DRL", null, null);
            }            	
            super.onInit(args);				
		} catch (DfException e) {
			DfLogger.error(this, "ViewDRL :: onInit Exception >> "+e.getMessage(), null, e);
		}
	}

	/**
	 * Allows user to go back to objectlist when closing the DRL window.
	 * @param control
	 * @param args
	 */
	public void onClose(Button control, ArgumentList args){
		setComponentReturn();
	}
}
