/**
* This class is for displaying  class is used to provide workflow status report for the current workflow on the document.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* CVattathara				10/01/2010		1.0				created
* #######################################################################################################
*/
package org.ifc.idocs.workflow.reportdetailscontainer;

import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.Panel;
import com.documentum.web.form.control.Tab;
import com.documentum.web.form.control.Tabbar;


public class ReportDetailsContainer extends com.documentum.webcomponent.library.workflow.reportdetailscontainer.ReportDetailsContainer{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String m_objectId;
	private String m_workflowId;
	public String MESSAGE="MESSAGE";
	private String m_component="workflow_error";
	private String r_workflow_id="r_workflow_id";

	public ReportDetailsContainer() {
		m_objectId = "";
		m_workflowId = "";
	}

	/**
	 * @param args
	 */
	public void onInit(ArgumentList args) {
		m_objectId=args.get("objectId");
		try {
			DfLogger.info(this, " :: onInit : "+getDfSession().getLoginUserName(), null, null);
			m_workflowId=IdocsUtil.getWorkflowId(getDfSession(), m_objectId);
		} catch (DfException e) {
			DfLogger.error(this," :: onInit Exception >> "+e.getMessage(),null,e);
		}
		if(!m_workflowId.equals("")){
			args.remove("objectId");
			args.add("objectId", m_workflowId);
			super.onInit(args);
		}
		else{
			setComponentReturnJump(m_component, args, getContext());
		}
	}
	
/* Commented as this fetches the workflow of the current Document
 * 
	private String getWorkflowId() throws DfException {
		IDfDocument dfDocument = (IDfDocument)getDfSession().getObject(new DfId(m_objectId));
		IDfCollection collection = dfDocument.getWorkflows("", "");
		if(collection.next()){
			m_workflowId=collection.getString(r_workflow_id);
			collection.close();
		}
		if(collection != null)collection.close();
		return m_workflowId;
	}*/

  public void onRender()
	  {
	    super.onRender();
	    try {
		    DfLogger.info(this, " :: onRender : "+getDfSession().getLoginUserName(), null, null);
		    Tabbar tabs = (Tabbar)getControl("tabs", Tabbar.class);
		    Panel panel = (Panel)getControl("__CLOSE_BUTTON_PANEL_NAME", Panel.class);
		    panel.setVisible(true);
	    } catch(Exception e) {
	    	DfLogger.error(this," :: onRender Exception >> "+e.getMessage(),null,e);
	    }
	  }
  
	 public void onTabSelected(Tab tab, ArgumentList args)
	  {
	   super.onTabSelected(tab, args);
	    Panel panel = (Panel)getControl("__CLOSE_BUTTON_PANEL_NAME", Panel.class);
	    panel.setVisible(true);
	  }
}