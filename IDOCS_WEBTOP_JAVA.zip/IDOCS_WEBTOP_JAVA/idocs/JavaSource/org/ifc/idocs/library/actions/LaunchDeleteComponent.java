/**
* This class to check the permissions for the component to validate.
* #######################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################
* Chitra Vattathara    09/17/2010	     1.0          Created

* #######################################################################
*/
package org.ifc.idocs.library.actions;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.ErrorMessageService;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.config.IConfigElement;

public class LaunchDeleteComponent extends com.documentum.web.formext.action.LaunchComponent {

	private static final long serialVersionUID = 1L;
    private static final NlsResourceBundle s_lookup = new NlsResourceBundle("org.ifc.idocs.action.ValidateGroupMembershipNlsProp");
	String accessRole = null;
	String strObjectType = "";
	String strObjectName ="";
	String strDocumentState ="";
	String strOwnerName ="";
	String m_lockOwner="";
	String isWorkflowRequired ="";
	String strTemplateTitle = "";
	String currentSecurityClassificationCode="";
	

    public String[] getRequiredParams(){
        return (new String[] {
            "objectId"
        });
    }
    
    /**
     * 
     */
	public boolean execute(String strAction, IConfigElement config, 
			ArgumentList args, Context context, Component component, Map completionArgs){
		String strObjectId = args.get("objectId");
		DfLogger.info(this, " :: execute : execute : Object ID "+strObjectId,null,null);
		boolean validated = false;
		try{
			if(strObjectId != null && strObjectId.trim().length()>0 && strObjectId.startsWith(IDocsConstants.MSG_DM_DOC_TYPE_PREF_CODE)){
			getRequiredAttributes(component, strObjectId);
			/**if Deletion of the Work flow is enabled in idocsProperties file*/
				if(IdocsUtil.getMessage("STR_DELETE_WRK_DOCUMENT_STATUS").equalsIgnoreCase(IdocsConstants.MSG_YES)){
					/**Verifying lockOwner existence and 
					 * 1. Allowing user to delete workflow document 
					 * 2. Restricting user to not delete non-workflow and locked document(both) */
				
				boolean restarableStatusVerified= false;
				if(m_lockOwner != null && m_lockOwner.length() >0){
					if(isDocumentPartOfWorkflow(strObjectId,component.getDfSession())){
						 strTemplateTitle=IdocsUtil.getTemplateTitle(component.getDfSession(), strObjectId);
						if(((m_lockOwner .equals(component.getDfSession().getDocbaseOwnerName()))) == false 
								|| (strTemplateTitle!= null 
										&& strTemplateTitle.trim().length() >0 
										&& strTemplateTitle.equals(IdocsUtil.getMessage("MSG_INTERNAL_OFFICE_MEMORANDUM")))){
							IDfCollection collection=null;
							String workFlowStatusQuery=IdocsUtil.getMessage("QRY_GET_WORKFLOW_STATUS_ON_VERSION_DOCS");
							boolean completedstatusExistance=false;
							boolean releasedStatusExistance=false;
							boolean restartableWRKStatus=false;
							try {
								restarableStatusVerified=true;
								restartableWRKStatus=getRestartableWorkFlowStatus(strObjectId,component.getDfSession());
								workFlowStatusQuery=workFlowStatusQuery.replace(STR_REPLACE_OBJECT_ID,strObjectId);
								collection=IdocsUtil.executeQuery(component.getDfSession(), workFlowStatusQuery, IDfQuery.DF_READ_QUERY);
								while(collection.next()){
									String status=collection.getString("workflow_status");
									if(status != null && status.trim().length() >0){
										if(status.equalsIgnoreCase("completed")){
											completedstatusExistance=true;
											DfLogger.info(this, "One/More Version is having Completed as workflow_status", null,null);
										}
										String releseStatus=collection.getString("doc_state");
										if(releseStatus.equalsIgnoreCase("Released")){
											releasedStatusExistance=true;
											DfLogger.info(this, "One/More Version is having Released as doc_status", null,null);
										}
									}
								}
								if(collection != null){
									collection.close();
								}
							} catch (DfException e) {
								DfLogger.error(this,e.getMessage(), null,null);
							}
							if(restartableWRKStatus && (completedstatusExistance || releasedStatusExistance)){
								ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_RELESED_DELETE_ERROR", component, new String[]{strObjectName}, null);
							}else{
								DfLogger.info(this, " :: execute :: document "+strObjectName+" is part of workflow document" ,null,null);	
							}
							/** Allowing system to validating other checks */
						}else{
							DfLogger.info(this, " :: execute :: document is locked by "+m_lockOwner ,null,null);
							ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_LOCKED_ADIMIN_DELETE_ERROR", component, new String[]{strObjectName}, null);
							return false;
						}
						}else{
							DfLogger.info(this, " :: execute :: document is locked by "+m_lockOwner ,null,null);
							ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_LOCKED_DELETE_ERROR", component, new String[]{strObjectName}, null);
							return false;
							}
					}
				 /** Restricting user for restartable WRK Completed/Released status existence  */
					if(restarableStatusVerified){
						//don't care , cursor entered in this section means already verified this check 
					}else{
						IDfCollection collection=null;
						String workFlowStatusQuery=IdocsUtil.getMessage("QRY_GET_WORKFLOW_STATUS_ON_VERSION_DOCS");
						boolean completedstatusExistance=false;
						boolean releasedStatusExistance=false;
						boolean restartableWRKStatus=false;
						try {
							restartableWRKStatus=getRestartableWorkFlowStatus(strObjectId,component.getDfSession());
							workFlowStatusQuery=workFlowStatusQuery.replace(STR_REPLACE_OBJECT_ID,strObjectId);
							collection=IdocsUtil.executeQuery(component.getDfSession(), workFlowStatusQuery, IDfQuery.DF_READ_QUERY);
							while(collection.next()){
								String status=collection.getString("workflow_status");
								if(status != null && status.trim().length() >0){
									if(status.equalsIgnoreCase("completed")){
										completedstatusExistance=true;
										DfLogger.info(this, "One/More Version is having Completed as workflow_status", null,null);
									}
									String releseStatus=collection.getString("doc_state");
									if(releseStatus.equalsIgnoreCase("Released")){
										releasedStatusExistance=true;
										DfLogger.info(this, "One/More Version is having Released as doc_status", null,null);
									}
								}
							}
							if(collection != null){
								collection.close();
							}
						} catch (DfException e) {
							DfLogger.error(this,e.getMessage(), null,null);
						}
						if(restartableWRKStatus && (completedstatusExistance || releasedStatusExistance)){
							ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_RELESED_DELETE_ERROR", component, new String[]{strObjectName}, null);
							return false;
						}else{
							/** Allowing system to validating other checks */	
						}
					
				}
				}else{
				/**if Deletion of the Work flow is not enabled in idocsProperties file*/
					if(isDocumentPartOfWorkflow(strObjectId,component.getDfSession())){
						ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_RUNNING_WORKFLOW_ACTION_DENIED", component,  new String[]{"Delete",strObjectName}, null);
						return false;
					}else{
						DfLogger.info(this,"WorkFlow Doc Deletion Not Enabled .. Continue not the part of WRK flow ", null,null);
					}
				}
				
				String templateCode = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(component.getDfSession(), strObjectId, IDocsConstants.MSG_TEMPLATE_CODE, IDocsConstants.MSG_IDOCS_DOCUMENT);
				if(strTemplateTitle != null && strTemplateTitle.length() >0){
					// queried previously 
				}else{
					strTemplateTitle  = IdocsUtil.getTemplateTitle(component.getDfSession(),strObjectId);
				}
				if(strObjectType != null && strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_PROJECT_DOC)){
					String projectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(component.getDfSession(),strObjectId,IDocsConstants.PROJECT_ID,strObjectType);
					if(projectId!= null && (IdocsUtil.isUserPresentInConflictOfInterest(projectId,component.getDfSession()) 
							|| IdocsUtil.isUserMemberofLDAPGroup(
									IdocsUtil.getMessage(IdocsConstants.CONFLICT_OF_INTEREST_ROLE), projectId, component.getDfSession()))){
						DfLogger.info(LaunchViewComponentWithPermitCheck.class,"::validateUserPermissionsForDelete  User is Present in Conflict Of Interest:", null, null);
						ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_COI_DELETE_DENIED", component, new String[]{"Delete",strObjectName}, null);
						return false;
					}else{
						DfLogger.debug(this, " :: validateUserPermissionsForDelete : Conflict Of Interest : Not present", null, null);
					}
				}else{
					DfLogger.debug(this, " :: validateUserPermissionsForDelete : Conflict Of Interest : Not a project document.", null, null);
				}
				
				/** Restricting Product workflow template deletion -- No one can delete product templates*/ 
				if(templateCode != null && templateCode.trim().length() > 0){
                    if (strTemplateTitle != null && strTemplateTitle.trim().length() > 0) {
	                    /** Product workflows cannot be deleted.*/
	                    if(IdocsUtil.ifProductIntegrationRequired(strTemplateTitle)){
	                    	ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_PRODUCT_TEMPLATE_DELETE_DENIED", component, new String[]{"Delete",strObjectName}, null);
							return false;
	                    }	
	                    /** Child Workflows cannot be deleted*/
	    				if(IdocsUtil.isThisAChildWorkflow(strTemplateTitle)){
	    					ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_CANNOT_DELETE_CHILDWORKFLOW", component, new String[]{strObjectName}, null);
	    					return false;
	    				}
					}			
				}
				
				String admingGroupName = IdocsUtil.getMessage("MSG_IDOCS_ADMIN_GRP");
				DfLogger.debug(this, " :: MSG_IDOCS_ADMIN_GRP : "+admingGroupName, null, null);
				if(admingGroupName != null && admingGroupName.trim().length() > 0 
						&& IdocsUtil.isMemberOfGroup(admingGroupName, component.getDfSession())){
					
					DfLogger.debug(this, " :: validateUserPermissionsForDelete : IDocs Admin : Allow Delete", null, null);
					return super.execute(strAction, config, args, context, component, completionArgs);
				}
				
				/** For 'Released' nobody can Delete the document */
				if(strDocumentState != null && strDocumentState.equalsIgnoreCase(IDocsConstants.MSG_STATE_RELEASED) == true ){
					if(templateCode!=null && templateCode.trim().length() > 0){
				        ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_RELEASED_ACTION_DENIED", component, new String[]{"Delete",strObjectName,IdocsUtil.handleLDAPEnvVariable(accessRole, component.getDfSession())}, null);
						return false;
					}else{
						/** Imported Documents in Release State also can be Deleted By the Owner */
						if(strOwnerName!=null && strOwnerName.equalsIgnoreCase(component.getDfSession().getLoginUserName()) == true ){
							DfLogger.info(this,"::  Allow to Delete as its Document Owner : " + strOwnerName, null, null);
							return super.execute(strAction, config, args, context, component, completionArgs);
						}						
					}
				}
				
				if(IdocsUtil.isSpecialNonWorkflowDocument(strTemplateTitle)){
					String specialNonWorkflowDeleteRole = IdocsUtil.getMessage("SPECIAL_NONWF_DELETE_ROLE");					
					if(specialNonWorkflowDeleteRole!=null && checkTeamMemberShip(component.getDfSession(), strObjectId, strObjectType,specialNonWorkflowDeleteRole)){
						DfLogger.info(this," :: '"+strObjectName+"' document can be deleted by : " + specialNonWorkflowDeleteRole, null, null);
						return super.execute(strAction, config, args, context, component, completionArgs);
					} else{
						ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_SPECIAL_NONWF_DELETE_DENIED", component, new String[]{specialNonWorkflowDeleteRole}, null);
						return false;
					}
				}
				/** Handle template which can only be deleted by owner .Not this handles only IOM */
				if (IdocsUtil.checkIfTokenPresent(IdocsUtil.getMessage("MSG_ONLY_OWNER_DELETE_TEMPLATENAMES"),strTemplateTitle,IdocsConstants.MSG_COMMA) == true
					|| (isWorkflowRequired != null && (isWorkflowRequired.equalsIgnoreCase(IdocsConstants.MSG_WORKFLOW_IS_REQUIRED)==false))){
					DfLogger.info(this,":: '"+strObjectName+"' document can only be deleted by owner: " + strOwnerName, null, null);

					if(strOwnerName!=null && strOwnerName.equalsIgnoreCase(component.getDfSession().getLoginUserName()) == true){
						return super.execute(strAction, config, args, context, component, completionArgs);
					} else {
						String iomdeleteRole = IdocsUtil.getMessage("IOM_NONWF_IMP_SCANN_DELETE_ROLE");
						if(iomdeleteRole!=null && checkTeamMemberShip(component.getDfSession(), strObjectId, strObjectType,iomdeleteRole)){
							DfLogger.info(this," :: '"+strObjectName+"' document can be deleted by : " + iomdeleteRole, null, null);
							return super.execute(strAction, config, args, context, component, completionArgs);
						}else{
							ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_ONLY_OWNER_CAN_DELETE", component, new String[]{strOwnerName + "','" + iomdeleteRole}, null);
							return false;
						}
					}
				}
											
				validated = validateUserPermissionsForDelete(strObjectId,completionArgs,component,component.getDfSession(),templateCode);
				DfLogger.info(this, " :: execute : validated ="+validated,null,null);
				if(validated == true ){
					return super.execute(strAction, config, args, context, component, completionArgs);
				}else{
					if(accessRole != null && accessRole.trim().length() > 0){
				        ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_ACTION_PERMISSION_DENIED", component, new String[]{"Delete",strObjectName,IdocsUtil.handleLDAPEnvVariable(accessRole, component.getDfSession())}, null);						
					}else{
				        ErrorMessageService.getService().setNonFatalError(s_lookup, "MSG_ACTION_PERMISSION_DENIED_OWNER_ONLY", component, new String[]{"Delete",strObjectName}, null);
					}
					return false;
				}			
			}else{
				return super.execute(strAction, config, args, context, component, completionArgs);
			}
		}catch (Exception e) {
			DfLogger.error(this, " :: execute : Exception :"+e.getMessage(),null,null);
		}
		return false;
    }


	/**
	 * 
	 * @param strObjectId
	 * @param dfSession
	 * @return
	 */

	private boolean isDocumentPartOfWorkflow(String strObjectId,IDfSession dfSession) {
		String workflowId = IdocsUtil.getWorkflowId(dfSession, strObjectId);
		if(workflowId!=null && workflowId.trim().length()>0){
			DfLogger.debug(this, " :: Document is part of workflow :",null,null);
			return true;
		}else{
			DfLogger.debug(this, " :: Document is NOT part of workflow :",null,null);
			return false;
		}
	}

	/**
	 * 
	 * @param strObjectId
	 * @param completionArgs
	 * @param component
	 * @param session
	 * @param templateCode 
	 * @return
	 * @throws DfException
	 */
	private boolean validateUserPermissionsForDelete(String strObjectId,Map completionArgs,
			Component component,IDfSession session, String templateCode) throws DfException {
		
		DfLogger.info(this,"::  validateUserPermissionsForDelete : " + strObjectId, null, null);
		DfLogger.info(this,":: CHANGE PERMIT Id:"+ strObjectId + " ::Type: " + strObjectType , null, null);
		DfLogger.info(this,"::  Document State : " + strDocumentState, null, null);
		/** If the document is country allow user to delete the permissions  */
		if(strObjectType!=null && strObjectType.trim().length() > 0 
				&& strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_COUNTRY_DOC)){
			DfLogger.info(this,"::  Allow Delete its a : " + IDocsConstants.MSG_IDOCS_COUNTRY_DOC, null, null);
			return true;
		}
		/** If the document state is released nobody is allowed to modify the ACL */
		if( strDocumentState != null && strDocumentState.equalsIgnoreCase(IdocsConstants.DOC_STATE_RELEASED)== true ){
			DfLogger.info(this,"::  Dont allow to Delete its : " + IdocsConstants.DOC_STATE_RELEASED, null, null);
			return false;
		}
		
		/** AS Changes */
		if(strTemplateTitle != null && strTemplateTitle.trim().length() >0){
			// Template tile query executed previously
		}else{
			strTemplateTitle = IdocsUtil.getTemplateTitle(session, strObjectId);
		}
		
		if(IdocsUtil.isAdvisoryTemplate(strTemplateTitle)){
			if(strObjectType != null && strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_PROJECT_DOC)){
				String projectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(component.getDfSession(),strObjectId,IDocsConstants.PROJECT_ID,strObjectType);
				return IdocsUtil.checkASProjectTeam(projectId, session);
			}else{
				
			}
		}
		/** End AS Changes */
		/** For non 'Released' Documents owners are allowed to edit the ACl */
		if(strOwnerName!=null && strOwnerName.equalsIgnoreCase(component.getDfSession().getLoginUserName()) == true ){
			DfLogger.info(this,"::  Allow to Delete as user is document owner : " + strOwnerName, null, null);
			return true;
		}

		/** For non 'Released' documents only specific users are allowed delete the Document the ACL. */
		if(currentSecurityClassificationCode != null &&currentSecurityClassificationCode.length() >0){
			//don't care
		}else{
			currentSecurityClassificationCode = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(component.getDfSession(),
						strObjectId,IDocsConstants.MSG_SEC_CLASSIFICATION_CODE,strObjectType);
		}
		
		DfLogger.info(this,"::  currentSecurityClassificationCode : " + currentSecurityClassificationCode, null, null);
		String projectRole = null;
		if(isWorkflowRequired !=null && isWorkflowRequired.equalsIgnoreCase(IdocsConstants.MSG_WORKFLOW_IS_REQUIRED) == true){
			/** Workflow documents , Creator Roles can delete. */
			projectRole = appendCreateRoles(component.getDfSession(),projectRole,strObjectId,templateCode);
		} else {
			if(IDocsConstants.MSG_OFFICIAL_CODE.equals(currentSecurityClassificationCode)){
				projectRole = IdocsUtil.getMessage("PROJECT_DOCUMENT_DELETE_ROLE_O");		
			}else if(IDocsConstants.MSG_CONFIDENTIAL_CODE.equals(currentSecurityClassificationCode)){
				projectRole = IdocsUtil.getMessage("PROJECT_DOCUMENT_DELETE_ROLE_C");			
			}else if(IDocsConstants.MSG_STRICTLY_CONFIDENTIAL_CODE.equals(currentSecurityClassificationCode)){
				projectRole = IdocsUtil.getMessage("PROJECT_DOCUMENT_DELETE_ROLE_S");			
			}else{
				DfLogger.info(this, " :: Exception: Unknown Security Classigication Code : "+currentSecurityClassificationCode,null,null);
			}
		}
		
		if(projectRole != null){			
			return checkTeamMemberShip(component.getDfSession(), strObjectId, strObjectType,projectRole);				
		}else{
			if(strOwnerName!=null && strOwnerName.equalsIgnoreCase(component.getDfSession().getLoginUserName()) == true ){
				return true;
			}else{
				return false;
			}
		}
	}
	
	/**
	 * This utility method gets the create roles from the APP SEC config table and appends with the given roles.
	 * out will be comma separated string.
	 * @param dfSession
	 * @param projectRole
	 * @param strObjectId
	 * @param templateCode
	 * @return
	 */
	private String appendCreateRoles(IDfSession dfSession, String projectRole,
			String strObjectId, String templateCode) {
		String createRole=projectRole;
		try {
			String getCreateRoleQry=IdocsUtil.getMessage("QRY_GET_CREATE_DOC_ROLES");	
			getCreateRoleQry=getCreateRoleQry.replaceAll(IdocsConstants.MSG_C_DQ_C,IdocsConstants.MSG_QUOTES+templateCode+IdocsConstants.MSG_QUOTES);
			DfLogger.debug(LaunchDeleteComponent.class, " :: appendCreateRoles : getCreateRoleQry : " + getCreateRoleQry, null, null);
			IDfQuery query = new DfQuery(getCreateRoleQry);
			IDfCollection createRoleCollection = query.execute(dfSession,IDfQuery.DF_READ_QUERY);
			while(createRoleCollection.next()){
				String newRoleValue = createRoleCollection.getString(IdocsConstants.MSG_CREATE_ROLE);
				if(newRoleValue!=null && newRoleValue.trim().length()>0 ){
					if(createRole == null || (createRole != null && createRole.trim().length() <= 0)){
						createRole = newRoleValue;
					}else {
						createRole = new StringBuilder().append(createRole).append(IdocsConstants.MSG_COMMA)
							.append(newRoleValue).toString(); 
					}
				}else{
					DfLogger.debug(LaunchDeleteComponent.class, " :: appendCreateRoles : Got a Blank Role Not Adding to createRole="+ createRole, null, null);
				}
			}
			if(createRoleCollection != null)createRoleCollection.close();
		} catch (DfException e) {
			DfLogger.error(LaunchDeleteComponent.class, " :: appendCreateRoles : Exception : " + e.getMessage(), null, null);			
		}
		String uniqueRoles = null;
		if(createRole != null && createRole.trim().length() > 0){
			
			String [] createRoleArray = createRole.split(",");
			Map uniqCreateRoleMap = new HashMap(); 
			for (int i = 0; i < createRoleArray.length; i++) {
				uniqCreateRoleMap.put(createRoleArray[i], createRoleArray[i]);
			}
			Iterator iterator = uniqCreateRoleMap.entrySet().iterator();
			while (iterator.hasNext()) { 
			     Map.Entry entry = (Map.Entry)iterator.next();
			     String roleValueFromMap = (String)entry.getKey();
			     if(uniqueRoles == null){
			    	 uniqueRoles = roleValueFromMap;
			     }else{
			    	 uniqueRoles =  uniqueRoles + "," +roleValueFromMap;
			     }
			}
		}
		DfLogger.debug(LaunchDeleteComponent.class, " :: appendCreateRoles : createRole << "+ createRole, null, null);
		createRole = uniqueRoles;
		return createRole;
	}
	
	/**
	 * This utility method checks whether the current user is a part of project/Institution team.
	 * @param dfSession 	- Current Login Session to get the detail of user details.
	 * @param strObjectId	- Current ObjectId
	 * @param strObjectType	- Current Object Type
	 * @param role			- Valid Roles who can perform this action
	 * @return				- true  - If Current User is a member of the valid Roles.
	 * 						- false - If the user is not a member of any of the valid roles.
	 */
	private boolean checkTeamMemberShip(IDfSession dfSession,
			String strObjectId, String strObjectType,
			String role){
		boolean validated = false;
		String strInstitutionNumberOrProjectId = null;
		try{
			String strMemberRoleQry = null;
			if(strObjectType != null && strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_INSTITUTION_DOC)){
				strMemberRoleQry = IdocsUtil.getMessage("QRY_INSTITUTION_MEMBER");
				strInstitutionNumberOrProjectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(dfSession,
						strObjectId,IdocsConstants.MSG_INSTITUTION_NBR,strObjectType);
				String clientProjects = IdocsUtil.getClientProjects(strInstitutionNumberOrProjectId,dfSession);
				if(clientProjects!=null && clientProjects.length()>0){
					clientProjects = clientProjects.replaceAll(IdocsConstants.MSG_COMMA, IdocsConstants.MSG_Q_COMMA_Q);
			    }
				boolean userPresentInLDAPGroup = IdocsUtil.isUserMemberofLDAPGroup(
						role, clientProjects, dfSession);
				if (userPresentInLDAPGroup == true) {
					return true;
				} else {
					DfLogger.debug(IdocsUtil.class,"User is not present in LDAP Group. COntinue with Direct User Membership",null, null);
				}
			}else if(strObjectType != null && strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_PROJECT_DOC)){
				strMemberRoleQry = IdocsUtil.getMessage("QRY_PROJ_MEMBER");
				strInstitutionNumberOrProjectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(dfSession,
						strObjectId,IdocsConstants.PROJ_ID,strObjectType);
				boolean userPresentInLDAPGroup = IdocsUtil.isUserMemberofLDAPGroup(
						role, strInstitutionNumberOrProjectId, dfSession);
				if (userPresentInLDAPGroup == true) {
					return true;
				} else {
					DfLogger.debug(IdocsUtil.class,"User is not present in LDAP Group. COntinue with Direct User Membership",null, null);
				}
			}
			strMemberRoleQry = strMemberRoleQry.replaceFirst(IdocsConstants.MSG_C_DQ_C,IdocsConstants.MSG_QUOTES+strInstitutionNumberOrProjectId+IdocsConstants.MSG_QUOTES);
			strMemberRoleQry = strMemberRoleQry.replaceFirst(IdocsConstants.MSG_C_DQ_C, IdocsUtil.makeQuerySafe(role,null));
			strMemberRoleQry = strMemberRoleQry.replaceFirst(IdocsConstants.MSG_C_DQ_C, IdocsConstants.MSG_QUOTES+IdocsUtil.handleSingleQuote(dfSession.getLoginUserName())+IdocsConstants.MSG_QUOTES);
			accessRole = IdocsConstants.MSG_QUOTES+role+IdocsConstants.MSG_QUOTES;
			IDfQuery query = new DfQuery();
			query.setDQL(strMemberRoleQry);
			DfLogger.info(this, " :: checkTeamMemberShip : Check User Role Query :"+strMemberRoleQry,null,null);
			IDfCollection coll=query.execute(dfSession,IDfQuery.DF_READ_QUERY);
			if(coll.next()){
				validated=true;
				coll.close();
			}
			if(coll != null )coll.close();
		}catch (Exception e) {
			DfLogger.info(this, " :: checkTeamMemberShip : Exception :"+e.getMessage(),null,null);
		}
		return validated;
	}	
	 
    /**
     * 
     * @param m_strObjectId
     * @return
     */
    private boolean getRestartableWorkFlowStatus(String m_strObjectId,IDfSession dfSession){
   	 String restartableWorkflowQry=IdocsUtil.getMessage("QRY_GET_RESTARTABLE_WORKFLOW");
   	 restartableWorkflowQry=restartableWorkflowQry.replace(STR_REPLACE_OBJECT_ID,m_strObjectId);
   	 IDfCollection dfCollection = null;
   	 boolean isworkflowrestartable=false;
   	 try {
   		 dfCollection=IdocsUtil.executeQuery(dfSession,restartableWorkflowQry, IDfQuery.DF_READ_QUERY);
   		 if(dfCollection != null){
   			 while(dfCollection.next()){
   				 isworkflowrestartable=dfCollection.getBoolean("isworkflowrestartable");
   			 }	 
   		 }else{
   			 DfLogger.debug(this, "Query Faild to Fetch details for query ::"+restartableWorkflowQry , null, null);
   		 }
   	 } catch (DfException e) {
   		 DfLogger.error(this, " Query Faild to Fetch details for query ::"+e.getMessage() , null, e);
   	 }finally{
   		 if(dfCollection != null){
   			 try {
   				 dfCollection.close();
   			 } catch (DfException e) {
   				 DfLogger.error(this, e.getMessage() , null, e);
   			 }
   		 }
   	 }
   	 return isworkflowrestartable;
    }
    
	/**
	 * @param component
	 * @param strObjectId
	 * @throws DfException
	 */
	private void getRequiredAttributes(Component component, String strObjectId)
			throws DfException {
		IDfCollection dfCollectionMain = null;
		String mainQuery=IdocsUtil.getMessage("QRY_GET_DOC_DETAILS");
		mainQuery=mainQuery.replace(STR_REPLACE_OBJECT_ID, strObjectId);
		dfCollectionMain=IdocsUtil.executeQuery(component.getDfSession(), mainQuery, IDfQuery.DF_READ_QUERY);
		while(dfCollectionMain.next()){
			strObjectType=dfCollectionMain.getString( IDocsConstants.MSG_R_OBJECT_TYPE);
			strObjectName=dfCollectionMain.getString( IDocsConstants.MSG_OBJECT_NAME);
			strDocumentState=dfCollectionMain.getString( IDocsConstants.MSG_DOC_STATE);
			m_lockOwner=dfCollectionMain.getString(IdocsConstants.R_LOCK_OWNER);
		    strOwnerName = dfCollectionMain.getString(IDocsConstants.MSG_OWNER_NAME);
		    isWorkflowRequired=dfCollectionMain.getString(IDocsConstants.MSG_IS_WORKFLOW_REQUIRED);
		    currentSecurityClassificationCode = dfCollectionMain.getString(IDocsConstants.MSG_SEC_CLASSIFICATION_CODE);
		}
		if(dfCollectionMain != null)
			dfCollectionMain.close();
	}
	
	private String STR_REPLACE_OBJECT_ID="<objectId>";
}