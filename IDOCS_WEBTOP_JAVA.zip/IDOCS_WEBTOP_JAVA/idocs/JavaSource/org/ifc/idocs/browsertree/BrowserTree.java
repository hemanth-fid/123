/**
* This is the custom class to create custom control browsertree - BrowserTree .
* #############################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #############################################################################
* Parag Doshi		    11/20/2010	     1.0          Created

* #############################################################################
*/
package org.ifc.idocs.browsertree;


import com.documentum.web.common.ArgumentList;

/**This class is used to get the control of custom webtop browser tree class.
 * 
 * @author parag
 *
 */
public class BrowserTree extends com.documentum.webtop.webcomponent.browsertree.BrowserTree
{
	/**
	 * This is custom behaviour class for browsertree which extends default class, 
	 * to create custom control in component
	 */
	private static final long serialVersionUID = -7640012670026774659L;

	public BrowserTree() {
		super();
	}
	
	public void onInit(ArgumentList args){
			super.onInit(args);
	}
}


