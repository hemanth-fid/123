/**
 * PCHW078ServicePort_Type.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W;

public interface PCHW078ServicePort_Type extends java.rmi.Remote {
    public gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078Response_Type PCHW078(gov.mdc.iwa.stubs.CICS.TWBA.PCHW078W.PCHW078Request_Type body) throws java.rmi.RemoteException;
}
