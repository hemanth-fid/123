package com.SWBC.model;

import java.util.Date;
import java.util.List;

public class Brm_app_info {
	private String accountNumber; // account_number_iir_match
	private Date as400_post_date;
	private String comments;

	private String id;

	private String loan_account_no;// [IS_ACCOUNT_NO]
	private Date loan_begin_date;

	private Date loan_cancel_date;
	private String loan_company_name;
	private String loan_cov_type;// [IS_COVERAGE_TYPE]
	private Date loan_doc_issue_date;// [IS_DOC_ISSUE_DT]
	private Date loan_effective_date;
	private String loan_escrow_client;
	private String loan_escrow_code; // [IS_ESCROW_CODE]
	private Date loan_expiration_date;// [IS_EXPIRATION_DATE]
	private Date loan_his_rei_date;

	private String loan_insur_status;// IS_INSUR_STATUS
	private String loan_insur_type; // [IS_INSUR_TYPE]
	private String loan_is_cancelled;
	private String loan_is_escrow_client;// FMS057
	private String loan_is_force_placed;

	private String loan_mortgagee_name;
	private String loan_no; // [IS_LOAN_NO]
	private String loan_no_suffix; // [IS_LOAN_SUFFIX]
	private Date loan_pme_bill_date;
	private String loan_policy_no;// [IS_POLICY_NO]
	private Date loan_transaction_date;
	private Date loan_uninsured_date; // [IS_UNINSURED_DATE]
	private String proc_user;
	private Date rec_created_on;
	private Date rec_modified_on;
	private String rule_outcome;
	private String tansactionLoanSuffix; // EM_LOAN_SUFFIX
	private Date transaction_cancel_date; // EM_POL_CANCEL_DATE
	private String transaction_cov_type; // EM_COV_TYPE
	private Date transaction_doc_issue_date; // EM_TRAN_DATE
	private String transaction_id; // EM_DOC_NO
	private String transaction_loan_no; // loan_number_iir_match ,
										// TransactionLoanNo
	private String transaction_mortgagee_name; // EM_MORTGAGE_COMPANY
	private String transaction_policy_no; // EM_POLICY_NO
	private String transaction_policy_reason; // EM_POL_CXL_RSN

	private Date transaction_reinstatement_date; // EM_POL_REINST_DATE
	private String transaction_status; // final_decision
	private String transaction_type; // EM_POL_TRAN_CODE
	private String loan_his_dual_policy_no;
	private String transactionInsurer;
	private Date transaction_effective_date;
	private Date transaction_expiration_date;
	private int policyScore;
	private List<String> policyCancelReasonList;
	private List<String> transactionInsurerList;
	private int PMEDays;
	private int REIDays;
	private long diffRcvdDate;
	private String swbc_chk;
	private int ES_CHECK_NO;
	private Date ES_RCVD_DATE; // for ITC 8 Series ..PME Received Date
	private Date ES_EXP_DATE;
	private Date ES_EFF_DATE;
	private String transactionPolicyDecision;
	private String rei_fmr_date_check;
	
	private String loan_pme_current_term;
	private String loan_pme_es_policy_no;
	private int loan_pme_policy_score;
	private Date loan_pme_effective_date;
	
	
	private Date loan_pme_expiration_date;
	private String transaction_impairment_code;
	private double transaction_em_cov_amt;
	private double	transaction_premium_amt;
	private double transaction_premium_net_amt;
	private String	transaction_em_flood_zone;
	private String	disbursementFlag;
	private String	loan_impairment_code;
	private double	loan_ag_coverage_amt;
	private double	loan_pme_premium_amt;
	private String	loan_ag_flood_zone;
	private String	loan_transaction_id;
	
	private double transaction_edi_deductible_per;
	private double transaction_non_edi_deductible_per;
	private double transaction_deductible_amt;
	private double loan_escrow_premium_amt;
	
	private double loan_ag_deductible_amt;
	private double loan_ag_deductible_pct;
	
	private String transaction_naic_code;
	
	private String policy_type;
	
	public String getPolicy_type() {
		return policy_type;
	}

	public void setPolicy_type(String policy_type) {
		this.policy_type = policy_type;
	}

	public String getTransaction_naic_code() {
		return transaction_naic_code;
	}

	public void setTransaction_naic_code(String transaction_naic_code) {
		this.transaction_naic_code = transaction_naic_code;
	}

	private String loan_gap_line;
	public Date getLoan_gap_effective_date() {
		return loan_gap_effective_date;
	}

	public void setLoan_gap_effective_date(Date loan_gap_effective_date) {
		this.loan_gap_effective_date = loan_gap_effective_date;
	}

	public Date getLoan_gap_expiration_date() {
		return loan_gap_expiration_date;
	}

	public void setLoan_gap_expiration_date(Date loan_gap_expiration_date) {
		this.loan_gap_expiration_date = loan_gap_expiration_date;
	}

	private Date loan_gap_effective_date;
	private Date loan_gap_expiration_date;
	
	public String getLoan_gap_line() {
		return loan_gap_line;
	}

	public void setLoan_gap_line(String loan_gap_line) {
		this.loan_gap_line = loan_gap_line;
	}

	public Date getLoan_pme_expiration_date() {
		return loan_pme_expiration_date;
	}

	public void setLoan_pme_expiration_date(Date loan_pme_expiration_date) {
		this.loan_pme_expiration_date = loan_pme_expiration_date;
	}

	public String getTransaction_impairment_code() {
		return transaction_impairment_code;
	}

	public void setTransaction_impairment_code(String transaction_impairment_code) {
		this.transaction_impairment_code = transaction_impairment_code;
	}

	public double getTransaction_em_cov_amt() {
		return transaction_em_cov_amt;
	}

	public void setTransaction_em_cov_amt(double transaction_em_cov_amt) {
		this.transaction_em_cov_amt = transaction_em_cov_amt;
	}

	public double getTransaction_premium_amt() {
		return transaction_premium_amt;
	}

	public void setTransaction_premium_amt(double transaction_premium_amt) {
		this.transaction_premium_amt = transaction_premium_amt;
	}

	public double getTransaction_premium_net_amt() {
		return transaction_premium_net_amt;
	}

	public void setTransaction_premium_net_amt(double transaction_premium_net_amt) {
		this.transaction_premium_net_amt = transaction_premium_net_amt;
	}

	public String getTransaction_em_flood_zone() {
		return transaction_em_flood_zone;
	}

	public void setTransaction_em_flood_zone(String transaction_em_flood_zone) {
		this.transaction_em_flood_zone = transaction_em_flood_zone;
	}

	public String getDisbursementFlag() {
		return disbursementFlag;
	}

	public void setDisbursementFlag(String disbursementFlag) {
		this.disbursementFlag = disbursementFlag;
	}

	public String getLoan_impairment_code() {
		return loan_impairment_code;
	}

	public void setLoan_impairment_code(String loan_impairment_code) {
		this.loan_impairment_code = loan_impairment_code;
	}

	public double getLoan_ag_coverage_amt() {
		return loan_ag_coverage_amt;
	}

	public void setLoan_ag_coverage_amt(double loan_ag_coverage_amt) {
		this.loan_ag_coverage_amt = loan_ag_coverage_amt;
	}

	public double getLoan_pme_premium_amt() {
		return loan_pme_premium_amt;
	}

	public void setLoan_pme_premium_amt(double loan_pme_premium_amt) {
		this.loan_pme_premium_amt = loan_pme_premium_amt;
	}

	public String getLoan_ag_flood_zone() {
		return loan_ag_flood_zone;
	}

	public void setLoan_ag_flood_zone(String loan_ag_flood_zone) {
		this.loan_ag_flood_zone = loan_ag_flood_zone;
	}

	public String getLoan_transaction_id() {
		return loan_transaction_id;
	}

	public void setLoan_transaction_id(String loan_transaction_id) {
		this.loan_transaction_id = loan_transaction_id;
	}

	public Date getLoan_pme_effective_date() {
		return loan_pme_effective_date;
	}

	public void setLoan_pme_effective_date(Date loan_pme_effective_date) {
		this.loan_pme_effective_date = loan_pme_effective_date;
	}


	
	
	public String getLoan_pme_es_policy_no() {
		return loan_pme_es_policy_no;
	}

	public void setLoan_pme_es_policy_no(String loan_pme_es_policy_no) {
		this.loan_pme_es_policy_no = loan_pme_es_policy_no;
	}

	public int getLoan_pme_policy_score() {
		return loan_pme_policy_score;
	}

	public void setLoan_pme_policy_score(int loan_pme_policy_score) {
		this.loan_pme_policy_score = loan_pme_policy_score;
	}

	public String getLoan_pme_current_term() {
		return loan_pme_current_term;
	}

	public void setLoan_pme_current_term(String loan_pme_current_term) {
		this.loan_pme_current_term = loan_pme_current_term;
	}

	private Date pme_creation_date;

	public Date getPme_creation_date() {
		return pme_creation_date;
	}

	public void setPme_creation_date(Date pme_creation_date) {
		this.pme_creation_date = pme_creation_date;
	}

	public String getRei_fmr_date_check() {
		return rei_fmr_date_check;
	}

	public void setRei_fmr_date_check(String rei_fmr_date_check) {
		this.rei_fmr_date_check = rei_fmr_date_check;
	}

	public long getDiffRcvdDate() {
		return diffRcvdDate;
	}

	public void setDiffRcvdDate(long diffRcvdDate) {
		this.diffRcvdDate = diffRcvdDate;
	}

	public String getSwbc_chk() {
		return swbc_chk;
	}

	public void setSwbc_chk(String swbc_chk) {
		this.swbc_chk = swbc_chk;
	}

	public int getES_CHECK_NO() {
		return ES_CHECK_NO;
	}

	public void setES_CHECK_NO(int eS_CHECK_NO) {
		ES_CHECK_NO = eS_CHECK_NO;
	}

	public Date getES_RCVD_DATE() {
		return ES_RCVD_DATE;
	}

	public void setES_RCVD_DATE(Date eS_RCVD_DATE) {
		ES_RCVD_DATE = eS_RCVD_DATE;
	}

	public Date getES_EXP_DATE() {
		return ES_EXP_DATE;
	}

	public void setES_EXP_DATE(Date eS_EXP_DATE) {
		ES_EXP_DATE = eS_EXP_DATE;
	}

	public Date getES_EFF_DATE() {
		return ES_EFF_DATE;
	}

	public void setES_EFF_DATE(Date eS_EFF_DATE) {
		ES_EFF_DATE = eS_EFF_DATE;
	}

	public Date getTransaction_effective_date() {
		return transaction_effective_date;
	}

	public void setTransaction_effective_date(Date transaction_effective_date) {
		this.transaction_effective_date = transaction_effective_date;
	}

	public Date getTransaction_expiration_date() {
		return transaction_expiration_date;
	}

	public void setTransaction_expiration_date(Date transaction_expiration_date) {
		this.transaction_expiration_date = transaction_expiration_date;
	}

	public List<String> getPolicyCancelReasonList() {
		return policyCancelReasonList;
	}

	public void setPolicyCancelReasonList(List<String> policyCancelReasonList) {
		this.policyCancelReasonList = policyCancelReasonList;
	}

	public List<String> getTransactionInsurerList() {
		return transactionInsurerList;
	}

	public void setTransactionInsurerList(List<String> transactionInsurerList) {
		this.transactionInsurerList = transactionInsurerList;
	}

	public String getTransactionInsurer() {
		return transactionInsurer;
	}

	public void setTransactionInsurer(String transactionInsurer) {
		this.transactionInsurer = transactionInsurer;
	}

	public int getPolicyScore() {
		return policyScore;
	}

	public void setPolicyScore(int policyScore) {
		this.policyScore = policyScore;
	}

	public String getLoan_his_dual_policy_no() {
		return loan_his_dual_policy_no;
	}

	public void setLoan_his_dual_policy_no(String loan_his_dual_policy_no) {
		this.loan_his_dual_policy_no = loan_his_dual_policy_no;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public Date getAs400_post_date() {
		return as400_post_date;
	}

	public String getComments() {
		return comments;
	}

	public String getId() {
		return id;
	}

	public String getLoan_account_no() {
		return loan_account_no;
	}

	public Date getLoan_begin_date() {
		return loan_begin_date;
	}

	public Date getLoan_cancel_date() {
		return loan_cancel_date;
	}

	public String getLoan_company_name() {
		return loan_company_name;
	}

	public String getLoan_cov_type() {
		return loan_cov_type;
	}

	public Date getLoan_doc_issue_date() {
		return loan_doc_issue_date;
	}

	public Date getLoan_effective_date() {
		return loan_effective_date;
	}

	public String getLoan_escrow_client() {
		return loan_escrow_client;
	}

	public String getLoan_escrow_code() {
		return loan_escrow_code;
	}

	public Date getLoan_expiration_date() {
		return loan_expiration_date;
	}

	public Date getLoan_his_rei_date() {
		return loan_his_rei_date;
	}

	public String getLoan_insur_status() {
		return loan_insur_status;
	}

	public String getLoan_insur_type() {
		return loan_insur_type;
	}

	public String getLoan_is_cancelled() {
		return loan_is_cancelled;
	}

	public String getLoan_is_escrow_client() {
		return loan_is_escrow_client;
	}

	public String getLoan_is_force_placed() {
		return loan_is_force_placed;
	}

	public String getLoan_mortgagee_name() {
		return loan_mortgagee_name;
	}

	public String getLoan_no() {
		return loan_no;
	}

	public String getLoan_no_suffix() {
		return loan_no_suffix;
	}

	public Date getLoan_pme_bill_date() {
		return loan_pme_bill_date;
	}

	public String getLoan_policy_no() {
		return loan_policy_no;
	}

	public Date getLoan_transaction_date() {
		return loan_transaction_date;
	}

	public Date getLoan_uninsured_date() {
		return loan_uninsured_date;
	}

	public String getProc_user() {
		return proc_user;
	}

	public Date getRec_created_on() {
		return rec_created_on;
	}

	public Date getRec_modified_on() {
		return rec_modified_on;
	}

	public String getRule_outcome() {
		return rule_outcome;
	}

	public String getTansactionLoanSuffix() {
		return tansactionLoanSuffix;
	}

	public Date getTransaction_cancel_date() {
		return transaction_cancel_date;
	}

	public String getTransaction_cov_type() {
		return transaction_cov_type;
	}

	public Date getTransaction_doc_issue_date() {
		return transaction_doc_issue_date;
	}

	public String getTransaction_id() {
		return transaction_id;
	}

	public String getTransaction_loan_no() {
		return transaction_loan_no;
	}

	public String getTransaction_mortgagee_name() {
		return transaction_mortgagee_name;
	}

	public String getTransaction_policy_no() {
		return transaction_policy_no;
	}

	public String getTransaction_policy_reason() {
		return transaction_policy_reason;
	}

	public Date getTransaction_reinstatement_date() {
		return transaction_reinstatement_date;
	}

	public String getTransaction_status() {
		return transaction_status;
	}

	public String getTransaction_type() {
		return transaction_type;
	}

	public String getTransactionPolicyDecision() {
		return transactionPolicyDecision;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public void setAs400_post_date(Date as400_post_date) {
		this.as400_post_date = as400_post_date;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setLoan_account_no(String loan_account_no) {
		this.loan_account_no = loan_account_no;
	}

	public void setLoan_begin_date(Date loan_begin_date) {
		this.loan_begin_date = loan_begin_date;
	}

	public void setLoan_cancel_date(Date loan_cancel_date) {
		this.loan_cancel_date = loan_cancel_date;
	}

	public void setLoan_company_name(String loan_company_name) {
		this.loan_company_name = loan_company_name;
	}

	public void setLoan_cov_type(String loan_cov_type) {
		this.loan_cov_type = loan_cov_type;
	}

	public void setLoan_doc_issue_date(Date loan_doc_issue_date) {
		this.loan_doc_issue_date = loan_doc_issue_date;
	}

	public void setLoan_effective_date(Date loan_effective_date) {
		this.loan_effective_date = loan_effective_date;
	}

	public void setLoan_escrow_client(String loan_escrow_client) {
		this.loan_escrow_client = loan_escrow_client;
	}

	public void setLoan_escrow_code(String loan_escrow_code) {
		this.loan_escrow_code = loan_escrow_code;
	}

	public void setLoan_expiration_date(Date loan_expiration_date) {
		this.loan_expiration_date = loan_expiration_date;
	}

	public void setLoan_his_rei_date(Date loan_his_rei_date) {
		this.loan_his_rei_date = loan_his_rei_date;
	}

	public void setLoan_insur_status(String loan_insur_status) {
		this.loan_insur_status = loan_insur_status;
	}

	public void setLoan_insur_type(String loan_insur_type) {
		this.loan_insur_type = loan_insur_type;
	}

	public void setLoan_is_cancelled(String loan_is_cancelled) {
		this.loan_is_cancelled = loan_is_cancelled;
	}

	public void setLoan_is_escrow_client(String loan_is_escrow_client) {
		this.loan_is_escrow_client = loan_is_escrow_client;
	}

	public void setLoan_is_force_placed(String loan_is_force_placed) {
		this.loan_is_force_placed = loan_is_force_placed;
	}

	public void setLoan_mortgagee_name(String loan_mortgagee_name) {
		this.loan_mortgagee_name = loan_mortgagee_name;
	}

	public void setLoan_no(String loan_no) {
		this.loan_no = loan_no;
	}

	public void setLoan_no_suffix(String loan_no_suffix) {
		this.loan_no_suffix = loan_no_suffix;
	}

	public void setLoan_pme_bill_date(Date loan_pme_bill_date) {
		this.loan_pme_bill_date = loan_pme_bill_date;
	}

	public void setLoan_policy_no(String loan_policy_no) {
		this.loan_policy_no = loan_policy_no;
	}

	public void setLoan_transaction_date(Date loan_transaction_date) {
		this.loan_transaction_date = loan_transaction_date;
	}

	public void setLoan_uninsured_date(Date loan_uninsured_date) {
		this.loan_uninsured_date = loan_uninsured_date;
	}

	public void setProc_user(String proc_user) {
		this.proc_user = proc_user;
	}

	public void setRec_created_on(Date rec_created_on) {
		this.rec_created_on = rec_created_on;
	}

	public void setRec_modified_on(Date rec_modified_on) {
		this.rec_modified_on = rec_modified_on;
	}

	public void setRule_outcome(String rule_outcome) {
		this.rule_outcome = rule_outcome;
	}

	public void setTansactionLoanSuffix(String tansactionLoanSuffix) {
		this.tansactionLoanSuffix = tansactionLoanSuffix;
	}

	public void setTransaction_cancel_date(Date transaction_cancel_date) {
		this.transaction_cancel_date = transaction_cancel_date;
	}

	public void setTransaction_cov_type(String transaction_cov_type) {
		this.transaction_cov_type = transaction_cov_type;
	}

	public void setTransaction_doc_issue_date(Date transaction_doc_issue_date) {
		this.transaction_doc_issue_date = transaction_doc_issue_date;
	}

	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}

	public void setTransaction_loan_no(String transaction_loan_no) {
		this.transaction_loan_no = transaction_loan_no;
	}

	public void setTransaction_mortgagee_name(String transaction_mortgagee_name) {
		this.transaction_mortgagee_name = transaction_mortgagee_name;
	}

	public void setTransaction_policy_no(String transaction_policy_no) {
		this.transaction_policy_no = transaction_policy_no;
	}

	public void setTransaction_policy_reason(String transaction_policy_reason) {
		this.transaction_policy_reason = transaction_policy_reason;
	}

	public void setTransaction_reinstatement_date(Date transaction_reinstatement_date) {
		this.transaction_reinstatement_date = transaction_reinstatement_date;
	}

	public void setTransaction_status(String transaction_status) {
		this.transaction_status = transaction_status;
	}

	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}

	public void setTransactionPolicyDecision(String transactionPolicyDecision) {
		this.transactionPolicyDecision = transactionPolicyDecision;
	}

	public int getPMEDays() {
		return PMEDays;
	}

	public void setPMEDays(int pMEDays) {
		PMEDays = pMEDays;
	}

	public int getREIDays() {
		return REIDays;
	}

	public void setREIDays(int rEIDays) {
		REIDays = rEIDays;
	}

	public double getTransaction_edi_deductible_per() {
		return transaction_edi_deductible_per;
	}

	public void setTransaction_edi_deductible_per(double transaction_edi_deductible_per) {
		this.transaction_edi_deductible_per = transaction_edi_deductible_per;
	}

	public double getTransaction_non_edi_deductible_per() {
		return transaction_non_edi_deductible_per;
	}

	public void setTransaction_non_edi_deductible_per(double transaction_non_edi_deductible_per) {
		this.transaction_non_edi_deductible_per = transaction_non_edi_deductible_per;
	}

	public double getTransaction_deductible_amt() {
		return transaction_deductible_amt;
	}

	public void setTransaction_deductible_amt(double transaction_deductible_amt) {
		this.transaction_deductible_amt = transaction_deductible_amt;
	}

	public double getLoan_escrow_premium_amt() {
		return loan_escrow_premium_amt;
	}

	public void setLoan_escrow_premium_amt(double loan_escrow_premium_amt) {
		this.loan_escrow_premium_amt = loan_escrow_premium_amt;
	}

	public double getLoan_ag_deductible_amt() {
		return loan_ag_deductible_amt;
	}

	public void setLoan_ag_deductible_amt(double loan_ag_deductible_amt) {
		this.loan_ag_deductible_amt = loan_ag_deductible_amt;
	}

	public double getLoan_ag_deductible_pct() {
		return loan_ag_deductible_pct;
	}

	public void setLoan_ag_deductible_pct(double loan_ag_deductible_pct) {
		this.loan_ag_deductible_pct = loan_ag_deductible_pct;
	}

}
