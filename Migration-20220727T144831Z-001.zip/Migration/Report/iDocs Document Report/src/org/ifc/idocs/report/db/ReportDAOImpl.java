package org.ifc.idocs.report.db;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ReportDAOImpl extends DBFactory{

	public static ResultSet getDocumentReport(String reportQuery){
		try {
			idocsProperties.load(inputStream);
			getConnection();
			String query = idocsProperties.getProperty("Document_report1") + reportQuery + idocsProperties.getProperty("Document_report2");
			System.out.println(query);
			PreparedStatement stmt = conn.prepareStatement(query);
			rs = stmt.executeQuery();
		} catch (SQLException e) {
			String message = e.getMessage();
			System.out.println("Please enter a valid extraction criteria present in table " + message);
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return rs;
	}

	public static ResultSet getDocumentDetailReport(String reportQuery){
		try {
			idocsProperties.load(inputStream);
			getConnection();
			String query = idocsProperties.getProperty("Document_detail_report1") + reportQuery + idocsProperties.getProperty("Document_detail_report2");
			System.out.println(query);
			PreparedStatement stmt = conn.prepareStatement(query);
			rs = stmt.executeQuery();
		} catch (SQLException e) {
			String message = e.getMessage();
			System.out.println("Please enter a valid extraction criteria present in table " + message);
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return rs;
	}

	public static ResultSet getSecurityExceptionReport(String str){
		try {
			idocsProperties.load(inputStream);
			getConnection();
			String query = idocsProperties.getProperty("Security_exception_report1");
			query += str;
			query += idocsProperties.getProperty("Security_exception_report2");
			System.out.println(query);
			PreparedStatement stmt = conn.prepareStatement(query);
			rs = stmt.executeQuery();
		} catch (SQLException e) {
			String message = e.getMessage();
			System.out.println("Please enter a valid extraction criteria present in table " + message);
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return rs;
	}

	public static void deleteAllReportRcords(String utilityId){
		try {
			getConnection();
			idocsProperties.load(inputStream);
			
			PreparedStatement stmt = conn.prepareStatement(idocsProperties.getProperty("Delete_report_documents") + utilityId + "'");
			stmt.executeQuery();
			System.out.println("Report Documents records related to " + utilityId + " are deleted");
			stmt.close();

			stmt = conn.prepareStatement(idocsProperties.getProperty("Delete_report_detailed_documents") + utilityId + "'");
			stmt.executeQuery();
			System.out.println("Report Detailed Documents records related to " + utilityId + " are deleted");
			stmt.close();

			stmt = conn.prepareStatement(idocsProperties.getProperty("Delete_report_security_exceptions") + utilityId + "'");
			stmt.executeQuery();
			System.out.println("Report Security Exceptions records related to " + utilityId + " are deleted");
			stmt.close();

			stmt = conn.prepareStatement(idocsProperties.getProperty("Delete_report_utility_map") + utilityId + "'");
			stmt.executeQuery();
			System.out.println("Report Utility Map records related to " + utilityId + " are deleted");
			stmt.close();

			stmt = conn.prepareStatement(idocsProperties.getProperty("Delete_migration_skipped_documents") + utilityId + "'");
			stmt.executeQuery();
			System.out.println("Migration Skipped Documents related to " + utilityId + " are deleted");
			stmt.close();

			conn.commit();
		} catch (SQLException e) {
			String message = e.getMessage();
			System.out.println("Please enter a valid extraction criteria present in table " + message);
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static ArrayList<String> getSkippedDocsCount(String utilityId) {
		ArrayList<String> skipList = new ArrayList<String>();
		try {
			PreparedStatement stmt = conn.prepareStatement("select SKIP_REASON, count(DOCUMENT_UNIQUE_ID) FROM MIGRATION_SKIPPED_DOCUMENTS WHERE UTILITY_CODE='" + utilityId + "' group by SKIP_REASON");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()){
				skipList.add("Skip Reason : " + rs.getString(1) + " | Count of Documents : " + rs.getString(2));
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return skipList;
	}
}
