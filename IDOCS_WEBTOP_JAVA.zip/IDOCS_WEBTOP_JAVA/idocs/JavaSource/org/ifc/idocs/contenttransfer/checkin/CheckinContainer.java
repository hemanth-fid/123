/**
* This component provides the UI for checkin in the document.
* 
* ##############################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* ##############################################################################
* Parag Doshi			11/02/2010		1.0					created
* ##############################################################################
*/
package org.ifc.idocs.contenttransfer.checkin;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;
import org.ifc.idocs.workflow.startworkflow.StartWorkflow;

import com.aspose.words.BookmarkCollection;
import com.aspose.words.CustomDocumentProperties;
import com.aspose.words.Document;
import com.aspose.words.DocumentProperty;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.formext.component.Component;
import com.documentum.web.formext.docbase.ObjectCacheUtil;

public class CheckinContainer extends com.documentum.webcomponent.library.contenttransfer.checkin.CheckinContainer {

    private static final long serialVersionUID = 1L;
    private static boolean m_start_workflow_checkbox = false;
	public static final int MSG_DRAFT_STATE_NUMBER = 0;
	public static final int MSG_RELEASED_STATE_NUMBER=1;
	private static final String MSG_CHECKED_IN = "Checked In";
	private static final String MSG_AS_WORKFLOW_CREATE_CODE = "101";
	private static final String QRY_VARIABLE_TEMPLATECODE = "<templatecode>";
	private static final String BOOKMARK_START_DATE="startDate";
	private static final String BOOKMARK_END_DATE="endDate";
	private static final String BOOKMARK_MEETING_TELECON_INFO="meeting_telecon_info";
    public CheckinContainer(){
    }

    /**
     * Disables the start workflow checkbox when the component is loaded.
     */
    public void onInit(ArgumentList args){
        try{
            DfLogger.info(this, (new StringBuilder(" :: onInit : ")).append(getDfSession().getLoginUserName()).toString(), null, null);
            m_start_workflow_checkbox = false;
            super.onInit(args);
        }catch(DfException e){
            DfLogger.error(this, (new StringBuilder(" :: onInit Exception >> ")).append(e.getMessage()).toString(), null, e);
        }
    }

    /**
     * This method displays the status of the checkin operation to the user.
     */ 
    protected void addFinalSuccessMessage(){
        super.addFinalSuccessMessage();
        Map ids = (Map)getReturnValue("old2newObjectIds");
        Collection newObjectIds = ids.values();
        if(newObjectIds.size() == 1){
            String objectId = (String)newObjectIds.toArray()[0];
            DfLogger.info(this, (new StringBuilder(" :: addFinalSuccessMessage : objectId : ")).append(objectId).toString(), null, null);
            try{
            	ArrayList list = getContainedComponents();
            	Component component = (Component)list.get(0);
            	UcfCheckin ucf_checkin = (UcfCheckin)component;
            	IDfDocument docObject = (IDfDocument)ObjectCacheUtil.getObject(getDfSession(),objectId);

            	/**
            	 * Start Code to Set the AMR Review Name/CESI Client Meeting and Information Review Summary with CRR Language/CESI Site Appraisal Visit (SAV) Findings (Appraisal BTO) 
            	 * as project_filename_startDate to endDate  
            	 */

            	if(docObject != null){
            		String doc_template_code=docObject.getString("template_code");  
            		if(doc_template_code !=null && doc_template_code.trim().length() >0){
            			String templateCodeQryStr = IdocsUtil.getMessage("QRY_TEMPLATE_CODE_INFO");
                    	templateCodeQryStr = templateCodeQryStr.replace(QRY_VARIABLE_TEMPLATECODE, doc_template_code);
                    	String templateTitleValue = null;
                    	IDfCollection templateCollection = null;
                    	try {
                    		templateCollection = IdocsUtil.executeQuery(getDfSession(),templateCodeQryStr,IDfQuery.DF_READ_QUERY);
                    		while(templateCollection.next()){
                    			templateTitleValue =	templateCollection.getString(IDocsConstants.MSG_TEMPLATE_TITLE);
                    		}
                    	} catch (Exception e) {
                    		DfLogger.error(this, "addFinalSuccessMessage : " + e.getMessage(), null, null);
                    	}finally{
                    		if(templateCollection != null)
                    			templateCollection.close();
                    	}
                    	
                    	if(templateTitleValue != null && templateTitleValue.trim().length() > 0) {
                    		if(templateTitleValue.equals(IdocsUtil.getMessage("MSG_AMR_REVIEW_TEMPLATES"))
                    				|| templateTitleValue.equals(IdocsUtil.getMessage("MSG_CESI_CLIENT_MEETING_INFO_SUMMARY_WITH_CRR"))
                    				|| templateTitleValue.equals(IdocsUtil.getMessage("MSG_CESI_SITE_APPRAISAL_VISIT_SAV"))
                    				|| templateTitleValue.equals(IdocsUtil.getMessage("MSG_TEMPLATE_REVISED_MAM_APPROVAL"))){
                    			m_templateName=templateTitleValue;
                			/**
                    			if template name is any one of these three templates  
                    			1. AMR Review
                    			2. CESI Client Meeting and Information Review Summary with CRR Language
                    			3. CESI Site Appraisal Visit (SAV) Findings (Appraisal BTO)
                			*/
                    			String documentName =getDocumentTemplateNameFromObjectName(docObject.getObjectName());//IdocsUtil.getTemplateTitle(getDfSession(), objectId); 
                    			if(documentName.equals(IdocsUtil.getMessage("MSG_AMR_REVIEW_TEMPLATES")) 
                    					|| documentName.equals(IdocsUtil.getMessage("MSG_CESI_CLIENT_MEETING_INFO_SUMMARY_WITH_CRR"))
                    					|| documentName.equals(IdocsUtil.getMessage("MSG_CESI_SITE_APPRAISAL_VISIT_SAV"))){
                    			/**
                    			 * Checking document Name which is having  the book mark values on the document or not 
                    			 */
                    				String newFileName = IDocsConstants.MSG_EMPTY_STRING;
                    				Document document = new Document(docObject.getContent());
                        			String filePostfix = getFileNameFromBookMark(document,m_templateName);
                        			
                        			if(filePostfix != null & filePostfix.trim().length() >0){
                        				DfLogger.info(this, "addFinalSuccessMessage : Document Name updating with book mark fields :  " + filePostfix , null, null);
                        				String prefix=getDocumentProjectOrPartner(docObject.getObjectName().toString());
                        				if(templateTitleValue.equals(IdocsUtil.getMessage("MSG_AMR_REVIEW_TEMPLATES"))){
                        					newFileName= prefix + IdocsConstants.MSG_UNDERSCORE+IdocsUtil.getMessage("MSG_AMR_REVIEW_TEMPLATES")+ filePostfix;
                        					DfLogger.info(this, "onCommitChanges :AMR Review New fileName  :  " + newFileName , null, null);
                        					}else if(templateTitleValue.equals(IdocsUtil.getMessage("MSG_CESI_CLIENT_MEETING_INFO_SUMMARY_WITH_CRR"))){
                        						newFileName= prefix + IdocsConstants.MSG_UNDERSCORE+IdocsUtil.getMessage("CESI_MEETING_INFORMATION_NEW_NAME")+ filePostfix;
                        						DfLogger.info(this, "onCommitChanges :CESI Client Meeting and Information Review Summary with CRR Language  New fileName  :  " + newFileName , null, null);
                        						}else if(templateTitleValue.equals(IdocsUtil.getMessage("MSG_CESI_SITE_APPRAISAL_VISIT_SAV"))){
                        							newFileName= prefix + IdocsConstants.MSG_UNDERSCORE+IdocsUtil.getMessage("CESI_SITE_APPRAISAL_VISIT_NEW_NAME")+ filePostfix;
                        							DfLogger.info(this, "onCommitChanges :CESI Site Appraisal Visit (SAV) Findings (Appraisal BTO) .  New fileName  :  " + newFileName , null, null);
                        							}
                        				docObject.setObjectName(newFileName);
                        				docObject.save();
                        				}
                        			}else if(documentName.equals(IdocsUtil.getMessage("MSG_TEMPLATE_REVISED_MAM_APPROVAL"))){
                        				String GTFPValue=readMAMTemplateCustomValues(docObject);
                        				if(GTFPValue != null && GTFPValue.trim().length() >0){
                        					String prefix=getDocumentProjectOrPartner(docObject.getObjectName().toString());
                        					String newObjectName=prefix + IdocsConstants.MSG_UNDERSCORE+IdocsUtil.getMessage("MSG_TEMPLATE_REVISED_MAM_APPROVAL")+IdocsConstants.MSG_UNDERSCORE+GTFPValue;
                        					
                        					DfLogger.info(this, "addFinalSuccessMessage :: Updating document Name with GTFPValue which is ::"+GTFPValue, null,null);
                        					
                        					docObject.setObjectName(newObjectName);
                        					docObject.save();
                        				}else{
                        					DfLogger.info(this, "addFinalSuccessMessage :: No need to update document name GTFPValue is Empty or Null", null,null);
                        					}
                        				}else {
                        					DfLogger.info(this, "addFinalSuccessMessage :: No need to update document name with bookmark fields  "+documentName, null,null);
                        					}
                    			}else{
                    				DfLogger.info(this, "addFinalSuccessMessage :: template name not in any of the 4 templates templateTitleValue"+templateTitleValue, null,null);
                    				}
                    		}else{
                    			DfLogger.info(this, "addFinalSuccessMessage :: templateTitleValue is empty or null", null,null);
                    			}
                    	}else{
                    		DfLogger.info(this, "addFinalSuccessMessage :: document is not templte doc", null,null);
                    		}
            		}
            	
            	/*
            	 * End Code to Set the Renaming Name as project_filename_startDate to endDate  
            	 */
            	
            	objectId = docObject.getObjectId().getId();
            	if (docObject.getOwnerName().equals(getDfSession().getLoginUserName())) {
            		DfLogger.debug(this, " :: addFinalSuccessMessage :attaching lifecycle using logged in user session: ", null, null);
            		IdocsUtil.attachPolicy(getDfSession(), docObject);
            	} else {
            		DfLogger.debug(this, " :: addFinalSuccessMessage :attaching lifecycle using admin session: ", null, null);
            		IDfSessionManager sessionManager = IdocsUtil.getAdminSessionManager(getDfSession());
            		IDfSession adminSession = sessionManager.getSession(getDfSession().getDocbaseName());
            		IDfDocument adminDocObject = (IDfDocument)adminSession.getObject(new DfId(objectId));
            		DfLogger.debug(this, " :: addFinalSuccessMessage :attaching lifecycle : admin session User: "+adminSession.getLoginUserName(), null, null);
            		IdocsUtil.attachPolicy(adminSession,adminDocObject);
            		if(adminSession !=null){
            			sessionManager.release(adminSession);
            		}
            	}

            	if(ucf_checkin.getExpectedDocumentName() != null || ucf_checkin.getdocSubTypeName() != null){
            		IDfDocument IomdocObject = (IDfDocument)ObjectCacheUtil.getObject(getDfSession(), docObject.getObjectId().getId());
            		if(ucf_checkin.getExpectedDocumentName() != null){
            			IomdocObject.setObjectName(ucf_checkin.getExpectedDocumentName());
            		}
            		if(ucf_checkin.getdocSubTypeName() != null){
	            		IomdocObject.setString(IDocsConstants.MSG_DOC_SUBTYPE_NAME,ucf_checkin.getdocSubTypeName());
	            		IomdocObject.setString(IDocsConstants.MSG_DOC_SUBTYPE_CODE,ucf_checkin.getdocSubTypeCode());
	            		IomdocObject.setTime(IDocsConstants.MSG_DOCUMENT_DATE.toString(),ucf_checkin.getdocmntdate());
						IomdocObject.setString(IDocsConstants.MSG_FOLDER_TITLE,ucf_checkin.getFolderTitle());            		
            		}
            		IomdocObject.save();
            	}
            	docObject = (IDfDocument)ObjectCacheUtil.getObject(getDfSession(), docObject.getObjectId().getId());
            	if(ucf_checkin.getMajorVersionLabel()!=null){                	
            		markCheckinMajorVersionAndSave(docObject,ucf_checkin);
            	} else {
            		if(docObject!=null && IdocsConstants.DOC_STATE_DRAFT.equals(docObject.getString(IDocsConstants.MSG_DOC_STATE)) == false){
            			docObject.setString(IDocsConstants.MSG_DOC_STATE, IdocsConstants.DOC_STATE_DRAFT);
            			docObject.save();
            		}                	
            	}
            	// During checkin process, update product template details in IDOCS Workflow table calling servlet

            	String objectType = docObject.getString(IDocsConstants.MSG_R_OBJECT_TYPE);
            	if(objectType != null && !"".equals(objectType) && objectType.equals(IDocsConstants.MSG_IDOCS_PROJECT_DOC)){
            		String strTemplateName = null;
            		// Template Name retriving from query
            		strTemplateName = IdocsUtil.getTemplateTitle(getDfSession(), docObject.getObjectId().getId());
            		IdocsUtil idocsUtil = new IdocsUtil();
            		int pdtWfTypeCode = idocsUtil.getProductTypeCode(getDfSession(), strTemplateName);
            		String strPdtWfNbr = docObject.getString("product_wf_nbr");
            		if(IdocsUtil.ifProductIntegrationRequired(strTemplateName) && strPdtWfNbr != null && !"".equals(strPdtWfNbr)){
            			String strServletURL = IdocsUtil.buildServletURL(component,getDfSession(), docObject, strPdtWfNbr, String.valueOf(pdtWfTypeCode),getPageContext(),false);
            			IdocsUtil.buildAndExecuteServlet(strServletURL);
            		}

            		/*
            		 * This is code has been added for Advisory Services
            		 * CODE : START
            		 */
            		try {
            			if(IdocsUtil.isAdvisoryTemplate(strTemplateName)){
            				DfLogger.info(this, (new StringBuilder(" :: Advisory Services : Calling Servlet : ")).toString(), null, null);
            				String asServletURL = IdocsUtil.asBuildServletURL(docObject,strTemplateName,getDfSession(),MSG_AS_WORKFLOW_CREATE_CODE);
            				DfLogger.info(this, (new StringBuilder(" ::  Servlet URL :::: ")).append(asServletURL).toString(), null, null);
            				IdocsUtil.buildAndExecuteServlet(asServletURL);
            				DfLogger.info(this, (new StringBuilder(" :: Advisory Services : Servlet Executed  : ")).toString(), null, null);
            			}
            		} catch (Exception e) {
            			DfLogger.error(this, (new StringBuilder(" ::  Exception occured in executing Servlet>> ")).append(e.getMessage()).toString(), null, e);
            		}

            		/*
            		 * CODE : END 
            		 */
            	}

            	IdocsUtil.auditIDocsActivity(MSG_CHECKED_IN,objectId,getDfSession());   
            	DfLogger.info(this, (new StringBuilder(" :: addFinalSuccessMessage : objectId : ")).append(objectId).toString(), null, null);
            	m_start_workflow_checkbox = ucf_checkin.getCheckBoxValue();
            	if(m_start_workflow_checkbox){
            		DfLogger.info(this, " :: addFinalSuccessMessage : m_start_workflow_checkbox is selected", null, null);
            		StartWorkflow startWF = new StartWorkflow();
            		boolean canWorkflowStart = startWF.canStartIDocsWorkFlow(objectId,false,false);
            		if(canWorkflowStart){
            			try{
            				DfLogger.info(this, " :: addFinalSuccessMessage : Calling Workflow Start", null, null);
            				startWF.initiateWF(getDfSession(), objectId);
            				DfLogger.info(this, " :: addFinalSuccessMessage : Workflow Started", null, null);
            			}catch(DfException e){
            				DfLogger.error(this, (new StringBuilder(" :: addFinalSuccessMessage Exception >> ")).append(e.getMessage()).toString(), null, e);
            			}
            		}
            	}
            }catch(DfException e){
                DfLogger.error(this, (new StringBuilder(" :: addFinalSuccessMessage Exception >> ")).append(e.getMessage()).toString(), null, e);
            } catch (Exception e) {
            	DfLogger.error(this, (new StringBuilder(" :: onCommitChanges Exception >> ")).append(e.getMessage()).toString(), null, e);
			}
        }
    }
    

    private String getDocumentProjectOrPartner(String fileName){
    	
    	String  newFileName=IDocsConstants.MSG_EMPTY_STRING;
    	DfLogger.info(this, "getFileTemplateName :To Get The document project or partnert code from the document Name  :  " + fileName , null, null);
		String objectName[]=fileName.split(IdocsConstants.MSG_UNDERSCORE);
		if(objectName != null && objectName.length > 1){
			newFileName = objectName[0];
		}
		return newFileName;
    }
    
    /**
     * 
     */
    
    private String getDocumentTemplateNameFromObjectName(String fileName){
    	
    	String  objectFileName="";
    	DfLogger.info(this, "getFileTemplateName :To Get The Template Name from the document Name  :  " + fileName , null, null);
		String objectName[]=fileName.split(IdocsConstants.MSG_UNDERSCORE);
		if(objectName != null && objectName.length >= 2){
			objectFileName = objectName[1];
		}
		return objectFileName;
    }
    
    /**
     * This method to build the file Name using BookMark fields startDate and endDate.
     * @param  document
     * @throws Exception
     * @return String 
     */
   
    private String getFileNameFromBookMark(Document document, String templateTitleValue)  throws Exception{
    	BookmarkCollection bookmarkCollection=document.getRange().getBookmarks();
    	
    	String filepostfixString=null;
    	String startDate = IDocsConstants.MSG_EMPTY_STRING;
		String endDate = IDocsConstants.MSG_EMPTY_STRING;
		
			if(templateTitleValue.equals(IdocsUtil.getMessage("MSG_AMR_REVIEW_TEMPLATES"))){
				startDate = bookmarkCollection.get(BOOKMARK_START_DATE).getText().substring(13).trim();
				endDate = bookmarkCollection.get(BOOKMARK_END_DATE).getText().substring(13).trim();
				if(endDate != null && startDate != null && startDate.length() >0 && endDate.length() >0){
					filepostfixString = " for period " + startDate+ " to " + endDate;
					DfLogger.info(this, "getFileNameFromBookMark :AMR Review New fileName  :  " + filepostfixString , null, null);
				}
			}else if(templateTitleValue.equals(IdocsUtil.getMessage("MSG_CESI_CLIENT_MEETING_INFO_SUMMARY_WITH_CRR"))){
				String bookMarkTeleconInfo = bookmarkCollection.get(BOOKMARK_MEETING_TELECON_INFO).getText().substring(13).trim();
				if(bookMarkTeleconInfo != null && bookMarkTeleconInfo.length() >0){
					filepostfixString =" "+ bookMarkTeleconInfo;
					DfLogger.info(this, "getFileNameFromBookMark :CESI Client Meeting and Information Review Summary with CRR Language  New fileName  :  " + filepostfixString , null, null);	
				}
			}else if(templateTitleValue.equals(IdocsUtil.getMessage("MSG_CESI_SITE_APPRAISAL_VISIT_SAV"))){
				startDate = bookmarkCollection.get(BOOKMARK_START_DATE).getText().substring(13).trim();
				if(startDate != null && startDate.length() >0){
					filepostfixString=" "+startDate;
					DfLogger.info(this, "getFileNameFromBookMark :CESI Site Appraisal Visit (SAV) Findings (Appraisal BTO) .  New fileName  :  " + filepostfixString , null, null);	
				}
			}
		return filepostfixString;
	}
 /**
  * 
  * @param dfDocument
  */
    private String readMAMTemplateCustomValues(IDfDocument dfDocument){
    	String gtfp_value="";
    	try {
    		Document wordDoc = new Document(dfDocument.getContent());
			CustomDocumentProperties customDocProp = wordDoc.getCustomDocumentProperties(); 
			DocumentProperty GTFP_TYPE=customDocProp.get(PCI_SELECTED_TEMPLATE);
			gtfp_value=GTFP_TYPE.getValue().toString();
			DfLogger.info(this,":Custom Property GTFP_TYPE Value is "+gtfp_value,null,null);
		} catch (DfException e) {
			DfLogger.error(this,"<<Exception>> "+e.getMessage(),null,null);
		} catch (Exception e) {
			DfLogger.error(this,"<<Exception>> "+e.getMessage(),null,null);
		}	
		return gtfp_value; 
    }


    /**
     * 
     * @param newDocument
     * @param checkinComponent
     * @throws DfException
     */
	private void markCheckinMajorVersionAndSave(IDfSysObject newDocument,
			UcfCheckin checkinComponent) throws DfException {
			DfLogger.info(this, " :: markCheckinVersion :: Checkin Version =" + checkinComponent.getMajorVersionLabel(), null, null);
			if(newDocument.getCurrentState() < MSG_RELEASED_STATE_NUMBER){
				newDocument.promote(IDocsConstants.MSG_STATE_RELEASED, false, true);
				newDocument.promote(IDocsConstants.MSG_STATE_RELEASED, false, false);
				DfLogger.info(this, " Double Promote to Released. ", null,null);
			}		
		}

	private String m_templateName="";
	private static final String PCI_SELECTED_TEMPLATE="pciSelectedTemplate";
}
