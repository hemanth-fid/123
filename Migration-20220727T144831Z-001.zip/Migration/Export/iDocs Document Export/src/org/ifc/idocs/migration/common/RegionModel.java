package org.ifc.idocs.migration.common;

public class RegionModel {
	private String extractionUtilityCode;
	private String importUtilityCode;
	private String legacyDocumentId;
	private String rollbackReqdInd;
	private String rollbackSuccessfulInd;
	private String extractionSuccessful;
	private String folderValueCode;
	private String folderTypeCode;
	private String documentumDocId;
	
	public String getExtractionUtilityCode() {
		return extractionUtilityCode;
	}
	public void setExtractionUtilityCode(String extractionUtilityCode) {
		this.extractionUtilityCode = extractionUtilityCode;
	}
	public String getImportUtilityCode() {
		return importUtilityCode;
	}
	public void setImportUtilityCode(String importUtilityCode) {
		this.importUtilityCode = importUtilityCode;
	}
	public String getLegacyDocumentId() {
		return legacyDocumentId;
	}
	public void setLegacyDocumentId(String legacyDocumentId) {
		this.legacyDocumentId = legacyDocumentId;
	}
	public String getRollbackReqdInd() {
		return rollbackReqdInd;
	}
	public void setRollbackReqdInd(String rollbackReqdInd) {
		this.rollbackReqdInd = rollbackReqdInd;
	}
	public String getRollbackSuccessfulInd() {
		return rollbackSuccessfulInd;
	}
	public void setRollbackSuccessfulInd(String rollbackSuccessfulInd) {
		this.rollbackSuccessfulInd = rollbackSuccessfulInd;
	}
	public String getExtractionSuccessful() {
		return extractionSuccessful;
	}
	public void setExtractionSuccessful(String extractionSuccessful) {
		this.extractionSuccessful = extractionSuccessful;
	}
	public String getFolderValueCode() {
		return folderValueCode;
	}
	public void setFolderValueCode(String folderValueCode) {
		this.folderValueCode = folderValueCode;
	}
	public String getFolderTypeCode() {
		return folderTypeCode;
	}
	public void setFolderTypeCode(String folderTypeCode) {
		this.folderTypeCode = folderTypeCode;
	}
	public String getDocumentumDocId() {
		return documentumDocId;
	}
	public void setDocumentumDocId(String documentumDocId) {
		this.documentumDocId = documentumDocId;
	}
}
