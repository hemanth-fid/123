/**
* 
* 
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Parag Doshi			11/14/2010		1.0				created
* #######################################################################################################
*/
package org.ifc.idocs.contenttransfer.importcontent;
		
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.control.docbase.IDocDocbaseAttributeTagUtility;
import org.ifc.idocs.library.actions.LaunchViewComponentWithPermitCheck;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.AcsService;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Form;
import com.documentum.web.form.FormActionReturnListener;
import com.documentum.web.form.control.Checkbox;
import com.documentum.web.form.control.Panel;
import com.documentum.web.form.control.fileselector.FileSelector;
import com.documentum.web.form.control.fileselector.IFile;
import com.documentum.web.formext.component.Prompt;
import com.documentum.web.formext.docbase.VdmUtil;

public class UcfImportContainer extends org.ifc.idocs.contenttransfer.importcontent.ImportContentContainer
{
	private static final long serialVersionUID = 1L;
	private static final String CONTROL_OLE_SCAN_ENABLE = "oleScanEnable";
	private static final String PROMPT_TITLE_MSG = "Import Document";
	
    public UcfImportContainer()
    {
    }

    /**
     * Enables the OLE Scan WDK controls.
     */
    public void onInit(ArgumentList args){
    	ArgumentList importComponentArguments = null;
    	String srgComponentArgs[] = args.getValues("componentArgs");
//    	System.out.println("Arguments :" + args);
    	for (int i=0; i < srgComponentArgs.length; i++)
    	{
    		String strEncodedArgs = srgComponentArgs[i];
//    		System.out.println("strEncodedArgs 1:" + strEncodedArgs);
    		importComponentArguments = ArgumentList.decode(strEncodedArgs);
    	}
    	String strObjectType = null;
    	if(importComponentArguments != null && importComponentArguments.isEmpty() == false){
    		strObjectType = importComponentArguments.get("type"); 
    	}
    	
    	String strObjectId = args.get("objectId");
		if(strObjectType != null && strObjectType.equalsIgnoreCase(IDocsConstants.MSG_IDOCS_PROJ_FOLDER)){
			String projectId = IDocDocbaseAttributeTagUtility.getSingleAttributeValue(getDfSession(),
					strObjectId,IdocsConstants.PROJ_ID,strObjectType);
			if(IdocsUtil.isUserPresentInConflictOfInterest(projectId,getDfSession()) || IdocsUtil.isUserMemberofLDAPGroup(
					 IdocsUtil.getMessage(IdocsConstants.CONFLICT_OF_INTEREST_ROLE), projectId, getDfSession())){
				DfLogger.info(LaunchViewComponentWithPermitCheck.class,"::validateUserPermissionsForView  User is Present in Conflict Of Interest:", null, null);
				ArgumentList promptArguments = new ArgumentList();
       		 	promptArguments.add(Prompt.ARG_TITLE, PROMPT_TITLE_MSG);
       		 	promptArguments.add(Prompt.ARG_MESSAGE, IdocsUtil.getMessage("COI_ROLE_IMPORT_ERROR_MESSAGE"));
    			promptArguments.add(Prompt.ARG_BUTTON, new String[]{Prompt.CANCEL});
    			setComponentNested(IDocsConstants.MSG_IDOCS_PROMPT_COMPONENT, promptArguments, getContext(),
    					new FormActionReturnListener(this, "onReturnFromPromptInput"));
			}else{
				DfLogger.warn(this, "User is not part of COI", null, null);
				super.onInit(args);
			}	
		}else{
			DfLogger.warn(this, "This is not an Project Folder.", null, null);
			super.onInit(args);
		}    
		initOkButtonControl();
        initOLEScanPanel();
    }
    
    public void onReturnFromPromptInput(Form form, Map map){
    	setComponentReturn();
    }
    
    /**
     * This methods uploads the files selcted by the user.
     */
	protected Collection getUploadedFilesFromRequest(){
        Set files = new HashSet();
        FileSelector fselector = getFileselectorControl(false);
        if(fselector != null){
            IFile ifiles[] = fselector.getSelectedFiles();
            if(ifiles != null){
                for(int i = 0; i < ifiles.length; i++){
                    IFile ifile = ifiles[i];
                    if(ifile != null){
                        addFile(files, ifile, null);
                    }
                }
            }
        }
        return files;
    }

	/**
	 * This helps the user to add multiple files for import
	 * @param files - List of files from the file system.
	 * @param file - File instance if the selected object is directory.
	 * @param parent - Parent folder object of the selected file
	 */
	private void addFile(Set files, IFile file, IFile parent){
        ImportContentContainer.ImportFile importFile = new ImportContentContainer.ImportFile(null, file.getPath(), null, parent == null ? null : parent.getPath(), file.isDirectory());
        files.add(importFile);
        IFile children[] = file.listFiles();
        if(children != null){
            for(int i = 0; i < children.length; i++){
                addFile(files, children[i], file);
            }
        }
    }

	/**
	 * Displays file selector control to the user for selecting the files
	 * to be imported from local file system
	 * @param create
	 * @return
	 */
    protected FileSelector getFileselectorControl(boolean create){
        return (FileSelector)(create ? getControl("fileselector", FileSelector.class) : getControl("fileselector"));
    }

    /**
     * Selects the BOCS option.
     */
    private void initOkButtonControl(){
        AcsService acsService = AcsService.getInstance();
        if(acsService.canOverrideDefaultBocsWriteMode()){
            getOkButtonControl(true).setEnabled(false);
        }
    }

    /**
     * Enables the OLEScan control panel
     */
    protected void initOLEScanPanel(){
        boolean bOLEScanSupported = VdmUtil.isOLEScanSupported();
        if(!bOLEScanSupported){
            getControl("oleScanPanel", Panel.class).setVisible(false);
        }else {
            Checkbox chkOLEScan = (Checkbox)getControl("oleScanEnable", Checkbox.class);
            chkOLEScan.setValue(VdmUtil.getOLEScanPreference());
        }
    }

    /**
     * This gets the OLE Enable request.
     */
    protected boolean getOLEScanEnableFromRequest() {
        boolean bOLEScanEnable = false;
        Checkbox chkOLEScan = (Checkbox)getControl("oleScanEnable");
        if(chkOLEScan != null) {
            bOLEScanEnable = chkOLEScan.getValue();
        }
        return bOLEScanEnable;
    }
}
