package org.ifc.idocs.forms.adaptors;

import com.documentum.fc.common.DfLogger;
import com.documentum.tools.adaptor.AdaptorException;
import com.documentum.tools.adaptor.IAdaptorParameter;
import com.documentum.tools.adaptor.configuration.IAdaptorConfiguration;
import com.documentum.xforms.engine.adaptor.datasource.ISetValueAdaptor;

public class SetIsValidationRequiredToNo
    implements ISetValueAdaptor
{

    public SetIsValidationRequiredToNo()
    {
    }

    public Object execute(IAdaptorParameter parameters[])
        throws AdaptorException
    {
        DfLogger.info(this,"SetIsValidationRequiredtoNull:: SetIsValidationRequiredtoNull",null,null); 
        String validationRequired = "no";
        return validationRequired;
    }

    public void destroy()
        throws AdaptorException
    {
    }

    public void init(IAdaptorConfiguration iadaptorconfiguration)
        throws AdaptorException
    {
    }
}
