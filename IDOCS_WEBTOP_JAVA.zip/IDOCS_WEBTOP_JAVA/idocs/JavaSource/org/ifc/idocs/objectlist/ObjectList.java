/**
* This class returns the DQL Query which will be used to fetch the client company/project folders.
* #######################################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* #######################################################################################################
* Leela Venkata Sudhakar    18/12/2012	     1.0            Created
* Leela Venkata Sudhakar    01/29/2013	     1.0.1          Modified(Included EMC Suggestions)
* Leela Venkata Sudhakar    02/08/2013	     1.0.2          Modified(Included Conflict of interest validation)
* #######################################################################################################
*/
package org.ifc.idocs.objectlist;



import javax.servlet.http.HttpServletRequest;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.create.CreateNewDoc;
import org.ifc.idocs.queryservices.DocTypeTableStructure;
import org.ifc.idocs.queryservices.IDocsQRYVO;
import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfTime;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.Button;
import com.documentum.web.form.control.Radio;
import com.documentum.web.form.control.Text;
import com.documentum.web.form.control.databound.DataDropDownList;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.form.control.databound.TableResultSet;
import com.documentum.web.formext.action.ActionService;
import com.documentum.web.formext.config.Context;
import com.documentum.web.formext.control.action.ActionControl;
import com.documentum.web.formext.docbase.ObjectCacheUtil;
import com.documentum.web.formext.session.DocbaseUtils;
import com.documentum.webcomponent.common.WebComponentErrorService;
import com.documentum.webcomponent.navigation.doclist.DocList;
import com.documentum.webcomponent.navigation.doclist.DocbaseQueryService;

/**
 * @author Leela Venkata Sudhakar
 * 
 */

 public class ObjectList extends com.documentum.webtop.webcomponent.objectlist.ObjectList{ 

	 public static final String ENTER_CATALOG_SEARCH_CRITERIA = "Enter Catalog Search Criteria";
	 public String folder_category="";
	 private boolean isNonOfficialTemplate=false;

	 private static final long serialVersionUID = 1L;

	 public boolean validProjFolderFlag = false;
	 public boolean validInstitFolderFlag = false;	
	 private String strFolderPath = null;
	 private String strContextFolderId = null;
	 private String strOriginalQuery = null;
	 public boolean isEligibleFolder = false;
	 
	 private String STR_DM_QUERY_E_CURSOR_ERROR="DM_QUERY_E_CURSOR_ERROR";
	 private String DM_POLICY_E_ERROR="DM_POLICY_E_ERROR_1800";
	 
	 public static String CALLER_COMPONENT="createnewdoc";
	 
	 private static final String FILESAND_FOLDER_FILTER="0";
	 private static final String TEMPLATE_FILTER="1";
	 private static final String EMAIL_FILTER="2";
	 private static final String SCAN_FILTER="3";
	 private static final String IMPORTED_FILTER="4";
	 private String STR_FILTER_STATUS="0";
	 private static final String STR_ROLE_ALL="All";
	 private static final String STR_ROLE_NONE="None";
	 private static final String STR_ALL_DOCUMENTS="alldocuments";
	 private static final String STR_TEMP_DOCUMENTS="templatedocuments";
	 private static final String STR_EMAIL_DOCUMENTS="emaildocs";
	 private static final String STR_SCAN_DOCUMENTS="scanneddocs";
	 private static final String STR_IMPORTED_DOCS="imported";
	 private static final String STR_EMAIL="EMAIL";
	 private static final String STR_ALL_DOC="ALL";
	 private static final String STR_SCAN="SCAN";
	 private static final String STR_IMPORTED="IMPORTED";  
	 private static final String STR_TEMPLATE="TEMPLATE";
	 private static final String TampleteDefultInput="Select Template Name";
	 
	 private String MSG_OBJECT_TYPE="";
	 private String errorMessage="";

	 public static final String CONTROL_FULLTEXT_INPU_BOX="fullTextSearch"; 
	 private static final String STR_FOLDERPATH_ARGS = "folderPath";
	 private static final String STR_FOLDERIDS_ARGS = "folderIds";
	 private static final String NULL_OBJECT_ID = "0000000000000000";
	 private static final String MSG_SUB_FOLDER_LIST = "subfolderLst";
	 private static final String MSG_SUB_TYPE_LIST = "subtypeLst";
	 private static final String MSG_TEMPLATE_NAME="templateName";
	 private static final String MSG_BUTTON_CREATE="createdoc";
	 public  static boolean drlStatus=false;
	 
	 private IDfFolder dfFolder=null;
	 private String prevFolderCategory="";
	 private String prevDocType="";
	 private String strTemplateName="";
	 private String findByIDQuery=null;
	 private String MSG_FOLDER_SECURITY=null;
	 private String MSG_FOLDER_SECURITY_CODE=null;

	 private boolean columnPreferencesStatus=false;
	 private boolean searchService=false;
	 private boolean beginsWith=false;
	 
	 private static final String STR_ERROR_MESSAGES="error_messages";
	 private static final String STR_TEMPLATE_NAME_FROM_PROMPTED_TEXT="templateNameFromPromptText";
	 private static final String MSG_ERROR_MESSAGE="error_messages";
	 private static final String MSG_ROLE="role";
	 private static final String STR_SUBFOLDER_TITLE="subfolder_title";
	 
	/**
	 * @return void 
	 * @param args
	 */
	
	public void onInit(ArgumentList args){
		try {
			super.onInit(args);
			strFolderPath = args.get(STR_FOLDERPATH_ARGS);
			String strIdList = args.get(STR_FOLDERIDS_ARGS);
			if (strIdList != null && !(strIdList.length()==0)&& !strIdList.equals(NULL_OBJECT_ID) ) {
				strContextFolderId = strIdList.substring(strIdList.lastIndexOf(".") + 1);
				dfFolder=(IDfFolder)ObjectCacheUtil.getObject(getDfSession(), strContextFolderId);
			} else {
				if(strFolderPath != null && !(strFolderPath.length() == 0) && !(strFolderPath.equals(IDocsConstants.STR_CABINETS_PATH))){
					dfFolder=(IDfFolder) getDfSession().getFolderByPath(strFolderPath);
					if((dfFolder != null) && !(dfFolder.getObjectId().getId().equals(NULL_OBJECT_ID))){
						strContextFolderId = dfFolder.getObjectId().toString();
						DfLogger.info(this," current context Folder ID :"+strContextFolderId,null,null);
					}else{
						DfLogger.info(this," folderObject is Null is NULL OBJECT ID ",null,null);  
					}
				}else{
					DfLogger.info(this," strFolderPath is Empty ",null,null);  
				}
			}
			if(strFolderPath == null || strFolderPath.equals(IDocsConstants.STR_CABINETS_PATH)){
				isEligibleFolder = false;
			}else{
				isEligibleFolder = isEligibleFolder();	
			}
			if (isEligibleFolder) {
				// To Set the Custom Query to Datagrid
				setCustomDataGridQuery();
				((Datagrid) getControl(DocList.CONTROL_GRID,com.documentum.web.form.control.databound.Datagrid.class)).getDataProvider().setQuery(strOriginalQuery,findByIDQuery);
				getFolderCategoryFromFolder();
				// populate subFolder dropdown list
				populateSubFolderList();
				// initialise subtype dropdown list
				initSubTypeList();
				// Populating Template Names 
				populateTemplateList();
				//To Set the dropdown values to defalut
				setDropDownValuesToDefault();
			}
		} catch(Exception e) {
			DfLogger.error(this, " :: onInit Exception >> "+e.getMessage(), null, e);
		}
	}

	
	/**
	 * NOTE: Suggested by Suvig Boyed, EMC 
	 */
	
	private void setCustomDataGridQuery() {
	    String attrList[] = buildVisibleAttributeList();
		strOriginalQuery= DocbaseQueryService.buildObjectListQuery(m_strFolderId, attrList, false, m_bShowFiles, "idocs_document", m_bShowAllVersions);
		strOriginalQuery=strOriginalQuery.replace("2,upper(object_name)","content_modify_date,upper(object_name)");
		strOriginalQuery=strOriginalQuery.replace(" order by 1,2,", " order by 1 DESC,2,");
		findByIDQuery = DocbaseQueryService.buildObjectListFindByIDQuery(m_strFolderId, attrList, false, m_bShowFiles, "idocs_document", m_bShowAllVersions);
		findByIDQuery=findByIDQuery.replace("2,upper(object_name)","content_modify_date,upper(object_name)");
	}  
	
	
	/**
	 * To Populate the subfolder dropdown List values 
	 */

	public void populateSubFolderList() {
		String folderCategory=getFolderCategory();
		DataDropDownList subfolderLst = (DataDropDownList) getControl(MSG_SUB_FOLDER_LIST,DataDropDownList.class);
		boolean resultSetNotFoundStatus=true;
		TableResultSet subFolderTypeResultSet =null;
		DocTypeTableStructure docTypeTableStructure = new DocTypeTableStructure(IDocsQRYVO.getTemplateInfoTableData(getDfSession()));
		String [] attributeList={STR_SUBFOLDER_TITLE};
		try {
			subFolderTypeResultSet=docTypeTableStructure.getTableResultSetColumnWithWhereClausesWithDistinct(attributeList, "folder_category", folderCategory,STR_SUBFOLDER_TITLE);
			if(subFolderTypeResultSet!= null ){
				subFolderTypeResultSet.sort(STR_SUBFOLDER_TITLE,Datagrid.SORTDIR_FORWARD,Datagrid.SORTMODE_TEXT);
				subfolderLst.getDataProvider().setDfSession(getDfSession());
				subfolderLst.getDataProvider().setScrollableResultSet(subFolderTypeResultSet);
				resultSetNotFoundStatus=false;
			}else{
				resultSetNotFoundStatus=true;
			}
		} catch (Exception e) {
			DfLogger.debug(this,"<<Exceptioin Occured>>"+e.getMessage(), null, null);
		}finally{
			if(resultSetNotFoundStatus){
				String strquery = IdocsUtil.getMessage("SUB_FOLDER_QRY");
				strquery=strquery.replace("folderCategory", folderCategory);
				DfLogger.debug(this,"SubFolder Query" + strquery,null,null);
				subfolderLst.getDataProvider().setDfSession(getDfSession());
				subfolderLst.getDataProvider().setScrollableResultSet(getTemplateTableResultSet(strquery,"subfolder"));	
			}else{
				//don't care entered into this block means already values are existed 
			}	
		}
	}
	
	private void initSubTypeList() {
		DataDropDownList subtypeLst = (DataDropDownList) getControl(MSG_SUB_TYPE_LIST,DataDropDownList.class);
		subtypeLst.getDataProvider().setDfSession(getDfSession());
	}
	
	/**
	 * 
	 */
	public void populateTemplateList(){
		String folder_category=getFolderCategory();
		DataDropDownList templateNames = (DataDropDownList) getControl(MSG_TEMPLATE_NAME,DataDropDownList.class);
		templateNames.setEnabled(true);
		templateNames.getDataProvider().setDfSession(getDfSession());
		TableResultSet subTemplateListResultSet;
		boolean resultSetNotFoundStatus=true;
		try {
			subTemplateListResultSet = IDocsQRYVO.getTemplateNamesResultSet(folder_category,getDfSession());
			if(subTemplateListResultSet!= null ){
				templateNames.getDataProvider().setDfSession(getDfSession());
				templateNames.getDataProvider().setScrollableResultSet(subTemplateListResultSet);
				resultSetNotFoundStatus=false;
			}else{
				DfLogger.debug(this,"Failed to get Values From  QueryServices:: ",null,null);
				resultSetNotFoundStatus=true;
			}
		} catch (Exception e) {
			DfLogger.error (this,"<<Exception Occured >> :: ",null,null);
		}finally{
			if(resultSetNotFoundStatus){
				if((folder_category.length()>0)){
					StringBuilder tempalteQueryBuilder=new StringBuilder();
					tempalteQueryBuilder.append(IdocsUtil.getMessage("TEMPLATE_NAME_QUERY").replace("''", ("'"+folder_category+"'")));
					templateNames.getDataProvider().setScrollableResultSet(getTemplateTableResultSet(tempalteQueryBuilder.toString(),"template"));
				}	
			}else{
				//don't care entered into this block means already values are existed 
			}
		}
	}
	
	/**
     * 
     * @param control
     * @param args
     */
	public void onSelectSubFolder(Control control, ArgumentList args) {
		String subFolderTitle = null;
		subFolderTitle = ((DataDropDownList) getControl(MSG_SUB_FOLDER_LIST,DataDropDownList.class)).getValue();
		String strQuery = null;
		if (subFolderTitle.equals("ALL")) {
			DfLogger.debug(this, " :: onSelectSubFolder>>> subfolderValue ALL ",null,null);
			DataDropDownList subTypeList = ((DataDropDownList) getControl(MSG_SUB_TYPE_LIST,DataDropDownList.class));
			if(subTypeList != null)
			subTypeList.setEnabled(false);
			prevFolderCategory=subFolderTitle;
			prevDocType="";
		}else {
			DfLogger.info(this, " :: onSelectSubFolder>>> in side else part :: ",null,null);
			prevFolderCategory=subFolderTitle;
			DataDropDownList subTypeList = ((DataDropDownList) getControl(MSG_SUB_TYPE_LIST,DataDropDownList.class));
			if(subTypeList != null){
				subTypeList.setEnabled(true);
				if(subTypeList.getValue().trim().length() > 0){
					DfLogger.debug(this,"subTypeList not null " + strQuery,null,null);
					prevDocType=subTypeList.getValue();
					}
				}else{
					DfLogger.info(this, " :: onSelectSubFolder>>> doc sub Value is null",null,null);
				}
			DfLogger.info(this, " :: onSelectSubFolder>>> populating SubFolderTitle list :: with  "+subFolderTitle,null,null);
			populateSubTypeList(subFolderTitle);
		}
		buildQueryWithFilters();
	}
	
	 /**
	  * 
	  * @param radio
	  * @param args
	  */
	
	public void onSelectFilterRadio(Radio radio, ArgumentList args){
		radio.setFocus();
		DfLogger.info(this,"onSelectFilterRadio  filter Name" + (radio.getName().trim()),null,null);
		if((radio.getName().trim()).equals((STR_TEMP_DOCUMENTS).trim())){
			STR_FILTER_STATUS=TEMPLATE_FILTER;
			}else if((radio.getName().trim()).equals((STR_EMAIL_DOCUMENTS).trim())){
				STR_FILTER_STATUS=EMAIL_FILTER;
				}else if((radio.getName().trim()).equals((STR_SCAN_DOCUMENTS).trim())){
					STR_FILTER_STATUS=SCAN_FILTER;
					}else if((radio.getName().trim()).equals((STR_ALL_DOCUMENTS).trim())){
						STR_FILTER_STATUS=FILESAND_FOLDER_FILTER;
						}else if((radio.getName().trim()).equals((STR_IMPORTED_DOCS).trim())){
							STR_FILTER_STATUS=IMPORTED_FILTER;
							}
		buildQueryWithFilters();
		DfLogger.debug(this,"onSelectFilterRadio ::  Query filter Status:: " + STR_FILTER_STATUS,null,null);
	 }
	
	/**
	 * 
	 * @param control
	 * @param args
	 */
	public void onSelectSubType(Control control, ArgumentList args) {
		
		String subFolderTitle = null;
		subFolderTitle = ((DataDropDownList) getControl(MSG_SUB_FOLDER_LIST,DataDropDownList.class)).getValue();
		String strQuery = null;
		if (subFolderTitle.equals("ALL")) {
			DfLogger.debug(this, " :: onSelectSubFolder>>> subfolderValue ALL",null,null);
			DataDropDownList subTypeList = ((DataDropDownList) getControl(MSG_SUB_TYPE_LIST,DataDropDownList.class));
			if(subTypeList != null)
			subTypeList.setEnabled(false);
			prevFolderCategory=subFolderTitle;
			prevDocType="";
		}else {
			DfLogger.info(this, " :: onSelectSubFolder>>> in side else part :: ",null,null);
			prevFolderCategory=subFolderTitle;
			DataDropDownList subTypeList = ((DataDropDownList) getControl(MSG_SUB_TYPE_LIST,DataDropDownList.class));
			if(subTypeList != null){
				subTypeList.setEnabled(true);
				if(subTypeList.getValue().trim().length() > 0){
					DfLogger.debug(this,"subTypeList not null " + strQuery,null,null);
					prevDocType=subTypeList.getValue();
					}
				}else{
					DfLogger.info(this, " :: onSelectSubFolder>>> doc sub Value is null",null,null);
				}
			DfLogger.info(this, " :: onSelectSubFolder>>> populating SubFolderTitle list :: with  "+subFolderTitle,null,null);
			populateSubTypeList(subFolderTitle);
		}
		buildQueryWithFilters();
		}

    public void onRender(){
    	try {
    		super.onRender();
    		if(isEligibleFolder){
    			if(columnPreferencesStatus){
    				buildQueryWithFilters();
    				columnPreferencesStatus=false;
    			}
    			// if the SUBFOLDER selection is ALL
    			if (prevFolderCategory != null && prevFolderCategory. trim().length() >0 &&  prevFolderCategory.equals("ALL")) {
    				setDropDownValuesToDefault();
    			}
    			if (prevFolderCategory != null && prevFolderCategory. trim().length() >0 &&  !prevFolderCategory.equals("ALL")) {
    				((DataDropDownList) getControl(MSG_SUB_FOLDER_LIST,DataDropDownList.class)).setValue(prevFolderCategory);
    				if(prevDocType != null && prevDocType.trim().length() >0)
    					((DataDropDownList) getControl(MSG_SUB_TYPE_LIST,DataDropDownList.class)).setValue(prevDocType);
    				else ((DataDropDownList) getControl(MSG_SUB_TYPE_LIST,DataDropDownList.class)).setEnabled(true);
    			}
    		}
    	} catch(Exception e) {
    		DfLogger.error(this, " :: onRender Exception >> "+e.getMessage(), null, e);
    	}
	   }
	
	private void setDropDownValuesToDefault(){
			((DataDropDownList) getControl(MSG_SUB_FOLDER_LIST,DataDropDownList.class)).setValue("ALL");
			DataDropDownList subtype=((DataDropDownList) getControl(MSG_SUB_TYPE_LIST,DataDropDownList.class));
			subtype.setEnabled((false));
			subtype.setValue("");
		}
	
	@Override
	public void onClickColumnsPrefs(Control control, ArgumentList args) {
		super.onClickColumnsPrefs(control, args);
		columnPreferencesStatus=true;
	}

	/**
	 * purpose : to get the idocs_folder folder_category attribute value 
	 * @return folder_category
	 */
	
	public void getFolderCategoryFromFolder(){
		String folder_category="";
		try {
			if(dfFolder != null && !dfFolder.getObjectId().getId().equals(IDocsConstants.BLANK_OBJECT_ID)){
				if(dfFolder.hasAttr("folder_category")){
					setFolderCategory(dfFolder.getString("folder_category"));
					DfLogger.info(this,"getFolderCategoryFromFolder  :: Folder Object folder_category :: "+folder_category,null,null);
					}else{
						setFolderCategory("");
						DfLogger.info(this,"getFolderCategoryFromFolder  :: Attribute not existed with name folder_category ",null,null);
					}
				}else {
					setFolderCategory("");
					DfLogger.info(this,"getFolderCategoryFromFolder  :: Folder Object is Null Object",null,null);
				}
			} catch (DfException e) {
				DfLogger.error(this,"getFolderCategoryFromFolder  :: failed to get folder_category value ::" + e.getMessage(),null,null);
			}
	}
	
	public String getTemplateName(){
	 return strTemplateName;
	}
	
	public void onRefreshButtonEvent(Control radio, ArgumentList args){
		 DfLogger.info(this,"onRefreshButton :: Component refreshed",null,null);
	     onRefreshData();
	 } 
		
	
	 /**
	  * Purpose is to provide full text results with in the selected filter 
	  * @param Text
	  * @param args
	  */
	public void onSelectFullText(Control Text, ArgumentList args){
	 Text beginsWith=(Text)getControl(CONTROL_FULLTEXT_INPU_BOX,Text.class);
	 try {
		searchService=false;
		DfLogger.info(this,"Value in side the begins with tag ::::" +beginsWith.getValue(),null,null);
		if(beginsWith.getValue() != null){
			String searchKey = beginsWith.getValue();
			if(searchKey!=null && searchKey.trim().length()> 0 
					&& ENTER_CATALOG_SEARCH_CRITERIA.equals(searchKey) == false){
				searchService=true;
				}else {
					DfLogger.debug(this,"onSelectFullText   :: no SearchString displaying old document ",null,null);
					}
			}else{
				DfLogger.debug(this,"onSelectFullText   :: no SearchString displaying old document ",null,null);
				}
		buildQueryWithFilters();
		}catch (Exception e) {
		DfLogger.error(this, e.getMessage(), null, e);
	}
   }
	
	
	public void onCatalogSearchResultsClear(Control Text, ArgumentList args){
		 DfLogger.debug(this,"onCatalogSearchResultsClear() :: " , null, null);
		 buildQueryWithFilters();
	}	 
	 /**
	  * Purpose is to provide ObjectName Contains results with in the selected filter 
	  * @param Text
	  * @param args
	  */
     public void getStartWith(Control Text, ArgumentList args){
    	Text startsWithText =(Text)getControl(CONTROL_FULLTEXT_INPU_BOX,Text.class);
  	    String startsWithTextValue=startsWithText.getValue();
  	    DfLogger.info(this,"Value in side the full text search text box with tag ::::" +startsWithTextValue,null,null);
		if(startsWithTextValue != null &&
				startsWithTextValue.trim().length() > 0){
			 beginsWith=true;
		}
		buildQueryWithFilters();
     }
     
     @Override
     public void onaction(ActionControl actionControl, ArgumentList args) {
    	 IDfCollection dfCollection=null;
    	 try {
    		 if(actionControl != null){
    			 /** Check for selectTemplate button related action component or not */
        		 if(actionControl.getName() != null && actionControl.getName().equalsIgnoreCase("selectTemplate")){
        			 DfLogger.debug(this,"onaction() :: New Doc Creation action :: true " ,null,null);
        			 DataDropDownList templateName=(DataDropDownList) getControl(MSG_TEMPLATE_NAME,DataDropDownList.class);
    			     String templateNameFromPromptText=templateName.getValue();
    				 String templateList = IdocsUtil.getMessage("STR_TEMPALATE_RESTRICTED_LIST");
    			/** if dropdown value is "Select Template Name"  throwing a error message */ 
    				 if(!(templateNameFromPromptText.trim().equalsIgnoreCase(TampleteDefultInput.trim()))){
    					 if(IdocsUtil.isUserPresentInConflictOfInterest(dfFolder.getString(IdocsConstants.PROJ_ID),getDfSession()) ||
        						 IdocsUtil.isUserMemberofLDAPGroup(IdocsUtil.getMessage(IdocsConstants.CONFLICT_OF_INTEREST_ROLE), dfFolder.getString(IdocsConstants.PROJ_ID), getDfSession())){
        	        		DfLogger.info(this," :: onaction:: User is Present in Conflict Of Interest", null, null);
        	        		Object params1[] = new Object[1];             
    						params1[0] = DocbaseUtils.getValidationExceptionMsg(new DfException("User is Present in Conflict Of Interest"));			            	   	
    						WebComponentErrorService.getService().setNonFatalError(this, "MSG_VALIDATION_ERROR", params1, null);
        	        	}else{
        	        		
    					 DfLogger.debug(this,"onaction() :: New Doc Creation action :: temaplateName  (templateNameFromPromptText.trim().equalsIgnoreCase(TampleteDefultInput.trim())) " ,null,null);
    					 strTemplateName=templateNameFromPromptText;
    			/** Check for template which we can not create through with a single click  */
    				 if(IdocsUtil.checkIfTokenPresent(templateList, templateNameFromPromptText, ",")){
    					 DfLogger.debug(this,"onaction() :: New Doc Creation action :: "+templateNameFromPromptText+" existed in Lite restricted template" ,null,null);
    				 boolean productTemplate=false;
    				 
    				 if(IdocsUtil.ifProductIntegrationRequired(strTemplateName)){
    					 DfLogger.debug(this,"onaction() :: New Doc Creation :: "+strTemplateName+" is a product workflow template" ,null,null);
            			 String templateType = null;
            			 if (strTemplateName.equals(IdocsUtil.getMessage("MSG_TEMPLATE_REVISED_MAM_APPROVAL"))) {
            				 templateType = IDocsConstants.MSG_TYPE_PRODUCT;
            				 DfLogger.debug(this,"onaction() :: New Doc Creation :: templateType ==>  "+templateType+" " ,null,null);
            				 productTemplate=true;
            			 } else if (strTemplateName.equals(IdocsUtil.getMessage("MSG_TEMPLATE_PDS_COMMITMENT"))) {
            				 templateType = IDocsConstants.MSG_TYPE_COMMITMENT;
            				 DfLogger.debug(this,"onaction() :: New Doc Creation :: templateType ==>  "+templateType+" " ,null,null);
            				 productTemplate=true;
            			 } else if (strTemplateName.equals(IdocsUtil.getMessage("MSG_TEMPLATE_PDS_FIRST_DISBURSEMENT")) ||
            					 strTemplateName.equals(IdocsUtil.getMessage("MSG_TEMPLATE_PDS_SUBSEQ_DISBURSEMENT"))){
            				 templateType = IDocsConstants.MSG_TYPE_DISBURSEMENT;
            				 DfLogger.debug(this,"onaction() :: New Doc Creation :: templateType ==>  "+templateType+" " ,null,null);
            				 productTemplate=true;
            			 } else if (strTemplateName.equals(IdocsUtil.getMessage("MSG_TEMPLATE_CANCELLATION_MEMO")) ||
            					 strTemplateName.equals(IdocsUtil.getMessage("MSG_TEMPLATE_COMMITMENT_TRANSFER_MEMO")) ||
            					 strTemplateName.equals(IdocsUtil.getMessage("MSG_TEMPLATE_DROPPAGE_MEMO"))) {
            				 templateType = IDocsConstants.MSG_TYPE_ADJUSTMENT;
            				 DfLogger.debug(this,"onaction() :: New Doc Creation :: templateType ==>  "+templateType+" " ,null,null);
            				 productTemplate=true;
            			 } else if (strTemplateName.equals(IdocsUtil.getMessage("MSG_TEMPLATE_PDS_SIGNING"))){
            				 templateType = IDocsConstants.MSG_EMPTY_STRING;
            				 DfLogger.debug(this,"onaction() :: New Doc Creation :: templateType ==>  "+templateType+" " ,null,null);
            				 productTemplate=true;
            			 } else {
            				 productTemplate=false;
            				 DfLogger.debug(this, " :: onaction : Not a Product template: ", null, null);
            			 }
            			 
            			 Object params[] = new Object[1]; 
    					 params[0] = DocbaseUtils.getValidationExceptionMsg(new DfException(templateType));
     		           	 WebComponentErrorService.getService().setNonFatalError(this, "MSG_RESTRICT_PRODUCT_TEMPLATE_CREATION", params, null);
    				 	}
    				 
    				 if(!productTemplate ){
    					 String childList = IdocsUtil.getMessage("MSG_PDT_INTEGRATION_CHILDWORKFLOW_TEMPLATES");
    					 /** Check for template which we can not create through IFCDocs system (child workflow templates) */
    					 if(IdocsUtil.checkIfTokenPresent(childList, templateNameFromPromptText, IdocsConstants.MSG_Q_COMMA_Q)){
    						 DfLogger.debug(this,"onaction() :: New Doc Creation :: "+templateNameFromPromptText+" is Child Work flow template" ,null,null);
    						 String errorMessage="";
    						 StringBuilder childWorkflowErrorMessageQuery=new StringBuilder();
    						 //QRY_TEMPLATE_INFO role, error_messages
    						 childWorkflowErrorMessageQuery.append("select error_messages from dm_dbo.IDOCS_TEMPLATE_INFO where template_title ='"+templateNameFromPromptText+"'");
    						 dfCollection = IdocsUtil.executeQuery(getDfSession(), childWorkflowErrorMessageQuery.toString(),IDfQuery.DF_CACHE_QUERY);
    						 if(null!=dfCollection){
    							 while (dfCollection.next()){
    								 errorMessage = dfCollection.getString(STR_ERROR_MESSAGES);
    							 }
    						 }
    						 if(errorMessage != null && errorMessage.length() >0){
    							 Object params1[] = new Object[1];             
    							 params1[0] = DocbaseUtils.getValidationExceptionMsg(new DfException(errorMessage));			            	   	
    							 WebComponentErrorService.getService().setNonFatalError(this, "MSG_VALIDATION_ERROR", params1, null);
    							 DfLogger.info(this, " :: onaction : errorMessage :: " + errorMessage,null,null);
    						 }else{
    							 WebComponentErrorService.getService().setNonFatalError(this, "MSG_CHILD_WRK_ERROR_MSG", null, null);		
    						 }
    					 }else{
    						 /** if the Template is Lite version Restricted template  launch NewDocument Component*/	  
    						 args.add("callerComponent",CALLER_COMPONENT);
    						 args.replace("objectId",dfFolder.getObjectId().toString());
    						 args.replace("templateName",templateNameFromPromptText);
    						 DfLogger.info(this, " :: onaction : calling NewDocContainer Component :: ",null,null);
    						 super.onaction(actionControl, args);
    					 }
    				 }
    				 
    				 }else{
    					 if(IdocsUtil.getMessage("MSG_NON_OFFICIAL_TEMPLATES").equals(templateNameFromPromptText)){
    						 isNonOfficialTemplate=true;
    					 }else{
    						 isNonOfficialTemplate=false;
    						 DfLogger.debug(this, "it can be any security classification depends on folder ", null, null);
    					 }
    					 DfLogger.debug(this,"onaction() :: calling ObjectList ==> createDocument() method " ,null,null);
    					 Button createbutton = new Button();
    					 ArgumentList list = new ArgumentList();
    					 list.add(STR_TEMPLATE_NAME_FROM_PROMPTED_TEXT,templateNameFromPromptText);
    					 createDocument(createbutton, list);
    				 } 
        	        }
    			 }else{
    					 DfLogger.debug(this,"onaction() :: New Doc Creation action :: temaplateName  "+TampleteDefultInput ,null,null);
    					 WebComponentErrorService.getService().setNonFatalError(this, "MSG_INVALID_NOT_TEMPLATE_STRING", null, null);
    				 }
        		 }else{
        			 super.onaction(actionControl, args);
        		 }
    		 }else{
    			 super.onaction(actionControl, args);
    		 }
   			  
		} catch (DfException e) {
			DfLogger.error(this, e.getMessage(), null, e);
		}finally{
			if(dfCollection != null)
				try {
					dfCollection.close();
				} catch (DfException e) {
					DfLogger.error(this, e.getMessage(), null, e);
				}
		}
    }

     /**
	  * 
	  */
     public void createDocument(Control Button, ArgumentList arglist) {
    	 drlStatus=false;
    	 boolean validationRequired=false;
    	 try {
    		 if(isEligibleFolder){
    			 MSG_OBJECT_TYPE=dfFolder.getTypeName();		    	
    			 if(MSG_OBJECT_TYPE.equals(IdocsConstants.PROJ_FOLDER_TYPE)){
    				 validationRequired=true;
    			 }else
    				 validationRequired=false;
    			 String templateNameFromPromptText=arglist.get(STR_TEMPLATE_NAME_FROM_PROMPTED_TEXT);
    			 if(!(templateNameFromPromptText.trim().equalsIgnoreCase(TampleteDefultInput.trim()))){
    				 if(validationRequired){
    					 if(dfFolder.getString(IDocsConstants.PROJECT_ID) != null){
    						 boolean userAccessValidation=validateProjUserAccess(getDfSession(),templateNameFromPromptText,dfFolder.getString(IDocsConstants.PROJECT_ID));
    						 if(userAccessValidation){
    							 /** This method will create template document if user in sufficient role */
    							 createTemplateDocument(templateNameFromPromptText,dfFolder);
    						 } else {
    							 Object params[] = new Object[1];             
    							 params[0] = DocbaseUtils.getValidationExceptionMsg(new DfException(getErrorMessage()));			            	   	
    							 WebComponentErrorService.getService().setNonFatalError(this, "MSG_VALIDATION_ERROR", params, null);
    						 }
    					 }
    				 }else{
    					 DfLogger.info(this,"Document creation validation not required for \"Institution\" or \"Country\" folder",null,null);  
    					 createTemplateDocument(templateNameFromPromptText,dfFolder);
    				 }
    			 }else {
    				 WebComponentErrorService.getService().setNonFatalError(this, "ERR_TMPL_NAME", null, null);
    			 }
    		 }
    	 } catch (DfException e) {
    		 DfLogger.error(this, e.getMessage(), null, e);
    	 }
     }
	 
   /**
	 * This method attaches the life cycle to the newly created document
	 * @param dfsess
	 * @param strNewObjectId
	 * @throws DfException
	 */
	 
	 private void  attachPolicy(IDfSession dfsess, IDfDocument newDoc) throws DfException{
		 if(newDoc.getString(IDocsConstants.POLICY_ID).equals(IDocsConstants.BLANK_OBJECT_ID)){
			 DfLogger.debug(this, "attachPolicy :: If label : "+newDoc.getString(IDocsConstants.MSG_R_VERSION_LABEL),null,null);
			 StringBuffer strBuff = new StringBuffer(64);
			 strBuff.append("dm_policy where object_name='").append(IDocsConstants.MSG_IDOCS_LIFECYCLE).append("'");
			 com.documentum.fc.common.IDfId policyId = dfsess.getIdByQualification(strBuff.toString());
			 if(policyId!=null && !(policyId.getId().equals(NULL_OBJECT_ID))){
				 DfLogger.debug(this, "attachPolicy :: LifeCycle : "+policyId.getId(),null,null);
				 newDoc.attachPolicy(policyId, "0", "");
			 }else{
				 DfLogger.debug(this, "attachPolicy :: LifeCycle NOT FOUND :strBuff="+strBuff,null,null);	
			 }
			 DfLogger.debug(this, " :: attachPolicy : LifeCycle '"+IDocsConstants.MSG_IDOCS_LIFECYCLE+"' is attached with Stage '",null,null);
		 }else{
			 DfLogger.debug(this, " :: attachPolicy : Else",null,null);
		 }
	 }

   /**
	 * 
	 * @param tName
	 * @param docFolder
	 */
	private void createTemplateDocument(String tName, IDfFolder docFolder) {
		String docId=null;
		IDfDocument newDoc = null;
		try {
			HttpServletRequest servletReq = (HttpServletRequest) getPageContext().getRequest();
			docId = new CreateNewDoc(tName, getDfSession(), this,docFolder,servletReq).getDocumentCreator();
			if (docId != null && docId.length() >0 && !docId.equals(NULL_OBJECT_ID)) {
				Context context = getContext();
				ArgumentList componentArgs = new ArgumentList();
				componentArgs.add("objectId", docId);
				newDoc = (IDfDocument) ObjectCacheUtil.getObject(getDfSession(), docId);
				attachPolicy(getDfSession(), newDoc);
				newDoc = (IDfDocument) ObjectCacheUtil.getObject(getDfSession(), docId);
				newDoc.setTime("document_date", new DfTime());
				/** Setting security Classification on document */
				setSecurityClassificatioin(newDoc);
				/** Setting initial version as 0.1 */
				int verlabelcnt = newDoc.getVersionLabelCount();
				if (verlabelcnt == 2) {
					newDoc.mark("0.1");
					newDoc.mark("CURRENT");
				} else {
					newDoc.mark("0.1");
					newDoc.mark("CURRENT");
					newDoc.mark("_NEW_");
				}
				newDoc.save();
				DfLogger.debug(this,"createTemplateDocument() :: New Doc Creation ::Saved document "+newDoc.getObjectId().toString() ,null,null);
				context.set("type", newDoc.getTypeName());
				context.set("objectId", newDoc.getObjectId().toString());
				componentArgs.add("isEditAfterNew","yes");
				DfLogger.debug(this,"createTemplateDocument() :: New Doc Creation ::Launching doument r_object_id is ::"+newDoc.getObjectId().toString() ,null,null);
				ActionService.execute("editfile", componentArgs, context, this,null);
				DataDropDownList templateName = (DataDropDownList) getControl(MSG_TEMPLATE_NAME, DataDropDownList.class);
				templateName.setValue(TampleteDefultInput);
				updateContextFromPath(strFolderPath);

			}else {
				DfLogger.debug(this,"createTemplateDocument() :: document created reason ==> nullobject id" ,null,null);
			}
		} catch (DfException e) {
			DfLogger.error(ObjectList.class, " :: createTemplateDocument  Exception >>> "+e.getMessage(),null,null);
		try {
			if(newDoc != null){
				 DfLogger.error(this,"createTemplateDocument() :: New Doc Creation exception block >>  "+newDoc.getObjectId().toString() ,null,e); 
			 	 newDoc.destroy();
			 	 if(e.getMessage().contains(STR_DM_QUERY_E_CURSOR_ERROR)){
			 		WebComponentErrorService.getService().setNonFatalError(this,"MSG_PLEASE_CREATE_DB", null, null);
			 		}else if(e.getMessage().contains(DM_POLICY_E_ERROR)){
			 		WebComponentErrorService.getService().setNonFatalError(this,"MSG_PLEASE_CREATE_POLICY", null, null);
			 		}else {
			 		WebComponentErrorService.getService().setNonFatalError(this,"MSG_PLEASE_CREATE_AGAIN", null, null);
			 		}
			 	 }
			} catch (DfException dfException) {
				DfLogger.error(ObjectList.class, " :: createTemplateDocument Exception >>> "+dfException.getMessage(),null,null);
			}
			
		}
	}

	/**
	 * @param newDoc
	 * @throws DfException
	 */
	private void setSecurityClassificatioin(IDfDocument newDoc) throws DfException {
		if (MSG_FOLDER_SECURITY != null) {
			if(isNonOfficialTemplate){
				if(IDocsConstants.MSG_OFFICIAL_USE_ONLY.equals(MSG_FOLDER_SECURITY)){
					newDoc.setString(IDocsConstants.MSG_SEC_CLASSIFICATION_CODE,IDocsConstants.MSG_CONFIDENTIAL_CODE);
					newDoc.setString(IDocsConstants.MSG_SEC_CLASSIFICATION,IDocsConstants.MSG_CONFIDENTIAL);
				}else{
					DfLogger.debug(this,"Not Required to Update Security classification on new doc", null, null);
					newDoc.setString(IDocsConstants.MSG_SEC_CLASSIFICATION_CODE,MSG_FOLDER_SECURITY_CODE);
					newDoc.setString(IDocsConstants.MSG_SEC_CLASSIFICATION,MSG_FOLDER_SECURITY);
				}
			}else{
				newDoc.setString(IDocsConstants.MSG_SEC_CLASSIFICATION_CODE,MSG_FOLDER_SECURITY_CODE);
				newDoc.setString(IDocsConstants.MSG_SEC_CLASSIFICATION,MSG_FOLDER_SECURITY);
			}
		}else{
			if(isNonOfficialTemplate){
				if(IDocsConstants.MSG_OFFICIAL_USE_ONLY.equals(MSG_FOLDER_SECURITY)){
					newDoc.setString(IDocsConstants.MSG_SEC_CLASSIFICATION_CODE,IDocsConstants.MSG_CONFIDENTIAL_CODE);
					newDoc.setString(IDocsConstants.MSG_SEC_CLASSIFICATION,IDocsConstants.MSG_CONFIDENTIAL);
				}else{
					DfLogger.debug(this,"Not Required to Update Security classification on new doc", null, null);
					newDoc.setString(IDocsConstants.MSG_SEC_CLASSIFICATION_CODE,dfFolder.getString("sec_classification_code"));
					newDoc.setString(IDocsConstants.MSG_SEC_CLASSIFICATION,dfFolder.getString("security_classification"));
				}
			}else{
				newDoc.setString(IDocsConstants.MSG_SEC_CLASSIFICATION_CODE,dfFolder.getString("sec_classification_code"));
				newDoc.setString(IDocsConstants.MSG_SEC_CLASSIFICATION,dfFolder.getString("security_classification"));
				DfLogger.debug(this,"createTemplateDocument ::: Docdate and Security classification Setting :: "+ MSG_FOLDER_SECURITY_CODE, null, null);
			}
		}
	}
	
   /**
	 * This method validates whether the logged user has sufficient privileges to create document
	 * in selected project folder
	 * @param dfSession
	 * @param strTemplateName
	 * @param projectId
	 * @return
	 */
	
	public boolean validateProjUserAccess(IDfSession dfSession, String strTemplateName, String projectId) {
		boolean validated=false;
		String validationError="";
		DfQuery query = new DfQuery();
		try{
			String role="";
			DfLogger.debug(ObjectList.class, " :: validateProjUserAccess : UserLoginName : "+getDfSession().getLoginUserName(),null,null);
			String templateQry = IdocsUtil.getMessage("QRY_TEMPLATE_INFO");
			templateQry = templateQry.replaceFirst(IdocsConstants.MSG_C_DQ_C, IdocsConstants.MSG_QUOTES+strTemplateName+IdocsConstants.MSG_QUOTES);
			IDfCollection coll=IdocsUtil.executeQuery(dfSession, templateQry, IDfQuery.DF_READ_QUERY);
			try{
				while(coll.next()){
					validationError=coll.getString(MSG_ERROR_MESSAGE);
					role=coll.getString(MSG_ROLE);
				}
			}catch (DfException e){
				DfLogger.error(this, " validateProjUserAccess  ::", null, null);
			}finally{
				if(coll != null) {
					coll.close();
				}
			}
			setErrorMessage(validationError);
			DfLogger.debug(ObjectList.class, " :: validateProjUserAccess : validationError : " + validationError + ": role: " + role,null,null);
			if(role.equalsIgnoreCase(STR_ROLE_ALL)){
				DfLogger.debug(ObjectList.class, " :: validateProjUserAccess : Validated : "+role,null,null);
				validated=true;
			}else if(role.equalsIgnoreCase(STR_ROLE_NONE)){
				DfLogger.debug(ObjectList.class, " :: validateProjUserAccess : NOT Validated : "+role,null,null);
				validated=false;
			}else if(role.startsWith(IDocsConstants.MSG_RESTART_ONLY)){
				DfLogger.debug(ObjectList.class, " :: validateProjUserAccess : NOT Validated : "+role,null,null);
				validated=false;
			}else{
				String createRole=null;
				String createRoleType = null;
				String errorMsg=null;
				boolean isWFStarted=false;
				String templateAccessQry=IdocsUtil.getMessage("QRY_APP_SEC_CONFIG_CREATE");
				templateAccessQry=templateAccessQry.replaceAll(IdocsConstants.MSG_C_DQ_C, IdocsConstants.MSG_QUOTES+strTemplateName+IdocsConstants.MSG_QUOTES);
				DfLogger.debug(ObjectList.class, " :: validateProjUserAccess : templateAccessQry : " + templateAccessQry, null, null);
				query.setDQL(templateAccessQry);
				coll=query.execute(dfSession,IDfQuery.DF_READ_QUERY);
				boolean enteredRoleCheck = false;
				while(coll.next() && validated==false){
					enteredRoleCheck = true;
					createRole=coll.getString(IdocsConstants.MSG_CREATE_ROLE);
					createRoleType=coll.getString(IdocsConstants.MSG_CREATE_ROLE_TYPE);
					isWFStarted=coll.getBoolean(IDocsConstants.MSG_IS_WORKFLOW_RESTARTABLE);
					errorMsg=coll.getString(IdocsConstants.MSG_ERROR_MESSAGES);
					validated = IdocsUtil.validateRole(projectId,createRole,createRoleType,"",isWFStarted,errorMsg,getDfSession());
				}
				if(coll!=null) coll.close();
				if(validated == false && enteredRoleCheck == false){
					DfLogger.debug(this, " :: validateProjUserAccess : NO ROWS in APP SEC : SKIP Validation ", null, null);
					validated = true;
				}
			}
		}catch(DfException e){
			DfLogger.error(ObjectList.class, " :: validateProjUserAccess Exception >>> "+e.getMessage(),null,null);
		}
		return validated;
	}
   
 	protected String getColumnsPreferenceId(){
		String prefId = lookupString("ifcdocscolumnpreferenceid", false);
		return (prefId == null) || (prefId.length() == 0) ? "application.display.classic_ifcdocscabinets_columns" : prefId;
	}
	
	private void buildQueryWithFilters(){
		Radio alldocs = ((Radio) getControl(STR_ALL_DOCUMENTS,Radio.class));
		Radio templatedocs = ((Radio) getControl(STR_TEMP_DOCUMENTS,Radio.class));
		Radio emaildocs = ((Radio) getControl(STR_EMAIL_DOCUMENTS,Radio.class));
		Radio scanneddocs = ((Radio) getControl(STR_SCAN_DOCUMENTS,Radio.class));
		if(alldocs.getValue()){
			DfLogger.debug(this," :: buildQueryWithFilters>>> selected Radio button ::alldocs",null,null);
			buildQueryForFilteredObjects(STR_ALL_DOC);
		}else
			if(templatedocs.getValue()){
				DfLogger.debug(this, " :: buildQueryWithFilters>>> selected Radio button template",null,null);
				buildQueryForFilteredObjects(STR_TEMPLATE);	
			}else
				if(emaildocs.getValue()){
					DfLogger.debug(this, " :: buildQueryWithFilters>>> selected Radio button email",null,null);
					buildQueryForFilteredObjects(STR_EMAIL);		
				}else 
					if(scanneddocs.getValue()){
						DfLogger.debug(this, " :: buildQueryWithFilters>>> selected Radio button scanning",null,null);
						buildQueryForFilteredObjects(STR_SCAN);	
					}else{
						DfLogger.debug(this, " :: buildQueryWithFilters>>> selected Radio button import",null,null);
						buildQueryForFilteredObjects(STR_IMPORTED);		
					}
	}
	
	
	/**
	 * To generate the TableResultSet
	 * @return
	 */
	public TableResultSet getTemplateTableResultSet(String query,String type){
		TableResultSet typeResultSet =null;
		if(type.equalsIgnoreCase("template")){
			typeResultSet=new TableResultSet(new String[] {"object_name"});
		}else if(type.equalsIgnoreCase("subfolder")){
			typeResultSet=new TableResultSet(new String[] {STR_SUBFOLDER_TITLE});
		}
		try {
		int count = 0;
			IDfCollection collection = IdocsUtil.executeQuery(getDfSession(),query, IDfQuery.DF_CACHE_QUERY);
		while (collection.next()) {
			count++;
			String attrValue ="";
			if(type.equalsIgnoreCase("template")){
				attrValue = collection.getString("object_name");
			}else if(type.equalsIgnoreCase("subfolder")){
				attrValue = collection.getString(STR_SUBFOLDER_TITLE);
			}
			typeResultSet.add(new String[] {attrValue});
		 }
		if (collection != null)collection.close();
		}catch (DfException ex){
			DfLogger.info(this, "<< Exception >>"+ex.getMessage(), null,null);
		}
		
		return typeResultSet;
	}

	
	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public void  onSelectTemplateName(Control dropDown,ArgumentList list){
		Button createButton = (Button)getControl(MSG_BUTTON_CREATE,Button.class);
		createButton.setFocus();
	}
	
   /**
	 * @param subFolderTitle
	 */
	public void populateSubTypeList(String subFolderTitle) {
		String folderCategory=getFolderCategory();
		TableResultSet typeResultSet = null;
		DocTypeTableStructure docTypeTableStructure = new DocTypeTableStructure(IDocsQRYVO.getTemplateInfoTableData(getDfSession()));
		String [] attributeList={"doc_type_name"};
		typeResultSet=docTypeTableStructure.getTableResultSetColumnWithWhereClausesWithDistinct(attributeList, "folder_category", folderCategory, STR_SUBFOLDER_TITLE,subFolderTitle, "doc_type_name");
		DataDropDownList subtypeLst = (DataDropDownList) getControl(MSG_SUB_TYPE_LIST,DataDropDownList.class);
		subtypeLst.setEnabled(true);
		subtypeLst.getDataProvider().setDfSession(getDfSession());
		if(typeResultSet != null){
			typeResultSet.sort("doc_type_name",Datagrid.SORTDIR_FORWARD,Datagrid.SORTMODE_TEXT);
			subtypeLst.getDataProvider().setScrollableResultSet(typeResultSet);
		}else{
			String strquery = "select doc_type_name from dm_dbo.IDOCS_DOC_TYPE_INFO"
				+ " where folder_category in('"+folderCategory+"')"
				+ "and subfolder_title ='" + subFolderTitle + "' order by doc_type_name;";
			DfLogger.debug(this,"SubType Query" + strquery,null,null);
			subtypeLst.getDataProvider().setQuery(strquery);
		}
		}
	
	
/**
 * 
 * 
 * @return
 * @throws DfException
 */
	public boolean isEligibleFolder() throws DfException {
		boolean isEligble = false;
		// check not null
		if (dfFolder != null) {
			// check if it s an allowed folder
			if (dfFolder.getTypeName().equals(IdocsConstants.PROJ_FOLDER_TYPE)
					|| dfFolder.getTypeName().equals(IdocsConstants.INSTITUTION_FOLDER_TYPE)
					|| dfFolder.getTypeName().equals(IdocsConstants.COUNTRY_FOLDER_TYPE)) {
				MSG_FOLDER_SECURITY_CODE=dfFolder.getString("sec_classification_code");
				MSG_FOLDER_SECURITY=dfFolder.getString("security_classification");
				isEligble = true;
			}
		}
		DfLogger.debug(this,"Eligible Folder:" + isEligble,null,null);
		return isEligble;
	}
	
	/**
	 * To Build Email and Scan Related Attributes Query 
	 */

    private void buildQueryForFilteredObjects(String entryValue){
 	   StringBuilder filterQueryBuilder= new StringBuilder(); 	   
 	    String docTypeName  = ((DataDropDownList) getControl(MSG_SUB_TYPE_LIST,DataDropDownList.class)).getValue();
		String subFolderTitle = ((DataDropDownList) getControl(MSG_SUB_FOLDER_LIST,DataDropDownList.class)).getValue();
		filterQueryBuilder.append(" ");
	   if(entryValue.equals(STR_ALL_DOC)){
		DfLogger.info(this,"buildQueryForEmailAndScanObjects() :: All Documents Query " +filterQueryBuilder.toString(),null,null);
	   }else
 	   if(entryValue.equals(STR_TEMPLATE)){
 		    filterQueryBuilder.append(IdocsUtil.getMessage("TEMPLATE_DOCS_FILTER"));
		    DfLogger.info(this,"buildQueryForEmailAndScanObjects() :: Template Documents Query " +filterQueryBuilder.toString(),null,null);
	   }else if(entryValue.equals(STR_EMAIL)){
		    filterQueryBuilder.append(IdocsUtil.getMessage("EMAIL_DOCS_QUERY_FILTER"));
			DfLogger.info(this,"buildQueryForEmailAndScanObjects() :: Email Documents Query " +filterQueryBuilder.toString(),null,null);
	   }else if(entryValue.equals(STR_SCAN)){
		    filterQueryBuilder.append(IdocsUtil.getMessage("SCANNING_DOCS_FILTER"));
			DfLogger.info(this,"buildQueryForEmailAndScanObjects() :: Scanning Documents Query " +filterQueryBuilder.toString(),null,null);
		}else{
			filterQueryBuilder.append(IdocsUtil.getMessage("IMPORTED_DOCS_FILTER"));
			DfLogger.info(this,"buildQueryForEmailAndScanObjects() :: Import Documents Query " +filterQueryBuilder.toString(),null,null);
		}
	   
		boolean filtersStatus=false; 
		if (subFolderTitle != null && !subFolderTitle.equals("") && !subFolderTitle.equals("ALL")) {
			if(entryValue.equals(STR_ALL_DOC)){
				filterQueryBuilder.append("  folder_title='" + subFolderTitle + "' ");
			}else{
				filterQueryBuilder.append(" AND folder_title='" + subFolderTitle + "' ");
			}
			filtersStatus=true;
		 }
		if (docTypeName != null && !docTypeName.equals("") && !subFolderTitle.equals("ALL")) {
			filterQueryBuilder.append(" AND doc_subtype_nme='" + docTypeName + "' ");
			filtersStatus=true;
			}
		
		if(filtersStatus ){
			 filterQueryBuilder.append(" AND ");
			}else{
				if(entryValue.equals(STR_ALL_DOC)){
					
				}else{
				  filterQueryBuilder.append(" AND ");
				}		
			}
		setCustomDataGridQuery();
		String stringQuery=strOriginalQuery;

		//Suvig: Added this to identify if the fulltext query should be used
		boolean isFullTextQuery = false;
		
		if(searchService){
			Text beginsWith=(Text)getControl(CONTROL_FULLTEXT_INPU_BOX,Text.class);
			String searchKey="";
			if(beginsWith.getValue() != null){
				searchKey=IdocsUtil.handleSingleQuote(beginsWith.getValue());	
				DfLogger.info(this,"Value in side the contentsearch text box with tag ::::" +searchKey,null,null);

				//Suvig: We want to extract the text between the from and order by to use in our query.
				//anything before the from is not useful as it is getting attributes that we don't need
				//anything after the order by is not useful since we want xPlore to do the ordering.
				//this gets the whereClause
				int afterFrom = strOriginalQuery.indexOf(" from ");
				int beforeorderby = strOriginalQuery.indexOf(" order by ");
				String whereClause = strOriginalQuery.substring(afterFrom,beforeorderby);

				//Suvig: This is the query we want to send to the search engine.
				stringQuery = "SELECT text,object_name,score,summary,r_modify_date,r_object_id,r_object_type,r_lock_owner,owner_name,"
							+" r_link_cnt,r_is_virtual_doc,r_content_size,a_content_type,i_is_reference,r_assembled_from_id,r_has_frzn_assembly,"
							+" a_compound_architecture,i_is_replica,r_policy_id,r_version_label,workflow_status,subject,"
							+" title,r_modifier,content_modify_date "
							+ whereClause;
				stringQuery=stringQuery.replace("idocs_document where "," idocs_document SEARCH DOCUMENT CONTAINS '" +searchKey
						+"' where " + filterQueryBuilder.toString());			

				// Suvig: isFullTextQuery gets set to true so that we can use the appropriate setQuery later
				isFullTextQuery = true;

			}else{
				searchKey="";
			}
			
			searchService=false;
		}else if(beginsWith){
			Text startsWithText =(Text)getControl(CONTROL_FULLTEXT_INPU_BOX,Text.class);
	  	    String startsWithTextValue=startsWithText.getValue();
	  	    DfLogger.info(this,"Value in side the simple text search text box with tag ::::" +startsWithTextValue,null,null);
			if(startsWithTextValue != null &&
					startsWithTextValue.trim().length() > 0){
				beginsWith=false;
				
				//Suvig: Added the toUpperCase and upper in the query.				
				startsWithTextValue=IdocsUtil.handleSingleQuote(startsWithTextValue).toUpperCase();
				stringQuery=stringQuery.replace("idocs_document where "," idocs_document where upper(object_name) like '%"+startsWithTextValue+"%' and "+ filterQueryBuilder.toString());	
			}else{
				stringQuery=stringQuery.replace("idocs_document where "," idocs_document where "+ filterQueryBuilder.toString());
			}
		}else{
			stringQuery=stringQuery.replace("idocs_document where "," idocs_document where "+ filterQueryBuilder.toString());
		}
		
		Datagrid dgrid = (Datagrid) getControl(DocList.CONTROL_GRID,Datagrid.class);

		//Suvig: If this is a fulltext query, we want to use setQuery without the findByIDQuery
		if (isFullTextQuery) {
			dgrid.getDataProvider().setQuery(stringQuery);			
		} else {
			dgrid.getDataProvider().setQuery(stringQuery,findByIDQuery);						
		}
	}
    
	
	public String getFolderCategory() {
		return folder_category;
	}
	
	public void setFolderCategory(String folderCategory) {
			folder_category = folderCategory;
	}

	/**
    * 
    * @param str
    * @param c
    * @param n
    * @return
    */
   
	public static int nthOccurrence(String str, char c, int n) {
		int pos = str.indexOf(c, 0);
		while (n-- > 0 && pos != -1)
			pos = str.indexOf(c, pos+1);
		DfLogger.debug(ObjectList.class, " :: projectFolder Position :"+pos, null, null);
		return pos;
	}
}