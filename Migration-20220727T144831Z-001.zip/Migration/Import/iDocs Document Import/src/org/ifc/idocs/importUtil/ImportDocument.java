package org.ifc.idocs.importUtil;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;
import com.documentum.operations.IDfCheckinNode;
import com.documentum.operations.IDfCheckinOperation;
import com.documentum.operations.IDfCheckoutOperation;
import com.documentum.operations.IDfFile;
import com.documentum.operations.IDfImportNode;
import com.documentum.operations.IDfImportOperation;

public class ImportDocument extends ImportUtility{

	//import file with specific version
	@SuppressWarnings("unchecked")
	protected static void importFile(int total) throws DfException
	{
		IDfClientX clientx = new DfClientX();
		IDfFile file = null;
		IDfId fid = null;
		String fullPath = "";
		try
		{
//			System.out.println("before calling getDestinationPath");
			fullPath=getDestinationPath(0);
//			System.out.println("after calling getDestinationPath");
			//Get Source file path.
			getSourceFile(0);
//			dominoDocLogger.info("ImportDocument :: importFile() : Document Name : "+sourceFilePath);

			file = clientx.getFile(sourceFilePath);
//			dominoDocLogger.info("ImportDocument :: importFile() : DestinationPath :: " +fullPath);
			fid = dfSession.getFolderByPath(fullPath).getObjectId();

			IDfImportOperation opi = clientx.getImportOperation();
			opi.setSession(dfSession);
			opi.setDestinationFolderId(fid);

			IDfImportNode node = (IDfImportNode) opi.add(file);
			node.setDocbaseObjectType(docBaseObjectType);
			opi.execute();

			newId = node.getNewObjectId();
			IDfSysObject importedDoc = (IDfSysObject)dfSession.getObject(newId);
			if(attributeValueList[0].get(idocsProperties.getProperty("MSG_VERSION")).equals("0.1")){
				importedDoc.mark("0.1");
			}
			importedDoc.save();
			boolean attrSetFlag = setAttributes(newId, dfSession, 0);
			if(attrSetFlag)
			{
	     		documentCount++;
//	     		System.out.println(">>>>>>>>>>>>>>>>>>> 1 Document Count  : "+documentCount);
				IDfQuery dfquery = new DfQuery();
				String query = idocsProperties.getProperty("QRY_UPDATE_AUDIT_REPORT")+ newId +idocsProperties.getProperty("QRY_UPDATE_AUDIT_REPORT_REM")+ attributeValueList[0].get(idocsProperties.getProperty("MSG_VERSION")) +"'";
	     		dfquery.setDQL(query);
	     		dfquery.execute(dfSession, IDfQuery.DF_EXEC_QUERY );
				if(total > 1)
				{
					prevVerFolderPath = fullPath;
					for(int j=1;j<total;j++)
					{
						boolean setVersionFlag = checkinNextVersion(dfSession,j);
						if(!setVersionFlag){
//							failedDocumentCount += total;
							break;
						}
						//Add Document to successful imported list
						getSourceFile(j-1);
						importedXMLList.addElement(sourceFilePath);
						dominoDocLogger.info("ImportDocument :: importFile() : The Document is imported Successfully.");
					}
				}
				getSourceFile(total-1);
				importedXMLList.addElement(sourceFilePath);
				dominoDocLogger.info("ImportDocument :: importFile() : The Document is imported Successfully.");
			}
			else
			{
//				failedDocumentCount += total;
			}
			//log can be provided here
			//document name, doid, all 
		}
		catch(Exception e)
		{
			failedXMLList.addElement(XMLPath);
			if(e.getMessage()!=null){
				dominoDocLogger.warning("ImportDocument :: importFile() : Import Failed : for "+XMLPath+"\n : "+e.getMessage());
			}else{
				dominoDocLogger.warning("ImportDocument :: importFile() : Import Failed : for "+fullPath);
			}
			e.printStackTrace();
		}
	}

	private static boolean checkinNextVersion(IDfSession dfSession,int j) throws DfException 
	{
		IDfClientX clientx = new DfClientX();
		IDfCheckoutOperation cop = clientx.getCheckoutOperation();

		newVerFolderPath = getDestinationPath(j);
		getSourceFile(j);
//		dominoDocLogger.info("ImportDocument :: checkinNextVersion() : Document Name : "+sourceFilePath);

		IDfSysObject sysObj = (IDfSysObject) dfSession.getObject(newId);
		cop.add(sysObj);
		cop.execute();

		if(sysObj.isCheckedOut())
		{
			IDfCheckinOperation cin = clientx.getCheckinOperation();
			float versionValue = Float.parseFloat(attributeValueList[j].get(idocsProperties.getProperty("MSG_VERSION")).toString());
			if((int)versionValue == versionValue){
				cin.setCheckinVersion(IDfCheckinOperation.NEXT_MAJOR);
				cin.setVersionLabels("CURRENT");
			}
			else{
				cin.setCheckinVersion(IDfCheckinOperation.NEXT_MINOR);
			}
			IDfCheckinNode node = (IDfCheckinNode) cin.add(sysObj);

			if(cin.execute())
			{
				IDfId newCheckinId =  node.getNewObjectId();
				boolean attrSetFlag = setAttributes(newCheckinId, dfSession, j);
				if(attrSetFlag)
				{
					IDfSysObject Obj = (IDfSysObject)dfSession.getObject(newCheckinId);
					newId = newCheckinId;
					Obj.setFile(sourceFilePath);
					Obj.save();
					
					if (!prevVerFolderPath.equals(newVerFolderPath)){
						Obj.unlink(prevVerFolderPath);
						Obj.link(newVerFolderPath);
						Obj.save();
					}
		     		documentCount++;
//		     		System.out.println(">>>>>>>>>>>>>>>>>>> 2 Document Count  : "+documentCount);
					IDfQuery dfquery = new DfQuery();
					String query = idocsProperties.getProperty("QRY_UPDATE_AUDIT_REPORT")+ newCheckinId +idocsProperties.getProperty("QRY_UPDATE_AUDIT_REPORT_REM")+attributeValueList[j].get(idocsProperties.getProperty("MSG_VERSION"))+"'";
		     		dfquery.setDQL(query);
		     		dfquery.execute(dfSession, IDfQuery.DF_EXEC_QUERY );
		     		prevVerFolderPath = newVerFolderPath;
		     		return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				dominoDocLogger.info("ImportDocument :: checkinNextVersion() : Checkin Failed.");
				return false;
			}
		}
		return false;
	}

	private static void getSourceFile(int index) 
	{
		sourceFilePath =  sourceRoot +attributeValueList[index].get("DocID").toString()+"_"+attributeValueList[index].get(idocsProperties.getProperty("MSG_VERSION")).toString()+"_"+attributeValueList[index].get("Filename").toString();
	}

	//get destination path based on category
	protected static String getDestinationPath(int index)
	{
		String destPath="";
		String currentPath="/"+attrData.get(idocsProperties.getProperty("MSG_REGION"))+"/"+attrData.get(idocsProperties.getProperty("MSG_COUNTRY"));
//		dominoDocLogger.info("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ currentPath : "+currentPath);
		if(category.equalsIgnoreCase(idocsProperties.getProperty("MSG_COUNTRIES_FOLDER")) || category.equalsIgnoreCase(idocsProperties.getProperty("MSG_COUNTRY_FOLDER")))
		{
			destPath=currentPath+"/"+idocsProperties.getProperty("MSG_COUNTRY_DOC")+"/"+categoryCode+" - "+attrData.get(idocsProperties.getProperty("MSG_COUNTRY"));
		}
		else if(category.equalsIgnoreCase(idocsProperties.getProperty("MSG_INSTITUTIONS_FOLDER")) || category.equalsIgnoreCase(idocsProperties.getProperty("MSG_INSTITUTION_FOLDER")))
		{
			destPath=currentPath+"/"+idocsProperties.getProperty("MSG_INSTITUTION_DOC")+"/"+categoryCode+" - "+attrData.get(idocsProperties.getProperty("MSG_INSTIT_SHORT_NAME"));
		}
		else if(category.equalsIgnoreCase(idocsProperties.getProperty("MSG_PROJECTS_FOLDER")) || category.equalsIgnoreCase(idocsProperties.getProperty("MSG_PROJECT_FOLDER")))
		{
//			System.out.println("###########   ProjCategory :: "+attrData.get(idocsProperties.getProperty("MSG_PROJ_CATEGORY_NAME")));
			destPath=currentPath+"/"+projMainCategory+"/"+categoryCode+" - "+attrData.get(idocsProperties.getProperty("MSG_PROJECT_SHORT_NAME"));
		}
		destPath = destPath+"/"+attributeValueList[index].get(idocsProperties.getProperty("MSG_SUBFOLDER"))+"/"+attributeValueList[index].get(idocsProperties.getProperty("MSG_DOC_TYPE"));
		dominoDocLogger.info("ImportDocument :: getDestinationPath() : Destination Folder Path : "+destPath);
//		System.out.println("ImportDocument :: getDestinationPath() : Destination Folder Path : "+destPath);
		return destPath;
	}

	//set attributes to uploaded file
	@SuppressWarnings("unchecked")
	private static boolean setAttributes(IDfId fileId,IDfSession dfSession,int index) throws DfException
	{
		StringTokenizer st;
		int j=0, attrCount=0;
		String attrName="";

		try
		{
			IDfSysObject sysObj = (IDfSysObject) dfSession.getObject(fileId);
			Set set = attributeValueList[index].entrySet();
			Iterator i = set.iterator();
			while(i.hasNext())
			{
				String key,value = "";
				Map.Entry me = (Map.Entry)i.next();
				if(mataData.get(me.getKey().toString()) != null)
				{
					key = mataData.get(me.getKey().toString()).toString();
					value = me.getValue().toString();
					if(key.contains("date"))
					{
						value = value.replace("\\", "/");
					}
					sysObj.setString(key, value);
				}
			}
			if(category.equalsIgnoreCase(idocsProperties.getProperty("MSG_COUNTRIES_FOLDER")) || category.equalsIgnoreCase(idocsProperties.getProperty("MSG_COUNTRY_FOLDER")))
			{
				st=new StringTokenizer(idocsProperties.getProperty("COUNTRY_DOC_ATTR_LIST"), ",");
				attrCount=st.countTokens();
		    	for(j=0;j<attrCount;j++)
		    	{
					attrName=st.nextToken();
					sysObj.setString(attrName, (String)attrData.get(attrName));
				}
			}
			else if(category.equalsIgnoreCase(idocsProperties.getProperty("MSG_INSTITUTIONS_FOLDER")) || category.equalsIgnoreCase(idocsProperties.getProperty("MSG_INSTITUTION_FOLDER")))
			{
				st=new StringTokenizer(idocsProperties.getProperty("INSTIT_DOC_ATTR_LIST"), ",");
				attrCount=st.countTokens();
		    	for(j=0;j<attrCount;j++)
		    	{
					attrName=st.nextToken();
					sysObj.setString(attrName, (String)attrData.get(attrName));
				}
			}
			else if(category.equalsIgnoreCase(idocsProperties.getProperty("MSG_PROJECTS_FOLDER")) || category.equalsIgnoreCase(idocsProperties.getProperty("MSG_PROJECT_FOLDER")))
			{
				if(docBaseObjectType.equalsIgnoreCase(idocsProperties.getProperty("MSG_IDOCS_EMAIL_DOC")))
				{
					st=new StringTokenizer(idocsProperties.getProperty("EMAIL_DOC_ATTR_LIST"), ",");
					attrCount=st.countTokens();
			    	for(j=0;j<attrCount;j++)
			    	{
						attrName=st.nextToken();
						sysObj.setString(attrName, (String)attrData.get(attrName));
					}
			    }
				else
				{
					st=new StringTokenizer(idocsProperties.getProperty("PROJECT_DOC_ATTR_LIST"), ",");
					attrCount=st.countTokens();
			    	for(j=0;j<attrCount;j++)
			    	{
						attrName=st.nextToken();
						sysObj.setString(attrName, (String)attrData.get(attrName));
					}
				}
			}
			sysObj.save();
			return true;
		}
		catch(Exception e)
		{
			dominoDocLogger.warning("ImportDocument :: setAttributes() : Set Attribute Failed for : attrName : "+attrName+" value : "+attrData.get(attrName)+" - "+e.getMessage());
//			e.printStackTrace();
			rollBack(fileId,index);
			return false;
		}
	}

	private static void rollBack(IDfId fileId, int index) throws DfException
	{
		IDfSysObject sysObj = (IDfSysObject) dfSession.getObject(fileId);
		sysObj.destroyAllVersions();
		dominoDocLogger.info("ImportDocument :: rollBack() : All Versions Deleted for : "+fileId);
		IDfQuery dfquery = new DfQuery();
		String query = idocsProperties.getProperty("QRY_ROLLBACK_AUDIT_REPORT")+attributeValueList[index].get(idocsProperties.getProperty("MSG_VERSION"))+"'";
		dfquery.setDQL(query);
		dfquery.execute(dfSession, IDfQuery.DF_EXEC_QUERY);
	}
}
