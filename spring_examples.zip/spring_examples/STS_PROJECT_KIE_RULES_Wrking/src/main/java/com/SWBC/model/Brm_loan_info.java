package com.SWBC.model;

import java.util.Date;

public class Brm_loan_info {
	
	private String id;
	private String transaction_id;
	private String trans_process_id;
	private String loan_account_no;//[IS_ACCOUNT_NO]
	private String loan_no; //[IS_LOAN_NO]
	private String loan_no_suffix; //[IS_LOAN_SUFFIX]
	private String loan_cov_type;//[IS_COVERAGE_TYPE]
	private String loan_policy_no;//[IS_POLICY_NO]
	private String loan_insur_type; //[IS_INSUR_TYPE]
	private String loan_company_name;
	private String loan_mortgagee_name;
	private Date loan_cancel_date;
	private Date loan_begin_date;
	private Date loan_effective_date;
	private Date loan_transaction_date;
	private Date loan_expiration_date;//[IS_EXPIRATION_DATE]
	private Date loan_doc_issue_date;//[IS_DOC_ISSUE_DT]
	private String loan_insur_status;//IS_INSUR_STATUS
	private Date loan_uninsured_date; //[IS_UNINSURED_DATE]
	private String loan_escrow_code; //[IS_ESCROW_CODE]
	private String loan_is_escrow_client;//FMS057
	private String loan_is_cancelled;
	private String loan_is_force_placed;

    private Date loan_his_rei_date;
	private Date loan_pme_bill_date;
	private String loan_escrow_client;
	
	private int PMEDays;
	private int REIDays;
	
	//loan history dual policy
	private String loan_his_dual_policy_no;
	private int loan_dual_policy_score;
	private int policyScore;
	
	private String loan_property_type;
	
	//REI rule 2.2 - REI Date Check for FP Policies
	private String rei_fmr_date_check;
	
	
	private int loan_es_check_no;
	private Date loan_es_eff_date;
	private Date loan_es_exp_date;
	private Date loan_es_rcvd_date;
	private String loan_swbc_check;
	
	
	private int loan_pme_policy_score;
	
	private String loan_pme_es_policy_no;
	
	private String loan_ag_spare_code;
	private String loan_flood_zone;
	private double loan_pme_premium_amt;
	private double loan_ag_coverage_amt;
	
	private Date loan_pme_effective_date;
	private Date loan_pme_expiration_date;
	
	private String loan_transaction_id;
	
	private String disbursementFlag;
	private double loan_escrow_premium_amt;
	
	private double loan_ag_deductible_amt;
	private double loan_ag_deductible_pct;
	
	private String loan_gap_line;
	private Date loan_gap_effective_date;
	private Date loan_gap_expiration_date;
	
	private String as400_loan_ins_status_msg;
	
	private String VSIPolicyNo;
	
	private String es_void;
	
	private String loan_ag_spare_code3;
	
	
	

	public String getLoan_ag_spare_code3() {
		return loan_ag_spare_code3;
	}
	public void setLoan_ag_spare_code3(String loan_ag_spare_code3) {
		this.loan_ag_spare_code3 = loan_ag_spare_code3;
	}
	public String getEs_void() {
		return es_void;
	}
	public void setEs_void(String es_void) {
		this.es_void = es_void;
	}
	public String getVSIPolicyNo() {
		return VSIPolicyNo;
	}
	public void setVSIPolicyNo(String vSIPolicyNo) {
		VSIPolicyNo = vSIPolicyNo;
	}
	public String getAs400_loan_ins_status_msg() {
		return as400_loan_ins_status_msg;
	}
	public void setAs400_loan_ins_status_msg(String as400_loan_ins_status_msg) {
		this.as400_loan_ins_status_msg = as400_loan_ins_status_msg;
	}
	public Date getLoan_gap_effective_date() {
		return loan_gap_effective_date;
	}
	public void setLoan_gap_effective_date(Date loan_gap_effective_date) {
		this.loan_gap_effective_date = loan_gap_effective_date;
	}
	public Date getLoan_gap_expiration_date() {
		return loan_gap_expiration_date;
	}
	public void setLoan_gap_expiration_date(Date loan_gap_expiration_date) {
		this.loan_gap_expiration_date = loan_gap_expiration_date;
	}
	
	
	public String getLoan_gap_line() {
		return loan_gap_line;
	}
	public void setLoan_gap_line(String loan_gap_line) {
		this.loan_gap_line = loan_gap_line;
	}
	public int getLoan_es_check_no() {
		return loan_es_check_no;
	}
	public void setLoan_es_check_no(int loan_es_check_no) {
		this.loan_es_check_no = loan_es_check_no;
	}
	public Date getLoan_es_eff_date() {
		return loan_es_eff_date;
	}
	public void setLoan_es_eff_date(Date loan_es_eff_date) {
		this.loan_es_eff_date = loan_es_eff_date;
	}
	public Date getLoan_es_exp_date() {
		return loan_es_exp_date;
	}
	public void setLoan_es_exp_date(Date loan_es_exp_date) {
		this.loan_es_exp_date = loan_es_exp_date;
	}
	public Date getLoan_es_rcvd_date() {
		return loan_es_rcvd_date;
	}
	public void setLoan_es_rcvd_date(Date loan_es_rcvd_date) {
		this.loan_es_rcvd_date = loan_es_rcvd_date;
	}
	public String getLoan_swbc_check() {
		return loan_swbc_check;
	}
	public void setLoan_swbc_check(String loan_swbc_check) {
		this.loan_swbc_check = loan_swbc_check;
	}
	private Date loan_pme_creation_date;
	
	//Loan Insurance Status Mapping Input Fields
	private String loan_is_waive_inititals ;
	private String loan_is_spare_code_1 ;
	private Date loan_is_waive_date;
	private String loan_is_audit_code;
	private String loan_is_letter_code;
	private String loan_is_impairment_code;
	private String loan_calculated_ins_status;
	
	//PME Current TERM
	private String loan_pme_current_term;
	

	public int getPolicyScore() {
		return policyScore;
	}
	public void setPolicyScore(int policyScore) {
		this.policyScore = policyScore;
	}
	private Date rec_created_on;
	private Date rec_modified_on;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}
	public String getTrans_process_id() {
		return trans_process_id;
	}
	public void setTrans_process_id(String trans_process_id) {
		this.trans_process_id = trans_process_id;
	}
	public String getLoan_account_no() {
		return loan_account_no;
	}
	public void setLoan_account_no(String loan_account_no) {
		this.loan_account_no = loan_account_no;
	}
	public String getLoan_no() {
		return loan_no;
	}
	public void setLoan_no(String loan_no) {
		this.loan_no = loan_no;
	}
	public String getLoan_no_suffix() {
		return loan_no_suffix;
	}
	public void setLoan_no_suffix(String loan_no_suffix) {
		this.loan_no_suffix = loan_no_suffix;
	}
	public String getLoan_cov_type() {
		return loan_cov_type;
	}
	public void setLoan_cov_type(String loan_cov_type) {
		this.loan_cov_type = loan_cov_type;
	}
	public String getLoan_policy_no() {
		return loan_policy_no;
	}
	public void setLoan_policy_no(String loan_policy_no) {
		this.loan_policy_no = loan_policy_no;
	}
	public String getLoan_insur_type() {
		return loan_insur_type;
	}
	public void setLoan_insur_type(String loan_insur_type) {
		this.loan_insur_type = loan_insur_type;
	}
	public String getLoan_company_name() {
		return loan_company_name;
	}
	public void setLoan_company_name(String loan_company_name) {
		this.loan_company_name = loan_company_name;
	}
	public String getLoan_mortgagee_name() {
		return loan_mortgagee_name;
	}
	public void setLoan_mortgagee_name(String loan_mortgagee_name) {
		this.loan_mortgagee_name = loan_mortgagee_name;
	}
	public Date getLoan_cancel_date() {
		return loan_cancel_date;
	}
	public void setLoan_cancel_date(Date loan_cancel_date) {
		this.loan_cancel_date = loan_cancel_date;
	}
	public Date getLoan_begin_date() {
		return loan_begin_date;
	}
	public void setLoan_begin_date(Date loan_begin_date) {
		this.loan_begin_date = loan_begin_date;
	}
	public Date getLoan_effective_date() {
		return loan_effective_date;
	}
	public void setLoan_effective_date(Date loan_effective_date) {
		this.loan_effective_date = loan_effective_date;
	}
	public Date getLoan_transaction_date() {
		return loan_transaction_date;
	}
	public void setLoan_transaction_date(Date loan_transaction_date) {
		this.loan_transaction_date = loan_transaction_date;
	}
	public Date getLoan_expiration_date() {
		return loan_expiration_date;
	}
	public void setLoan_expiration_date(Date loan_expiration_date) {
		this.loan_expiration_date = loan_expiration_date;
	}
	public Date getLoan_doc_issue_date() {
		return loan_doc_issue_date;
	}
	public void setLoan_doc_issue_date(Date loan_doc_issue_date) {
		this.loan_doc_issue_date = loan_doc_issue_date;
	}
	public String getLoan_insur_status() {
		return loan_insur_status;
	}
	public void setLoan_insur_status(String loan_insur_status) {
		this.loan_insur_status = loan_insur_status;
	}
	public Date getLoan_uninsured_date() {
		return loan_uninsured_date;
	}
	public void setLoan_uninsured_date(Date loan_uninsured_date) {
		this.loan_uninsured_date = loan_uninsured_date;
	}
	public String getLoan_escrow_code() {
		return loan_escrow_code;
	}
	public void setLoan_escrow_code(String loan_escrow_code) {
		this.loan_escrow_code = loan_escrow_code;
	}
	public String getLoan_is_escrow_client() {
		return loan_is_escrow_client;
	}
	public void setLoan_is_escrow_client(String loan_is_escrow_client) {
		this.loan_is_escrow_client = loan_is_escrow_client;
	}
	public String getLoan_is_cancelled() {
		return loan_is_cancelled;
	}
	public void setLoan_is_cancelled(String loan_is_cancelled) {
		this.loan_is_cancelled = loan_is_cancelled;
	}
	public String getLoan_is_force_placed() {
		return loan_is_force_placed;
	}
	public void setLoan_is_force_placed(String loan_is_force_placed) {
		this.loan_is_force_placed = loan_is_force_placed;
	}
	
	public Date getRec_created_on() {
		return rec_created_on;
	}
	public void setRec_created_on(Date rec_created_on) {
		this.rec_created_on = rec_created_on;
	}
	public Date getRec_modified_on() {
		return rec_modified_on;
	}
	public void setRec_modified_on(Date rec_modified_on) {
		this.rec_modified_on = rec_modified_on;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	private String comments;
	
	public Date getLoan_his_rei_date() {
		return loan_his_rei_date;
	}
	public void setLoan_his_rei_date(Date loan_his_rei_date) {
		this.loan_his_rei_date = loan_his_rei_date;
	}
	public Date getLoan_pme_bill_date() {
		return loan_pme_bill_date;
	}
	public void setLoan_pme_bill_date(Date loan_pme_bill_date) {
		this.loan_pme_bill_date = loan_pme_bill_date;
	}
	public String getLoan_escrow_client() {
		return loan_escrow_client;
	}
	public void setLoan_escrow_client(String loan_escrow_client) {
		this.loan_escrow_client = loan_escrow_client;
	}
	public String getLoan_his_dual_policy_no() {
		return loan_his_dual_policy_no;
	}
	public void setLoan_his_dual_policy_no(String loan_his_dual_policy_no) {
		this.loan_his_dual_policy_no = loan_his_dual_policy_no;
	}
	public int getPMEDays() {
		return PMEDays;
	}
	public void setPMEDays(int pMEDays) {
		PMEDays = pMEDays;
	}
	public int getREIDays() {
		return REIDays;
	}
	public void setREIDays(int rEIDays) {
		REIDays = rEIDays;
	}
	public String getLoan_property_type() {
		return loan_property_type;
	}
	public void setLoan_property_type(String loan_property_type) {
		this.loan_property_type = loan_property_type;
	}
	public String getRei_fmr_date_check() {
		return rei_fmr_date_check;
	}
	public void setRei_fmr_date_check(String rei_fmr_date_check) {
		this.rei_fmr_date_check = rei_fmr_date_check;
	}
	public Date getLoan_pme_creation_date() {
		return loan_pme_creation_date;
	}
	public void setLoan_pme_creation_date(Date loan_pme_creation_date) {
		this.loan_pme_creation_date = loan_pme_creation_date;
	}
	public String getLoan_is_waive_inititals() {
		return loan_is_waive_inititals;
	}
	public void setLoan_is_waive_inititals(String loan_is_waive_inititals) {
		this.loan_is_waive_inititals = loan_is_waive_inititals;
	}
	public String getLoan_is_spare_code_1() {
		return loan_is_spare_code_1;
	}
	public void setLoan_is_spare_code_1(String loan_is_spare_code_1) {
		this.loan_is_spare_code_1 = loan_is_spare_code_1;
	}
	public Date getLoan_is_waive_date() {
		return loan_is_waive_date;
	}
	public void setLoan_is_waive_date(Date loan_is_waive_date) {
		this.loan_is_waive_date = loan_is_waive_date;
	}
	public String getLoan_is_audit_code() {
		return loan_is_audit_code;
	}
	public void setLoan_is_audit_code(String loan_is_audit_code) {
		this.loan_is_audit_code = loan_is_audit_code;
	}
	public String getLoan_is_letter_code() {
		return loan_is_letter_code;
	}
	public void setLoan_is_letter_code(String loan_is_letter_code) {
		this.loan_is_letter_code = loan_is_letter_code;
	}
	public String getLoan_is_impairment_code() {
		return loan_is_impairment_code;
	}
	public void setLoan_is_impairment_code(String loan_is_impairment_code) {
		this.loan_is_impairment_code = loan_is_impairment_code;
	}
	public String getLoan_calculated_ins_status() {
		return loan_calculated_ins_status;
	}
	public void setLoan_calculated_ins_status(String loan_calculated_ins_status) {
		this.loan_calculated_ins_status = loan_calculated_ins_status;
	}
	public String getLoan_pme_current_term() {
		return loan_pme_current_term;
	}
	public void setLoan_pme_current_term(String loan_pme_current_term) {
		this.loan_pme_current_term = loan_pme_current_term;
	}
	
	public int getLoan_pme_policy_score() {
		return loan_pme_policy_score;
	}
	public void setLoan_pme_policy_score(int loan_pme_policy_score) {
		this.loan_pme_policy_score = loan_pme_policy_score;
	}
	public String getLoan_pme_es_policy_no() {
		return loan_pme_es_policy_no;
	}
	public void setLoan_pme_es_policy_no(String loan_pme_es_policy_no) {
		this.loan_pme_es_policy_no = loan_pme_es_policy_no;
	}

	public String getLoan_ag_spare_code() {
		return loan_ag_spare_code;
	}
	public void setLoan_ag_spare_code(String loan_ag_spare_code) {
		this.loan_ag_spare_code = loan_ag_spare_code;
	}
	public String getLoan_flood_zone() {
		return loan_flood_zone;
	}
	public void setLoan_flood_zone(String loan_flood_zone) {
		this.loan_flood_zone = loan_flood_zone;
	}
	public double getLoan_pme_premium_amt() {
		return loan_pme_premium_amt;
	}
	public void setLoan_pme_premium_amt(double loan_pme_premium_amt) {
		this.loan_pme_premium_amt = loan_pme_premium_amt;
	}
	public double getLoan_ag_coverage_amt() {
		return loan_ag_coverage_amt;
	}
	public void setLoan_ag_coverage_amt(double loan_ag_coverage_amt) {
		this.loan_ag_coverage_amt = loan_ag_coverage_amt;
	}
	public Date getLoan_pme_effective_date() {
		return loan_pme_effective_date;
	}
	public void setLoan_pme_effective_date(Date loan_pme_effective_date) {
		this.loan_pme_effective_date = loan_pme_effective_date;
	}
	public Date getLoan_pme_expiration_date() {
		return loan_pme_expiration_date;
	}
	public void setLoan_pme_expiration_date(Date loan_pme_expiration_date) {
		this.loan_pme_expiration_date = loan_pme_expiration_date;
	}
	public int getLoan_dual_policy_score() {
		return loan_dual_policy_score;
	}
	public void setLoan_dual_policy_score(int loan_dual_policy_score) {
		this.loan_dual_policy_score = loan_dual_policy_score;
	}
	public String getLoan_transaction_id() {
		return loan_transaction_id;
	}
	public void setLoan_transaction_id(String loan_transaction_id) {
		this.loan_transaction_id = loan_transaction_id;
	}
	public String getDisbursementFlag() {
		return disbursementFlag;
	}
	public void setDisbursementFlag(String disbursementFlag) {
		this.disbursementFlag = disbursementFlag;
	}
	public double getLoan_escrow_premium_amt() {
		return loan_escrow_premium_amt;
	}
	public void setLoan_escrow_premium_amt(double loan_escrow_premium_amt) {
		this.loan_escrow_premium_amt = loan_escrow_premium_amt;
	}
	public double getLoan_ag_deductible_amt() {
		return loan_ag_deductible_amt;
	}
	public void setLoan_ag_deductible_amt(double loan_ag_deductible_amt) {
		this.loan_ag_deductible_amt = loan_ag_deductible_amt;
	}
	public double getLoan_ag_deductible_pct() {
		return loan_ag_deductible_pct;
	}
	public void setLoan_ag_deductible_pct(double loan_ag_deductible_pct) {
		this.loan_ag_deductible_pct = loan_ag_deductible_pct;
	}
}
