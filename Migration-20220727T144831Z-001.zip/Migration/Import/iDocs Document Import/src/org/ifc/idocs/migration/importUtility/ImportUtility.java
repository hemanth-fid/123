package org.ifc.idocs.migration.importUtility;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.owasp.esapi.ESAPI;
import org.owasp.esapi.errors.EncryptionException;

import org.ifc.idocs.migration.helper.AppConfig;
import org.ifc.idocs.migration.helper.LogHelper;
import org.ifc.idocs.migration.helper.PerformanceTuningHelper;
import org.ifc.idocs.migration.helper.UpdateDB;
import org.ifc.idocs.migration.helper.UpdateRefreshDataURL;
import org.ifc.idocs.migration.report.ReportingUtility;
import org.ifc.idocs.migration.rollback.RollbackUtility;
import org.ifc.idocs.migration.updateReferences.CreateFavourites;
import org.ifc.idocs.migration.updateReferences.UpdateCRRPSR;
import org.ifc.idocs.migration.updateReferences.UpdateProductDB;
import org.ifc.idocs.migration.updateReferences.UpdateTAASDB;
import org.ifc.idocs.migration.wfAudits.ImportWFAudits;

import com.documentum.fc.client.DfAuthenticationException;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.DfIdentityException;
import com.documentum.fc.client.DfNoServersException;
import com.documentum.fc.client.DfPrincipalException;
import com.documentum.fc.client.DfServiceException;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfLoginInfo;

/**
 * ImportUtility - Main method where all the Import Utility functionalities would be called. 
 * @author HAnuganti
 * 
 * #############################################################################################
 * Author		            DateofChange	 Version	  ModificationHistory
 * ###########################################################################################
 * Hemachandra Anuganti 
 * ###########################################################################################
 * 
 */
public class ImportUtility {

	protected static final String propertiesFile = "/ImportDominoDoc.properties";
	protected static Properties idocsProperties = new Properties();
	protected static IDfSessionManager sessionMgr = null;
	protected static IDfSession dfSession = null;
	private static boolean sessionAvailable = false;
	protected static String category = "";
	protected static String categoryCode = "";
	protected static String projMainCategory = "";
	protected static String docBaseObjectType ="";
	protected static String sourceFilePath = "";
	protected static String skipped_fldType_code = "";
	protected static String skipped_fldValue_code = "";
	protected static String fld_type_code = "";
	protected static String fld_value_code = "";
	protected static String prevVerFolderPath = "";
	protected static String newVerFolderPath = "";
	protected static String sourceRoot = "";
	protected static String legacyID="";
	protected static String xmlPath = "";
	protected static String legacyDocId = "";
	protected static String region = "";
	protected static String location = "";
	protected static String queryString5 = "";
	protected static String extractionID = "";
	protected static String impUniqId = "";
	protected static int totalDocsCount = 0;
	protected static int existingDocsCnt = 0;
	protected static int uploadedDocCnt = 0;
	final static int max_path = 250;
	protected static ArrayList<String> dbqryList = new ArrayList<String>();
	protected static ArrayList<String> dbqryWFList = new ArrayList<String>();
	protected static HashMap attrData = new HashMap();
	protected static HashMap attributeValueList[];
	protected static HashMap metaData = new HashMap();
	protected static HashMap templateMappingHM = new HashMap(); 
	protected static HashMap levelFldHM = new HashMap();
	protected static HashMap docTitleMapHM = new HashMap();
	protected static Logger importDocLogger = LogHelper.getLogger(ImportUtility.class);
	protected static AppConfig config = AppConfig.getInstance();
	protected static IDfId newId = null;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int choice = 0;
		// Loading the Properties File
		InputStream inputStream = ImportUtility.class
				.getResourceAsStream(propertiesFile);
		try {
			idocsProperties.load(inputStream);
			// Creation of UI for Import Utility
			
			if (args.length > 0){
				choice = Integer.parseInt(args[0]);
			}else{
			System.out.println("");
			System.out
					.println("*******************************************************************");
			System.out
					.println("*              iDocs - Documents Import Utilities                 *");
			System.out
					.println("*******************************************************************");
			System.out.println("\t 1. Baseline Import - Execute Import Utility");
			System.out.println("");
			System.out.println("\t 2. Delta Import - Cleanup for Delta Import Utility");
			System.out.println("\t 3. Delta Import - Created/Updated Documents");
			System.out.println("\t 4. Delta Import - Cleanup Utility for Deleted Documents");
			System.out.println("\t 5. Delta Import - Cleanup Failed imported document (Rollback Utility)");
			System.out.println("");
			System.out.println("\t 6. Execute Reporting Utility");
			System.out.println("");
			System.out.println("\t 7. Reference Data Update - CRR/PSR Database");
			System.out.println("\t 8. Reference Data Update - TAAS Database");
			System.out.println("\t 9. Reference Data Update - Product Database");
			System.out.println("\t 10. Reference Data - Create Favorites");
			System.out.println("");
			System.out.println("\t 11. Import Workflow audits for the Migrated Documents");
			System.out.println("");
			System.out.println("\t 12. Baseline Import - for abrupt Utility Termination");
			System.out.println("");
			System.out.println("\t 13. Update Refresh Data URL");
			System.out.println("");
			System.out.println("\t 14. Exit the Utility");
			System.out.println("*******************************************************************");
			System.out.print("Enter your Choice : ");
			BufferedReader br = new BufferedReader(new InputStreamReader(
					System.in));
			String menuChoice = br.readLine();
			System.out.println("");

			if (menuChoice!= "") {
				try {
					choice = Integer.parseInt(menuChoice);
				} catch (NumberFormatException nfe) {
					choice = 0;
				}
			}
			}
			if (((choice >= 1) && (choice <= 13)) && (!sessionAvailable)){
				
				importDocLogger.info("Initializing Docbase Session...!!");
				if(initializeSession()){
					importDocLogger.info("Docbase Session Established....!!");
			switch (choice) {
			case 1:
				//Import Utility Call
				importDocLogger.info("Execution Started...for menu choice::"+choice);
				UpdateDB.getConnection();
				ImportExecution.run(dfSession,choice);
				importDocLogger.info("Execution ended...for menu choice::"+choice);
				importDocLogger.info("*****************************************************");
				break;
			case 2:
				//Clean up Utility Call
				importDocLogger.info("Executing Cleanup Utility before Delta run::"+choice);
				UpdateDB.getConnection();
				ImportExecution.run(dfSession,choice);
				importDocLogger.info("Cleanup Utility ran successfully before delta utility run for menu choice::"+choice);
				break;
			case 3:
				//Import Utility Call
				importDocLogger.info("Execution Started...for menu choice::"+choice);
				UpdateDB.getConnection();
				ImportExecution.run(dfSession,choice);
				importDocLogger.info("Execution ended...for menu choice::"+choice);
				importDocLogger.info("*****************************************************");
				break;
			case 4:
				importDocLogger.info("Executing Cleanup Utility::"+choice);
				UpdateDB.getConnection();
				RollbackUtility.callCleanup();
				importDocLogger.info("Cleanup Utility ran successfully for menu choice::"+choice);
				break;
			case 5:
				importDocLogger.info("Executing Roll Back Utility::"+choice);
				importDocLogger.info("Executing Utility for Rolling back the imported documents(Cleanup)...");
				UpdateDB.getConnection();
				RollbackUtility.performFunction();
				importDocLogger.info("Rollback Utility ran successfully for menu choice::"+choice);
				break;
			case 6:
				importDocLogger.info("Executing Reporting Utility for the menu choice::"+choice);
				UpdateDB.getConnection();
				ReportingUtility.updateReportTBL();
				importDocLogger.info("Reporting Utility ran successfully for menu choice::"+choice);
				break;
			case 7:
				importDocLogger.info("Execution Started...for menu choice::"+choice);
				importDocLogger.info("Executing Utility for CRR/PSR Database Update...");
				UpdateCRRPSR.updateCRRPSRdrls();
				importDocLogger.info("CRR/PSR Databases Updated Successfully...");
				importDocLogger.info("Execution ended...for menu choice::"+choice);
				break;
			case 8:
				importDocLogger.info("Execution Started...for menu choice::"+choice);
				importDocLogger.info("Executing Utility for TAAS Database Update...");
				UpdateTAASDB.updateTAASRdrls();
				importDocLogger.info("TAAS Databases Updated Successfully...");
				importDocLogger.info("Execution ended...for menu choice::"+choice);
				break;
			case 9:
				importDocLogger.info("Execution Started...for menu choice::"+choice);
				importDocLogger.info("Executing Utility for PRODUCT Database Update..."+choice);
				UpdateProductDB.updateWorkFolwDRLs();
				importDocLogger.info("PRODUCT Databases Updated Successfully...");
				importDocLogger.info("Execution ended...for menu choice::"+choice);
				break;
			case 10:
				importDocLogger.info("Execution Started...for menu choice::"+choice);
				importDocLogger.info("Executing Utility for User Preferences(Subscriptions) creation in IFCDocs Documentum...");
				CreateFavourites.runSubscriptions(dfSession);
				importDocLogger.info("User Preferences(Subscriptions) created successfully in IFCDocs Documentum...");
				importDocLogger.info("Execution ended...for menu choice::"+choice);
				break;
			case 11:
				importDocLogger.info("Execution Started...for menu choice::"+choice);
				importDocLogger.info("Executing Utility for Uploading Workflow audits to IFCDocs Documentum...");
				UpdateDB.getConnection();
				ImportWFAudits.uploadWFAudits();
				importDocLogger.info("Workflow audits uploaded successfully to IFCDocs Documentum...");
				//ImportWFAudits.importWorkflowAuditTrails(dfSession,extractionID);
				importDocLogger.info("Execution ended...for menu choice::"+choice);
				break;
			case 12:
				//Import Utility Call
				importDocLogger.info("Execution Started...for menu choice::"+choice);
				importDocLogger.info("Re Executing the Import Utility for Baseline Import(abrupt Utility Termination)...");
				UpdateDB.getConnection();
				ImportExecution.run(dfSession,choice);
				importDocLogger.info("Execution ended...for menu choice::"+choice);
				importDocLogger.info("*****************************************************");
				break;
			case 13:
				//Import Utility Call
				importDocLogger.info("Execution Started...for menu choice::"+choice);
				importDocLogger.info("Updating RefreshData URL....!");
				UpdateRefreshDataURL.updateRefreshDataURLs();
				importDocLogger.info("Execution ended...for menu choice::"+choice);
				importDocLogger.info("*****************************************************");
				break;
			case 14:
				importDocLogger.info("Menu Chioce selected to exit the Utility::"+choice);
				System.exit(0);
				importDocLogger.info("Disconnecting Docbase Session::"+choice);
				dfSession.disconnect();
			default:
				importDocLogger.info("Invalid Entry Please provide your selection again..."+choice);
			}
		}
			}else if(choice == 14){
				importDocLogger.info("Exiting the utility");
				System.exit(0);
			}else{
				importDocLogger.info("Invalid Entry Please provide your selection again...");
				main(args);
			}
			
			if (choice != 14) {
				dfSession = null;
				sessionAvailable = false;
				System.exit(0);
//				main(args);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("IOException Exceptions in accessing the files::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"IOException Initializing the Import Utility :: ", e);
			e.printStackTrace();
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfException Exceptions in querying::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"DfException Initializing the Import Utility :: ", e);
			e.printStackTrace();
		}
	}

	protected static boolean initializeSession() {
		// TODO Auto-generated method stub
		// Getting the Session from Session Manager
		try {
			// setting variables
			sessionMgr = getSessionMgr(config.getString("docBaseCredentials.uName"), config.getString("docBaseCredentials.encrptpwd"), config.getString("docBaseCredentials.repositoryName"));
			dfSession = sessionMgr.getSession(config.getString("docBaseCredentials.repositoryName"));
			sessionAvailable = true;
		} catch (DfIdentityException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfIdentityException::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"DfIdentityException Initializing the docbase session for Import Utility :: ", e);
			e.printStackTrace();
			sessionAvailable = false;
		} catch (DfAuthenticationException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("!!!!! Please provide valid Docbase Credentials in Config XML !!!!!");
			importDocLogger.log(Level.WARNING,"DfAuthenticationException Initializing the docbase session for Import Utility :: ", e);
//			e.printStackTrace();
			sessionAvailable = false;
		} catch (DfPrincipalException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("DfPrincipalException::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"DfPrincipalException Initializing the docbase session for Import Utility :: ", e);
			e.printStackTrace();
			sessionAvailable = false;
		} catch(DfNoServersException dse){
			importDocLogger.warning("!!!!! Unable to connect to docbase for the docbroker configured for Utility !!!!!");
			importDocLogger.log(Level.WARNING,"DfNoServersException Initializing the docbase session for Import Utility :: ", dse);
//			dse.printStackTrace();
			sessionAvailable = false;
		}catch (DfServiceException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("Unable to connect to docbase for the docbroker configured for utility");
			importDocLogger.warning("DfServiceException::"+e.getMessage());
			importDocLogger.log(Level.WARNING,"DfServiceException Initializing the docbase session for Import Utility :: ", e);
			e.printStackTrace();
			sessionAvailable = false;
		}
		return sessionAvailable;
	}

	protected static IDfSessionManager getSessionMgr(String strDocBaseUsrNme,
			String strDocBasePswd, String strDocBaseNme) {
		// TODO Auto-generated method stub

		IDfClient client;
		IDfSessionManager sMgr = null;
		try {
			client = DfClient.getLocalClient();
			sMgr = client.newSessionManager();
			IDfLoginInfo login = new DfLoginInfo();
			login.setUser(strDocBaseUsrNme);
			login.setPassword(ESAPI.encryptor().decrypt(strDocBasePswd));
			login.setDomain(null);
			sMgr.setIdentity(strDocBaseNme, login);
		} catch (DfException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("Unable to connect to docbase for the docbroker configured for utility");
			importDocLogger.warning("!!! Please provide valid DFC Properties and Docbase Credentials !!!");
			importDocLogger.log(Level.WARNING,"DfException Initializing the docbase session for Import Utility :: ", e);
			e.printStackTrace();
		} catch (EncryptionException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("EncryptionException while decrypting the password");
			importDocLogger.warning("!!!..Please Provide valid encrypted password to run the Utility...!!!");
			importDocLogger.log(Level.WARNING,"EncryptionException Initializing the docbase session for Import Utility :: ", e);
			e.printStackTrace();
		}
		return sMgr;
	}

	public static void reInitializeDocbaseSession() {
		// TODO Auto-generated method stub
		
	}
}
