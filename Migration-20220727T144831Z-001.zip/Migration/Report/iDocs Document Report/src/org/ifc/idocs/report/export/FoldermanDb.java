package org.ifc.idocs.report.export;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import lotus.domino.Database;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.View;
import lotus.domino.ViewEntry;
import lotus.domino.ViewEntryCollection;

import org.ifc.idocs.report.common.LogHelper;
import org.ifc.idocs.report.common.NotesSession;
import org.ifc.idocs.report.model.Country;
import org.ifc.idocs.report.model.DomdocRepository;

/**
 * @author SPankajamsadanan
 *
 */
public class FoldermanDb {
	
	protected Database db;
	protected DomdocRepository domdoc;
	
	public static View versionsView = null;
	Logger exportDocLogger = LogHelper.getLogger(FoldermanDb.class);

	/**
	 * FoldermanDb constructor
	 * @param domdoc
	 * @param path
	 * @throws NotesException
	 */
	public FoldermanDb(DomdocRepository domdoc, String path) throws NotesException {
		this.domdoc = domdoc;
		this.db = NotesSession.getInstance().getDatabase(domdoc.getServerName(), path);
	}

	/**
	 * @throws NotesException
	 */
	public void recycle() throws NotesException {
		this.db.recycle();		
	}

	/**
	 * @return
	 * @throws NotesException
	 */
	@SuppressWarnings("unchecked")
	public List<Country> getCountries() throws NotesException  {
		List<Country> countries = new ArrayList<Country>();
		View countryView = db.getView("FoldersCountry");
		ViewEntryCollection countryColl = countryView.getAllEntries();
		ViewEntry countryVector = countryColl.getFirstEntry();
		while (countryVector != null) {
			Vector v = countryVector.getColumnValues();
			countries.add(new Country(v.elementAt(0).toString(), v.elementAt(1).toString()));
			countryVector = countryColl.getNextEntry(countryVector);
		}
		countryColl.recycle();
		countryView.recycle();
		return countries;
	}

	/**
	 * findFolders method 
	 * @param query
	 * @return DocumentCollection
	 * @throws NotesException
	 */
	public DocumentCollection findFolders(String query){
		try{
			String baseQuery = "Form='Folder'";
			String searchStr;
			if (query.length()>0) {
				searchStr = baseQuery + " & " + query ;
			} else {
				searchStr = baseQuery;
			}
//			System.out.println("Folderman search query : " + searchStr);
			return this.db.search(searchStr);
		}
		catch(NotesException e){
			System.out.println("Folderman Database has not been opened yet. Please check Folderman details in config.xml file");
			System.exit(0);
		}
		return null;
	}

	public View getDeltaVersionDocuments(String docId) {
		try{
			if(versionsView == null){
				versionsView =  db.getView("(Versions)");
			}
		}catch(NotesException e){
			exportDocLogger.warning("Database has not been opened yet");
			e.printStackTrace();
			exportDocLogger.log(Level.WARNING,"FoldermanDB.java-NotesException", e);
		}
		return versionsView;
		
	}

}
