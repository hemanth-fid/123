package sf.application.custcomm.ccs.purge;

import java.io.File;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import sf.application.custcomm.ccs.constants.CleanUpConstants;
import sf.application.custcomm.ccs.constants.QueryConstants;
import sf.application.custcomm.ccs.dao.ICleanUpQueryDao;
import sf.application.custcomm.ccs.dao.impl.CleanUpQueryDao;
import sf.application.custcomm.ccs.exceptions.CleanUpServiceException;
import sf.application.custcomm.ccs.exceptions.QueryException;
import sf.application.custcomm.ccs.util.CleanUpHelper;
import sf.application.custcomm.ccs.util.CommonUtils;
import sf.application.custcomm.ccs.util.DocumentumUtils;
import sf.application.custcomm.ccs.util.FileOperationUtils;

import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.emciig.utils.QueryUtils;
import com.emciig.utils.SessionUtils;

public class PurgeDataCleanupThread implements Runnable {

	private File file;
	private Map<String, String> parameters = null;
	private ICleanUpQueryDao cleanUpQueryDao = new CleanUpQueryDao();
	private static final Logger LOGGER = DfLogger.getLogger(PurgeDataCleanupThread.class);
	private String fileobjectId;
	private StringBuilder messageAppender = new StringBuilder();

	public PurgeDataCleanupThread(File file, Map<String, String> parameters) {

		this.file = file;
		this.parameters = parameters;

	}

	public PurgeDataCleanupThread(String fileobjectId, Map<String, String> parameters) {

		this.fileobjectId = fileobjectId;
		this.parameters = parameters;

	}

	public void run() {

		try {

			performOperationFile(file);
			performOperationRepoFile(fileobjectId);
			writeFailedObjectIdsToFile(
					parameters.get("drive") + ":\\" + parameters.get("edc_cleanup_folder_path")
							+ parameters.get("error") + "error-" + FileOperationUtils.getFileName(),
					messageAppender.toString());

		} catch (CleanUpServiceException e) {
			LOGGER.error(e.getMessage(), e);

		}

	}

	private void writeFailedObjectIdsToFile(String fileLocation, String content) throws CleanUpServiceException {

		if (content != null && content.trim().length() > 0)
			CommonUtils.writeToFile(fileLocation, content);

	}

	private void performOperationRepoFile(String fileobjectId) {

		if (!CommonUtils.isNull(fileobjectId)) {
			IDfSession idfSession = null;
			try {

				idfSession = DocumentumUtils.getSession(parameters);
				String objectName = getObjectName(idfSession, fileobjectId);
				updateStatusInProcess(idfSession, fileobjectId, objectName);
				List<String> objectIds = FileOperationUtils.readFile(getPath(idfSession, fileobjectId));
				LOGGER.info("folderids count " + objectIds.size());
				executeDelete(idfSession, objectIds, fileobjectId);
				updateStatusCompleted(idfSession, fileobjectId, objectName);

			} catch (Exception e) {
				LOGGER.error("Error", e);
			} finally {

				SessionUtils.disconnect(idfSession);

			}

		}

	}

	private void executeDelete(IDfSession objSession, List<String> objectIds, String fileobjectId)
			throws QueryException, DfException {

		String objectFolderPath = getObjectFolderPath(objSession, fileobjectId);

		if (objectFolderPath.contains("/Temp/EDC Cleanup/Folders Cleanup")) {
			System.out.println("objectFolderPath");
			executeDelete(objectIds);

		} else if (objectFolderPath.contains("/Temp/EDC Cleanup/Objects Cleanup")) {
			deleteObjects(objSession, objectIds);

		} else if (objectFolderPath.contains("/Temp/EDC Cleanup/Content Cleanup")) {

			destroyObjectContent(objSession, objectIds);

		} else {

			LOGGER.info(
					"Please drop the files in any one of the folders based on the object type : Folder Cleanup,Objects Cleanup and Content Cleanup");

		}

	}

	private String getPath(IDfSession idfSession, String fileobjectId) throws QueryException, DfException {

		String contentId = cleanUpQueryDao.getQueryStringValue(
				QueryUtils.getDqlStatement(QueryConstants.QRY_GET_I_CONTENT_ID, new Object[] { fileobjectId }),
				"i_contents_id", IDfQuery.DF_READ_QUERY, idfSession);

		String path = cleanUpQueryDao.queryExecute(QueryConstants.QRY_GET_PATH, new Object[] { contentId }, idfSession);

		return path;

	}

	private void updateStatusInProcess(IDfSession idfSession, String fileobjectId, String objectName)
			throws QueryException, DfException {

		cleanUpQueryDao.queryExecute(QueryConstants.QRY_UPDATE_STATUS,
				new Object[] { "In Process", objectName + " In Process", fileobjectId }, idfSession);

	}

	private void updateStatusCompleted(IDfSession idfSession, String fileobjectId, String objectName)
			throws QueryException, DfException {

		String objectsUpdated = cleanUpQueryDao.queryExecute(QueryConstants.QRY_UPDATE_STATUS,
				new Object[] { "Completed", objectName + " Completed", fileobjectId }, idfSession);

	}

	private String getObjectFolderPath(IDfSession idfSession, String fileobjectId) throws QueryException, DfException {

		String folderPath = cleanUpQueryDao.getQueryStringValue(
				QueryUtils.getDqlStatement(QueryConstants.QRY_GET_FOLDER_PATH, new Object[] { fileobjectId }),
				"r_folder_path", IDfQuery.DF_READ_QUERY, idfSession);
		return folderPath;

	}

	private String getObjectName(IDfSession idfSession, String fileobjectId) throws QueryException, DfException {

		return cleanUpQueryDao.getQueryStringValue(
				QueryUtils.getDqlStatement(QueryConstants.QRY_GET_OBJECT_NAME, new Object[] { fileobjectId }),
				"object_name", IDfQuery.DF_READ_QUERY, idfSession);

	}

	private void performOperationFile(File file) {

		if (!CommonUtils.isNull(file)) {

			FileOperationUtils.fileMove(file.getAbsolutePath(), parameters.get("drive") + ":\\"
					+ parameters.get("edc_cleanup_folder_path") + parameters.get("in_process") + file.getName());

			List<String> foldersIds = FileOperationUtils.readFile(parameters.get("drive") + ":\\"
					+ parameters.get("edc_cleanup_folder_path") + parameters.get("in_process") + file.getName());

			executeDelete(foldersIds);

			FileOperationUtils.fileMove(
					parameters.get("drive") + ":\\" + parameters.get("edc_cleanup_folder_path")
							+ parameters.get("in_process") + file.getName(),
					parameters.get("drive") + ":\\" + parameters.get("edc_cleanup_folder_path")
							+ parameters.get("completed") + file.getName());
		}

	}

	private void executeDelete(List<String> foldersIds) {

		IDfSession idfSession = null;
		try {

			idfSession = DocumentumUtils.getSession(parameters);

			for (String folderId : foldersIds) {

				try {

					if (isObjectExists(idfSession, folderId) == 1) {
						System.out.println("isObjectExists");
						deleteObjects(idfSession, getFolderContents(idfSession, folderId));
						deleteFolder(idfSession, folderId);

					}

				} catch (Exception e) {

					LOGGER.error("Error", e);

				}

			}

		}

		catch (Exception e) {
			LOGGER.error("Error", e);
		} finally {

			SessionUtils.disconnect(idfSession);

		}

	}

	private void deleteObjects(IDfSession idfSession, List<String> objectIds) {

		for (String objectId : objectIds) {

			try {
				System.out.println("objectId" + objectId);
				List<String> contentIds = getDmrContentIds(idfSession, objectId);
				destroyObject(idfSession, objectId);
				destroyObjectContent(idfSession, contentIds);

			} catch (Exception e) {

				messageAppender.append(objectId + "-" + e.getMessage());
				messageAppender.append(CleanUpConstants.NEW_LINE);
				LOGGER.error(
						"This Object id  is not deleted " + objectId + "due to the following error " + e.getMessage(),
						e);

			}

		}

	}

	private List<String> getFolderContents(IDfSession idfSession, String folderId) throws QueryException {

		List<String> objectIds = cleanUpQueryDao.getFolderContents(idfSession, QueryConstants.QRY_GET_FOLDER_CONTENTS,
				new Object[] { folderId });

		return objectIds;

	}

	private void deleteFolder(IDfSession idfSession, String folderId) throws QueryException {

		// Before deleting the folder,check whether the folder is empty or not

		List<String> objectIds = getFolderContents(idfSession, folderId);

		if (objectIds != null && objectIds.size() > 0) {

			// delete the contents of the folder one more time
			deleteObjects(idfSession, objectIds);

		}
		System.out.println("folderId " + folderId);

		try {
			idfSession.apiExec("destroy", folderId);
		} catch (Exception e) {
			messageAppender.append(folderId);
			messageAppender.append("-" + e.getMessage());
			messageAppender.append(CleanUpConstants.NEW_LINE);
			LOGGER.error("This folder id  is not deleted " + folderId + "due to the following error " + e.getMessage(),
					e);
			updateFolderSubject(idfSession, folderId);

		}

	}

	private List<String> getDmrContentIds(IDfSession idfSession, String objectId) throws QueryException {

		return cleanUpQueryDao.getDmrContentIds(idfSession, QueryConstants.QRY_GET_DMR_CONTENT_IDS,
				new Object[] { objectId });

	}

	private void destroyObject(IDfSession idfSession, String objectId) throws DfException {

		idfSession.apiExec("destroy", objectId);

	}

	private void destroyObjectContent(IDfSession idfSession, List<String> contentIds) {

		for (String contentId : contentIds) {

			try {

				if (getParentCount(idfSession, contentId) == 0) {

					cleanUpQueryDao.executeContentDestroy(idfSession, QueryConstants.QRY_DESTROY_CONTENT,
							new Object[] { contentId });

				}

			} catch (Exception e) {

				messageAppender.append(contentId);
				messageAppender.append("-" + e.getMessage());
				messageAppender.append(CleanUpConstants.NEW_LINE);
				LOGGER.error(
						"This content id  is not deleted " + contentId + "due to the following error " + e.getMessage(),
						e);

			}

		}

	}

	private void updateFolderSubject(IDfSession idfSession, String folderId) throws QueryException {

		cleanUpQueryDao.queryExecute(QueryConstants.QRY_UPDATE_FOLDER_SUBJECT, new Object[] { folderId }, idfSession);

	}

	private int getParentCount(IDfSession idfSession, String contentId) throws QueryException {

		return cleanUpQueryDao.getParentCount(idfSession, QueryConstants.QRY_GET_DMR_CONTENT_PARENT_COUNT,
				new Object[] { contentId });

	}

	private int isObjectExists(IDfSession idfSession, String objectId) throws QueryException {

		return cleanUpQueryDao.getQueryCount(QueryConstants.QRY_OBJECT_ID_EXISTS, new Object[] { objectId },
				idfSession);

	}

	/*
	 * public static void main(String args[]){
	 * 
	 * PurgeDataCleanupThread objPurgeDataCleanupThread=new
	 * PurgeDataCleanupThread("090f8cfa818e9103",null);
	 * objPurgeDataCleanupThread.performOperationRepoFile("090f8cfa818e9103");
	 * 
	 * }
	 */

}
