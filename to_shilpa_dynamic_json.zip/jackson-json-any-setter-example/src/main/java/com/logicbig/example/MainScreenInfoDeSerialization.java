package com.logicbig.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

public class MainScreenInfoDeSerialization {
    public static void main(String[] args) throws IOException {
        /*String jsonString = "{\"id\":\"TradeDetails\",\"title\":\"Trade Details\","
                + "\"width\":500,\"height\":300,\"xLocation\":400,\"yLocation\":200}";*/
        
        String jsonString = readFile("resources\\dynamic.json");

        System.out.println("-- before deserialization --");
        System.out.println(jsonString);

        ObjectMapper om = new ObjectMapper();
        ScreenInfo screenInfo = om.readValue(jsonString, ScreenInfo.class);
        System.out.println("-- after deserialization --");
        //System.out.println(screenInfo);
        
       // System.out.println("city : "+screenInfo.getProperties().get("roles"));
        //System.out.println("country : "+screenInfo.getProperties().get("roles"));
        Gson gson = new Gson();
        String json = gson.toJson(screenInfo.getProperties().get("roles")); 
        
       // System.out.println(screenInfo.getProperties().get("roles").toString());
        //System.out.println(json);
        
        screenInfo = om.readValue(gson.toJson(screenInfo.getProperties().get("roles")), ScreenInfo.class);
        
        System.out.println("email : "+screenInfo.getProperties().get("email"));
    }
    
	public static String readFile(String fileName) throws IOException {
	    BufferedReader br = new BufferedReader(new FileReader(fileName));
	    try {
	        StringBuilder sb = new StringBuilder();
	        String line = br.readLine();




	        while (line != null) {
	            sb.append(line);
	            sb.append("\n");
	            line = br.readLine();
	        }
	        return sb.toString();
	    } finally {
	        br.close();
	    }

}
}