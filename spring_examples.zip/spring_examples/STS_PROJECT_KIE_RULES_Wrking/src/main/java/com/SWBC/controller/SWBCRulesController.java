package com.SWBC.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.ws.rs.HeaderParam;

import org.apache.wink.json4j.OrderedJSONObject;
import org.json.JSONException;
//import org.apache.wink.json4j.JSONException;
//import org.apache.wink.json4j.OrderedJSONObject;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.SWBC.RulesService.SWBCRulesService;
import com.SWBC.model.Brm_request_info;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

@RestController
public class SWBCRulesController {

	private final SWBCRulesService swbcRulesService;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	public SWBCRulesController(SWBCRulesService swbcRulesService) {
		this.swbcRulesService = swbcRulesService;
	}

	@Autowired
	private Environment env;

	@RequestMapping(value = "/api", method = { RequestMethod.GET })
	public void getRuleAPIOutput(@HeaderParam("userName") String userName, @HeaderParam("tranType") String tranType,
			@HeaderParam("enableLookup") String enableLookup, @HeaderParam("ruleSet") String ruleSet,
			@HeaderParam("singleAPITrec") String singleAPITrec, @HeaderParam("tid") String tid,
			@HeaderParam("t_loan_no") String t_loan_no, @HeaderParam("l_suffix") String l_suffix,
			@HeaderParam("t_cov_type") String t_cov_type, @HeaderParam("t_acc_no") String t_acc_no,
			@HeaderParam("source") String source) {

		if (env.getRequiredProperty("select.transaction.types").toUpperCase().contains(tranType.toUpperCase())) {
			logger.debug("Recvd Username:::::::::::::::::::::::::::::::::" + userName + "  Start Time:"
					+ new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime()));

			AbstractApplicationContext context = new AnnotationConfigApplicationContext(Brm_request_info.class);
			Brm_request_info brm_request_info = (Brm_request_info) context.getBean("brmRequest");

			brm_request_info.setSource(source);
			brm_request_info.setTransType(tranType);
			brm_request_info.setEnableLookup(enableLookup);
			brm_request_info.setRuleVersion(ruleSet);

			if (singleAPITrec == null) {
				brm_request_info.setSingleAPITrec("false");
			} else {
				brm_request_info.setSingleAPITrec(singleAPITrec);
				brm_request_info.setAcc_no(t_acc_no);
				brm_request_info.setLoan_no(t_loan_no);
				brm_request_info.setCov_type(t_cov_type);
				brm_request_info.setTid(tid);
				brm_request_info.setLoan_suffix(l_suffix);
			}

			swbcRulesService.getRulesOutput(brm_request_info);

		}

	}

	@RequestMapping(value = "/app", method = { RequestMethod.POST, RequestMethod.HEAD })
	public void getRuleAPPOutput(

			@HeaderParam("userName") String userName, @HeaderParam("ruleSet") String ruleSet,
			@HeaderParam("tid") String tid, @HeaderParam("source") String source,
			@HeaderParam("t_loan_no") String t_loan_no, @HeaderParam("l_suffix") String l_suffix,
			@HeaderParam("t_cov_type") String t_cov_type, @HeaderParam("t_acc_no") String t_acc_no,
			@HeaderParam("tranType") String tranType, @HeaderParam("enableLookup") String enableLookup,
			@HeaderParam("singleAPITrec") String singleAPITrec)

	{

		logger.debug("Recvd Username:::::::::::::::::::::::::::::::::" + userName + "  Start Time:"
				+ new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime()));

		if (env.getRequiredProperty("select.transaction.types").toUpperCase().contains(tranType.toUpperCase())) {
			AbstractApplicationContext context = new AnnotationConfigApplicationContext(Brm_request_info.class);
			Brm_request_info brm_request_info = (Brm_request_info) context.getBean("brmRequest");

			brm_request_info.setTransType(tranType);
			brm_request_info.setEnableLookup(enableLookup);
			brm_request_info.setRuleVersion(ruleSet);
			brm_request_info.setAcc_no(t_acc_no);
			brm_request_info.setLoan_no(t_loan_no);
			brm_request_info.setCov_type(t_cov_type);
			brm_request_info.setUser(userName);
			brm_request_info.setTid(tid);
			brm_request_info.setSource(source);
			brm_request_info.setLoan_suffix(l_suffix);
			brm_request_info.setSingleAPITrec(singleAPITrec);

			swbcRulesService.getRulesOutput(brm_request_info);
		}

	}

	@RequestMapping(value = "/jsonOut", method = { RequestMethod.GET, RequestMethod.HEAD }, produces = {
			"application/json" })
	public String getJSONOut(

			@HeaderParam("dbId") String dbId)

	{

		// String dbId = String.valueOf(idIdApp);
		if (dbId == null || dbId.trim() == "") {
			return null;
		} else {

			JSONObject json = new JSONObject(swbcRulesService.getJsonApp(dbId).getJsonOut());

			json.remove("Parameters");

			return json.toString(4);
		}

	}

	@RequestMapping(value = "/jsonOutOrder", method = { RequestMethod.GET, RequestMethod.HEAD }, produces = {
			"application/json" })
	public String getJSONOutOrder(

			@HeaderParam("dbId") String dbId)

	{
		// String dbId = String.valueOf(idIdApp);

		// JsonObject jsonOutOrder = null;

		String jsonString = null;

		if (dbId == null || dbId.trim() == "") {
			return null;
			// return "Row not selected";
		} else {

			try {
				OrderedJSONObject jsonw = new OrderedJSONObject(swbcRulesService.getJsonApp(dbId).getInput_param());
				jsonString = jsonw.toString(4);
				return jsonw.toString(4);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			} catch (org.apache.wink.json4j.JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return jsonString;

	}

	@RequestMapping(value = "/testrule", method = { RequestMethod.GET})
	public String gettestrule(

			@HeaderParam("ruleSet") String ruleSet, @HeaderParam("tid") String tid,
			@HeaderParam("t_loan_no") String t_loan_no, @HeaderParam("l_suffix") String l_suffix,
			@HeaderParam("t_cov_type") String t_cov_type, @HeaderParam("t_acc_no") String t_acc_no,
			@HeaderParam("tranType") String tranType, @HeaderParam("enableLookup") String enableLookup,
			@HeaderParam("singleAPITrec") String singleAPITrec)

	{

		Brm_request_info brm_request_info = null;
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		JsonParser jp = new JsonParser();
		
		JsonElement je = null;
	
		
		if (env.getRequiredProperty("select.transaction.types").toUpperCase().contains(tranType.toUpperCase())) {
			
			
			AbstractApplicationContext context = new AnnotationConfigApplicationContext(Brm_request_info.class);
			brm_request_info = (Brm_request_info) context.getBean("brmRequest");

			brm_request_info.setTransType(tranType);
			brm_request_info.setEnableLookup(enableLookup);
			brm_request_info.setRuleVersion(ruleSet);
			brm_request_info.setAcc_no(t_acc_no);
			brm_request_info.setLoan_no(t_loan_no);
			brm_request_info.setCov_type(t_cov_type);

			brm_request_info.setTid(tid);

			brm_request_info.setLoan_suffix(l_suffix);
			brm_request_info.setSingleAPITrec(singleAPITrec);

			//swbcRulesService.getTestRule(brm_request_info);

		}
		
		je = jp.parse(swbcRulesService.getTestRule(brm_request_info));
		return gson.toJson(je);

	}

}
