package com.amex.ngdp.dataflow.common.transform;

import com.amex.ngdp.dataflow.common.model.InputRecord;

import org.apache.beam.sdk.transforms.DoFn;

/**
 * Takes a String representing comma delimited row and converts it to a BigQuery TableRow for
 * storage.
 */
public class ParseAndConvertToInputRecord extends DoFn<String, InputRecord> {

  @ProcessElement
  public void processElement(@Element String row, OutputReceiver<InputRecord> receiver) {
    String[] fields = row.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");

    // Skip the header
    if (!fields[0].equals("user_id")) {
      receiver.output(new InputRecord(fields[0], Double.parseDouble(fields[1])));
    }
  }
}
