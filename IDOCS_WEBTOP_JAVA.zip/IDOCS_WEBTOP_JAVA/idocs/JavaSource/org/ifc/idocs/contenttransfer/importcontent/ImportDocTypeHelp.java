/**
* This custom class is used to provide list of document names to the jsp page (help) for 
* document name selection while importing the document.
* 
* ########################################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* ########################################################################################
* Parag Doshi			11/13/2010		1.0				created
* ########################################################################################
*/
package org.ifc.idocs.contenttransfer.importcontent;

import java.util.HashMap;
import java.util.Map;

import org.ifc.idocs.utils.IdocsConstants;
import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.common.DfLogger;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.LocaleService;
import com.documentum.web.form.control.Button;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.form.control.databound.TableResultSet;
import com.documentum.web.formext.component.Component;

public class ImportDocTypeHelp extends Component
{
	private static final long serialVersionUID = 1L;
	private static String m_NewDocNlsProp = "org.ifc.idocs.contenttransfer.importcontent.ImportContentNlsProp";
	private static NlsResourceBundle m_nlsResourceBundle = new NlsResourceBundle(m_NewDocNlsProp);
	Map<String, String> folderCategoryMap = new HashMap<String, String>();
	
    public ImportDocTypeHelp(){
      
    }

    /**
     * Initializes the Datagrid with Document Type Details
     */
    public void onInit(ArgumentList arg0) {
    	Datagrid datagrid = null;
        try{
            datagrid = (Datagrid)getControl("mygrid", Datagrid.class);
        }catch(Exception ex){
            if(datagrid == null){
                datagrid = (Datagrid)createControl("mygrid", Datagrid.class);
            }
        }
        String currentFolderCategory = getFolderCategoryFromSession();
        DfLogger.error(this," :: ImportDocTypeHelp : FolderCategory = "+currentFolderCategory,null,null);
        String helpQry = m_nlsResourceBundle.getString("QRY_DOCTYPE_FOR_SUGGESTIONS", LocaleService.getLocale());
        helpQry = helpQry.replaceFirst("''", "'"+currentFolderCategory+"'");
        DfLogger.error(this," :: ImportDocTypeHelp : helpQry : "+helpQry,null,null);
	    try{
	    	TableResultSet typeResultSet = new TableResultSet(new String[] {"doc_name", "doc_type","doc_sub_folder","doc_proj_partner"});
	    	IDfCollection collection = IdocsUtil.executeQuery(getDfSession(), helpQry, IDfQuery.DF_READ_QUERY);
	        while(collection.next()) {
	            String docName = collection.getString("doc_name");
	            String docType = collection.getString("doc_type");
	            String docSubFolder = collection.getString("doc_sub_folder");
	            String docCategory = collection.getString("doc_proj_partner");
	            typeResultSet.add(new String[] {docName, docType,docSubFolder,docCategory});
		    }
		    if( collection != null )collection.close();
		    datagrid.getDataProvider().setScrollableResultSet(typeResultSet);
	    }catch (Exception e) {

		}
	    
    	super.onInit(arg0);
    }
    
    /**
     * This will retrieve the corresponding doc_proj_partner
     * @param currentFolderCategory - Current Folder Category
     */
    private String getDocProjPartner(String currentFolderCategory) {
    	String projPartner = null;
    	String docProjPartnerMapping = m_nlsResourceBundle.getString("DOC_PROJ_PARTNER",LocaleService.getLocale());
    	if(docProjPartnerMapping != null && docProjPartnerMapping.trim().length()>0){
    		String mappingArray[] = docProjPartnerMapping.split(",");
    		for (int i = 0; i < mappingArray.length; i++) {
				String strMapping = mappingArray[i];
				String strMappingSplitArray[] = strMapping.split(":");
				if(strMappingSplitArray!=null && strMappingSplitArray.length == 2 ){
					projPartner = strMappingSplitArray[0];
					String folderCategory = strMappingSplitArray[1];
					if(folderCategory!=null 
							&& folderCategory.trim().length()>0 
							&& folderCategory.equalsIgnoreCase(currentFolderCategory)){
						return projPartner;
					}
				}
			}
    	}
    	return projPartner;	
	}

	/**
     * Method to retrieve folder category from the session.
     * @return - String representation of the current folder category.
     */
    public String getFolderCategoryFromSession() {
    	javax.servlet.http.HttpSession httpSession = getPageContext().getSession();
		return (String)httpSession.getAttribute(IdocsConstants.MSG_FOLDER_CATEGORY);
	}
    
    /**
     * 
     */
    public void onClose(Button control, ArgumentList args){
        setComponentReturn();
    }
}
