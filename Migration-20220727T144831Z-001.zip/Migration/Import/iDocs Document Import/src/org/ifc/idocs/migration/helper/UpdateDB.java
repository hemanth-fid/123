package org.ifc.idocs.migration.helper;

import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;

import oracle.jdbc.OraclePreparedStatement;

import org.ifc.idocs.migration.importUtility.ImportUtility;
/**
 * UpdateDB - All the Migration database related connetions and common methods were implemented. 
 * @author HAnuganti
 * 
 * #############################################################################################
 * Author		            DateofChange	 Version	  ModificationHistory
 * ###########################################################################################
 * Hemachandra Anuganti 
 * ###########################################################################################
 * 
 */
public class UpdateDB extends ImportUtility {

private static Connection conn;
private static ResultSet rs;
private static PreparedStatement stmt;

	/*
	 * // TODO Auto-generated constructor stub
	 */

	public static Connection getConnection() {
		// TODO Auto-generated method stub

		//importDocLogger.info("inside getConnection()::" + UpdateDB.class);
		try {
			Class.forName(config.getString("dbImpUtilityConnections.driverName"));
			conn = DriverManager.getConnection(config.getString("dbImpUtilityConnections.connectionName"),
					config.getString("dbImpUtilityConnections.userName"),
					config.getString("dbImpUtilityConnections.passwrd"));
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("ClassNotFoundException::" + e.getMessage());
			importDocLogger.log(Level.WARNING,"ClassNotFoundException::", e);
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("SQLException::" + e.getMessage());
			importDocLogger.log(Level.WARNING,"SQLException++", e);
			e.printStackTrace();
		}
		return conn;

	}

	
	// Provide only 2 functions to use them as update/insert and select query
	// functionality

	/**
	 * Update/Insert/delete function
	 */
	public static void updateDatabase(String stringQuery) {
		// TODO Auto-generated catch block
		try {
			stmt = conn.prepareStatement(stringQuery.toString());
			stmt.executeQuery();
			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("SQLException::" + e.getMessage());
			importDocLogger.log(Level.WARNING,"SQLException::"+stringQuery, e);
			e.printStackTrace();
		}finally{
			
			try {
				stmt.close();
				stmt =null;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				importDocLogger.warning("SQLException::" + e.getMessage());
				importDocLogger.log(Level.WARNING,"SQLException Finally block::"+stringQuery, e);
				e.printStackTrace();
			}
			
		}
	}

	
	/**
	 * Insert
	 * 
	 * @param stringQuery
	 */
	public static ResultSet selectFrmDatabse(String stringQuery) {
		// TODO Auto-generated catch block
		try {
			stmt = conn.prepareStatement(stringQuery.toString());
			rs = stmt.executeQuery();
			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("SQLException::" + e.getMessage());
			importDocLogger.log(Level.WARNING,"SQLException Catch block::"+stringQuery, e);
			e.printStackTrace();
		}finally{
			
			/*try {
				stmt.close();
				stmt =null;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			
		}
		return rs;
	}
	
	/*
	 * // TODO Auto-generated constructor stub
	 */

	public static Connection getBatchConnection() {
		// TODO Auto-generated method stub

		Connection batchConn = null;

		//importDocLogger.info("inside getConnection()::" + UpdateDB.class);
		try {
			Class.forName(config.getString("dbImpUtilityConnections.driverName"));
			batchConn = DriverManager.getConnection(config.getString("dbImpUtilityConnections.connectionName"),
					config.getString("dbImpUtilityConnections.userName"),
					config.getString("dbImpUtilityConnections.passwrd"));
			} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("ClassNotFoundException::" + e.getMessage());
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			importDocLogger.warning("SQLException::" + e.getMessage());
			importDocLogger.log(Level.WARNING,"SQLException getConnection method::", e);
			e.printStackTrace();
		}
		return batchConn;
	}
	
	
	public static void executeBatch(ArrayList<String> qryList,Connection batchConn) {
		// TODO Auto-generated method stub
		
		PreparedStatement batchPstmt = null;
		String strDBExQry = "";
			try {
				importDocLogger.warning("Updating Migration Databases...!");
				for(int i=0;i<qryList.size();i++){
					//System.out.println(qryList.get(i).toString());
//					importDocLogger.warning(qryList.get(i).toString());
					strDBExQry = qryList.get(i).toString();
					batchPstmt = batchConn.prepareStatement(qryList.get(i).toString());
					batchPstmt.executeUpdate(qryList.get(i).toString());
				}
				((OraclePreparedStatement)batchPstmt).sendBatch(); 
//				int stmtCnt[] = stmt.executeBatch();
//				System.out.println("Total Number of Queries executed::"+stmtCnt);
				batchConn.commit();
				importDocLogger.warning("Updated Migration Databases Successfully...!");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				importDocLogger.warning("Failed in executing the query::"+strDBExQry+"::"+ e.getMessage());
				importDocLogger.log(Level.WARNING,"SQLException Query failed to execute::", e);
				e.printStackTrace();
			}finally{
					try {
						batchConn.commit();
						if (batchPstmt!=null){
							batchPstmt.close();
							batchPstmt =null;
						}
						if (batchConn!=null){
							batchConn.close();
							batchConn =null;
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						importDocLogger.warning("Failed in closing the statement and connection::" + e.getMessage());
						importDocLogger.log(Level.WARNING,"SQLException Finally block::", e);
						e.printStackTrace();
					}
			}
	}


	public static ResultSet selectFrmWfReportDatabse(String string, Connection wfBatchConn) {
		// TODO Auto-generated method stub

		Statement wfStmt = null;
		ResultSet wfRs = null;
			try {
				wfStmt = wfBatchConn.createStatement();
				wfRs = wfStmt.executeQuery(string);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				importDocLogger.warning("SQLException::" + e.getMessage());
				importDocLogger.log(Level.WARNING,"SQLException Catch block::"+string, e);
				e.printStackTrace();
			}finally{
				/*try {
					if (wfBatchConn!=null){
						wfBatchConn.close();
						wfBatchConn =null;
					}
					if (wfBatchConn!=null){
						wfBatchConn.close();
						wfBatchConn =null;
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					importDocLogger.warning("Failed in closing the statement and connection::" + e.getMessage());
					importDocLogger.log(Level.WARNING,"SQLException Finally block::", e);
					e.printStackTrace();
				}*/
				
			}
			return wfRs;
	}
}
