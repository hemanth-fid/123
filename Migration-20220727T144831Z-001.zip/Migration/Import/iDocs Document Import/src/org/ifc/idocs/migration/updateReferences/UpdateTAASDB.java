package org.ifc.idocs.migration.updateReferences;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.ifc.idocs.migration.helper.UpdateReferenceDB;
import org.ifc.idocs.migration.importUtility.ImportUtility;

import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.common.DfException;
/**
 * GetDiscussionDocs - Discussion documents would be uploaded. 
 * @author HAnuganti
 * 
 * #############################################################################################
 * Author		            DateofChange	 Version	  ModificationHistory
 * ###########################################################################################
 * Hemachandra Anuganti 
 * ###########################################################################################
 * 
 */
public class UpdateTAASDB extends ImportUtility{
	
	public static void updateTAASRdrls() {
		String dominoID = "";
	// TODO Auto-generated method stub
		UpdateReferenceDB.getConnection();
		ResultSet rsTAAS = UpdateReferenceDB.selectRecords(idocsProperties.getProperty("MSG_GET_TAAS_DOCUMENT_ID"),idocsProperties.getProperty("MSG_TAAS_IDENTITY"));
		try {
			while(rsTAAS.next()){
				dominoID = rsTAAS.getString("TAAS_DOCUMENT_ID");
				importDocLogger.warning("Processing document to update the TAAS DB::["+dominoID+"]");
				String selectQuery = idocsProperties.getProperty("MSG_TAAS_DOC_SELECT");
				selectQuery = selectQuery.replaceFirst("<orig_doc_id>", dominoID);
				IDfDocument document = (IDfDocument) dfSession.getObjectByQualification(selectQuery);
				if (document != null) {
					String docRObjectID = document.getString("r_object_id");
					String updateQuery = idocsProperties.getProperty("MSG_TAAS_UPDATE_QRY");
					updateQuery = updateQuery.replaceFirst("<r_object_id>", docRObjectID);
					updateQuery = updateQuery.replaceFirst("<domDocID>", dominoID);
					UpdateReferenceDB.updateRecords(updateQuery,idocsProperties.getProperty("MSG_TAAS_IDENTITY"));
					String updtQry = idocsProperties.getProperty("MSG_TAAS_UPDATE_QRY1");
					updtQry = updtQry.replaceFirst("<r_object_id>", docRObjectID);
					updtQry = updtQry.replaceFirst("<domDocID>", dominoID);
					UpdateReferenceDB.updateRecords(updtQry, idocsProperties.getProperty("MSG_TAAS_IDENTITY"));
				}else{
					importDocLogger.warning("Documet Does not exist in IFCDocs Documentum for the Lagacy ID::["+dominoID+"]");
				}
			}
			if(rsTAAS != null){
				rsTAAS.close();
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			importDocLogger.warning("Issue while processing the Legacy ID for TAAS DB Update::["+dominoID+"]");
			importDocLogger.warning("Catch block ::   SQLException" + e1.getMessage());
		} catch (DfException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			importDocLogger.warning("Issue while processing the Legacy ID for TAAS DB Update::["+dominoID+"]");
			importDocLogger.warning("Catch block ::   Dfexception" + e.getMessage());
		}
	}
}
