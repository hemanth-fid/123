/**
* This component for importing document to idocs and to update attribute fields while 
* importing the document.
* 
* ###############################################################################
* Author		 	  DateofChange	 Version		ModificationHistory
* ###############################################################################
* Parag Doshi			11/01/2010		1.0				created
* ###############################################################################
*/
package org.ifc.idocs.contenttransfer.importcontent;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import org.ifc.idocs.constants.IDocsConstants;
import org.ifc.idocs.queryservices.DocTypeTableStructure;
import org.ifc.idocs.queryservices.IDocsQRYVO;
import org.ifc.idocs.utils.IdocsConstants;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfFolder;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfTime;
import com.documentum.fc.common.IDfTime;
import com.documentum.nls.NlsResourceBundle;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.common.LocaleService;
import com.documentum.web.form.control.DateInput;
import com.documentum.web.form.control.Label;
import com.documentum.web.form.control.Radio;
import com.documentum.web.form.control.Text;
import com.documentum.web.form.control.databound.DataDropDownList;
import com.documentum.web.form.control.databound.TableResultSet;
import com.documentum.web.formext.docbase.ObjectCacheUtil;

public class ImportContent extends com.documentum.webcomponent.library.contenttransfer.importcontent.ImportContent
{
	private static final String SEC_CLASSIFICATION_CODE = "sec_classification_code";
	private static final String FOLDER_CATEGORY = "folder_category";
	private static final String EMPTY_STRING = "";
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static String m_NewDocNlsProp = "org.ifc.idocs.contenttransfer.importcontent.ImportContentNlsProp";
	private static NlsResourceBundle m_nlsResourceBundle = new NlsResourceBundle(m_NewDocNlsProp);
	protected String strFolderCategory = EMPTY_STRING;
	private String strFolderType=EMPTY_STRING, folderTitle=EMPTY_STRING, subFolder=EMPTY_STRING;
	private IDfFolder parentFolder=null;
	private String selectedDocTypeCode = IDocsConstants.MSG_EMPTY_STRING; 
	private String selectedSecClassification = IDocsConstants.MSG_EMPTY_STRING;

    public ImportContent() {
    }
    
    /**
     * This method fetches the folder category of the current folder.
     */
    public void onInit(ArgumentList args){
        try {
        	strFolderType=EMPTY_STRING;
        	folderTitle=EMPTY_STRING;
        	subFolder=EMPTY_STRING;
        	strFolderCategory = EMPTY_STRING;

        	super.onInit(args);
        	DfLogger.info(this, " :: onInit : Reset the Object Name ", null, null);
        	String strFolderId = EMPTY_STRING, secClassCode=EMPTY_STRING;
	        strFolderId=args.get("objectId");

	        IDfSession dfsess = getDfSession();
	        
	        IDfFolder docFolder = (IDfFolder)ObjectCacheUtil.getObject(getDfSession(), strFolderId);
	        if(docFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_PROJ_FOLDER", LocaleService.getLocale())) 
	        		|| docFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_INSTIT_FOLDER", LocaleService.getLocale())) 
	        		|| docFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_COUNTRY_FOLDER", LocaleService.getLocale()))){
		        parentFolder = docFolder;
	        }else{
		        docFolder = (IDfFolder)dfsess.getObject(docFolder.getFolderId(0));
		        if(docFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_PROJ_FOLDER", LocaleService.getLocale())) 
		        		|| docFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_INSTIT_FOLDER", LocaleService.getLocale())) 
		        		|| docFolder.getTypeName().equals(m_nlsResourceBundle.getString("MSG_IDOCS_COUNTRY_FOLDER", LocaleService.getLocale()))){
		        	parentFolder = docFolder;
		        }else{
		        	parentFolder=(IDfFolder)dfsess.getObject(docFolder.getFolderId(0));
		        }
	        }

	        strFolderType = parentFolder.getTypeName();
	        strFolderCategory = parentFolder.getString(FOLDER_CATEGORY);
	        secClassCode = parentFolder.getString(SEC_CLASSIFICATION_CODE);
	        
	        DfLogger.debug(this," :: onInit : strFolderType : "+strFolderType,null,null);
	        DfLogger.debug(this," :: onInit : strFolderCategory : "+strFolderCategory,null,null);
	        DfLogger.debug(this," :: onInit : secClassCode : "+secClassCode,null,null);
	        setFolderCategoryToSession(strFolderCategory);
	        setupTypeList();
			setAuthor();
			setIFCDocsAuthor();
			setDocDate();
			setupSecurityClassification(secClassCode);
		} catch (DfException e) {
			DfLogger.error(this," :: onInit Exception >> "+e.getMessage(),null,e);
		}
    }
       
    /**
     * This utility method will set the folder category to HTTP Session for later use.
     * @param strFolderCategory - Current folder category
     */
    public void setFolderCategoryToSession(String strFolderCategory) {
    	javax.servlet.http.HttpSession httpSession = getPageContext().getSession();
		httpSession.setAttribute(IdocsConstants.MSG_FOLDER_CATEGORY,strFolderCategory);
		DfLogger.debug(this," ::  FolderCategory Set to : "+strFolderCategory,null,null);
	}
    
    /**
     * Method to clear the folder category from the session.
     */
    public void clearFolderCategoryToSession() {
    	javax.servlet.http.HttpSession httpSession = getPageContext().getSession();
		httpSession.setAttribute(IdocsConstants.MSG_FOLDER_CATEGORY,IDocsConstants.MSG_EMPTY_STRING);
	}

    /**
     * Sets the sub-folder title to the document based on the value selected by the user.
     */
	public void onRender() {
		DfLogger.debug(this," :: onRender >> ",null,null);
	    Label label = (Label)getControl("subfolder", Label.class);
		DfLogger.debug(this," :: onRender : Set subFolder : "+subFolder,null,null);
		label.setLabel(subFolder);
	    super.onRender();       
    }
	
	public void onRenderEnd() {
		DfLogger.debug(this," :: onRenderEnd >> ",null,null);
		DataDropDownList typeList = (DataDropDownList)getControl("docTypeList", DataDropDownList.class);
		DataDropDownList securityClassification = (DataDropDownList)getControl("securityClassification", DataDropDownList.class);
		DfLogger.debug(this," :: onRenderEnd : Current Sec Classification Value="+ securityClassification.getValue(),null,null);
		DfLogger.debug(this," :: onRenderEnd : Update the SubFolder Title with "+ typeList.getValue(),null,null);
		try {
			onSelectDoc(typeList, null);
			onSelectSecClassification(securityClassification, null);
		} catch (DfException e) {
			DfLogger.error(this," :: onRenderEnd : Update the SubFolder Title ERROR : "+e.getMessage(),null,null);
			e.printStackTrace();
		}
		super.onRenderEnd();
	}

	/**
	 * Automatically populates the author name to current user name.
	 * @throws DfException
	 */
	private void setAuthor() throws DfException {
		String author=EMPTY_STRING;
		author=getDfSession().getLoginUserName();
		DfLogger.debug(this, " :: setAuthor : "+author, null, null);
		Label authors = (Label)getControl("authors", Label.class);
		authors.setLabel(author);
	}
	

	/**
	 * Automatically populates the author name to current user name.
	 * @throws DfException
	 */
	private void setIFCDocsAuthor() throws DfException {
		String author=EMPTY_STRING;
		author=getDfSession().getLoginUserName();
		DfLogger.debug(this, " :: setAuthor : "+author, null, null);
		Label authors = (Label)getControl("ifcdocs_authors", Label.class);
		authors.setLabel(author);
	}
	
	/**
	 * This method sets the document_date of the document to current date.
	 */
	private void setDocDate() {
		DateInput documentDate = (DateInput)getControl("docDate",DateInput.class);
		documentDate.setValue(new DfTime(new SimpleDateFormat(
		"yyyy/MM/dd").format(new Date()), "mon dd, yyyy").asString("month dd, yyyy"));
	}

	/**
	 * Updated the level2 folder names on the document based on the  user selection
	 * @param typeList - Dropdown list control
	 * @param args - Context arguments
	 * @throws DfException
	 */
	public void onSelectDoc(DataDropDownList typeList,ArgumentList args) throws DfException{
		selectedDocTypeCode = typeList.getValue(); 
		DfLogger.debug(this, " :: onSelectDoc :: selectedDocTypeCode = "+selectedDocTypeCode, null, null);
		String [] typeResults =null;
		String columnNames[] = {"subfolder_title","doc_type_name"};
		DocTypeTableStructure docTypeTableStructure = new DocTypeTableStructure(IDocsQRYVO.getTemplateInfoTableData(getDfSession()));
		typeResults=docTypeTableStructure.getTableResultSetColumnWithWhereClausesWithDistinctAsArray(columnNames, FOLDER_CATEGORY, strFolderCategory, "is_active","Yes","doc_type_code",typeList.getValue(),"subfolder_title");
    	if(typeResults.length >= 2){
    		subFolder = typeResults[0];
    		folderTitle =typeResults[1];
    	}
    	if(subFolder != null && subFolder.length() >0){
    		DfLogger.info(this, "Values are existed no need to query again", null, null);
    	}else {
    	DfQuery query = new DfQuery();
		String subFolderQry = m_nlsResourceBundle.getString("QUERY_FOLDER_TITLE", LocaleService.getLocale());
    	subFolderQry = subFolderQry.replaceFirst("''", "'"+typeList.getValue()+"'");
    	subFolderQry = subFolderQry.replaceFirst("''", "'"+strFolderCategory+"'");
    	query.setDQL(subFolderQry);
    	DfLogger.debug(this, " :: onSelectDoc :: selectedDocTypeCode : subFolderQry="+subFolderQry, null, null);
    	IDfCollection dfCollection = query.execute(getDfSession(), 0);
    	if(dfCollection.next()){
    		subFolder = dfCollection.getString("subfolder_title");
    		folderTitle = dfCollection.getString("doc_type_name");
    		dfCollection.close();
    	}
    	if(dfCollection != null)
    		dfCollection.close();
    	}
    	updateSubfolder(subFolder);
    }
	
	/**
	 * 
	 * @param typeList
	 * @param args
	 * @throws DfException
	 */
	public void onSelectSecClassification(DataDropDownList typeList,ArgumentList args) throws DfException{
		selectedSecClassification = typeList.getValue(); 
		DfLogger.debug(this, " :: onSelectSecClassification: "+selectedSecClassification, null, null);
		
	}

	/**
	 * This method sets the subfolder of the document
	 * @param subFolder
	 * @throws DfException
	 */
	private void updateSubfolder(String subFolder) throws DfException {
		Label label = (Label)getControl("subfolder", Label.class);
    	label.setLabel(subFolder);
    	DfLogger.debug(this, " :: updateSubfolder ="+subFolder, null, null);
	}

	/**
	 * Prepares the dropdown list with permitted document subtype names
	 * @throws DfException
	 */
	public void setupTypeList() throws DfException{
		DfLogger.debug(this," :: setupTypeList...!!!",null,null);
		TableResultSet typeResultSet = null;
		DataDropDownList typeList = (DataDropDownList)getControl("docTypeList", DataDropDownList.class);
        typeList.clearOptions();
        DocTypeTableStructure docTypeTableStructure = new DocTypeTableStructure(IDocsQRYVO.getTemplateInfoTableData(getDfSession()));
        String columnNames[] = {"doc_type_code","doc_type_name"};
        typeResultSet=docTypeTableStructure.getTableResultSetColumnWithWhereClausesWithDistinct(columnNames, FOLDER_CATEGORY, strFolderCategory, "is_active","Yes", "doc_type_code");
        if(typeResultSet !=null){
        	DfLogger.debug(this, "No need to Query again Values are existed", null, null);
        }else{
        	typeResultSet=new TableResultSet(new String[] {"doc_type_code", "doc_type_name"});
        	typeResultSet.add(new String[] {EMPTY_STRING, "Select"});
        	DfQuery query = new DfQuery();
            String typeListQry = m_nlsResourceBundle.getString("QUERY_SELECT_TYPE", LocaleService.getLocale());
            typeListQry = typeListQry.replaceFirst("''", "'" + strFolderCategory + "'");
            DfLogger.debug(this," :: setupTypeList : typeListQry : "+typeListQry,null,null);
            query.setDQL(typeListQry);
            IDfCollection collection = query.execute(getDfSession(), 0);
            while(collection.next()){        
                String typeName = collection.getString("doc_type_code");
                String typeLabel = collection.getString("doc_type_name");
                typeResultSet.add(new String[] {
                		typeName, typeLabel
                });
            }
            if(collection != null )collection.close();
        }
        typeList.getDataProvider().setScrollableResultSet(typeResultSet);
    }
	
	/**
	 * This method updated the security classification dropdown.
	 * @param secClassCode - Current security classification code.
	 * @throws DfException
	 */
	private void setupSecurityClassification(String secClassCode) throws DfException {
		TableResultSet templateResultSet = new TableResultSet(new String[] {
				"security_classification_code", "security_classification"
            });
		selectedSecClassification = secClassCode;
		if(secClassCode.equals(IDocsConstants.MSG_OFFICIAL_CODE)) {
			templateResultSet.add(new String[]{IDocsConstants.MSG_OFFICIAL_CODE,IDocsConstants.MSG_OFFICIAL_USE_ONLY});
			templateResultSet.add(new String[]{IDocsConstants.MSG_CONFIDENTIAL_CODE,IDocsConstants.MSG_CONFIDENTIAL});
			templateResultSet.add(new String[]{IDocsConstants.MSG_STRICTLY_CONFIDENTIAL_CODE,IDocsConstants.MSG_STRICTLY_CONFIDENTIAL});
		} else if(secClassCode.equals(IDocsConstants.MSG_CONFIDENTIAL_CODE)) {
			templateResultSet.add(new String[]{IDocsConstants.MSG_CONFIDENTIAL_CODE,IDocsConstants.MSG_CONFIDENTIAL});
			templateResultSet.add(new String[]{IDocsConstants.MSG_STRICTLY_CONFIDENTIAL_CODE,IDocsConstants.MSG_STRICTLY_CONFIDENTIAL});
		} else if(secClassCode.equals(IDocsConstants.MSG_STRICTLY_CONFIDENTIAL_CODE)) {
			templateResultSet.add(new String[]{IDocsConstants.MSG_STRICTLY_CONFIDENTIAL_CODE,IDocsConstants.MSG_STRICTLY_CONFIDENTIAL});
		}else{
			templateResultSet.add(new String[]{IDocsConstants.MSG_OFFICIAL_CODE,IDocsConstants.MSG_OFFICIAL_USE_ONLY});
			templateResultSet.add(new String[]{IDocsConstants.MSG_CONFIDENTIAL_CODE,IDocsConstants.MSG_CONFIDENTIAL});
			templateResultSet.add(new String[]{IDocsConstants.MSG_STRICTLY_CONFIDENTIAL_CODE,IDocsConstants.MSG_STRICTLY_CONFIDENTIAL});
		}
			
		DataDropDownList typeList = (DataDropDownList)getControl("securityClassification", DataDropDownList.class);
        typeList.getDataProvider().setScrollableResultSet(templateResultSet);
	}
	
	 
    protected Map getObjectAttributes(){
            Map userFilledValues = super.getObjectAttributes();
            userFilledValues.put(IDocsConstants.MSG_DOC_SUBTYPE_NAME, getFolderTitle());
            userFilledValues.put(IDocsConstants.MSG_FOLDER_TITLE, getSubFolder());
            userFilledValues.put(IDocsConstants.MSG_DOC_SUBTYPE_CODE, getSelectedDocType());
            userFilledValues.put(IDocsConstants.MSG_DOCUMENT_DATE, getDocDate());
            userFilledValues.put(IDocsConstants.MSG_SEC_CLASSIFICATION,getSelectedSecClassification());
            printMap(userFilledValues);            
            return userFilledValues;
    }

   
    
    public void printMap(Map Map) {
		Iterator it = Map.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry e = (Map.Entry) it.next();
			DfLogger.info(this, e.getKey() + " " + e.getValue(), null, null);
		}
		DfLogger.info(this, "________________________________", null, null);
	}
    
   /**
	 * This retrns the object type of the navigated folder.
	 */
	protected String getTypeSelection(){
		String strType = EMPTY_STRING;
		if(strFolderType.equals(IdocsConstants.PROJ_FOLDER_TYPE)){
			strType = IdocsConstants.PROJ_DOC_TYPE;
		} else if (strFolderType.equals(IdocsConstants.INSTITUTION_FOLDER_TYPE)){
			strType = IdocsConstants.INSTITUTION_DOC_TYPE;
		} else if (strFolderType.equals(IdocsConstants.COUNTRY_FOLDER_TYPE)){
			strType = IdocsConstants.COUNTRY_DOC_TYPE;
		}
        DfLogger.info(this, " :: getTypeSelection : strType : "+strType, null, null);
        
    	return strType;
    }
	
	/**
	 * Returns the current author name set on the document.
	 * @return
	 */
	public String getAuthor() {
		Text authors = (Text)getControl("authors", Text.class);
		return authors.getValue();
	}
	
	/**
	 * Returns the current author name set on the document.
	 * @return
	 */
	public String getIFCDosAuthor() {
		Label authors = (Label)getControl("ifcdocs_authors", Label.class);
		return authors.getLabel();
	}
	
	  /**
	    * Returns the current document date set on the document.
	    * @return
	    */
	    
	public IDfTime getDocDate() {
		DateInput documentDate = (DateInput) getControl("docDate",
				DateInput.class);
		IDfTime dfTime = new DfTime(documentDate.toDate());
		if(dfTime.compareTo(new DfTime())== 1){
			return new DfTime();
		}else{
			return dfTime;
		}
	}
	
	/**
	 * Returns the current subfolder set on the document.
	 * @return
	 */
	public String getSubFolder(){
		Label label = (Label)getControl("subfolder", Label.class);
		return label.getLabel();
	}
	
	/**
	 * Returns the current folder_title set on the document.
	 * @return
	 */
	public String getFolderTitle(){
		return folderTitle;
	}
	
	/**
	 * Returns the version selected during the checkin.
	 * @return
	 */
	public String getVersionLabel() {
		Radio checkinAsDraft = (Radio)getControl("checkinAsDraft");
		if(checkinAsDraft.getValue() == true ){
			DfLogger.info(this, " :: VersionSelection ="+MSG_DRAFT, null, null);
			return MSG_DRAFT;
		}else{
			DfLogger.info(this, " :: VersionSelection ="+MSG_VERSION, null, null);
			return MSG_VERSION;
		}
	}
	
	/**
	 * Returns the Folder Object of the parent folder.
	 * @return
	 */
	public IDfFolder getParentFolder(){
		return parentFolder;
	}
	
	/**
	 * Returns the selected doc type.
	 * @return
	 */
	public String getSelectedDocType(){
		return selectedDocTypeCode;
	}
	
	public String getSelectedSecClassificationCode(){
		DfLogger.debug(this, " :: getSelectedSecClassification: selectedSecClassification="+selectedSecClassification, null, null);
		return selectedSecClassification;
	}
	
	public String getSelectedSecClassification(){
		String returnValue = IDocsConstants.MSG_EMPTY_STRING;
		if(selectedSecClassification.equals(IDocsConstants.MSG_OFFICIAL_CODE)) {
			returnValue = IDocsConstants.MSG_OFFICIAL_USE_ONLY;
		} else if(selectedSecClassification.equals(IDocsConstants.MSG_CONFIDENTIAL_CODE)) {
			returnValue = IDocsConstants.MSG_CONFIDENTIAL;			
		} else if(selectedSecClassification.equals(IDocsConstants.MSG_STRICTLY_CONFIDENTIAL_CODE)) {
			returnValue = IDocsConstants.MSG_STRICTLY_CONFIDENTIAL;			
		}
		DfLogger.debug(this, " :: getSelectedSecClassification: returnValue"+returnValue, null, null);
		return returnValue;
	}
	
	public static final String MSG_DRAFT = "Draft";
	public static final String MSG_VERSION = "Version";
}