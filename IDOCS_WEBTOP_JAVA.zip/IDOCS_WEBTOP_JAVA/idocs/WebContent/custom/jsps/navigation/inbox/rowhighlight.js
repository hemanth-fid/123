var oldColour = "#ffffff";
var highlightIE = "#b6c7e6";
var highlightMoz = "rgb(182,199,230)";
function onclickCell(source)
{
var table = source.parentNode.parentNode.parentNode;
var checkbox = table.getElementsByTagName("input").item(0);
var highlightColor;
if (g_clientInfo.isBrowser(ClientInfo.MSIE))
{
highlightColor = highlightIE;
}
else
{
highlightColor = highlightMoz;
}
var cell = table.getElementsByTagName("td").item(0);
if (checkbox.checked)
{
if(cell.style.backgroundColor != highlightColor)
{
oldColour  = cell.style.backgroundColor;
colorCells(table, highlightColor);
}
}
else
{
if(cell.style.backgroundColor == highlightColor)
{
colorCells(table, oldColour);
}
}
}
function colorCells(node, color)
{
var elements = node.getElementsByTagName("td");
for(i=0; i < elements.length; i++)
{
elements.item(i).style.backgroundColor = color;
}
}
