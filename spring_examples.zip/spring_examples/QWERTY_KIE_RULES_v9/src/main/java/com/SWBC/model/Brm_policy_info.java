package com.SWBC.model;

import java.util.Date;

public class Brm_policy_info 
{
	
	//Lower case: CTRL+SHIFT+Y (CMD+SHIFT+Y on Mac OS X)
	//Upper case: CTRL+SHIFT+X (CMD+SHIFT+X on Mac OS X)
	
	private String transaction_id;
	private String transaction_type;
	private String po_vsi_policy_no;
	private String po_account_no;
	private String po_loan_no;
	private String po_loan_suffix;
	private String po_coverage_type;
	private int pt_tran_sequence;
	private String pt_policy_status;
	private Date pt_voided_date;
	private Date pt_effective_date;
	private Date pt_expiration_date;
	private Date pt_refund_date;
	private String pt_refund_reason;
	private String comment;
	private Date transaction_rei_date;
	
	public String getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}
	public String getTransaction_type() {
		return transaction_type;
	}
	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}
	public String getPo_vsi_policy_no() {
		return po_vsi_policy_no;
	}
	public void setPo_vsi_policy_no(String po_vsi_policy_no) {
		this.po_vsi_policy_no = po_vsi_policy_no;
	}
	public String getPo_account_no() {
		return po_account_no;
	}
	public void setPo_account_no(String po_account_no) {
		this.po_account_no = po_account_no;
	}
	public String getPo_loan_no() {
		return po_loan_no;
	}
	public void setPo_loan_no(String po_loan_no) {
		this.po_loan_no = po_loan_no;
	}
	public String getPo_loan_suffix() {
		return po_loan_suffix;
	}
	public void setPo_loan_suffix(String po_loan_suffix) {
		this.po_loan_suffix = po_loan_suffix;
	}
	public String getPo_coverage_type() {
		return po_coverage_type;
	}
	public void setPo_coverage_type(String po_coverage_type) {
		this.po_coverage_type = po_coverage_type;
	}
	public int getPt_tran_sequence() {
		return pt_tran_sequence;
	}
	public void setPt_tran_sequence(int pt_tran_sequence) {
		this.pt_tran_sequence = pt_tran_sequence;
	}
	public String getPt_policy_status() {
		return pt_policy_status;
	}
	public void setPt_policy_status(String pt_policy_status) {
		this.pt_policy_status = pt_policy_status;
	}
	public Date getPt_voided_date() {
		return pt_voided_date;
	}
	public void setPt_voided_date(Date pt_voided_date) {
		this.pt_voided_date = pt_voided_date;
	}
	public Date getPt_effective_date() {
		return pt_effective_date;
	}
	public void setPt_effective_date(Date pt_effective_date) {
		this.pt_effective_date = pt_effective_date;
	}
	public Date getPt_expiration_date() {
		return pt_expiration_date;
	}
	public void setPt_expiration_date(Date pt_expiration_date) {
		this.pt_expiration_date = pt_expiration_date;
	}
	public Date getPt_refund_date() {
		return pt_refund_date;
	}
	public void setPt_refund_date(Date pt_refund_date) {
		this.pt_refund_date = pt_refund_date;
	}
	public String getPt_refund_reason() {
		return pt_refund_reason;
	}
	public void setPt_refund_reason(String pt_refund_reason) {
		this.pt_refund_reason = pt_refund_reason;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public Date getTransaction_rei_date() {
		return transaction_rei_date;
	}
	public void setTransaction_rei_date(Date transaction_rei_date) {
		this.transaction_rei_date = transaction_rei_date;
	}

}
