package gov.iwa.fema.export.bean;

public class FemaObjectBean {

	private String r_object_id;
	
	private String invoice_no;
	private String vendor_name;
	private String department;
	private String po_no;


	public String getR_object_id() {
		return r_object_id;
	}
	public void setR_object_id(String r_object_id) {
		this.r_object_id = r_object_id;
	}
	
	public String getInvoice_no() {
		return invoice_no;
	}
	public void setInvoice_no(String invoice_no) {
		this.invoice_no = invoice_no;
	}
	public String getVendor_name() {
		return vendor_name;
	}
	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getPo_no() {
		return po_no;
	}
	public void setPo_no(String po_no) {
		this.po_no = po_no;
	}


}