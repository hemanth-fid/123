package com.SWBC.preproc;

import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.util.Properties;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieSession;

import com.SWBC.model.PreProc_Doca_Ucap;
import com.SWBC.model.PreProc_loan_line;
import com.documentum.com.DfClientX;
import com.documentum.fc.client.DfSingleDocbaseModule;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfLoginInfo;


public class PreProcMainService{
	
	public static final String LOG_HEADER = "com.swbc.doca.exception.queue.CreateQuery("
			+ "1.0" + ")";

	private static IDfSession mSess;
	private static IDfSessionManager mSessMgr;
	private static String mRunMode = "";
	private Connection mDBConn = null;

	private final String namespace = "doca";
	private final String dbEndpoint = "DocbaseDirectSQLConnection";
	
	
	public static void main(String[] args) throws IOException {
		
		mRunMode = "Application";
		PreProcMainService prog = new PreProcMainService();
		
//		Properties prop = new Properties();
//		InputStream input = new FileInputStream("preprocapp.properties");
//		prop.load(input);
		
		PreProc_Doca_Ucap docaObj = new PreProc_Doca_Ucap();
		

		try {
//			prog.getSessionLocal();
//
//			String dql = prop.getProperty("select.input.qyr")+" where r_object_id = '09020af0814f91a9' ";
//			
//			System.out.println(dql);
//			
//			IDfCollection coll = DCTMOpsUtils.executeQuery(mSess, dql);		
//			docaObj = prog.setDocaAttr(docaObj, coll);

//			callBRMApi();
			
			KieSession kieSession= KieServices.Factory.get().getKieClasspathContainer().newKieSession("preprocrules_id");
			docaObj.setProperty_address_1("Test Addr");
			kieSession.insert(docaObj);
			kieSession.fireAllRules();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		finally {
//			if (input != null) {
//				try {
//					input.close();
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
//			}
//		}
		
	
		
	}
	
	



	private IDfSessionManager getSessionLocal() throws DfException 
	{ 
		//Create a client object using a factory method in DfClientX.
		DfClientX clientx = new DfClientX(); 
		IDfClient client = clientx.getLocalClient(); 

		//Call a factory method to create the session manager. 
		mSessMgr = client.newSessionManager(); 
		
		IDfLoginInfo loginInfo = clientx.getLoginInfo(); 
		loginInfo.setUser("dmadmin"); 
		loginInfo.setPassword("DCTMadmin"); 
		
		// set single identity for all docbases 
		mSessMgr.setIdentity("swbc_bpm", loginInfo);
		mSess = mSessMgr.getSession("swbc_bpm");
		return mSessMgr;
	
	}



	public void setRunmode(String mRunMode) 
	{
		this.mRunMode = mRunMode;
	}

	public PreProc_Doca_Ucap setDocaAttr(PreProc_Doca_Ucap obj, IDfCollection coll ) throws DfException
	{
		
		PreProc_loan_line loanLine = new PreProc_loan_line();
		
		while(coll.next())
		{
			obj.setDocument_type(coll.getString("document_type"));
			obj.setTransaction_id(coll.getString("transaction_id"));
			loanLine.setAcc_no(coll.getString("account_number"));
			loanLine.setCov_type(coll.getString("cov_type"));
			loanLine.setLoan_no(coll.getString("document_type"));
			loanLine.setLoan_suffix(coll.getString("document_type"));
			loanLine.setTid(coll.getString("document_type"));
			
			
		}
		
		
		
		return obj;
		
	}

	
	public static void callBRMApi()
	{
		
		
		
		try {
			URL url = new URL("http://localhost:8080/api");
			
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("POST");
			
			StringBuilder sb = new StringBuilder();
			sb.append("userName=");
			sb.append("dmadmin");
			sb.append("&");
			sb.append("tranType=");
			sb.append("XLC");
			sb.append("&");
			sb.append("enableLookup=");
			sb.append("dmadmin");
			sb.append("&");
			sb.append("ruleVersion=");
			sb.append("dmadmin");
			sb.append("&");
			sb.append("singleAPITrec=");
			sb.append("dmadmin");
			sb.append("&");
			sb.append("tid=");
			sb.append("dmadmin");
			sb.append("&");
			sb.append("t_loan_no=");
			sb.append("dmadmin");
			sb.append("&");
			sb.append("l_suffix=");
			sb.append("dmadmin");
			sb.append("&");
			sb.append("t_cov_type=");
			sb.append("dmadmin");
			sb.append("&");
			sb.append("t_acc_no=");
			sb.append("dmadmin");

			
			conn.setDoOutput(true);
			DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
			wr.writeBytes(sb.toString());
			wr.flush();
			wr.close();
			conn.getResponseCode();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

}
