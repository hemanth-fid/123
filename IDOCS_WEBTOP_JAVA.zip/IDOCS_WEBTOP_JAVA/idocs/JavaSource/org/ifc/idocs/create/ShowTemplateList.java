package org.ifc.idocs.create;

import java.util.HashMap;
import java.util.Map;

import org.ifc.idocs.utils.IdocsUtil;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.common.DfLogger;
import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.Control;
import com.documentum.web.form.control.Button;
import com.documentum.web.form.control.Hidden;
import com.documentum.web.form.control.databound.Datagrid;
import com.documentum.web.form.control.databound.TableResultSet;
import com.documentum.web.formext.component.Component;

public class ShowTemplateList extends Component{

	private static final long serialVersionUID = 1L;
	Map<String, String> folderCategoryMap = new HashMap<String, String>();
	String templateName = ""; 
    public ShowTemplateList(){
      
    }

    /**
     * Initializes the Datagrid with Document Type Details
     */
    public void onInit(ArgumentList arg) {
    	String  folderCategory = arg.get("folderCategory");
    	Datagrid datagrid = null;
        try{
            datagrid = (Datagrid)getControl("mygrid", Datagrid.class);
        }catch(Exception ex){
            if(datagrid == null){
                datagrid = (Datagrid)createControl("mygrid", Datagrid.class);
            }
        }
    
        String templateListQuery = "select distinct object_name from idocs_document doc, dm_dbo.IDOCS_TEMPLATE_INFO ti " +
		"where folder('/Templates/IFCDocs') and doc.object_name=ti.template_title " 
		+" and (ti.category_name='"
		+ folderCategory
		+ "' OR( '"
		+ folderCategory
		+ "' <> 'Country Documents' and doc_category=' ')) order by object_name";
        DfLogger.debug(this," :: ShowTemplateList : templateListQuery : "+templateListQuery,null,null);
	    try{
	    	TableResultSet typeResultSet = new TableResultSet(new String[] {"object_name", "doc_category"});
	    	IDfCollection collection = IdocsUtil.executeQuery(getDfSession(), templateListQuery, IDfQuery.DF_READ_QUERY);
	        while(collection.next()) {
	            String docName = collection.getString("object_name");
	            typeResultSet.add(new String[] {docName});
		    }
		    if( collection != null )collection.close();
		    datagrid.getDataProvider().setScrollableResultSet(typeResultSet);
	    }catch (Exception e) {

		}
	    
    	super.onInit(arg);
    }
    
    public void onDoubleClick(Control ctrl, ArgumentList args){
    	templateName = args.get("object_name");
    	setReturnValue("templatename", templateName);
    	setComponentReturn();
    }
    
    public void onOk(Button control, ArgumentList args){
    	Hidden singleSelectTemplateName = (Hidden)getControl("hiddenTemplateName");
    	if(singleSelectTemplateName != null){
    		String selectedTemplateName = singleSelectTemplateName.getValue();
    		if(selectedTemplateName != null && selectedTemplateName .trim().length() > 0){
    			templateName = selectedTemplateName; 
    		}
    	}
    	setReturnValue("templatename", templateName);
    	setComponentReturn();
    }
    
    /**
     * 
     */
    public void onClose(Button control, ArgumentList args){
    	setComponentReturn();
    }
}
