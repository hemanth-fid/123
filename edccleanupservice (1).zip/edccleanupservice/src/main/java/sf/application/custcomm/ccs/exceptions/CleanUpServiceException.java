/***************************************************************************
 * State Farm
 * Version Template: 2012
 *
 * File Name: ExportProcessException.java
 *
 * Version     ChgDate          Author           Comments
 * ________   __________       ________         ___________
 * 1.0        05/31/2013         t7p9         Initial Creation 
 *
 ***************************************************************************/

package sf.application.custcomm.ccs.exceptions;
import com.documentum.fc.common.DfLogger;

/**
 * <i>ExportProcessException</i> is a custom exception class that is built on
 * extending the Exception.
 * 
 */
public class CleanUpServiceException extends Exception {

	private static final long serialVersionUID = 1L;

	/**
	 * Logs the error message captured within the work-flow timer service
	 * 
	 * @param message
	 *            Exception message description
	 */
	public CleanUpServiceException(String message) {
		super(message);
		DfLogger.error(this, message, null, null);
	}

	/**
	 * Logs the error message and cause captured within the work-flow timer service
	 * 
	 * @param message
	 *            Exception message description
	 * @param throwable
	 *            Throwable class
	 */
	public CleanUpServiceException(String message, Throwable throwable) {
		super(message, throwable);
		DfLogger.error(this, message, null, throwable);
	}

}
