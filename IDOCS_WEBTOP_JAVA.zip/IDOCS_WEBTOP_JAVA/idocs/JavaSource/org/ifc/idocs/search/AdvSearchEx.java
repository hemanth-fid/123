package org.ifc.idocs.search;

import com.documentum.web.common.ArgumentList;
import com.documentum.web.form.control.Radio;
import com.documentum.web.form.control.Text;
import com.documentum.web.formext.control.docbase.search.SearchObjectTypeDropDownList;

public class AdvSearchEx extends com.documentum.webcomponent.library.advsearch.AdvSearchEx
{

    private static final long serialVersionUID = 1L;
 
    public AdvSearchEx()
    {
    }

    public void onInit(ArgumentList args)
    {
        super.onInit(args);
        updateControlState("Advanced Search", args);
    }

    public void updateControlState(String radioLabel, ArgumentList args)
    {
        Text m_text = (Text)getControl("projpartctrl", Text.class);
        Radio m_radio1 = (Radio)getControl("specificlocationradio", Radio.class);
        Radio m_radio2 = (Radio)getControl("currentlocationradio", Radio.class);
        SearchObjectTypeDropDownList m_searchobjecttypedropdownlist = (SearchObjectTypeDropDownList)getControl("objecttypectrl", SearchObjectTypeDropDownList.class);
        if(radioLabel.equals("Advanced Search"))
        {
            m_text.setEnabled(false);
            m_radio1.setEnabled(true);
            m_radio2.setEnabled(true);
            m_searchobjecttypedropdownlist.setEnabled(true);
        } else
        if(radioLabel.equals("Catalog Search"))
        {
            m_radio1.setEnabled(false);
            m_radio2.setEnabled(false);
            m_searchobjecttypedropdownlist.setEnabled(false);
            m_searchobjecttypedropdownlist.setValue("dm_document");
            m_text.setEnabled(true);
        }
    }

    public void onLocationRadioClicked(Radio radio, ArgumentList args)
    {
        updateControlState(radio.getLabel(), args);
    }
}
