package org.ifc.idocs.migration.common;

public class CountryProjectDoc {

	private String countryCode;
	private String folderTypeCode;
	private String folderValueCode;
	private String sourceDocId;
	
	public String getCountryCode() {
		return countryCode;
	}
	public String getFolderTypeCode() {
		return folderTypeCode;
	}
	public void setFolderTypeCode(String folderTypeCode) {
		this.folderTypeCode = folderTypeCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getFolderValueCode() {
		return folderValueCode;
	}
	public void setFolderValueCode(String folderValueCode) {
		this.folderValueCode = folderValueCode;
	}
	public String getSourceDocId() {
		return sourceDocId;
	}
	public void setSourceDocId(String sourceDocId) {
		this.sourceDocId = sourceDocId;
	}
	
}
